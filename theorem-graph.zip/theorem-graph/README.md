# theorem-graph — exporting the Lean body as data

Tools that read the compiled Lean libraries and turn them into machine-readable data, plus the
exports themselves. Part of the repository-wide layout in the root [`README.md`](../README.md).

| Path | Contents |
|---|---|
| `Tools/TheoremGraph.lean` | `lake exe theoremgraph <outDir> <Modules…>`: every hand-written declaration as an AST tree (JSON), pretty-printed statement, source line, and statement/proof premises. |
| `Tools/StructuralBraid.lean` | The `#structural_braid <decl>` command: runs the verified structural braid encoder `QBX.Formal.StructuralBraid` on a real declaration (the term-reading front end itself is not verified). |
| `scripts/build_views.py` | Standard-library Python: turns an export into the HIF hypergraph, the alpha-invariant AST index + `duplicates.json`, and a Poincaré-disk embedding of the library → module → declaration tree. |
| `data/` | The exports per library (`qbx/`, `refinery/`, `spookyprimes/`, `sovereign/`, `requestproject/`, `sovkernel/`) and the merged view `all/`. **Formats, commands and numbers: `data/README.md`.** |
| `data/DEDUP_2026-10-09.md` | Every declaration removed in the 2026-10-09 duplicate clean-up and the name that replaced it. |

## Build and run (from the repository root)

```bash
lake build Tools theoremgraph                     # Tools depends on QBXFormal
lake exe theoremgraph theorem-graph/data/qbx QBX.Formal
python3 theorem-graph/scripts/build_views.py theorem-graph/data/qbx
```

The full regeneration recipe for all six libraries is in `data/README.md` §2.

## Dependencies

* `Tools.StructuralBraid` imports `QBX.Formal.StructuralBraid` (in `QBX/`).
* The Poincaré distance in `build_views.py` is the formula `poincareDist` from
  `sovereign/RequestProject/Hyperbolic/PoincareMetric.lean`; the Python is not itself verified.
* Exports refer to declarations by module name, so they stayed valid when the source folders
  moved on 2026-10-09. Source *paths* recorded inside older exports use the old layout
  (`unsorted/sov/…`, `Refinery/…`); see the move table in the root `README.md`.
