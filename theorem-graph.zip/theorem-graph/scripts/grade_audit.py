"""Audit of the six-channel grading: are reading collisions real braid equalities?

Run from the repository root after `python3 -m qbx_micro grade ...`:

    PYTHONPATH=QBX/src python3 theorem-graph/scripts/grade_audit.py [ROWS.jsonl.gz [STRANDS]]

For every class of declarations with identical six-channel readings but different
braid words, decide whether the words are the same braid with the Garside left normal
form (`qbx_ir.algebra.garside`, a complete invariant of B_n; needs numpy).  A class
with two different normal forms would be a genuine channel collision.
"""
import gzip, json, sys
sys.path.insert(0, "QBX/src"); sys.setrecursionlimit(100000)
from collections import defaultdict
from qbx_micro import grade as G
ROWS = sys.argv[1] if len(sys.argv) > 1 else 'theorem-graph/data/grades/all.jsonl.gz'
N = int(sys.argv[2]) if len(sys.argv) > 2 else 4
rows=[json.loads(l) for l in gzip.open(ROWS,'rt')]
cls=defaultdict(dict)
for r in rows:
    cls[json.dumps(r['readings'],sort_keys=True)].setdefault(r['word'],r['name'])
multi=[v for v in cls.values() if len(v)>1]
print('classes with >1 distinct word:', len(multi), 'extra words', sum(len(v)-1 for v in multi))
need={n for v in multi for n in v.values()}
D='theorem-graph/data/'
words={}
for x in G.load([D+l+'/decls.jsonl.gz' for l in ['qbx','refinery','spookyprimes','sovkernel','requestproject','sovereign']]):
    if x['name'] in need: words[x['name']]=G.encode(G.to_sexpr(x['ast']),N-2)
from qbx_ir.core.braid import Braid
from qbx_ir.algebra.garside import left_normal_form
same=diff=0; examples=[]
for v in multi:
    nfs={}
    for wh,name in v.items():
        nf=left_normal_form(Braid.from_short_form(N,words[name]))
        nfs.setdefault(repr(nf),[]).append(name)
    if len(nfs)==1: same+=1
    else:
        diff+=1
        if len(examples)<5: examples.append(list(v.values())[:2])
print('classes whose words are all the same braid:', same, ' classes with genuinely different braids:', diff)
print(examples)
