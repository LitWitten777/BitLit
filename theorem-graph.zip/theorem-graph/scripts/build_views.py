#!/usr/bin/env python3
"""Turn a `lake exe theoremgraph` export into the three views of the theorem body.

Input  (written by `Tools/TheoremGraph.lean`):
    <dir>/decls.jsonl        one declaration per line, with its statement AST
    <dir>/hyperedges.jsonl   premise hyperedges (head = declaration, tail = premises)

Output (written next to the input):
    hypergraph.hif.json      the premise hypergraph in HIF (Hypergraph Interchange Format)
    ast_index.jsonl          per declaration: AST size/depth, alpha-invariant shape hash,
                             head symbol, binder profile (no full tree: that stays in decls)
    duplicates.json          groups of declarations whose statements are identical up to
                             binder names (same shape hash), across all libraries
    poincare.csv / .json     a 2-D Poincare-disk embedding of the module/declaration tree
    poincare.svg             a picture of that embedding
    summary.json             counts and embedding-distortion statistics

Only the Python standard library is used.

Poincare embedding.  The tree is ROOT -> library -> module-path prefixes -> module ->
declarations.  It is embedded with Sarkar's construction: the root sits at 0; the children
of a node v are placed at one hyperbolic distance rho_v from v, evenly spaced in angle, leaving
the direction of v's parent free; rho_v >= tau grows with v's degree so that adjacent children
are at least tau apart (`child_radius`).  Moving v to the origin and back uses Mobius addition
    a (+) z = (a + z) / (1 + conj(a) z),
so the hyperbolic distance used throughout is
    d(x, y) = 2 artanh |(-x) (+) y|,
which is literally `poincareDist` in `sovereign/RequestProject/Hyperbolic/PoincareMetric.lean`.
The construction is correct because left Mobius translation is an isometry
(`poincareDist_mobiusAdd_left`), rotations are isometries (`poincareDist_map`) and
d(0, z) = 2 artanh |z| (`poincareDist_zero_left`), all proved there.
"""
from __future__ import annotations

import argparse
import cmath
import csv
import gzip
import hashlib
import json
import math
import random
import sys
from collections import Counter, defaultdict
from pathlib import Path


# ----------------------------------------------------------------------------- loading

def load_jsonl(path: Path):
    """Read `path`, or `path.gz` if only the compressed export is present."""
    if not path.exists() and path.with_name(path.name + ".gz").exists():
        path = path.with_name(path.name + ".gz")
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                yield json.loads(line)


def gz_text(path: Path, newline=None):
    """Open `path` for writing as deterministic gzip text (no timestamp, level 9).

    All large views are stored compressed (footprint clean-up of 2026-10-12); readers
    use :func:`load_jsonl`, which accepts `.gz` transparently.
    """
    raw = open(path, "wb")
    gz = gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0)
    import io
    return io.TextIOWrapper(gz, encoding="utf-8", newline=newline)


# ----------------------------------------------------------------------------- AST views

def shape(ast):
    """The AST with binder names removed (alpha-invariant canonical form)."""
    if not isinstance(ast, list) or not ast:
        return ast
    tag = ast[0]
    if tag in ("pi", "lam"):
        return [tag, ast[2], shape(ast[3]), shape(ast[4])]
    if tag == "let":
        return [tag, shape(ast[2]), shape(ast[3]), shape(ast[4])]
    if tag == "app":
        return [tag] + [shape(a) for a in ast[1:]]
    if tag == "proj":
        return [tag, ast[1], ast[2], shape(ast[3])]
    return ast


def shape_hash(ast) -> str:
    blob = json.dumps(shape(ast), separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()[:20]


def conclusion(ast):
    """Strip the leading binders (hypotheses / universally quantified variables)."""
    binders = []
    while isinstance(ast, list) and ast and ast[0] == "pi":
        binders.append(ast[2])
        ast = ast[4]
    return binders, ast


def head_symbol(ast) -> str:
    if isinstance(ast, list) and ast:
        if ast[0] == "app":
            return head_symbol(ast[1])
        if ast[0] == "const":
            return ast[1]
        return ast[0]
    return "?"


# ----------------------------------------------------------------------------- hypergraph

def to_hif(decls, edges, source: str):
    nodes = [{"node": d["name"],
              "attrs": {"kind": d["kind"], "module": d["module"], "library": d["library"]}}
             for d in decls]
    hif_edges, incidences = [], []
    for i, e in enumerate(edges):
        eid = f"{e['role']}:{e['head']}"
        hif_edges.append({"edge": eid, "attrs": {"role": e["role"], "arity": len(e["tail"]) + 1}})
        incidences.append({"edge": eid, "node": e["head"], "direction": "head"})
        for t in e["tail"]:
            incidences.append({"edge": eid, "node": t, "direction": "tail"})
    return {"network-type": "directed",
            "metadata": {"source": source,
                         "description": "Premise hypergraph of the Lean theorem body. "
                                        "Each hyperedge has one head (a declaration) and as "
                                        "tail the project-local constants used by its "
                                        "statement (role=statement) or proof (role=proof)."},
            "nodes": nodes, "edges": hif_edges, "incidences": incidences}


# ----------------------------------------------------------------------------- Poincare disk

def mobius_add(a: complex, z: complex) -> complex:
    """Mobius addition on the unit disk, a (+) z = (a + z) / (1 + conj(a) z)."""
    return (a + z) / (1 + a.conjugate() * z)


def poincare_dist(x: complex, y: complex) -> float:
    """`poincareDist x y = 2 * artanh ‖(-x) (+) y‖` (as in PoincareMetric.lean)."""
    r = abs(mobius_add(-x, y))
    r = min(r, 1 - 1e-16)
    return 2 * math.atanh(r)


class Tree:
    def __init__(self):
        self.children: dict[str, list[str]] = defaultdict(list)
        self.parent: dict[str, str | None] = {"ROOT": None}
        self.label: dict[str, str] = {"ROOT": "ROOT"}
        self.level: dict[str, str] = {"ROOT": "root"}

    def add(self, node: str, parent: str, label: str, level: str):
        if node in self.parent:
            return
        self.parent[node] = parent
        self.children[parent].append(node)
        self.label[node] = label
        self.level[node] = level

    def depth(self, node: str) -> int:
        d = 0
        while self.parent[node] is not None:
            node = self.parent[node]
            d += 1
        return d


def build_tree(decls) -> Tree:
    t = Tree()
    for d in sorted(decls, key=lambda d: (d["module"], d["kind"], d["name"])):
        parts = d["module"].split(".")
        parent = "ROOT"
        for i in range(1, len(parts) + 1):
            mid = "mod:" + ".".join(parts[:i])
            level = "library" if i == 1 else ("module" if i == len(parts) else "namespace")
            t.add(mid, parent, ".".join(parts[:i]), level)
            parent = mid
        t.add("decl:" + d["name"], parent, d["name"], d["kind"])
    return t


def child_radius(tau: float, slots: int) -> float:
    """Hyperbolic distance from a node to its children so that adjacent children (angular gap
    2*pi/slots) are at least `tau` apart:  cosh d = 1 + 2 sinh^2(rho) sin^2(pi/slots)."""
    if slots <= 1:
        return tau
    return max(tau, math.asinh(math.sinh(tau / 2) / math.sin(math.pi / slots)))


def sarkar_embed(t: Tree, tau: float):
    """Sarkar's construction with degree-adaptive edge lengths.  Returns positions and the
    hyperbolic length of the edge from each node to its parent."""
    pos = {"ROOT": 0j}
    edge_len = {"ROOT": 0.0}
    stack = ["ROOT"]
    while stack:
        v = stack.pop()
        kids = t.children.get(v, [])
        if not kids:
            continue
        zv = pos[v]
        p = t.parent[v]
        if p is None:
            base, slots, offset = 0.0, len(kids), 0
        else:
            w = mobius_add(-zv, pos[p])          # parent, seen from v moved to the origin
            base, slots, offset = cmath.phase(w), len(kids) + 1, 1
        rho = child_radius(tau, slots)
        r = math.tanh(rho / 2)                   # Euclidean radius of hyperbolic distance rho
        for k, c in enumerate(kids):
            ang = base + 2 * math.pi * (k + offset) / slots
            pos[c] = mobius_add(zv, cmath.rect(r, ang))   # move back: v (+) u
            edge_len[c] = rho
            stack.append(c)
    return pos, edge_len


def distortion(t: Tree, pos, edge_len, samples: int, seed: int = 0):
    nodes = [n for n in pos if n != "ROOT"]
    rng = random.Random(seed)
    cache: dict[str, list[str]] = {}

    def anc(n):
        if n not in cache:
            path = [n]
            while t.parent[path[-1]] is not None:
                path.append(t.parent[path[-1]])
            cache[n] = path
        return cache[n]

    ratios = []
    for _ in range(samples):
        a, b = rng.choice(nodes), rng.choice(nodes)
        if a == b:
            continue
        pa, pb = anc(a), anc(b)
        sb = set(pb)
        i = next(i for i, x in enumerate(pa) if x in sb)
        j = pb.index(pa[i])
        dtree = sum(edge_len[x] for x in pa[:i]) + sum(edge_len[x] for x in pb[:j])
        ratios.append(poincare_dist(pos[a], pos[b]) / dtree)
    ratios.sort()
    if not ratios:
        return {}
    return {"pairs": len(ratios), "min_ratio": ratios[0],
            "p01_ratio": ratios[len(ratios) // 100], "median_ratio": ratios[len(ratios) // 2],
            "max_ratio": ratios[-1],
            "note": "ratio = hyperbolic distance / weighted tree distance (sum of the "
                    "hyperbolic edge lengths on the tree path); 1.0 = isometric"}


def write_svg(path: Path, t: Tree, pos, libs: list[str], size: int = 2000):
    palette = ["#e6194b", "#3cb44b", "#4363d8", "#f58231", "#911eb4", "#46f0f0", "#f032e6",
               "#bcf60c", "#fabebe", "#008080", "#9a6324", "#800000"]
    colour = {lib: palette[i % len(palette)] for i, lib in enumerate(libs)}
    half = size / 2

    def xy(z):
        return half + z.real * (half - 10), half - z.imag * (half - 10)

    def lib_of(n):
        while t.level.get(n) != "library" and t.parent.get(n) is not None:
            n = t.parent[n]
        return t.label.get(n, "ROOT")

    out = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{size}" height="{size}" '
           f'viewBox="0 0 {size} {size}">',
           f'<rect width="{size}" height="{size}" fill="#0b0b12"/>',
           f'<circle cx="{half}" cy="{half}" r="{half - 10}" fill="none" stroke="#888" '
           f'stroke-width="2"/>']
    for n, p in t.parent.items():
        if p is None or not n.startswith("mod:"):
            continue
        (x1, y1), (x2, y2) = xy(pos[p]), xy(pos[n])
        out.append(f'<line x1="{x1:.2f}" y1="{y1:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" '
                   f'stroke="#555" stroke-width="0.6"/>')
    for n, z in pos.items():
        if n == "ROOT":
            continue
        x, y = xy(z)
        c = colour.get(lib_of(n), "#ccc")
        rad = 3.0 if n.startswith("mod:") else 1.2
        title = t.label[n].replace("&", "&amp;").replace("<", "&lt;")
        out.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{rad}" fill="{c}">'
                   f'<title>{title}</title></circle>')
    for i, lib in enumerate(libs):
        out.append(f'<text x="20" y="{40 + 28 * i}" fill="{colour[lib]}" font-size="24" '
                   f'font-family="monospace">{lib}</text>')
    out.append("</svg>")
    with gz_text(path) as fh:
        fh.write("\n".join(out))


# ----------------------------------------------------------------------------- main

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("dirs", nargs="+", type=Path,
                    help="export directories; several are merged into one view")
    ap.add_argument("--out", type=Path, default=None, help="output directory (default: first dir)")
    ap.add_argument("--tau", type=float, default=3.0,
                    help="minimum hyperbolic edge length / sibling separation (default 3.0)")
    ap.add_argument("--samples", type=int, default=20000, help="pairs for the distortion estimate")
    ap.add_argument("--no-svg", action="store_true")
    args = ap.parse_args(argv)
    out = args.out or args.dirs[0]
    out.mkdir(parents=True, exist_ok=True)

    decls, edges, seen = [], [], set()
    for d in args.dirs:
        for x in load_jsonl(d / "decls.jsonl"):
            if x["name"] not in seen:
                seen.add(x["name"])
                decls.append(x)
        edges.extend(load_jsonl(d / "hyperedges.jsonl"))

    # Premises that are generated declarations (`foo.eq_1`, `Foo.mk.injEq`, ...) are not
    # exported as nodes; attribute them to the nearest written ancestor (`foo`, `Foo`).
    def resolve(name: str):
        while name and name not in seen:
            name = name.rpartition(".")[0]
        return name or None

    clean = []
    for e in edges:
        if e["head"] not in seen:
            continue
        tail = sorted({r for r in map(resolve, e["tail"]) if r and r != e["head"]})
        if tail:
            clean.append({**e, "tail": tail})
    edges = clean

    # AST index + duplicates
    groups = defaultdict(list)
    with gz_text(out / "ast_index.jsonl.gz") as fh:
        for x in decls:
            h = shape_hash(x["ast"])
            if x["ast_truncated"]:
                # A cut-off AST does not determine the statement; never group these.
                h = "trunc-" + hashlib.sha256(x["name"].encode("utf-8")).hexdigest()[:14]
            binders, concl = conclusion(x["ast"])
            if x["kind"] == "theorem":
                groups[h].append(x["name"])
            fh.write(json.dumps({
                "name": x["name"], "kind": x["kind"], "module": x["module"],
                "shape_hash": h, "ast_nodes": x["ast_nodes"], "ast_depth": x["ast_depth"],
                "ast_truncated": x["ast_truncated"], "binders": "".join(binders),
                "conclusion_head": head_symbol(concl),
                "statement_uses": len(x["statement_uses"]), "proof_uses": len(x["proof_uses"]),
            }, ensure_ascii=False) + "\n")
    dups = sorted((v for v in groups.values() if len(v) > 1), key=len, reverse=True)
    (out / "duplicates.json").write_text(json.dumps(
        {"note": "theorems whose statements (fully elaborated Lean types) are identical up "
                 "to binder names; theorems with truncated ASTs are never grouped",
         "groups": dups}, indent=1, ensure_ascii=False), encoding="utf-8")

    # Hypergraph
    with gz_text(out / "hypergraph.hif.json.gz") as fh:
        fh.write(json.dumps(to_hif(decls, edges, ",".join(map(str, args.dirs))),
                            ensure_ascii=False))

    # Poincare embedding
    tree = build_tree(decls)
    max_depth = max(tree.depth(n) for n in tree.parent)
    tau = args.tau
    pos, edge_len = sarkar_embed(tree, tau)
    libs = sorted({x["library"] for x in decls})
    with gz_text(out / "poincare.csv.gz", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["id", "label", "level", "parent", "depth", "x", "y", "hyperbolic_radius",
                    "edge_length"])
        for n, z in pos.items():
            w.writerow([n, tree.label[n], tree.level[n], tree.parent[n] or "", tree.depth(n),
                        f"{z.real:.17g}", f"{z.imag:.17g}", f"{poincare_dist(0j, z):.6f}",
                        f"{edge_len[n]:.6f}"])
    with gz_text(out / "poincare.json.gz") as fh:
        fh.write(json.dumps(
        {"model": "Poincare disk", "tau": tau, "edge_length": edge_len,
         "distance": "2*artanh(|(-x) (+) y|), Mobius addition",
         "points": {n: [z.real, z.imag] for n, z in pos.items()}}))
    if not args.no_svg:
        write_svg(out / "poincare.svg.gz", tree, pos, libs)

    kinds = Counter(x["kind"] for x in decls)
    summary = {
        "declarations": len(decls), "by_kind": dict(kinds),
        "by_library": dict(Counter(x["library"] for x in decls)),
        "modules": sum(1 for n in tree.level if tree.level[n] == "module"),
        "hyperedges": len(edges),
        "hyperedges_by_role": dict(Counter(e["role"] for e in edges)),
        "truncated_asts": sum(1 for x in decls if x["ast_truncated"]),
        "empty_pretty_print": sum(1 for x in decls if not x["pp"]),
        "duplicate_statement_groups": len(dups),
        "theorems_in_duplicate_groups": sum(len(g) for g in dups),
        "tree_depth": max_depth, "tau": tau,
        "max_hyperbolic_radius": max(poincare_dist(0j, z) for z in pos.values()),
        "distortion": distortion(tree, pos, edge_len, args.samples),
    }
    (out / "summary.json").write_text(json.dumps(summary, indent=1), encoding="utf-8")
    print(json.dumps(summary, indent=1))
    return 0


if __name__ == "__main__":
    sys.exit(main())
