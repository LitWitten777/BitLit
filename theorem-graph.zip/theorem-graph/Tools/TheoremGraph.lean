module

public import Lean

/-!
# `theoremgraph` — export the project's theorem body as AST trees and a hypergraph

Usage (from the repository root, after the libraries are built):

```
lake exe theoremgraph <outDir> <RootModule> [<RootModule> ...]
```

for example `lake exe theoremgraph theorem-graph/data/qbx QBX.Formal`.

The program loads the compiled `.olean` files of the given root modules (with full private
data, so proof terms are available), keeps every declaration whose module lives under the
same top-level namespace as one of the roots (`QBX`, `Sovereign`, …), and writes

* `decls.jsonl` — one JSON object per declaration: name, kind, module, the statement as an
  AST tree (nested JSON arrays, see `astJson`), its node count / depth, a pretty-printed
  statement, and the project-local constants used by the statement and by the proof;
* `hyperedges.jsonl` — one directed hyperedge per declaration and role: the head is the
  declaration, the tail is the set of project-local constants its statement (`"statement"`)
  or its proof / body (`"proof"`) uses.

`theorem-graph/scripts/build_views.py` turns these into the HIF hypergraph and the
Poincaré-disk embedding.

AST encoding (statement = the declaration's type, `mdata` stripped, application spines
flattened):

```
["pi",  binderName, binderInfo, domain, body]      binderInfo ∈ "d" "i" "s" "c"
["lam", binderName, binderInfo, domain, body]
["let", name, type, value, body]
["app", head, arg₁, …, argₙ]
["const", name]      ["bvar", deBruijnIndex]     ["sort", level]
["nat", n]           ["str", s]                  ["proj", structName, idx, expr]
["fvar"]  ["mvar"]   ["trunc"]   (a subtree cut off by the node budget)
```
-/

open Lean Meta

namespace TheoremGraph

/-- Node budget for one statement AST; larger statements are cut with `["trunc"]`. -/
def astBudget : Nat := 4000

def binderCode : BinderInfo → String
  | .default => "d"
  | .implicit => "i"
  | .strictImplicit => "s"
  | .instImplicit => "c"

/-- Serialise an expression to the nested-array AST format, spending at most one unit of the
state (the remaining node budget) per emitted node. Returns the JSON and the depth. -/
partial def astJson (e : Expr) : StateM Nat (Json × Nat) := do
  match e with
  | .mdata _ b => astJson b
  | _ =>
  let left ← get
  if left == 0 then return (Json.arr #["trunc"], 1)
  set (left - 1)
  match e with
  | .bvar i => return (Json.arr #["bvar", i], 1)
  | .fvar _ => return (Json.arr #["fvar"], 1)
  | .mvar _ => return (Json.arr #["mvar"], 1)
  | .sort u => return (Json.arr #["sort", toString (format u)], 1)
  | .const n _ => return (Json.arr #["const", n.toString], 1)
  | .lit (.natVal n) => return (Json.arr #["nat", n], 1)
  | .lit (.strVal s) => return (Json.arr #["str", s], 1)
  | .proj s i b => do
      let (j, d) ← astJson b
      return (Json.arr #["proj", s.toString, i, j], d + 1)
  | .forallE n t b bi => do
      let (jt, dt) ← astJson t
      let (jb, db) ← astJson b
      return (Json.arr #["pi", n.eraseMacroScopes.toString, binderCode bi, jt, jb], max dt db + 1)
  | .lam n t b bi => do
      let (jt, dt) ← astJson t
      let (jb, db) ← astJson b
      return (Json.arr #["lam", n.eraseMacroScopes.toString, binderCode bi, jt, jb], max dt db + 1)
  | .letE n t v b _ => do
      let (jt, dt) ← astJson t
      let (jv, dv) ← astJson v
      let (jb, db) ← astJson b
      return (Json.arr #["let", n.eraseMacroScopes.toString, jt, jv, jb], max (max dt dv) db + 1)
  | .app .. => do
      let (jf, df) ← astJson e.getAppFn
      let mut out : Array Json := #["app", jf]
      let mut d := df
      for a in e.getAppArgs do
        let (ja, da) ← astJson a
        out := out.push ja
        d := max d da
      return (Json.arr out, d + 1)
  | .mdata _ b => astJson b

def kindOf : ConstantInfo → String
  | .thmInfo _ => "theorem"
  | .defnInfo _ => "def"
  | .axiomInfo _ => "axiom"
  | .opaqueInfo _ => "opaque"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "ctor"
  | .recInfo _ => "recursor"
  | .quotInfo _ => "quot"

/-- Declarations that are compiler / elaborator plumbing rather than user-facing content. -/
def isPlumbing (env : Environment) (n : Name) (ci : ConstantInfo) : Bool :=
  n.isInternalDetail || isAuxRecursor env n || isNoConfusion env n ||
  (match ci with | .recInfo _ => true | .quotInfo _ => true | _ => false)

def nameArr (ns : Array Name) : Json := Json.arr (ns.map (Json.str ·.toString))

/-- Command-line driver. -/
public def run (args : List String) : IO UInt32 := do
  match args with
  | outDir :: roots@(_ :: _) =>
    initSearchPath (← findSysroot)
    unsafe enableInitializersExecution
    let rootNames := roots.map String.toName
    let env ← importModules (rootNames.toArray.map ({ module := · })) {} (loadExts := true)
    let tops : List Name := rootNames.map (·.getRoot)
    let modNames := env.header.moduleNames
    -- Collect the project declarations.
    let mut decls : Array (Name × ConstantInfo × Name) := #[]
    for (n, ci) in env.constants.map₁.toList do
      if let some idx := env.getModuleIdxFor? n then
        let m := modNames[idx.toNat]!
        if tops.contains m.getRoot && !isPlumbing env n ci then
          decls := decls.push (n, ci, m)
    decls := decls.qsort (fun a b => Name.lt a.1 b.1)
    let projSet : NameSet := decls.foldl (fun s d => s.insert d.1) {}
    let localOnly (self : Name) (ns : Array Name) : Array Name :=
      (ns.filter (fun c => c != self && projSet.contains c)).toList.eraseDups.toArray
    IO.FS.createDirAll outDir
    let declH ← IO.FS.Handle.mk (System.FilePath.mk outDir / "decls.jsonl") .write
    let edgeH ← IO.FS.Handle.mk (System.FilePath.mk outDir / "hyperedges.jsonl") .write
    let ctx : Core.Context :=
      { fileName := "theoremgraph"
        fileMap := default
        maxHeartbeats := 0
        options := {} }
    let mut count := 0
    for (n, ci, m) in decls do
      let ty := ci.type
      let ((ast, depth), left) := (astJson ty).run astBudget
      let tyConsts := localOnly n ty.getUsedConstants
      let bodyConsts := match ci.value? (allowOpaque := true) with
        | some v => localOnly n v.getUsedConstants
        | none => #[]
      let info ← try
          (do
            let rng ← findDeclarationRanges? n
            let fmt ← (ppExpr ty).run' {} {}
            pure (rng.map (·.range), toString fmt) : CoreM (Option DeclarationRange × String)).toIO'
            ctx { env := env }
        catch _ => pure (none, "")
      -- Declarations without a source range are generated (equation lemmas, `congr_simp`,
      -- `sizeOf_spec`, `noConfusionType`, …); they are not part of the written theorem body.
      let some rng := info.1 | continue
      let ppStr := info.2
      let j := Json.mkObj [
        ("name", n.toString), ("kind", kindOf ci), ("module", m.toString),
        ("library", m.getRoot.toString), ("line", rng.pos.line),
        ("ast_nodes", astBudget - left), ("ast_depth", depth),
        ("ast_truncated", left == 0), ("ast", ast), ("pp", ppStr),
        ("statement_uses", nameArr tyConsts), ("proof_uses", nameArr bodyConsts)]
      declH.putStrLn j.compress
      if !tyConsts.isEmpty then
        edgeH.putStrLn (Json.mkObj [("head", n.toString), ("role", "statement"),
          ("tail", nameArr tyConsts)]).compress
      if !bodyConsts.isEmpty then
        edgeH.putStrLn (Json.mkObj [("head", n.toString), ("role", "proof"),
          ("tail", nameArr bodyConsts)]).compress
      count := count + 1
    declH.flush
    edgeH.flush
    IO.println s!"theoremgraph: wrote {count} declarations from {roots} to {outDir}"
    return 0
  | _ =>
    IO.eprintln "usage: lake exe theoremgraph <outDir> <RootModule> [<RootModule> ...]"
    return 1

end TheoremGraph

public def main (args : List String) : IO UInt32 := TheoremGraph.run args
