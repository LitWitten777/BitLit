import Lean
import QBX.Formal.StructuralBraid

/-!
# `#structural_braid` — the structural braid encoder on real Lean declarations

`QBX.Formal.Structural.encode` (in `QBX/Formal/StructuralBraid.lean`) is the verified structural
encoder of `docs/research/harmonic_bible_braid_bridge.md`, stated on the model `SExpr` of
elaborated terms.  This file is the (unverified) front end: `toSExpr` translates a `Lean.Expr`
into `SExpr String`, and

```
#structural_braid Nat.add_comm        -- 23 strands (default)
#structural_braid Nat.add_comm 8      -- 8 strands
```

prints the braid word (short form `±i`, 1-based) of the declaration's *type*, its length and
its writhe.  Constant codes are `String.hash` of the constant's full name.

Translation: `mdata` is stripped; `letE` becomes a β-redex `(fun x => body) value`; `proj S i e`
becomes the application of a constant `S.i` to `e`; universe levels are read as their numeric
value when they are closed (otherwise 0); string literals are coded by their hash; metavariables
are treated as free variables.  Free variables are named by their unique id, so renaming them
never changes the output (theorem S1, `encode_rename`).
-/

open Lean Elab Command Meta

namespace QBX.Tools.StructuralBraid

open QBX.Formal QBX.Formal.Structural

/-- Translate an elaborated term into the model `SExpr`. -/
def toSExpr : Expr → SExpr String
  | .bvar k => .bvar k
  | .fvar id => .fvar id.name.toString
  | .mvar id => .fvar ("?" ++ id.name.toString)
  | .sort u => .sort (u.toNat.getD 0)
  | .const n _ => .const n.toString
  | .app f a => .app (toSExpr f) (toSExpr a)
  | .lam n t b _ => .lam n.toString (toSExpr t) (toSExpr b)
  | .forallE n t b _ => .pi n.toString (toSExpr t) (toSExpr b)
  | .letE n t v b _ => .app (.lam n.toString (toSExpr t) (toSExpr b)) (toSExpr v)
  | .lit (.natVal v) => .lit v
  | .lit (.strVal s) => .lit s.hash.toNat
  | .mdata _ e => toSExpr e
  | .proj s i e => .app (.const (s.toString ++ "." ++ toString i)) (toSExpr e)

/-- The constant codes: the hash of the full name. -/
def code (c : String) : ℕ := c.hash.toNat

/-- The short form (`±i`, 1-based) of a braid word. -/
def shortForm {n : ℕ} (w : Word n) : List ℤ :=
  w.map fun l => if l.pos then ((l.idx : ℕ) + 1 : ℤ) else -((l.idx : ℕ) + 1 : ℤ)

/-- The braid word of a declaration's type on `m + 2` strands. -/
def braidOfType (m : ℕ) (ty : Expr) : Word (m + 2) := encode code m (toSExpr ty)

/-- `#structural_braid c [n]`: the structural braid of the type of `c` on `n` strands
(default 23). -/
syntax (name := structuralBraidCmd) "#structural_braid " ident (ppSpace num)? : command

@[command_elab structuralBraidCmd]
def elabStructuralBraid : CommandElab := fun stx => do
  let id := stx[1]
  let n : Nat := match stx[2].getOptional? with
    | some k => k.isNatLit?.getD 23
    | none => 23
  if Nat.blt n 2 then throwError "need at least 2 strands"
  let name ← liftCoreM <| realizeGlobalConstNoOverloadWithInfo id
  let info ← getConstInfo name
  let w := braidOfType (n - 2) info.type
  logInfo m!"{name} on {n} strands: {w.length} crossings, writhe {w.writhe}\n{shortForm w}"

end QBX.Tools.StructuralBraid

/-! The elaborated type of `Nat.add_comm` is exactly the model term `addCommStmt "n" "m"` of the
S3 certificate, so the theorems `encode_addComm_ne_addLt` and `encode_addComm_alpha` apply to it. -/
#eval show MetaM Unit from do
  let info ← getConstInfo ``Nat.add_comm
  unless QBX.Tools.StructuralBraid.toSExpr info.type ==
      (QBX.Formal.Structural.addCommStmt "n" "m" : QBX.Formal.Structural.SExpr String) do
    throwError "unexpected elaborated form of Nat.add_comm"
