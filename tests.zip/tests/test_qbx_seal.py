"""The one-command seal script (agents/scripts/qbx_seal.py)."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pytest
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

SCRIPTS = Path(__file__).resolve().parents[1] / "agents" / "scripts"
sys.path.insert(0, str(SCRIPTS))
import _frozen_sig as fs  # noqa: E402
import qbx_seal  # noqa: E402

import hashlib  # noqa: E402


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _pem(key, password: bytes | None = None) -> bytes:
    enc = (serialization.BestAvailableEncryption(password) if password
           else serialization.NoEncryption())
    return key.private_bytes(serialization.Encoding.PEM,
                             serialization.PrivateFormat.PKCS8, enc)


@pytest.fixture
def repo(tmp_path, monkeypatch):
    """A miniature QBX tree with one frozen file, signed by `owner`."""
    monkeypatch.delenv("QBX_FROZEN_TRUST_ANCHOR", raising=False)
    monkeypatch.delenv("QBX_SIGNING_KEY", raising=False)
    root = tmp_path / "QBX"
    mem = root / "agents" / "memory"
    cfg = root / "agents" / "config"
    mem.mkdir(parents=True)
    cfg.mkdir(parents=True)
    (root / "migrations").mkdir()
    a = root / "migrations" / "001_init.sql"
    a.write_text("create table t();\n")
    (root / "b.py").write_text("x = 1\n")
    key = Ed25519PrivateKey.generate()
    keyfile = tmp_path / "owner.pem"
    keyfile.write_bytes(_pem(key))
    pub = key.public_key().public_bytes(serialization.Encoding.Raw,
                                        serialization.PublicFormat.Raw).hex()
    (cfg / "frozen_trust_anchor.json").write_text(json.dumps({"keys": {"owner": pub}}))
    data = {"description": "test", "interfaces": {
        "migrations/001_init.sql": {"sha256": _sha(a), "frozen_at": "Phase 0"}}}
    (mem / "frozen_interfaces.json").write_text(json.dumps(data))
    sig = fs.sign(data, key, "owner")
    (mem / "frozen_interfaces.sig").write_text(json.dumps(sig))
    (mem / "decision_log.md").write_text("# Decision Log\n\nintro\n\n## 2026-01-01 — old\n\nbody\n")
    (mem / "project_state.json").write_text(json.dumps({"frozen_migrations": ["migrations/001_init.sql"]}))
    return root, keyfile, key


def run(root, *args, ask=None, ask_hidden=None):
    ask = ask or (lambda prompt: pytest.fail(f"unexpected prompt {prompt!r}"))
    ask_hidden = ask_hidden or (lambda prompt: pytest.fail(f"unexpected hidden prompt {prompt!r}"))
    return qbx_seal.main(["--root", str(root), *args], ask=ask, ask_hidden=ask_hidden)


def record(root):
    return json.loads((root / "agents/memory/frozen_interfaces.json").read_text())


def verified(root) -> bool:
    lay = qbx_seal.Layout(root)
    ok, _ = qbx_seal.verify(lay, record(root),
                            json.loads(lay.sig.read_text()),
                            json.loads(lay.anchor.read_text())["keys"])
    return ok


def test_status_on_signed_record(repo, capsys):
    root, _, _ = repo
    assert run(root, "status") == 0
    assert "Verified: yes" in capsys.readouterr().out


def test_freeze_then_unfreeze_with_key_file(repo):
    root, keyfile, _ = repo
    assert run(root, "freeze", str(root / "b.py"), "--label", "Phase 3", "--key", str(keyfile), "--yes") == 0
    rec = record(root)
    assert rec["interfaces"]["b.py"]["frozen_at"] == "Phase 3"
    assert verified(root)
    log = (root / "agents/memory/decision_log.md").read_text()
    assert log.index("Frozen-interface seal (owner)") < log.index("2026-01-01 — old")
    reqs = json.loads((root / "agents/memory/freeze_requests.json").read_text())
    assert reqs["pending"] == [] and reqs["history"][0]["path"] == "b.py"

    assert run(root, "unfreeze", "migrations/001_init.sql", "--reason", "superseded",
               "--key", str(keyfile), "--yes") == 0
    assert "migrations/001_init.sql" not in record(root)["interfaces"]
    assert verified(root)
    state = json.loads((root / "agents/memory/project_state.json").read_text())
    assert state["frozen_migrations"] == []


def test_unrequested_change_is_refused_and_nothing_written(repo):
    root, keyfile, _ = repo
    before = (root / "agents/memory/frozen_interfaces.json").read_bytes()
    (root / "migrations/001_init.sql").write_text("drop table t;\n")
    assert run(root, "--key", str(keyfile), "--yes") == 2
    assert (root / "agents/memory/frozen_interfaces.json").read_bytes() == before
    assert run(root, "amend", "migrations/001_init.sql", "--amendment", "A-9",
               "--key", str(keyfile), "--yes") == 0
    assert verified(root)
    assert record(root)["interfaces"]["migrations/001_init.sql"]["amended"] == "A-9"


def test_interactive_accept_of_unrequested_change(repo):
    root, keyfile, _ = repo
    (root / "migrations/001_init.sql").write_text("changed\n")
    answers = iter(["accept", "y", str(keyfile)])
    assert run(root, ask=lambda prompt: next(answers)) == 0
    assert verified(root)


def test_wrong_key_is_refused(repo, tmp_path):
    root, _, _ = repo
    other = tmp_path / "other.pem"
    other.write_bytes(_pem(Ed25519PrivateKey.generate()))
    before = (root / "agents/memory/frozen_interfaces.sig").read_bytes()
    assert run(root, "freeze", "b.py", "--key", str(other), "--yes") == 2
    assert (root / "agents/memory/frozen_interfaces.sig").read_bytes() == before
    assert "b.py" not in record(root)["interfaces"]


def test_missing_key_file_is_never_created(repo, tmp_path):
    root, _, _ = repo
    ghost = tmp_path / "typo.pem"
    assert run(root, "freeze", "b.py", "--key", str(ghost), "--yes") == 2
    assert not ghost.exists()


def test_encrypted_pem_and_hidden_paste(repo, tmp_path):
    root, _, key = repo
    enc = tmp_path / "enc.pem"
    enc.write_bytes(_pem(key, b"pw"))
    assert run(root, "freeze", "b.py", "--key", str(enc), "--yes",
               ask_hidden=lambda prompt: "pw") == 0
    assert verified(root)
    # pasted 64-hex seed through the interactive prompt
    seed = key.private_bytes(serialization.Encoding.Raw, serialization.PrivateFormat.Raw,
                             serialization.NoEncryption()).hex()
    (root / "b.py").write_text("x = 2\n")
    answers = iter(["accept", "y", ""])
    assert run(root, ask=lambda prompt: next(answers), ask_hidden=lambda prompt: seed) == 0
    assert verified(root)


def test_nothing_to_do(repo, capsys):
    root, keyfile, _ = repo
    assert run(root, "--key", str(keyfile), "--yes") == 0
    assert "Nothing to do" in capsys.readouterr().out


def test_queue_only_and_dry_run(repo):
    root, _, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only") == 0
    reqs = json.loads((root / "agents/memory/freeze_requests.json").read_text())
    assert reqs["pending"][0]["path"] == "b.py"
    assert run(root, "--dry-run") == 0
    assert "b.py" not in record(root)["interfaces"]


def test_compatible_with_verify_frozen(repo, monkeypatch):
    """A record sealed by qbx_seal verifies with the existing checker."""
    root, keyfile, _ = repo
    assert run(root, "freeze", "b.py", "--key", str(keyfile), "--yes") == 0
    data = record(root)
    sig = json.loads((root / "agents/memory/frozen_interfaces.sig.json").read_text())
    anchor = json.loads((root / "agents/config/frozen_trust_anchor.json").read_text())["keys"]
    assert fs.check(data, sig, anchor)[0] == "ok"


def test_rollback_restores_files(tmp_path):
    p, q = tmp_path / "p", tmp_path / "q"
    p.write_text("old")
    tx = qbx_seal.Transaction()
    tx.write(p, "new")
    tx.write(q, "created")
    tx.rollback()
    assert p.read_text() == "old" and not q.exists()


# ---- queue discipline: conflicts and stale requests -----------------------

def _pending(root):
    return json.loads((root / "agents/memory/freeze_requests.json").read_text())["pending"]


def test_request_records_queued_content_hash(repo):
    root, _, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only") == 0
    assert _pending(root)[0]["content_sha256"] == _sha(root / "b.py")


def test_same_path_different_content_is_refused(repo, capsys):
    """Two agents queue the same path with different content: refuse."""
    root, _, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only", "--requested-by", "agent-1") == 0
    first = _pending(root)[0]
    (root / "b.py").write_text("x = 2\n")
    assert run(root, "freeze", "b.py", "--queue-only", "--requested-by", "agent-2") == 2
    assert "conflicting request" in capsys.readouterr().err
    assert _pending(root) == [first]          # nothing overwritten


def test_owner_resolves_conflict_with_replace_or_drop(repo):
    root, _, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only", "--requested-by", "agent-1") == 0
    (root / "b.py").write_text("x = 2\n")
    assert run(root, "freeze", "b.py", "--queue-only", "--replace") == 0
    assert [r["content_sha256"] for r in _pending(root)] == [_sha(root / "b.py")]
    assert run(root, "drop", "b.py") == 0
    assert _pending(root) == []
    assert run(root, "drop", "b.py") == 2     # nothing left to drop


def test_identical_request_is_idempotent(repo):
    root, _, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only", "--requested-by", "agent-1") == 0
    assert run(root, "freeze", "b.py", "--queue-only", "--requested-by", "agent-2") == 0
    assert len(_pending(root)) == 1


def test_different_action_on_same_path_is_refused(repo, capsys):
    root, _, _ = repo
    (root / "migrations/001_init.sql").write_text("create table t2();\n")
    assert run(root, "amend", "migrations/001_init.sql", "--amendment", "A-1",
               "--queue-only") == 0
    assert run(root, "unfreeze", "migrations/001_init.sql", "--reason", "x",
               "--queue-only") == 2
    assert "conflicting request" in capsys.readouterr().err


def test_seal_refuses_file_modified_after_queueing(repo, capsys):
    root, keyfile, _ = repo
    assert run(root, "freeze", "b.py", "--queue-only") == 0
    (root / "b.py").write_text("x = 3\n")
    before = record(root)
    assert run(root, "--key", str(keyfile), "--yes") == 2
    assert "modified after" in capsys.readouterr().err
    assert record(root) == before and verified(root)
    # re-queueing the reviewed content resolves it
    assert run(root, "freeze", "b.py", "--queue-only", "--replace") == 0
    assert run(root, "--key", str(keyfile), "--yes") == 0
    assert record(root)["interfaces"]["b.py"]["sha256"] == _sha(root / "b.py")


def test_seal_refuses_hand_edited_duplicate_requests(repo, capsys):
    """Conflicting entries written into the queue by hand are also refused."""
    root, keyfile, _ = repo
    reqs = {"pending": [
        {"action": "freeze", "path": "b.py", "content_sha256": "0" * 64},
        {"action": "freeze", "path": "b.py", "content_sha256": _sha(root / "b.py")}],
        "history": []}
    (root / "agents/memory/freeze_requests.json").write_text(json.dumps(reqs))
    assert run(root, "--key", str(keyfile), "--yes") == 2
    assert "conflicting pending requests" in capsys.readouterr().err


def test_legacy_request_without_hash_still_seals(repo):
    root, keyfile, _ = repo
    reqs = {"pending": [{"action": "freeze", "path": "b.py"}], "history": []}
    (root / "agents/memory/freeze_requests.json").write_text(json.dumps(reqs))
    assert run(root, "--key", str(keyfile), "--yes") == 0
    assert "b.py" in record(root)["interfaces"]


def test_seal_clears_stale_owner_action():
    """A finished seal removes the "./seal.sh" owner to-do; a non-empty queue keeps it."""
    state = {"pending_owner_actions": ["./seal.sh — sign the queued freeze", "review X"]}
    plan = qbx_seal.Plan()
    cleared = qbx_seal.update_project_state(state, plan, pending_left=0)
    assert cleared["pending_owner_actions"] == ["review X"]
    assert "last_sealed" in cleared
    kept = qbx_seal.update_project_state(state, plan, pending_left=1)
    assert kept["pending_owner_actions"] == state["pending_owner_actions"]
