"""In-memory 2-category checker (Phase 1 sprint 6; mirror of migration 009).

Formal backing: ``Formal/TwoCategory.lean`` — identity preservation and
interchange are exactly functoriality of horizontal composition
(``exists_bifunctor_iff``); neither implies the other
(``interchange_not_implied``, ``identity_preservation_not_implied``); on the
2-cells of an identity 1-morphism the laws force vertical = horizontal and
commutativity (``eckmannHilton_two_cells``).
"""

from __future__ import annotations

import itertools
from collections import Counter

import pytest

from qbx.categorical.two_category import (
    TwoCategory,
    TwoCategoryChecker,
    TwoCategoryViolation,
    base_category,
    codiscrete_two_category,
    one_cell_two_category,
)
from qbx.core.enforced_functor import EnforcementMode


def reasons(tc: TwoCategory):
    return sorted(r for r, _ in tc.problems())


# Base category: A --f,g--> B --h--> C, plus an idempotent k : B → B (k ∘ k = k).
OBJECTS = "ABC"
MORPHISMS = {"f": ("A", "B"), "g": ("A", "B"), "h": ("B", "C"), "k": ("B", "B"),
             "hf": ("A", "C"), "hg": ("A", "C")}
COMPOSITIONS = {("h", "f"): "hf", ("h", "g"): "hg", ("k", "f"): "f", ("k", "g"): "g",
                ("k", "k"): "k", ("h", "k"): "h"}


def small() -> TwoCategory:
    return base_category(OBJECTS, MORPHISMS, COMPOSITIONS)


# ---------------------------------------------------------------------------
# Models that satisfy every law
# ---------------------------------------------------------------------------
def test_codiscrete_two_category_passes():
    tc = codiscrete_two_category(OBJECTS, MORPHISMS, COMPOSITIONS)
    assert tc.problems() == []
    assert TwoCategoryChecker(EnforcementMode.STRICT).check(tc)


def test_commutative_monoid_on_identity_cell_passes():
    z3 = ["0", "1", "2"]
    add = lambda a, b: str((int(a) + int(b)) % 3)  # noqa: E731
    assert one_cell_two_category(z3, "0", add, add).problems() == []


def perms3():
    return ["".join(p) for p in itertools.permutations("012")]


def pmul(a: str, b: str) -> str:
    return "".join(a[int(b[i])] for i in range(3))


def test_eckmann_hilton_noncommutative_group_fails_interchange():
    """S₃ with vertical = horizontal = group multiplication: every unit and
    associativity law holds, but interchange must fail (eckmannHilton_two_cells)."""
    tc = one_cell_two_category(perms3(), "012", pmul, pmul)
    assert set(reasons(tc)) == {"interchange"}


def test_eckmann_hilton_oracle_exhaustive():
    """All pairs of unital operations on {e, x, y}: the checker passes iff both
    are the same associative, commutative operation (Eckmann–Hilton)."""
    elems = ["e", "x", "y"]
    nonunit = [(a, b) for a in "xy" for b in "xy"]

    def ops():
        for vals in itertools.product(elems, repeat=4):
            table = dict(zip(nonunit, vals))

            def op(a, b, table=table):
                return b if a == "e" else a if b == "e" else table[(a, b)]
            yield table, op

    def assoc(op):
        return all(op(op(a, b), c) == op(a, op(b, c)) for a, b, c in itertools.product(elems, repeat=3))

    def comm(op):
        return all(op(a, b) == op(b, a) for a, b in itertools.product(elems, repeat=2))

    all_ops = list(ops())
    n_valid = 0
    for (tv, v), (th, h) in itertools.product(all_ops, repeat=2):
        expected = tv == th and assoc(v) and comm(v)
        got = one_cell_two_category(elems, "e", v, h).is_valid()
        assert got == expected
        n_valid += got
    assert n_valid > 0


def test_interchange_independent_of_identity_preservation():
    """interchange_not_implied: unit laws and identity preservation hold, interchange fails."""
    tc = one_cell_two_category(perms3(), "012", pmul, pmul)
    assert "identity_preservation" not in reasons(tc)
    assert "interchange" in reasons(tc)


def test_identity_preservation_independent_of_interchange():
    """identity_preservation_not_implied: interchange holds, 1_g ⋆ 1_f ≠ 1_(g∘f)."""
    tc = small()
    for f in ("f", "h", "hf"):
        tc.identity_cell(f)
    z = tc.add_cell("z", "hf", "hf")
    tc.compose_horizontal(tc.identity_cells["h"], tc.identity_cells["f"], result=z)
    assert reasons(tc) == ["identity_preservation"]


# ---------------------------------------------------------------------------
# Typing
# ---------------------------------------------------------------------------
def test_non_parallel_cell_rejected():
    tc = small()
    tc.add_cell("bad", "f", "h")
    assert reasons(tc) == ["cell_typing"]


def test_identity_cell_must_be_f_to_f():
    tc = small()
    tc.add_cell("a", "f", "g")
    tc.identity_cells["f"] = "a"
    assert reasons(tc) == ["identity_typing"]


def test_vertical_typing():
    tc = small()
    tc.add_cell("a", "f", "g")
    tc.add_cell("b", "f", "g")
    tc.vertical[("b", "a")] = "a"          # target(a) = g ≠ f = source(b)
    assert reasons(tc) == ["vertical_typing"]
    with pytest.raises(ValueError):
        TwoCategory.compose_vertical(small_with_cells(), "b", "a")


def small_with_cells():
    tc = small()
    tc.add_cell("a", "f", "g")
    tc.add_cell("b", "f", "g")
    return tc


def test_horizontal_typing_and_missing_composite():
    tc = small()
    a = tc.add_cell("a", "f", "g")
    b = tc.identity_cell("h")
    tc.horizontal[(b, a)] = a                 # result must be hf ⇒ hg
    probs = tc.problems()
    assert [r for r, _ in probs] == ["horizontal_typing"]
    assert probs[0][1]["missing_composite"] is False
    tc2 = small()
    del tc2.compositions[("h", "g")]
    a2 = tc2.add_cell("a", "f", "g")
    b2 = tc2.identity_cell("h")
    with pytest.raises(ValueError):
        tc2.compose_horizontal(b2, a2)
    tc2.horizontal[(b2, a2)] = a2
    probs = tc2.problems()
    assert [r for r, _ in probs] == ["horizontal_typing"]
    assert probs[0][1]["missing_composite"] is True


def test_horizontal_not_composable():
    tc = small()
    a = tc.add_cell("a", "f", "g")
    b = tc.add_cell("b", "g", "f")
    with pytest.raises(ValueError):
        tc.compose_horizontal(b, a)          # f : A → B does not precede g : A → B
    tc.horizontal[(b, a)] = a
    assert reasons(tc) == ["horizontal_typing"]


# ---------------------------------------------------------------------------
# Laws
# ---------------------------------------------------------------------------
def test_vertical_unit():
    tc = small()
    a = tc.add_cell("a", "f", "g")
    one_g = tc.identity_cell("g")
    assert tc.compose_vertical(one_g, a) == a     # writer uses the unit law
    tc.vertical[(one_g, a)] = tc.add_cell("a2", "f", "g")
    assert reasons(tc) == ["vertical_unit"]


def test_horizontal_unit():
    tc = small()
    a = tc.add_cell("a", "f", "g")
    unit_b = tc.identity_cell("id_B")
    assert tc.compose_horizontal(unit_b, a) == a
    tc.horizontal[(unit_b, a)] = tc.add_cell("a2", "f", "g")
    assert reasons(tc) == ["horizontal_unit"]


def test_identity_preservation_writer():
    tc = small()
    r = tc.compose_horizontal(tc.identity_cell("h"), tc.identity_cell("f"))
    assert r == tc.identity_cells["hf"]
    assert tc.problems() == []


def test_vertical_associativity():
    tc = small()
    a = tc.add_cell("a", "f", "g")
    b = tc.add_cell("b", "g", "f")
    c = tc.add_cell("c", "f", "g")
    ba = tc.compose_vertical(b, a)
    cb = tc.compose_vertical(c, b)
    tc.compose_vertical(cb, a)                # fresh cell
    tc.compose_vertical(c, ba)                # another fresh cell
    assert reasons(tc) == ["vertical_associativity"]
    tc2 = small()
    a = tc2.add_cell("a", "f", "g")
    b = tc2.add_cell("b", "g", "f")
    c = tc2.add_cell("c", "f", "g")
    ba = tc2.compose_vertical(b, a)
    cb = tc2.compose_vertical(c, b)
    x = tc2.compose_vertical(cb, a)
    tc2.compose_vertical(c, ba, result=x)
    assert tc2.problems() == []


def test_interchange_violation_and_repair():
    tc = small()
    a1, a2 = tc.add_cell("a1", "f", "g"), tc.add_cell("a2", "g", "f")
    b1 = tc.identity_cell("h")
    b2 = b1
    a = tc.compose_vertical(a2, a1)           # f ⇒ f (fresh)
    b = tc.compose_vertical(b2, b1)           # 1_h ∘ᵥ 1_h = 1_h
    x = tc.compose_horizontal(b, a)           # fresh hf ⇒ hf
    p = tc.compose_horizontal(b2, a2)
    q = tc.compose_horizontal(b1, a1)
    y = tc.compose_vertical(p, q)             # fresh, different from x
    assert x != y
    assert reasons(tc) == ["interchange"]
    (_, d), = tc.problems()
    assert d["horizontal_of_vertical"] == x and d["vertical_of_horizontal"] == y


def test_strict_mode_raises_and_permissive_logs():
    tc = small()
    tc.add_cell("bad", "f", "h")
    checker = TwoCategoryChecker(EnforcementMode.PERMISSIVE)
    assert checker.check(tc) is False
    assert [r for r, _ in checker.violations] == ["cell_typing"]
    with pytest.raises(TwoCategoryViolation):
        TwoCategoryChecker(EnforcementMode.STRICT).check(tc)


def test_fresh_result_cell_is_not_a_violation():
    """Laws are checked on the recorded data: redirecting a composite to a
    brand-new cell with no composites of its own breaks no recorded law."""
    tc = codiscrete_two_category(OBJECTS, MORPHISMS, COMPOSITIONS)
    key = ("k=>id_B", "id_B=>k")
    tc.vertical[key] = tc.add_cell("other", "id_B", "id_B")
    assert tc.problems() == []


def test_perturbing_any_composite_is_detected():
    """Z/2 × Z/2 on an identity 1-morphism with every composite recorded: changing
    any single vertical or horizontal composite is caught (by a unit law or, by
    Eckmann–Hilton, by interchange)."""
    elems = ["00", "01", "10", "11"]

    def add(a, b):
        return "".join(str((int(x) + int(y)) % 2) for x, y in zip(a, b))

    for table in ("vertical", "horizontal"):
        for key in itertools.product(elems, repeat=2):
            for wrong in elems:
                tc = one_cell_two_category(elems, "00", add, add)
                if getattr(tc, table)[key] == wrong:
                    continue
                getattr(tc, table)[key] = wrong
                assert tc.problems(), (table, key, wrong)
