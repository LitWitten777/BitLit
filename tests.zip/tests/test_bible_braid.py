"""Tests for qbx_bible: Bible text → braid conversion and the run pipeline."""

import json
import os
import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.polynomial_invariants import kauffman_bracket, kauffman_bracket_state_sum
from qbx_ir.io import load as load_qbx

from qbx_bible import (
    DEFAULT_CORPUS,
    Encoding,
    concat,
    consonantal,
    decode_short,
    encode_text,
    load_corpus,
    load_osis,
    run_braid,
    select,
    tokenize,
)
from qbx_bible.cli import main as cli_main
from qbx_bible.corpus import normalize_ref
from qbx_bible.encode import HEBREW, HEBREW_FINALS
from qbx_bible.pipeline import ledger_certificate

GEN_1_1 = "בראשית ברא אלהים את השמים ואת הארץ"
STANDARD = dict(zip(HEBREW, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90,
                             100, 200, 300, 400]))


@pytest.fixture(scope="module")
def genesis():
    return load_corpus()


# ---------------------------------------------------------------------------
# Corpus
# ---------------------------------------------------------------------------

def test_default_corpus_is_genesis_1(genesis):
    assert os.path.exists(DEFAULT_CORPUS)
    assert len(genesis) == 31
    assert genesis[0].ref == "Genesis 1:1" and genesis[-1].ref == "Genesis 1:31"


def test_genesis_1_1_text(genesis):
    """Points and accents are dropped; the consonantal text, letter count and
    standard gematria (2701) of Genesis 1:1 come out right."""
    v = select(genesis, "Genesis 1:1")[0]
    assert consonantal(v.text) == GEN_1_1
    words = tokenize(v.text)
    assert len(words) == 7 and sum(len(w) for w in words) == 28
    value = sum(STANDARD[HEBREW_FINALS.get(l.char, l.char)] for w in words for l in w)
    assert value == 2701


def test_maqqef_separates_words(genesis):
    v = select(genesis, "Genesis 1:3")[0]
    assert consonantal(v.text) == "ויאמר אלהים יהי אור ויהי אור"


@pytest.mark.parametrize("spec,refs", [
    ("Genesis 1:1", ["Genesis 1:1"]),
    ("Gen.1.2", ["Genesis 1:2"]),
    ("Genesis 1:3-5", ["Genesis 1:3", "Genesis 1:4", "Genesis 1:5"]),
    ("Genesis 1:30-2:3", ["Genesis 1:30", "Genesis 1:31"]),
])
def test_select(genesis, spec, refs):
    assert [v.ref for v in select(genesis, spec)] == refs


def test_select_whole_chapter_and_errors(genesis):
    assert len(select(genesis, "Genesis 1")) == 31
    assert len(select(genesis, "Gen 1")) == 31
    with pytest.raises(ValueError):
        select(genesis, "Exodus 1:1")
    with pytest.raises(ValueError):
        select(genesis, "Nowhere 1:1")


def test_normalize_ref():
    assert normalize_ref("Gen.1.1") == "Genesis 1:1"
    assert normalize_ref("1Sam.3.4") == "1 Samuel 3:4"
    assert normalize_ref("Song of Solomon 2:1") == "Song of Songs 2:1"


def test_osis_loader(tmp_path):
    xml = """<?xml version="1.0" encoding="UTF-8"?>
<osis xmlns="http://www.bibletechnologies.net/2003/OSIS/namespace"><osisText><div type="book">
<chapter osisID="Gen.1">
<verse osisID="Gen.1.3"><w>וַ/יֹּ֥אמֶר</w> <w>אֱלֹהִ֖ים</w> <w>יְהִ֣י</w> <w>א֑וֹר</w>
<w>וַֽ/יְהִי</w><seg type="x-maqqef">־</seg><w>אֽוֹר</w><seg type="x-sof-pasuq">׃</seg></verse>
<verse osisID="Gen.1.4"><w type="x-ketiv">כתיב</w><note type="variant"><rdg type="x-qere"><w>קרי</w></rdg></note></verse>
</chapter></div></osisText></osis>"""
    path = tmp_path / "Gen.xml"
    path.write_text(xml, encoding="utf-8")
    verses = load_osis(str(path))
    assert [v.ref for v in verses] == ["Genesis 1:3", "Genesis 1:4"]
    assert consonantal(verses[0].text) == "ויאמר אלהים יהי אור ויהי אור"
    assert "־" in verses[0].text and verses[0].text.endswith("׃")
    assert consonantal(verses[1].text) == "כתיב"        # the written text; the qere note is skipped
    assert load_corpus(str(path)) == verses


# ---------------------------------------------------------------------------
# Encoding
# ---------------------------------------------------------------------------

def test_generator_rule():
    enc = Encoding(8)
    short = encode_text("אבגדהוזחת", "t", enc).braid.short_form()
    assert short == [1, 2, 3, 4, 5, 6, 7, 1, (22 - 1) % 7 + 1]


def test_sofit_rule_inverts_finals():
    on = encode_text("ם מ", "t", Encoding(8)).braid.short_form()
    off = encode_text("ם מ", "t", Encoding(8, sofit_rule=False)).braid.short_form()
    k = HEBREW.index("מ") % 7 + 1
    assert on == [-k, k] and off == [k, k]


def test_greek_and_latin():
    assert encode_text("abc, ABC!", "t").braid.short_form() == [1, 2, 3, 1, 2, 3]
    # λ=11, ο=15, γ=3, final ς ↦ inverse of σ=18; i = (k − 1) mod 7 + 1
    assert encode_text("λόγος", "t").braid.short_form() == [4, 1, 3, 1, -4]


def test_verse_braid_is_product_of_word_braids(genesis):
    v = select(genesis, "Genesis 1:1")[0]
    e = encode_text(v.text, v.ref)
    product = Braid.identity(8)
    for w in GEN_1_1.split():
        product = product * encode_text(w, w).braid
    assert e.braid.short_form() == product.short_form()
    assert len(e.braid.word) == 28 and e.braid.strand_count == 8
    assert e.braid.metadata["ref"] == "Genesis 1:1"
    assert [w["text"] for w in e.braid.metadata["words"]] == GEN_1_1.split()


def test_injective_encoding_round_trips_genesis_1(genesis):
    enc = Encoding(23)
    for v in genesis:
        letters = consonantal(v.text).replace(" ", "")
        assert decode_short(encode_text(v.text, v.ref, enc).braid.short_form(), "hebrew", enc) == letters
    with pytest.raises(ValueError):
        decode_short([1], "hebrew", Encoding(8))


def test_passage_is_concatenation(genesis):
    parts = [encode_text(v.text, v.ref) for v in select(genesis, "Genesis 1:1-3")]
    p = concat(parts, "Genesis 1:1-3")
    assert p.braid.short_form() == sum((x.braid.short_form() for x in parts), [])
    assert [x["ref"] for x in p.braid.metadata["verses"]] == ["Genesis 1:1", "Genesis 1:2", "Genesis 1:3"]


# ---------------------------------------------------------------------------
# Run
# ---------------------------------------------------------------------------

def test_run_genesis_1_1(genesis):
    v = select(genesis, "Genesis 1:1")[0]
    e = encode_text(v.text, v.ref)
    r = run_braid(e, Encoding())
    assert r["all_checks_passed"], r["checks"]
    assert r["ledger"]["accepted"] and r["ledger"]["steps"] > 0
    assert r["crossings"] == 28 and r["words"] == 7
    assert r["invariants"]["writhe"] == 28 - 2 * 3          # three final letters
    assert r["sofit_test"]["finals_in_text"] == 3
    assert set(r["views"]) == {"L0", "L1", "L2", "L3", "L4", "L5", "L6", "L7"}
    assert "jones" in r["invariants"] and "alexander" in r["invariants"]
    json.dumps(r, ensure_ascii=False)                       # serialisable
    r2 = run_braid(encode_text(v.text, v.ref), Encoding(), views=[])
    assert r2["fingerprint_hash"] == r["fingerprint_hash"]  # deterministic


def test_garside_check_can_fail(genesis):
    """The sofit test is discriminating: for Genesis 1:1 the element changes."""
    v = select(genesis, "Genesis 1:1")[0]
    on = encode_text(v.text, v.ref, Encoding(8, True)).braid
    off = encode_text(v.text, v.ref, Encoding(8, False)).braid
    assert not braid_group_equal(on, off)


def test_ledger_certificate_matches_reduction():
    b = Braid.from_short_form(4, [3, 1, -1, 2, 1, 3])
    cert = ledger_certificate(b, include_trace=True)
    assert cert["accepted"] and not cert["problems"]
    assert cert["reduced"].short_form() == cert["trace"][-1]["output_word"]
    assert braid_group_equal(b, cert["reduced"])


def test_every_verse_of_genesis_1_runs(genesis):
    for v in genesis:
        r = run_braid(encode_text(v.text, v.ref), Encoding(), views=["L2"])
        assert r["all_checks_passed"], (v.ref, r["checks"])


def test_cli_writes_loadable_outputs(tmp_path, capsys):
    out = tmp_path / "out"
    code = cli_main(["--ref", "Genesis 1:1-2", "--passage", "--views", "L0,L2,L6",
                     "--out", str(out), "--svg"])
    assert code == 0
    names = sorted(os.listdir(out))
    assert "Genesis_1_1.qbx.json" in names and "Genesis_1_1_2.qbx.json" in names
    assert "Genesis_1_1.svg" in names
    b = load_qbx(str(out / "Genesis_1_1.qbx.json"))
    report = json.loads((out / "Genesis_1_1.report.json").read_text(encoding="utf-8"))
    assert b.short_form() == report["word"] and b.strand_count == 8
    passage = json.loads((out / "Genesis_1_1_2.report.json").read_text(encoding="utf-8"))
    assert passage["crossings"] == report["crossings"] + json.loads(
        (out / "Genesis_1_2.report.json").read_text(encoding="utf-8"))["crossings"]
    assert "3 braids, all checks passed" in capsys.readouterr().out


def test_cli_text_and_errors(capsys):
    assert cli_main(["--text", "In the beginning", "--no-write", "--views", "none"]) == 0
    assert cli_main(["--ref", "Exodus 1:1", "--no-write"]) == 2
    assert cli_main(["--views", "L9", "--no-write"]) == 2


# ---------------------------------------------------------------------------
# Kauffman bracket: Temperley–Lieb evaluation agrees with the state sum
# ---------------------------------------------------------------------------

def test_kauffman_bracket_matches_state_sum():
    rng = random.Random(7)
    for _ in range(150):
        n = rng.randint(2, 6)
        word = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 11))]
        b = Braid.from_short_form(n, word)
        assert kauffman_bracket(b) == kauffman_bracket_state_sum(b), (n, word)
