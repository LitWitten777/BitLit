"""Tests for ``qbx.categorical.topos`` (Phase 1 sprint 8, migration 011).

Formal backing: ``Formal/Topos.lean`` (registry H-031 – H-033).
"""

from __future__ import annotations

import random
from collections import Counter

import pytest

from qbx.categorical.topos import (
    REASONS,
    SubobjectClassifier,
    ToposChecker,
    ToposViolation,
    all_partial_orders,
    finite_sets,
    poset,
)
from qbx.core.enforced_functor import EnforcementMode
from tests.topos_examples import injective, random_classifier, surjective


# ---------------------------------------------------------------------------
# Finite sets
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("sizes", [[0, 1, 2], [0, 1, 2, 3], [1, 2, 3]])
def test_finite_sets_with_two_element_omega_classify(sizes):
    assert finite_sets(sizes).problems() == []


def test_finite_sets_builder_records_every_function():
    S = finite_sets([0, 1, 2, 3])
    assert len(S.category.morphisms) == sum(b ** a for a in range(4) for b in range(4))


def test_classify_in_finite_sets():
    S = finite_sets([0, 1, 2])
    assert S.classify("s1s2_0") == "s2s2_10"
    assert S.classify("s1s2_1") == "id_s2"
    assert S.classify("s0s2_") == "s2s2_00"
    assert S.classify("s2s1_00") is None                 # not a monomorphism
    assert S.classify("nope") is None


def test_characteristic_of_identity_is_truth_after_bang():
    """chi_id_eq: χ(id_X) = truth ∘ !_X (the constant map to 1)."""
    S = finite_sets([0, 1, 2, 3])
    for n in range(4):
        assert S.classify(f"id_s{n}") == f"s{n}s2_" + "1" * n


def test_characteristic_is_the_indicator_function():
    """For every injective U → X in finite sets, χ is the indicator of the image."""
    S = finite_sets([0, 1, 2, 3])
    for m, (u, x) in S.category.morphisms.items():
        if not injective(m) or x == "s0":
            continue
        n = int(x[1:])
        image = set(range(n)) if m.startswith("id_") else {int(c) for c in m.split("_")[1]}
        values = "".join("1" if i in image else "0" for i in range(n))
        expected = f"{x}s2_{values}"
        assert S.classify(m) == (expected if expected in S.category.morphisms else "id_s2"), m


def test_three_element_omega_is_not_a_classifier():
    """classifier_existence_not_sufficient: every mono is classified, the
    non-surjective ones by 2^|X∖U| morphisms."""
    S = finite_sets([0, 1, 2, 3], omega_size=3)
    probs = S.problems()
    assert {r for r, _ in probs} == {"characteristic_not_unique"}
    assert {d["mono"] for _, d in probs} == {m for m in S.category.morphisms
                                             if injective(m) and not surjective(m)}
    for _, d in probs:
        a, b = (int(x) for x in d["mono"].split("_")[0].split("s")[1:])
        assert d["count"] == 2 ** (b - a)


def test_non_mono_subobject():
    S = finite_sets([0, 1, 2])
    S.register_subobject("s2s1_00")
    assert S.problems() == [("not_mono", {"mono": "s2s1_00", "count": 7})]


def test_wrong_characteristic():
    S = finite_sets([0, 1, 2])
    S.register_subobject("s1s2_0")
    S.attach_characteristic("s1s2_0", "id_s2")
    assert Counter(r for r, _ in S.problems()) == Counter({"pullback_not_commuting": 1,
                                                           "pullback_existence": 2})


def test_pullback_uniqueness_failure():
    """A non-mono registered with a χ: f = (0 ↦ 1, 1 ↦ 1) factors through the
    constant s2 → s2 in two ways."""
    S = finite_sets([0, 1, 2])
    S.register_subobject("s2s2_11")
    S.attach_characteristic("s2s2_11", "s2s2_11")
    reasons = Counter(r for r, _ in S.problems())
    assert reasons["pullback_uniqueness"] > 0 and reasons["not_mono"] == 1


def test_classifier_typing_stops_the_check():
    S = finite_sets([0, 1, 2])
    S.truth = "s2s1_00"
    assert S.problems() == [("classifier_typing", {"omega": "s2", "truth": "s2s1_00"})]
    S.truth = None
    assert S.problems() == [("classifier_typing", {"omega": "s2", "truth": None})]


def test_terminal_check():
    S = finite_sets([0, 1, 2])
    S.truth = "s2s2_11"
    assert sorted(S.problems(), key=repr) == sorted(
        [("terminal_uniqueness", {"object": "s1", "count": 2}),
         ("terminal_uniqueness", {"object": "s2", "count": 4})], key=repr)


def test_truth_values():
    S = finite_sets([0, 1, 2])
    S.truth_values.update({"true": "s1s2_1", "false": "s1s2_0", "half": "s2s2_10"})
    assert S.problems() == [("truth_value_typing", {"name": "half", "morphism": "s2s2_10"})]


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------
def test_register_subobject_refuses_and_is_idempotent():
    S = finite_sets([0, 1, 2])
    with pytest.raises(KeyError):
        S.register_subobject("nope")
    with pytest.raises(ValueError, match="not the target"):
        S.register_subobject("s1s2_0", "s1")
    a = S.register_subobject("s1s2_0", "s2")
    assert S.register_subobject("s1s2_0") is a and len(S.subobjects) == 1


def test_attach_characteristic_refuses_and_never_replaces():
    S = finite_sets([0, 1, 2])
    with pytest.raises(KeyError):
        S.attach_characteristic("s1s2_0", "s2s2_10")
    S.register_subobject("s1s2_0")
    with pytest.raises(ValueError, match="not a morphism X"):
        S.attach_characteristic("s1s2_0", "s1s2_1")
    S.attach_characteristic("s1s2_0", "s2s2_10")
    S.attach_characteristic("s1s2_0", "s2s2_10")
    with pytest.raises(ValueError, match="already has"):
        S.attach_characteristic("s1s2_0", "s2s2_11")
    assert S.characteristics == {"s1s2_0": "s2s2_10"}
    assert S.problems() == []


# ---------------------------------------------------------------------------
# Oracle: partial orders
# ---------------------------------------------------------------------------
def test_partial_order_counts():
    assert [len(list(all_partial_orders("abcd"[:n]))) for n in range(1, 5)] == [1, 3, 19, 219]


def test_partial_orders_classifier_iff_one_element():
    """partialOrder_hasClassifier_iff, on every partial order with at most four
    elements and every candidate (1, Ω) with 1 ≤ Ω."""
    for n in range(1, 5):
        elems = list("abcd"[:n])
        for rel in all_partial_orders(elems):
            for t in elems:
                for om in elems:
                    if t == om or (t, om) in rel:
                        assert poset(elems, rel, t, om).is_valid() == (n == 1)


def test_two_chain_has_unique_but_missing_characteristics():
    """classifier_uniqueness_not_sufficient: in false ≤ true with truth = id_true,
    the mono false → true has no characteristic morphism, none is ever doubled."""
    P = poset(["f", "t"], {("f", "t")}, "t", "t")
    assert P.problems() == [("unclassified_mono", {"mono": "f<=t"})]


# ---------------------------------------------------------------------------
# Checker modes and random recordings
# ---------------------------------------------------------------------------
def test_checker_modes():
    S = finite_sets([0, 1, 2])
    S.register_subobject("s2s1_00")
    checker = ToposChecker(EnforcementMode.PERMISSIVE)
    assert checker.check(S) is False and checker.violations[0][0] == "not_mono"
    with pytest.raises(ToposViolation):
        ToposChecker(EnforcementMode.STRICT).check(S)
    assert ToposChecker(EnforcementMode.STRICT).check(finite_sets([0, 1, 2])) is True


def test_random_recordings_use_known_reasons():
    rng = random.Random(7)
    seen = Counter()
    for _ in range(80):
        cls = random_classifier(rng)
        assert isinstance(cls, SubobjectClassifier)
        for r, _ in cls.problems():
            assert r in REASONS
            seen[r] += 1
    assert set(seen) == set(REASONS)
