"""Tests for the Phase 1 adjunction engine (in-memory reference implementation)."""

import pytest

from qbx.categorical import (
    Adjunction,
    AdjunctionViolation,
    ComposedFunctor,
    IdentityFunctor,
    NaturalTransformation,
)
from qbx.core.enforced_functor import Category, EnforcedFunctor, EnforcementMode

STRICT = EnforcementMode.STRICT
PERMISSIVE = EnforcementMode.PERMISSIVE


class TableFunctor(EnforcedFunctor):
    def __init__(self, functor_id, source, target, objs, morphs, mode=PERMISSIVE):
        super().__init__(functor_id, functor_id, source, target, mode=mode)
        self._objs, self._morphs = objs, morphs
        for o in source.objects:
            self.map_object(o)
        for m in source.morphisms:
            self.map_morphism(m)

    def _map_object(self, obj_id):
        return self._objs[obj_id]

    def _map_morphism(self, morph_id):
        return self._morphs[morph_id]


def _indiscrete(extra=()):
    """I: objects P, Q;  p: P → Q,  q: Q → P,  q ∘ p = id_P,  p ∘ q = id_Q."""
    I = Category(id="I", name="indiscrete")
    for o in ("P", "Q"):
        I.add_object(o, o)
        I.add_identity(o, f"id_{o}")
    I.add_morphism("p", "P", "Q")
    I.add_morphism("q", "Q", "P")
    I.add_composition("p", "q", "id_P")    # q ∘ p = id_P   (p first)
    I.add_composition("q", "p", "id_Q")    # p ∘ q = id_Q   (q first)
    for name, src, tgt in extra:
        I.add_morphism(name, src, tgt)
    return I


def _build(I, unit, counit, mode=PERMISSIVE):
    """F: I → I constant at P,  G = Id_I;  F ⊣ G for the standard (η, ε)."""
    G = IdentityFunctor(I, "G", mode=mode)
    F = TableFunctor("F", I, I, {"P": "P", "Q": "P"}, {m: "id_P" for m in I.morphisms}, mode)
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(I, mode=mode),
                                ComposedFunctor(F, G, mode=mode), mode=mode)
    eps = NaturalTransformation("eps", "eps", ComposedFunctor(G, F, mode=mode),
                                IdentityFunctor(I, mode=mode), mode=mode)
    for x, m in unit.items():
        eta.set_component(x, m, check=False)
    for y, m in counit.items():
        eps.set_component(y, m, check=False)
    return Adjunction("adj", "F⊣G", F, G, eta, eps, mode=mode)


UNIT = {"P": "id_P", "Q": "q"}
COUNIT = {"P": "id_P", "Q": "p"}


def _laws(adj):
    return sorted(v["law"] for v in adj.violations)


def test_genuine_adjunction_passes_strict():
    adj = _build(_indiscrete(), UNIT, COUNIT, mode=STRICT)
    assert adj.verify_all_laws()
    assert adj.violations == []
    assert adj.unit.violations == [] and adj.counit.violations == []


def test_right_triangle_uses_correct_order():
    """G(ε_Q) ∘ η_Q = p ∘ q = id_Q; the reverse order q ∘ p = id_P would fail."""
    adj = _build(_indiscrete(), UNIT, COUNIT)
    assert adj.verify_right_triangle()


def test_right_triangle_violation():
    I = _indiscrete(extra=[("q2", "Q", "P"), ("e", "Q", "Q")])
    I.add_composition("q2", "p", "e")      # p ∘ q2 = e ≠ id_Q
    adj = _build(I, {"P": "id_P", "Q": "q2"}, COUNIT)
    assert not adj.verify_triangles()
    assert _laws(adj) == ["triangle_right"]


def test_left_triangle_violation():
    I = _indiscrete(extra=[("e", "P", "P")])
    adj = _build(I, UNIT, {"P": "e", "Q": "p"})
    assert not adj.verify_triangles()
    assert _laws(adj) == ["triangle_left", "triangle_left", "triangle_right"]


def test_missing_composite_is_violation():
    I = _indiscrete()
    del I.compositions[("q", "p")]
    adj = _build(I, UNIT, COUNIT)
    assert not adj.verify_triangles()
    assert _laws(adj) == ["triangle_right_composite_missing"]


def test_missing_component_is_violation():
    adj = _build(_indiscrete(), UNIT, {"P": "id_P"})
    assert not adj.verify_all_laws()
    assert _laws(adj) == ["counit_component_missing", "triangle_right_missing"]
    assert any(v["law"] == "naturality_missing_data" for v in adj.counit.violations)


def test_component_typing_violation():
    adj = _build(_indiscrete(), {"P": "id_P", "Q": "id_Q"}, COUNIT)
    assert not adj.verify_components()
    assert _laws(adj) == ["unit_component_typing"]


def test_unit_functor_mismatch():
    I = _indiscrete()
    adj = _build(I, UNIT, COUNIT)
    adj.unit = NaturalTransformation("eta'", "eta'", IdentityFunctor(I), IdentityFunctor(I))
    assert not adj.verify_functors()
    assert _laws(adj).count("unit_functor_mismatch") == 4   # object Q; id_Q, p, q


def test_category_typing_violation():
    I = _indiscrete()
    J = Category(id="J", name="other")
    J.add_object("Z", "Z")
    J.add_identity("Z", "id_Z")
    adj = _build(I, UNIT, COUNIT)
    adj.G = IdentityFunctor(J)
    assert not adj.verify_all_laws()
    assert _laws(adj) == ["adjunction_typing"]


def test_strict_mode_raises():
    I = _indiscrete(extra=[("e", "P", "P")])
    adj = _build(I, UNIT, {"P": "e", "Q": "p"})
    adj.mode = STRICT
    with pytest.raises(AdjunctionViolation) as exc:
        adj.verify_triangles()
    assert exc.value.law == "triangle_left"


def test_generator_shortcut_for_unit_and_counit():
    adj = _build(_indiscrete(), UNIT, COUNIT)
    assert adj.verify_all_laws(unit_generators=["p", "q"], counit_generators=["p", "q"])
    assert adj.violations == []


def test_hom_set_bijection():
    adj = _build(_indiscrete(), UNIT, COUNIT)
    # f = p : F(Q) = P → Q  ↦  G(p) ∘ η_Q = p ∘ q = id_Q : Q → G(Q)
    assert adj.left_adjunct_at("Q", "p") == "id_Q"
    # and back: id_Q : Q → G(Q)  ↦  ε_Q ∘ F(id_Q) = p ∘ id_P = p
    assert adj.right_adjunct("Q", "id_Q") == "p"
    # F(X) = P for both X, so the bare transpose is ambiguous
    assert adj.left_adjunct("p") is None
    for x in ("P", "Q"):
        for f in ("id_P", "p"):
            g = adj.left_adjunct_at(x, f)
            assert g is not None and adj.right_adjunct(x, g) == f


def test_serialize_intent_is_deterministic():
    a = _build(_indiscrete(), UNIT, COUNIT)
    b = _build(_indiscrete(), UNIT, COUNIT)
    assert a.serialize_intent()[0] == b.serialize_intent()[0]


# ---- Neither triangle implies the other (Formal/Adjunction.lean) ----------


def _terminal():
    T = Category(id="T", name="terminal")
    T.add_object("*", "*")
    T.add_identity("*", "id_*")
    return T


def _zero_monoid():
    """One object s; morphisms id_s and z with z ∘ z = z (the monoid {1, 0})."""
    M = Category(id="M", name="{1,0}")
    M.add_object("s", "s")
    M.add_identity("s", "id_s")
    M.add_morphism("z", "s", "s")
    M.add_composition("z", "z", "z")
    return M


def test_right_triangle_does_not_imply_left():
    """Mirror of `right_triangle_not_implies_left`: counit component 0."""
    T, M = _terminal(), _zero_monoid()
    F = TableFunctor("F", T, M, {"*": "s"}, {"id_*": "id_s"})
    G = TableFunctor("G", M, T, {"s": "*"}, {"id_s": "id_*", "z": "id_*"})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(T), ComposedFunctor(F, G))
    eps = NaturalTransformation("eps", "eps", ComposedFunctor(G, F), IdentityFunctor(M))
    eta.set_component("*", "id_*")
    eps.set_component("s", "z")
    adj = Adjunction("a", "a", F, G, eta, eps, mode=PERMISSIVE)
    assert eta.verify_all_laws() and eps.verify_all_laws()   # both natural
    assert adj.verify_right_triangle()
    assert not adj.verify_left_triangle()
    assert _laws(adj) == ["triangle_left"]


def test_left_triangle_does_not_imply_right():
    """Mirror of `left_triangle_not_implies_right`: unit component 0."""
    T, M = _terminal(), _zero_monoid()
    F = TableFunctor("F", M, T, {"s": "*"}, {"id_s": "id_*", "z": "id_*"})
    G = TableFunctor("G", T, M, {"*": "s"}, {"id_*": "id_s"})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(M), ComposedFunctor(F, G))
    eps = NaturalTransformation("eps", "eps", ComposedFunctor(G, F), IdentityFunctor(T))
    eta.set_component("s", "z")
    eps.set_component("*", "id_*")
    adj = Adjunction("a", "a", F, G, eta, eps, mode=PERMISSIVE)
    assert eta.verify_all_laws() and eps.verify_all_laws()
    assert adj.verify_left_triangle()
    assert not adj.verify_right_triangle()
    assert _laws(adj) == ["triangle_right"]
