"""Shared examples and random generators for the addressing tests (pure Python
and live database)."""

from __future__ import annotations

import json
import random
import struct
import uuid
from typing import Any, Dict, List, Tuple

import cbor2

from qbx.addressing.address import HASH_ALGOS, AddressV2
from qbx.core.hashing import pq_hash

# One input per malformation code (decoding stops there).
MALFORMED: Dict[str, List[bytes]] = {
    "truncated": [b"", b"\x19\x01", b"\x62a", b"\x82\x01", b"\xa1\x61a"],
    "reserved_info": [b"\x1c", b"\x9e"],
    "indefinite_length": [b"\x9f\xff", b"\x7f\xff"],
    "invalid_utf8": [b"\x61\xff", b"\x61\x00", b"\x62\xc3\x28"],
    "unsupported_tag": [b"\xc0\x60", b"\xd8\x20\x00"],
    "unsupported_simple": [b"\xf7", b"\xe0", b"\xf8\x20"],
    "trailing_bytes": [b"\x00\x00", b"\x80\x80"],
    "non_text_key": [b"\xa1\x01\x02", b"\xa1\xf6\x00"],
    "duplicate_key": [b"\xa2\x61a\x01\x61a\x02"],
    "too_deep": [b"\x81" * 17 + b"\x00"],
}

# One input per non-canonical code (decoding succeeds).
NON_CANONICAL: Dict[str, List[bytes]] = {
    "non_minimal_head": [b"\x18\x01", b"\x19\x00\xff", b"\x3a\x00\x00\x00\x01", b"\x58\x00"],
    "unsorted_keys": [b"\xa2\x61b\x01\x61a\x02", b"\xa2\x62aa\x01\x61b\x02"],
    "non_shortest_float": [b"\xfb" + struct.pack(">d", 0.5), b"\xfa" + struct.pack(">f", 1.0),
                           b"\xfb" + struct.pack(">d", 0.0), b"\xfa\x7f\x80\x00\x00"],
    "non_nfc_text": [b"\x63e\xcc\x81"],
}

MALFORMED_CODES = tuple(MALFORMED)
NON_CANONICAL_CODES = tuple(NON_CANONICAL)

ADDRESS_REASONS = ("address_hash_format", "address_hash_mismatch", "cbor_malformed",
                   "cbor_non_canonical", "address_schema", "trust_mismatch", "pointer_typing")

ENDPOINTS_OK = ["10.0.0.1", "0.0.0.0", "10.0.0.1:443", "::1", "fe80::1", "2001:db8::1",
                "[::1]:8080", "[2001:db8::1]:65535", "::ffff:1.2.3.4", "1:2:3:4:5:6:7:8"]
ENDPOINTS_BAD = ["", "10.1", "01.2.3.4", "256.1.1.1", "1.2.3.4/24", "::1/128", "1.2.3",
                 "10.0.0.1:0", "10.0.0.1:65536", "10.0.0.1:080", "[10.0.0.1]:80", "::1:80x",
                 "gggg::1", "1::2::3", "fe80::1%eth0", " 10.0.0.1", "10.0.0.1 ", "localhost",
                 "[::1]", "[::1]:", "example.com:80"]


def canon(problems) -> List[Tuple[str, str]]:
    """Problems in a canonical order (details as sorted JSON)."""
    return sorted((r, json.dumps(d, sort_keys=True)) for r, d in problems)


def random_address(rng: random.Random) -> AddressV2:
    return AddressV2(
        path_signature=bytes(rng.randrange(256) for _ in range(rng.randint(1, 8))),
        universe_id=str(uuid.UUID(int=rng.getrandbits(128))),
        artifact_id=rng.choice([None, str(uuid.UUID(int=rng.getrandbits(128)))]),
        coords=bytes(rng.randrange(256) for _ in range(rng.randint(0, 3))),
        coords_scale=rng.randint(0, 5),
        semantic_tags=tuple(bytes([rng.randrange(256)]) for _ in range(rng.randint(0, 2))),
        trust_score=rng.choice([0.0, 0.5, 1.0, 0.25, rng.random()]),
        verification_depth=rng.randint(0, 3),
        routing_hint=rng.choice([None, {"region": "eu"}]),
        timestamp=rng.randint(0, 2 ** 40),
        nonce=bytes(rng.randrange(256) for _ in range(16)),
    )


_JUNK = [None, -1, 0, 2, 3, "x", "ab", "AB", b"\x01", 1.5, 0.5, -0.5, float("nan"),
         float("inf"), [], ["zz"], ["ab"], {}, {"a": "b"}, {"a": 1}, True,
         "00000000-0000-0000-0000-000000000000", "0" * 32, 2 ** 64 - 1]
_TRUST_JUNK = [0, 1, -1, 0.5, 1.5, -0.0, "x", None, float("nan"), 2.0]


def random_payload(rng: random.Random) -> Any:
    """An AddressV2 payload, sometimes perturbed (fields removed, added, retyped)."""
    p: Any = random_address(rng).payload()
    for _ in range(rng.choice([0, 0, 1, 2, 3])):
        op = rng.random()
        k = rng.choice(sorted(p))
        if op < 0.15:
            del p[k]
        elif op < 0.25:
            p["extra" + str(rng.randint(0, 2))] = 1
        elif op < 0.7:
            p[k] = rng.choice(_JUNK)
        elif isinstance(p.get("trust_hint"), dict):
            th = dict(p["trust_hint"])
            kk = rng.choice(["trust_score", "verification_depth", "zz"])
            if rng.random() < 0.3:
                th.pop(kk, None)
            else:
                th[kk] = rng.choice(_TRUST_JUNK)
            p["trust_hint"] = th
    if rng.random() < 0.08:
        p = rng.choice([[1, 2], "x", 5])
    return p


def random_address_case(rng: random.Random) -> Dict[str, Any]:
    """Arguments of ``address_problems`` / ``addr_address_problems``: CBOR (canonical
    or not, sometimes corrupted), hash (right, wrong, malformed), algorithm and
    recorded trust columns (matching the hint or not)."""
    p = random_payload(rng)
    b = cbor2.dumps(p, canonical=rng.random() < 0.9)
    r = rng.random()
    if r < 0.12:
        b = bytearray(b)
        b[rng.randrange(len(b))] = rng.randrange(256)
        b = bytes(b)
    elif r < 0.16:
        b = rng.choice([x for xs in MALFORMED.values() for x in xs])
    algo = rng.choice(["SHA3-256"] * 5 + ["SHA3-512", "SHA-256", "PQ-HASH-1", "MD5", "sha3-256"])
    h = pq_hash(b, algo) if algo in HASH_ALGOS else "ab" * 32
    r = rng.random()
    if r < 0.1:
        h = "0" * 64
    elif r < 0.15:
        h = h.upper()
    th = p.get("trust_hint") if isinstance(p, dict) else None
    ts = th.get("trust_score") if isinstance(th, dict) else None
    ts = ts if isinstance(ts, float) else 0.0
    if rng.random() < 0.15:
        ts = rng.choice([None, 0.0, 0.75])
    vd = th.get("verification_depth") if isinstance(th, dict) else None
    vd = vd if type(vd) is int and 0 <= vd < 2 ** 31 else 0
    if rng.random() < 0.15:
        vd = rng.choice([None, 0, 7])
    return {"cbor": b, "hash": h, "algo": algo, "trust": ts, "depth": vd}


def random_cbor_input(rng: random.Random) -> bytes:
    """Bytes for the decoder: canonical or not, mutated, or a crafted example."""
    def val(d: int = 0) -> Any:
        r = rng.random()
        if d > 3 or r < 0.5:
            return rng.choice([0, 1, 23, 24, 255, 256, 65535, 65536, 2 ** 32, 2 ** 64 - 1, -1, -25,
                               -2 ** 64, "", "a", "é", "e\u0301", "hello", b"", b"\x00\xff", True,
                               False, None, 0.0, -0.0, 0.5, 0.1, 1e300, 65504.0, 1e-7,
                               float("inf"), float("nan"), 5.96e-8, 1 / 3])
        if r < 0.75:
            return [val(d + 1) for _ in range(rng.randint(0, 3))]
        return {rng.choice(["a", "b", "aa", "version", "x", "zz", "é"]): val(d + 1)
                for _ in range(rng.randint(0, 3))}

    r = rng.random()
    if r < 0.1:
        return rng.choice([x for xs in MALFORMED.values() for x in xs])
    if r < 0.2:
        return rng.choice([x for xs in NON_CANONICAL.values() for x in xs])
    b = bytearray(cbor2.dumps(val(), canonical=rng.random() < 0.8))
    if rng.random() < 0.6:
        for _ in range(rng.randint(1, 3)):
            op = rng.random()
            if op < 0.3 and b:
                b[rng.randrange(len(b))] = rng.randrange(256)
            elif op < 0.5:
                b.insert(rng.randint(0, len(b)), rng.randrange(256))
            elif op < 0.7 and b:
                del b[rng.randrange(len(b))]
            elif op < 0.85 and b:
                b = b[:rng.randint(0, len(b))]
            else:
                b += bytes([rng.randrange(256)])
    return bytes(b)
