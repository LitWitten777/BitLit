"""Tests for EnforcedFunctor law enforcement."""

import pytest

from qbx.core.enforced_functor import (
    Category,
    EnforcedFunctor,
    EnforcementMode,
)
from qbx.core.exceptions import FunctorLawViolation

def _build_identity_functor(mode=EnforcementMode.STRICT):
    """Build a small category C with one object X and identity id_X, and F = id."""
    C = Category(id="C", name="C")
    C.add_object("X", "X")
    C.add_identity("X", "id_X")

    class IdFunctor(EnforcedFunctor):
        def _map_object(self, obj_id):
            return obj_id

        def _map_morphism(self, morph_id):
            return morph_id

    F = IdFunctor(
        functor_id="F1", name="Identity", source=C, target=C, mode=mode
    )
    F.map_object("X")
    F.map_morphism("id_X")
    return F, C

def test_identity_functor_passes_laws():
    F, _ = _build_identity_functor()
    assert F.verify_identity_law()
    assert F.verify_composition_law()
    assert F.verify_all_laws()

def test_identity_law_violation_strict():
    """F maps id_X to a non-identity morphism → strict mode raises."""
    C = Category(id="C", name="C")
    C.add_object("X", "X")
    C.add_identity("X", "id_X")
    # Add a bogus morphism that is NOT the identity
    C.add_morphism("bogus", "X", "X")

    class BadFunctor(EnforcedFunctor):
        def _map_object(self, obj_id):
            return obj_id

        def _map_morphism(self, morph_id):
            return "bogus"  # wrong!

    F = BadFunctor(
        functor_id="F_bad", name="Bad", source=C, target=C,
        mode=EnforcementMode.STRICT,
    )
    F.map_object("X")
    F.map_morphism("id_X")
    with pytest.raises(FunctorLawViolation):
        F.verify_identity_law()

def test_identity_law_violation_permissive():
    C = Category(id="C", name="C")
    C.add_object("X", "X")
    C.add_identity("X", "id_X")
    C.add_morphism("bogus", "X", "X")

    class BadFunctor(EnforcedFunctor):
        def _map_object(self, obj_id):
            return obj_id

        def _map_morphism(self, morph_id):
            return "bogus"

    F = BadFunctor(
        functor_id="F_bad", name="Bad", source=C, target=C,
        mode=EnforcementMode.PERMISSIVE,
    )
    F.map_object("X")
    F.map_morphism("id_X")
    assert not F.verify_identity_law()
    assert len(F.violations) >= 1

def test_composition_law():
    """Build a category with f: X→Y, g: Y→Z, h = g∘f, and F = id."""
    C = Category(id="C", name="C")
    C.add_object("X", "X")
    C.add_object("Y", "Y")
    C.add_object("Z", "Z")
    C.add_identity("X", "id_X")
    C.add_identity("Y", "id_Y")
    C.add_identity("Z", "id_Z")
    C.add_morphism("f", "X", "Y")
    C.add_morphism("g", "Y", "Z")
    C.add_morphism("h", "X", "Z")
    C.add_composition("f", "g", "h")  # h = g ∘ f

    class IdFunctor(EnforcedFunctor):
        def _map_object(self, obj_id):
            return obj_id

        def _map_morphism(self, morph_id):
            return morph_id

    F = IdFunctor(functor_id="F", name="Id", source=C, target=C)
    for obj in ("X", "Y", "Z"):
        F.map_object(obj)
    for morph in ("id_X", "id_Y", "id_Z", "f", "g", "h"):
        F.map_morphism(morph)

    assert F.verify_composition_law()

def test_serialize_mapping_intent():
    F, _ = _build_identity_functor()
    canonical, blob = F.serialize_mapping_intent()
    assert isinstance(canonical, bytes)
    assert len(canonical) > 0
    assert blob.payload_hash == blob.payload_hash  # sanity
    assert blob.key_id == F.signer.key_id