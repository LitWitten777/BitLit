"""Addressing protocol (AddressV2, migration 013) — the pure-Python reference.

Formal backing: ``Formal/Addressing.lean`` — the XOR distance is a metric
(``xorDist_triangle``) in which each distance from a point is attained once
(``xorDist_unidirectional``), the bucket index is an ultrametric
(``bucket_ultrametric``), the ``k`` closest nodes exist and are unique
(``kClosest_exists``, ``kClosest_unique``), and comparing bytewise XORs
lexicographically compares XOR distances (``bytea_xor_order``).  The tests
below check the Python implementation against each of these statements.
"""

from __future__ import annotations

import itertools
import math
import random
import uuid
from datetime import datetime, timedelta, timezone

import cbor2
import pytest

from qbx.addressing import (
    AddressBook,
    AddressingError,
    AddressV2,
    address_problems,
    bucket_index,
    closest_nodes,
    decode_strict,
    distance,
    endpoint_ok,
    is_k_closest,
    schema_problems,
    xor_distance,
)
from qbx.addressing.cbor_strict import pack_float, untag
from qbx.addressing.registry import (
    CacheRow,
    DiscoveryRow,
    GatewayRow,
    cache_problems,
    discovery_problems,
    gateway_problems,
)
from qbx.core.canonical import canonical_cbor
from qbx.core.hashing import pq_hash
from qbx.path.signature import PathSignature
from tests.addressing_examples import (
    ENDPOINTS_BAD,
    ENDPOINTS_OK,
    MALFORMED,
    NON_CANONICAL,
    random_address,
    random_cbor_input,
)

T0 = datetime(2026, 1, 1, tzinfo=timezone.utc)


# ---------------------------------------------------------------------------
# The strict decoder
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("code", sorted(MALFORMED))
def test_malformed_examples(code):
    for b in MALFORMED[code]:
        d = decode_strict(b)
        assert d.malformed is not None and d.malformed["error"] == code, b
        assert d.value is None and d.non_canonical == []


@pytest.mark.parametrize("code", sorted(NON_CANONICAL))
def test_non_canonical_examples(code):
    for b in NON_CANONICAL[code]:
        d = decode_strict(b)
        assert d.ok, b
        assert [e["error"] for e in d.non_canonical] == [code], b


def test_depth_limit_is_sixteen():
    assert decode_strict(b"\x81" * 16 + b"\x00").ok
    assert decode_strict(b"\x81" * 17 + b"\x00").malformed == {"offset": 17, "error": "too_deep"}


def test_canonical_encoder_output_is_canonical():
    """Whatever ``canonical_cbor`` produces decodes with no findings, back to the
    same value (it NFC-normalizes text, so not even ``non_nfc_text``)."""
    rng = random.Random(1)
    checked = 0
    for _ in range(600):
        b = random_cbor_input(rng)
        if not decode_strict(b).ok:          # only the subset the decoder accepts
            continue
        checked += 1
        enc = canonical_cbor(cbor2.loads(b))
        d = decode_strict(enc)
        assert d.ok and d.non_canonical == [], enc.hex()
        assert repr(untag(d.value)) == repr(cbor2.loads(enc))
    assert checked > 100


def test_decoder_agrees_with_cbor2_on_accepted_inputs():
    rng = random.Random(2)
    accepted = 0
    for _ in range(1500):
        b = random_cbor_input(rng)
        d = decode_strict(b)
        if d.ok:
            accepted += 1
            assert repr(untag(d.value)) == repr(cbor2.loads(b)), b.hex()
    assert accepted > 300


@pytest.mark.parametrize("v", [0.0, -0.0, 1.0, 0.5, 65504.0, 5.960464477539063e-08, 1e-7,
                               0.1, 1 / 3, 1e300, 3.4028234663852886e38, 1.401298464324817e-45,
                               float("inf"), -float("inf"), 2.0 ** -24, 2.0 ** -25, 100000.0])
def test_shortest_float_rule_matches_cbor2(v):
    """Exactly the width ``cbor2`` canonical encoding picks is canonical; every
    wider encoding of the same value is flagged; the value round-trips."""
    enc = cbor2.dumps(v, canonical=True)
    width = {0xF9: 16, 0xFA: 32, 0xFB: 64}[enc[0]]
    for w in (16, 32, 64):
        if w < width:
            continue
        b = pack_float(v, w)
        d = decode_strict(b)
        assert d.ok
        assert (d.non_canonical == []) == (w == width), (v, w)
        got = d.value["$float"]
        assert got == v and math.copysign(1, got) == math.copysign(1, v)


def test_nan_is_canonical_only_as_half():
    assert decode_strict(b"\xf9\x7e\x00").non_canonical == []
    assert decode_strict(b"\xfb\x7f\xf8\x00\x00\x00\x00\x00\x00").non_canonical[0]["error"] == \
        "non_shortest_float"


# ---------------------------------------------------------------------------
# AddressV2
# ---------------------------------------------------------------------------
def test_address_round_trip_and_no_problems():
    rng = random.Random(3)
    for _ in range(50):
        a = random_address(rng)
        b = a.encode()
        for algo in ("SHA3-256", "SHA3-512", "SHA-256", "PQ-HASH-1"):
            h = a.address_hash(algo)
            assert address_problems(b, h, algo, a.trust_score, a.verification_depth) == []
        assert AddressV2.decode(b) == a


def test_matches_path_signature_address(monkeypatch):
    """``PathSignature.build`` hashes exactly the AddressV2 payload."""
    fixed = [uuid.UUID(int=11), uuid.UUID(int=22)]
    monkeypatch.setattr("qbx.path.signature.uuid.uuid4", lambda: fixed.pop(0))
    sig = PathSignature.build("cat", "A", "B", ["f", "g"], universe_id=str(uuid.UUID(int=5)),
                              coords=b"\x01\x02", semantic_tags=[b"\xaa"], trust_score=0.5,
                              verification_depth=2)
    a = AddressV2(path_signature=sig.canonical_bytes, universe_id=str(uuid.UUID(int=5)),
                  coords=b"\x01\x02", semantic_tags=(b"\xaa",), trust_score=0.5,
                  verification_depth=2, nonce=uuid.UUID(int=22).bytes)
    assert a.address_hash() == sig.address_hash
    assert address_problems(a.encode(), sig.address_hash, "SHA3-256", 0.5, 2) == []


def test_address_problem_kinds():
    a = random_address(random.Random(4))
    b = a.encode()
    h = a.address_hash()
    ts, vd = a.trust_score, a.verification_depth
    assert address_problems(b, "0" * 64, "SHA3-256", ts, vd) == \
        [("address_hash_mismatch", {"algo": "SHA3-256"})]
    assert address_problems(b, h.upper(), "SHA3-256", ts, vd) == \
        [("address_hash_format", {"algo": "SHA3-256"})]
    assert address_problems(b, h, "MD5", ts, vd) == [("address_hash_format", {"algo": "MD5"})]
    assert ("trust_mismatch", {"column": "trust_score"}) in \
        address_problems(b, h, "SHA3-256", 0.75 if ts != 0.75 else 0.5, vd)
    assert ("trust_mismatch", {"column": "verification_depth"}) in \
        address_problems(b, h, "SHA3-256", ts, vd + 1)
    trunc = b[:-1]
    assert address_problems(trunc, pq_hash(trunc), "SHA3-256", ts, vd)[0][0] == "cbor_malformed"


def test_schema_problems():
    p = random_address(random.Random(5)).payload()
    enc = lambda q: decode_strict(cbor2.dumps(q, canonical=True)).value  # noqa: E731
    assert schema_problems(enc(p)) == []
    q = dict(p, version=1)
    assert schema_problems(enc(q)) == [("address_schema", {"field": "version", "error": "value"})]
    q = dict(p, nonce="ab")
    assert schema_problems(enc(q)) == [("address_schema", {"field": "nonce", "error": "format"})]
    q = dict(p)
    del q["coords"]
    q["junk"] = 1
    assert sorted(schema_problems(enc(q)), key=str) == sorted(
        [("address_schema", {"field": "coords", "error": "missing"}),
         ("address_schema", {"field": "junk", "error": "unknown"})], key=str)
    q = dict(p, trust_hint={"trust_score": 1.5, "verification_depth": 0})
    assert schema_problems(enc(q)) == \
        [("address_schema", {"field": "trust_hint.trust_score", "error": "range"})]
    q = dict(p, trust_hint={"trust_score": 1, "verification_depth": -1})
    assert sorted(schema_problems(enc(q)), key=str) == sorted(
        [("address_schema", {"field": "trust_hint.trust_score", "error": "type"}),
         ("address_schema", {"field": "trust_hint.verification_depth", "error": "range"})],
        key=str)
    assert schema_problems(enc([1])) == [("address_schema", {"field": "", "error": "not_a_map"})]


# ---------------------------------------------------------------------------
# XOR metric (Formal/Addressing.lean)
# ---------------------------------------------------------------------------
def _ids(rng, n, nbytes=32):
    return [bytes(rng.randrange(256) for _ in range(nbytes)) for _ in range(n)]


def test_xor_metric_laws():
    rng = random.Random(6)
    for x, y, z in (tuple(_ids(rng, 3)) for _ in range(300)):
        assert distance(x, x) == 0 and distance(x, y) == distance(y, x)
        assert (distance(x, y) == 0) == (x == y)
        assert distance(x, z) <= distance(x, y) + distance(y, z)          # xorDist_triangle
        bxz, bxy, byz = bucket_index(x, z), bucket_index(x, y), bucket_index(y, z)
        if bxz is not None:                                               # bucket_ultrametric
            assert bxz <= max(b for b in (bxy, byz) if b is not None)


def test_unidirectionality():
    rng = random.Random(7)
    for _ in range(200):
        x, y, z = _ids(rng, 3, nbytes=2)
        if distance(x, y) == distance(x, z):                              # xorDist_unidirectional
            assert y == z
    x = bytes(2)
    assert len({distance(x, w.to_bytes(2, "big")) for w in range(2 ** 16)}) == 2 ** 16


def test_bytewise_order_is_distance_order():
    """``bytea_xor_order``: comparing ``key ⊕ u`` and ``key ⊕ v`` bytewise compares
    the XOR distances."""
    rng = random.Random(8)
    for key, u, v in (tuple(_ids(rng, 3, nbytes=rng.randint(1, 4))) for _ in range(500)):
        if len({len(key), len(u), len(v)}) > 1:
            continue
        assert (xor_distance(key, u) < xor_distance(key, v)) == (distance(key, u) < distance(key, v))


def test_k_closest_unique_and_exists():
    rng = random.Random(9)
    for _ in range(40):
        key = _ids(rng, 1)[0]
        nodes = _ids(rng, rng.randint(0, 12))
        for k in range(len(nodes) + 1):
            chosen = closest_nodes(key, nodes, k)
            assert is_k_closest(key, nodes, chosen, k)                    # kClosest_exists
            for other in itertools.islice(itertools.combinations(nodes, k), 50):
                if is_k_closest(key, nodes, other, k):                    # kClosest_unique
                    assert set(other) == set(chosen)
        assert [distance(key, n) for n in closest_nodes(key, nodes, len(nodes))] == \
            sorted(distance(key, n) for n in nodes)


def test_bucket_index_values():
    a = bytes(32)
    assert bucket_index(a, a) is None
    assert bucket_index(a, bytes(31) + b"\x01") == 0
    assert bucket_index(a, b"\x80" + bytes(31)) == 255
    assert bucket_index(a, bytes(30) + b"\x01\x00") == 8


# ---------------------------------------------------------------------------
# Rows, writers and resolution
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("e", ENDPOINTS_OK)
def test_endpoint_ok(e):
    assert endpoint_ok(e)


@pytest.mark.parametrize("e", ENDPOINTS_BAD)
def test_endpoint_bad(e):
    assert not endpoint_ok(e)


def test_row_problems():
    h = "ab" * 32
    assert cache_problems(CacheRow(h, ["x"], 10, T0)) == []
    assert cache_problems(CacheRow("zz", [], 0, T0)) == [
        ("cache_typing", {"error": "hash_format"}), ("cache_typing", {"error": "ttl"})]
    assert cache_problems(CacheRow(h, ["x", "x"], 1, T0)) == [("cache_typing", {"error": "pointers"})]
    assert gateway_problems(GatewayRow(h, "10.0.0.1:80", "tcp"), {h}) == []
    assert gateway_problems(GatewayRow(h, "nope", "ftp"), set()) == [
        ("gateway_typing", {"error": "endpoint"}), ("gateway_typing", {"error": "protocol"}),
        ("gateway_unregistered", {})]
    assert discovery_problems(DiscoveryRow(2, [1, 2], 5)) == []
    assert discovery_problems(DiscoveryRow(0, [1], -1)) == [
        ("discovery_typing", {"error": "k"}), ("discovery_typing", {"error": "latency"}),
        ("discovery_typing", {"error": "results"})]


def test_address_book_writers():
    book = AddressBook()
    a = random_address(random.Random(10))
    b, h = a.encode(), a.address_hash()
    row = book.register_address(h, b, pointers=["p1"])
    assert row.trust_score == a.trust_score and row.verification_depth == a.verification_depth
    assert book.register_address(h, b, pointers=["p2", "p1"]).pointers == ["p1", "p2"]
    with pytest.raises(AddressingError):
        book.register_address("0" * 64, b)
    with pytest.raises(AddressingError):
        book.register_address(h, b, trust=0.123456)
    book.register_address(h, b, owner=None)
    with pytest.raises(AddressingError):
        book.register_gateway("cd" * 32, "10.0.0.1", "tcp")
    g = book.register_gateway(h, "10.0.0.1", "tcp")
    assert book.register_gateway(h, "10.0.0.1", "tcp") is g
    with pytest.raises(AddressingError):
        book.register_node(b"\x01")
    n = book.register_node(bytes(32), "n0")
    assert book.register_node(bytes(32)) is n
    with pytest.raises(AddressingError):
        book.register_node(bytes(32), "elsewhere")


def test_resolution_and_purge():
    book = AddressBook()
    h = "cd" * 32
    assert book.resolve(h, T0) is None
    book.cache_resolution(h, ["old"], 10, T0)
    book.cache_resolution(h, ["new"], 5, T0 + timedelta(seconds=3))
    assert book.resolve(h, T0 + timedelta(seconds=1)) == ["old"]
    assert book.resolve(h, T0 + timedelta(seconds=4)) == ["new"]
    assert book.resolve(h, T0 + timedelta(seconds=8)) == ["old"]      # "new" expired at 8
    assert book.resolve(h, T0 + timedelta(seconds=10)) is None        # "old" expired at 10
    with pytest.raises(AddressingError):
        book.cache_resolution(h, ["x"], 0, T0)
    assert book.purge(T0 + timedelta(seconds=8)) == 1
    assert book.purge(T0 + timedelta(seconds=10)) == 1
    a = random_address(random.Random(11))
    book.register_address(a.address_hash(), a.encode(), pointers=["reg"])
    book.cache_resolution(a.address_hash(), ["cached"], 100, T0)
    assert book.resolve(a.address_hash(), T0) == ["reg"]               # the registry wins
