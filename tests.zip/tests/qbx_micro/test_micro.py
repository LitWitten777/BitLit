"""Tests for qbx_micro: known values, Lean-backed identities, and agreement with qbx_ir."""

import math
import random

import pytest

from qbx_micro import braid as B, cliff as C, laws as L, chern as CH, cert, grade as G

RNG = random.Random(20261012)


def rand_word(n, length):
    return [RNG.choice([i for i in range(1, n)] + [-i for i in range(1, n)]) for _ in range(length)]


# ----------------------------------------------------------------------------- clifford core

def test_clifford_signature_and_reverse():
    sig = (-1, -1, -1)
    e1, e2 = C.gen(0), C.gen(1)
    assert C.gp(e1, e1, sig) == {0: -1}
    assert C.gp(e1, e2, sig) == C.scale(C.gp(e2, e1, sig), -1)
    biv = C.gp(e1, e2, sig)
    assert C.gp(biv, biv, sig) == {0: -1}
    assert C.reverse(biv) == C.scale(biv, -1)


def test_hypercube_counts():
    assert C.cube_f_vector(3) == [8, 12, 6, 1]
    assert C.binomials(4) == [1, 4, 6, 4, 1]


# ----------------------------------------------------------------------------- channels

def test_jones_known_values():
    assert B.jones_in_t(2, [1, 1, 1]) == {1: 1, 3: 1, 4: -1}            # right trefoil
    assert B.jones_in_t(2, [-1, -1, -1]) == {-1: 1, -3: 1, -4: -1}      # left trefoil
    assert B.jones_in_t(3, [1, -2, 1, -2]) == {-2: 1, -1: -1, 0: 1, 1: -1, 2: 1}
    assert B.jones_in_t(2, [1, 1]) == {0.5: -1, 2.5: -1}                # Hopf link


@pytest.mark.parametrize("trial", range(15))
def test_markov_and_braid_relations(trial):
    w = rand_word(3, 7)
    assert B.jones(3, w) == B.jones(4, w + [3]) == B.jones(4, w + [-3])
    assert B.jones(3, w) == B.jones(3, w[3:] + w[:3])
    for r in (3, 5):
        assert B.oscillator_mod(3, w, r) == B.oscillator_mod(3, w[2:] + w[:2], r)
    assert B.clifford_key(4, w + [1, 2, 1]) == B.clifford_key(4, w + [2, 1, 2])
    assert B.clifford_key(4, w + [1, 3]) == B.clifford_key(4, w + [3, 1])
    assert B.anchor(4, w + [1, 2, 1]) == B.anchor(4, w + [2, 1, 2])
    assert B.anchor(4, w + [1, -1]) == B.anchor(4, w)
    # the harmonic reading is computed from an exact matrix, so it is a braid invariant
    assert B.harmonic(4, w + [1, 2, 1]) == B.harmonic(4, w + [2, 1, 2])
    assert B.harmonic(4, w + [1, 3, -1]) == B.harmonic(4, w + [3])


@pytest.mark.parametrize("trial", range(15))
def test_integrity_checks_hold(trial):
    n = RNG.choice([3, 4, 5])
    assert all(B.integrity(n, rand_word(n, 12)).values())


def test_oscillator_mod_is_a_ring_image():
    # the F_p value is the image of d*V: compare with the exact polynomial mapped to F_p
    for _ in range(5):
        w = rand_word(3, 6)
        for r in (3, 5):
            p = B.P_OSC
            a = pow(B.root_of_unity_mod(4 * r, p), r + 1, p)
            ai = pow(a, p - 2, p)
            dv = B._padd(B._pshift(B.jones(3, w), 2, -1), B._pshift(B.jones(3, w), -2, -1))
            img = sum(c * (pow(a, k, p) if k >= 0 else pow(ai, -k, p)) for k, c in dv.items()) % p
            assert img == B.oscillator_mod(3, w, r)


def test_clifford_is_not_faithful():
    # tau_k^4 = -1, so sigma_1^8 has trivial Clifford reading (rep_not_injective)
    assert B.clifford(3, [1] * 8) == ({0: 1}, 0)
    assert B.fold(3, [1] * 8) == (0, 1, 2)
    assert B.anchor(3, [1] * 8) != B.anchor(3, [])


def test_entropy_bound_pseudo_anosov():
    golden_sq = (3 + math.sqrt(5)) / 2
    assert abs(B.entropy_bound(3, [1, -2]) - math.log(golden_sq)) < 1e-12
    assert abs(B.entropy_bound(3, [1, -2] * 300) / 300 - math.log(golden_sq)) < 1e-9
    assert B.entropy_bound(3, [1, 2] * 6) < 1e-3   # periodic braid


def test_against_qbx_ir():
    pytest.importorskip("numpy")
    from qbx_ir.core.braid import Braid
    from qbx_ir.algebra import invariants as inv
    from qbx_ir.quantum.representation import jones_from_quantum_trace
    for _ in range(10):
        n = RNG.choice([2, 3, 4])
        w = rand_word(n, 6)
        b = Braid.from_short_form(n, w)
        assert tuple(p - 1 for p in inv.permutation(b)) == B.fold(n, w)
        poly = B.jones(n, w)                      # powers of A, t = A^-4
        assert all(k % 2 == 0 for k in poly)
        for r in (3, 5, 7):
            q = complex(math.cos(math.pi / r), math.sin(math.pi / r))
            theirs = jones_from_quantum_trace(b, q)   # convention t^(1/2) = -1/q, i.e. A^2 = -q
            mine = sum(c * (-q) ** (k // 2) for k, c in poly.items())
            assert abs(theirs - mine) < 1e-6
            assert abs(B.jones_at(n, w, r) - theirs) < 1e-6
            assert abs(B.jones_numeric(n, w, r) - theirs) < 1e-6


# ----------------------------------------------------------------------------- laws and certificates

def test_law_table_matches_textbook():
    t = dict((k, dict(v)) for k, v in L.law_table(budget=1024).items())
    assert t["commutative"]["C"] != "fails" and t["commutative"]["H"] == "fails"
    assert t["associative"]["H"] == "holds-complete" and t["associative"]["O"] == "fails"
    assert t["left-alternative"]["O"] != "fails" and t["left-alternative"]["S"] == "fails"
    assert t["flexible"]["S"] != "fails"
    assert t["norm-multiplicative"]["O"] != "fails" and t["norm-multiplicative"]["S"] == "fails"


def test_zero_divisors():
    assert L.find_zero_divisor(3) is None
    a, b = L.find_zero_divisor(4)
    assert any(a) and any(b) and L.mul(a, b) == [0] * 16


def test_certificate_file_is_current():
    import os
    here = os.path.dirname(__file__)
    path = os.path.join(here, "..", "..", "Formal", "Certificates", "CayleyDickson.lean")
    with open(path) as fh:
        assert fh.read() == cert.lean_law_file()


def test_certificate_formats():
    st, w = L.check("(a*b)*c = a*(b*c)", 3)
    out = cert.all_formats("t", "(a*b)*c = a*(b*c)", 3, w)
    assert "decide" in out["lean"] and "vm_compute" in out["coq"] and "by eval" in out["isa"]


# ----------------------------------------------------------------------------- chern

# the phase diagram proved in sovereign/Sovereign/Metamaterial/ChernNumber.lean
# (chernNumber_qwz_of_pos / _of_neg / _of_two_lt): -1 on (0,2), +1 on (-2,0), 0 for |m| > 2
@pytest.mark.parametrize("m,c", [(-3, 0), (-1.5, 1), (-0.5, 1), (0.5, -1), (1.5, -1), (3, 0)])
def test_qwz_phase_diagram_matches_lean(m, c):
    res = CH.chern(CH.qwz(m), 24)
    assert res["degree"] == c and res["agree"] and res["rounding"] < 1e-6


def test_higher_winding():
    assert CH.chern(CH.qwz_winding(1.0, 2), 32)["degree"] == -2
    assert CH.chern(CH.qwz_winding(1.0, 3), 40)["degree"] == -3


# ----------------------------------------------------------------------------- encoder

def test_encoder_alpha_invariance_and_operators():
    # forall a b : Nat, a + b = b + a   vs   ... a + b < b + a  (S3 of StructuralBraid.lean)
    def stmt(rel):
        nat = ["const", "Nat"]
        add = lambda x, y: ["app", ["const", "HAdd.hAdd"], nat, nat, nat, ["const", "inst"], x, y]
        body = ["app", ["const", rel], nat, add(["bvar", 1], ["bvar", 0]), add(["bvar", 0], ["bvar", 1])]
        return ["pi", "a", "d", nat, ["pi", "b", "d", nat, body]]
    e1 = G.encode(G.to_sexpr(stmt("Eq")))
    e1_renamed = G.encode(G.to_sexpr(["pi", "x", "d", stmt("Eq")[3], ["pi", "y", "d"] + stmt("Eq")[4][3:]]))
    e2 = G.encode(G.to_sexpr(stmt("LT.lt")))
    assert e1 == e1_renamed
    assert e1 != e2
