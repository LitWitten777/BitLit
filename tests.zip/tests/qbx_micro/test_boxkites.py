"""Exact check of the sedenion zero-divisor claim in the user's `unified-picture.md`
("Leech-Sedenion-Fano stratification"), with the doubling product of qbx_micro.laws.

The 168 vectors e_a + s e_(8+b) and their negatives (a != b in 1..7, s = +-1) are the
"primitive" zero divisors; the structure found here is the box-kite structure of de Marrais.
Integer arithmetic throughout (the sqrt(2) scale in the source is irrelevant).
"""

from fractions import Fraction

from qbx_micro.laws import mul

DIM = 16


def vec(a, b, s, t):
    v = [0] * DIM
    v[a] += s
    v[8 + b] += t
    return v


def rank(rows):
    M = [[Fraction(x) for x in r] for r in rows]
    r = 0
    for c in range(len(M[0])):
        p = next((i for i in range(r, len(M)) if M[i][c] != 0), None)
        if p is None:
            continue
        M[r], M[p] = M[p], M[r]
        for i in range(len(M)):
            if i != r and M[i][c] != 0:
                f = M[i][c] / M[r][c]
                M[i] = [x - f * y for x, y in zip(M[i], M[r])]
        r += 1
    return r


def left_matrix(v):
    cols = [mul(v, [1 if k == j else 0 for k in range(DIM)]) for j in range(DIM)]
    return [[cols[j][i] for j in range(DIM)] for i in range(DIM)]


LABELS = [(a, b, s, t) for a in range(1, 8) for b in range(1, 8) if a != b for s in (1, -1) for t in (1, -1)]
V = [vec(*l) for l in LABELS]


def zero(x):
    return all(c == 0 for c in x)


def graph():
    adj = dict((i, set()) for i in range(len(V)))
    for i in range(len(V)):
        for j in range(len(V)):
            if i != j and zero(mul(V[i], V[j])):
                adj[i].add(j)
    return adj


ADJ = graph()


def test_kernels():
    assert len(V) == 168
    assert all(DIM - rank(left_matrix(v)) == 4 for v in V)
    others = [vec(a, b, s, t) for a in range(8) for b in range(8) if not (a and b and a != b)
              for s in (1, -1) for t in (1, -1)]
    assert len(others) == 88 and all(rank(left_matrix(v)) == DIM for v in others)


def test_annihilation_graph():
    assert all(j in ADJ[i] for i in ADJ for j in ADJ[i])           # u w = 0 iff w u = 0
    assert all(len(n) == 8 for n in ADJ.values())                    # 8-regular, 672 edges
    seen, comps = set(), []
    for s in ADJ:
        if s in seen:
            continue
        c, st = {s}, [s]
        while st:
            for y in ADJ[st.pop()]:
                if y not in c:
                    c.add(y)
                    st.append(y)
        seen |= c
        comps.append(c)
    assert sorted(len(c) for c in comps) == [24] * 7
    # each component avoids exactly one imaginary octonion unit (one Fano point)
    missing = []
    for c in comps:
        used = set()
        for i in c:
            used |= {LABELS[i][0], LABELS[i][1]}
        assert len(used) == 6
        missing.append((set(range(1, 8)) - used).pop())
    assert sorted(missing) == list(range(1, 8))
    # twin classes of size 4, no edge inside a class, quotient of each component a 6-cycle
    classes = {}
    for i in ADJ:
        classes.setdefault(frozenset(ADJ[i]), []).append(i)
    assert sorted(len(c) for c in classes.values()) == [4] * 42
    cid = dict((i, k) for k, c in enumerate(classes.values()) for i in c)
    for c in classes.values():
        assert not any(j in ADJ[i] for i in c for j in c)
    quot = dict((cid[c[0]], set(cid[j] for j in ADJ[c[0]])) for c in classes.values())
    assert all(len(n) == 2 for n in quot.values())
    for k in quot:
        # walk the 2-regular quotient: cycle length 6
        prev, cur, n = None, k, 0
        while True:
            nxt = [x for x in quot[cur] if x != prev][0]
            prev, cur, n = cur, nxt, n + 1
            if cur == k:
                break
        assert n == 6
