"""qbx_micro.gosset agrees with the Lean results in QBX/Formal/Gosset/*.lean."""

from fractions import Fraction

from qbx_micro import gosset as G


def test_roots_and_shells():
    assert len(G.ROOTS) == 240 and len(set(G.ROOTS)) == 240
    for r in G.ROOTS:
        assert G.dot(r, r) == 8 and G.is_lattice_point(r)
        counts = [sum(1 for s in G.ROOTS if G.dot(r, s) == c) for c in (8, 4, 0, -4, -8)]
        assert counts == [1, 56, 126, 56, 1]          # Gosset.shell_counts


def test_flag_ladder_chain():
    assert all(G.dot(a, b) == 4 for i, a in enumerate(G.FLAG) for b in G.FLAG[i + 1:])
    assert [len(G.layer(k)) for k in range(9)] == [240, 56, 27, 16, 10, 6, 3, 1, 0]
    assert [len(G.perp(k)) for k in range(9)] == [240, 126, 72, 40, 20, 8, 2, 0, 0]
    coords = [G.flag_coord(r) for r in G.ROOTS]
    assert len(set(coords)) == 240                     # Gosset.flagCoord_nodup
    assert all(-2 <= c <= 2 for t in coords for c in t)
    depth = [G.ladder_depth(r) for r in G.ROOTS]
    assert [sum(1 for d in depth if d >= k) for k in range(9)] == [240, 56, 27, 16, 10, 6, 3, 1, 0]


def test_coxeter_rings():
    for simple, roots, h in ((G.SIMPLE_E8, G.ROOTS, 30), (G.SIMPLE_E7, G.perp(1), 18),
                             (G.SIMPLE_E6, G.perp(2), 12)):
        assert all(len(G.orbit(r, simple)) == h for r in roots)
    seen = set()
    for k in range(8):
        for j in range(30):
            r = G.root_at(k, j)
            assert G.ring_address(r) == (k, j)
            seen.add(r)
    assert len(seen) == 240                           # Gosset.coxeterE8_rings
    r = G.ROOTS[17]
    k, j = G.ring_address(r)
    assert G.ring_address(G.coxeter(r)) == (k, (j + 1) % 30)


def test_magic_star_and_lines():
    for p, n in G.STAR_TABLE.items():
        assert len(G.star_fibre(p)) == n              # Gosset.starPoint_counts
    for p in G.HEXAGRAM:
        F = G.star_fibre(p)
        for x in F:
            assert sum(1 for y in F if G.dot(x, y) == 4) == 16
            assert sum(1 for y in F if G.dot(x, y) == 0) == 10
    S = G.sixes()
    assert len(S) == 72 and len(set(tuple(v) for v in S.values())) == 72
    for six in S.values():
        assert len(six) == 6 and all(G.dot(a, b) == 4 for a in six for b in six if a != b)


def test_decoder():
    assert G.nearest_lattice_point([0] * 8) == (0,) * 8
    for r in G.ROOTS[::7]:
        x = [Fraction(a, 2) + Fraction(1, 10) * ((i % 3) - 1) for i, a in enumerate(r)]
        assert G.nearest_lattice_point(x) == r
    x = [Fraction(3, 7), Fraction(-5, 3), Fraction(1, 9), 2, Fraction(-1, 4), 0, Fraction(7, 5), 1]
    y = G.nearest_lattice_point(x)
    assert G.is_lattice_point(y)
    d = lambda v: sum((q - Fraction(a, 2)) ** 2 for q, a in zip(x, v))
    # no lattice point at distance <= sqrt(2) from y (i.e. y + root) is closer
    assert all(d(y) <= d(tuple(a + b for a, b in zip(y, r))) for r in G.ROOTS)


def test_placement_test_is_calibrated():
    items = list(range(20))
    good = dict((i, G.ROOTS[i]) for i in items)
    pairs = [(i, j) for i in items for j in items if i < j and G.dot(good[i], good[j]) == 4]
    res = G.placement_test(good, pairs, trials=300)
    assert res["observed"] == len(pairs) and res["p_value"] < 0.01
    assert abs(res["expected"] - len(pairs) * 56 / 239.0) < 1e-9
