"""Random inputs for the Hebrew primacy checks (``qbx.hebrew``, migration 014).

Every generator takes a ``random.Random`` and is deterministic for a given
seed.  The inputs mix valid data with every kind of defect the checks report.
"""

from __future__ import annotations

import random
from typing import Any, Dict, List, Optional, Tuple

from qbx.hebrew.gematria import GEMATRIA
from qbx.hebrew.text import LETTER_TABLE, MARKS, VERSE_PUNCTUATION
from qbx.hebrew.torah import BOOKS

LETTERS = [l for l, *_ in LETTER_TABLE]
MARK_LIST = sorted(MARKS)
PUNCT = sorted(VERSE_PUNCTUATION)
# Characters a check must reject: Latin, digits, other Hebrew-block code points
# (U+05C8–U+05CF are unassigned, U+05EF is yod triangle), presentation forms
# (not NFC: U+FB2A, U+FB2B, U+FB4B decompose; U+FB20 is a wide ayin), Arabic,
# an emoji, a tab and a colon.
OTHER = list("abzXY019:") + ["\t", "\u05C8", "\u05EF", "\u05F0", "\uFB20", "\u0627",
                              "\U0001F600", "\u00A0", "\u2028"]
NON_NFC = ["\uFB2A", "\uFB2B", "\uFB4B", "\uFB31"]


def random_text(rng: random.Random, kind: str = "word", n: Optional[int] = None) -> str:
    """A random word / verse text; mostly valid, sometimes broken."""
    r = rng.random()
    if r < 0.04:
        return ""
    if r < 0.08:
        return rng.choice(LETTERS) + rng.choice(NON_NFC)
    if r < 0.12:   # dagesh (ccc 21) before patah (ccc 17): not in canonical order
        return rng.choice(LETTERS) + "\u05BC\u05B7"
    n = n if n is not None else rng.randint(1, 7)
    out: List[str] = []
    for _ in range(n):
        x = rng.random()
        if x < 0.62:
            out.append(rng.choice(LETTERS))
        elif x < 0.80:
            out.append(rng.choice(MARK_LIST))
        elif x < 0.92 and kind == "verse":
            out.append(rng.choice(PUNCT))
        elif x < 0.95:
            out.append(rng.choice(OTHER))
        else:
            out.append(rng.choice(PUNCT))
    return "".join(out)


def random_root(rng: random.Random) -> Optional[str]:
    r = rng.random()
    if r < 0.3:
        return None
    if r < 0.35:
        return ""
    return "".join(rng.choice(LETTERS) if rng.random() < 0.85 else rng.choice(OTHER + MARK_LIST)
                   for _ in range(rng.randint(1, 4)))


BAD_RULE_VALUES: List[Any] = [-1, 1.5, "3", True, None, 2 ** 31, [1], {"a": 1}, -0.5]
OK_RULE_VALUES: List[Any] = [0, 1, 7, 3.0, 2 ** 31 - 1, 400]
UNKNOWN_KEYS = ["x", "", "אב", "a", "\u05B8", "1", "ﬠ"]


def random_rules(rng: random.Random) -> Any:
    """``{}``, a full table, or a table with defects; sometimes not an object."""
    r = rng.random()
    if r < 0.12:
        return {}
    if r < 0.17:
        return rng.choice([[], "rules", 3, None, [["א", 1]]])
    rules: Dict[str, Any] = {}
    for letter in LETTERS:
        rules[letter] = rng.choice([GEMATRIA[letter], rng.randint(0, 1000)])
    if r < 0.55:
        return rules
    for _ in range(rng.randint(1, 3)):
        y = rng.random()
        if y < 0.35:
            rules.pop(rng.choice(LETTERS), None)
        elif y < 0.6:
            rules[rng.choice(UNKNOWN_KEYS)] = rng.choice(OK_RULE_VALUES + BAD_RULE_VALUES)
        elif y < 0.9:
            rules[rng.choice(LETTERS)] = rng.choice(BAD_RULE_VALUES)
        else:
            rules[rng.choice(LETTERS)] = rng.choice(OK_RULE_VALUES)
    return rules


def random_obligation(rng: random.Random, rules: Any) -> Tuple[str, str, int, int, int]:
    """(left, right, left value, right value, concat value); values mostly right."""
    from qbx.hebrew.functor import functor_value

    left = random_text(rng, "word", rng.randint(1, 4))
    right = random_text(rng, "word", rng.randint(1, 4))
    vals = [functor_value(rules, t) for t in (left, right, left + right)]
    vals = [v if v is not None else rng.randint(0, 1000) for v in vals]
    for i in range(3):
        if rng.random() < 0.2:
            vals[i] += rng.choice([-1, 1, 7, 100])
    return left, right, vals[0], vals[1], vals[2]


def random_verse_ref(rng: random.Random) -> str:
    en, he, n = rng.choice(BOOKS)
    book = rng.choice([en, he])
    r = rng.random()
    if r < 0.55:
        return "%s %d:%d" % (book, rng.randint(1, n), rng.randint(1, 999))
    if r < 0.65:
        return "%s %d:%d" % (book, rng.randint(n + 1, 999), rng.randint(1, 50))
    if r < 0.72:
        return "%s %d:%d" % (rng.choice(["Joshua", "genesis", "Gen", "בראשית ", "Isaiah"]),
                             rng.randint(1, 20), rng.randint(1, 20))
    return rng.choice([
        "%s %d" % (book, rng.randint(1, 9)),
        "%s 0:1" % book,
        "%s 1:0" % book,
        "%s 01:1" % book,
        "%s 1:1000" % book,
        "%s  1:1" % book,
        "%s 1:1\n" % book,
        "%s\n1:1" % book,
        " 1:1",
        "",
        "%s 1:1:1" % book,
        "%s:1 1:1" % book,
    ])


def random_language_case(rng: random.Random) -> Tuple[str, str, str]:
    left = rng.choice(["Hebrew", "Greek", "Latin", "", "  ", "Aramaic"])
    right = rng.choice(["Hebrew", "Greek", "Latin", "", " ", left])
    status = rng.choice(["provisional", "provisional", "lean_verified", "verified", ""])
    return left, right, status
