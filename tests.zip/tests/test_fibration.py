"""In-memory fibration checker (Phase 1 sprint 7; mirror of migration 010).

Formal backing: ``Formal/Fibration.lean`` — the check is exactly a strongly
(co)cartesian morphism (``isStronglyCartesian_iff_check``,
``isStronglyCocartesian_iff_check``); every ``(u, e)`` having a lift passing it
is exactly ``Functor.IsFibered`` (``isFibered_iff_cleavageCheck``); existence
and uniqueness are both needed (``cartesian_existence_not_sufficient``,
``cartesian_uniqueness_not_sufficient``); over a one-object base the cartesian
morphisms are the isomorphisms (``isStronglyCartesian_star_iff_isIso``).
"""

from __future__ import annotations

import random
from collections import Counter

import pytest

from qbx.categorical.fibration import (
    Fibration,
    FibrationChecker,
    FibrationViolation,
    Lift,
    all_monoids,
    category,
    monoid_over_point,
    units,
)
from qbx.core.enforced_functor import EnforcementMode
from tests.fibration_examples import (
    elements_fibration,
    non_cartesian_example,
    random_fibration,
    transformation_monoid,
)


def reasons(fib: Fibration):
    return sorted(r for r, _ in fib.problems())


def test_category_of_elements_is_a_fibration():
    fib = elements_fibration()
    assert fib.problems() == []
    assert FibrationChecker(EnforcementMode.STRICT).check(fib)
    # every morphism of a discrete fibration is cartesian
    assert all(fib.is_cartesian(m) for m in fib.total.morphisms)


def test_category_of_elements_is_not_an_opfibration():
    fib = elements_fibration("opfibration")
    got = Counter(r for r, _ in fib.problems())
    # l1, l2 fail the cocartesian check (l2 does not factor through l1 and
    # vice versa), and u has no cocartesian lift at xa, xb or xc
    assert got == Counter({"cocartesian_existence": 2, "missing_lift": 3})
    missing = sorted(d["object"] for r, d in fib.problems() if r == "missing_lift")
    assert missing == ["xa", "xb", "xc"]


def test_non_cartesian_lift_is_reported():
    fib = non_cartesian_example()
    assert fib.problems() == [
        ("cartesian_existence", {"lift": "phi", "base": "u", "h": "psi", "w": "id_x"}),
        ("missing_lift", {"base": "u", "object": "b"}),
    ]
    with pytest.raises(FibrationViolation):
        FibrationChecker(EnforcementMode.STRICT).check(fib)
    assert not FibrationChecker(EnforcementMode.PERMISSIVE).check(fib)


def test_adding_the_factorization_repairs_it():
    """With k : c → a over id_x and φ ∘ k = ψ, φ is cartesian and lifts exist."""
    fib = non_cartesian_example()
    fib.total.add_morphism("k", "c", "a")
    fib.total.add_composition("k", "phi", "psi")
    fib.morphism_map["k"] = "id_x"
    assert fib.problems() == []


def test_uniqueness_failure():
    """Two k's over id_x with φ ∘ k = ψ: existence holds, uniqueness fails."""
    fib = non_cartesian_example()
    for k in ("k1", "k2"):
        fib.total.add_morphism(k, "c", "a")
        fib.total.add_composition(k, "phi", "psi")
        fib.morphism_map[k] = "id_x"
    assert reasons(fib) == ["cartesian_uniqueness", "missing_lift"]
    (_, details), _ = fib.problems()
    assert details["count"] == 2


def test_writer_refusals():
    fib = non_cartesian_example()
    with pytest.raises(ValueError, match="does not lie over"):
        fib.register_lift("psi", "id_x")
    with pytest.raises(ValueError, match="source / target"):
        fib.register_lift("psi", "u", source="a")
    with pytest.raises(ValueError, match="another base"):
        fib.register_lift("phi", "id_y")
    assert fib.register_lift("phi", "u") is fib.lifts[0]      # never replaced
    fib.register_lift("psi", "u")                              # same base and target: allowed
    assert [lift.morphism for lift in fib.lifts] == ["phi", "psi"]


def test_ill_formed_lifts_are_reported_not_checked():
    fib = non_cartesian_example()
    fib.lifts = [Lift("phi", "id_y", "a", "b"), Lift("psi", "u", "a", "b")]
    assert reasons(fib) == ["lift_not_over_base", "lift_typing", "missing_lift"]
    fib.morphism_map.pop("phi")
    fib.lifts = [Lift("phi", "u", "a", "b")]
    assert ("lift_not_over_base", {"lift": "phi", "base": "u", "image": None}) in fib.problems()


def test_functor_typing():
    fib = elements_fibration()
    fib.functor_source = "B"
    assert ("fibration_typing", {"functor": "p", "total": "E", "base": "B"}) in fib.problems()


def test_kind_is_validated():
    B = category("B", ["x"], {}, {})
    with pytest.raises(ValueError):
        Fibration(B, B, kind="bifibration")


# ---------------------------------------------------------------------------
# Oracle: over the one-object base, cartesian = invertible
# (isStronglyCartesian_star_iff_isIso)
# ---------------------------------------------------------------------------
def test_all_three_element_monoids_cartesian_iff_unit():
    elems = ["id_*", "x", "y"]
    count = 0
    for mul in all_monoids(elems, "id_*"):
        fib = monoid_over_point(elems, "id_*", mul)
        cartesian = sorted(m for m in elems if fib.is_cartesian(m))
        assert cartesian == sorted(units(elems, "id_*", mul))
        # non-units are exactly the failing registered lifts; a lift of id_pt
        # at * always exists (the identity), so there is no missing_lift
        failing = {d["lift"] for _, d in fib.problems()}
        assert failing == set(elems) - set(cartesian)
        count += 1
    assert count == 11      # labelled monoid tables on 3 elements with a fixed identity


def test_transformation_monoid():
    elems, unit, mul = transformation_monoid()
    fib = monoid_over_point(elems, unit, mul)
    assert sorted(m for m in elems if fib.is_cartesian(m)) == ["id_*", "s"]
    assert set(units(elems, unit, mul)) == {"id_*", "s"}
    got = {r for r, _ in fib.problems()}
    # c0 ∘ k = c0 for every k: existence holds, uniqueness fails; nothing
    # factors the identity through c0: existence fails
    assert got == {"cartesian_existence", "cartesian_uniqueness"}


# ---------------------------------------------------------------------------
# Random recordings: the problems are deterministic, and dropping all lifts
# never removes a missing_lift
# ---------------------------------------------------------------------------
def test_random_models_are_deterministic_and_lift_independent():
    rng = random.Random(1010)
    seen = Counter()
    for _ in range(200):
        fib = random_fibration(rng)
        probs = fib.problems()
        assert probs == fib.problems()
        seen.update(r for r, _ in probs)
        missing = [p for p in probs if p[0] == "missing_lift"]
        fib.lifts = []
        assert [p for p in fib.problems() if p[0] == "missing_lift"] == missing
    assert {"lift_typing", "lift_not_over_base", "cartesian_existence",
            "cocartesian_existence", "missing_lift"} <= set(seen)
