"""The verse strings in the Lean audit agree with the WLC data files in QBX/data/bible/."""

import json
import os
import re

ROOT = os.path.join(os.path.dirname(__file__), "..")
AUDIT = os.path.join(ROOT, "Forensics", "Inert", "KabbalahSecretsE8Audit.lean")
DATA = os.path.join(ROOT, "data", "bible")


def _lean_strings():
    s = open(AUDIT, encoding="utf-8").read()
    out = {}
    for k in (19, 20, 21):
        out[k] = re.search(r"def exod14_%d : List Char :=\s*\"([^\"]+)\"" % k, s).group(1)
    out["gen"] = re.search(r'def gen1_1 : String := "([^"]+)"', s).group(1)
    return out


def test_exodus_verses_match_tsv():
    lean = _lean_strings()
    rows = [l.rstrip("\n").split("\t") for l in open(os.path.join(DATA, "exodus_14_19-21_wlc.tsv"), encoding="utf-8")
            if not l.startswith("#") and not l.startswith("ref")]
    assert [r[0] for r in rows] == ["Exodus 14:19", "Exodus 14:20", "Exodus 14:21"]
    for k, r in zip((19, 20, 21), rows):
        assert lean[k] == r[2] and len(r[2]) == 72


def test_genesis_1_1_matches_wlc_tsv():
    lean = _lean_strings()["gen"]
    for line in open(os.path.join(DATA, "genesis_1_wlc.tsv"), encoding="utf-8"):
        if line.startswith("Genesis 1:1\t") or "\t1:1\t" in line or line.split("\t")[0] in ("1:1", "Gen.1.1"):
            text = line.rstrip("\n").split("\t")[-1]
            words = ["".join(c for c in w if "\u05d0" <= c <= "\u05ea") for w in text.split()]
            assert " ".join(w for w in words if w) == lean
            return
    raise AssertionError("Genesis 1:1 not found")


def test_stats_file():
    st = json.load(open(os.path.join(DATA, "torah_wlc_stats.json"), encoding="utf-8"))
    assert st["total"]["chapters"] == 187
    assert st["exodus_14_19_21_letters"] == [72, 72, 72]
    assert st["genesis_1_1"] == {"words": 7, "letters": 28}
    assert st["names72"][:3] == ["והו", "ילי", "סיט"]
