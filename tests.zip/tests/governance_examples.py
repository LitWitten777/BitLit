"""Random inputs for the governance checks (``qbx.governance``, migration 015).

Every generator takes a ``random.Random`` and is deterministic for a given
seed.  The inputs mix valid data with every kind of defect the checks report.
"""

from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Set, Tuple

from qbx.governance.modality import SEED

KINDS = [k for _, k, _, _ in SEED]
NAMES = [n for n, _, _, _ in SEED]
CONTEXT_NAMES = ["dev", "staging", "prod", "audit", "Ω", "ctx-ä"]
BLANKS = ["", " ", "\t\n", " \r\f\v "]
TEXTS = ["data_privacy", "x", " padded ", "ünïcode", "\u00a0", "a b"]


def random_text(rng: random.Random, blank_rate: float = 0.2) -> Optional[str]:
    r = rng.random()
    if r < 0.05:
        return None
    if r < 0.05 + blank_rate:
        return rng.choice(BLANKS)
    return rng.choice(TEXTS)


def random_version(rng: random.Random) -> str:
    good = ["1.0.0", "0.0.1", "10.20.30", "2.0.11"]
    bad = ["banana", "1.0", "01.0.0", "1.0.0.0", "1.0.0\n", "v1.0.0", "1.-1.0", "", "1.0.0 ",
           "١.0.0"]
    return rng.choice(good) if rng.random() < 0.6 else rng.choice(bad)


def random_json(rng: random.Random, object_rate: float = 0.6) -> Any:
    if rng.random() < object_rate:
        return rng.choice([{}, {"rules": []}, {"a": 1, "b": [True, None]}])
    return rng.choice([42, "x", [], [1, 2], None, True, 1.5])


def random_frame(rng: random.Random, n: Optional[int] = None,
                 p: float = 0.4) -> Tuple[List[str], Set[Tuple[str, str]]]:
    """A random set of contexts and relation; often closed into a preorder."""
    n = n if n is not None else rng.randint(0, 5)
    ctx = rng.sample(CONTEXT_NAMES, n)
    rel = {(a, b) for a in ctx for b in ctx if rng.random() < p}
    if ctx and rng.random() < 0.4:   # reflexive-transitive closure
        rel |= {(c, c) for c in ctx}
        changed = True
        while changed:
            new = {(a, d) for a, b in rel for c, d in rel if b == c} - rel
            changed = bool(new)
            rel |= new
    return ctx, rel


def random_outcomes(rng: random.Random, ctx: List[str]) -> Any:
    r = rng.random()
    if r < 0.05:
        return None
    if r < 0.1:
        return rng.choice([[], "pass", 1, {"dev": "true"}, {"dev": None}, {"dev": 1}])
    out: Dict[str, bool] = {}
    for c in ctx:
        if rng.random() < 0.9:
            out[c] = rng.random() < 0.7
    if rng.random() < 0.2:
        out["elsewhere"] = rng.random() < 0.5
    return out


def random_steps(rng: random.Random) -> Any:
    r = rng.random()
    if r < 0.08:
        return rng.choice(['"x"', [], {}, 3, None])
    roles = ["author", "reviewer", "security", "owner", "ü-role"]
    steps: List[Any] = []
    for _ in range(rng.randint(1, 4)):
        x = rng.random()
        if x < 0.75:
            steps.append({"role": rng.choice(roles)})
        elif x < 0.85:
            steps.append({"role": rng.choice(BLANKS + [3, None, ["a"]])})
        elif x < 0.92:
            steps.append({"name": "r"})
        else:
            steps.append(rng.choice(["author", 1, None, []]))
    return steps


def random_timeout(rng: random.Random) -> Optional[int]:
    return rng.choice([1, 2, 7, 30, 3650, 0, -3, 3651, None, 7, 7])


T0 = datetime(2026, 3, 29, 0, 30, tzinfo=timezone.utc)   # near a European DST change


def random_time(rng: random.Random, base: datetime = T0) -> datetime:
    return base + timedelta(hours=rng.randint(-48, 400), microseconds=rng.randint(0, 999999))


def random_window(rng: random.Random, timeout: Optional[int]) -> Tuple[Optional[datetime],
                                                                       Optional[datetime]]:
    a = random_time(rng) if rng.random() > 0.05 else None
    r = rng.random()
    if a is None or r < 0.05:
        return a, (random_time(rng) if rng.random() < 0.5 else None)
    t = timeout if isinstance(timeout, int) and timeout > 0 else 7
    if r < 0.15:
        return a, a - timedelta(seconds=rng.randint(0, 100))       # window
    if r < 0.3:
        return a, a + timedelta(days=t, microseconds=rng.choice([0, 1]))  # boundary
    return a, a + timedelta(hours=rng.randint(1, 24 * t + 48))
