"""Provisional-hypothesis expiry policy (decision Q-003: 90 days, renewable once)."""

from __future__ import annotations

import subprocess
import sys
from datetime import date
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parents[1] / "agents" / "scripts"
sys.path.insert(0, str(SCRIPTS))
import check_hypothesis_expiry as ce  # noqa: E402

HEAD = "# R\n\n## Proved\n\n| ID | x |\n|---|---|\n| H-1 | y |\n\n## Provisional\n\n" \
       "| ID | Claim | Owner | Registered | Expires | Renewals |\n|---|---|---|---|---|---|\n"


def reg(*rows):
    return HEAD + "".join(rows) + "\n## Other\n\n| a | b |\n"


def test_empty_section_is_fine():
    assert ce.check("## Provisional\n\n*(none)*\n", date(2026, 1, 1)) == ([], [])


def test_valid_entry_and_warning():
    t = reg("| P-1 | c | formal_verifier | 2026-10-01 | 2026-12-30 | 0 |\n")
    assert ce.check(t, date(2026, 10, 2)) == ([], [])
    errs, warns = ce.check(t, date(2026, 12, 20))
    assert errs == [] and warns == ["P-1: expires on 2026-12-30"]


def test_expiry_day_is_expired():
    t = reg("| P-1 | c | o | 2026-10-01 | 2026-12-30 | 0 |\n")
    errs, _ = ce.check(t, date(2026, 12, 30))
    assert errs and "renew it once" in errs[0]


def test_renewed_once():
    t = reg("| P-1 | c | o | 2026-10-01 | 2027-03-30 | 1 |\n")
    assert ce.check(t, date(2027, 1, 15))[0] == []
    errs, _ = ce.check(t, date(2027, 3, 30))
    assert errs and "prove, downgrade or abandon" in errs[0]


def test_policy_violations():
    t = reg("| P-1 | c | o | 2026-10-01 | 2027-10-01 | 0 |\n",   # window too long
            "| P-2 | c | o | 2026-10-01 | 2027-06-28 | 2 |\n",   # renewed twice
            "| P-3 | c |  | 2026-10-01 | 2026-12-30 | 0 |\n",    # no owner
            "| P-4 | c | o | soon | later | 0 |\n",
            "| P-5 | c | o |\n")
    errs, _ = ce.check(t, date(2026, 10, 2))
    joined = "\n".join(errs)
    for frag in ["P-1: Expires must be", "P-2: Renewals", "P-3: no owner", "P-4: dates", "malformed row"]:
        assert frag in joined


def test_bad_header():
    t = "## Provisional\n\n| ID | Claim |\n|---|---|\n| P | c |\n"
    assert ce.check(t, date(2026, 1, 1))[0]


def test_repository_registry_passes():
    r = subprocess.run([sys.executable, str(SCRIPTS / "check_hypothesis_expiry.py")],
                       capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr
