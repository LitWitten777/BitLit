"""Signed frozen-interface hashes (decision Q-002, option 1)."""

from __future__ import annotations

import copy
import json
import subprocess
import sys
from pathlib import Path

from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

SCRIPTS = Path(__file__).resolve().parents[1] / "agents" / "scripts"
sys.path.insert(0, str(SCRIPTS))
import _frozen_sig as fs  # noqa: E402

DATA = {"interfaces": {"a.py": {"sha256": "11" * 32, "frozen_at": "x"},
                       "QBX/b.sql": {"sha256": "22" * 32}}}


def anchor_for(key, key_id="k"):
    raw = key.public_key().public_bytes(serialization.Encoding.Raw,
                                        serialization.PublicFormat.Raw)
    return {key_id: raw.hex()}


def test_sign_and_check():
    k = Ed25519PrivateKey.generate()
    sig = fs.sign(DATA, k, "k")
    assert fs.check(DATA, sig, anchor_for(k))[0] == "ok"


def test_metadata_outside_hashes_is_not_signed_but_hashes_are():
    k = Ed25519PrivateKey.generate()
    sig = fs.sign(DATA, k, "k")
    d = copy.deepcopy(DATA)
    d["interfaces"]["a.py"]["frozen_at"] = "changed"
    d["computed_at"] = "now"
    assert fs.check(d, sig, anchor_for(k))[0] == "ok"
    d["interfaces"]["a.py"]["sha256"] = "33" * 32
    assert fs.check(d, sig, anchor_for(k))[0] == "invalid"
    d = copy.deepcopy(DATA)
    del d["interfaces"]["a.py"]
    assert fs.check(d, sig, anchor_for(k))[0] == "invalid"


def test_legacy_prefix_is_normalised():
    k = Ed25519PrivateKey.generate()
    sig = fs.sign(DATA, k, "k")
    d = {"interfaces": {"a.py": DATA["interfaces"]["a.py"], "b.sql": DATA["interfaces"]["QBX/b.sql"]}}
    assert fs.check(d, sig, anchor_for(k))[0] == "ok"


def test_wrong_key_unknown_key_and_missing_pieces():
    k, other = Ed25519PrivateKey.generate(), Ed25519PrivateKey.generate()
    sig = fs.sign(DATA, k, "k")
    assert fs.check(DATA, sig, anchor_for(other))[0] == "invalid"
    assert fs.check(DATA, sig, anchor_for(k, "someone-else"))[0] == "invalid"
    assert fs.check(DATA, None, anchor_for(k))[0] == "unsigned"
    assert fs.check(DATA, sig, {})[0] == "no_anchor"
    assert fs.check(DATA, dict(sig, algorithm="RSA"), anchor_for(k))[0] == "invalid"
    assert fs.check(DATA, dict(sig, signature="zz"), anchor_for(k))[0] == "invalid"


def test_repository_record_is_signed_and_verifies():
    """The committed hashes verify against the committed trust anchor."""
    r = subprocess.run([sys.executable, str(SCRIPTS / "verify_frozen.py"), "--require-signature"],
                       capture_output=True, text=True, env={"PATH": "/usr/bin:/bin"})
    assert r.returncode == 0, r.stdout + r.stderr
    assert "signature verified" in r.stdout


def test_out_of_band_anchor_overrides_repo(tmp_path):
    other = Ed25519PrivateKey.generate()
    anchor = tmp_path / "anchor.json"
    anchor.write_text(json.dumps({"keys": anchor_for(other, "dev-frozen-2026-10-01")}))
    r = subprocess.run([sys.executable, str(SCRIPTS / "verify_frozen.py")],
                       capture_output=True, text=True,
                       env={"PATH": "/usr/bin:/bin", "QBX_FROZEN_TRUST_ANCHOR": str(anchor)})
    assert r.returncode == 1 and "signature invalid" in r.stdout
