"""Tests for the Phase 1 monad / comonad engine (in-memory reference)."""

import itertools

import pytest

from qbx.categorical import (
    Comonad,
    ComposedFunctor,
    IdentityFunctor,
    Monad,
    MonadViolation,
    NaturalTransformation,
)
from qbx.core.enforced_functor import Category, EnforcedFunctor, EnforcementMode

STRICT = EnforcementMode.STRICT
PERMISSIVE = EnforcementMode.PERMISSIVE


class TableFunctor(EnforcedFunctor):
    def __init__(self, functor_id, source, target, objs, morphs, mode=PERMISSIVE):
        super().__init__(functor_id, functor_id, source, target, mode=mode)
        self._objs, self._morphs = objs, morphs
        for o in source.objects:
            self.map_object(o)
        for m in source.morphisms:
            self.map_morphism(m)

    def _map_object(self, obj_id):
        return self._objs[obj_id]

    def _map_morphism(self, morph_id):
        return self._morphs[morph_id]


def monoid(elements, mul):
    """One object S; x · y = mul(x, y) ('1' = identity)."""
    M = Category(id="M", name="monoid")
    M.add_object("S", "S")
    M.add_identity("S", "1")
    for e in elements:
        M.add_morphism(e, "S", "S")
    for g, f in itertools.product(elements, repeat=2):
        M.add_composition(f, g, mul(g, f))      # g ∘ f, f first
    return M


def endo(M, phi, name="T", mode=PERMISSIVE):
    return TableFunctor(name, M, M, {"S": "S"}, {m: phi.get(m, m) for m in M.morphisms}, mode)


def z2():
    return monoid(["s"], lambda g, f: "1")


def z3():
    t = {("g", "g"): "g2", ("g", "g2"): "1", ("g2", "g"): "1", ("g2", "g2"): "g"}
    return monoid(["g", "g2"], lambda x, y: t[(x, y)])


def klein():
    v = {"1": (0, 0), "a": (1, 0), "b": (0, 1), "c": (1, 1)}
    inv = {w: k for k, w in v.items()}
    return monoid(["a", "b", "c"],
                  lambda x, y: inv[((v[x][0] + v[y][0]) % 2, (v[x][1] + v[y][1]) % 2)])


def make_monad(M, phi, e, u, mode=PERMISSIVE, monad_mode=None):
    T = endo(M, phi, mode=mode)
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(M, mode=mode), T, mode=mode)
    mu = NaturalTransformation("mu", "mu", ComposedFunctor(T, T, mode=mode), T, mode=mode)
    eta.set_component("S", e, check=False)
    mu.set_component("S", u, check=False)
    return Monad("m", "m", T, eta, mu, mode=monad_mode or mode)


def make_comonad(M, phi, e, d, mode=PERMISSIVE):
    G = endo(M, phi, mode=mode)
    eps = NaturalTransformation("eps", "eps", G, IdentityFunctor(M, mode=mode), mode=mode)
    delta = NaturalTransformation("delta", "delta", G, ComposedFunctor(G, G, mode=mode), mode=mode)
    eps.set_component("S", e, check=False)
    delta.set_component("S", d, check=False)
    return Comonad("w", "w", G, eps, delta, mode=mode)


def laws(x):
    return sorted({v["law"] for v in x.violations})


def test_z2_monad_passes():
    m = make_monad(z2(), {}, "s", "s")
    assert m.verify_all_laws()
    assert m.violations == []


def test_z2_monad_strict():
    m = make_monad(z2(), {}, "s", "s", mode=STRICT)
    assert m.verify_all_laws()


def test_z3_unit_laws_fail():
    m = make_monad(z3(), {}, "g", "g")
    assert not m.verify_laws()
    assert laws(m) == ["left_unit", "right_unit"]


def test_z3_strict_raises():
    m = make_monad(z3(), {}, "g", "g", monad_mode=STRICT)
    with pytest.raises(MonadViolation):
        m.verify_laws()


def test_klein_left_unit_and_associativity():
    m = make_monad(klein(), {"a": "b", "b": "a"}, "a", "a")
    assert not m.verify_laws()
    assert laws(m) == ["associativity", "left_unit"]


def test_klein_naturality_fails_for_unit():
    m = make_monad(klein(), {"a": "b", "b": "a"}, "a", "a")
    assert not m.verify_all_laws()


def test_multiplication_functor_mismatch():
    M = klein()
    T = endo(M, {"a": "b", "b": "a"})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(M), T)
    mu = NaturalTransformation("mu", "mu", T, T)      # should be out of T∘T
    eta.set_component("S", "1", check=False)
    mu.set_component("S", "1", check=False)
    m = Monad("m", "m", T, eta, mu, mode=PERMISSIVE)
    assert not m.verify_functors()
    assert laws(m) == ["multiplication_functor_mismatch"]


def indiscrete():
    I = Category(id="I", name="indiscrete")
    for o in ("P", "Q"):
        I.add_object(o, o)
        I.add_identity(o, f"id_{o}")
    I.add_morphism("p", "P", "Q")
    I.add_morphism("q", "Q", "P")
    I.add_composition("p", "q", "id_P")
    I.add_composition("q", "p", "id_Q")
    return I


def test_monad_with_identity_composites():
    I = indiscrete()
    T = TableFunctor("T", I, I, {"P": "P", "Q": "P"}, {m: "id_P" for m in I.morphisms})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(I), T)
    mu = NaturalTransformation("mu", "mu", ComposedFunctor(T, T), T)
    for x, m in {"P": "id_P", "Q": "q"}.items():
        eta.set_component(x, m, check=False)
    for x in ("P", "Q"):
        mu.set_component(x, "id_P", check=False)
    m = Monad("m", "m", T, eta, mu, mode=PERMISSIVE)
    assert m.verify_all_laws(), m.violations
    # Kleisli: q : Q → P = T(Q);  id_P : P → P = T(P); composite μ_P ∘ T(id_P) ∘ q = q
    assert m.kleisli_compose("q", "id_P", "P") == "q"
    assert m.kleisli_compose("q", "id_P") is None       # T(P) = T(Q): Z ambiguous


def test_missing_and_ill_typed_components():
    I = indiscrete()
    T = TableFunctor("T", I, I, {"P": "P", "Q": "P"}, {m: "id_P" for m in I.morphisms})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(I), T)
    mu = NaturalTransformation("mu", "mu", ComposedFunctor(T, T), T)
    eta.set_component("P", "id_P", check=False)
    eta.set_component("Q", "p", check=False)          # p : P → Q, wrong
    mu.set_component("P", "id_P", check=False)        # μ_Q missing
    m = Monad("m", "m", T, eta, mu, mode=PERMISSIVE)
    assert not m.verify_components()
    assert {"unit_component_typing", "multiplication_component_missing"} <= set(laws(m))


def test_z2_comonad_passes():
    w = make_comonad(z2(), {}, "s", "s")
    assert w.verify_all_laws()


def test_z3_counit_laws_fail():
    w = make_comonad(z3(), {}, "g", "g")
    assert not w.verify_laws()
    assert laws(w) == ["left_counit", "right_counit"]


def test_klein_comonad():
    w = make_comonad(klein(), {"a": "b", "b": "a"}, "a", "a")
    assert not w.verify_laws()
    assert laws(w) == ["coassociativity", "right_counit"]


def test_typing_mismatch():
    M, N = z2(), z3()
    T = endo(M, {})
    eta = NaturalTransformation("eta", "eta", IdentityFunctor(N), IdentityFunctor(N))
    mu = NaturalTransformation("mu", "mu", ComposedFunctor(T, T), T)
    m = Monad("m", "m", T, eta, mu, mode=PERMISSIVE)
    assert not m.verify_all_laws()
    assert laws(m) == ["monad_typing"]


def test_serialize_intent_deterministic():
    m1 = make_monad(z2(), {}, "s", "s")
    m2 = make_monad(z2(), {}, "s", "s")
    assert m1.serialize_intent()[0] == m2.serialize_intent()[0]
