"""In-memory enriched-category engine (Phase 1, sprint 5).

Formal backing: ``Formal/Enriched.lean`` (registry H-022 – H-024).
"""

from __future__ import annotations

import itertools
from fractions import Fraction

import pytest

from qbx.categorical.enriched import (
    INF,
    QUANTALES,
    EnrichedCategory,
    EnrichedChecker,
    EnrichedViolation,
    compose_kernels,
    kernel_bad_rows,
    kernels_equal,
    parse_kernel,
    parse_value,
    quantale_of,
)
from qbx.core.enforced_functor import EnforcementMode


def metric(dists, objs="XYZ"):
    return EnrichedCategory(list(objs), "metric",
                            {k: {"distance": v} for k, v in dists.items()})


def reasons(ec):
    return sorted(r for r, _ in ec.problems())


# ---------------------------------------------------------------------------
# Values and quantales
# ---------------------------------------------------------------------------
def test_kinds_map_to_quantales():
    assert quantale_of("metric").name == "lawvere"
    assert quantale_of("ordered").name == "boolean"
    assert quantale_of("quantale", "product").name == "product"
    assert quantale_of("probabilistic") is None
    with pytest.raises(ValueError):
        quantale_of("quantale", "tropical")
    with pytest.raises(ValueError):
        quantale_of("fuzzy")


def test_parse_value():
    law, boo = QUANTALES["lawvere"], QUANTALES["boolean"]
    assert parse_value(law, {"distance": 0.1}) == Fraction(1, 10)
    assert parse_value(law, {"distance": "Infinity"}) == INF
    assert parse_value(law, {"distance": float("nan")}) is None
    assert parse_value(law, {"distance": True}) is None
    assert parse_value(law, {"foo": 1}) is None
    assert parse_value(boo, {"holds": False}) == 0
    assert parse_value(boo, {"distance": 1}) is None
    assert parse_value(QUANTALES["product"], {"value": "Infinity"}) is None


def test_exact_arithmetic():
    # 0.1 + 0.7 = 0.8 exactly, although 0.1 + 0.7 < 0.8 in binary floating point
    assert 0.1 + 0.7 < 0.8
    assert reasons(metric({("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
                           ("X", "Y"): 0.1, ("Y", "Z"): 0.7, ("X", "Z"): 0.8})) == []


# ---------------------------------------------------------------------------
# Laws
# ---------------------------------------------------------------------------
def test_lawvere_metric():
    good = {("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
            ("X", "Y"): 1, ("Y", "Z"): 1, ("X", "Z"): 2}
    assert metric(good).is_enriched()
    assert reasons(metric({**good, ("X", "Z"): 5})) == ["composition_law"]
    bad = dict(good)
    del bad[("X", "Z")]
    (r, d), = metric(bad).problems()
    assert r == "composition_law" and d["missing"] and d["direct"] == INF


def test_unit_law_not_sufficient():
    """Formal/Enriched.lean: unit_law_not_sufficient (the constant distance 1)."""
    ec = metric({("X", "X"): 1}, objs="X")
    assert reasons(ec) == ["unit_law"]


def test_composition_law_not_sufficient():
    """Formal/Enriched.lean: composition_law_not_sufficient (d 0 2 = 3)."""
    d = {(x, x): 0 for x in "XYZ"}
    d.update({(x, y): 1 for x in "XYZ" for y in "XYZ" if x != y})
    d[("X", "Z")] = 3
    assert reasons(metric(d)) == ["composition_law"]


VALUES = [0, 1, 2, "Infinity", None]       # None: no hom recorded


def to_num(v):
    return INF if v in ("Infinity", None) else Fraction(v)


@pytest.mark.parametrize("objs", ["X", "XY"])
def test_lawvere_exhaustive_against_definition(objs):
    """The engine (which joins recorded pairs only) agrees with the definition of
    lawvere_enriched_iff (all triples, missing = ∞) — triangle_iff_finite."""
    pairs = [(x, y) for x in objs for y in objs]
    for choice in itertools.product(VALUES, repeat=len(pairs)):
        d = {p: v for p, v in zip(pairs, choice) if v is not None}
        full = {p: to_num(v) for p, v in zip(pairs, choice)}
        definition = all(full[(x, x)] == 0 for x in objs) and all(
            full[(x, z)] <= full[(x, y)] + full[(y, z)]
            for x in objs for y in objs for z in objs)
        assert metric(d, objs).is_enriched() == definition, d


def test_three_point_sample_against_definition():
    import random
    rng = random.Random(5)
    objs = "XYZ"
    pairs = [(x, y) for x in objs for y in objs]
    for _ in range(2000):
        choice = [rng.choice(VALUES) for _ in pairs]
        d = {p: v for p, v in zip(pairs, choice) if v is not None}
        full = {p: to_num(v) for p, v in zip(pairs, choice)}
        definition = all(full[(x, x)] == 0 for x in objs) and all(
            full[(x, z)] <= full[(x, y)] + full[(y, z)]
            for x in objs for y in objs for z in objs)
        assert metric(d, objs).is_enriched() == definition


def test_other_quantales():
    base = {("X", "X"): 1, ("Y", "Y"): 1, ("Z", "Z"): 1,
            ("X", "Y"): 0.5, ("Y", "Z"): 0.5, ("X", "Z"): 0.3}
    hv = {k: {"value": v} for k, v in base.items()}
    assert reasons(EnrichedCategory(list("XYZ"), "quantale", hv, quantale="goedel")) == [
        "composition_law"]
    assert reasons(EnrichedCategory(list("XYZ"), "quantale", hv, quantale="product")) == []
    ultra = {("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
             ("X", "Y"): 1, ("Y", "Z"): 2, ("X", "Z"): 2.5}
    ec = EnrichedCategory(list("XYZ"), "quantale",
                          {k: {"distance": v} for k, v in ultra.items()}, quantale="ultrametric")
    assert reasons(ec) == ["composition_law"]
    assert metric(ultra).is_enriched()


def test_preorder():
    holds = {(x, x): True for x in "XYZ"}
    holds.update({("X", "Y"): True, ("Y", "Z"): True})
    ec = EnrichedCategory(list("XYZ"), "ordered", {k: {"holds": v} for k, v in holds.items()})
    assert reasons(ec) == ["composition_law"]
    holds[("X", "Z")] = True
    ec = EnrichedCategory(list("XYZ"), "ordered", {k: {"holds": v} for k, v in holds.items()})
    assert ec.is_enriched()


def test_tolerance_and_ranges():
    d = {("X", "X"): 0, ("Y", "Y"): 0, ("X", "Y"): 1, ("Y", "X"): 1}
    ec = metric({**d, ("X", "X"): Fraction(1, 10**7)}, objs="XY")
    assert "unit_law" in reasons(ec)
    ec.tolerance = Fraction(1, 10**6)
    assert ec.is_enriched()
    assert "out_of_range" in reasons(metric({**d, ("X", "Y"): -1}, objs="XY"))
    assert "foreign_object" in reasons(metric({**d, ("X", "W"): 1}, objs="XY"))


# ---------------------------------------------------------------------------
# Kernels
# ---------------------------------------------------------------------------
P01 = {"a": {"a": 0.5, "b": 0.5}, "b": {"b": 1}}
P12 = {"a": {"a": 0.9, "b": 0.1}, "b": {"a": 0.2, "b": 0.8}}
P02 = {"a": {"a": 0.55, "b": 0.45}, "b": {"a": 0.2, "b": 0.8}}


def test_kernel_composition_is_stochastic_and_associative():
    f, g = parse_kernel({"kernel": P01}), parse_kernel({"kernel": P12})
    fg = compose_kernels(f, g)
    assert kernels_equal(fg, parse_kernel({"kernel": P02}))
    assert kernel_bad_rows(fg) == []
    h = parse_kernel({"kernel": {"a": {"b": 1}, "b": {"a": 0.25, "b": 0.75}}})
    assert kernels_equal(compose_kernels(compose_kernels(f, g), h),
                         compose_kernels(f, compose_kernels(g, h)))


def test_markov_chain():
    homs = {("T0", "T1"): {"kernel": P01}, ("T1", "T2"): {"kernel": P12},
            ("T0", "T2"): {"kernel": P02}, ("T1", "T1"): {"kernel": {"a": {"a": 1}, "b": {"b": 1}}}}
    ec = EnrichedCategory(["T0", "T1", "T2"], "probabilistic", homs)
    assert ec.is_enriched()
    assert ec.composition_problems(("T1", "T2"), ("T0", "T1"), {"kernel": P02}) == []
    homs[("T0", "T2")] = {"kernel": P01}
    assert reasons(ec) == ["chapman_kolmogorov"]
    assert [r for r, _ in ec.composition_problems(("T1", "T2"), ("T0", "T1"),
                                                  {"kernel": P02})] == ["chapman_kolmogorov"]


def test_composition_rows():
    ec = metric({("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
                 ("X", "Y"): 1, ("Y", "Z"): 1, ("X", "Z"): 2})
    assert ec.composition_problems(("Y", "Z"), ("X", "Y"), {"distance": 2}) == []
    assert [r for r, _ in ec.composition_problems(("X", "Y"), ("X", "Y"), {"distance": 2})] == [
        "composition_typing"]
    assert [r for r, _ in ec.composition_problems(("Y", "Z"), ("X", "Y"), {"distance": 1})] == [
        "composition_value"]


def test_strict_mode_raises():
    ec = metric({("X", "X"): 1}, objs="X")
    with pytest.raises(EnrichedViolation):
        EnrichedChecker(EnforcementMode.STRICT).check(ec)
    checker = EnrichedChecker(EnforcementMode.PERMISSIVE)
    assert checker.check(ec) is False
    assert [r for r, _ in checker.violations] == ["unit_law"]
