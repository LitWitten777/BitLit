"""Pytest fixtures for QBX Phase 0."""

import os
import pytest

from qbx.core.enforced_functor import EnforcementMode

@pytest.fixture(autouse=True)
def _set_test_env(monkeypatch):
    monkeypatch.setenv("QBX_ENFORCEMENT_MODE", "permissive")
    monkeypatch.setenv("QBX_HEBREW_MIX_ENABLED", "true")
    monkeypatch.setenv("QBX_WEYL_EXPANSION_REQUIRES_CAPABILITY", "true")
    yield

@pytest.fixture
def strict_mode():
    return EnforcementMode.STRICT

@pytest.fixture
def permissive_mode():
    return EnforcementMode.PERMISSIVE