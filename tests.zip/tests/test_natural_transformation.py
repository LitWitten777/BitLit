"""Tests for the Phase 1 natural transformation checker."""

import pytest

from qbx.categorical import (
    NaturalTransformation,
    NaturalityViolation,
    compose,
    generates,
    incremental_checked_morphisms,
    legacy_trigger_checked_morphisms,
)
from qbx.core.enforced_functor import Category, EnforcedFunctor, EnforcementMode

STRICT = EnforcementMode.STRICT
PERMISSIVE = EnforcementMode.PERMISSIVE


class TableFunctor(EnforcedFunctor):
    """A functor given by explicit object and morphism tables."""

    def __init__(self, functor_id, source, target, objs, morphs, mode=STRICT):
        super().__init__(functor_id, functor_id, source, target, mode=mode)
        self._objs, self._morphs = objs, morphs
        for o in source.objects:
            self.map_object(o)
        for m in source.morphisms:
            self.map_morphism(m)

    def _map_object(self, obj_id):
        return self._objs[obj_id]

    def _map_morphism(self, morph_id):
        return self._morphs[morph_id]


def _arrow_category():
    """C = (X --f--> Y)."""
    C = Category(id="C", name="arrow")
    for o in ("X", "Y"):
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("f", "X", "Y")
    return C


def _square_target(commuting=True):
    """D containing a square  A --p--> B,  A' --q--> B',  a: A→A', b: B→B'."""
    D = Category(id="D", name="square")
    for o in ("A", "B", "A2", "B2"):
        D.add_object(o, o)
        D.add_identity(o, f"id_{o}")
    D.add_morphism("p", "A", "B")
    D.add_morphism("q", "A2", "B2")
    D.add_morphism("a", "A", "A2")
    D.add_morphism("b", "B", "B2")
    D.add_morphism("r", "A", "B2")
    D.add_morphism("s", "A", "B2")
    D.add_composition("p", "b", "r")                     # b ∘ p = r
    D.add_composition("a", "q", "r" if commuting else "s")  # q ∘ a = r (or s)
    return D


def _arrow_functors(D):
    C = _arrow_category()
    F = TableFunctor("F", C, D, {"X": "A", "Y": "B"},
                     {"id_X": "id_A", "id_Y": "id_B", "f": "p"})
    G = TableFunctor("G", C, D, {"X": "A2", "Y": "B2"},
                     {"id_X": "id_A2", "id_Y": "id_B2", "f": "q"})
    return C, F, G


def test_functors_used_in_tests_are_lawful():
    _, F, G = _arrow_functors(_square_target())
    assert F.verify_all_laws() and G.verify_all_laws()


def test_commuting_square_is_natural():
    _, F, G = _arrow_functors(_square_target(commuting=True))
    eta = NaturalTransformation("eta", "eta", F, G, mode=STRICT)
    assert eta.set_component("X", "a")
    assert eta.set_component("Y", "b")
    assert eta.verify_all_laws()
    assert eta.violations == []


def test_non_commuting_square_strict_raises():
    _, F, G = _arrow_functors(_square_target(commuting=False))
    eta = NaturalTransformation("eta", "eta", F, G, mode=STRICT)
    eta.set_component("X", "a")
    with pytest.raises(NaturalityViolation) as exc:
        eta.set_component("Y", "b")
    assert exc.value.law == "naturality_square"


def test_non_commuting_square_permissive_logs():
    _, F, G = _arrow_functors(_square_target(commuting=False))
    eta = NaturalTransformation("eta", "eta", F, G, mode=PERMISSIVE)
    assert eta.set_component("X", "a")       # nothing checkable yet
    assert not eta.set_component("Y", "b")   # square of f checked here
    assert [v["law"] for v in eta.violations] == ["naturality_square"]
    assert not eta.verify_naturality()


@pytest.mark.parametrize("order", [("X", "Y"), ("Y", "X")])
def test_incremental_check_catches_violation_in_either_order(order):
    """Regression for the migration-004 trigger defect (Lean: checkedBy_of_mem)."""
    _, F, G = _arrow_functors(_square_target(commuting=False))
    eta = NaturalTransformation("eta", "eta", F, G, mode=PERMISSIVE)
    comps = {"X": "a", "Y": "b"}
    results = [eta.set_component(o, comps[o]) for o in order]
    assert results == [True, False]


def test_component_typing_violation():
    _, F, G = _arrow_functors(_square_target())
    eta = NaturalTransformation("eta", "eta", F, G, mode=STRICT)
    with pytest.raises(NaturalityViolation) as exc:
        eta.set_component("X", "b")   # b: B → B2, but η_X must be A → A2
    assert exc.value.law == "component_typing"


def test_missing_component_detected():
    _, F, G = _arrow_functors(_square_target())
    eta = NaturalTransformation("eta", "eta", F, G, mode=PERMISSIVE)
    eta.set_component("X", "a")
    assert not eta.verify_typing()
    assert eta.violations[-1]["law"] == "component_missing"


def test_missing_composite_is_a_violation_not_a_pass():
    _, F, G = _arrow_functors(_square_target())
    del F.target.compositions[("a", "q")]
    eta = NaturalTransformation("eta", "eta", F, G, mode=PERMISSIVE)
    eta.components.update({"X": "a", "Y": "b"})
    assert not eta.verify_naturality()
    assert eta.violations[-1]["law"] == "naturality_composite_missing"


def _endo_setup():
    """One object X with endomorphisms e, k that do not commute; F = G = id."""
    C = Category(id="E", name="endo")
    C.add_object("X", "X")
    C.add_identity("X", "id_X")
    for m in ("e", "k", "ek", "ke"):
        C.add_morphism(m, "X", "X")
    C.add_composition("e", "k", "ek")   # k ∘ e
    C.add_composition("k", "e", "ke")   # e ∘ k
    ident = {m: m for m in C.morphisms}
    F = TableFunctor("Id", C, C, {"X": "X"}, ident, mode=PERMISSIVE)
    return C, F


def test_endomorphism_square_is_checked():
    """The original trigger skipped every endomorphism (Lean: trigger_misses_endo)."""
    C, F = _endo_setup()
    eta = NaturalTransformation("eta", "eta", F, F, mode=PERMISSIVE)
    assert not eta.set_component("X", "k")   # square of e: e;k = ek ≠ ke = k;e
    laws = {v["details"]["f"] for v in eta.violations if v["law"] == "naturality_square"}
    assert "e" in laws
    assert "e" not in legacy_trigger_checked_morphisms(C, ["X"])
    assert "e" in incremental_checked_morphisms(C, ["X"])


def test_legacy_trigger_misses_forward_square():
    """Lean: trigger_misses_forward / triggerCheckedBy_iff."""
    C = _arrow_category()
    assert "f" not in legacy_trigger_checked_morphisms(C, ["X", "Y"])
    assert "f" in legacy_trigger_checked_morphisms(C, ["Y", "X"])
    for order in (["X", "Y"], ["Y", "X"]):
        assert incremental_checked_morphisms(C, order) == set(C.morphisms)


def _chain():
    """C = X --f--> Y --g--> Z with h = g ∘ f, mapped into D by F, G."""
    C = Category(id="C3", name="chain")
    for o in ("X", "Y", "Z"):
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("f", "X", "Y")
    C.add_morphism("g", "Y", "Z")
    C.add_morphism("h", "X", "Z")
    C.add_composition("f", "g", "h")
    return C


def test_generates():
    C = _chain()
    assert generates(C, ["f", "g"])
    assert not generates(C, ["f"])
    assert not generates(C, ["f", "h"])


def test_naturality_on_generators_matches_full_check():
    """F = G = id on the chain, η = identities: natural; generators shortcut agrees."""
    C = _chain()
    ident = {m: m for m in C.morphisms}
    F = TableFunctor("Id", C, C, {o: o for o in C.objects}, ident)
    eta = NaturalTransformation.identity(F, "id_F", mode=STRICT)
    assert eta.verify_all_laws()
    assert eta.verify_naturality(generators=["f", "g"])


def test_non_generating_set_falls_back_to_full_check():
    C = _chain()
    D = Category(id="D3", name="chain-copy")
    for o in ("X", "Y", "Z"):
        D.add_object(o, o)
        D.add_identity(o, f"id_{o}")
    for m, (s, t) in C.morphisms.items():
        if m.startswith("id_"):
            continue
        D.add_morphism(m, s, t)
    D.add_morphism("h2", "X", "Z")   # a parallel morphism to h
    D.add_composition("f", "g", "h")
    F = TableFunctor("F", C, D, {o: o for o in C.objects},
                     {m: m for m in C.morphisms})
    G = TableFunctor("G", C, D, {o: o for o in C.objects},
                     {**{m: m for m in C.morphisms}, "h": "h2"}, mode=PERMISSIVE)
    # G breaks the composition law, so the square of h fails while f, g pass.
    eta = NaturalTransformation("eta", "eta", F, G, mode=PERMISSIVE)
    eta.components.update({o: f"id_{o}" for o in C.objects})
    assert not eta.verify_naturality(generators=["f"])   # falls back, finds h
    assert eta.violations[-1]["details"]["f"] == "h"


def test_vertical_composition_of_identities():
    C = _chain()
    F = TableFunctor("Id", C, C, {o: o for o in C.objects}, {m: m for m in C.morphisms})
    one = NaturalTransformation.identity(F, "one", mode=STRICT)
    two = one.vcompose(one, "two")
    assert two.components == one.components
    assert two.verify_all_laws()


def test_compose_unit_laws():
    C = _chain()
    assert compose(C, "id_X", "f") == "f"
    assert compose(C, "f", "id_Y") == "f"
    assert compose(C, "f", "g") == "h"
    assert compose(C, "g", "f") is None   # not composable


def test_serialize_intent_deterministic():
    _, F, G = _arrow_functors(_square_target())
    eta = NaturalTransformation("eta", "eta", F, G, mode=STRICT)
    eta.set_component("Y", "b")
    eta.set_component("X", "a")
    c1, b1 = eta.serialize_intent()
    eta2 = NaturalTransformation("eta", "eta", F, G, mode=STRICT)
    eta2.set_component("X", "a")
    eta2.set_component("Y", "b")
    c2, b2 = eta2.serialize_intent()
    assert c1 == c2 and b1.payload_hash == b2.payload_hash
