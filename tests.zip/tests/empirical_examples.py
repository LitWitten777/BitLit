"""Random inputs for the empirical-grounding checks (``qbx.empirical``,
migration 016).

Every generator takes a ``random.Random`` and is deterministic for a given
seed.  The inputs mix valid data with every kind of defect the checks report.
Numbers are small decimals so that boundary cases (``9.7 + 0.3 = 10``) occur
and exact arithmetic matters.
"""

from __future__ import annotations

import random
from datetime import timedelta
from typing import Any, Dict, List, Optional

from qbx.empirical.measurement import TESTS
from tests.governance_examples import BLANKS, T0, random_text, random_version

NUMBERS = [0, 1, 2, 3, 10, -1, -2, 0.1, 0.2, 0.3, 0.5, 2.5, 9.7, 9.8, 1e-05, 1.5, 7, 12]
NON_NUMBERS = ["1", None, True, [], {}, "NaN"]
UNITS = ["K", "m", "s"]
BAD_JSON = [42, "x", [], [1, 2], True, 1.5]


def random_number(rng: random.Random) -> Any:
    return rng.choice(NUMBERS)


def maybe_bad_number(rng: random.Random, bad_rate: float = 0.1) -> Any:
    return rng.choice(NON_NUMBERS) if rng.random() < bad_rate else random_number(rng)


def random_object(rng: random.Random, object_rate: float = 0.85) -> Any:
    if rng.random() < object_rate:
        return rng.choice([{}, {"a": 1}, {"source": "lab", "n": [1, 2]}])
    return rng.choice(BAD_JSON + [None])


def random_name_json(rng: random.Random) -> Any:
    """A JSON value that is usually a name."""
    r = rng.random()
    if r < 0.8:
        return rng.choice(UNITS)
    if r < 0.9:
        return rng.choice(BLANKS)
    return rng.choice([5, None, ["K"]])


# ---------------------------------------------------------------------------
# Measurements
# ---------------------------------------------------------------------------
def random_descriptor(rng: random.Random) -> Any:
    r = rng.random()
    if r < 0.3:
        return {"kind": "interval"}
    if r < 0.45:
        return {"kind": "uniform"}
    if r < 0.8:
        return {"kind": "gaussian", "coverage_factor": rng.choice([1, 2, 3, 1.5, 0, -2, "2"])}
    return rng.choice([{"kind": "poisson"}, {"kind": 5}, {}, {"kind": "gaussian"}, 42, None, []])


def random_body(rng: random.Random) -> Any:
    if rng.random() < 0.08:
        return rng.choice(BAD_JSON + [None])
    body: Dict[str, Any] = {}
    if rng.random() < 0.7:
        body["min"] = maybe_bad_number(rng, 0.05)
    if rng.random() < 0.7:
        body["max"] = maybe_bad_number(rng, 0.05)
    if rng.random() < 0.7:
        body["unit"] = random_name_json(rng)
    if rng.random() < 0.2:
        body["note"] = "extra keys are allowed"
    return body


def random_precision(rng: random.Random) -> Any:
    if rng.random() < 0.08:
        return rng.choice(BAD_JSON + [None])
    p: Dict[str, Any] = {}
    if rng.random() < 0.6:
        p["absolute"] = rng.choice([0, 0.1, 0.5, 1, 2, -1, "1"])
    if rng.random() < 0.5:
        p["relative"] = rng.choice([0, 0.01, 0.1, -0.1, None])
    return p


def random_tests(rng: random.Random) -> Any:
    if rng.random() < 0.08:
        return rng.choice(["range_check", [1], {"t": 1}, None, ["range_check", 2]])
    pool = list(TESTS) * 2 + (["rnage_check"] if rng.random() < 0.2 else [])
    n = rng.randint(0, 4)
    out: List[str] = []
    for _ in range(n):
        t = rng.choice(pool)
        if t in out and rng.random() < 0.8:
            continue
        out.append(t)
    return out


def random_observation(rng: random.Random) -> Any:
    if rng.random() < 0.05:
        return rng.choice([5, "x", None, []])
    o: Dict[str, Any] = {}
    if rng.random() < 0.95:
        o["value"] = maybe_bad_number(rng, 0.05)
    if rng.random() < 0.7:
        o["uncertainty"] = rng.choice([0, 0.1, 0.2, 0.3, 0.5, 1, 2, 0.6, -0.1, "0.1"])
    if rng.random() < 0.6:
        o["unit"] = random_name_json(rng)
    return o


def random_observations(rng: random.Random) -> Any:
    if rng.random() < 0.06:
        return rng.choice([{"value": 99}, [], "x", 3, None])
    return [random_observation(rng) for _ in range(rng.randint(1, 4))]


def random_contract(rng: random.Random, name: Optional[str] = None) -> Dict[str, Any]:
    return {
        "name": name if name is not None else random_text(rng, blank_rate=0.1),
        "observable_id": random_text(rng, blank_rate=0.1),
        "version": random_version(rng),
        "body": random_body(rng),
        "expected_precision": random_precision(rng),
        "validation_tests": random_tests(rng),
    }


def random_bundle(rng: random.Random) -> Dict[str, Any]:
    return {
        "observations": random_observations(rng),
        "context": random_object(rng, 0.9),
        "provenance": random_object(rng, 0.9),
    }


def good_contract(rng: random.Random, name: str) -> Dict[str, Any]:
    """A contract without problems."""
    lo = rng.choice([0, 1, -1, 2.5])
    body: Dict[str, Any] = {"min": lo, "max": lo + rng.choice([0, 5, 9.7, 10]), "unit": "K"}
    if rng.random() < 0.3:
        del body["min"]
    if rng.random() < 0.3:
        del body["max"]
    prec = {"absolute": rng.choice([0, 0.1, 0.3, 0.5]), "relative": rng.choice([0, 0.01, 0.1])}
    tests = rng.sample(list(TESTS), rng.randint(0, 3))
    return {"name": name, "observable_id": "T", "version": "1.0.0", "body": body,
            "expected_precision": prec, "validation_tests": tests}


def good_bundle(rng: random.Random) -> Dict[str, Any]:
    obs = []
    for _ in range(rng.randint(1, 4)):
        o: Dict[str, Any] = {"value": rng.choice([0, 1, 2.5, 5, 9.7, 9.8, 10, -1, 0.3])}
        if rng.random() < 0.8:
            o["uncertainty"] = rng.choice([0, 0.1, 0.3, 0.5, 1])
        if rng.random() < 0.8:
            o["unit"] = rng.choice(["K", "K", "m"])
        obs.append(o)
    return {"observations": obs, "context": {}, "provenance": {}}


def good_descriptor(rng: random.Random) -> Optional[dict]:
    return rng.choice([None, {"kind": "interval"}, {"kind": "uniform"},
                       {"kind": "gaussian", "coverage_factor": 2},
                       {"kind": "gaussian", "coverage_factor": 1.5}])


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
def random_solver_config(rng: random.Random) -> Any:
    if rng.random() < 0.1:
        return rng.choice(BAD_JSON + [None])
    c: Dict[str, Any] = {}
    if rng.random() < 0.5:
        c["tolerance"] = rng.choice([1e-06, 0.001, 1, 0, -1, "small"])
    if rng.random() < 0.3:
        c["method"] = "rk45"
    return c


def random_tolerance(rng: random.Random) -> Optional[float]:
    return rng.choice([None, 1e-06, 0.01, 1.0, 0.0, -1.0, float("nan"), float("inf")])


def random_window(rng: random.Random):
    started = None if rng.random() < 0.05 else T0 + timedelta(minutes=rng.randint(0, 100))
    r = rng.random()
    if r < 0.4 or started is None:
        finished = None if r < 0.3 else T0
    else:
        finished = started + timedelta(minutes=rng.choice([-5, 0, 1, 60]))
    return started, finished


def random_names_json(rng: random.Random, pool: List[str]) -> Any:
    r = rng.random()
    if r < 0.15:
        return None
    if r < 0.25:
        return rng.choice([5, "cam", {"a": 1}, ["cam", ""], ["cam", 3]])
    xs = [rng.choice(pool) for _ in range(rng.randint(0, 3))]
    return xs


def random_safety(rng: random.Random, pool: List[str]) -> Any:
    r = rng.random()
    if r < 0.2:
        return None
    if r < 0.28:
        return rng.choice([{"actuator": "arm"}, "x", 3])
    out = []
    for _ in range(rng.randint(0, 3)):
        if rng.random() < 0.1:
            out.append(rng.choice([5, "arm", None]))
            continue
        c: Dict[str, Any] = {"actuator": rng.choice(pool + ["", "ghost", 7])}
        if rng.random() < 0.5:
            c["min"] = maybe_bad_number(rng, 0.1)
        if rng.random() < 0.5:
            c["max"] = maybe_bad_number(rng, 0.1)
        out.append(c)
    return out


# ---------------------------------------------------------------------------
# Mechanisms
# ---------------------------------------------------------------------------
TYPES = ["lo", "mid", "hi"]
OUTCOMES = ["none", "half", "item"]


def random_spec(rng: random.Random) -> Any:
    if rng.random() < 0.05:
        return rng.choice(BAD_JSON + [None])
    types = rng.sample(TYPES, rng.randint(1, 3))
    outcomes = rng.sample(OUTCOMES, rng.randint(1, 3))
    spec: Dict[str, Any] = {
        "types": types,
        "outcomes": outcomes,
        "allocation": {t: rng.choice(outcomes) for t in types},
        "payment": {t: rng.choice([0, 0.5, 1, 1.5, 2, 3]) for t in types},
        "valuation": {t: {o: rng.choice([0, 1, 2, 2.5, 3, 4]) for o in outcomes} for t in types},
    }
    r = rng.random()
    if r < 0.04:
        spec["types"] = rng.choice([[], ["lo", "lo"], ["lo", ""], "lo", [1]])
    elif r < 0.08:
        spec["outcomes"] = rng.choice([[], ["x", "x"], None])
    elif r < 0.12:
        spec["allocation"] = rng.choice([{}, {types[0]: "ghost"}, [1], {t: 1 for t in types}])
    elif r < 0.16:
        spec["payment"] = {t: "1" for t in types}
    elif r < 0.2:
        spec["valuation"] = {t: {} for t in types}
    elif r < 0.22:
        spec["allocation"] = dict(spec["allocation"], extra=outcomes[0])
    return spec


def random_constraints(rng: random.Random) -> Any:
    r = rng.random()
    if r < 0.1:
        return None
    if r < 0.17:
        return rng.choice([[], "ic", {"ic": "yes"}, {"ir": 1}])
    c: Dict[str, Any] = {}
    if rng.random() < 0.7:
        c["ic"] = rng.random() < 0.8
    if rng.random() < 0.6:
        c["ir"] = rng.random() < 0.8
    return c
