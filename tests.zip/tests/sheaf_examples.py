"""Shared sheaf examples for ``tests/test_sheaf.py`` and ``tests/live_db/test_sheaf_db.py``."""

from __future__ import annotations

import itertools
import random
from typing import List

from qbx.categorical.sheaf import (
    CochainRecord,
    CohomologyRecord,
    FiniteSite,
    Presheaf,
    constant_presheaf,
    functions_presheaf,
    generated_topology,
)

BOGUS = "U_bogus"


def canon(problems):
    """Problems in a canonical order (details compared as sorted items)."""
    return sorted((r, repr(sorted(d.items()))) for r, d in problems)


def random_topology(rng: random.Random, max_points: int = 3) -> FiniteSite:
    points = ["a", "b", "c", "d"][:rng.randint(1, max_points)]
    gens = [[p for p in points if rng.random() < 0.5] for _ in range(rng.randint(0, 3))]
    return generated_topology(points, gens)


def random_covers(rng: random.Random, site: FiniteSite, k: int) -> None:
    opens = sorted(site.opens)
    for i in range(k):
        covered = rng.choice(opens)
        inside = [v for v in opens if site.subset(v, covered)]
        members = [v for v in inside if rng.random() < 0.5]
        if rng.random() < 0.7:                     # usually make it a cover
            missing = site.opens[covered] - frozenset().union(*(site.opens[m] for m in members))
            if missing:
                members.append(covered if rng.random() < 0.3 else
                               min((v for v in inside if site.opens[v] >= missing),
                                   key=lambda v: len(site.opens[v])))
        if rng.random() < 0.05:
            members.append(BOGUS)
        if rng.random() < 0.05:
            outside = [v for v in opens if not site.subset(v, covered)]
            if outside:
                members.append(rng.choice(outside))
        if rng.random() < 0.03:
            covered = BOGUS
        site.add_cover(f"c{i}", covered, members)


def random_site(rng: random.Random) -> FiniteSite:
    """A random finite topology with some covers, sometimes broken (an open
    removed, a wrong base, covers that do not cover or are ill typed)."""
    site = random_topology(rng)
    for _ in range(2):
        if rng.random() < 0.12 and len(site.opens) > 1:
            del site.opens[rng.choice(sorted(site.opens))]
    if rng.random() < 0.04:
        site.base = rng.choice([None, BOGUS] + sorted(site.opens))
    random_covers(rng, site, rng.randint(0, 3))
    return site


def _relabel_restrictions(F: Presheaf, v: str, old: str, new: str) -> None:
    for key, img in list(F.restrictions.items()):
        if key[1] == v and img == old:
            F.restrictions[key] = new


def random_presheaf(rng: random.Random, site: FiniteSite) -> Presheaf:
    """A presheaf on ``site`` built from a functions presheaf or a constant
    one, then perturbed: duplicated sections (locality), removed sections
    (gluing), dropped / changed restrictions (functoriality), ill-typed rows,
    and cohomology / cochain records (some wrong)."""
    roll = rng.random()
    if roll < 0.6:
        values = {p: ["0", "1"][:rng.randint(1, 2)]
                  for p in sorted(frozenset().union(*site.opens.values()))}
        F = functions_presheaf(site, values, name="F")
    elif site.empty_open is None:
        F = constant_presheaf(site, ["x", "y"][:rng.randint(0, 2)], name="F")
    else:
        empty = None if rng.random() < 0.4 else ["*"]
        F = constant_presheaf(site, ["x", "y"][:rng.randint(0 if empty is None else 1, 2)],
                              empty, name="F")
    opens = sorted(site.opens)
    if opens and rng.random() < 0.3:              # duplicate a section (locality)
        u = rng.choice(opens)
        if F.F(u):
            s = rng.choice(F.F(u))
            t = s + "'"
            F.sections[u].append(t)
            for (a, b, c), img in list(F.restrictions.items()):
                if a == u and c == s:
                    F.restrictions[(a, b, t)] = t if b == u else img
    if opens and rng.random() < 0.3:              # remove a section (gluing)
        u = rng.choice(opens)
        if len(F.F(u)) > 1:
            s = rng.choice(F.F(u))
            F.sections[u].remove(s)
            for key in [k for k in F.restrictions if k[0] == u and k[2] == s]:
                del F.restrictions[key]
            _relabel_restrictions(F, u, s, F.F(u)[0])
    if F.restrictions and rng.random() < 0.15:    # drop a restriction
        del F.restrictions[rng.choice(sorted(F.restrictions))]
    if F.restrictions and rng.random() < 0.2:     # change an image
        key = rng.choice(sorted(F.restrictions))
        F.restrictions[key] = rng.choice(F.F(key[1]) or ["?"])
    if rng.random() < 0.04:
        F.sections.setdefault(BOGUS, []).append("z")
    if F.restrictions and rng.random() < 0.04:
        key = rng.choice(sorted(F.restrictions))
        F.restrictions[key] = "not-a-section"
    covers = sorted(site.covers)
    if covers and rng.random() < 0.5:
        c = rng.choice(covers)
        cov = site.covers[c]
        n = (len(F.compatible_families(cov.covered, cov.members))
             if site.is_valid() else rng.randint(0, 2))
        F.cohomology.append(CohomologyRecord(0, c, {"cardinality": n + (rng.random() < 0.3)}))
    if rng.random() < 0.2:
        F.cohomology.append(CohomologyRecord(rng.choice([1, 2]), rng.choice(covers + [None]),
                                             {"rank": rng.randint(0, 2)}))
    if rng.random() < 0.05:
        F.cohomology.append(CohomologyRecord(rng.choice([-1, 0, 1]), None,
                                             rng.choice([{}, {"rank": -1}, {"cardinality": "x"},
                                                         {"cardinality": True}])))
    if rng.random() < 0.15:
        F.cochains.append(CochainRecord(rng.choice([0, 1, -1]) if rng.random() < 0.3 else 0,
                                        rng.choice(covers + [None])))
    return F


def hollow_triangle() -> FiniteSite:
    """Three opens with pairwise, but no triple, intersections (nerve: the
    boundary of a triangle)."""
    S = generated_topology(["p", "q", "r"], [["p", "q"], ["p", "r"], ["q", "r"]])
    S.add_cover("tri", S.base, ["U_pq", "U_pr", "U_qr"])
    return S


def register_all_covers(site: FiniteSite) -> List[str]:
    """Register every cover of every open (named ``all<i>``)."""
    names = []
    for u in sorted(site.opens):
        for members in site.all_covers(u):
            name = f"all{len(names)}"
            site.add_cover(name, u, members)
            names.append(name)
    return names


def two_point_discrete() -> FiniteSite:
    return generated_topology(["a", "b"], [["a"], ["b"]])


def subsets(xs):
    return itertools.chain.from_iterable(itertools.combinations(xs, r) for r in range(len(xs) + 1))
