"""The governance reference checks (``qbx.governance``; migration 015).

The live-database tests (``tests/live_db/test_governance_db.py``) show the
database reports the same problems; these tests pin the reference itself and
use the results of ``Formal/Modality.lean`` as oracles.
"""

from __future__ import annotations

import itertools
import random
from datetime import timedelta

from qbx.governance.approval import is_approved, token_problems, workflow_problems, workflow_roles
from qbx.governance.audit import GENESIS, audit_problems, chain_problems, record_hash
from qbx.governance.modality import SEED, modality_problems, modality_table_problems
from qbx.governance.policy import (
    accessible_from,
    assignment_problems,
    check_problems,
    computed_result,
    context_problems,
    frame_problems,
    holds,
    policy_problems,
)
from tests.governance_examples import T0, random_frame


def subsets(xs):
    xs = list(xs)
    for r in range(len(xs) + 1):
        for c in itertools.combinations(xs, r):
            yield set(c)


def box(ctx, rel, p):
    return {w for w in ctx if all(v in p for v in ctx if (w, v) in rel)}


def dia(ctx, rel, p):
    return {w for w in ctx if any(v in p for v in ctx if (w, v) in rel)}


# ---------------------------------------------------------------------------
# Modalities
# ---------------------------------------------------------------------------
def test_seed_table_is_clean_and_changes_are_reported():
    seed = [(n, k) for n, k, _, _ in SEED]
    assert modality_table_problems(seed) == []
    changed = [("□", "possibility"), ("◇", "possibility"), ("!", "obligation"), ("X", "necessity")]
    assert modality_table_problems(changed) == [
        ("modality_kind", {"name": "□", "expected": "necessity", "found": "possibility"}),
        ("modality_missing", {"name": "?"}),
        ("modality_unknown", {"name": "X"}),
    ]


def test_backings():
    assert modality_problems("necessity", None, "c") == []
    assert modality_problems("possibility", "m", None) == []
    assert modality_problems("necessity", "m", "c") == [("modality_backing", {"error": "monad"})]
    assert modality_problems("obligation", "m", "c") == [
        ("modality_backing", {"error": "monad"}), ("modality_backing", {"error": "comonad"})]
    assert modality_problems("possibility", "m", None, 2, 0) == [
        ("modality_backing_unlawful", {"structure": "monad", "violations": 2})]


# ---------------------------------------------------------------------------
# Frames (box_subset_self_iff, box_subset_box_box_iff, box_subset_dia_iff_serial)
# ---------------------------------------------------------------------------
def test_frame_examples():
    ctx = ["dev", "prod", "staging"]
    rel = {("dev", "staging"), ("staging", "prod"), ("dev", "dev")}
    assert frame_problems("alethic", ctx, rel) == [
        ("frame_reflexive", {"context": "prod"}),
        ("frame_reflexive", {"context": "staging"}),
        ("frame_transitive", {"from": "dev", "via": "staging", "to": "prod"}),
    ]
    assert frame_problems("deontic", ctx, rel) == [("frame_serial", {"context": "prod"})]
    assert accessible_from("dev", rel) == ["dev", "staging"]
    assert context_problems(" \t") == [("context_typing", {"error": "name"})]
    assert context_problems("dev") == []


def test_frame_checks_are_the_modal_axioms():
    """Lean: reflexive ⟺ ∀p □p ⊆ p; transitive ⟺ ∀p □p ⊆ □□p; and dually for
    ◇ (p ⊆ ◇p, ◇◇p ⊆ ◇p); serial ⟺ ∀p □p ⊆ ◇p.  Checked by brute force over
    every proposition on 300 random frames."""
    rng = random.Random(1512)
    for _ in range(300):
        ctx, rel = random_frame(rng)
        probs = frame_problems("alethic", ctx, rel)
        refl = not any(r == "frame_reflexive" for r, _ in probs)
        trans = not any(r == "frame_transitive" for r, _ in probs)
        props = list(subsets(ctx))
        assert refl == all(box(ctx, rel, p) <= p for p in props)
        assert refl == all(p <= dia(ctx, rel, p) for p in props)
        assert trans == all(box(ctx, rel, p) <= box(ctx, rel, box(ctx, rel, p)) for p in props)
        assert trans == all(dia(ctx, rel, dia(ctx, rel, p)) <= dia(ctx, rel, p) for p in props)
        serial = frame_problems("deontic", ctx, rel) == []
        assert serial == all(box(ctx, rel, p) <= dia(ctx, rel, p) for p in props)


# ---------------------------------------------------------------------------
# Policies and assignments
# ---------------------------------------------------------------------------
def test_policy_problems():
    assert policy_problems("p", "1.0.0", {}, "m", "personal_data", "soft") == []
    assert policy_problems(" ", "01.0.0", 42, None, "", None) == [
        ("policy_typing", {"error": e})
        for e in ("name", "version", "body", "modality", "scope", "enforcement")]
    assert policy_problems("p", "1.0.0\n", {}, "m", None, "hard") == [
        ("policy_typing", {"error": "version"})]


def test_assignment_problems():
    assert assignment_problems("□", "□", "write", None) == []
    assert assignment_problems("□", "◇", "fly", False, 2) == [
        ("assignment_modality", {"expected": "□", "found": "◇"}),
        ("assignment_typing", {"error": "scope"}),
        ("assignment_typing", {"error": "morphism"}),
        ("assignment_duplicate", {"count": 2}),
    ]


# ---------------------------------------------------------------------------
# Checks (result_eq_pass_iff, holds_dual, necessity_pass_*, obligation_pass_*)
# ---------------------------------------------------------------------------
def test_check_examples():
    acc = ["prod", "staging"]
    out = {"prod": True, "staging": False}
    assert check_problems(True, "necessity", "hard", "dev", out, "fail", acc) == []
    assert check_problems(True, "necessity", "soft", "dev", out, "pass", acc) == [
        ("check_result", {"recorded": "pass", "computed": "warn"})]
    assert check_problems(True, "possibility", "soft", "dev", out, "pass", acc) == []
    assert check_problems(True, "obligation", "hard", "dev", {"prod": True}, "pass", acc) == [
        ("check_outcome_missing", {"context": "staging"})]
    assert check_problems(False, None, None, None, {"x": 1}, "pass", None) == [
        ("check_typing", {"error": "policy"}), ("check_typing", {"error": "context"}),
        ("check_typing", {"error": "outcomes"})]
    # vacuous: no accessible context
    assert computed_result("necessity", "hard", [], {}) == "pass"
    assert computed_result("permission", "hard", [], {}) == "fail"


def test_checks_follow_the_kripke_semantics():
    """On 300 random frames, for every context and outcome set: the computed
    result is 'pass' iff the context is in □p / ◇p; ◇ = ¬□¬ and ? = ¬!¬;
    on reflexive frames a passed □ check implies the context's own outcome;
    on transitive frames a passed □ check passes at every accessible context;
    on serial frames a passed ! check passes as a ? check."""
    rng = random.Random(1513)
    for _ in range(300):
        ctx, rel = random_frame(rng)
        refl = all((c, c) in rel for c in ctx)
        trans = all((a, d) in rel for a, b in rel for c, d in rel if b == c)
        serial = all(any((c, x) in rel for x in ctx) for c in ctx)
        for p in subsets(ctx):
            out = {c: c in p for c in ctx}
            neg = {c: c not in p for c in ctx}
            for w in ctx:
                acc = accessible_from(w, rel)
                nec = holds("necessity", acc, out)
                pos = holds("possibility", acc, out)
                assert nec == (w in box(ctx, rel, p))
                assert pos == (w in dia(ctx, rel, p))
                assert pos == (not holds("necessity", acc, neg))
                assert holds("permission", acc, out) == (not holds("obligation", acc, neg))
                for lvl in ("soft", "hard", "block_and_alert"):
                    assert (computed_result("necessity", lvl, acc, out) == "pass") == nec
                if refl and nec:
                    assert out[w]
                if trans and nec:
                    assert all(holds("necessity", accessible_from(v, rel), out) for v in acc)
                if serial and holds("obligation", acc, out):
                    assert holds("permission", acc, out)


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------
def test_workflow_problems():
    steps = [{"role": "author"}, {"role": "reviewer"}]
    assert workflow_problems("w", steps, 7) == []
    assert workflow_roles("w", steps, 7) == ["author", "reviewer"]
    assert workflow_problems("", "x", -3) == [
        ("workflow_typing", {"error": "name"}), ("workflow_typing", {"error": "steps"}),
        ("workflow_typing", {"error": "timeout"})]
    assert workflow_problems("w", [{"role": "a"}, {"role": " "}, "a", {"role": "a"}], 3651) == [
        ("workflow_typing", {"error": "step", "index": 1}),
        ("workflow_typing", {"error": "step", "index": 2}),
        ("workflow_typing", {"error": "duplicate_role", "index": 3}),
        ("workflow_typing", {"error": "timeout"})]


def test_token_problems_and_status():
    roles = ["author", "reviewer"]
    a = T0
    assert token_problems(roles, 7, "art", "author", a, a + timedelta(days=7)) == []
    assert token_problems(roles, 7, "art", "author", a, a + timedelta(days=7, microseconds=1)) == [
        ("token_typing", {"error": "timeout"})]
    assert token_problems(roles, 7, None, "nobody", a, a - timedelta(days=1)) == [
        ("token_typing", {"error": "role"}), ("token_typing", {"error": "artifact"}),
        ("token_typing", {"error": "window"})]
    assert token_problems(None, 7, "art", "author", None, None) == [
        ("token_typing", {"error": e})
        for e in ("workflow", "approved_at", "expires_at")]
    later = a + timedelta(hours=1)
    assert token_problems(roles, 7, "art", "reviewer", later, later + timedelta(days=1),
                          [("author", a)]) == []
    assert token_problems(roles, 7, "art", "reviewer", a, a + timedelta(days=1),
                          [("author", later)]) == [("token_order", {"role": "author"})]
    good = [("author", a, a + timedelta(days=7)), ("reviewer", later, later + timedelta(days=1))]
    assert is_approved(roles, good, later)
    assert not is_approved(roles, good, a)                         # reviewer not yet
    assert not is_approved(roles, good, later + timedelta(days=1))  # reviewer expired
    assert not is_approved(None, good, later)


# ---------------------------------------------------------------------------
# Audit chain (chainHash_injective)
# ---------------------------------------------------------------------------
def _chain(rows):
    out, prev = [], GENESIS
    for i, (actor, action, details) in enumerate(rows, start=1):
        ts = T0 + timedelta(seconds=i)
        h = record_hash(prev, i, actor, action, None, None, details, None, ts)
        out.append((i, prev, h, actor, action, None, None, details, None, ts))
        prev = h
    return out


def test_chain_detects_every_tampering():
    recs = _chain([("alice", "create", "{}"), ("bob", "approve", '{"x": 1}'),
                   ("carol", "deploy", "{}")])
    assert chain_problems(recs) == []
    edited = list(recs)
    edited[1] = edited[1][:3] + ("mallory",) + edited[1][4:]
    assert chain_problems(edited) == [(1, ("audit_chain", {"error": "hash", "seq": 2}))]
    deleted = [recs[0], recs[2]]
    assert chain_problems(deleted) == [
        (1, ("audit_chain", {"error": "gap", "seq": 3, "expected": 2})),
        (1, ("audit_chain", {"error": "link", "seq": 3}))]
    assert audit_problems("a", "b", {}) == []
    assert audit_problems(" ", "", None) == [
        ("audit_typing", {"error": "actor"}), ("audit_typing", {"error": "action"}),
        ("audit_typing", {"error": "details"})]


def test_field_encoding_is_a_prefix_code():
    """Shifting text between fields changes the hash (the payload determines
    the fields), and NULL differs from the empty text."""
    h = lambda *f: record_hash(GENESIS, 1, *f, None, None, "{}", None, T0)
    assert h("ab", "c") != h("a", "bc")
    assert h("a:b", "c") != h("a", "b:c")
    assert record_hash(GENESIS, 1, "a", "b", None, None, None, None, T0) != \
        record_hash(GENESIS, 1, "a", "b", None, None, "", None, T0)
