"""Shared subobject-classifier examples for ``tests/test_topos.py`` and
``tests/live_db/test_topos_db.py``."""

from __future__ import annotations

import random
from typing import Dict, List, Tuple

from qbx.categorical.topos import Subobject, SubobjectClassifier, _new_category


def injective(name: str) -> bool:
    """Is the finite-set function named ``s<a>s<b>_<values>`` (or ``id_s<n>``) injective?"""
    if name.startswith("id_"):
        return True
    values = name.split("_", 1)[1]
    return len(set(values)) == len(values)


def surjective(name: str) -> bool:
    if name.startswith("id_"):
        return True
    head, values = name.split("_", 1)
    b = int(head.split("s")[2])
    return set(values) == {str(i) for i in range(b)}


def random_classifier(rng: random.Random) -> SubobjectClassifier:
    """A random recording: a small category with a partial (not necessarily
    associative) composition table, a candidate terminal object with maps
    ``b_<o>`` into it, a candidate ``truth`` and some subobjects,
    characteristic morphisms and truth values — with some bad rows (truth not
    ending at Ω or missing, extra maps into 1, subobjects over the wrong object,
    ill-typed χ and truth values)."""
    objs = [f"o{i}" for i in range(rng.randint(2, 4))]
    cat = _new_category("C", objs)
    one = objs[0]
    morphisms: Dict[str, Tuple[str, str]] = {}
    for i in range(rng.randint(2, 7)):
        morphisms[f"m{i}"] = (rng.choice(objs), rng.choice(objs[1:] if rng.random() < 0.8 else objs))
    if rng.random() < 0.8:
        for o in objs[1:]:
            if not any(st == (o, one) for st in morphisms.values()) or rng.random() < 0.05:
                morphisms[f"b_{o}"] = (o, one)
    for m, (s, t) in morphisms.items():
        cat.add_morphism(m, s, t)
    every = dict(cat.morphisms)
    for f, (fs, ft) in every.items():
        for g, (gs, gt) in every.items():
            if ft != gs or f.startswith("id_") or g.startswith("id_") or rng.random() > 0.7:
                continue
            cand = [h for h, st in every.items() if st == (fs, gt)]
            if cand:
                cat.add_composition(f, g, rng.choice(cand))
    from_one = [m for m, (s, _) in morphisms.items() if s == one]
    truth = rng.choice(from_one) if from_one else None
    omega = cat.morphisms[truth][1] if truth else rng.choice(objs)
    if rng.random() < 0.08:
        omega = rng.choice(objs)
    if rng.random() < 0.04:
        truth = None
    cls = SubobjectClassifier(cat, omega, truth)
    names: List[str] = list(cat.morphisms)
    for m in rng.sample(names, k=min(len(names), rng.randint(0, 3))):
        target = cat.morphisms[m][1]
        if rng.random() < 0.1:
            target = rng.choice(objs)
        cls.subobjects.append(Subobject(m, target))
        if rng.random() < 0.7:
            cands = [c for c, st in cat.morphisms.items() if st == (target, omega)]
            if cands and rng.random() < 0.85:
                cls.characteristics[m] = rng.choice(cands)
            else:
                cls.characteristics[m] = rng.choice(names)
    for i in range(rng.randint(0, 2)):
        cands = [c for c, st in cat.morphisms.items() if st == (one, omega)]
        cls.truth_values[f"tv{i}"] = (rng.choice(cands) if cands and rng.random() < 0.7
                                      else rng.choice(names))
    return cls
