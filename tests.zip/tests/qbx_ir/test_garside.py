"""Garside normal form: exact word problem."""

import random

from qbx_ir import Braid
from qbx_ir.algebra.garside import (
    braid_group_equal,
    is_trivial,
    left_normal_form,
    simple_word,
)
from qbx_ir.algebra.polynomial_invariants import burau_matrix

B = Braid.from_short_form


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def random_relation_move(rng, n, word):
    """Insert a defining relation (or a cancelling pair) at a random position."""
    i = rng.randint(1, n - 1)
    pos = rng.randint(0, len(word))
    choice = rng.randint(0, 2)
    if choice == 0:
        ins = [i, -i] if rng.random() < 0.5 else [-i, i]
    elif choice == 1 and i + 1 < n:
        ins = [i, i + 1, i, -(i + 1), -i, -(i + 1)]
    else:
        j = rng.randint(1, n - 1)
        ins = [i, j, -i, -j] if abs(i - j) >= 2 else [i, -i]
    return word[:pos] + ins + word[pos:]


def test_braid_relation_and_noncommutation():
    assert braid_group_equal(B(3, [1, 2, 1]), B(3, [2, 1, 2]))
    assert braid_group_equal(B(4, [1, 3]), B(4, [3, 1]))
    assert not braid_group_equal(B(3, [1, 2]), B(3, [2, 1]))
    assert not braid_group_equal(B(3, [1]), B(3, [2]))


def test_delta_properties():
    for n in range(2, 7):
        d = Braid.half_twist(n)
        assert left_normal_form(d).power == 1 and not left_normal_form(d).factors
        full = Braid.full_twist(n)
        for i in range(1, n):
            s = B(n, [i])
            assert braid_group_equal(full * s, s * full)  # Δ² is central
            assert braid_group_equal(d * s * d.inverse(), B(n, [n - i]))


def test_inverse_and_relations_random():
    rng = random.Random(11)
    for _ in range(300):
        n = rng.randint(2, 6)
        w = random_word(rng, n, rng.randint(0, 12))
        b = B(n, w)
        assert is_trivial(b * b.inverse())
        w2 = w
        for _ in range(3):
            w2 = random_relation_move(rng, n, w2)
        assert braid_group_equal(b, B(n, w2))
        nf = left_normal_form(b)
        assert left_normal_form(nf.to_braid()) == nf


def test_simple_words_are_positive_permutation_braids():
    assert simple_word((1, 0, 2)) == [1]
    assert sorted(simple_word((2, 1, 0))) == [1, 1, 2]


def test_agrees_with_burau_on_three_strands():
    # The Burau representation is faithful on B_3, so equality must match exactly.
    rng = random.Random(5)
    for _ in range(150):
        b1 = B(3, random_word(rng, 3, rng.randint(0, 8)))
        b2 = B(3, random_word(rng, 3, rng.randint(0, 8)))
        if rng.random() < 0.3:
            b2 = B(3, random_relation_move(rng, 3, b1.short_form()))
        assert braid_group_equal(b1, b2) == (burau_matrix(b1) == burau_matrix(b2))


def test_equal_implies_equal_burau_on_more_strands():
    rng = random.Random(9)
    for _ in range(100):
        n = rng.randint(4, 5)
        w = random_word(rng, n, rng.randint(0, 8))
        w2 = random_relation_move(rng, n, random_relation_move(rng, n, w))
        assert braid_group_equal(B(n, w), B(n, w2))
        assert burau_matrix(B(n, w)) == burau_matrix(B(n, w2))
