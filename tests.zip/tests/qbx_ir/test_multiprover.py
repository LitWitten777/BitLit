"""
Tests of the five-channel resonance machine against the Lean theorems of
``QBX/Formal/MultiProver`` (each test names its oracle).
"""

import cmath
import math
import random

import numpy as np
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.multiprover import (
    CHANNELS,
    burau_at,
    defect,
    harmonic_resonant,
    heal,
    quantum_dim,
    verdict,
)


def B(*word, n=3):
    return Braid.from_short_form(n, list(word))


def random_word(rng, n, length):
    return [rng.choice([i for i in range(-(n - 1), n) if i != 0]) for _ in range(length)]


# ---- Machine.lean ---------------------------------------------------------


def test_verdict_proved_on_yang_baxter():
    """verdict_eq_proved_iff / resonance_iff: equal braids resonate in all channels."""
    cert = verdict(B(1, 2, 1), B(2, 1, 2))
    assert cert.verdict == "PROVED"
    assert cert.agree == CHANNELS and cert.disagree == ()


def test_sq_sq_partial():
    """sq_sq_partial: σ₁² vs σ₂² — link, harmonic, oscillator agree; fold, anchor refute."""
    cert = verdict(B(1, 1), B(2, 2))
    assert cert.verdict == "REFUTED"
    assert set(cert.agree) == {"link", "harmonic", "oscillator"}
    assert set(cert.disagree) == {"fold", "anchor"}
    assert cert.partial_resonance


def test_blind_partial():
    """blind_partial: σ₁²σ₂⁻²σ₁⁻²σ₂² vs 1 — the link channel agrees, fold refutes."""
    cert = verdict(B(1, 1, -2, -2, -1, -1, 2, 2), B())
    assert cert.verdict == "REFUTED"
    assert "link" in cert.agree and "fold" in cert.disagree


@pytest.mark.parametrize("k", [1, 2, 3, 4, 7])
def test_sigma_pow_harmonic_silent(k):
    """sigma_pow_harmonic_silent: σ₁^k resonates everywhere, like the identity."""
    cert = verdict(B(*([1] * k)), B())
    assert "harmonic" in cert.agree and "fold" in cert.disagree


def test_hidden_harmonic_refutes():
    """hidden_harmonic_refutes: at θ = π, σ₁²σ₂⁻² has trace 6 and does not resonate."""
    hidden = B(1, 1, -2, -2)
    m = burau_at(hidden, math.pi)
    assert np.allclose(m, [[5, 2], [2, 1]])
    assert not harmonic_resonant(hidden, math.pi)
    assert harmonic_resonant(B(), math.pi)
    assert "harmonic" in verdict(hidden, B()).disagree


def test_never_contradicts():
    """verdict_ne_proved_of_disagree: no channel disagrees on a PROVED claim."""
    rng = random.Random(7)
    for _ in range(40):
        w = random_word(rng, 3, 6)
        # Insert a cancelling pair and commute nothing: same braid, different word.
        i = rng.randrange(len(w) + 1)
        g = rng.choice([1, 2, -1, -2])
        w2 = w[:i] + [g, -g] + w[i:]
        cert = verdict(B(*w), B(*w2))
        assert cert.verdict == "PROVED" and cert.disagree == ()


def test_heal():
    """heal / defect_eq_one_iff."""
    rng = random.Random(3)
    for _ in range(20):
        b1, b2 = B(*random_word(rng, 3, 5)), B(*random_word(rng, 3, 5))
        assert braid_group_equal(heal(b1, b2), b1)
        assert braid_group_equal(defect(b1, b2), B()) == braid_group_equal(b1, b2)


# ---- HarmonicSweep.lean ---------------------------------------------------


def test_resonance_criterion_and_partner():
    """resonance_iff_trace and norm_mul_partner on random 3-braids."""
    rng = random.Random(11)
    for _ in range(60):
        b = B(*random_word(rng, 3, rng.randrange(1, 9)))
        theta = rng.uniform(0, 2 * math.pi)
        m = burau_at(b, theta)
        ev = np.linalg.eigvals(m)
        assert abs(abs(ev[0]) * abs(ev[1]) - 1) < 1e-8
        on_circle = abs(abs(ev[0]) - 1) < 1e-6
        if abs(abs(np.trace(m)) - 2) > 1e-6:
            assert on_circle == (abs(np.trace(m)) < 2)
        # det · conj(tr) = tr (det_mul_conj_trace)
        assert abs(np.linalg.det(m) * np.conj(np.trace(m)) - np.trace(m)) < 1e-8


def test_resonance_universal():
    """resonance_universal: cos θ > -1/2 ⇒ every eigenvalue is on the unit circle."""
    rng = random.Random(5)
    for _ in range(60):
        b = B(*random_word(rng, 3, rng.randrange(1, 12)))
        theta = rng.uniform(-2 * math.pi / 3 + 1e-3, 2 * math.pi / 3 - 1e-3)
        ev = np.linalg.eigvals(burau_at(b, theta))
        assert np.allclose(np.abs(ev), 1, atol=1e-7)


# ---- TorusAnchor.lean -----------------------------------------------------


def test_det_burau_circle():
    """det_burau_circle: det ρ̄(β)(e^{iθ}) = (-1)^len e^{i·writhe·θ}, any strand count."""
    rng = random.Random(2)
    for n in (2, 3, 4, 5):
        for _ in range(10):
            w = random_word(rng, n, rng.randrange(0, 8))
            theta = rng.uniform(0, 2 * math.pi)
            d = np.linalg.det(burau_at(B(*w, n=n), theta)) if n > 1 else 1
            writhe = sum(1 if x > 0 else -1 for x in w)
            assert abs(d - (-1) ** len(w) * cmath.exp(1j * writhe * theta)) < 1e-8


# ---- OscillatorChannel.lean -----------------------------------------------


@pytest.mark.parametrize("r", [3, 4, 5, 6, 7, 10])
def test_quantum_dims(r):
    """quantumDim_self, quantumDim_pos, quantumDim_rec, quantumDim_symm."""
    assert abs(quantum_dim(r, r)) < 1e-12
    for k in range(1, r):
        assert quantum_dim(r, k) > 0
        assert abs(quantum_dim(r, r - k) - quantum_dim(r, k)) < 1e-12
    for k in range(0, r):
        lhs = quantum_dim(r, k + 2)
        rhs = quantum_dim(r, 2) * quantum_dim(r, k + 1) - quantum_dim(r, k)
        assert abs(lhs - rhs) < 1e-12


def test_fibonacci_and_ising():
    """quantumDim_fib, fib_fusion, quantumDim_ising."""
    phi = (1 + math.sqrt(5)) / 2
    assert abs(quantum_dim(5, 2) - phi) < 1e-12
    assert abs(quantum_dim(5, 2) ** 2 - (1 + quantum_dim(5, 2))) < 1e-12
    assert abs(quantum_dim(4, 2) - math.sqrt(2)) < 1e-12


# ---- Scheduler.lean -------------------------------------------------------


def test_scheduled_reading_matches_direct():
    """schedule_correct: chunked map–reduce gives the direct perm / writhe / Burau readings."""
    from qbx_ir.algebra.invariants import writhe
    from qbx_ir.algebra.multiprover import (
        anchor_reading,
        scheduled_anchor_reading,
        scheduled_reading,
    )
    from qbx_ir.algebra.invariants import permutation

    rng = random.Random(2026)
    for n in (2, 3, 4):
        for length in (0, 1, 7, 30):
            b = B(*random_word(rng, n, length), n=n)
            for chunk_size in (1, 2, 5, 64):
                s = scheduled_reading(b, chunk_size)
                assert s.perm == tuple(permutation(b))
                assert s.writhe == writhe(b)
                assert scheduled_anchor_reading(b, chunk_size) == anchor_reading(b)


def test_merge_readings_any_bracketing():
    """ReduceTree.eval_eq_prod: every bracketing of the chunk summaries agrees."""
    from qbx_ir.algebra.multiprover import chunk_reading, merge_readings

    rng = random.Random(7)
    b = B(*random_word(rng, 3, 12), n=3)
    w = b.word
    x, y, z = (chunk_reading(3, w[:4]), chunk_reading(3, w[4:9]), chunk_reading(3, w[9:]))
    left = merge_readings(merge_readings(x, y), z)
    right = merge_readings(x, merge_readings(y, z))
    assert left.perm == right.perm and left.writhe == right.writhe
    assert [[e.to_int_dict() for e in r] for r in left.burau] == \
        [[e.to_int_dict() for e in r] for r in right.burau]
