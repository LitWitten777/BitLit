"""Rewrite rules R01–R03, provenance and the terminating reduction."""

import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.rewriting import (
    ALL_RULES,
    FAR_COMMUTATION,
    INVERSE_CANCELLATION,
    YANG_BAXTER,
    apply_rule,
    audit_transformation,
    braid_hash,
    find_matches,
    insert_cancelling_pair,
    normal_form,
    normal_form_with_trace,
    yang_baxter_pair,
)

B = Braid.from_short_form


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def test_rules_apply():
    out, t = apply_rule(B(3, [2, 1, -1, 2]), INVERSE_CANCELLATION, 1)
    assert out.short_form() == [2, 2]
    assert t.rule_id == "R01" and t.input_hash != t.output_hash
    out, _ = apply_rule(B(4, [1, 3]), FAR_COMMUTATION, 0)
    assert out.short_form() == [3, 1]
    out, _ = apply_rule(B(3, [1, 2, 1]), YANG_BAXTER, 0)
    assert out.short_form() == [2, 1, 2]
    out, _ = apply_rule(B(3, [-2, -1, -2]), YANG_BAXTER, 0)
    assert out.short_form() == [-1, -2, -1]
    with pytest.raises(ValueError):
        apply_rule(B(3, [1, 2]), FAR_COMMUTATION, 0)


def test_mixed_sign_triple_is_not_r03():
    assert find_matches(B(3, [1, 2, -1]), YANG_BAXTER) == []


def test_provenance_hashes_are_canonical():
    assert braid_hash(B(3, [1, 2])) == braid_hash(B(3, [1, 2], name="other"))
    assert braid_hash(B(3, [1, 2])) != braid_hash(B(4, [1, 2]))


def test_every_rewrite_preserves_declared_properties():
    rng = random.Random(7)
    for _ in range(200):
        n = rng.randint(3, 6)
        b = B(n, random_word(rng, n, rng.randint(2, 10)))
        for rule in ALL_RULES:
            for pos in find_matches(b, rule):
                out, t = apply_rule(b, rule, pos)
                audit = audit_transformation(b, out, rule)
                assert all(audit.values()), (b, rule.name, pos, audit)
                assert set(audit) == set(t.preserved_properties)


def test_normal_form_terminates_on_commuting_words():
    # Regression: the 0.1 engine swapped σ1σ3 ↔ σ3σ1 forever.
    nf = normal_form(B(5, [3, 1, 4, 1, 3, 2]))
    assert nf.short_form() == [1, 1, 3, 4, 3, 2]
    assert normal_form(B(4, [3, 1])).short_form() == [1, 3]
    assert normal_form(B(4, [1, 3])).short_form() == [1, 3]


def test_normal_form_cancels_and_preserves_element():
    assert normal_form(B(2, [1, -1])).short_form() == []
    rng = random.Random(3)
    for _ in range(200):
        n = rng.randint(2, 6)
        b = B(n, random_word(rng, n, rng.randint(0, 14)))
        nf, trace = normal_form_with_trace(b)
        assert braid_group_equal(b, nf)
        assert len(nf) <= len(b)
        assert normal_form(nf).short_form() == nf.short_form()  # fixed point
        if trace:
            assert trace[0].input_hash == braid_hash(b)
            assert trace[-1].output_hash == braid_hash(nf)


def test_insert_cancelling_pair_is_inverse_of_r01():
    b = B(3, [1, 2])
    c = insert_cancelling_pair(b, 1, 2, -1)
    assert c.short_form() == [1, -2, 2, 2]
    assert braid_group_equal(b, c)


def test_yang_baxter_pair():
    lhs, rhs = yang_baxter_pair(4, 2)
    assert lhs.short_form() == [2, 3, 2] and rhs.short_form() == [3, 2, 3]
    with pytest.raises(ValueError):
        yang_baxter_pair(3, 2)
