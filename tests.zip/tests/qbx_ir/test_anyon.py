"""Anyon layer: Fibonacci and Ising braid representations."""

import numpy as np
import pytest

from qbx_ir import Braid
from qbx_ir.anyon import (
    anyon_representation,
    fibonacci_model,
    fusion_space,
    generator_matrix,
    ising_model,
)

B = Braid.from_short_form
MODELS = [(fibonacci_model(), "τ"), (ising_model(), "σ")]


@pytest.mark.parametrize("model,a", MODELS)
@pytest.mark.parametrize("n", [3, 4, 5])
def test_braid_relations_and_unitarity(model, a, n):
    sp = fusion_space(model, a, n)
    for i in range(1, n):
        g = generator_matrix(model, sp, i)
        assert np.allclose(g.conj().T @ g, np.eye(sp.dim))
        assert np.allclose(anyon_representation(B(n, [i, -i]), model, a), np.eye(sp.dim))
        if i + 1 < n:
            assert np.allclose(anyon_representation(B(n, [i, i + 1, i]), model, a),
                               anyon_representation(B(n, [i + 1, i, i + 1]), model, a))
        for j in range(i + 2, n):
            assert np.allclose(anyon_representation(B(n, [i, j]), model, a),
                               anyon_representation(B(n, [j, i]), model, a))


def test_fusion_space_dimensions():
    fib = fibonacci_model()
    assert [fusion_space(fib, "τ", n).dim for n in range(1, 8)] == [1, 2, 3, 5, 8, 13, 21]
    ising = ising_model()
    assert [fusion_space(ising, "σ", n).dim for n in range(1, 7)] == [1, 2, 2, 4, 4, 8]


def test_f_matrices_unitary():
    for model, _ in MODELS:
        assert model.f_unitarity_residual() < 1e-12


def test_total_charge_is_conserved():
    fib = fibonacci_model()
    U = anyon_representation(B(4, [1, 2, -3, 2]), fib, "τ")
    basis = fusion_space(fib, "τ", 4).basis
    for r, br in enumerate(basis):
        for c, bc in enumerate(basis):
            if br[-1] != bc[-1]:
                assert abs(U[r, c]) < 1e-12


def test_fibonacci_sigma_eigenvalues_are_r_symbols():
    fib = fibonacci_model()
    eig = np.linalg.eigvals(generator_matrix(fib, fusion_space(fib, "τ", 3), 2))
    r1, rt = fib.r_symbols[("τ", "τ", "1")], fib.r_symbols[("τ", "τ", "τ")]
    for z in eig:
        assert min(abs(z - r1), abs(z - rt)) < 1e-9
