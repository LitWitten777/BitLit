"""Model check of the SQL algorithm of migration 023 (``braid_jones_values``).

No PostgreSQL server is needed: the functions ``braid_jones_cup``,
``braid_jones_loops``, ``braid_jones_binom`` and ``braid_jones_values`` of
``migrations/023_braid_jones.sql`` are transcribed statement by statement
below (1-based array indexing, text matching keys, the per-letter
``GROUP BY (key, exponent) HAVING sum <> 0`` merge, the closed-form
``d^(L-1)`` expansion, the window extraction and the Jones sign), and compared
with the reference ``qbx_ir.jones_ledger.jones_values``.

This checks the *algorithm* of the migration, not its SQL syntax or its
execution by PostgreSQL; ``tests/test_migrations_parse.py`` and
``tests/live_db/test_braid_jones_db.py`` do that where PostgreSQL is available.
"""

from __future__ import annotations

import random
import re
from collections import defaultdict
from pathlib import Path

from qbx_ir.jones_ledger import jones_values

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "023_braid_jones.sql"


# --- transcription of migrations/023_braid_jones.sql --------------------------

def sql_cup(p_key: str, p_n: int, p_i: int):
    m = [int(x) for x in p_key.split(",")]          # string_to_array(p_key, ',')::int[]
    get = lambda idx: m[idx - 1]                    # 1-based m[idx]

    def put(idx, val):
        m[idx - 1] = val

    bi = p_n + p_i
    bj = p_n + p_i + 1
    x = get(bi + 1)
    y = get(bj + 1)
    if x == bj:
        closed = True
    else:
        closed = False
        put(x + 1, y)
        put(y + 1, x)
    put(bi + 1, bj)
    put(bj + 1, bi)
    return ",".join(map(str, m)), closed


def sql_loops(p_key: str, p_n: int) -> int:
    m = [int(x) for x in p_key.split(",")]
    seen = [False] * (2 * p_n)
    loops = 0
    for st in range(0, 2 * p_n):
        if seen[st]:
            continue
        loops += 1
        p = st
        while not seen[p]:
            seen[p] = True
            q = m[p]
            seen[q] = True
            p = q - p_n if q >= p_n else q + p_n
    return loops


def sql_binom(p_n: int, p_k: int) -> int:
    r = 1
    for j in range(1, p_k + 1):
        num = r * (p_n - p_k + j)
        assert num % j == 0          # div() is exact here
        r = num // j
    return r


def sql_values(p_n: int, p_word):
    length = len(p_word)
    rows = [(",".join(str(j + p_n if j < p_n else j - p_n) for j in range(2 * p_n)), 0, 1)]
    w = 0
    for k in range(1, length + 1):
        g = p_word[k - 1]
        gi = abs(g) - 1
        if g > 0:
            a_id, a_cup, w = 1, -1, w + 1
        else:
            a_id, a_cup, w = -1, 1, w - 1
        union = [(key, e + a_id, c) for key, e, c in rows]
        for key, e, c in rows:
            key2, closed = sql_cup(key, p_n, gi)
            for sh, f, cl in ((0, 1, False), (2, -1, True), (-2, -1, True)):
                if cl == closed:
                    union.append((key2, e + a_cup + sh, c * f))
        acc = defaultdict(int)
        for key, e, c in union:
            acc[(key, e)] += c
        rows = sorted((key, e, c) for (key, e), c in acc.items() if c != 0)
    acc = defaultdict(int)
    for key, e, c in rows:
        n_loops = sql_loops(key, p_n)
        sign = 1 if (n_loops - 1) % 2 == 0 else -1
        for i in range(0, n_loops):
            acc[e + 2 * (n_loops - 1) - 4 * i] += c * sign * sql_binom(n_loops - 1, i)
    final = sorted((e, c) for e, c in acc.items() if c != 0)
    if not final:
        return (0, 0, (), 0, 0, ())
    es = [e for e, _ in final]
    cs = dict(final)
    lo, hi = es[0], es[-1]
    bracket = tuple(cs.get(x, 0) for x in range(lo, hi + 1))
    sgn = 1 if w % 2 == 0 else -1    # Python's % agrees with PostgreSQL's on "= 0"
    return (lo, hi - lo + 1, bracket, lo - 3 * w, hi - lo + 1, tuple(sgn * x for x in bracket))


def reference(n, word):
    v = jones_values(n, word)
    return (v.bracket_exp_min, v.bracket_width, v.bracket_coefficients,
            v.jones_exp_min, v.jones_width, v.jones_coefficients)


# --- tests --------------------------------------------------------------------

def test_known_values():
    # unknot, Hopf link, trefoil, figure-eight
    for n, word in [(1, []), (2, [1]), (2, [1, 1]), (2, [1, 1, 1]), (3, [1, -2, 1, -2]),
                    (3, []), (4, [1, 2, 3])]:
        assert sql_values(n, word) == reference(n, word), (n, word)


def test_random_words_agree_with_reference():
    rng = random.Random(23)
    for _ in range(300):
        n = rng.randint(1, 6)
        length = 0 if n == 1 else rng.randint(0, 12)
        word = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]
        assert sql_values(n, word) == reference(n, word), (n, word)


def test_binom():
    from math import comb
    for n in range(0, 15):
        for k in range(0, n + 1):
            assert sql_binom(n, k) == comb(n, k)


def test_migration_defines_the_transcribed_functions():
    sql = MIGRATION.read_text()
    for name in ("braid_jones_cup", "braid_jones_loops", "braid_jones_binom",
                 "braid_jones_values", "braid_jones_problems", "braid_bracket_equal",
                 "braid_jones_equal", "check_braid_jones", "certify_braid_jones",
                 "run_phase3_batch_checks"):
        assert re.search(rf"CREATE OR REPLACE FUNCTION {name}\(", sql), name
    # the same strand limit as the reference
    from qbx_ir.jones_ledger import MAX_JONES_STRANDS
    m = re.search(r"FUNCTION braid_jones_max_strands\(\) RETURNS INT AS \$\$\s*SELECT (\d+)", sql)
    assert m and int(m.group(1)) == MAX_JONES_STRANDS
