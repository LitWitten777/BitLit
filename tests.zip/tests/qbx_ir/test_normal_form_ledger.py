"""Reference checks of the normal-form certificates (``qbx_ir.normal_form_ledger``)."""

from __future__ import annotations

import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.invariant_ledger import CertRow
from qbx_ir.ledger import RULES, BraidRow, apply_short
from qbx_ir.normal_form_ledger import (
    NFRow,
    certificate_problems,
    equality_certified,
    invariant_consistency_problems,
    normal_form_values,
    normal_forms_equal,
    transport_problems,
)

# Test vectors shared with the Lean check ``leftNormalForm_agrees_with_python``
# (QBX/Formal/BraidNormalForm.lean, ``pythonVectors``).
LEAN_VECTORS = [
    (1, [], 0, [], []),
    (2, [1, 1, -1], 1, [], [1]),
    (3, [1, 2, 1], 1, [], [1, 2, 1]),
    (3, [1, 2, 1, -2, -1, -2], 0, [], []),
    (3, [-1], -1, [[2, 0, 1]], [-1, -2, -1, 1, 2]),
    (3, [1, 1, -2, -2], -2, [[1, 0, 2], [1, 0, 2], [2, 0, 1], [1, 2, 0]],
     [-1, -2, -1, -1, -2, -1, 1, 1, 1, 2, 2, 1]),
    (3, [1, 2, 1, 1, 2, 1], 2, [], [1, 2, 1, 1, 2, 1]),
    (4, [1, 2, -3, 1, -1, 2, 3, 3, -2], -2,
     [[2, 1, 0, 3], [3, 2, 0, 1], [2, 3, 0, 1], [0, 2, 1, 3], [0, 3, 1, 2]],
     [-1, -2, -3, -1, -2, -1, -1, -2, -3, -1, -2, -1, 1, 2, 1, 1, 2, 1, 3, 2, 2, 1, 3, 2, 2, 2, 3]),
    (4, [2, 1, 3, 2], 0, [[2, 3, 0, 1]], [2, 1, 3, 2]),
    (5, [-1, -2, 3, 4, -4, 1, 2, 2, 3, -1, 4], -2,
     [[2, 4, 3, 1, 0], [4, 2, 1, 3, 0], [1, 3, 0, 2, 4], [4, 0, 1, 2, 3]],
     [-1, -2, -3, -4, -1, -2, -3, -1, -2, -1, -1, -2, -3, -4, -1, -2, -3, -1, -2, -1, 2, 3, 2, 1,
      4, 3, 2, 1, 1, 2, 1, 3, 4, 3, 2, 1, 2, 1, 3, 1, 2, 3, 4]),
]


@pytest.mark.parametrize("n, word, power, factors, normal_word", LEAN_VECTORS)
def test_lean_vectors(n, word, power, factors, normal_word):
    v = normal_form_values(n, word)
    assert v.power == power
    assert [list(f) for f in v.factors] == factors
    assert list(v.normal_word) == normal_word


def test_normal_word_is_the_same_braid_and_its_own_normal_form():
    rng = random.Random(11)
    for _ in range(200):
        n = rng.randint(1, 5)
        w = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 9))] if n > 1 else []
        v = normal_form_values(n, w)
        assert braid_group_equal(Braid.from_short_form(n, w), Braid.from_short_form(n, list(v.normal_word)))
        again = normal_form_values(n, list(v.normal_word))
        assert (again.power, again.factors) == (v.power, v.factors)


def test_certificate_problems():
    b = BraidRow.of(3, [1, 2, 1])
    good = NFRow.of(b)
    assert (good.power, good.factors, good.normal_word) == (1, (), (1, 2, 1))
    assert certificate_problems(good) == []
    bad = NFRow(b, "x", 0, ((2, 1, 0),), (1,))
    assert [r for r, _ in certificate_problems(bad)] == [
        "braid_hash_mismatch", "power_mismatch", "factors_mismatch", "normal_word_mismatch"]
    assert certificate_problems(bad)[2] == (
        "factors_mismatch", {"recorded": [[2, 1, 0]], "expected": []})
    broken = BraidRow(3, (1, 5), "h")
    assert certificate_problems(NFRow(broken, "h", 0, (), ())) == [("braid_not_well_formed", {})]
    with pytest.raises(ValueError):
        NFRow.of(broken)
    assert normal_forms_equal(good, NFRow(broken, "h", 0, (), ())) is None
    assert normal_forms_equal(good, NFRow.of(BraidRow.of(4, [1, 2, 1]))) is None


def test_equality_answers():
    a = NFRow.of(BraidRow.of(3, [1, 2, 1]))
    b = NFRow.of(BraidRow.of(3, [2, 1, 2]))
    c = NFRow.of(BraidRow.of(3, [1]))
    assert normal_forms_equal(a, b) is True and equality_certified(a, b)
    assert normal_forms_equal(a, c) is False and not equality_certified(a, c)
    assert transport_problems(True, a, c) == [("normal_form_not_preserved", {})]
    assert transport_problems(False, a, c) == []
    assert transport_problems(True, a, b) == []
    assert equality_certified(None, a) is False


def test_normal_forms_agree_along_rewrites_and_decide_equality():
    rng = random.Random(13)
    for _ in range(300):
        n = rng.randint(2, 5)
        w = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 7))]
        c = NFRow.of(BraidRow.of(n, w))
        for rule in RULES:
            for k in range(len(w)):
                out = apply_short(w, rule, k)
                if out is not None:
                    assert normal_forms_equal(c, NFRow.of(BraidRow.of(n, out))) is True
        v = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 7))]
        d = NFRow.of(BraidRow.of(n, v))
        assert normal_forms_equal(c, d) == braid_group_equal(Braid.from_short_form(n, w),
                                                             Braid.from_short_form(n, v))


def test_invariant_consistency():
    x, e = BraidRow.of(3, [1, -1]), BraidRow.of(3, [])
    nx, ne = NFRow.of(x), NFRow.of(e)
    ix, ie = CertRow.of(x), CertRow.of(e)
    others = [(nx, ix), (ne, ie)]
    assert invariant_consistency_problems(nx, ix, others) == []
    # A "valid-looking" but different invariant certificate cannot occur on a sound ledger;
    # simulate one by pairing x's normal form with the certificate of another braid.
    y = BraidRow.of(3, [1, 1])
    iy = CertRow.of(y)
    assert invariant_consistency_problems(nx, iy, others) == [
        ("invariants_contradict_normal_form",
         {"other_braid_hash": e.braid_hash, "invariants": ["writhe", "linking"]})]
