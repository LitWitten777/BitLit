"""Core IR: construction, validation and word operations."""

import pytest

from qbx_ir import Braid, Generator, Strand


def test_from_short_form_roundtrip():
    b = Braid.from_short_form(4, [1, -2, 3, 2])
    assert b.short_form() == [1, -2, 3, 2]
    assert len(b) == 4
    assert str(b.word[1]) == "σ_2⁻¹"


def test_validation():
    with pytest.raises(ValueError):
        Braid.from_short_form(3, [3])  # σ_3 needs 4 strands
    with pytest.raises(ValueError):
        Braid.from_short_form(0, [])
    with pytest.raises(ValueError):
        Generator.from_short(0)
    with pytest.raises(ValueError):
        Strand(id=0)


def test_compose_inverse_power():
    a = Braid.from_short_form(3, [1, 2])
    b = Braid.from_short_form(3, [-1])
    assert (a * b).short_form() == [1, 2, -1]
    assert a.inverse().short_form() == [-2, -1]
    assert a.power(2).short_form() == [1, 2, 1, 2]
    assert a.power(-1).short_form() == [-2, -1]
    assert a.power(0).short_form() == []
    with pytest.raises(ValueError):
        a.compose(Braid.identity(4))


def test_tensor_mirror_reverse_stabilize():
    a = Braid.from_short_form(2, [1])
    b = Braid.from_short_form(3, [2, -1])
    t = a.tensor(b)
    assert t.strand_count == 5 and t.short_form() == [1, 4, -3]
    assert b.mirror().short_form() == [-2, 1]
    assert b.reverse_strands().short_form() == [1, -2]
    assert a.stabilize().strand_count == 3 and a.stabilize().short_form() == [1, 2]


def test_half_twist_word():
    assert Braid.half_twist(3).short_form() == [1, 2, 1]
    assert len(Braid.half_twist(5)) == 10


def test_crossings_track_strands():
    b = Braid.from_short_form(3, [1, 2])
    cs = b.crossings()
    assert [(c.left_strand_id, c.right_strand_id) for c in cs] == [(1, 2), (1, 3)]


def test_qbx_dict_roundtrip():
    b = Braid.from_short_form(3, [1, -2], name="X")
    b2 = Braid.from_qbx_dict(b.to_qbx_dict())
    assert b2.short_form() == b.short_form() and b2.name == "X"
