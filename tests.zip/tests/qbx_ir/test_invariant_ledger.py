"""Reference checks of the braid invariant certificates (``qbx_ir.invariant_ledger``)."""

from __future__ import annotations

import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.invariant_ledger import (
    CertRow,
    certificate_problems,
    differences,
    invariant_values,
    transport_problems,
)
from qbx_ir.ledger import RULES, BraidRow, apply_short


def test_values_of_small_braids():
    # σ1σ2σ1 in B_3: permutation (3 2 1), one fixed strand and a 2-cycle.
    v = invariant_values(3, [1, 2, 1])
    assert v.permutation == (3, 2, 1)
    assert v.writhe == 3
    assert v.components == (0, 1, 0)
    assert v.linking == (1,)
    # The Hopf link σ1² and the empty braid in B_2.
    assert invariant_values(2, [1, 1]).linking == (1,)
    assert invariant_values(2, []) == invariant_values(2, [1, -1])
    # One strand.
    v = invariant_values(1, [])
    assert (v.permutation, v.writhe, v.components, v.linking) == ((1,), 0, (0,), ())


def test_pure_example_is_certified_unequal_to_the_identity():
    """σ1²σ2⁻² vs ε in B_3: same permutation and writhe, different linking (Lean:
    ``crossings_detect_more``)."""
    a = CertRow.of(BraidRow.of(3, [1, 1, -2, -2]))
    e = CertRow.of(BraidRow.of(3, []))
    assert differences(a, e) == ["linking"]
    assert transport_problems(True, a, e) == [("invariant_not_preserved", {"invariant": "linking"})]
    assert transport_problems(False, a, e) == []


def test_certificate_problems():
    b = BraidRow.of(3, [1, 2, 1])
    good = CertRow.of(b)
    assert certificate_problems(good) == []
    bad = CertRow(b, "x", (1, 2, 3), 1, (0, 1, 2), ())
    assert [r for r, _ in certificate_problems(bad)] == [
        "braid_hash_mismatch", "permutation_mismatch", "writhe_mismatch",
        "components_mismatch", "linking_mismatch"]
    broken = BraidRow(3, (1, 5), "h")
    assert certificate_problems(CertRow(broken, "h", (), 0, (), ())) == [("braid_not_well_formed", {})]
    with pytest.raises(ValueError):
        CertRow.of(broken)
    assert differences(good, CertRow(broken, "h", (), 0, (), ())) is None
    assert differences(good, CertRow.of(BraidRow.of(4, [1, 2, 1]))) is None


def test_certificates_are_invariant_along_rewrites_and_detect_inequality():
    rng = random.Random(7)
    for _ in range(300):
        n = rng.randint(2, 5)
        w = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 7))]
        c = CertRow.of(BraidRow.of(n, w))
        for rule in RULES:
            for k in range(len(w)):
                out = apply_short(w, rule, k)
                if out is not None:
                    assert differences(c, CertRow.of(BraidRow.of(n, out))) == []
        v = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 7))]
        d = differences(c, CertRow.of(BraidRow.of(n, v)))
        if d:
            assert not braid_group_equal(Braid.from_short_form(n, w), Braid.from_short_form(n, v))
