"""
Executable mirrors of Lean results, with the Lean theorems as oracles.

Each test names the Lean declaration whose statement it checks numerically.
"""

from fractions import Fraction
from itertools import product

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.invariants import closure_components, linking_matrix, permutation
from qbx_ir.algebra.structural import (
    IDENTITY,
    braid_hash,
    carry,
    carry_cocycle,
    cobdry3,
    crossing_change,
    crossing_strands,
    decatenate,
    decatenation_lower_bound,
    decode_hash,
    encode_bits,
    free_hash,
    free_hash_braid,
    fox_colourings,
    is_tricolourable,
    pos_hash,
    sliding_phase,
    tangle_fraction,
    tangle_parity,
    telescope_invariant,
    torus_braid_3,
    torus_matrix,
    total_linking,
)

B = Braid.from_short_form


def all_bits(max_len):
    for k in range(max_len + 1):
        yield from product((0, 1), repeat=k)


# ---- braid hash (QBX/Formal/BraidHash.lean) ------------------------------


def test_hash_equals_torus_matrix_of_encoding():
    # braidHash_eq: the hash is b3ToSL2 of the encoded braid
    for bits in all_bits(8):
        assert braid_hash(bits) == torus_matrix(encode_bits(bits))


def test_hash_injective_and_decodable():
    # braidHash_injective, with decode_hash as constructive inverse
    seen = {}
    for bits in all_bits(12):
        h = braid_hash(bits)
        assert h not in seen, (bits, seen.get(h))
        seen[h] = bits
        assert decode_hash(h) == list(bits)


def test_hash_is_homomorphism():
    # braidHash_append
    from qbx_ir.algebra.structural import mat_mul

    for s in all_bits(4):
        for t in all_bits(4):
            assert braid_hash(s + t) == mat_mul(braid_hash(s), braid_hash(t))


def test_hash_det_one_nonneg():
    # det_braidHash, braidHash_nonneg
    for bits in all_bits(8):
        (a, b), (c, d) = braid_hash(bits)
        assert a * d - b * c == 1 and min(a, b, c, d) >= 0


def test_decode_rejects_non_hash():
    with pytest.raises(ValueError):
        decode_hash(((0, 1), (-1, 0)))
    with pytest.raises(ValueError):
        decode_hash(((2, 0), (0, 2)))


def test_positive_hash_collisions():
    # posHash_braid_collision and posHash_twelve_eq_one
    assert pos_hash([0, 1, 0]) == pos_hash([1, 0, 1])
    assert pos_hash([0, 1] * 6) == IDENTITY


def reduced_words(max_len):
    for k in range(max_len + 1):
        for w in product((1, -1, 2, -2), repeat=k):
            if all(w[i] != -w[i + 1] for i in range(k - 1)):
                yield w


def test_free_hash_injective_on_reduced_words():
    # freeHash_injective (Sanov): distinct reduced words, distinct hashes
    seen = {}
    for w in reduced_words(6):
        h = free_hash(w)
        assert h not in seen, (w, seen.get(h))
        seen[h] = w


def test_free_hash_is_torus_matrix_and_pure():
    # freeHash = b3ToSL2 ∘ lift braidGens; sigma_sq_pure
    for w in reduced_words(4):
        b = free_hash_braid(w)
        assert torus_matrix(b) == free_hash(w)
        assert permutation(b) == (1, 2, 3)


# ---- rational tangles (QBX/Formal/Bio/RationalTangles.lean) ---------------


def test_tangle_sigma_sq():
    # act_sigma0_sq_zero
    assert tangle_fraction(B(3, [1, 1])) == (2, 1)


def test_tangle_fraction_coprime_and_parity():
    # primitive_act, parity_act_of_permHom_eq
    from math import gcd

    words = [list(w) for k in range(5) for w in product([1, -1, 2, -2], repeat=k)]
    by_perm = {}
    for w in words:
        b = B(3, w)
        p, q = tangle_fraction(b)
        assert gcd(p, q) == 1
        par = tangle_parity(b)
        by_perm.setdefault(permutation(b), set()).add(par)
    assert all(len(v) == 1 for v in by_perm.values())


# ---- Fox colourings (QBX/Notes/TernaryBraids.lean) ----------------


@pytest.mark.parametrize("q", range(0, 13))
def test_colourings_torus(q):
    # colourings_torus: 27 if 6 | q, 9 if q even, 3 if q odd
    expected = 27 if q % 6 == 0 else 9 if q % 2 == 0 else 3
    assert fox_colourings(torus_braid_3(q)) == expected
    # tricolourable_torus_iff
    assert is_tricolourable(torus_braid_3(q)) == (q % 2 == 0)


def test_colourings_tenen_and_three_fibres():
    # colourings_tenen, colourings_threeFibres
    assert fox_colourings(torus_braid_3(10)) == 9
    assert fox_colourings(torus_braid_3(3)) == 3


def test_colourings_trefoil_two_strands():
    # standard: the trefoil σ₁³ is tricolourable (9 colourings), the unknot σ₁ is not
    assert fox_colourings(B(2, [1, 1, 1])) == 9
    assert fox_colourings(B(2, [1])) == 3


# ---- crossing changes (QBX/Formal/Bio/Catenanes.lean) ---------------------


def _lk(braid, s, t):
    comps = closure_components(braid)
    idx = {x: i for i, c in enumerate(comps) for x in c}
    a, b = sorted((idx[s], idx[t]))
    return linking_matrix(braid)[(a, b)]


def test_crossing_change_preserves_components():
    # permHom_crossingChange / closureComponents_crossingChange
    for w in product([1, -1, 2, -2, 3, -3], repeat=4):
        b = B(4, list(w))
        for k in range(len(w)):
            assert permutation(crossing_change(b, k)) == permutation(b)


def test_crossing_change_lemma():
    # linkingNumber_crossingChange_of_mem: a crossing change between two
    # different components changes their linking number by exactly ±1
    # (+1 when σ⁻¹ ↦ σ); a self-crossing changes no linking number
    # (linkingNumber_crossingChange_self).
    for w in product([1, -1, 2, -2, 3, -3], repeat=4):
        b = B(4, list(w))
        idx = {x: i for i, c in enumerate(closure_components(b)) for x in c}
        for k in range(len(w)):
            b2 = crossing_change(b, k)
            u, v = crossing_strands(b, k)
            sign = b.word[k].sign
            if idx[u] != idx[v]:
                assert _lk(b, u, v) - _lk(b2, u, v) == sign
            else:
                assert linking_matrix(b) == linking_matrix(b2)


def test_total_linking_drops_by_at_most_two():
    # totalLinking_le
    for w in product([1, -1, 2, -2, 3, -3], repeat=4):
        b = B(4, list(w))
        for k in range(len(w)):
            assert abs(total_linking(b) - total_linking(crossing_change(b, k))) <= 2


@pytest.mark.parametrize("m", range(-4, 5))
def test_catenane_decatenation_sharp(m):
    # totalLinking_duplex and catenane_decatenation: σ₁^{2m} needs exactly |m|
    # strand passages; flipping one letter at a time achieves it.
    sign = 1 if m >= 0 else -1
    b = B(2, [sign] * (2 * abs(m)))
    assert total_linking(b) == 2 * abs(m)
    assert decatenation_lower_bound(b) == abs(m)
    for step in range(abs(m)):
        b = crossing_change(b, 2 * step)
    assert total_linking(b) == 0


def test_sharp_decatenation_all_short_words():
    # sharp_decatenation / decatenation_minimum / totalLinking_even: every braid
    # closure is made homologically unlinked by exactly totalLinking/2 passages.
    for n, letters, length in ((3, [1, -1, 2, -2], 5), (4, [1, -1, 2, -2, 3, -3], 4)):
        for w in product(letters, repeat=length):
            b = B(n, list(w))
            t = total_linking(b)
            assert t % 2 == 0
            final, flips = decatenate(b)
            assert len(flips) == t // 2 == decatenation_lower_bound(b)
            assert all(v == 0 for v in linking_matrix(final).values())
            assert closure_components(final) == closure_components(b)


def test_sharp_decatenation_ring_chain():
    # A chain of four rings with neighbour linking numbers 2, -1, 3:
    # σ₁⁴ σ₂⁻² σ₃⁶ needs exactly 2 + 1 + 3 = 6 passages.
    b = B(4, [1] * 4 + [-2] * 2 + [3] * 6)
    assert total_linking(b) == 12
    final, flips = decatenate(b)
    assert len(flips) == 6
    assert total_linking(final) == 0


# ---- carry cocycle (QBX/Formal/Hebrew/CyclicGenerator.lean) ---------------


@pytest.mark.parametrize("n", range(1, 7))
def test_carry_is_two_cocycle(n):
    # carry_cobdry2
    for b, c, d in product(range(n), repeat=3):
        assert (carry(n, c, d) - carry(n, (b + c) % n, d)
                + carry(n, b, (c + d) % n) - carry(n, b, c)) == 0


@pytest.mark.parametrize("n", range(2, 7))
def test_gen_cocycle(n):
    # genCocycle_isCocycle, sum_genCocycle, genCocycle_order
    for m in range(0, 2 * n + 1):
        f = lambda a, b, c, m=m: carry_cocycle(n, a, b, c, m)
        for a, b, c, d in product(range(n), repeat=4):
            assert cobdry3(f, n, a, b, c, d) == 0
        assert telescope_invariant(f, n) == Fraction(m % n, n)


# The Bitcoin genesis block (285 bytes), as in QBX.Forensics.GenesisBlock.genesisBytes.
GENESIS_BLOCK = bytes.fromhex(
    "0100000000000000000000000000000000000000000000000000000000000000"
    "000000003ba3edfd7a7b12b27ac72c3e67768f617fc81bc3888a51323a9fb8aa"
    "4b1e5e4a29ab5f49ffff001d1dac2b7c01010000000100000000000000000000"
    "00000000000000000000000000000000000000000000ffffffff4d04ffff001d"
    "0104455468652054696d65732030332f4a616e2f32303039204368616e63656c"
    "6c6f72206f6e206272696e6b206f66207365636f6e64206261696c6f75742066"
    "6f722062616e6b73ffffffff0100f2052a01000000434104678afdb0fe554827"
    "1967f1a67130b7105cd6a828e03909a67962e0ea1f61deb649f6bc3f4cef38c4"
    "f35504e51ec112de5c384df7ba0b8d578a4c702b6bf11d5fac00000000"
)


def test_genesis_block_cocycle_phase():
    # genesisBytes_length, genesis_phase_256, genesis_phase_7, genesis_phase_3,
    # genesis_meruC1_phase
    assert len(GENESIS_BLOCK) == 285
    for n, expected in [(256, Fraction(107, 256)), (7, Fraction(3, 7)), (3, Fraction(0))]:
        xs = [x % n for x in GENESIS_BLOCK]
        phase = sliding_phase(lambda a, b, c, n=n: carry_cocycle(n, a, b, c), xs)
        assert phase == expected
        assert (n * phase) % 1 == 0  # nsmul_slidingPhase_genCocycle
    xs3 = [x % 3 for x in GENESIS_BLOCK]
    assert sliding_phase(lambda a, b, c: Fraction(a * b * c, 3), xs3) == Fraction(1, 3)
