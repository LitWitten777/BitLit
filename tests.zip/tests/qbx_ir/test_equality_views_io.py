"""Five equalities, eight views, file format, SVG and fingerprint."""

import copy

import numpy as np

from qbx_ir import Braid, EqualityKind, check_equality
from qbx_ir import io as qio
from qbx_ir.fingerprint import fingerprint, fingerprint_hash
from qbx_ir.quantum import SL2RMatrix, representation
from qbx_ir.render import braid_to_svg
from qbx_ir.views import all_views, render, render_all

B = Braid.from_short_form


def test_five_equalities_are_distinct():
    a, b = B(3, [1, 2, 1]), B(3, [2, 1, 2])
    assert not check_equality(a, b, EqualityKind.SYNTACTIC)
    assert check_equality(a, b, EqualityKind.WORD)
    assert check_equality(a, b, EqualityKind.TOPOLOGICAL)
    rho = lambda x: representation(x, SL2RMatrix(2.0))  # noqa: E731
    assert check_equality(a, b, EqualityKind.REPRESENTATION, representation_fn=rho)
    r = check_equality(a, b, EqualityKind.PHYSICAL)
    assert not r.equal and not r.certain
    assert check_equality(a, b, EqualityKind.PHYSICAL, physical_fn=lambda x, y: True)


def test_representation_equality_can_be_coarser_than_word_equality():
    # The permutation R-matrix only sees S_n: σ1² looks like the identity.
    from qbx_ir.quantum import PermutationRMatrix

    rho = lambda x: representation(x, PermutationRMatrix())  # noqa: E731
    a, b = B(2, [1, 1]), B(2, [])
    assert check_equality(a, b, EqualityKind.REPRESENTATION, representation_fn=rho)
    assert not check_equality(a, b, EqualityKind.WORD)


def test_closure_equality_semidecision():
    # Conjugate braids have isotopic closures but are different braids.
    a = B(3, [1, 2, 2])
    c = B(3, [2])
    b = c * a * c.inverse()
    assert not check_equality(a, b, EqualityKind.WORD)
    r = check_equality(a, b, EqualityKind.TOPOLOGICAL, closure=True)
    assert not r.certain  # invariants agree; undetermined
    r2 = check_equality(B(2, [1, 1, 1]), B(2, [-1, -1, -1]), EqualityKind.TOPOLOGICAL, closure=True)
    assert r2.certain and not r2.equal  # trefoil vs mirror: Jones separates


def test_all_views_total_and_pure():
    braids = [Braid.identity(1), Braid.identity(3), B(3, [1, -2, 1]), B(5, [1, 2, 3, 4, -1]),
              Braid.full_twist(4)]
    assert len(all_views()) == 8
    for b in braids:
        before = copy.deepcopy(b)
        views = render_all(b)
        assert set(views) == {f"L{k}" for k in range(8)}
        assert all(isinstance(v, str) and v for v in views.values())
        assert b == before
    assert "σ_1" in render(B(2, [1]), "L2")


def test_qbx_file_roundtrip(tmp_path):
    b = B(3, [1, -2, 1], name="demo")
    for fmt in ("json",):
        assert qio.loads(qio.dumps(b, fmt), fmt).short_form() == b.short_form()
    p = tmp_path / "b.json"
    qio.save(b, str(p))
    assert qio.load(str(p)).short_form() == [1, -2, 1]
    doc = {"qbx": "0.1", "braid": {"strands": 3, "word": [{"sigma": 1, "power": 2},
                                                           {"sigma": 2, "power": -1}]}}
    assert qio.from_document(doc).short_form() == [1, 1, -2]


def test_svg_renders():
    svg = braid_to_svg(B(3, [1, -2]))
    assert svg.startswith("<svg") and svg.endswith("</svg>") and svg.count("<line") >= 4


def test_fingerprint_is_group_invariant():
    a, b = B(3, [1, 2, 1, -2]), B(3, [2, 1, 2, -2])
    assert fingerprint_hash(a) == fingerprint_hash(b)
    assert fingerprint_hash(a) != fingerprint_hash(B(3, [1, 2]))
    fp = fingerprint(a)
    assert fp["n"] == 3 and fp["I_topo"]["writhe"] == 2
    assert np.isfinite(fp["I_geometric"]["e8_cost"])
