"""Pentagon and hexagon equations for the shipped anyon models.

Numerical counterpart of `Formal/AnyonCoherence.lean` / `Formal/AnyonModels.lean` (H-065),
with the same conventions: ``F(a, b, c, d, e, f) = [F^{abc}_d]_{ef}`` and
``R(a, b, c) = R^{ab}_c``, both extended by zero on non-admissible vertices, and every label
assignment checked.
"""

import cmath
import itertools
import math

import pytest

from qbx_ir.anyon import fibonacci_model, ising_model, toric_code_model

MODELS = [fibonacci_model(), ising_model(), toric_code_model()]


def f_symbol(model, a, b, c, d, e, f):
    left = model.intermediates_left(a, b, c, d)
    right = model.intermediates_right(a, b, c, d)
    if e not in left or f not in right:
        return 0
    return complex(model.f_matrix(a, b, c, d)[left.index(e), right.index(f)])


def r_symbol(model, a, b, c):
    return complex(model.r_symbol(a, b, c)) if model.admissible(a, b, c) else 0


def r_reversed(model, a, b, c):
    r = r_symbol(model, b, a, c)
    return 1 / r if r else 0


@pytest.mark.parametrize("model", MODELS, ids=lambda m: m.name)
def test_pentagon(model):
    labels = model.labels
    for a, b, c, d, e, f, g, k, l in itertools.product(labels, repeat=9):
        lhs = f_symbol(model, f, c, d, e, g, l) * f_symbol(model, a, b, l, e, f, k)
        rhs = sum(f_symbol(model, a, b, c, g, f, h) * f_symbol(model, a, h, d, e, g, k)
                  * f_symbol(model, b, c, d, k, h, l) for h in labels)
        assert abs(lhs - rhs) < 1e-12, (a, b, c, d, e, f, g, k, l)


@pytest.mark.parametrize("model", MODELS, ids=lambda m: m.name)
@pytest.mark.parametrize("reverse", [False, True], ids=["hexagon", "hexagon_inv"])
def test_hexagons(model, reverse):
    labels = model.labels
    R = (lambda a, b, c: r_reversed(model, a, b, c)) if reverse else \
        (lambda a, b, c: r_symbol(model, a, b, c))
    for a, b, c, d, e, g in itertools.product(labels, repeat=6):
        lhs = R(c, a, e) * f_symbol(model, a, c, b, d, e, g) * R(c, b, g)
        rhs = sum(f_symbol(model, c, a, b, d, e, f) * R(c, f, d)
                  * f_symbol(model, a, b, c, d, f, g) for f in labels)
        assert abs(lhs - rhs) < 1e-12, (a, b, c, d, e, g)


def test_tables_match_lean_definitions():
    """The non-trivial entries named in `fibF`, `fibR`, `isingF`, `isingR`."""
    phi = (1 + math.sqrt(5)) / 2
    fib = fibonacci_model()
    assert f_symbol(fib, "τ", "τ", "τ", "τ", "1", "1") == pytest.approx(1 / phi)
    assert f_symbol(fib, "τ", "τ", "τ", "τ", "1", "τ") == pytest.approx(1 / math.sqrt(phi))
    assert f_symbol(fib, "τ", "τ", "τ", "τ", "τ", "τ") == pytest.approx(-1 / phi)
    assert r_symbol(fib, "τ", "τ", "1") == pytest.approx(cmath.exp(-4j * math.pi / 5))
    assert r_symbol(fib, "τ", "τ", "τ") == pytest.approx(cmath.exp(3j * math.pi / 5))
    ising = ising_model()
    s = 1 / math.sqrt(2)
    assert f_symbol(ising, "σ", "σ", "σ", "σ", "ψ", "ψ") == pytest.approx(-s)
    assert f_symbol(ising, "σ", "σ", "σ", "σ", "1", "ψ") == pytest.approx(s)
    assert f_symbol(ising, "ψ", "σ", "ψ", "σ", "σ", "σ") == pytest.approx(-1)
    assert f_symbol(ising, "σ", "ψ", "σ", "ψ", "σ", "σ") == pytest.approx(-1)
    assert r_symbol(ising, "σ", "σ", "1") == pytest.approx(cmath.exp(-1j * math.pi / 8))
    assert r_symbol(ising, "σ", "σ", "ψ") == pytest.approx(cmath.exp(3j * math.pi / 8))
    assert r_symbol(ising, "σ", "ψ", "σ") == pytest.approx(-1j)
    assert r_symbol(ising, "ψ", "ψ", "1") == pytest.approx(-1)


def test_toric_code_matches_lean():
    """`toricR`, `toric_spin_*`, `toric_monodromy_em` of `Formal/ToricAnyons.lean`."""
    tc = toric_code_model()
    assert r_symbol(tc, "ε", "ε", "1") == -1
    assert r_symbol(tc, "e", "e", "1") == 1
    assert r_symbol(tc, "m", "m", "1") == 1
    assert r_symbol(tc, "m", "e", "ε") * r_symbol(tc, "e", "m", "ε") == -1
    for a in tc.labels:
        for b in tc.labels:
            assert len(tc.fuse(a, b)) == 1
    assert tc.total_quantum_dimension() == pytest.approx(2.0)
