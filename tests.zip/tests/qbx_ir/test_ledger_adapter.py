"""QBX-IR ↔ ledger adapter (Phase 2 sprint 5) on the in-memory reference backend.

The same scenarios run against PostgreSQL in
``tests/live_db/test_ledger_adapter_db.py``.
"""

from __future__ import annotations

import random
from dataclasses import replace

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.rewriting import (
    ALL_RULES,
    apply_rule,
    braid_hash,
    find_matches,
    normal_form,
    normal_form_with_trace,
)
from qbx_ir.ledger_adapter import (
    DerivationRecord,
    InMemoryBraidLedger,
    LedgerRefusal,
    TraceRecord,
    braid_row_of,
    certificate_problems_of_trace,
    persist_normal_form,
    read_braid,
    read_trace,
    read_transformation,
    rewrite_row_of,
    round_trip,
    trace_problems,
    transformation_of,
    verify_trace,
    write_trace,
)


def random_braid(rng, n_max=5, len_max=12):
    n = rng.randint(1, n_max)
    if n == 1:
        return Braid.identity(1)
    return Braid.from_short_form(
        n, [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, len_max))])


def random_rewrite_trace(rng, braid, steps):
    """A trace of arbitrary rule applications (all three rules, R02 both ways)."""
    trace, cur = [], braid
    for _ in range(steps):
        options = [(r, k) for r in ALL_RULES for k in find_matches(cur, r)]
        if not options:
            break
        r, k = rng.choice(options)
        cur, t = apply_rule(cur, r, k)
        trace.append(t)
    return cur, trace


def test_round_trip_random_normal_form_traces():
    rng = random.Random(5)
    for _ in range(150):
        b = random_braid(rng)
        ledger = InMemoryBraidLedger()
        record, problems = round_trip(ledger, b, certify=True)
        assert problems == []
        src, steps, tgt = read_trace(ledger, record.derivation_id)
        reduced, trace = normal_form_with_trace(b)
        assert src.short_form() == b.short_form() and braid_hash(src) == braid_hash(b)
        assert [t for t, _ in steps] == trace
        assert all(fwd for _, fwd in steps)
        assert tgt.short_form() == reduced.short_form() == normal_form(b).short_form()
        assert ledger.equality_certified(record.source_id, record.target_id)


def test_round_trip_arbitrary_traces():
    rng = random.Random(11)
    for _ in range(120):
        b = random_braid(rng, n_max=6, len_max=10)
        end, trace = random_rewrite_trace(rng, b, rng.randint(0, 8))
        ledger = InMemoryBraidLedger()
        record = write_trace(ledger, b, trace)
        assert verify_trace(ledger, record, b, trace) == []
        assert read_braid(ledger, record.target_id).short_form() == end.short_form()
        assert braid_group_equal(read_braid(ledger, record.source_id),
                                 read_braid(ledger, record.target_id))


def test_reduced_braid_has_empty_trace():
    ledger = InMemoryBraidLedger()
    b = Braid.from_short_form(4, [1, 3, 2])
    reduced, trace, record = persist_normal_form(ledger, b)
    assert trace == [] and record.rewrite_ids == ()
    assert record.source_id == record.target_id
    assert verify_trace(ledger, record, b, trace) == []


def test_content_addressing_shares_rows():
    ledger = InMemoryBraidLedger()
    b = Braid.from_short_form(3, [1, -1, 2])
    _, _, r1 = persist_normal_form(ledger, b)
    _, _, r2 = persist_normal_form(ledger, b)
    assert (r1.source_id, r1.target_id) == (r2.source_id, r2.target_id)
    assert r1.derivation_id != r2.derivation_id
    assert len(ledger.braids) == 2


def test_names_are_stored():
    ledger = InMemoryBraidLedger()
    b = Braid.from_short_form(3, [1, -1, 2], name="beta")
    _, _, record = persist_normal_form(ledger, b, name="beta")
    assert read_braid(ledger, record.source_id).name == "beta"
    assert ledger.derivation(record.derivation_id).name == "beta"


def test_row_conversions_are_inverse():
    rng = random.Random(3)
    for _ in range(60):
        b = random_braid(rng)
        _, trace = random_rewrite_trace(rng, b, 4)
        for t in trace:
            assert transformation_of(rewrite_row_of(b.strand_count, t)) == t
        assert braid_row_of(b).braid_hash == braid_hash(b)


# -- tampered traces --------------------------------------------------------

def sample_trace():
    b = Braid.from_short_form(4, [3, 1, -1, 2, 1, -3, 3])
    _, trace = normal_form_with_trace(b)
    assert len(trace) >= 2
    return b, trace


def test_trace_problems_wrong_output():
    b, trace = sample_trace()
    bad = replace(trace[0], output_word=(1,) + tuple(trace[0].output_word))
    reasons = [(r, d["step"], d.get("reason")) for r, d in trace_problems(b, [bad] + trace[1:])]
    assert ("step_problem", 0, "output_not_well_formed") in reasons   # recorded hash is stale
    assert ("step_problem", 0, "output_mismatch") in reasons
    assert ("step_disconnected", 1, None) in reasons


def test_trace_problems_disconnected_start():
    b, trace = sample_trace()
    assert trace_problems(b, trace[1:]) == [("step_disconnected", {"step": 0})]


def test_trace_problems_rule_and_declaration():
    b, trace = sample_trace()
    for bad, reason in [
        (replace(trace[0], rule_id="R99"), "rule_unknown"),
        (replace(trace[0], rule_id="R03"), "not_applicable"),
        (replace(trace[0], position=trace[0].position + 1), None),
        (replace(trace[0], preserved_properties=("writhe",)), "declaration_mismatch"),
    ]:
        found = [d["reason"] for r, d in trace_problems(b, [bad]) if r == "step_problem"]
        assert found, bad
        if reason is not None:
            assert reason in found


def test_write_trace_refuses_before_writing():
    b, trace = sample_trace()
    ledger = InMemoryBraidLedger()
    with pytest.raises(ValueError):
        write_trace(ledger, b, trace[1:])
    assert ledger.braids == {} and ledger.rewrites == {} and ledger.derivations == {}


def test_trace_problems_iff_writer_records_it():
    """A trace passes the pre-flight check iff the writers record exactly it."""
    rng = random.Random(23)
    fields = ["rule_id", "position", "output_word", "output_hash", "input_word",
              "preserved_properties", "changed_properties"]
    for _ in range(300):
        b = random_braid(rng, n_max=5, len_max=8)
        _, trace = random_rewrite_trace(rng, b, rng.randint(1, 4))
        if not trace:
            continue
        k = rng.randrange(len(trace))
        f = rng.choice(fields)
        t = trace[k]
        new = {
            "rule_id": rng.choice(["R01", "R02", "R03", "R04"]),
            "position": t.position + rng.choice([-1, 1, 2]),
            "output_word": tuple(t.output_word) + (1,) if b.strand_count > 1 else (5,),
            "output_hash": "0" * 64,
            "input_word": tuple(t.input_word)[::-1],
            "preserved_properties": ("writhe",),
            "changed_properties": (),
        }[f]
        tampered = list(trace)
        tampered[k] = replace(t, **{f: new})
        ok = trace_problems(b, tampered) == []
        ledger = InMemoryBraidLedger()
        try:
            record = write_trace(ledger, b, tampered)
            written = verify_trace(ledger, record, b, tampered) == []
        except (ValueError, LedgerRefusal):
            written = False
        assert ok == written
        if tampered == trace:
            assert ok   # other tamperings may still be valid records (same output)


# -- verification failures ---------------------------------------------------

def test_verify_detects_other_braid_and_trace():
    b, trace = sample_trace()
    ledger = InMemoryBraidLedger()
    record = write_trace(ledger, b, trace)
    other = Braid.from_short_form(4, [1, 2])
    reasons = [r for r, _ in verify_trace(ledger, record, other, [])]
    assert reasons == ["source_mismatch", "trace_length", "target_mismatch"]
    reasons = [r for r, _ in verify_trace(ledger, record, b, trace[:1])]
    assert reasons == ["trace_length", "target_mismatch"]


def test_verify_detects_tampered_derivation():
    b, trace = sample_trace()
    ledger = InMemoryBraidLedger()
    record = write_trace(ledger, b, trace)
    d = ledger.derivations[record.derivation_id]
    # A row written around the writer: the target is the source.
    ledger.derivations[record.derivation_id] = DerivationRecord(
        d.source_id, d.source_id, d.steps, d.directions)
    reasons = [r for r, _ in verify_trace(ledger, record, b, trace)]
    assert reasons == ["target_mismatch", "derivation_problem", "not_certified"]
    # Steps used backwards.
    ledger.derivations[record.derivation_id] = DerivationRecord(
        d.source_id, d.target_id, d.steps, tuple(False for _ in d.directions))
    reasons = [r for r, _ in verify_trace(ledger, record, b, trace)]
    assert reasons[:2] == ["step_direction", "step_direction"]
    assert "derivation_problem" in reasons and reasons[-1] == "not_certified"
    assert verify_trace(ledger, TraceRecord("x", (), "missing", "y"), b, trace) == [
        ("derivation_unknown", {})]


# -- writers and certificates ------------------------------------------------

def test_in_memory_writers_refuse():
    ledger = InMemoryBraidLedger()
    with pytest.raises(LedgerRefusal):
        ledger.register_braid(3, [3])
    with pytest.raises(LedgerRefusal):
        ledger.register_braid(0, [])
    bid = ledger.register_braid(3, [1, 2])
    with pytest.raises(LedgerRefusal):
        ledger.record_rewrite("nope", "R01", 0)
    with pytest.raises(LedgerRefusal):
        ledger.record_rewrite(bid, "R01", 0)
    with pytest.raises(LedgerRefusal):
        ledger.record_rewrite(bid, "R07", 0)
    with pytest.raises(LedgerRefusal):
        ledger.record_derivation(bid, ["nope"], [True])
    with pytest.raises(LedgerRefusal):
        ledger.record_derivation(bid, [], [True])


def test_certificates_missing_then_agree():
    b, trace = sample_trace()
    ledger = InMemoryBraidLedger()
    record = write_trace(ledger, b, trace)
    assert [r for r, _ in certificate_problems_of_trace(ledger, record)] == [
        "invariant_missing", "normal_form_missing", "representation_missing"]
    ledger.certify(record.source_id)
    ledger.certify(record.target_id)
    assert certificate_problems_of_trace(ledger, record) == []


def test_read_transformation_matches_apply_rule():
    b = Braid.from_short_form(3, [1, 2, 1])
    out, t = apply_rule(b, ALL_RULES[2], 0)
    ledger = InMemoryBraidLedger()
    bid = ledger.register_braid(3, b.short_form())
    rid = ledger.record_rewrite(bid, "R03", 0)
    assert read_transformation(ledger, rid) == t
    assert read_braid(ledger, ledger.rewrite_ends(rid)[1]).short_form() == out.short_form()
