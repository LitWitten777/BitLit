"""Quantum layer: R-matrices, representation, verification, L5↔L6 bridge."""

import numpy as np
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.polynomial_invariants import jones_polynomial
from qbx_ir.quantum import (
    PermutationRMatrix,
    SL2RMatrix,
    TwistedSwapRMatrix,
    jones_from_quantum_trace,
    representation,
    verify_braid_equality,
    verify_braid_relations,
    verify_yang_baxter,
)
from qbx_ir.quantum.r_matrix import hecke_residual

B = Braid.from_short_form


@pytest.mark.parametrize("q", [2.0, 0.7, 1.3 + 0.4j, np.exp(0.9j)])
def test_sl2_yang_baxter_and_relations(q):
    R = SL2RMatrix(q)
    assert verify_yang_baxter(R)[0]
    assert verify_braid_relations(R, n=5)[0]
    assert hecke_residual(R) < 1e-9
    assert np.allclose(R.matrix() @ R.inverse_matrix(), np.eye(4))


def test_twisted_swap_family():
    rng = np.random.default_rng(0)
    for d in (2, 3):
        table = rng.normal(size=(d, d)) + 1j * rng.normal(size=(d, d))
        R = TwistedSwapRMatrix(table)
        assert verify_yang_baxter(R)[0]
        assert verify_braid_relations(R, n=4)[0]
    assert verify_braid_relations(PermutationRMatrix(), n=4)[0]
    assert verify_yang_baxter(TwistedSwapRMatrix.legacy_sl2(2.0))[0]


def test_representation_respects_word_order():
    R = SL2RMatrix(1.7)
    a, b = B(3, [1]), B(3, [-2, 1])
    assert np.allclose(representation(a * b, R), representation(b, R) @ representation(a, R))
    assert np.allclose(representation(a * a.inverse(), R), np.eye(8))


def test_representation_distinguishes_noncommuting():
    ok, _ = verify_braid_equality(B(3, [1, 2]), B(3, [2, 1]), SL2RMatrix(2.0))
    assert not ok


@pytest.mark.parametrize("word,n", [([1], 2), ([1, 1, 1], 2), ([1, -2, 1, -2], 3),
                                     ([1, 1], 2), ([], 2), ([1, 2, -1, 2, 3], 4)])
def test_jones_via_quantum_trace(word, n):
    b = B(n, word)
    for q in (1.3 + 0.2j, 0.8 - 0.5j):
        assert abs(jones_from_quantum_trace(b, q) - jones_polynomial(b).evaluate(-1 / q)) < 1e-8
