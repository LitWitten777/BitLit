"""Reference implementation of the reduced Burau / Alexander certificates of
migration 024 (qbx_ir.burau_ledger).

Formal backing: ``Formal/BurauRep.lean`` and ``Formal/BraidBurauCert.lean``
(registry H-063, H-064).
"""

from __future__ import annotations

import random
import re
from pathlib import Path

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.polynomial_invariants import alexander_polynomial, burau_matrix
from qbx_ir.burau_ledger import (
    MAX_BURAU_STRANDS,
    BurauRow,
    alexander_equal,
    burau_equal,
    burau_values,
    certificate_problems,
    encode_matrix,
    inequality_certified,
    nf_consistency_problems,
    non_conjugacy_certified,
    transport_problems,
)
from qbx_ir.ledger import BraidRow
from qbx_ir.normal_form_ledger import NFRow

LEAN = Path(__file__).resolve().parents[2] / "Formal" / "BraidBurauCert.lean"
LEAN_VECTORS = Path(__file__).resolve().parents[2] / "Formal" / "BraidBurauCert" / "Vectors"


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def decode(v):
    """The matrix of a certificate as {(i, j): {exponent: coefficient}}."""
    out = {}
    for i in range(v.size):
        for j in range(v.size):
            base = (i * v.size + j) * v.width
            out[(i, j)] = {v.exp_min + k: v.coefficients[base + k]
                           for k in range(v.width) if v.coefficients[base + k]}
    return out


def test_known_values():
    # σ1 on two strands: ρ̄ = (-t); the closure is the unknot.
    assert burau_values(2, [1]) == burau_values(2, [1]).__class__(1, 1, 1, (-1,), (1,))
    # n = 1: empty matrix, Alexander polynomial 1.
    v = burau_values(1, [])
    assert (v.size, v.exp_min, v.width, v.coefficients, v.alexander) == (0, 0, 0, (), (1,))
    # Trefoil σ1³, figure-eight (σ1σ2⁻¹)², 2-component unlink.
    assert burau_values(2, [1, 1, 1]).alexander == (1, -1, 1)
    assert burau_values(3, [1, -2, 1, -2]).alexander == (1, -3, 1)
    assert burau_values(2, []).alexander == ()
    # The trefoil and its mirror have the same Alexander polynomial.
    assert burau_values(2, [-1, -1, -1]).alexander == (1, -1, 1)


def test_encoding_round_trip_and_minimal_window():
    rng = random.Random(1)
    for _ in range(150):
        n = rng.randint(1, 6)
        w = random_word(rng, n, rng.randint(0, 9)) if n > 1 else []
        v = burau_values(n, w)
        mat = burau_matrix(Braid.from_short_form(n, w))
        assert len(v.coefficients) == v.size * v.size * v.width
        got = decode(v)
        for i in range(v.size):
            for j in range(v.size):
                assert got[(i, j)] == {k: int(c) for k, c in mat[i][j].coeffs.items()}
        if v.width:
            firsts = [v.coefficients[(x * v.width)] for x in range(v.size * v.size)]
            lasts = [v.coefficients[(x * v.width) + v.width - 1] for x in range(v.size * v.size)]
            assert any(firsts) and any(lasts)          # the window is the smallest one
        else:
            assert v.exp_min == 0 and v.size == 0


def test_equal_braids_have_equal_certificates():
    rng = random.Random(2)
    for _ in range(80):
        n = rng.randint(2, 5)
        w1 = random_word(rng, n, rng.randint(0, 6))
        w2 = random_word(rng, n, rng.randint(0, 6))
        a, b = BurauRow.of(BraidRow.of(n, w1)), BurauRow.of(BraidRow.of(n, w2))
        if braid_group_equal(Braid.from_short_form(n, w1), Braid.from_short_form(n, w2)):
            assert burau_equal(a, b) is True and alexander_equal(a, b) is True
    # The braid relation and inverse cancellation hold exactly.
    assert burau_values(3, [1, 2, 1]) == burau_values(3, [2, 1, 2])
    assert burau_values(4, [1, -1, 3]) == burau_values(4, [3])
    # σ1 and σ2 are different elements of B_3.
    a, b = BurauRow.of(BraidRow.of(3, [1])), BurauRow.of(BraidRow.of(3, [2]))
    assert burau_equal(a, b) is False and inequality_certified(a, b)


def test_alexander_is_a_conjugacy_invariant():
    rng = random.Random(3)
    for _ in range(60):
        n = rng.randint(2, 5)
        x = random_word(rng, n, rng.randint(0, 4))
        y = random_word(rng, n, rng.randint(0, 5))
        conj = x + y + [-g for g in reversed(x)]
        assert burau_values(n, conj).alexander == burau_values(n, y).alexander


def test_non_conjugacy_certificate():
    """σ1σ2⁻¹σ1σ2⁻¹ and σ1σ2⁻¹: same writhe, both 3-cycles, different Alexander
    polynomials — not conjugate in B_3 (Lean: figureEight_not_conj)."""
    a = BurauRow.of(BraidRow.of(3, [1, -2, 1, -2]))
    b = BurauRow.of(BraidRow.of(3, [1, -2]))
    assert alexander_equal(a, b) is False
    assert non_conjugacy_certified(a, b)
    assert inequality_certified(a, b)


def test_problems_of_tampered_certificates():
    braid = BraidRow.of(3, [1, -2, 1])
    good = BurauRow.of(braid)
    assert certificate_problems(good) == []
    bad_hash = BurauRow(braid, "e" * 8, good.size, good.exp_min, good.width, good.coefficients,
                        good.alexander)
    assert [r for r, _ in certificate_problems(bad_hash)] == ["braid_hash_mismatch"]
    shifted = BurauRow(braid, good.braid_hash, good.size, good.exp_min - 1, good.width + 1,
                       good.coefficients, good.alexander)
    # Same coefficient list, different window: a different matrix.
    assert [r for r, _ in certificate_problems(shifted)] == ["window_mismatch"]
    coeffs = list(good.coefficients)
    coeffs[2] += 1
    wrong = BurauRow(braid, good.braid_hash, good.size, good.exp_min, good.width, tuple(coeffs),
                     good.alexander)
    assert certificate_problems(wrong) == [("coefficients_mismatch",
                                            {"recorded_length": len(coeffs),
                                             "expected_length": len(coeffs),
                                             "first_index": 2})]
    alex = BurauRow(braid, good.braid_hash, good.size, good.exp_min, good.width,
                    good.coefficients, (1, 1))
    assert certificate_problems(alex) == [("alexander_mismatch",
                                           {"recorded": ["1", "1"],
                                            "expected": [str(x) for x in good.alexander]})]
    size = BurauRow(braid, good.braid_hash, 5, good.exp_min, good.width, good.coefficients,
                    good.alexander)
    assert [r for r, _ in certificate_problems(size)] == ["size_mismatch"]
    malformed = BurauRow(BraidRow(3, (1, 7), "h"), "h", 2, 0, 0, (), ())
    assert certificate_problems(malformed) == [("braid_not_well_formed", {})]
    big = BraidRow.of(MAX_BURAU_STRANDS + 1, [1])
    assert certificate_problems(BurauRow(big, big.braid_hash, 0, 0, 0, (), ())) == [
        ("strand_count_too_large", {"strand_count": MAX_BURAU_STRANDS + 1,
                                    "max": MAX_BURAU_STRANDS})]
    with pytest.raises(ValueError, match="strand_count_too_large"):
        BurauRow.of(big)
    assert burau_equal(good, malformed) is None
    assert burau_equal(good, BurauRow.of(BraidRow.of(4, [1, -2, 1]))) is None   # B_3 vs B_4


def test_transport_and_nf_consistency_never_fire_on_correct_data():
    rng = random.Random(4)
    for _ in range(40):
        n = rng.randint(2, 4)
        w = random_word(rng, n, rng.randint(0, 6))
        w2 = w + [1, -1]
        a, b = BurauRow.of(BraidRow.of(n, w)), BurauRow.of(BraidRow.of(n, w2))
        assert transport_problems(True, a, b) == []
        nf_a, nf_b = NFRow.of(a.braid), NFRow.of(b.braid)
        assert nf_consistency_problems(a, nf_a, [(b, nf_b)]) == []
    # A wrong (but self-consistent-looking) certificate is caught by transport.
    a = BurauRow.of(BraidRow.of(3, [1, -1]))
    b = BurauRow.of(BraidRow.of(3, []))
    assert transport_problems(False, a, BurauRow.of(BraidRow.of(3, [1]))) == []
    # (both closures are split, so the Alexander polynomials agree: 0)
    assert transport_problems(True, a, BurauRow.of(BraidRow.of(3, [1]))) == [
        ("burau_not_preserved", {})]
    assert transport_problems(True, a, BurauRow.of(BraidRow.of(3, [1, 2]))) == [
        ("burau_not_preserved", {}), ("alexander_not_preserved", {})]
    assert transport_problems(True, a, b) == []


def test_alexander_matches_polynomial_invariants():
    rng = random.Random(5)
    for _ in range(60):
        n = rng.randint(1, 5)
        w = random_word(rng, n, rng.randint(0, 7)) if n > 1 else []
        p = alexander_polynomial(Braid.from_short_form(n, w))
        got = burau_values(n, w).alexander
        assert {k: v for k, v in enumerate(got) if v} == p.to_int_dict()


def _lean_vectors():
    # Since the 2026-10-11 split the vectors live in ``Formal/BraidBurauCert/Vectors/*.lean``
    # (one ``def burauVNN : BurauVector := (...)`` each); ``BraidBurauCert.lean`` lists them.
    block = "\n".join(f.read_text() for f in sorted(LEAN_VECTORS.glob("*.lean")))
    rows = re.findall(r"\((\d+), \[([^\]]*)\], (-?\d+), (\d+), \[([^\]]*)\], \[([^\]]*)\], "
                      r"(-?\d+), (-?\d+)\)", block)

    def ints(s):
        return tuple(int(x) for x in s.split(",") if x.strip())

    return [(int(n), list(ints(w)), int(lo), int(wd), ints(cs), ints(al))
            for n, w, lo, wd, cs, al, _, _ in rows]


def test_lean_vectors_match_python():
    """The test vectors of ``Formal/BraidBurauCert.lean`` (``burau_agrees_with_python``) are
    the values of this module."""
    vectors = _lean_vectors()
    assert len(vectors) >= 15
    for n, w, lo, wd, cs, al in vectors:
        v = burau_values(n, w)
        assert (v.exp_min, v.width, v.coefficients, v.alexander) == (lo, wd, cs, al), (n, w)


def test_encode_matrix_of_zero_matrix():
    assert encode_matrix([]) == (0, 0, 0, ())
