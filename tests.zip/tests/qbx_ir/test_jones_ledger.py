"""Reference implementation of the Kauffman bracket / Jones certificates of
migration 023 (qbx_ir.jones_ledger).

Formal backing: ``Formal/KauffmanBracket.lean`` and ``Formal/KauffmanBracket/*.lean``
(registry H-278 … H-281).
"""

from __future__ import annotations

import random
import re
from pathlib import Path

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.polynomial_invariants import (
    jones_polynomial,
    kauffman_bracket,
    kauffman_bracket_state_sum,
)
from qbx_ir.jones_ledger import (
    MAX_JONES_STRANDS,
    JonesRow,
    bracket_equal,
    certificate_problems,
    encode_poly,
    jones_equal,
    jones_values,
    nf_consistency_problems,
    non_conjugacy_certified,
    non_isotopy_certified,
    transport_problems,
)
from qbx_ir.algebra.laurent import Laurent
from qbx_ir.ledger import BraidRow
from qbx_ir.normal_form_ledger import NFRow

LEAN_VECTORS = Path(__file__).resolve().parents[2] / "Formal" / "KauffmanBracket" / "Vectors.lean"


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def decode(lo, width, coeffs):
    return {lo + k: c for k, c in enumerate(coeffs) if c}


def test_known_values():
    # Unknot (one strand): bracket and Jones polynomial 1.
    v = jones_values(1, [])
    assert (v.bracket_exp_min, v.bracket_width, v.bracket_coefficients) == (0, 1, (1,))
    assert (v.jones_exp_min, v.jones_width, v.jones_coefficients) == (0, 1, (1,))
    # Two-component unlink: d = -A^2 - A^-2.
    assert decode(*encode_poly(kauffman_bracket(Braid.from_short_form(2, [])))) == {2: -1, -2: -1}
    # Hopf link σ1²: V = -A^-10 - A^-2 in A.
    v = jones_values(2, [1, 1])
    assert decode(v.jones_exp_min, v.jones_width, v.jones_coefficients) == {-10: -1, -2: -1}
    # Figure-eight: amphichiral, V(A) = V(A^-1).
    v = jones_values(3, [1, -2, 1, -2])
    j = decode(v.jones_exp_min, v.jones_width, v.jones_coefficients)
    assert j == {-k: c for k, c in j.items()}


def test_encoding_round_trip_and_minimal_window():
    rng = random.Random(1)
    for _ in range(120):
        n = rng.randint(1, 5)
        w = random_word(rng, n, rng.randint(0, 8)) if n > 1 else []
        b = Braid.from_short_form(n, w)
        v = jones_values(n, w)
        assert decode(v.bracket_exp_min, v.bracket_width, v.bracket_coefficients) == \
            kauffman_bracket(b).to_int_dict()
        for lo, wd, cs in [(v.bracket_exp_min, v.bracket_width, v.bracket_coefficients),
                           (v.jones_exp_min, v.jones_width, v.jones_coefficients)]:
            assert len(cs) == wd
            if wd:
                assert cs[0] != 0 and cs[-1] != 0          # the window is the smallest one
            else:
                assert lo == 0


def test_jones_matches_polynomial_invariants():
    """The stored Jones polynomial in A is ``jones_polynomial`` after A^k ↦ t^{-k/4}."""
    rng = random.Random(2)
    for _ in range(80):
        n = rng.randint(1, 5)
        w = random_word(rng, n, rng.randint(0, 8)) if n > 1 else []
        v = jones_values(n, w)
        j = decode(v.jones_exp_min, v.jones_width, v.jones_coefficients)
        t = jones_polynomial(Braid.from_short_form(n, w)).to_int_dict()
        assert t == {-k // 2: c for k, c in j.items()}


def test_bracket_matches_state_sum():
    rng = random.Random(3)
    for _ in range(40):
        n = rng.randint(1, 4)
        w = random_word(rng, n, rng.randint(0, 9)) if n > 1 else []
        b = Braid.from_short_form(n, w)
        assert kauffman_bracket(b) == kauffman_bracket_state_sum(b)


def test_equal_braids_have_equal_certificates():
    rng = random.Random(4)
    for _ in range(60):
        n = rng.randint(2, 4)
        w1 = random_word(rng, n, rng.randint(0, 6))
        w2 = random_word(rng, n, rng.randint(0, 6))
        a, b = JonesRow.of(BraidRow.of(n, w1)), JonesRow.of(BraidRow.of(n, w2))
        if braid_group_equal(Braid.from_short_form(n, w1), Braid.from_short_form(n, w2)):
            assert bracket_equal(a, b) is True and jones_equal(a, b) is True
    assert jones_values(3, [1, 2, 1]) == jones_values(3, [2, 1, 2])
    assert jones_values(4, [1, -1, 3]) == jones_values(4, [3])


def test_markov_invariance():
    rng = random.Random(5)
    for _ in range(40):
        n = rng.randint(2, 4)
        x = random_word(rng, n, rng.randint(0, 4))
        y = random_word(rng, n, rng.randint(0, 5))
        conj = x + y + [-g for g in reversed(x)]
        assert jones_values(n, conj) == jones_values(n, y)          # conjugation
        shifted = [g + (1 if g > 0 else -1) for g in y]
        for s in (1, -1):                                           # stabilisation
            st = jones_values(n + 1, [s] + shifted)
            v = jones_values(n, y)
            assert (st.jones_exp_min, st.jones_width, st.jones_coefficients) == \
                (v.jones_exp_min, v.jones_width, v.jones_coefficients)


def test_non_isotopy_certificates():
    """Lean: hopf_not_unlink, trefoil_not_mirror, figureEight_not_trefoil,
    figureEight_not_unknot."""
    row = lambda n, w: JonesRow.of(BraidRow.of(n, w))
    assert non_isotopy_certified(row(2, [1, 1]), row(2, []))
    assert non_isotopy_certified(row(2, [1, 1, 1]), row(2, [-1, -1, -1]))
    assert non_isotopy_certified(row(3, [1, -2, 1, -2]), row(2, [1, 1, 1]))
    assert non_isotopy_certified(row(3, [1, -2, 1, -2]), row(1, []))
    # σ1σ2 on three strands is a stabilised unknot.
    assert jones_equal(row(3, [1, 2]), row(1, [])) is True
    assert non_conjugacy_certified(row(3, [1, -2, 1, -2]), row(3, [1, -2]))
    assert bracket_equal(row(3, [1]), row(2, [1])) is None       # different strand counts


def test_problems_of_tampered_certificates():
    braid = BraidRow.of(3, [1, -2, 1])
    good = JonesRow.of(braid)
    assert certificate_problems(good) == []
    fields = [good.bracket_exp_min, good.bracket_width, good.bracket_coefficients,
              good.jones_exp_min, good.jones_width, good.jones_coefficients]
    bad_hash = JonesRow(braid, "e" * 8, *fields)
    assert [r for r, _ in certificate_problems(bad_hash)] == ["braid_hash_mismatch"]
    shifted = JonesRow(braid, good.braid_hash, good.bracket_exp_min - 1, *fields[1:])
    assert [r for r, _ in certificate_problems(shifted)] == ["bracket_window_mismatch"]
    coeffs = list(good.bracket_coefficients)
    coeffs[0] += 1
    wrong = JonesRow(braid, good.braid_hash, fields[0], fields[1], tuple(coeffs), *fields[3:])
    assert certificate_problems(wrong) == [("bracket_coefficients_mismatch",
                                            {"recorded_length": len(coeffs),
                                             "expected_length": len(coeffs),
                                             "first_index": 0})]
    jw = JonesRow(braid, good.braid_hash, *fields[:3], good.jones_exp_min + 4, *fields[4:])
    assert [r for r, _ in certificate_problems(jw)] == ["jones_window_mismatch"]
    jc = JonesRow(braid, good.braid_hash, *fields[:5], tuple(-c for c in fields[5]))
    assert [r for r, _ in certificate_problems(jc)] == ["jones_coefficients_mismatch"]
    malformed = JonesRow(BraidRow(3, (1, 7), "h"), "h", 0, 0, (), 0, 0, ())
    assert certificate_problems(malformed) == [("braid_not_well_formed", {})]
    big = BraidRow.of(MAX_JONES_STRANDS + 1, [1])
    assert certificate_problems(JonesRow(big, big.braid_hash, 0, 0, (), 0, 0, ())) == [
        ("strand_count_too_large", {"strand_count": MAX_JONES_STRANDS + 1,
                                    "max": MAX_JONES_STRANDS})]
    with pytest.raises(ValueError, match="strand_count_too_large"):
        JonesRow.of(big)
    assert jones_equal(good, malformed) is None


def test_transport_and_nf_consistency_never_fire_on_correct_data():
    rng = random.Random(6)
    for _ in range(30):
        n = rng.randint(2, 4)
        w = random_word(rng, n, rng.randint(0, 6))
        a, b = JonesRow.of(BraidRow.of(n, w)), JonesRow.of(BraidRow.of(n, w + [1, -1]))
        assert transport_problems(True, a, b) == []
        assert nf_consistency_problems(a, NFRow.of(a.braid), [(b, NFRow.of(b.braid))]) == []
    a = JonesRow.of(BraidRow.of(2, [1, 1]))
    b = JonesRow.of(BraidRow.of(2, []))
    assert transport_problems(False, a, b) == []
    assert transport_problems(True, a, b) == [("bracket_not_preserved", {}),
                                              ("jones_not_preserved", {})]


def test_encode_poly_of_zero():
    assert encode_poly(Laurent()) == (0, 0, ())


def _lean_vectors():
    block = LEAN_VECTORS.read_text()
    rows = re.findall(r"\((\d+), \[([^\]]*)\], (-?\d+), (\d+), \[([^\]]*)\], (-?\d+), (\d+), "
                      r"\[([^\]]*)\]\)", block)

    def ints(s):
        return tuple(int(x) for x in s.split(",") if x.strip())

    return [(int(n), list(ints(w)), int(a), int(b), ints(c), int(d), int(e), ints(f))
            for n, w, a, b, c, d, e, f in rows]


def test_lean_vectors_match_python():
    """The test vectors of ``Formal/KauffmanBracket/Vectors.lean``
    (``jones_agrees_with_python``) are the values of this module."""
    vectors = _lean_vectors()
    assert len(vectors) >= 13
    for n, w, a, b, c, d, e, f in vectors:
        v = jones_values(n, w)
        assert (v.bracket_exp_min, v.bracket_width, v.bracket_coefficients,
                v.jones_exp_min, v.jones_width, v.jones_coefficients) == (a, b, c, d, e, f), (n, w)
