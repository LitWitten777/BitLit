"""Permutation, writhe, linking and polynomial invariants."""

from qbx_ir import Braid
from qbx_ir.algebra.invariants import (
    closure_components,
    is_positive,
    is_pure,
    linking_matrix,
    linking_number,
    permutation,
    permutation_one_line,
    writhe,
)
from qbx_ir.algebra.laurent import Laurent
from qbx_ir.algebra.polynomial_invariants import (
    alexander_polynomial,
    format_jones,
    jones_polynomial,
    kauffman_bracket,
)

B = Braid.from_short_form


def jones(b):
    return jones_polynomial(b).to_int_dict()


def test_permutation_conventions():
    b = B(3, [1, 2])
    assert permutation(b) == (2, 3, 1)  # strand at each final position
    assert permutation_one_line(b) == [3, 1, 2]  # final position of each strand
    assert is_pure(B(2, [1, 1])) and not is_pure(B(2, [1]))
    assert is_positive(B(3, [1, 2])) and not is_positive(B(3, [1, -2]))


def test_writhe_and_components():
    assert writhe(B(3, [1, -2, 1])) == 1
    assert closure_components(B(3, [1, 2])) == [[1, 3, 2]]
    assert len(closure_components(B(3, []))) == 3


def test_linking_numbers():
    assert linking_number(B(2, [1, 1])) == 1  # Hopf link
    assert linking_number(B(2, [-1, -1])) == -1
    assert linking_number(B(2, [1, 1, 1, 1])) == 2  # T(2,4)
    assert linking_number(B(2, [1, 1, 1])) == 0  # trefoil is a knot
    assert linking_matrix(B(3, [])) == {(0, 1): 0, (0, 2): 0, (1, 2): 0}


def test_jones_standard_values():
    assert jones(B(1, [])) == {0: 1}
    assert jones(B(2, [1])) == {0: 1}  # unknot
    assert jones(B(2, [1, 1, 1])) == {2: 1, 6: 1, 8: -1}  # right trefoil t + t³ − t⁴
    assert jones(B(2, [-1, -1, -1])) == {-2: 1, -6: 1, -8: -1}  # left trefoil
    assert jones(B(3, [1, -2, 1, -2])) == {4: 1, 2: -1, 0: 1, -2: -1, -4: 1}  # 4_1
    assert jones(B(2, [1, 1])) == {1: -1, 5: -1}  # Hopf: −t^{1/2} − t^{5/2}
    assert jones(B(2, [])) == {1: -1, -1: -1}  # 2-component unlink
    assert format_jones(jones_polynomial(B(2, [1, 1, 1]))) == "-t^4 + t^3 + t"


def test_bracket_normalisation():
    assert kauffman_bracket(B(1, [])) == Laurent.const(1)
    assert kauffman_bracket(B(2, [1])) == Laurent({3: -1})


def test_jones_markov_invariance():
    b = B(3, [1, -2, 1, 2])
    j = jones_polynomial(b)
    assert jones_polynomial(b.stabilize(1)) == j
    assert jones_polynomial(b.stabilize(-1)) == j
    c = B(3, [2])
    assert jones_polynomial(c * b * c.inverse()) == j


def test_alexander_standard_values():
    assert alexander_polynomial(B(2, [1, 1, 1])).to_int_dict() == {0: 1, 1: -1, 2: 1}
    assert alexander_polynomial(B(3, [1, -2, 1, -2])).to_int_dict() == {0: 1, 1: -3, 2: 1}
    assert alexander_polynomial(B(2, [1])).to_int_dict() == {0: 1}
    assert alexander_polynomial(B(2, [])).is_zero()  # split link
    # 5_1 = T(2,5): 1 − t + t² − t³ + t⁴
    assert alexander_polynomial(B(2, [1] * 5)).to_int_dict() == {0: 1, 1: -1, 2: 1, 3: -1, 4: 1}
