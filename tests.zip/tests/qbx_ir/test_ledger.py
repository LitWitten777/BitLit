"""The braid ledger reference (``qbx_ir.ledger``, migration 019).

``apply_short`` must be ``apply_rule`` on short forms, ``word_hash`` must be
``braid_hash``, and accepted derivations must connect braids that are equal in
B_n (the Garside normal form is the oracle; Lean: ``chainEnd_eval_eq``).
"""

from __future__ import annotations

import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.rewriting import ALL_RULES, apply_rule, braid_hash, find_matches
from qbx_ir.ledger import (
    BraidRow,
    RewriteRow,
    apply_short,
    braid_problems,
    derivation_end,
    derivation_problems,
    record_rewrite,
    rewrite_problems,
    word_hash,
)


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def test_apply_short_is_apply_rule():
    rng = random.Random(19)
    for _ in range(400):
        n = rng.randint(2, 5)
        w = random_word(rng, n, rng.randint(0, 7))
        b = Braid.from_short_form(n, w)
        for rule in ALL_RULES:
            matches = set(find_matches(b, rule))
            for k in range(-1, len(w) + 1):
                got = apply_short(w, rule.name, k)
                if k in matches:
                    assert got == apply_rule(b, rule, k)[0].short_form()
                else:
                    assert got is None
    assert apply_short([1, -1], "R04", 0) is None
    assert apply_short([1, -1], "R01", None) is None


def test_word_hash_is_braid_hash():
    rng = random.Random(7)
    for _ in range(100):
        n = rng.randint(1, 6)
        w = random_word(rng, n, rng.randint(0, 6)) if n > 1 else []
        assert word_hash(n, w) == braid_hash(Braid.from_short_form(n, w))


def test_braid_problems():
    assert braid_problems(BraidRow.of(3, [1, -2, 1])) == []
    assert braid_problems(BraidRow.of(0, [])) == [("strand_count", {"strand_count": 0})]
    assert braid_problems(BraidRow.of(3, [1, 0, 3, -2])) == [
        ("letter", {"position": 1, "letter": 0}),
        ("letter", {"position": 2, "letter": 3}),
    ]
    bad = BraidRow(3, (1,), "00")
    assert braid_problems(bad) == [("hash", {"recorded": "00", "expected": word_hash(3, [1])})]


def test_rewrite_problems():
    b = BraidRow.of(3, [1, 2, 1])
    good = record_rewrite(b, "R03", 0)
    assert good.output.word == (2, 1, 2)
    assert rewrite_problems(good) == []
    wrong = RewriteRow(b, "R03", 0, BraidRow.of(3, [2, 1, 1]), good.input_hash,
                       word_hash(3, [2, 1, 1]), good.preserved, good.changed)
    assert rewrite_problems(wrong) == [
        ("output_mismatch", {"expected": [2, 1, 2], "recorded": [2, 1, 1]})]
    not_app = RewriteRow(b, "R01", 0, b, b.braid_hash, b.braid_hash,
                         good.preserved, ("word_length",))
    assert rewrite_problems(not_app) == [("not_applicable", {"rule": "R01", "position": 0})]
    unknown = RewriteRow(b, "R09", 0, b, b.braid_hash, b.braid_hash, (), ())
    assert rewrite_problems(unknown) == [("rule_unknown", {"rule": "R09"})]
    decl = RewriteRow(b, "R03", 0, good.output, good.input_hash, good.output_hash,
                      ("writhe",), good.changed)
    assert [p[0] for p in rewrite_problems(decl)] == ["declaration_mismatch"]
    with pytest.raises(ValueError):
        record_rewrite(b, "R01", 0)


def test_derivation_problems_and_soundness():
    """Random chains: accepted ones connect braids equal in B_n."""
    rng = random.Random(2026)
    accepted = 0
    for _ in range(200):
        n = rng.randint(3, 5)
        start = BraidRow.of(n, random_word(rng, n, rng.randint(0, 6)))
        cur = start
        steps, dirs = [], []
        for _ in range(rng.randint(0, 6)):
            options = []
            for rule in ("R01", "R02", "R03"):
                for k in range(len(cur.word)):
                    if apply_short(cur.word, rule, k) is not None:
                        options.append((rule, k))
            if rng.random() < 0.4 or not options:
                # a backward step: insert a cancelling pair, recorded as an R01 rewrite
                i = rng.randint(1, n - 1) * rng.choice([1, -1])
                k = rng.randint(0, len(cur.word))
                bigger = BraidRow.of(n, list(cur.word[:k]) + [i, -i] + list(cur.word[k:]))
                steps.append(record_rewrite(bigger, "R01", k))
                dirs.append(False)
                cur = bigger
            else:
                rule, k = rng.choice(options)
                t = record_rewrite(cur, rule, k)
                steps.append(t)
                dirs.append(True)
                cur = t.output
        assert derivation_problems(start, cur, steps, dirs) == []
        end = derivation_end(start, steps, dirs)
        assert end is not None and end.key == cur.key
        assert braid_group_equal(Braid.from_short_form(n, list(start.word)),
                                 Braid.from_short_form(n, list(cur.word)))
        accepted += 1
        if steps:
            k = rng.randrange(len(steps))
            flipped = dirs[:k] + [not dirs[k]] + dirs[k + 1:]
            probs = derivation_problems(start, cur, steps, flipped)
            assert probs, "flipping a direction must break the chain"
    assert accepted == 200


def test_derivation_problem_kinds():
    b = BraidRow.of(3, [1, 2, 1])
    t = record_rewrite(b, "R03", 0)
    assert derivation_problems(b, b, [t], []) == [("steps_shape", {"steps": 1, "directions": 0})]
    assert derivation_problems(b, b, [None], [True]) == [("step_unknown", {"step": 0})]
    assert derivation_problems(b, b, [t], [False]) == [("step_disconnected", {"step": 0})]
    assert derivation_problems(b, b, [t], [True]) == [("target_mismatch", {})]
    assert derivation_problems(b, t.output, [t, t], [True, False]) == [("target_mismatch", {})]
    assert derivation_problems(b, b, [t, t], [True, False]) == []
    assert derivation_problems(b, b, [], []) == []
