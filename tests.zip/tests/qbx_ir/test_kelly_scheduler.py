"""
Tests of the Kelly-allocated graduated multi-prover against the Lean theorems of
``QBX/Formal/MultiProver/KellyAllocation.lean`` and ``KellyScheduler.lean``
(each test names its oracle).
"""

import random
from fractions import Fraction

import pytest

from qbx_ir import Braid
from qbx_ir.algebra.kelly_scheduler import (
    KellyMultiProver,
    TierStats,
    alloc_ticks,
    default_cost,
    kelly_weight,
    tick_share,
    timed_scheduled_reading,
)
from qbx_ir.algebra.multiprover import verdict


def B(word, n=3):
    return Braid.from_short_form(n, list(word))


def random_word(rng, n, length):
    return [rng.choice([i for i in range(-(n - 1), n) if i != 0]) for _ in range(length)]


def equal_variant(rng, n, word):
    """A different word for the same braid: insert cancelling pairs and apply
    braid relations."""
    w = list(word)
    for _ in range(3):
        i = rng.randrange(0, len(w) + 1)
        g = rng.choice([k for k in range(1, n)])
        w[i:i] = [g, -g] if rng.random() < 0.5 else [-g, g]
    # one Yang–Baxter insertion  s1 s2 s1 (s2 s1 s2)^-1
    if n >= 3:
        i = rng.randrange(0, len(w) + 1)
        w[i:i] = [1, 2, 1, -2, -1, -2]
    return w


# ---- KellyAllocation.lean ---------------------------------------------------


def test_worked_examples():
    """The `example`s at the end of KellyAllocation.lean."""
    ws = [Fraction(1, 2), Fraction(0), Fraction(1, 4)]
    assert alloc_ticks(100, 5, ws) == [61, 5, 33]
    assert kelly_weight(TierStats(), 3) == Fraction(1, 3)
    assert kelly_weight(TierStats(2, 0), 3) == 0


def test_allocation_floor_and_budget():
    """floor_le_tickShare, allocTicks_sum_le, tickShare_dead, tickShare_mono."""
    rng = random.Random(3)
    for _ in range(300):
        k = rng.randrange(0, 6)
        ws = [Fraction(rng.randrange(0, 5), rng.randrange(1, 6)) for _ in range(k)]
        floor = rng.randrange(0, 10)
        total = floor * k + rng.randrange(0, 200)
        a = alloc_ticks(total, floor, ws)
        assert len(a) == k
        assert all(x >= floor for x in a)
        assert sum(a) <= total
        if sum(ws) != 0:
            assert tick_share(total, floor, ws, Fraction(0)) == floor
        for w1 in ws:
            for w2 in ws:
                if w1 <= w2:
                    assert tick_share(total, floor, ws, w1) <= tick_share(total, floor, ws, w2)


def test_dead_after_failures():
    """kellyWeight_eq_zero_of_failures and kellyWeight_pos_iff."""
    for b in [Fraction(1, 2), Fraction(1), Fraction(3), Fraction(7, 2), Fraction(10)]:
        for a in range(0, 15):
            s = TierStats(a, 0)
            if b <= a + 1:
                assert kelly_weight(s, b) == 0
            assert (kelly_weight(s, b) > 0) == (s.rate * (b + 1) > 1)


def test_stats_valid():
    """Valid.record, rate_pos, rate_lt_one."""
    s = TierStats()
    rng = random.Random(1)
    for _ in range(50):
        s = s.record(rng.random() < 0.3)
        assert s.decisions <= s.attempts
        assert 0 < s.rate < 1


# ---- KellyScheduler.lean ----------------------------------------------------


def _claims(rng, count, n=3, length=12):
    out = []
    for _ in range(count):
        w = random_word(rng, n, length)
        if rng.random() < 0.5:
            out.append((B(w, n), B(equal_variant(rng, n, w), n)))
        else:
            out.append((B(w, n), B(random_word(rng, n, length), n)))
    return out


@pytest.mark.parametrize("n", [3, 4])
def test_graduated_equals_verdict(n):
    """graduatedLoop_channels_eq_verdict: every answer equals the machine's verdict,
    for any statistics (here: an adapting stream with exploration)."""
    rng = random.Random(7 + n)
    prover = KellyMultiProver(explore_every=4)
    for b1, b2 in _claims(rng, 40, n=n, length=10):
        r = prover.decide(b1, b2)
        assert r.verdict == verdict(b1, b2).verdict
        if r.decided_by != "fold":
            assert r.verdict == "REFUTED"


def test_answers_independent_of_budget():
    """graduated_channels_eq_verdict holds for all budgets and floors."""
    rng = random.Random(11)
    claims = _claims(rng, 12)
    for bf, ff in [(0, 0), (Fraction(1, 10), 0), (1, 0), (5, 1), (100, 100)]:
        prover = KellyMultiProver(budget_factor=Fraction(bf), floor_factor=Fraction(ff))
        for b1, b2 in claims:
            assert prover.decide(b1, b2).verdict == verdict(b1, b2).verdict


def test_kelly_kills_refuters_on_true_claims():
    """On a stream of true identities no refuter ever refutes; their Kelly weights
    drop to 0 (kellyWeight_eq_zero_of_failures) and the expensive ones are skipped."""
    rng = random.Random(5)
    prover = KellyMultiProver(explore_every=0)
    for _ in range(30):
        w = random_word(rng, 3, 16)
        r = prover.decide(B(w), B(equal_variant(rng, 3, w)))
        assert r.verdict == "PROVED"
    assert all(prover.stats[c].decisions == 0 for c in prover.refuters)
    assert "anchor" in r.skipped and "harmonic" in r.skipped


def test_cheap_refuters_save_fold_runs_on_false_claims():
    """On a stream of false claims the cheap link refuter (payoff ≫ 1, never dead)
    decides most claims, so the complete fold channel runs only on the rest
    (graduatedRun_of_decided)."""
    rng = random.Random(9)
    prover = KellyMultiProver()
    by = []
    for _ in range(40):
        by.append(prover.decide(B(random_word(rng, 3, 14)), B(random_word(rng, 3, 14))).decided_by)
    assert prover.fold_runs == by.count("fold")
    assert by.count("link") > 20
    assert prover.fold_runs < 20


def test_cost_model_positive():
    b = B([1, 2, -1] * 5)
    for c in ("link", "oscillator", "anchor", "harmonic", "fold"):
        assert default_cost(c, b, b) > 0


def test_timed_scheduled_reading():
    """Instrumentation: phases are timed and the reconstruction covers the four
    non-homomorphic channels."""
    t = timed_scheduled_reading(B(random_word(random.Random(2), 3, 200)), chunk_size=32)
    assert t.chunks == 7
    assert set(t.reconstruct) == {"fold", "link", "oscillator", "harmonic"}
    assert 0 <= t.reconstruct_fraction(1) <= 1
    assert t.reconstruct_fraction(8) >= t.reconstruct_fraction(1)
