"""Exact representation matrices (qbx_ir.quantum.exact) and the reference
implementation of the representation certificates of migration 022
(qbx_ir.representation_ledger)."""

from __future__ import annotations

import random
from fractions import Fraction

import numpy as np
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.core.equality import EqualityKind, check_equality
from qbx_ir.ledger import BraidRow, word_hash
from qbx_ir.normal_form_ledger import NFRow
from qbx_ir.quantum.exact import (
    ExactMatrix,
    ExactSL2Representation,
    exact_sl2_matrix,
    reduce_fraction,
    scaled_generators,
)
from qbx_ir.quantum.r_matrix import SL2RMatrix
from qbx_ir.quantum.representation import representation_alt
from qbx_ir.representation_ledger import (
    MAX_REP_STRANDS,
    RepRow,
    certificate_problems,
    inequality_certified,
    nf_consistency_problems,
    representations_equal,
    transport_problems,
)

PARAMS = [(2, 1), (3, 2), (-1, 3), (5, 7), (-2, 1)]


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


def test_exact_matches_numpy():
    rng = random.Random(3)
    for _ in range(100):
        n = rng.randint(1, 4)
        w = random_word(rng, n, rng.randint(0, 7)) if n > 1 else []
        p, r = rng.choice(PARAMS)
        m = exact_sl2_matrix(n, w, p, r)
        u = representation_alt(Braid.from_short_form(n, w), SL2RMatrix(p / r))
        e = np.array([[float(x) for x in row] for row in m.to_fractions()])
        assert np.allclose(e, u, atol=1e-9 * (1 + np.abs(u).max()))


def test_reduced_and_canonical():
    rng = random.Random(4)
    for _ in range(60):
        n = rng.randint(1, 4)
        w = random_word(rng, n, rng.randint(0, 7)) if n > 1 else []
        p, r = rng.choice(PARAMS)
        m = exact_sl2_matrix(n, w, p, r)
        assert m.denominator > 0
        assert reduce_fraction(m.numerators, m.denominator) == (m.numerators, m.denominator)
        # Any other representation of the same fraction reduces to the same pair.
        k = rng.choice([-3, -1, 2, 5])
        assert reduce_fraction([k * x for x in m.numerators], k * m.denominator) == \
            (m.numerators, m.denominator)


def test_scaled_generators_are_scaled_r_matrices():
    for p, r in PARAMS:
        q = Fraction(p, r)
        pos, neg = scaled_generators(p, r)
        R = SL2RMatrix(float(q))
        assert np.allclose(np.array(pos, dtype=float), p * r * R.matrix().real)
        assert np.allclose(np.array(neg, dtype=float), p * r * R.inverse_matrix().real)


def test_braid_relations_hold_exactly():
    for p, r in PARAMS:
        for n in (3, 4):
            for i in range(1, n - 1):
                assert exact_sl2_matrix(n, [i, i + 1, i], p, r) == \
                    exact_sl2_matrix(n, [i + 1, i, i + 1], p, r)
            for i in range(1, n):
                assert exact_sl2_matrix(n, [i, -i], p, r) == exact_sl2_matrix(n, [], p, r)
        assert exact_sl2_matrix(4, [1, 3], p, r) == exact_sl2_matrix(4, [3, 1], p, r)


def test_commutator_example():
    """σ1²σ2²σ1⁻²σ2⁻²: same permutation, writhe and linking as the identity, but a different
    exact matrix (Lean: representation_detects_more)."""
    m = exact_sl2_matrix(3, [1, 1, 2, 2, -1, -1, -2, -2])
    assert m.denominator == 64
    assert m != exact_sl2_matrix(3, [])


def test_equality_api_is_exact():
    rho = ExactSL2Representation(Fraction(3, 2))
    a, b = Braid.from_short_form(3, [1, 2, 1]), Braid.from_short_form(3, [2, 1, 2])
    res = check_equality(a, b, EqualityKind.REPRESENTATION, representation_fn=rho)
    assert res.equal and res.certain and "exact" in res.details
    c = Braid.from_short_form(3, [1])
    assert not check_equality(a, c, EqualityKind.REPRESENTATION, representation_fn=rho).equal
    with pytest.raises(ValueError):
        ExactSL2Representation(0)
    with pytest.raises(ValueError):
        exact_sl2_matrix(2, [1], 2, 4)


def test_certificates_and_problems():
    b = BraidRow.of(3, [1, 2, 1])
    c = RepRow.of(b, 3, 2)
    assert certificate_problems(c) == []
    assert c.dimension == 8 and isinstance(exact_sl2_matrix(3, [1, 2, 1], 3, 2), ExactMatrix)
    bad = RepRow(b, 3, 2, "x", 4, c.numerators[:-1], 2 * c.denominator)
    assert [r for r, _ in certificate_problems(bad)] == [
        "braid_hash_mismatch", "dimension_mismatch", "denominator_mismatch", "numerators_mismatch"]
    assert certificate_problems(RepRow(b, 2, 4, b.braid_hash, 8, c.numerators, 1)) == [
        ("parameter_invalid", {"q_num": 2, "q_den": 4})]
    big = BraidRow.of(MAX_REP_STRANDS + 1, [1])
    assert certificate_problems(RepRow(big, 2, 1, big.braid_hash, 0, (), 1)) == [
        ("strand_count_too_large", {"strand_count": MAX_REP_STRANDS + 1, "max": MAX_REP_STRANDS})]
    malformed = BraidRow(3, (1, 7), "h")
    assert certificate_problems(RepRow(malformed, 2, 1, "h", 8, (), 1)) == [
        ("braid_not_well_formed", {})]
    with pytest.raises(ValueError):
        RepRow.of(malformed)


def test_equal_braids_have_equal_certificates_and_different_ones_are_different():
    rng = random.Random(8)
    for _ in range(80):
        n = rng.randint(2, 4)
        w1 = random_word(rng, n, rng.randint(0, 6))
        w2 = random_word(rng, n, rng.randint(0, 6)) if rng.random() < 0.5 else \
            w1 + [1, -1]
        q = rng.choice(PARAMS)
        a, b = RepRow.of(BraidRow.of(n, w1), *q), RepRow.of(BraidRow.of(n, w2), *q)
        eq = representations_equal(a, b)
        truth = braid_group_equal(Braid.from_short_form(n, w1), Braid.from_short_form(n, w2))
        if truth:
            assert eq is True
        if eq is False:
            assert not truth and inequality_certified(a, b)
    a, b = RepRow.of(BraidRow.of(3, [1])), RepRow.of(BraidRow.of(3, [1]), 3, 2)
    assert representations_equal(a, b) is None                  # different parameters
    assert representations_equal(a, RepRow.of(BraidRow.of(4, [1]))) is None


def test_transport_and_consistency():
    x, e = BraidRow.of(3, [1, -1]), BraidRow.of(3, [])
    cx, ce = [RepRow.of(x), RepRow.of(x, 3, 2)], [RepRow.of(e)]
    assert transport_problems(True, cx, ce) == []
    wrong = RepRow(e, 2, 1, e.braid_hash, 8, cx[0].numerators, 7)    # an invalid certificate
    assert transport_problems(True, cx, [wrong]) == []               # not comparable
    s1, s2 = BraidRow.of(3, [1]), BraidRow.of(3, [2])
    assert transport_problems(True, [RepRow.of(s1)], [RepRow.of(s2)]) == [
        ("representation_not_preserved", {"q_num": 2, "q_den": 1})]
    assert transport_problems(False, [RepRow.of(s1)], [RepRow.of(s2)]) == []
    nx, ne = NFRow.of(x), NFRow.of(e)
    assert nf_consistency_problems(cx[0], nx, [(ce[0], ne)]) == []
    # A forged pair: s2's certificate claimed for a braid whose normal form equals s1's.
    forged = RepRow.of(s2)
    assert nf_consistency_problems(RepRow.of(s1), NFRow.of(s1),
                                   [(forged, NFRow.of(BraidRow.of(3, [1, 2, -2])))]) == [
        ("representation_contradicts_normal_form", {"other_braid_hash": s2.braid_hash})]
    assert word_hash(3, [2]) == s2.braid_hash
