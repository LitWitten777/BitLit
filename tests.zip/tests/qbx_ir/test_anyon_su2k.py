"""SU(2)_k anyons (from Phase D work stream D6, integrated into qbx_ir.anyon 2026-10-04) — fusion, pentagon and hexagons (k = 2…5), and the
cross-checks against the shipped Ising and Fibonacci models."""
import cmath
import math

import numpy as np
import pytest
from hypothesis import given, settings
from hypothesis import strategies as st

from qbx_ir.anyon import SU2k, label_name, su2k_model
from qbx_ir.anyon.coherence import (find_gauge, from_anyon_model, fs_indicators,
                                gauge_transform, hexagon_residual,
                                pentagon_residual, restrict,
                                topological_spins, unitarity_residual)

TOL = 1e-10


def test_labels_and_fusion():
    m = SU2k(3)
    assert [label_name(a) for a in m.labels] == ["0", "1/2", "1", "3/2"]
    assert m.fuse(1, 1) == [0, 2]            # 1/2 ⊗ 1/2 = 0 ⊕ 1
    assert m.fuse(2, 2) == [0, 2]            # 1 ⊗ 1 = 0 ⊕ 1 (truncated at k = 3)
    assert m.fuse(3, 3) == [0]               # 3/2 ⊗ 3/2 = 0
    assert m.fuse(1, 3) == [2]


def test_quantum_dimensions():
    phi = (1 + math.sqrt(5)) / 2
    assert SU2k(2).qdim(1) == pytest.approx(math.sqrt(2))
    assert SU2k(3).qdim(2) == pytest.approx(phi)
    for k in range(1, 7):
        m = SU2k(k)
        assert m.total_dimension() ** 2 == pytest.approx(
            (k + 2) / (2 * math.sin(math.pi / (k + 2)) ** 2))


@pytest.mark.parametrize("k", [2, 3, 4, 5])
@pytest.mark.parametrize("conjugate", [False, True])
def test_pentagon_hexagons_unitarity(k, conjugate):
    m = SU2k(k, conjugate).data()
    assert pentagon_residual(m) < TOL
    assert hexagon_residual(m) < TOL
    assert hexagon_residual(m, reverse=True) < TOL
    assert unitarity_residual(m) < TOL


@settings(deadline=None, derandomize=True, max_examples=300)
@given(st.integers(2, 5), st.lists(st.integers(0, 5), min_size=9, max_size=9))
def test_pentagon_on_random_label_tuples(k, labels):
    m = SU2k(k)
    a, b, c, d, e, f, g, kk, l = (x % (k + 1) for x in labels)
    F = m.F
    lhs = F(f, c, d, e, g, l) * F(a, b, l, e, f, kk)
    rhs = sum(F(a, b, c, g, f, h) * F(a, h, d, e, g, kk) * F(b, c, d, kk, h, l)
              for h in m.labels)
    assert abs(lhs - rhs) < TOL


def test_spin_of_half_at_level_2():
    """θ_{1/2} = e^{2πi·3/16} for SU(2)_2 (brief), against e^{2πi/16} for Ising σ."""
    assert SU2k(2).theta(1) == pytest.approx(cmath.exp(2j * math.pi * 3 / 16))
    spins = topological_spins(SU2k(2).data())
    assert spins[1] == pytest.approx(cmath.exp(2j * math.pi * 3 / 16))


def test_theta_from_R_matches_formula():
    for k in range(1, 6):
        m = SU2k(k)
        assert np.allclose(topological_spins(m.data()), [m.theta(a) for a in m.labels])


# ---- cross-checks with the shipped models ---------------------------------

def _models():
    pytest.importorskip("numpy")
    from qbx_ir.anyon import fibonacci_model, ising_model
    return from_anyon_model(ising_model()), from_anyon_model(fibonacci_model())


def test_su2_2_vs_ising():
    """Same fusion rules, different braided categories: θ_{1/2} ≠ θ_σ and the
    Frobenius–Schur indicator of 1/2 is −1 (Ising σ: +1); both are gauge
    invariant, so no gauge relates the F/R data."""
    ising, _ = _models()
    s2 = SU2k(2).data()
    assert np.array_equal(s2.N, ising.N)
    ts, ti = topological_spins(s2), topological_spins(ising)
    assert ts[1] == pytest.approx(cmath.exp(2j * math.pi * 3 / 16))
    assert ti[1] == pytest.approx(cmath.exp(2j * math.pi / 16))
    assert ts[2] == pytest.approx(-1) and ti[2] == pytest.approx(-1)   # ψ / spin 1 agree
    assert fs_indicators(s2)[1] == pytest.approx(-1)
    assert fs_indicators(ising)[1] == pytest.approx(1)
    assert find_gauge(s2, ising) is None
    # what does agree: the F- and R-data of the ψ / spin-1 sector
    assert s2.F[2, 1, 2, 1, 1, 1] == pytest.approx(ising.F[2, 1, 2, 1, 1, 1])
    assert s2.R[2, 2, 0] == pytest.approx(ising.R[2, 2, 0])


def test_su2_3_integer_part_is_fibonacci():
    """The integer-spin part {0, 1} of SU(2)_3 is Fibonacci (not its complex
    conjugate), in the gauge u^{ττ}_τ = i (which flips the sign of the
    off-diagonal entries of F^{τττ}_τ); R-symbols agree without any gauge."""
    _, fib = _models()
    s3 = restrict(SU2k(3).data(), [0, 2])
    assert np.array_equal(s3.N, fib.N)
    assert pentagon_residual(s3) < TOL and hexagon_residual(s3) < TOL
    assert np.allclose(s3.R, fib.R)
    gauge = find_gauge(s3, fib)
    assert gauge == {(1, 1, 0): 1, (1, 1, 1): 1j}
    g = gauge_transform(s3, gauge)
    assert np.abs(g.F - fib.F).max() < TOL
    assert find_gauge(restrict(SU2k(3, conjugate=True).data(), [0, 2]), fib) is None
    assert np.allclose(topological_spins(s3), topological_spins(fib))


def test_shipped_models_pass_the_same_checks():
    ising, fib = _models()
    for m in (ising, fib):
        assert pentagon_residual(m) < TOL
        assert hexagon_residual(m) < TOL
        assert hexagon_residual(m, reverse=True) < TOL


@pytest.mark.parametrize("k", [1, 2, 3])
def test_su2k_model_is_anyon_model(k):
    """`su2k_model(k)` packages the same data as an `AnyonModel`."""
    from qbx_ir.anyon import AnyonModel
    m = su2k_model(k)
    assert isinstance(m, AnyonModel)
    s = SU2k(k)
    assert m.labels == tuple(label_name(a) for a in s.labels)
    assert m.f_unitarity_residual() < 1e-10
    for a in s.labels:
        for b in s.labels:
            assert m.fuse(label_name(a), label_name(b)) == frozenset(
                label_name(c) for c in s.fuse(a, b))
            for c in s.fuse(a, b):
                if a and b:
                    assert m.r_symbol(label_name(a), label_name(b), label_name(c)) == \
                        pytest.approx(s.R(a, b, c))
    assert m.total_quantum_dimension() == pytest.approx(s.total_dimension())
