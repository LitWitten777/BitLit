"""Container format (decision CNT-001): descriptors, curvature rules, composition, versioning."""

from __future__ import annotations

import copy
import json

import pytest

from qbx_containers import (
    Container,
    can_embed,
    classify_profile,
    classify_revision,
    compose_product,
    compose_sum,
    development,
    load_registry,
    volume_profile,
)
from qbx_containers.registry import Composite


@pytest.fixture(scope="module")
def reg():
    return load_registry()


def test_shipped_registry_is_clean(reg):
    bad = {n: e for n, (e, _) in reg.check().items() if e}
    assert bad == {}


@pytest.mark.parametrize("spec,expected", [
    ("hypercube(6)", "positive"), ("finite(8)", "positive"),
    ("lattice(1)", "flat"), ("lattice(3)", "flat"), ("torus(8,8)", "flat"),
    ("tree(2)", "negative"), ("free(6)", "negative"),
    ("product(tree(2);hypercube(4))", "negative"), ("product(lattice(2);hypercube(4))", "flat"),
])
def test_profile_classes_match_lean_theorems(spec, expected):
    # Lean: hypercube_correct, lattice_correct (+ torusCover_surjective), tree_correct,
    # tree_prod_hypercube_correct, lattice_prod_hypercube_correct.
    prof = volume_profile(development(spec), 40)
    got = "positive" if spec.startswith("finite") else classify_profile(prof)
    assert got == expected


def test_volume_formulas():
    assert volume_profile("hypercube(4)", 5) == [1, 5, 11, 15, 16, 16]
    assert volume_profile("lattice(2)", 3) == [1, 5, 13, 25]       # centred square numbers
    assert volume_profile("tree(2)", 3) == [1, 3, 7, 15]
    assert volume_profile("torus(4,4)", 5)[-1] == 16


def test_product_table_is_lean_table():
    order = ["positive", "flat", "negative"]
    for a in order:
        for b in order:
            assert compose_product(a, b) == order[max(order.index(a), order.index(b))]
            assert compose_product(a, b) == compose_product(b, a)
    assert compose_sum(["positive", "flat"]) == "flat"


def _mk(**kw):
    base = dict(name="x", version="1.0.0", curvature="flat", carrier="lattice(2)",
                metric={"formula": "l1"}, algebra=["translation"], boundary={"kind": "none"})
    base.update(kw)
    return Container.from_dict(base)


def test_wrong_declaration_detected(reg):
    errs, _ = reg.check_container(_mk(curvature="positive", algebra=[]))
    assert any("volume profile" in e for e in errs)


def test_forbidden_operation_detected(reg):
    errs, _ = reg.check_container(_mk(name="q", curvature="positive", carrier="hypercube(3)",
                                      algebra=["translation"], boundary={"kind": "closed"}))
    assert any("translation" in e for e in errs)
    errs, _ = reg.check_container(_mk(curvature="negative", carrier="tree(2)",
                                      algebra=["o1_random_access"], boundary={"kind": "leaves"}))
    assert any("o1_random_access" in e for e in errs)


def test_unresolved_lean_reference_detected(reg):
    errs, _ = reg.check_container(_mk(lean={"correctness": "QBX.Formal.Foundations.no_such_theorem"}))
    assert any("does not resolve" in e for e in errs)


def test_undeclared_curvature_change_detected(reg):
    d = copy.deepcopy(reg.composites["hebrew_pipeline"].data)
    d["transitions"][2]["curvature_changing"] = False
    errs, _ = reg.check_composite(Composite("p", "pipeline", d))
    assert any("not declared curvature_changing" in e for e in errs)


def test_wrong_composite_declaration_detected(reg):
    d = dict(name="c", kind="product", factors=["cache_tree", "hypercube_q4"], curvature="positive")
    errs, _ = reg.check_composite(Composite("c", "product", d))
    assert any("composition rules give negative" in e for e in errs)


def test_bundle_needs_connection(reg):
    d = dict(name="b", kind="bundle", base="torus_8x8", fiber="hypercube_q4")
    errs, _ = reg.check_composite(Composite("b", "bundle", d))
    assert any("connection" in e for e in errs)


def test_versioning_rule():
    a = _mk()
    assert classify_revision(a, _mk(curvature="negative", carrier="tree(2)")) == "new_container"
    assert classify_revision(a, _mk(metric={"formula": "l2"})) == "major"
    assert classify_revision(a, _mk(algebra=["translation", "fft"])) == "minor"
    assert classify_revision(a, _mk(algebra=[])) == "major"
    assert classify_revision(a, _mk(notes="doc")) == "patch"


def test_tree_does_not_fit_in_small_flat_container():
    # design example: a 2^20-leaf tree into a flat container of diameter 40
    tree = volume_profile("tree(2)", 20)
    flat = volume_profile("lattice(2)", 40)
    assert can_embed(tree, flat, stretch=2) is not None
    assert can_embed(volume_profile("lattice(1)", 20), flat) is None


def test_descriptors_are_valid_json_files(reg):
    for c in reg.containers.values():
        json.loads(c.path.read_text())
