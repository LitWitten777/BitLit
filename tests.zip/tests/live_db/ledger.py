"""Small helper for building categorical data in the live test database.

Composition convention (shared with ``qbx.db.repositories.CategoryRepository``):
``composition(left_id = g, right_id = f, result_id = h)`` records ``h = g ∘ f``
— ``f`` is applied first.
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple


class Ledger:
    def __init__(self, conn):
        self.conn = conn
        self.ids: Dict[str, str] = {}
        self.cat_of: Dict[str, str] = {}
        self.morphisms: Dict[str, List[str]] = {}   # category name -> morphism names
        self.composites: List[str] = []             # morphisms recorded as composites

    # -- low level -----------------------------------------------------
    def q(self, sql: str, *args):
        with self.conn.cursor() as cur:
            cur.execute(sql, args)
            try:
                return cur.fetchall()
            except Exception:  # no result set
                return None

    def one(self, sql: str, *args):
        rows = self.q(sql, *args)
        return rows[0][0] if rows else None

    def set_mode(self, mode: str) -> None:
        self.q("SELECT set_config('qbx.enforcement_mode', %s, true)", mode)

    # -- categories ----------------------------------------------------
    def category(self, name: str) -> str:
        cid = self.one("INSERT INTO category (name) VALUES (%s) RETURNING id", name)
        self.ids[name] = cid
        return cid

    def obj(self, cat: str, name: str) -> str:
        cid = self.ids[cat]
        oid = self.one(
            "INSERT INTO object (category_id, name) VALUES (%s, %s) RETURNING id", cid, name
        )
        self.ids[name] = oid
        self.cat_of[name] = cat
        mid = self.one(
            "INSERT INTO morphism (category_id, source_id, target_id, name) "
            "VALUES (%s, %s, %s, %s) RETURNING id",
            cid, oid, oid, "id_" + name,
        )
        self.ids["id_" + name] = mid
        self.cat_of["id_" + name] = cat
        self.morphisms.setdefault(cat, []).append("id_" + name)
        self.q(
            "INSERT INTO identity_morphism (category_id, object_id, morphism_id) VALUES (%s, %s, %s)",
            cid, oid, mid,
        )
        return oid

    def mor(self, name: str, src: str, tgt: str) -> str:
        cat = self.cat_of[src]
        mid = self.one(
            "INSERT INTO morphism (category_id, source_id, target_id, name) "
            "VALUES (%s, %s, %s, %s) RETURNING id",
            self.ids[cat], self.ids[src], self.ids[tgt], name,
        )
        self.ids[name] = mid
        self.cat_of[name] = cat
        self.morphisms.setdefault(cat, []).append(name)
        return mid

    def comp(self, g: str, f: str, h: str) -> None:
        """Record ``h = g ∘ f`` (``f`` first)."""
        self.q(
            "INSERT INTO composition (category_id, left_id, right_id, result_id) "
            "VALUES (%s, %s, %s, %s)",
            self.ids[self.cat_of[h]], self.ids[g], self.ids[f], self.ids[h],
        )
        self.composites.append(h)

    # -- functors and transformations ---------------------------------
    def functor(self, name: str, src_cat: str, tgt_cat: str,
                objs: Dict[str, str], mors: Dict[str, str]) -> str:
        fid = self.one(
            "INSERT INTO functor (name, source_category_id, target_category_id) "
            "VALUES (%s, %s, %s) RETURNING id",
            name, self.ids[src_cat], self.ids[tgt_cat],
        )
        self.ids[name] = fid
        for a, b in objs.items():
            self.q(
                "INSERT INTO functor_object_map (functor_id, source_object_id, target_object_id) "
                "VALUES (%s, %s, %s)", fid, self.ids[a], self.ids[b],
            )
        for a, b in mors.items():
            self.q(
                "INSERT INTO functor_morphism_map (functor_id, source_morphism_id, target_morphism_id) "
                "VALUES (%s, %s, %s)", fid, self.ids[a], self.ids[b],
            )
        return fid

    def nt(self, name: str, src_functor: str, tgt_functor: str,
           components: Optional[Dict[str, str]] = None) -> str:
        tid = self.one(
            "INSERT INTO natural_transformation (name, source_functor_id, target_functor_id) "
            "VALUES (%s, %s, %s) RETURNING id",
            name, self.ids[src_functor], self.ids[tgt_functor],
        )
        self.ids[name] = tid
        for x, m in (components or {}).items():
            self.component(name, x, m)
        return tid

    def component(self, nt: str, x: str, m: str) -> None:
        self.q(
            "INSERT INTO natural_transformation_component (transformation_id, object_id, morphism_id) "
            "VALUES (%s, %s, %s)", self.ids[nt], self.ids[x], self.ids[m],
        )

    def naturality_violations(self, nt: str):
        return self.q(
            "SELECT law, morphism_f FROM naturality_violation WHERE transformation_id = %s",
            self.ids[nt],
        )

    def adjunction(self, name: str, F: str, G: str, unit: str, counit: str) -> str:
        """Insert via ``register_adjunction`` (the insert trigger runs the check)."""
        aid = self.one(
            "SELECT register_adjunction(%s, %s, %s, %s, %s)",
            name, self.ids[F], self.ids[G], self.ids[unit], self.ids[counit],
        )
        self.ids[name] = aid
        return aid

    def check_adjunction(self, name: str) -> None:
        self.q("SELECT check_adjunction_triangles(%s)", self.ids[name])

    def adjunction_laws(self, name: str):
        return sorted(
            r[0] for r in self.q(
                "SELECT law FROM adjunction_violation WHERE adjunction_id = %s", self.ids[name]
            )
        )

    def clear_adjunction_violations(self, name: str) -> None:
        self.q("DELETE FROM adjunction_violation WHERE adjunction_id = %s", self.ids[name])

    # -- monads and comonads (migration 006) -----------------------------
    def monad(self, name: str, cat: str, T: str, unit: str, mult: str) -> str:
        """Insert via ``register_monad`` (the insert trigger runs the check)."""
        mid = self.one(
            "SELECT register_monad(%s, %s, %s, %s, %s)",
            name, self.ids[cat], self.ids[T], self.ids[unit], self.ids[mult],
        )
        self.ids[name] = mid
        return mid

    def comonad(self, name: str, cat: str, G: str, counit: str, comult: str) -> str:
        cid = self.one(
            "SELECT register_comonad(%s, %s, %s, %s, %s)",
            name, self.ids[cat], self.ids[G], self.ids[counit], self.ids[comult],
        )
        self.ids[name] = cid
        return cid

    def monad_laws(self, name: str):
        return sorted(r[0] for r in self.q(
            "SELECT law FROM monad_violation WHERE monad_id = %s", self.ids[name]))

    def comonad_laws(self, name: str):
        return sorted(r[0] for r in self.q(
            "SELECT law FROM comonad_violation WHERE comonad_id = %s", self.ids[name]))

    # -- limits and colimits (migration 007) -----------------------------
    def diagram(self, name: str, cat: str, nodes: Dict[str, Optional[str]],
                arrows: Optional[Dict[str, tuple]] = None) -> str:
        """Nodes ``{node: object}``; arrows ``{label: (src_node, tgt_node, morphism)}``.

        Node ids are stored as ``ids["<diagram>.<node>"]``.
        """
        did = self.one(
            "INSERT INTO diagram (category_id, name) VALUES (%s, %s) RETURNING id",
            self.ids[cat], name,
        )
        self.ids[name] = did
        for n, o in nodes.items():
            self.ids[f"{name}.{n}"] = self.one(
                "INSERT INTO diagram_node (diagram_id, label, object_id) VALUES (%s, %s, %s) RETURNING id",
                did, n, self.ids[o] if o is not None else None,
            )
        for label, (s, t, m) in (arrows or {}).items():
            self.ids[f"{name}.{label}"] = self.one(
                "INSERT INTO diagram_arrow (diagram_id, label, source_node_id, target_node_id, morphism_id) "
                "VALUES (%s, %s, %s, %s, %s) RETURNING id",
                did, label, self.ids[f"{name}.{s}"], self.ids[f"{name}.{t}"],
                self.ids[m] if m is not None else None,
            )
        return did

    def cone(self, name: str, diagram: str, apex: str, legs: Dict[str, str],
             cocone: bool = False) -> str:
        table = "cocone" if cocone else "cone"
        cid = self.one(
            f"INSERT INTO {table} (diagram_id, apex_object_id) VALUES (%s, %s) RETURNING id",
            self.ids[diagram], self.ids[apex],
        )
        self.ids[name] = cid
        for node, m in legs.items():
            self.leg(name, diagram, node, m, cocone)
        return cid

    def leg(self, cone: str, diagram: str, node: str, m: str, cocone: bool = False) -> None:
        table, col = ("cocone_leg", "cocone_id") if cocone else ("cone_leg", "cone_id")
        self.q(
            f"INSERT INTO {table} ({col}, node_id, leg_morphism_id) VALUES (%s, %s, %s)",
            self.ids[cone], self.ids[f"{diagram}.{node}"], self.ids[m],
        )

    def finalize(self, name: str, cone: str, cocone: bool = False) -> str:
        fn = "finalize_colimit" if cocone else "finalize_limit"
        lid = self.one(f"SELECT {fn}(%s)", self.ids[cone])
        self.ids[name] = lid
        return lid

    def universal(self, name: str, cocone: bool = False) -> bool:
        fn = "verify_colimit_universality" if cocone else "verify_limit_universality"
        return self.one(f"SELECT {fn}(%s)", self.ids[name])

    def cone_reasons(self, cone: str, cocone: bool = False):
        fn = "cocone_problems" if cocone else "cone_problems"
        return sorted(r[0] for r in self.q(f"SELECT reason FROM {fn}(%s)", self.ids[cone]))

    def lim_violations(self, cone: str, cocone: bool = False):
        table, col = ("colimit_violation", "cocone_id") if cocone else ("limit_violation", "cone_id")
        return sorted(r[0] for r in self.q(
            f"SELECT reason FROM {table} WHERE {col} = %s", self.ids[cone]))

    def clear_lim_violations(self) -> None:
        self.q("DELETE FROM limit_violation")
        self.q("DELETE FROM colimit_violation")

    # -- enriched categories (migration 008) ---------------------------
    def enriched(self, name: str, cat: str, kind: str, quantale: Optional[str] = None,
                 tolerance=None) -> str:
        import json
        meta = {}
        if quantale is not None:
            meta["quantale"] = quantale
        if tolerance is not None:
            meta["tolerance"] = tolerance
        sid = self.one(
            "INSERT INTO enrichment_space (name, kind, metadata) VALUES (%s, %s, %s::jsonb) "
            "RETURNING id", name + "_space", kind, json.dumps(meta))
        eid = self.one(
            "INSERT INTO enriched_category (base_category_id, enrichment_space_id) "
            "VALUES (%s, %s) RETURNING id", self.ids[cat], sid)
        self.ids[name] = eid
        return eid

    def hom(self, ec: str, x: str, y: str, value) -> str:
        """Record (or overwrite) the hom-value from ``x`` to ``y``."""
        import json
        self.q("SELECT update_enriched_hom_value(%s, %s, %s, %s::jsonb)",
               self.ids[ec], self.ids[x], self.ids[y], json.dumps(value))
        hid = self.one(
            "SELECT id FROM enriched_hom WHERE enriched_category_id = %s "
            "AND source_object_id = %s AND target_object_id = %s",
            self.ids[ec], self.ids[x], self.ids[y])
        self.ids[f"{ec}:{x}->{y}"] = hid
        return hid

    def enriched_composite(self, ec: str, left: Tuple[str, str], right: Tuple[str, str],
                           composed):
        """Record ``left ∘ right``; returns (id, verified)."""
        import json
        return self.q(
            "INSERT INTO enriched_composition "
            "(enriched_category_id, left_hom_id, right_hom_id, composed_value, verified) "
            "VALUES (%s, %s, %s, %s::jsonb, TRUE) RETURNING id, verified",
            self.ids[ec], self.ids[f"{ec}:{left[0]}->{left[1]}"],
            self.ids[f"{ec}:{right[0]}->{right[1]}"], json.dumps(composed))[0]

    def enriched_reasons(self, ec: str):
        return sorted(r[0] for r in self.q(
            "SELECT reason FROM enriched_problems(%s)", self.ids[ec]))

    def enriched_problems(self, ec: str):
        return self.q("SELECT reason, details FROM enriched_problems(%s)", self.ids[ec])

    def check_enriched(self, ec: str) -> bool:
        return self.one("SELECT check_enriched_category(%s)", self.ids[ec])

    def enriched_violations(self, ec: str):
        return sorted(r[0] for r in self.q(
            "SELECT reason FROM enriched_violation WHERE enriched_category_id = %s",
            self.ids[ec]))

    def clear_enriched_violations(self) -> None:
        self.q("DELETE FROM enriched_violation")

    # -- 2-categories (migration 009) ----------------------------------
    def two_category(self, name: str, cat: str) -> str:
        tid = self.one(
            "INSERT INTO two_category (name, base_category_id) VALUES (%s, %s) RETURNING id",
            name, self.ids[cat])
        self.ids[name] = tid
        return tid

    def cell(self, tc: str, name: str, src: str, tgt: str) -> str:
        cid = self.one(
            "INSERT INTO two_morphism (two_category_id, source_morphism_id, target_morphism_id, name) "
            "VALUES (%s, %s, %s, %s) RETURNING id",
            self.ids[tc], self.ids[src], self.ids[tgt], name)
        self.ids[name] = cid
        return cid

    def identity2(self, tc: str, mor: str, cell: Optional[str] = None) -> str:
        """Record ``cell`` as 1_mor (directly), or create it with ``two_identity_cell``."""
        if cell is not None:
            self.q("INSERT INTO two_identity (two_category_id, morphism_id, two_morphism_id) "
                   "VALUES (%s, %s, %s)", self.ids[tc], self.ids[mor], self.ids[cell])
            return self.ids[cell]
        cid = self.one("SELECT two_identity_cell(%s, %s)", self.ids[tc], self.ids[mor])
        self.ids[f"id2({mor})"] = cid
        return cid

    def vrow(self, tc: str, upper: str, lower: str, result: str) -> None:
        """Insert a vertical-composition row directly (the trigger checks it)."""
        self.q("INSERT INTO two_morphism_vertical_comp (two_category_id, upper_id, lower_id, result_id) "
               "VALUES (%s, %s, %s, %s)", self.ids[tc], self.ids[upper], self.ids[lower],
               self.ids[result])

    def hrow(self, tc: str, left: str, right: str, result: str) -> None:
        self.q("INSERT INTO two_morphism_horizontal_comp (two_category_id, left_id, right_id, result_id) "
               "VALUES (%s, %s, %s, %s)", self.ids[tc], self.ids[left], self.ids[right],
               self.ids[result])

    def _name_result(self, rid: str, name: Optional[str]) -> str:
        key = name or self.name_of(rid) or rid
        self.ids[key] = rid
        return key

    def vcomp(self, tc: str, upper: str, lower: str, result: Optional[str] = None,
              name: Optional[str] = None) -> str:
        """``compose_two_vertical``; returns the result's name in ``ids``."""
        rid = self.one("SELECT compose_two_vertical(%s, %s, %s, %s)", self.ids[tc],
                       self.ids[upper], self.ids[lower],
                       self.ids[result] if result is not None else None)
        return self._name_result(rid, name)

    def hcomp(self, tc: str, left: str, right: str, result: Optional[str] = None,
              name: Optional[str] = None) -> str:
        rid = self.one("SELECT compose_two_horizontal(%s, %s, %s, %s)", self.ids[tc],
                       self.ids[left], self.ids[right],
                       self.ids[result] if result is not None else None)
        return self._name_result(rid, name)

    def name_of(self, ident) -> Optional[str]:
        for k, v in self.ids.items():
            if v == ident:
                return k
        return None

    def two_problems(self, tc: str):
        """``two_category_problems`` with ids replaced by names."""
        rev = {v: k for k, v in self.ids.items()}
        out = []
        for reason, details in self.q("SELECT reason, details FROM two_category_problems(%s)",
                                      self.ids[tc]):
            out.append((reason, {k: rev.get(v, v) if isinstance(v, str) else v
                                 for k, v in details.items()}))
        return out

    def two_reasons(self, tc: str):
        return sorted(r for r, _ in self.two_problems(tc))

    def check_two(self, tc: str) -> bool:
        return self.one("SELECT check_two_category(%s)", self.ids[tc])

    def two_violations(self, tc: str):
        return sorted(r[0] for r in self.q(
            "SELECT violation_type FROM two_category_coherence_violation WHERE two_category_id = %s",
            self.ids[tc]))

    def clear_two_violations(self) -> None:
        self.q("DELETE FROM two_category_coherence_violation")

    def load_two_category(self, tc_model, cat: str = "C2", name: str = "T") -> str:
        """Load an in-memory ``TwoCategory`` (from ``qbx.categorical.two_category``)."""
        self.category(cat)
        for o in tc_model.identities:
            self.obj(cat, o)
        for f, (s, t) in tc_model.morphisms.items():
            if f not in self.ids:
                self.mor(f, s, t)
        for (g, f), h in tc_model.compositions.items():
            self.comp(g, f, h)
        self.two_category(name, cat)
        for c, (s, t) in tc_model.cells.items():
            self.cell(name, c, s, t)
        for f, c in tc_model.identity_cells.items():
            self.identity2(name, f, c)
        for (u, l), r in tc_model.vertical.items():
            self.vrow(name, u, l, r)
        for (b, a), r in tc_model.horizontal.items():
            self.hrow(name, b, a, r)
        return self.ids[name]

    # -- fibrations (migration 010) -------------------------------------
    def fibration(self, name: str, total: str, base: str, functor: str,
                  kind: str = "fibration") -> str:
        fid = self.one(
            "INSERT INTO fibration (name, total_category_id, base_category_id, "
            "projection_functor_id, kind) VALUES (%s, %s, %s, %s, %s) RETURNING id",
            name, self.ids[total], self.ids[base], self.ids[functor], kind,
        )
        self.ids[name] = fid
        return fid

    def lift(self, fib: str, morphism: str, base: str,
             src: Optional[str] = None, tgt: Optional[str] = None) -> str:
        """Register through ``register_cartesian_lift`` (the writer)."""
        return self.one(
            "SELECT register_cartesian_lift(%s, %s, %s, %s, %s)",
            self.ids[fib], self.ids[base], self.ids.get(src) if src else None,
            self.ids.get(tgt) if tgt else None, self.ids[morphism],
        )

    def lift_row(self, fib: str, morphism: str, base: str,
                 src: Optional[str] = None, tgt: Optional[str] = None) -> str:
        """Insert a lift row directly (bypassing the writer; the trigger runs)."""
        if src is None or tgt is None:
            s, t = self.q("SELECT source_id, target_id FROM morphism WHERE id = %s",
                          self.ids[morphism])[0]
        return self.one(
            "INSERT INTO cartesian_lift (fibration_id, base_morphism_id, total_source_object_id, "
            "total_target_object_id, total_morphism_id) VALUES (%s, %s, %s, %s, %s) RETURNING id",
            self.ids[fib], self.ids[base],
            self.ids[src] if src is not None else s,
            self.ids[tgt] if tgt is not None else t,
            self.ids[morphism],
        )

    def fib_problems(self, fib: str):
        """``fibration_problems`` with ids replaced by names."""
        rev = {v: k for k, v in self.ids.items()}
        out = []
        for reason, details in self.q("SELECT reason, details FROM fibration_problems(%s)",
                                      self.ids[fib]):
            out.append((reason, {k: rev.get(v, v) if isinstance(v, str) else v
                                 for k, v in details.items()}))
        return out

    def fib_reasons(self, fib: str):
        return sorted(r for r, _ in self.fib_problems(fib))

    def check_fibration(self, fib: str) -> bool:
        return self.one("SELECT check_fibration(%s)", self.ids[fib])

    def fib_violations(self, fib: str):
        return sorted(r[0] for r in self.q(
            "SELECT reason FROM fibration_violation WHERE fibration_id = %s", self.ids[fib]))

    def clear_fib_violations(self) -> None:
        self.q("DELETE FROM fibration_violation")

    def load_fibration(self, model, name: str = "F") -> str:
        """Load an in-memory ``Fibration`` (from ``qbx.categorical.fibration``).

        Identities must be named ``id_<object>`` (as ``obj`` creates them).
        Lifts are inserted directly, so ill-formed ones reach the trigger.
        """
        for cat in (model.total, model.base):
            self.category(cat.id)
            for o in cat.objects:
                self.obj(cat.id, o)
                assert cat.identities[o] == "id_" + o
            for m, (s, t) in cat.morphisms.items():
                if m not in self.ids:
                    self.mor(m, s, t)
            for (f, g), h in cat.compositions.items():
                self.comp(g, f, h)
        src = model.functor_source or model.total.id
        tgt = model.functor_target or model.base.id
        self.functor(model.functor, src, tgt, model.object_map, model.morphism_map)
        self.fibration(name, model.total.id, model.base.id, model.functor, model.kind)
        for lift in model.lifts:
            self.lift_row(name, lift.morphism, lift.base, lift.source, lift.target)
        return self.ids[name]

    # -- subobject classifiers (migration 011) ---------------------------
    def classifier(self, name: str, cat: str, omega: str, truth: Optional[str]) -> str:
        """Insert a classifier row directly (the trigger runs)."""
        cid = self.one(
            "INSERT INTO subobject_classifier (category_id, omega_object_id, true_morphism_id) "
            "VALUES (%s, %s, %s) RETURNING id",
            self.ids[cat], self.ids[omega], self.ids[truth] if truth else None,
        )
        self.ids[name] = cid
        return cid

    def subobject_row(self, cat: str, mono: str, of_object: str) -> str:
        """Insert a subobject row directly (bypassing the writer; the trigger runs)."""
        return self.one(
            "INSERT INTO subobject (category_id, mono_morphism_id, subobject_of_object_id) "
            "VALUES (%s, %s, %s) RETURNING id",
            self.ids[cat], self.ids[mono], self.ids[of_object],
        )

    def characteristic_row(self, sub_id: str, chi: str) -> str:
        return self.one(
            "INSERT INTO characteristic_morphism (subobject_id, morphism_id) "
            "VALUES (%s, %s) RETURNING id", sub_id, self.ids[chi],
        )

    def truth_value_row(self, cls: str, name: str, mor: Optional[str]) -> str:
        return self.one(
            "INSERT INTO truth_value (classifier_id, name, morphism_id) "
            "VALUES (%s, %s, %s) RETURNING id",
            self.ids[cls], name, self.ids[mor] if mor else None,
        )

    def topos_problems(self, cls: str):
        """``subobject_classifier_problems`` with ids replaced by names."""
        rev = {v: k for k, v in self.ids.items()}
        out = []
        for reason, details in self.q(
                "SELECT reason, details FROM subobject_classifier_problems(%s)", self.ids[cls]):
            out.append((reason, {k: rev.get(v, v) if isinstance(v, str) else v
                                 for k, v in details.items()}))
        return out

    def topos_reasons(self, cls: str):
        return sorted(r for r, _ in self.topos_problems(cls))

    def check_topos(self, cls: str) -> bool:
        return self.one("SELECT check_subobject_classifier(%s)", self.ids[cls])

    def topos_violations(self, cat: str):
        return sorted(r[0] for r in self.q(
            "SELECT reason FROM topos_violation WHERE category_id = %s", self.ids[cat]))

    def clear_topos_violations(self) -> None:
        self.q("DELETE FROM topos_violation")

    def classify(self, cat: str, mono: str) -> Optional[str]:
        return self.name_of(self.one("SELECT classify_mono(%s, %s)",
                                     self.ids[cat], self.ids[mono]))

    def load_classifier(self, model, name: str = "Om") -> str:
        """Load an in-memory ``SubobjectClassifier`` (from ``qbx.categorical.topos``).

        Identities must be named ``id_<object>`` (as ``obj`` creates them).
        Every row is inserted directly, so ill-typed ones reach the triggers.
        """
        cat = model.category
        self.category(cat.id)
        for o in cat.objects:
            self.obj(cat.id, o)
            assert cat.identities[o] == "id_" + o
        for m, (s, t) in cat.morphisms.items():
            if m not in self.ids:
                self.mor(m, s, t)
        for (f, g), h in cat.compositions.items():
            self.comp(g, f, h)
        self.classifier(name, cat.id, model.omega, model.truth)
        for sub in model.subobjects:
            sid = self.subobject_row(cat.id, sub.mono, sub.of_object)
            if sub.mono in model.characteristics:
                self.characteristic_row(sid, model.characteristics[sub.mono])
        for tv, mor in model.truth_values.items():
            self.truth_value_row(name, tv, mor)
        return self.ids[name]

    # -- finite sites and presheaves (migration 012) -----------------------
    def _object_for(self, cat: str, name: Optional[str]) -> Optional[str]:
        """The object named ``name`` in ``cat``, created on first use."""
        if name is None:
            return None
        if name not in self.ids:
            self.obj(cat, name)
        return self.ids[name]

    def load_site(self, site, cat: str = "Top") -> str:
        """Load an in-memory ``FiniteSite`` (from ``qbx.categorical.sheaf``).

        Every row is inserted directly, so ill-typed ones reach the triggers.
        Opens are objects of ``cat``; covers are registered under their names."""
        if cat not in self.ids:
            self.category(cat)
        for u in site.opens:
            self._object_for(cat, u)
        base = self._object_for(cat, site.base)
        sid = self.one("INSERT INTO site (name, base_space_object_id) VALUES (%s, %s) RETURNING id",
                       site.name, base)
        self.ids[site.name] = sid
        for u, pts in site.opens.items():
            self.q("INSERT INTO site_open (site_id, object_id, points) VALUES (%s, %s, %s)",
                   sid, self.ids[u], sorted(pts))
        for name, cov in site.covers.items():
            cid = self.one(
                "INSERT INTO site_cover (site_id, name, covered_object_id) VALUES (%s, %s, %s) "
                "RETURNING id", sid, name, self._object_for(cat, cov.covered))
            self.ids[name] = cid
            for m in cov.members:
                self.q("INSERT INTO cover (site_id, open_set_object_id, site_cover_id) "
                       "VALUES (%s, %s, %s)", sid, self._object_for(cat, m), cid)
        return sid

    def load_presheaf(self, presheaf, cat: str = "Top") -> str:
        """Load an in-memory ``Presheaf`` on an already loaded site (rows inserted directly)."""
        import json

        sid = self.ids[presheaf.site.name]
        pid = self.one("INSERT INTO presheaf (site_id, name) VALUES (%s, %s) RETURNING id",
                       sid, presheaf.name)
        self.ids[presheaf.name] = pid
        for u, secs in presheaf.sections.items():
            oid = self._object_for(cat, u)
            for s in secs:
                self.q("INSERT INTO presheaf_section (presheaf_id, open_object_id, label) "
                       "VALUES (%s, %s, %s)", pid, oid, s)
        for (u, v, s), t in presheaf.restrictions.items():
            self.q("INSERT INTO presheaf_restriction "
                   "(presheaf_id, from_object_id, to_object_id, section, image) "
                   "VALUES (%s, %s, %s, %s, %s)",
                   pid, self._object_for(cat, u), self._object_for(cat, v), s, t)
        for rec in presheaf.cohomology:
            self.q("INSERT INTO cohomology_group "
                   "(site_id, presheaf_id, degree, group_descriptor, site_cover_id) "
                   "VALUES (%s, %s, %s, %s, %s)", sid, pid, rec.degree,
                   json.dumps(rec.descriptor), self._cover_id(rec.cover))
        for ch in presheaf.cochains:
            self.q("INSERT INTO cech_complex (site_id, presheaf_id, degree, site_cover_id) "
                   "VALUES (%s, %s, %s, %s)", sid, pid, ch.degree, self._cover_id(ch.cover))
        return pid

    def _cover_id(self, name: Optional[str]) -> Optional[str]:
        if name is None:
            return None
        if name not in self.ids:      # a cover of no site: a cover of a scratch site
            other = self.one("INSERT INTO site (name) VALUES (%s) RETURNING id", "other_" + name)
            self.ids[name] = self.one(
                "INSERT INTO site_cover (site_id, name) VALUES (%s, %s) RETURNING id",
                other, name)
        return self.ids[name]

    def _named(self, rows):
        rev = {v: k for k, v in self.ids.items()}

        def name(v):
            return rev.get(v, v) if isinstance(v, str) else v

        out = []
        for reason, details in rows:
            d = {}
            for k, v in details.items():
                d[k] = sorted(name(x) for x in v) if isinstance(v, list) else name(v)
            out.append((reason, d))
        return out

    def site_problems(self, site: str):
        return self._named(self.q("SELECT reason, details FROM sheaf_site_problems(%s)",
                                  self.ids[site]))

    def presheaf_problems(self, presheaf: str):
        return self._named(self.q("SELECT reason, details FROM sheaf_presheaf_problems(%s)",
                                  self.ids[presheaf]))

    def sheaf_violations(self, site: str):
        return sorted(r[0] for r in self.q(
            "SELECT reason FROM sheaf_cohomology_obstruction WHERE site_id = %s", self.ids[site]))

    def clear_sheaf_violations(self) -> None:
        self.q("DELETE FROM sheaf_cohomology_obstruction")
