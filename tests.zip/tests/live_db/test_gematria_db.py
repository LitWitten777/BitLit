"""SQL and Python gematria agree (migration 014 trigger vs `qbx.hebrew.gematria`).

Convention (agents/skills/hebrew_primacy_rules.md, rule R7): the five final
forms ך ם ן ף ץ take 500–900, so שלום = 300 + 30 + 6 + 600 = 936.
"""

import pytest

pytest.importorskip("psycopg2")

from qbx.hebrew.gematria import gematria_value  # noqa: E402

WORDS = ["שלום", "תורה", "אמן", "ארץ", "כף", "מלך", "אברהם", "בראשית"]


@pytest.mark.parametrize("word", WORDS)
def test_sql_gematria_matches_python(db, word):
    wid = db.one("INSERT INTO hebrew_word (text) VALUES (%s) RETURNING id", word)
    assert db.one("SELECT total_gematria FROM hebrew_word WHERE id = %s", wid) == gematria_value(word)


def test_shalom_is_936(db):
    wid = db.one("INSERT INTO hebrew_word (text) VALUES ('שלום') RETURNING id")
    assert db.one("SELECT total_gematria FROM hebrew_word WHERE id = %s", wid) == 936
