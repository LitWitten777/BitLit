"""Migration 012 (sheaf cohomology: finite sites, presheaves, the sheaf
condition, Čech H⁰) on a real PostgreSQL.

Formal backing: ``Formal/Sheaf.lean`` — locality and gluing over every cover
are exactly Mathlib's ``IsSheaf`` (``isSheaf_iff_locality_and_gluing``); a sheaf
has one section over ∅ (``uniqueBot``, the ``sheaf_empty_open`` check); neither
half implies the other (``constBool_gluing_not_locality``,
``constEmpty_locality_not_gluing`` — both used below); for a sheaf the number
of compatible families on a cover is the number of sections
(``card_compatible_eq``, used below as an oracle for H⁰); the presheaf of all
functions passes (``presheafToTypes_locality_and_gluing``, used below).
"""

from __future__ import annotations

import json
import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx.categorical.sheaf import (
    PRESHEAF_REASONS,
    SITE_REASONS,
    CohomologyRecord,
    constant_presheaf,
    functions_presheaf,
    generated_topology,
)
from tests.sheaf_examples import (
    canon,
    random_presheaf,
    random_site,
    random_topology,
    register_all_covers,
    two_point_discrete,
)


def reset(db) -> None:
    db.conn.rollback()
    db.ids.clear()
    db.cat_of.clear()
    db.morphisms.clear()
    db.composites.clear()


def split_site(db):
    """The discrete two-point space with the cover {a} ⊔ {b} of {a, b}."""
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    db.load_site(S)
    return S


def flag(db, presheaf: str) -> bool:
    return db.one("SELECT is_sheaf FROM presheaf WHERE id = %s", db.ids[presheaf])


# ---------------------------------------------------------------------------
# The original migration's bugs
# ---------------------------------------------------------------------------
def test_is_sheaf_is_computed_not_trusted(db):
    """Original bug: check_sheaf_condition returned the stored flag (FALSE for
    every presheaf until set by hand, TRUE after)."""
    S = split_site(db)
    db.load_presheaf(functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]}, name="Fun"))
    db.load_presheaf(constant_presheaf(S, ["x", "y"], ["*"], name="Const"))
    db.q("UPDATE presheaf SET is_sheaf = TRUE")                  # forged: ignored
    assert flag(db, "Fun") is False and flag(db, "Const") is False
    assert db.one("SELECT check_sheaf_condition(%s)", db.ids["Fun"]) is True
    assert db.one("SELECT check_sheaf_condition(%s)", db.ids["Const"]) is False
    assert flag(db, "Fun") is True and flag(db, "Const") is False
    assert db.sheaf_violations("S") == ["sheaf_gluing"]
    # any change to the data resets the verdict
    db.q("DELETE FROM presheaf_restriction WHERE presheaf_id = %s AND section = 'a=1,b=0' "
         "AND to_object_id = %s", db.ids["Fun"], db.ids["U_a"])
    assert flag(db, "Fun") is False
    assert db.one("SELECT check_sheaf_condition(%s)", db.ids["Fun"]) is False
    assert db.presheaf_problems("Fun") == [
        ("restriction_missing", {"from": "U_ab", "to": "U_a", "section": "a=1,b=0"})]


def test_register_presheaf_refuses_non_opens(db):
    """Original bug: sections over anything (not an open, not even an id) were accepted."""
    S = split_site(db)
    db.obj("Top", "Elsewhere")
    for key in ("x", db.ids["Elsewhere"]):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="not an open of the site"):
            db.q("SELECT register_presheaf(%s, 'F', %s)", db.ids["S"], json.dumps({key: ["s"]}))
        db.q("ROLLBACK TO SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not a list of labels"):
        db.q("SELECT register_presheaf(%s, 'F', %s)", db.ids["S"],
             json.dumps({db.ids["U_a"]: "s"}))


def test_store_functions_refuse_ill_typed_records(db):
    """Original bug: negative degrees and a site other than the presheaf's were accepted."""
    S = split_site(db)
    pid = db.one("SELECT register_presheaf(%s, 'F', '{}'::jsonb)", db.ids["S"])
    other = db.one("SELECT register_site('other', NULL)")
    cases = [
        ("SELECT store_cohomology_group(%s, %s, -1, '{\"rank\": 0}'::jsonb)",
         (db.ids["S"], pid), "non-negative"),
        ("SELECT store_cohomology_group(%s, %s, 0, '{\"cardinality\": 0}'::jsonb)",
         (other, pid), "not a presheaf on the site"),
        ("SELECT store_cohomology_group(%s, %s, 1, '{\"cardinality\": 0}'::jsonb)",
         (db.ids["S"], pid), "non-negative integer rank"),
        ("SELECT store_cech_cochain(%s, %s, -3, '{}'::jsonb)",
         (db.ids["S"], pid), "non-negative"),
        ("SELECT store_cech_cochain(%s, %s, 0, '{}'::jsonb, %s)",
         (db.ids["S"], pid, db.one("INSERT INTO site_cover (site_id, name) VALUES (%s, 'o') "
                                   "RETURNING id", other)), "not a cover of the site"),
    ]
    for sql, args, msg in cases:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, *args)
        db.q("ROLLBACK TO SAVEPOINT s")
    # one descriptor per (presheaf, cover, degree)
    first = db.one("SELECT store_cohomology_group(%s, %s, 0, '{\"cardinality\": 1}'::jsonb, %s)",
                   db.ids["S"], pid, db.ids["split"])
    assert db.one("SELECT store_cohomology_group(%s, %s, 0, '{\"cardinality\": 1}'::jsonb, %s)",
                  db.ids["S"], pid, db.ids["split"]) == first
    with pytest.raises(psycopg2.Error, match="different descriptor"):
        db.q("SELECT store_cohomology_group(%s, %s, 0, '{\"cardinality\": 2}'::jsonb, %s)",
             db.ids["S"], pid, db.ids["split"])


def test_direct_ill_typed_records_are_logged(db):
    S = split_site(db)
    db.load_presheaf(functions_presheaf(S, {"a": ["0"], "b": ["0"]}, name="F"))
    db.q("INSERT INTO cohomology_group (site_id, presheaf_id, degree, group_descriptor) "
         "VALUES (%s, %s, -2, '{}'::jsonb)", db.ids["S"], db.ids["F"])
    db.q("INSERT INTO cech_complex (site_id, presheaf_id, degree) VALUES (%s, %s, -1)",
         db.ids["S"], db.ids["F"])
    assert db.sheaf_violations("S") == ["cochain_typing", "cohomology_typing"]
    assert db.one("SELECT degree FROM sheaf_cohomology_obstruction "
                  "WHERE reason = 'cohomology_typing'") == -2
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="not well typed"):
        db.q("INSERT INTO presheaf_section (presheaf_id, open_object_id, label) "
             "VALUES (%s, %s, 'z')", db.ids["F"], db.obj("Top", "Q"))


def test_descent_verified_is_computed(db):
    """Original bug: sheaf_descent_data accepted verified = TRUE with no check."""
    S = split_site(db)
    db.load_presheaf(functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]}, name="Fun"))
    db.load_presheaf(constant_presheaf(S, ["x", "y"], ["*"], name="Const"))
    a, b = db.ids["U_a"], db.ids["U_b"]

    def verify(p, fam):
        return db.one("SELECT verify_descent(%s, %s, %s)", db.ids[p], db.ids["split"],
                      json.dumps(fam))

    assert verify("Fun", {a: "a=1", b: "b=0"}) is True
    assert verify("Fun", {a: "a=1"}) is False                   # not on every member
    assert verify("Fun", {a: "a=7", b: "b=0"}) is False         # not a section
    assert verify("Const", {a: "x", b: "x"}) is True
    assert verify("Const", {a: "x", b: "y"}) is False           # compatible, no gluing
    forged = db.one("INSERT INTO sheaf_descent_data (presheaf_id, site_cover_id, "
                    "descent_cocycle, verified) VALUES (%s, %s, %s, TRUE) RETURNING verified",
                    db.ids["Const"], db.ids["split"], json.dumps({a: "x", b: "y"}))
    assert forged is False
    # a legacy row naming a cover member row resolves to that member's cover
    member = db.one("SELECT id FROM cover WHERE site_cover_id = %s LIMIT 1", db.ids["split"])
    assert db.one("INSERT INTO sheaf_descent_data (presheaf_id, cover_id, descent_cocycle) "
                  "VALUES (%s, %s, %s) RETURNING verified", db.ids["Fun"], member,
                  json.dumps({a: "a=0", b: "b=0"})) is True


def test_covers_are_checked(db):
    """Original bug: a cover was never checked to cover anything."""
    S = two_point_discrete()
    S.add_cover("short", "U_ab", ["U_a"])
    db.load_site(S)
    assert db.site_problems("S") == [("cover_not_covering", {"cover": "short"})]
    with pytest.raises(psycopg2.Error, match="not an open inside the covered set"):
        db.q("SELECT register_site_cover(%s, 'bad', %s, %s::uuid[])", db.ids["S"],
             db.ids["U_a"], [db.ids["U_b"]])


def test_legacy_cover_rows_join_the_default_cover(db):
    S = two_point_discrete()
    db.load_site(S)
    for u in ("U_a", "U_b"):
        db.q("INSERT INTO cover (site_id, open_set_object_id) VALUES (%s, %s)",
             db.ids["S"], db.ids[u])
    sc = db.one("SELECT id FROM site_cover WHERE site_id = %s AND name = 'default'", db.ids["S"])
    assert db.one("SELECT covered_object_id FROM site_cover WHERE id = %s", sc) == db.ids["U_ab"]
    assert db.one("SELECT count(*) FROM cover WHERE site_cover_id = %s", sc) == 2
    assert db.site_problems("S") == []


# ---------------------------------------------------------------------------
# Writers
# ---------------------------------------------------------------------------
def test_writers_build_a_sheaf(db):
    db.category("Top")
    for n in ("E", "A", "B", "AB"):
        db.obj("Top", n)
    sid = db.one("SELECT register_site('W', %s)", db.ids["AB"])
    assert db.one("SELECT register_site('W', %s)", db.ids["AB"]) == sid
    for n, pts in (("E", []), ("A", ["a"]), ("B", ["b", "b"]), ("AB", ["b", "a"])):
        db.q("SELECT register_site_open(%s, %s, %s)", sid, db.ids[n], pts)
    assert db.one("SELECT points FROM site_open WHERE object_id = %s", db.ids["AB"]) == ["a", "b"]
    with pytest.raises(psycopg2.Error, match="same points"):
        db.q("SAVEPOINT s")
        db.obj("Top", "AB2")
        db.q("SELECT register_site_open(%s, %s, %s)", sid, db.ids["AB2"], ["a", "b"])
    db.q("ROLLBACK TO SAVEPOINT s")
    cov = db.one("SELECT register_site_cover(%s, 'split', %s, %s::uuid[])", sid, db.ids["AB"],
                 [db.ids["A"], db.ids["B"], db.ids["A"]])
    sections = {db.ids["E"]: ["()"], db.ids["A"]: ["0", "1"], db.ids["B"]: ["0"],
                db.ids["AB"]: ["00", "10"]}
    pid = db.one("SELECT register_presheaf(%s, 'G', %s)", sid, json.dumps(sections))
    res = [("E", "E", "()", "()"), ("A", "A", "0", "0"), ("A", "A", "1", "1"),
           ("A", "E", "0", "()"), ("A", "E", "1", "()"), ("B", "B", "0", "0"),
           ("B", "E", "0", "()")]
    for s in ("00", "10"):
        res += [("AB", "AB", s, s), ("AB", "A", s, s[0]), ("AB", "B", s, s[1]),
                ("AB", "E", s, "()")]
    for u, v, s, t in res:
        db.q("SELECT record_restriction(%s, %s, %s, %s, %s)", pid, db.ids[u], db.ids[v], s, t)
    db.q("SELECT record_restriction(%s, %s, %s, '0', '0')", pid, db.ids["A"], db.ids["A"])
    for args, msg in (((db.ids["A"], db.ids["A"], "0", "1"), "different restriction"),
                      ((db.ids["A"], db.ids["AB"], "0", "00"), "not an open inside"),
                      ((db.ids["A"], db.ids["E"], "7", "()"), "not a section")):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q("SELECT record_restriction(%s, %s, %s, %s, %s)", pid, *args)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.q("SELECT store_cohomology_group(%s, %s, 0, '{\"cardinality\": 2}'::jsonb, %s)",
         sid, pid, cov)
    assert db.one("SELECT check_site(%s)", sid) is True
    assert db.one("SELECT check_sheaf_condition(%s)", pid) is True


# ---------------------------------------------------------------------------
# The Lean results as oracles
# ---------------------------------------------------------------------------
def test_functions_presheaf_passes_on_every_cover(db):
    """``presheafToTypes_locality_and_gluing`` and ``card_compatible_eq``."""
    rng = random.Random(21)
    for i in range(12):
        reset(db)
        S = random_topology(rng)
        register_all_covers(S)
        F = functions_presheaf(S, {p: ["0", "1"][:rng.randint(1, 2)]
                                   for p in frozenset().union(*S.opens.values())}, name="F")
        db.load_site(S)
        db.load_presheaf(F)
        assert db.presheaf_problems("F") == [], i
        for name, cov in S.covers.items():
            n = db.one("SELECT count(*) FROM sheaf_compatible_families(%s, %s)",
                       db.ids["F"], db.ids[name])
            assert n == len(F.F(cov.covered))


def test_constant_presheaves_need_both_halves(db):
    """``constBool_gluing_not_locality``: gluing holds, locality fails on the
    empty cover of ∅; ``constEmpty_locality_not_gluing``: the reverse."""
    S = generated_topology(["a", "b"], [["a"]])
    register_all_covers(S)
    empty_cover = next(n for n, c in S.covers.items() if c.covered == "U_empty" and not c.members)
    db.load_site(S)
    db.load_presheaf(constant_presheaf(S, ["x", "y"], name="Bool"))
    db.load_presheaf(constant_presheaf(S, [], name="Empty"))
    for name in S.covers:
        assert db.one("SELECT sheaf_gluing_failures(%s, %s)", db.ids["Bool"], db.ids[name]) == 0
        assert db.one("SELECT sheaf_locality_failures(%s, %s)", db.ids["Empty"],
                      db.ids[name]) == 0
    assert canon(db.presheaf_problems("Bool")) == canon([
        ("sheaf_empty_open", {"count": 2}),
        ("sheaf_locality", {"cover": empty_cover, "count": 1})])
    assert canon(db.presheaf_problems("Empty")) == canon([
        ("sheaf_empty_open", {"count": 0}),
        ("sheaf_gluing", {"cover": empty_cover, "count": 1})])


def test_h0_descriptors_are_checked(db):
    S = split_site(db)
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0", "1", "2"]}, name="F")
    F.cohomology.append(CohomologyRecord(0, "split", {"cardinality": 6}))
    F.cohomology.append(CohomologyRecord(0, "split", {"cardinality": 5}))
    F.cohomology.append(CohomologyRecord(1, "split", {"rank": 0}))
    db.load_presheaf(F)
    assert db.presheaf_problems("F") == [
        ("cohomology_h0_mismatch", {"cover": "split", "recorded": 5, "computed": 6})]


# ---------------------------------------------------------------------------
# Batch tier, views, strict mode
# ---------------------------------------------------------------------------
def test_batch_checks_and_view(db):
    S = two_point_discrete()
    S.add_cover("short", "U_ab", ["U_a"])
    db.load_site(S)
    db.load_presheaf(constant_presheaf(S, ["x", "y"]))
    db.clear_sheaf_violations()
    db.q("SELECT run_all_batch_checks()")
    rows = db.q("SELECT violation_type FROM v_all_violations WHERE module = 'sheaf_cohomology' "
                "ORDER BY 1")
    assert [r[0] for r in rows] == ["cover_not_covering", "site_invalid"]
    db.q("SELECT store_sheaf_obstruction(%s, NULL, 1, '{}'::jsonb)", db.ids["S"])
    assert "obstruction" in [r[0] for r in db.q(
        "SELECT violation_type FROM v_all_violations WHERE module = 'sheaf_cohomology'")]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="not a valid finite site"):
        db.q("SELECT check_site(%s)", db.ids["S"])


def test_strict_check_raises(db):
    S = split_site(db)
    db.load_presheaf(constant_presheaf(S, ["x", "y"], ["*"]))
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="is not a sheaf"):
        db.q("SELECT check_sheaf_condition(%s)", db.ids["Const"])


def test_checks_refuse_unknown_rows(db):
    for fn in ("check_site", "check_sheaf_condition"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="not found"):
            db.q(f"SELECT {fn}(gen_random_uuid())")
        db.q("ROLLBACK TO SAVEPOINT s")


# ---------------------------------------------------------------------------
# Upgrade path from the original table layout
# ---------------------------------------------------------------------------
def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE sheaf_descent_data, sheaf_cohomology_obstruction, cohomology_group, "
         "cech_complex, presheaf_restriction, presheaf_section, presheaf, cover, site_cover, "
         "site_open, site CASCADE")
    db.q("""
      CREATE TABLE site (id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL UNIQUE,
        base_space_object_id UUID REFERENCES object(id) ON DELETE CASCADE,
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE cover (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID NOT NULL REFERENCES site(id) ON DELETE CASCADE,
        open_set_object_id UUID NOT NULL REFERENCES object(id) ON DELETE CASCADE,
        metadata JSONB DEFAULT '{}'::jsonb);
      CREATE TABLE presheaf (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID NOT NULL REFERENCES site(id) ON DELETE CASCADE, name TEXT NOT NULL,
        assignment JSONB DEFAULT '{}'::jsonb, is_sheaf BOOLEAN DEFAULT FALSE,
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now(),
        UNIQUE (site_id, name));
      CREATE TABLE cech_complex (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID NOT NULL REFERENCES site(id) ON DELETE CASCADE,
        presheaf_id UUID NOT NULL REFERENCES presheaf(id) ON DELETE CASCADE,
        degree INT NOT NULL, data JSONB DEFAULT '{}'::jsonb, computed_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE cohomology_group (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID REFERENCES site(id) ON DELETE CASCADE,
        presheaf_id UUID REFERENCES presheaf(id) ON DELETE CASCADE, degree INT NOT NULL,
        group_descriptor JSONB NOT NULL, computed_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE sheaf_cohomology_obstruction (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID REFERENCES site(id) ON DELETE CASCADE,
        presheaf_id UUID REFERENCES presheaf(id) ON DELETE CASCADE, degree INT,
        details JSONB DEFAULT '{}'::jsonb, detected_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE sheaf_descent_data (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        presheaf_id UUID NOT NULL REFERENCES presheaf(id) ON DELETE CASCADE,
        cover_id UUID NOT NULL REFERENCES cover(id) ON DELETE CASCADE,
        descent_cocycle JSONB NOT NULL, verified BOOLEAN DEFAULT FALSE,
        verification_proof UUID REFERENCES proof_artifact(id), verified_at TIMESTAMPTZ);
    """)
    db.category("Top")
    for n in ("X", "A"):
        db.obj("Top", n)
    sid = db.one("INSERT INTO site (name, base_space_object_id) VALUES ('old', %s) RETURNING id",
                 db.ids["X"])
    db.q("INSERT INTO cover (site_id, open_set_object_id) VALUES (%s, %s)", sid, db.ids["A"])
    pid = db.one("INSERT INTO presheaf (site_id, name, assignment) VALUES (%s, 'P', %s) "
                 "RETURNING id", sid, json.dumps({db.ids["A"]: ["s", "t"], "junk": ["u"],
                                                  db.ids["X"]: "not a list"}))
    path = Path(__file__).resolve().parents[2] / "migrations" / "012_sheaf_cohomology.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    assert db.one("SELECT count(*) FROM site_cover WHERE site_id = %s AND name = 'default' "
                  "AND covered_object_id = %s", sid, db.ids["X"]) == 1
    assert db.one("SELECT count(*) FROM cover WHERE site_cover_id IS NULL") == 0
    assert sorted(r[0] for r in db.q("SELECT label FROM presheaf_section WHERE presheaf_id = %s",
                                     pid)) == ["s", "t"]
    # the old site has no opens yet: its problems are reported, not hidden
    db.ids["old"] = sid
    assert "base_typing" in [r for r, _ in db.site_problems("old")]
    # and the upgraded tables work
    S = split_site(db)
    db.load_presheaf(functions_presheaf(S, {"a": ["0"], "b": ["0", "1"]}, name="F"))
    assert db.presheaf_problems("F") == []


# ---------------------------------------------------------------------------
# Agreement with the in-memory reference engine
# ---------------------------------------------------------------------------
def test_database_agrees_with_python_reference(db):
    rng = random.Random(7)
    site_total, total = Counter(), Counter()
    for i in range(250):
        S = random_site(rng)
        F = random_presheaf(rng, S)
        reset(db)
        db.load_site(S)
        db.load_presheaf(F)
        assert canon(db.site_problems("S")) == canon(S.problems()), i
        py = canon(F.problems())
        assert canon(db.presheaf_problems("F")) == py, i
        site_total.update(r for r, _ in S.problems())
        total.update(r for r, _ in F.problems())
    assert set(site_total) == set(SITE_REASONS)
    assert set(total) == set(PRESHEAF_REASONS)
