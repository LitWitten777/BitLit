"""Migration 007 (limits and colimits) on a real PostgreSQL.

Formal backing: ``Formal/Limits.lean`` — a cone is a limit iff every cone has
a mediator into it and its legs are jointly monic (``nonempty_isLimit_iff``);
neither half suffices alone (``existence_not_sufficient``,
``jointlyMonic_not_sufficient``); checking triangles on the recorded arrows
suffices for a cone (``coneOfEdges``).
"""

from __future__ import annotations

import psycopg2
import pytest


# ---------------------------------------------------------------------------
# Fixtures: small, fully recorded categories
# ---------------------------------------------------------------------------
def product_category(db):
    """P = A × B with projections p, q; X with x1, x2 and the mediator u."""
    db.category("C")
    for o in ["A", "B", "P", "X"]:
        db.obj("C", o)
    db.mor("p", "P", "A")
    db.mor("q", "P", "B")
    db.mor("x1", "X", "A")
    db.mor("x2", "X", "B")
    db.mor("u", "X", "P")
    db.comp("p", "u", "x1")
    db.comp("q", "u", "x2")
    db.diagram("D", "C", {"a": "A", "b": "B"})
    db.cone("lim", "D", "P", {"a": "p", "b": "q"})
    db.cone("other", "D", "X", {"a": "x1", "b": "x2"})


def coproduct_category(db):
    """S = A + B with injections i, j; Y with y1, y2 and the mediator v."""
    db.category("C")
    for o in ["A", "B", "S", "Y"]:
        db.obj("C", o)
    db.mor("i", "A", "S")
    db.mor("j", "B", "S")
    db.mor("y1", "A", "Y")
    db.mor("y2", "B", "Y")
    db.mor("v", "S", "Y")
    db.comp("v", "i", "y1")
    db.comp("v", "j", "y2")
    db.diagram("D", "C", {"a": "A", "b": "B"})
    db.cone("colim", "D", "S", {"a": "i", "b": "j"}, cocone=True)
    db.cone("other", "D", "Y", {"a": "y1", "b": "y2"}, cocone=True)


# ---------------------------------------------------------------------------
# Limits
# ---------------------------------------------------------------------------
def test_product_is_universal(db):
    product_category(db)
    db.finalize("L", "lim")
    assert db.universal("L") is True
    assert db.lim_violations("lim") == []


def test_second_mediator_breaks_uniqueness(db):
    product_category(db)
    db.mor("u2", "X", "P")
    db.comp("p", "u2", "x1")
    db.comp("q", "u2", "x2")
    db.finalize("L", "lim")
    assert db.universal("L") is False
    assert db.lim_violations("lim") == ["legs_not_jointly_monic", "non_unique_mediator"]


def test_unrecorded_composite_is_reported_not_guessed(db):
    product_category(db)
    db.mor("u2", "X", "P")
    db.comp("p", "u2", "x1")          # q ∘ u2 not recorded
    db.finalize("L", "lim")
    assert db.universal("L") is False
    assert db.lim_violations("lim") == ["missing_composite"]


def test_missing_mediator(db):
    product_category(db)
    db.mor("z1", "X", "A")
    db.cone("other2", "D", "X", {"a": "z1", "b": "x2"})
    db.finalize("L", "lim")
    assert db.universal("L") is False
    assert db.lim_violations("lim") == ["no_mediator"]


def test_identity_leg_and_identity_mediator(db):
    """Limit of A →f B is A with legs id_A, f.  The original 007 looked up
    f ∘ id_A in `composition` and reported a non-commuting triangle; a second
    cone with the same legs needs the identity as mediator."""
    db.category("C")
    db.obj("C", "A")
    db.obj("C", "B")
    db.mor("f", "A", "B")
    db.diagram("D", "C", {"a": "A", "b": "B"}, {"e": ("a", "b", "f")})
    db.cone("lim", "D", "A", {"a": "id_A", "b": "f"})
    assert db.cone_reasons("lim") == []
    db.cone("twin", "D", "A", {"a": "id_A", "b": "f"})
    db.finalize("L", "lim")
    assert db.universal("L") is True


def test_terminal_object_as_limit_of_empty_diagram(db):
    db.category("C")
    db.obj("C", "T")
    db.obj("C", "Y")
    db.mor("t", "Y", "T")
    db.diagram("E", "C", {})
    db.cone("term", "E", "T", {})
    db.cone("fromY", "E", "Y", {})
    db.finalize("L", "term")
    assert db.universal("L") is True
    # A second morphism Y → T: legs (none) no longer jointly monic.
    db.mor("t2", "Y", "T")
    db.clear_lim_violations()
    assert db.universal("L") is False
    assert db.lim_violations("term") == ["legs_not_jointly_monic", "non_unique_mediator"]


def test_jointly_monic_but_no_mediator(db):
    """Mirror of `jointlyMonic_not_sufficient`: apex Y of the empty diagram
    has no incoming morphism from T, so the cone at T has no mediator."""
    db.category("C")
    db.obj("C", "T")
    db.obj("C", "Y")
    db.mor("t", "Y", "T")
    db.diagram("E", "C", {})
    db.cone("atY", "E", "Y", {})
    db.cone("atT", "E", "T", {})
    db.finalize("L", "atY")
    assert db.universal("L") is False
    assert db.lim_violations("atY") == ["no_mediator"]


def test_non_commuting_cones_are_not_counted(db):
    product_category(db)
    db.mor("g", "A", "B")
    db.diagram("D2", "C", {"a": "A", "b": "B"}, {"e": ("a", "b", "g")})
    db.mor("w", "X", "B")
    db.comp("g", "x1", "w")
    db.cone("good", "D2", "X", {"a": "x1", "b": "w"})
    db.cone("bad", "D2", "X", {"a": "x1", "b": "x2"})   # g ∘ x1 = w ≠ x2
    assert db.cone_reasons("bad") == ["non_commuting_triangle"]
    db.finalize("L", "good")
    # `bad` would need a mediator X → X with x2 = w ∘ m; it is skipped.
    assert db.universal("L") is True


def test_cone_problems_are_all_reported(db):
    db.category("C")
    db.category("C2")
    for o in ["A", "B", "Z"]:
        db.obj("C", o)
    db.obj("C2", "W")
    db.mor("f", "A", "B")
    db.mor("h", "B", "A")
    db.mor("k", "Z", "A")
    db.diagram("D", "C", {"a": "A", "b": "B", "lonely": "Z", "blank": None},
               {"e": ("a", "b", "f"), "typo": ("a", "b", "h"), "none": ("a", "b", None)})
    # apex Z: leg at a is k (fine), leg at b missing, leg at lonely mistyped
    db.cone("c", "D", "Z", {"a": "k", "lonely": "k"})
    assert db.cone_reasons("c") == sorted([
        "arrow_typing", "arrow_without_morphism", "leg_typing",
        "missing_leg", "node_without_object",
    ])
    db.cone("w", "D", "W", {})
    assert "apex_category" in db.cone_reasons("w")


def test_isolated_node_without_leg_is_caught(db):
    """The original 007 only looked at nodes touched by an arrow."""
    db.category("C")
    db.obj("C", "A")
    db.obj("C", "B")
    db.diagram("D", "C", {"b": "B"})
    db.cone("c", "D", "A", {})
    assert db.cone_reasons("c") == ["missing_leg"]
    assert db.one("SELECT check_cone_commutes(%s)", db.ids["c"]) is False
    assert db.lim_violations("c") == ["missing_leg"]


def test_missing_composite_in_triangle(db):
    db.category("C")
    for o in ["X", "A", "B"]:
        db.obj("C", o)
    db.mor("f", "A", "B")
    db.mor("x", "X", "A")
    db.mor("y", "X", "B")
    db.diagram("D", "C", {"a": "A", "b": "B"}, {"e": ("a", "b", "f")})
    db.cone("c", "D", "X", {"a": "x", "b": "y"})
    assert db.cone_reasons("c") == ["missing_composite"]
    db.comp("f", "x", "y")
    assert db.cone_reasons("c") == []


def test_foreign_leg(db):
    db.category("C")
    db.obj("C", "A")
    db.diagram("D", "C", {"a": "A"})
    db.diagram("D2", "C", {"a": "A"})
    db.cone("c", "D", "A", {"a": "id_A"})
    db.leg("c", "D2", "a", "id_A")
    assert db.cone_reasons("c") == ["foreign_leg"]


def test_finalize_refuses_invalid_cone_in_permissive_mode(db):
    db.category("C")
    db.obj("C", "A")
    db.obj("C", "B")
    db.diagram("D", "C", {"b": "B"})
    db.cone("c", "D", "A", {})
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="Cannot finalize limit"):
        db.finalize("L", "c")
    db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_mode_raises_permissive_logs(db):
    db.category("C")
    db.obj("C", "A")
    db.obj("C", "B")
    db.diagram("D", "C", {"b": "B"})
    db.cone("c", "D", "A", {})
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q("SELECT check_cone_commutes(%s)", db.ids["c"])
    db.q("ROLLBACK TO SAVEPOINT s")


def test_limit_row_over_wrong_diagram(db):
    product_category(db)
    db.diagram("D2", "C", {"a": "A"})
    db.q('INSERT INTO "limit" (diagram_id, cone_id) VALUES (%s, %s)', db.ids["D2"], db.ids["lim"])
    assert "diagram_mismatch" in db.lim_violations("lim")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="another diagram"):
        db.q('INSERT INTO "limit" (diagram_id, cone_id) VALUES (%s, %s)', db.ids["D2"], db.ids["lim"])
    db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_universality_raises(db):
    product_category(db)
    db.mor("u2", "X", "P")
    db.comp("p", "u2", "x1")
    db.comp("q", "u2", "x2")
    db.finalize("L", "lim")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not universal"):
        db.universal("L")
    db.q("ROLLBACK TO SAVEPOINT s")


# ---------------------------------------------------------------------------
# Colimits
# ---------------------------------------------------------------------------
def test_coproduct_is_universal(db):
    coproduct_category(db)
    db.finalize("K", "colim", cocone=True)
    assert db.universal("K", cocone=True) is True


def test_coproduct_second_mediator(db):
    coproduct_category(db)
    db.mor("v2", "S", "Y")
    db.comp("v2", "i", "y1")
    db.comp("v2", "j", "y2")
    db.finalize("K", "colim", cocone=True)
    assert db.universal("K", cocone=True) is False
    assert db.lim_violations("colim", cocone=True) == ["legs_not_jointly_epic", "non_unique_mediator"]


def test_cocone_triangle_with_identity(db):
    """Colimit of A →f B is B with legs f, id_B: ι_A = ι_B ∘ f."""
    db.category("C")
    db.obj("C", "A")
    db.obj("C", "B")
    db.mor("f", "A", "B")
    db.diagram("D", "C", {"a": "A", "b": "B"}, {"e": ("a", "b", "f")})
    db.cone("k", "D", "B", {"a": "f", "b": "id_B"}, cocone=True)
    assert db.cone_reasons("k", cocone=True) == []
    db.cone("bad", "D", "B", {"a": "f", "b": "id_B"}, cocone=True)
    db.finalize("K", "k", cocone=True)
    assert db.universal("K", cocone=True) is True
    # Wrong direction for a cocone leg.
    db.cone("rev", "D", "A", {"a": "id_A", "b": "f"}, cocone=True)
    assert db.cone_reasons("rev", cocone=True) == ["leg_typing"]


def test_colimit_missing_mediator(db):
    coproduct_category(db)
    db.mor("z1", "A", "Y")
    db.cone("other2", "D", "Y", {"a": "z1", "b": "y2"}, cocone=True)
    db.finalize("K", "colim", cocone=True)
    assert db.universal("K", cocone=True) is False
    assert db.lim_violations("colim", cocone=True) == ["no_mediator"]


# ---------------------------------------------------------------------------
# Batch tier
# ---------------------------------------------------------------------------
def test_run_all_batch_checks_covers_limits(db):
    product_category(db)
    db.mor("u2", "X", "P")
    db.comp("p", "u2", "x1")
    db.comp("q", "u2", "x2")
    db.finalize("L", "lim")
    db.clear_lim_violations()
    db.q("SELECT run_all_batch_checks()")
    assert db.lim_violations("lim") == ["legs_not_jointly_monic", "non_unique_mediator"]
    modules = dict(db.q("SELECT module, count FROM violation_summary()"))
    assert modules.get("limit") == 2


def test_database_agrees_with_reference_engine_on_divisor_lattice(db):
    """Load the divisors of 12 (a ≤ b iff a | b) with every composite, record
    every cone over each two-node discrete diagram, and compare the database's
    verdict for every cone with the in-memory engine (and with gcd)."""
    import itertools
    import math

    from qbx.categorical import Diagram, LimitChecker, all_cones
    from qbx.core.enforced_functor import EnforcementMode
    from tests.test_limits import DIV12, divides, poset

    C, hom = poset(DIV12, divides)
    db.category("Div12")
    for x in DIV12:
        db.obj("Div12", x)                       # creates id_x
    for m, (s, t) in C.morphisms.items():
        if s != t:
            db.mor(m, s, t)
    for (f, g), h in C.compositions.items():
        db.comp(g, f, h)                         # h = g ∘ f
    for k, (a, b) in enumerate(itertools.combinations(DIV12, 2)):
        D = Diagram(C, {"a": a, "b": b})
        dname = f"D{k}"
        db.diagram(dname, "Div12", {"a": a, "b": b})
        cones = list(all_cones(D))
        for c in cones:
            db.cone(f"{dname}@{c.apex}", dname, c.apex, c.legs)
        for c in cones:
            name = f"{dname}@{c.apex}"
            db.finalize(f"L{name}", name)
            in_db = db.universal(f"L{name}")
            ref = LimitChecker(EnforcementMode.PERMISSIVE).verify_universality(c)
            assert in_db == ref == (c.apex == str(math.gcd(int(a), int(b)))), (a, b, c.apex)


# ---------------------------------------------------------------------------
# Random comparison with the reference engine (registry R-016, backlog D1-001)
# ---------------------------------------------------------------------------
def _random_limit_instance(rng, db, p):
    """Load a random finite "category" with parallel arrows and a partial
    composition table, random diagrams (with arrows, nodes without an object,
    foreign objects and mistyped arrows) and random cones and cocones (with
    missing, mistyped, foreign-category and foreign-diagram legs) into the
    database, and build the same data for the reference engine.

    Returns ``(cones, diagrams)`` where ``cones`` maps a cone name to its
    reference :class:`Cone` (the ``name`` field is the ledger name)."""
    from qbx.categorical import Cone, Diagram, all_cones
    from qbx.core.enforced_functor import Category

    C = Category(id=p + "C", name=p + "C")
    db.category(p + "C")
    db.category(p + "F")
    objs = [f"{p}o{i}" for i in range(rng.randint(2, 4))]
    for o in objs:
        db.obj(p + "C", o)
        C.add_object(o, o)
        C.add_identity(o, "id_" + o)
    foreign = p + "z"
    db.obj(p + "F", foreign)                       # object and identity of another category

    k = 0
    for s in objs:
        for t in objs:
            for _ in range(rng.choice([0, 0, 1, 1, 2])):
                name = f"{p}m{k}"
                k += 1
                db.mor(name, s, t)
                C.add_morphism(name, s, t)
    non_id = [m for m in C.morphisms if m not in C.identities.values()]
    for f in non_id:
        for g in non_id:
            if C.morphisms[f][1] != C.morphisms[g][0] or rng.random() < 0.25:
                continue
            want = (C.morphisms[f][0], C.morphisms[g][1])
            results = [h for h, st in C.morphisms.items() if st == want]
            if results:
                h = rng.choice(results)
                db.comp(g, f, h)
                C.add_composition(f, g, h)

    def hom(s, t):
        return [m for m, st in C.morphisms.items() if st == (s, t)]

    def some_morphism(s, t):
        """Usually a morphism s → t when there is one; sometimes any morphism
        (possibly ill-typed) or the identity of the foreign object."""
        r = rng.random()
        if r < 0.08:
            return "id_" + foreign
        good = hom(s, t) if s in C.objects and t in C.objects else []
        if good and r < 0.85:
            return rng.choice(good)
        return rng.choice(sorted(C.morphisms))

    ghost = p + "G"                                # a second diagram whose node is "foreign"
    db.diagram(ghost, p + "C", {"g": objs[0]})

    cones = {}
    diagrams = []
    for di in range(rng.randint(2, 3)):
        dname = f"{p}D{di}"
        nodes = {}
        for ni in range(rng.randint(0, 3)):
            r = rng.random()
            nodes[f"n{ni}"] = None if r < 0.06 else foreign if r < 0.12 else rng.choice(objs)
        arrows = {}
        ghost_arrows = []
        for ai in range(rng.randint(0, 3) if nodes else 0):
            s, t = rng.choice(list(nodes)), rng.choice(list(nodes))
            r = rng.random()
            if r < 0.06:
                arrows[f"a{ai}"] = (s, t, None)
            elif r < 0.12:
                ghost_arrows.append((f"a{ai}", t, some_morphism(objs[0], nodes[t] or objs[0])))
            else:
                arrows[f"a{ai}"] = (s, t, some_morphism(nodes[s], nodes[t]))
        db.diagram(dname, p + "C", nodes, arrows)
        D = Diagram(C, dict(nodes), dict(arrows))
        for label, t, m in ghost_arrows:
            db.q("INSERT INTO diagram_arrow (diagram_id, label, source_node_id, target_node_id, "
                 "morphism_id) VALUES (%s, %s, %s, %s, %s)",
                 db.ids[dname], label, db.ids[f"{ghost}.g"], db.ids[f"{dname}.{t}"], db.ids[m])
            D.add_arrow(label, "<ghost>", t, m)      # source node not in this diagram
        diagrams.append(dname)

        for cocone in (False, True):
            tag = "k" if cocone else "c"
            # A random subset of the genuine cones (so that universality has
            # something to find), then random, mostly malformed ones.
            genuine = list(all_cones(D, cocone))
            rng.shuffle(genuine)
            for ci, c in enumerate(genuine[:rng.randint(0, 5)]):
                name = f"{dname}.{tag}g{ci}"
                db.cone(name, dname, c.apex, c.legs, cocone=cocone)
                cones[name] = Cone(D, c.apex, dict(c.legs), cocone, name)
            for ci in range(rng.randint(1, 4)):
                name = f"{dname}.{tag}r{ci}"
                apex = foreign if rng.random() < 0.07 else rng.choice(objs)
                legs = {}
                for n, obj in nodes.items():
                    if rng.random() < 0.88:
                        src, tgt = (obj, apex) if cocone else (apex, obj)
                        legs[n] = some_morphism(src, tgt)
                db.cone(name, dname, apex, legs, cocone=cocone)
                ref = Cone(D, apex, dict(legs), cocone, name)
                if rng.random() < 0.1:
                    m = some_morphism(objs[0], objs[0])
                    db.leg(name, ghost, "g", m, cocone=cocone)
                    ref.legs["<ghost>"] = m
                cones[name] = ref
    return cones, diagrams


def _db_universality_reasons(db, name, cocone):
    """Insert a (co)limit row for the cone directly, discard what the insert
    trigger logged, and run the universality check."""
    table, col = ("colimit", "cocone_id") if cocone else ('"limit"', "cone_id")
    lid = db.one(f"INSERT INTO {table} (diagram_id, {col}) "
                 f"SELECT diagram_id, id FROM {'cocone' if cocone else 'cone'} WHERE id = %s "
                 "RETURNING id", db.ids[name])
    db.clear_lim_violations()
    fn = "verify_colimit_universality" if cocone else "verify_limit_universality"
    verdict = db.one(f"SELECT {fn}(%s)", lid)
    return verdict, db.lim_violations(name, cocone=cocone)


def test_random_cones_match_reference(db):
    """Cone and cocone problems agree with `cone_problems` on random data,
    including diagrams with arrows, ill-typed and foreign legs."""
    import random

    from qbx.categorical import cone_problems

    rng = random.Random(7)
    seen = set()
    for i in range(25):
        cones, _ = _random_limit_instance(rng, db, f"r{i}_")
        for name, ref in cones.items():
            expected = sorted(r for r, _ in cone_problems(ref))
            seen.update(expected)
            assert db.cone_reasons(name, cocone=ref.cocone) == expected, (name, ref)
    # The random data reaches every cone-level reason.
    assert seen >= {"apex_category", "node_without_object", "node_category", "missing_leg",
                    "leg_typing", "foreign_leg", "arrow_without_morphism", "arrow_typing",
                    "missing_composite", "non_commuting_triangle"}, seen


def test_random_universality_matches_reference(db):
    """`verify_limit_universality` / `verify_colimit_universality` agree with
    `LimitChecker.verify_universality` against the recorded (co)cones."""
    import random

    from qbx.categorical import LimitChecker
    from qbx.core.enforced_functor import EnforcementMode

    rng = random.Random(70)
    seen = set()
    verdicts = set()
    for i in range(20):
        cones, _ = _random_limit_instance(rng, db, f"u{i}_")
        for name, ref in cones.items():
            others = [o for n, o in cones.items()
                      if n != name and o.cocone == ref.cocone and o.diagram is ref.diagram]
            checker = LimitChecker(EnforcementMode.PERMISSIVE)
            expected = checker.verify_universality(ref, others)
            verdict, reasons = _db_universality_reasons(db, name, ref.cocone)
            assert (verdict, reasons) == (expected, checker.reasons()), name
            seen.update(reasons)
            verdicts.add(verdict)
    assert verdicts == {True, False}
    assert seen >= {"invalid_cone", "no_mediator", "non_unique_mediator",
                    "legs_not_jointly_monic", "legs_not_jointly_epic", "missing_composite"}, seen
