"""Live-database tests for migration 006 (monads and comonads).

Fixtures are one-object categories (monoids) and the indiscrete category on
P, Q.  In a one-object category an endofunctor is a monoid endomorphism φ, a
unit is an element e and a multiplication an element u; the monad laws read

    left_unit      u · φ(e) = 1        (μ_X ∘ T(η_X) = id)
    right_unit     u · e    = 1        (μ_X ∘ η_{T(X)} = id)
    associativity  u · φ(u) = u · u    (μ_X ∘ T(μ_X) = μ_X ∘ μ_{T(X)})
"""

import itertools

import pytest

psycopg2 = pytest.importorskip("psycopg2")


def _monoid(db, cat, elements, mul):
    """One object S; `elements` are the non-identity morphisms; `mul(x, y)`
    returns the name of x · y = x ∘ y ('1' for the identity)."""
    db.category(cat)
    db.obj(cat, "S")
    for e in elements:
        db.mor(e, "S", "S")
    for g, f in itertools.product(elements, repeat=2):
        h = mul(g, f)
        db.comp(g, f, "id_S" if h == "1" else h)


def _endo(db, name, cat, phi):
    """Endofunctor of a one-object category given by the element map phi."""
    mors = {m: ("id_S" if phi.get(m, m) == "1" else phi.get(m, m)) for m in db.morphisms[cat]}
    db.functor(name, cat, cat, {"S": "S"}, mors)


def _z2(db):
    _monoid(db, "M", ["s"], lambda g, f: "1")
    for n in ("Id", "T", "TT"):
        _endo(db, n, "M", {})


def _z3(db):
    table = {("g", "g"): "g2", ("g", "g2"): "1", ("g2", "g"): "1", ("g2", "g2"): "g"}
    _monoid(db, "M", ["g", "g2"], lambda x, y: table[(x, y)])
    for n in ("Id", "T", "TT"):
        _endo(db, n, "M", {})


def _klein(db):
    """Z/2 × Z/2 = {1, a, b, c}; T swaps a and b (so T∘T = Id)."""
    def mul(x, y):
        v = {"1": (0, 0), "a": (1, 0), "b": (0, 1), "c": (1, 1)}
        inv = {w: k for k, w in v.items()}
        return inv[((v[x][0] + v[y][0]) % 2, (v[x][1] + v[y][1]) % 2)]
    _monoid(db, "M", ["a", "b", "c"], mul)
    _endo(db, "Id", "M", {})
    _endo(db, "T", "M", {"a": "b", "b": "a"})
    _endo(db, "TT", "M", {})


def test_z2_monad_is_clean(db):
    """T = Id, η = μ = s with s ∘ s = id: a genuine monad with real composites."""
    _z2(db)
    db.nt("eta", "Id", "T", {"S": "s"})
    db.nt("mu", "TT", "T", {"S": "s"})
    db.monad("Z2", "M", "T", "eta", "mu")
    assert db.monad_laws("Z2") == []
    assert db.naturality_violations("eta") == []
    assert db.naturality_violations("mu") == []


def test_z2_monad_passes_in_strict_mode(db):
    _z2(db)
    db.nt("eta", "Id", "T", {"S": "s"})
    db.nt("mu", "TT", "T", {"S": "s"})
    db.set_mode("strict")
    db.monad("Z2", "M", "T", "eta", "mu")
    assert db.monad_laws("Z2") == []


def test_z3_unit_laws_fail(db):
    """η = μ = g: g ∘ g = g2 ≠ id, so both unit laws fail; associativity holds."""
    _z3(db)
    db.nt("eta", "Id", "T", {"S": "g"})
    db.nt("mu", "TT", "T", {"S": "g"})
    db.monad("Z3", "M", "T", "eta", "mu")
    assert db.monad_laws("Z3") == ["left_unit", "right_unit"]


def test_z3_strict_mode_raises(db):
    _z3(db)
    db.nt("eta", "Id", "T", {"S": "g"})
    db.nt("mu", "TT", "T", {"S": "g"})
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="Monad law"):
        db.monad("Z3", "M", "T", "eta", "mu")


def test_klein_left_unit_and_associativity_fail(db):
    """φ swaps a, b; e = u = a: u·φ(e) = c ≠ 1 (left_unit), u·e = 1 (right_unit
    holds), u·φ(u) = c ≠ 1 = u·u (associativity).  The original checker looked
    up μ_{T(X)} ∘ μ_X for the right-hand side of associativity."""
    _klein(db)
    db.nt("eta", "Id", "T", {"S": "a"})
    db.nt("mu", "TT", "T", {"S": "a"})
    db.monad("K", "M", "T", "eta", "mu")
    assert db.monad_laws("K") == ["associativity", "left_unit"]


def test_multiplication_functor_mismatch(db):
    """μ must go out of T∘T; using T (≠ T∘T, since φ ≠ id) is reported."""
    _klein(db)
    db.nt("eta", "Id", "T", {"S": "id_S"})
    db.nt("mu", "T", "T", {"S": "id_S"})
    db.monad("K", "M", "T", "eta", "mu")
    assert "multiplication_functor_mismatch" in db.monad_laws("K")


def _indiscrete(db):
    db.category("I")
    db.obj("I", "P")
    db.obj("I", "Q")
    db.mor("p", "P", "Q")
    db.mor("q", "Q", "P")
    db.comp("q", "p", "id_P")
    db.comp("p", "q", "id_Q")
    ms = db.morphisms["I"]
    db.functor("Id", "I", "I", {"P": "P", "Q": "Q"}, {m: m for m in ms})
    for n in ("T", "TT"):     # constant at P (T∘T = T)
        db.functor(n, "I", "I", {"P": "P", "Q": "P"}, {m: "id_P" for m in ms})


def test_monad_of_adjunction_identities_only(db):
    """T constant at P, η_Q = q, μ = id: every law composite has an identity
    factor (never stored in `composition`) — the unit laws are applied."""
    _indiscrete(db)
    db.nt("eta", "Id", "T", {"P": "id_P", "Q": "q"})
    db.nt("mu", "TT", "T", {"P": "id_P", "Q": "id_P"})
    db.monad("C", "I", "T", "eta", "mu")
    assert db.monad_laws("C") == []


def test_component_typing_and_missing(db):
    _indiscrete(db)
    db.nt("eta", "Id", "T", {"P": "id_P", "Q": "p"})     # p : P → Q, not Q → P
    db.nt("mu", "TT", "T", {"P": "id_P"})                 # μ_Q missing
    db.monad("C", "I", "T", "eta", "mu")
    laws = db.monad_laws("C")
    assert "unit_component_typing" in laws
    assert "multiplication_component_missing" in laws
    assert "left_unit_missing" in laws                   # μ_Q missing


def test_direct_insert_is_checked(db):
    _z3(db)
    db.nt("eta", "Id", "T", {"S": "g"})
    db.nt("mu", "TT", "T", {"S": "g"})
    mid = db.one(
        "INSERT INTO monad (name, category_id, endofunctor_id, unit_nt_id, multiplication_nt_id) "
        "VALUES ('Z3', %s, %s, %s, %s) RETURNING id",
        db.ids["M"], db.ids["T"], db.ids["eta"], db.ids["mu"],
    )
    db.ids["Z3"] = mid
    assert db.monad_laws("Z3") == ["left_unit", "right_unit"]


def test_monad_typing(db):
    _z2(db)
    db.category("N")
    db.obj("N", "R")
    db.functor("U", "M", "N", {"S": "R"}, {"id_S": "id_R", "s": "id_R"})
    db.nt("eta", "Id", "T", {"S": "s"})
    db.nt("mu", "TT", "T", {"S": "s"})
    db.monad("bad", "M", "U", "eta", "mu")
    assert db.monad_laws("bad") == ["monad_typing"]


# ---------------------------------------------------------------------------
# Comonads
# ---------------------------------------------------------------------------

def test_z2_comonad_is_clean(db):
    _z2(db)
    db.nt("eps", "T", "Id", {"S": "s"})
    db.nt("delta", "T", "TT", {"S": "s"})
    db.comonad("Z2", "M", "T", "eps", "delta")
    assert db.comonad_laws("Z2") == []


def test_z3_counit_laws_fail(db):
    _z3(db)
    db.nt("eps", "T", "Id", {"S": "g"})
    db.nt("delta", "T", "TT", {"S": "g"})
    db.comonad("Z3", "M", "T", "eps", "delta")
    assert db.comonad_laws("Z3") == ["left_counit", "right_counit"]


def test_klein_comonad_right_counit_and_coassociativity_fail(db):
    """Dual of the Klein monad: ε = δ = a; ε·δ = 1 (left_counit holds),
    φ(ε)·δ = b·a = c (right_counit fails), δ·δ = 1 ≠ c = φ(δ)·δ."""
    _klein(db)
    db.nt("eps", "T", "Id", {"S": "a"})
    db.nt("delta", "T", "TT", {"S": "a"})
    db.comonad("K", "M", "T", "eps", "delta")
    assert db.comonad_laws("K") == ["coassociativity", "right_counit"]


def test_comonad_identities_only(db):
    """G constant at P on the indiscrete category, ε_Q = p, δ = id."""
    _indiscrete(db)
    db.nt("eps", "T", "Id", {"P": "id_P", "Q": "p"})
    db.nt("delta", "T", "TT", {"P": "id_P", "Q": "id_P"})
    db.comonad("W", "I", "T", "eps", "delta")
    assert db.comonad_laws("W") == []


def test_run_all_batch_checks_with_monads(db):
    """run_all_batch_checks used to crash as soon as a monad existed."""
    _z3(db)
    db.nt("eta", "Id", "T", {"S": "g"})
    db.nt("mu", "TT", "T", {"S": "g"})
    db.monad("Z3", "M", "T", "eta", "mu")
    db.nt("eps", "T", "Id", {"S": "g"})
    db.nt("delta", "T", "TT", {"S": "g"})
    db.comonad("W3", "M", "T", "eps", "delta")
    db.q("DELETE FROM monad_violation")
    db.q("DELETE FROM comonad_violation")
    db.q("SELECT run_all_batch_checks()")
    assert db.monad_laws("Z3") == ["left_unit", "right_unit"]
    assert db.comonad_laws("W3") == ["left_counit", "right_counit"]


# ---------------------------------------------------------------------------
# Random instances: the database reports what the reference reports
# (qbx.categorical.Monad / Comonad; registry R-015)
# ---------------------------------------------------------------------------
import random  # noqa: E402
from collections import Counter  # noqa: E402

from qbx.categorical import Comonad, Monad, NaturalTransformation  # noqa: E402
from tests.live_db.test_adjunction_db import (  # noqa: E402
    PERMISSIVE, _compose_maps, _load_category, _model_category, _perturb,
    _random_category, _random_components, _random_map, _Table)


def _endo_keys_db(db, table, key_col, name):
    back = {v: k for k, v in db.ids.items()}
    rows = db.q(f"SELECT law, object_id, details->>'morphism', left_side, right_side FROM {table} "
                f"WHERE {key_col} = %s", db.ids[name])
    out = Counter()
    for law, obj, mor, left, right in rows:
        if law.endswith(("_unit", "_counit")):
            extra = (back.get(left),)
        elif law in ("associativity", "coassociativity"):
            extra = (back.get(left), back.get(right))
        else:
            extra = ()
        out[(law, back.get(obj or mor)) + extra] += 1
    return out


def _endo_keys_ref(struct):
    out = Counter()
    for v in struct.violations:
        d, law = v["details"], v["law"]
        subject = d.get("object", d.get("morphism", d.get("X")))
        if law.endswith(("_unit", "_counit")):
            extra = (d.get("composite"),)
        elif law in ("associativity", "coassociativity"):
            extra = (d.get("lhs"), d.get("rhs"))
        else:
            extra = ()
        out[(law, subject) + extra] += 1
    return out


@pytest.mark.parametrize("kind", ["monad", "comonad"])
def test_endo_structure_check_matches_reference(db, kind):
    rng = random.Random(6 if kind == "monad" else 60)
    seen = Counter()
    for i in range(200):
        p = f"{kind[0]}{i}_"
        C = _random_category(rng, p, "c")
        T = _random_map(rng, C, C)
        ident = ({o: o for o in C["objs"]}, {m: m for m in C["all"]})
        TT = _compose_maps(T, T)
        if kind == "monad":
            specs = {"aF": ident, "aG": T, "bF": TT, "bG": T}
        else:
            specs = {"aF": T, "aG": ident, "bF": T, "bG": TT}
        maps = {k: _perturb(rng, v, C, C) for k, v in specs.items()}
        comps_a = _random_components(rng, C, maps["aF"], maps["aG"])
        comps_b = _random_components(rng, C, maps["bF"], maps["bG"])
        cn = p + "C"
        _load_category(db, C, cn)
        db.functor(p + "T", cn, cn, *T)
        for k, v in maps.items():
            db.functor(p + k, cn, cn, *v)
        db.nt(p + "a", p + "aF", p + "aG", comps_a)
        db.nt(p + "b", p + "bF", p + "bG", comps_b)
        if kind == "monad":
            db.monad(p + "M", cn, p + "T", p + "a", p + "b")
        else:
            db.comonad(p + "M", cn, p + "T", p + "a", p + "b")

        K = _model_category(C, cn)
        tf = {k: _Table(p + k, K, K, *v) for k, v in maps.items()}
        a = NaturalTransformation(p + "a", "a", tf["aF"], tf["aG"], mode=PERMISSIVE)
        a.components.update(comps_a)
        b = NaturalTransformation(p + "b", "b", tf["bF"], tf["bG"], mode=PERMISSIVE)
        b.components.update(comps_b)
        cls = Monad if kind == "monad" else Comonad
        struct = cls(p + "M", "M", _Table(p + "T", K, K, *T), a, b, mode=PERMISSIVE)
        struct.verify_typing() and (struct.verify_functors(), struct.verify_components(),
                                    struct.verify_laws())
        ref = _endo_keys_ref(struct)
        got = _endo_keys_db(db, f"{kind}_violation", f"{kind}_id", p + "M")
        assert got == ref, (i, sorted(got - ref), sorted(ref - got))
        seen.update(k[0] for k in ref)
        seen["clean" if not ref else "dirty"] += 1
    unit = "unit" if kind == "monad" else "counit"
    mult = "multiplication" if kind == "monad" else "comultiplication"
    laws = (("left_unit", "right_unit", "associativity") if kind == "monad"
            else ("left_counit", "right_counit", "coassociativity"))
    expected = [f"{unit}_functor_mismatch", f"{mult}_functor_mismatch", f"{unit}_component_typing",
                f"{mult}_component_typing", f"{mult}_component_missing", "clean"]
    for law in laws:
        expected += [law, law + "_missing", law + "_composite_missing"]
    for law in expected:
        assert seen[law] > 0, (law, seen)
