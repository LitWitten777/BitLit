"""Migration 021 (Garside normal-form certificates) on a real PostgreSQL.

The reference is ``qbx_ir.normal_form_ledger``: on random data — including
certificates of malformed braids and certificates with wrong hashes, powers,
factors and normal words — the database reports exactly the problems the Python
code reports, with the same details, in the same order.  The equality answers,
the transport check (normal forms agree along accepted rewrites and
derivations) and the consistency check with the invariant certificates of
migration 020 are compared too.

Formal backing: ``Formal/BraidNormalForm.lean`` — ``nfValue_leftNormalForm``
(the normal form stands for the braid of the word), ``eval_eq_of_leftNormalForm_eq``
(equal normal forms prove equal braids) and ``cert_eq_of_leftNormalForm_eq``
(… and equal invariant certificates).  The answer "different" relies on
Garside's uniqueness theorem (H-057, provisional).
"""

from __future__ import annotations

import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.invariant_ledger import CertRow
from qbx_ir.ledger import BraidRow, braid_problems, derivation_problems, rewrite_problems
from qbx_ir.normal_form_ledger import (
    NFRow,
    certificate_problems,
    equality_certified,
    invariant_consistency_problems,
    normal_form_values,
    normal_forms_equal,
    transport_problems,
)
from tests.live_db.test_braid_ledger_db import build_random_ledger, random_word

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "021_braid_normal_forms.sql"


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def as_lists(factors):
    return [list(f) for f in factors]


def test_values_agree_with_python(db):
    rng = random.Random(5)
    for _ in range(200):
        n = rng.randint(1, 6)
        w = random_word(rng, n, rng.randint(0, 12)) if n > 1 else []
        got = db.q("SELECT * FROM braid_normal_form_values(%s, %s::int[])", n, w)[0]
        v = normal_form_values(n, w)
        assert got == (v.power, as_lists(v.factors), list(v.normal_word)), (n, w)


def test_values_on_known_braids(db):
    def nf(n, w):
        return db.q("SELECT * FROM braid_normal_form_values(%s, %s::int[])", n, w)[0]
    assert nf(3, [1, 2, 1]) == (1, [], [1, 2, 1])                     # Δ
    assert nf(3, [2, 1, 2]) == (1, [], [1, 2, 1])                     # Δ again
    assert nf(3, [1, 2, 1, -2, -1, -2]) == (0, [], [])                # trivial
    assert nf(3, [-1]) == (-1, [[2, 0, 1]], [-1, -2, -1, 1, 2])
    assert nf(2, [1, 1, -1]) == (1, [], [1])
    assert nf(1, []) == (0, [], [])
    assert nf(4, [2, 1, 3, 2]) == (0, [[2, 3, 0, 1]], [2, 1, 3, 2])


def random_nf(rng, braid: BraidRow) -> NFRow:
    """A certificate for ``braid``: usually the right one, sometimes tampered with."""
    if braid_problems(braid):
        return NFRow(braid, braid.braid_hash, 0, (), ())
    good = NFRow.of(braid)
    roll = rng.random()
    n = braid.strand_count
    if roll < 0.07:
        return NFRow(braid, "e" * 8, good.power, good.factors, good.normal_word)
    if roll < 0.14:
        return NFRow(braid, good.braid_hash, good.power + rng.choice([-1, 1]), good.factors,
                     good.normal_word)
    if roll < 0.20 and good.factors:
        f = list(good.factors[0])
        f[0], f[-1] = f[-1], f[0]
        return NFRow(braid, good.braid_hash, good.power, (tuple(f),) + good.factors[1:],
                     good.normal_word)
    if roll < 0.25:
        return NFRow(braid, good.braid_hash, good.power,
                     good.factors + (tuple(range(n - 1, -1, -1)),), good.normal_word)
    if roll < 0.31:
        return NFRow(braid, good.braid_hash, good.power, good.factors, good.normal_word + (1,))
    return good


def insert_nf(db, bid, c: NFRow):
    return db.one(
        "INSERT INTO braid_normal_form (braid_id, braid_hash, power, factors, normal_word) "
        "VALUES (%s, %s, %s, %s::int[], %s::int[]) RETURNING id",
        bid, c.braid_hash, c.power, as_lists(c.factors), list(c.normal_word))


def test_random_certificates_equality_transport_and_consistency_match_reference(db):
    seen = Counter()
    for seed in range(10):
        db.q("SAVEPOINT s")
        rng = random.Random(400 + seed)
        m = build_random_ledger(db, rng)
        nfs, invs, nf_ids = {}, {}, {}
        for bid, braid in m.braid_row.items():
            if rng.random() < 0.85:
                c = random_nf(rng, braid)
                cid = insert_nf(db, bid, c)
                nfs[bid], nf_ids[bid] = c, cid
                got = rows(db, "SELECT * FROM braid_normal_form_problems(%s)", cid)
                assert got == certificate_problems(c), (seed, c)
                seen.update(r for r, _ in got)
                if not got:
                    seen["certificate_ok"] += 1
            if not braid_problems(braid) and rng.random() < 0.7:
                db.one("SELECT certify_braid_invariants(%s)", bid)
                invs[bid] = CertRow.of(braid)
        ids = list(m.braid_row)
        # Equality answers on random pairs (and on every pair with equal words in B_n).
        pairs = [(rng.choice(ids), rng.choice(ids)) for _ in range(60)]
        pairs += [(a, b) for a in ids for b in ids
                  if a != b and nfs.get(a) and nfs.get(b)
                  and normal_forms_equal(nfs[a], nfs[b]) is True]
        for a, b in pairs:
            got = db.one("SELECT braid_normal_form_equal(%s, %s)", a, b)
            want = normal_forms_equal(nfs.get(a), nfs.get(b))
            assert got == want, (seed, got, want)
            assert db.one("SELECT braid_nf_equality_certified(%s, %s)", a, b) == \
                equality_certified(nfs.get(a), nfs.get(b))
            if want is not None:
                ra, rb = m.braid_row[a], m.braid_row[b]
                truth = braid_group_equal(Braid.from_short_form(ra.strand_count, list(ra.word)),
                                          Braid.from_short_form(rb.strand_count, list(rb.word)))
                assert want == truth
                seen["equal" if want else "different"] += 1
                if want and a != b:
                    seen["equality_certified_distinct_words"] += 1
        # Consistency with the invariant certificates: never fires on a sound ledger.
        for bid, cid in nf_ids.items():
            got = rows(db, "SELECT * FROM braid_nf_invariant_problems(%s)", cid)
            others = [(nfs[o], invs.get(o)) for o in nf_ids]
            want = invariant_consistency_problems(nfs[bid], invs.get(bid), others)
            assert got == want == [], (seed, got, want)
        # Transport along every rewrite.
        for rid, r in m.rewrite_row.items():
            ok = not rewrite_problems(r)
            a, b = m.braid_id[r.input.key], m.braid_id[r.output.key]
            got = rows(db, "SELECT * FROM braid_rewrite_nf_transport_problems(%s)", rid)
            assert got == transport_problems(ok, nfs.get(a), nfs.get(b)) == [], (seed, got)
            if ok and normal_forms_equal(nfs.get(a), nfs.get(b)):
                seen["transport_checked"] += 1
        # Transport along random derivations.
        for _ in range(20):
            src = rng.choice(ids)
            steps, dirs, cur = [], [], src
            for _ in range(rng.randint(0, 4)):
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = m.braid_id[(r.output if d else r.input).key]
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, cur, steps, dirs)
            accepted = not derivation_problems(m.braid_row[src], m.braid_row[cur],
                                               [m.rewrite_row[s] for s in steps], dirs)
            got = rows(db, "SELECT * FROM braid_derivation_nf_transport_problems(%s)", did)
            assert got == transport_problems(accepted, nfs.get(src), nfs.get(cur)) == []
            if accepted and normal_forms_equal(nfs.get(src), nfs.get(cur)):
                seen["derivation_transport_checked"] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("braid_not_well_formed", "braid_hash_mismatch", "power_mismatch",
                   "factors_mismatch", "normal_word_mismatch", "certificate_ok", "equal",
                   "different", "equality_certified_distinct_words", "transport_checked",
                   "derivation_transport_checked"):
        assert seen[reason] > 0, reason


def test_writer_and_equality(db):
    """σ1σ2σ1 and σ2σ1σ2 are certified equal (both are Δ); σ1 and σ2 are not."""
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    b = db.one("SELECT register_braid(3, ARRAY[2, 1, 2])")
    c = db.one("SELECT register_braid(3, ARRAY[1])")
    d = db.one("SELECT register_braid(3, ARRAY[2])")
    assert db.one("SELECT braid_normal_form_equal(%s, %s)", a, b) is None   # no certificates
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", a, b) is False
    for x in (a, b, c, d):
        db.one("SELECT certify_braid_normal_form(%s)", x)
    ca = db.one("SELECT id FROM braid_normal_form WHERE braid_id = %s", a)
    assert db.one("SELECT certify_braid_normal_form(%s)", a) == ca        # one per braid
    assert db.one("SELECT braid_normal_form_equal(%s, %s)", a, b) is True
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", a, b) is True
    assert db.one("SELECT braid_normal_form_equal(%s, %s)", c, d) is False
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", c, d) is False
    assert db.q("SELECT power, factors, normal_word FROM braid_normal_form WHERE braid_id = %s",
                c) == [(0, [[1, 0, 2]], [1])]
    e = db.one("SELECT register_braid(4, ARRAY[1, 2, 1])")
    db.one("SELECT certify_braid_normal_form(%s)", e)
    assert db.one("SELECT braid_normal_form_equal(%s, %s)", a, e) is None  # B_3 vs B_4
    assert db.one("SELECT check_braid_normal_forms()") == 0
    assert db.one("SELECT count(*) FROM invariant_violation "
                  "WHERE module = 'braid_normal_forms'") == 0


def test_certify_refuses_a_malformed_braid(db):
    db.q("INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (3, ARRAY[1, 7], 'h')")
    bid = db.one("SELECT id FROM braid_word WHERE braid_hash = 'h'")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="braid_not_well_formed"):
        db.q("SELECT certify_braid_normal_form(%s)", bid)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="unknown braid"):
        db.q("SELECT certify_braid_normal_form(gen_random_uuid())")
    db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_mode_rejects_a_bad_certificate_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    insert = ("INSERT INTO braid_normal_form (braid_id, braid_hash, power, factors, normal_word) "
              "VALUES (%s, %s, 0, ARRAY[[2, 1, 0]], ARRAY[1, 2, 1])")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q(insert, a, h)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, a, h)
    got = db.q("SELECT violation_type, details FROM invariant_violation "
               "WHERE module = 'braid_normal_forms' ORDER BY detected_at, id")
    assert sorted(got, key=lambda t: t[0]) == [
        ("factors_mismatch", {"recorded": [[2, 1, 0]], "expected": [], "table": "braid_normal_form"}),
        ("power_mismatch", {"recorded": 0, "expected": 1, "table": "braid_normal_form"}),
    ]


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    c = db.one("SELECT certify_braid_normal_form(%s)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_normal_form SET power = 5 WHERE id = %s",
                "DELETE FROM braid_normal_form WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, c)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q("DELETE FROM braid_normal_form WHERE id = %s", c)
    assert db.q("SELECT violation_type, details->>'op' FROM invariant_violation "
                "WHERE module = 'braid_normal_forms'") == [("log_mutation", "DELETE")]


def test_phase2_batch_checks_include_the_normal_forms(db):
    a = db.one("SELECT register_braid(3, ARRAY[2, 1])")
    c = db.one("SELECT certify_braid_normal_form(%s)", a)
    db.q("UPDATE braid_normal_form SET normal_word = ARRAY[1, 2] WHERE id = %s", c)
    db.q("DELETE FROM invariant_violation")
    db.q("SELECT run_phase2_batch_checks()")
    assert db.q("SELECT violation_type FROM invariant_violation "
                "WHERE module = 'braid_normal_forms'") == [("normal_word_mismatch",)]


def test_consistency_check_catches_a_broken_invariant_loop(db):
    """With a deliberately broken writhe computation (word length instead of exponent sum),
    σ1σ1⁻¹ and ε get 'valid' invariant certificates that differ although their normal forms
    agree: the consistency check reports it (on a sound ledger it cannot fire — Lean:
    cert_eq_of_leftNormalForm_eq)."""
    x = db.one("SELECT register_braid(3, ARRAY[1, -1])")
    e = db.one("SELECT register_braid(3, ARRAY[]::int[])")
    db.one("SELECT certify_braid_normal_form(%s)", x)
    db.one("SELECT certify_braid_normal_form(%s)", e)
    db.q("ALTER FUNCTION braid_invariant_values(INT, INT[]) RENAME TO braid_invariant_values_orig")
    db.q("""
      CREATE FUNCTION braid_invariant_values(p_n INT, p_word INT[])
      RETURNS TABLE(permutation INT[], writhe INT, components INT[], linking INT[]) AS $$
        SELECT v.permutation, coalesce(cardinality(p_word), 0), v.components, v.linking
          FROM braid_invariant_values_orig(p_n, p_word) v $$ LANGUAGE sql""")
    db.one("SELECT certify_braid_invariants(%s)", x)
    db.one("SELECT certify_braid_invariants(%s)", e)
    hx = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", x)
    he = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", e)
    cx = db.one("SELECT id FROM braid_normal_form WHERE braid_id = %s", x)
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", x, e) is True
    assert rows(db, "SELECT * FROM braid_nf_invariant_problems(%s)", cx) == [
        ("invariants_contradict_normal_form", {"other_braid_hash": he, "invariants": ["writhe"]})]
    db.q("DELETE FROM invariant_violation")
    assert db.one("SELECT check_braid_normal_forms()") == 2
    got = db.q("SELECT details->>'other_braid_hash' FROM invariant_violation "
               "WHERE module = 'braid_normal_forms' "
               "AND violation_type = 'invariants_contradict_normal_form'")
    assert sorted(r[0] for r in got) == sorted([hx, he])


def test_transport_check_catches_a_broken_normal_form(db):
    """With a deliberately broken normal form (the power ignores inverse letters), the two
    ends of the R01 rewrite σ1σ1⁻¹ → ε get 'valid' certificates with different normal forms:
    the transport check reports it."""
    x = db.one("SELECT register_braid(3, ARRAY[1, -1])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R01', 0)", x)
    e = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r)
    db.q("ALTER FUNCTION braid_normal_form_values(INT, INT[]) RENAME TO braid_normal_form_values_orig")
    db.q("""
      CREATE FUNCTION braid_normal_form_values(p_n INT, p_word INT[])
      RETURNS TABLE(power INT, factors INT[], normal_word INT[]) AS $$
        SELECT v.power + coalesce(cardinality(p_word), 0), v.factors, v.normal_word
          FROM braid_normal_form_values_orig(p_n, p_word) v $$ LANGUAGE sql""")
    db.one("SELECT certify_braid_normal_form(%s)", x)
    db.one("SELECT certify_braid_normal_form(%s)", e)
    assert db.one("SELECT braid_normal_form_equal(%s, %s)", x, e) is False
    assert rows(db, "SELECT * FROM braid_rewrite_nf_transport_problems(%s)", r) == [
        ("normal_form_not_preserved", {})]


def test_migration_is_reapplicable(db):
    with db.conn.cursor() as cur:
        cur.execute(MIGRATION.read_text())
    a = db.one("SELECT register_braid(4, ARRAY[1, 3, -1])")
    assert db.one("SELECT certify_braid_normal_form(%s)", a)
