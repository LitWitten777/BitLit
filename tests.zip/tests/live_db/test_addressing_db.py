"""Migration 013 (addressing protocol: AddressV2, cache, gateways, DHT) on a
real PostgreSQL.

The reference is ``qbx.addressing``: on random inputs the database reports
exactly the problems the Python code reports, with the same details.

Formal backing: ``Formal/Addressing.lean`` — ``bytea_xor_order`` (sorting the
bytewise XORs as ``BYTEA`` is sorting by XOR distance) and
``xorDist_unidirectional`` / ``kClosest_unique`` (no ties, so the k closest
nodes are well defined) justify comparing ``dht_closest_nodes`` with the
Python ``closest_nodes`` as ordered lists.
"""

from __future__ import annotations

import hashlib
import json
import random
from collections import Counter
from datetime import timedelta
from pathlib import Path

import psycopg2
import pytest

from qbx.addressing import AddressBook, address_problems, closest_nodes, decode_strict
from qbx.addressing.dht import bucket_index, dht_key, xor_distance
from qbx.addressing.registry import (
    CacheRow,
    DhtRow,
    DiscoveryRow,
    GatewayRow,
    RegistryRow,
    cache_problems,
    discovery_problems,
    dht_problems,
    endpoint_ok,
    gateway_problems,
    registry_problems,
)
from qbx.core.hashing import pq_hash
from tests.addressing_examples import (
    ADDRESS_REASONS,
    ENDPOINTS_BAD,
    ENDPOINTS_OK,
    MALFORMED_CODES,
    NON_CANONICAL_CODES,
    canon,
    random_address,
    random_address_case,
    random_cbor_input,
)

B = psycopg2.Binary


def _float_canon(v):
    if isinstance(v, list):
        return [_float_canon(x) for x in v]
    if isinstance(v, dict):
        if "$float" in v:
            return ("float", repr(float(v["$float"])))
        return {k: _float_canon(x) for k, x in v.items()}
    return v


def problems(db, fn, row_id):
    return db.q(f"SELECT reason, details FROM {fn}(%s)", row_id)


def violations(db, table=None):
    if table is None:
        return db.q("SELECT reason, details FROM address_violation")
    return db.q("SELECT reason, details FROM address_violation WHERE subject_table = %s", table)


def register(db, a, pointers=("p",), algo="SHA3-256"):
    return db.one("SELECT register_address(%s, %s, NULL, %s, NULL, NULL, %s)",
                  a.address_hash(algo), B(a.encode()), json.dumps(list(pointers)), algo)


# ---------------------------------------------------------------------------
# Hashing and decoding
# ---------------------------------------------------------------------------
def test_sha3_matches_hashlib(db):
    rng = random.Random(1)
    lengths = [0, 1, 71, 72, 73, 135, 136, 137, 271, 272, 273] + [rng.randint(0, 400)
                                                                  for _ in range(15)]
    for n in lengths:
        data = bytes(rng.randrange(256) for _ in range(n))
        for algo in ("SHA3-256", "SHA3-512", "SHA-256", "PQ-HASH-1"):
            assert db.one("SELECT addr_pq_hash(%s, %s)", B(data), algo) == pq_hash(data, algo)
    assert db.one("SELECT addr_pq_hash('\\x00'::bytea, 'MD5')") is None


def test_cbor_decoder_agrees_with_python(db):
    rng = random.Random(2)
    seen = Counter()
    for i in range(1500):
        b = random_cbor_input(rng)
        py = decode_strict(b)
        got = db.one("SELECT addr_cbor_decode(%s)", B(b))
        assert got["malformed"] == py.malformed, (i, b.hex())
        assert got["non_canonical"] == py.non_canonical, (i, b.hex())
        assert _float_canon(got["value"]) == _float_canon(py.value), (i, b.hex())
        if py.malformed:
            seen[py.malformed["error"]] += 1
        seen.update(e["error"] for e in py.non_canonical)
    assert set(MALFORMED_CODES) | set(NON_CANONICAL_CODES) <= set(seen)


def test_address_problems_agree_with_python(db):
    rng = random.Random(3)
    seen = Counter()
    for i in range(1200):
        c = random_address_case(rng)
        py = address_problems(c["cbor"], c["hash"], c["algo"], c["trust"], c["depth"])
        got = db.q("SELECT reason, details FROM addr_address_problems(%s, %s, %s, %s, %s)",
                   B(c["cbor"]), c["hash"], c["algo"], c["trust"], c["depth"])
        assert canon(got) == canon(py), (i, c)
        seen.update(r for r, _ in py)
    assert set(ADDRESS_REASONS) - {"pointer_typing"} <= set(seen)


# ---------------------------------------------------------------------------
# Registry rows: triggers, batch checks, writers
# ---------------------------------------------------------------------------
def test_registry_rows_agree_with_python(db):
    """Rows inserted directly (permissive mode) are checked by the trigger; the
    logged problems are exactly the Python ones."""
    rng = random.Random(4)
    seen = Counter()
    for i in range(150):
        c = random_address_case(rng)
        pointers = rng.choice([["a"], [], ["a", "b"], ["a", "a"], [""], [1], {"x": 1}, "a"])
        h = c["hash"]
        if db.one("SELECT 1 FROM address_registry WHERE address_hash = %s", h):
            h = "%064x" % rng.getrandbits(256)      # keep the hash unique (a mismatching one)
        rid = db.one("INSERT INTO address_registry (address_hash, address_cbor, hash_algo, "
                     "pointers, trust_score, verification_depth) VALUES (%s, %s, %s, %s, %s, %s) "
                     "RETURNING id", h, B(c["cbor"]), c["algo"], json.dumps(pointers),
                     0.0 if c["trust"] is None else c["trust"],
                     0 if c["depth"] is None else c["depth"])
        row = RegistryRow(h, c["cbor"], c["algo"], pointers,
                          0.0 if c["trust"] is None else c["trust"],
                          0 if c["depth"] is None else c["depth"])
        py = registry_problems(row)
        assert canon(problems(db, "addr_registry_problems", rid)) == canon(py), i
        logged = db.q("SELECT reason, details FROM address_violation WHERE subject_id = %s", rid)
        assert canon(logged) == canon(py), i
        seen.update(r for r, _ in py)
    assert set(ADDRESS_REASONS) <= set(seen)


def test_register_address_writer(db):
    a = random_address(random.Random(5))
    b, h = a.encode(), a.address_hash()
    rid = register(db, a, ["p1"])
    row = db.q("SELECT trust_score, verification_depth, pointers, hash_algo FROM address_registry "
               "WHERE id = %s", rid)[0]
    assert row == (a.trust_score, a.verification_depth, ["p1"], "SHA3-256")
    assert violations(db) == []
    assert db.one("SELECT check_address(%s)", rid) is True
    # again: same row, new pointers appended, nothing else changes
    assert register(db, a, ["p2", "p1"]) == rid
    assert db.one("SELECT pointers FROM address_registry WHERE id = %s", rid) == ["p1", "p2"]
    for args, msg in [
        (("0" * 64, B(b), None, "[]", None, None, "SHA3-256"), "address_hash_mismatch"),
        ((h.upper(), B(b), None, "[]", None, None, "SHA3-256"), "address_hash_format"),
        ((h, B(b), None, "[]", 0.123, None, "SHA3-256"), "trust_mismatch"),
        ((h, B(b), None, "[]", None, a.verification_depth + 1, "SHA3-256"), "trust_mismatch"),
        ((h, B(b), None, '["x", "x"]', None, None, "SHA3-256"), "pointer_typing"),
        ((pq_hash(b"\x00"), B(b"\x00"), None, "[]", None, None, "SHA3-256"), "address_schema"),
        ((pq_hash(b"\x18\x01"), B(b"\x18\x01"), None, "[]", None, None, "SHA3-256"),
         "cbor_non_canonical"),
        ((h, B(b), B(b"\x01"), "[]", None, None, "SHA3-256"), "another owner"),
    ]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q("SELECT register_address(%s, %s, %s, %s, %s, %s, %s)", *args)
        db.q("ROLLBACK TO SAVEPOINT s")
    # the same hash text under another algorithm with other content is refused
    a2 = random_address(random.Random(6))
    rid2 = register(db, a2, [], algo="SHA3-512")
    assert db.one("SELECT hash_algo FROM address_registry WHERE id = %s", rid2) == "SHA3-512"


def test_original_bug_pointers_and_trust_are_not_replaced(db):
    """The original register_address replaced pointers and trust on conflict."""
    a = random_address(random.Random(7))
    rid = register(db, a, ["keep"])
    register(db, a, [])
    assert db.q("SELECT pointers, trust_score FROM address_registry WHERE id = %s", rid)[0] == \
        (["keep"], a.trust_score)


def test_address_is_immutable_and_trust_is_filled(db):
    a = random_address(random.Random(8))
    rid = db.one("INSERT INTO address_registry (address_hash, address_cbor) VALUES (%s, %s) "
                 "RETURNING id", a.address_hash(), B(a.encode()))
    assert db.q("SELECT trust_score, verification_depth, pointers FROM address_registry "
                "WHERE id = %s", rid)[0] == (a.trust_score, a.verification_depth, [])
    assert violations(db) == []
    for col, val in [("address_hash", "ab" * 32), ("address_cbor", B(b"\x00")),
                     ("hash_algo", "SHA3-512"), ("owner_pubkey", B(b"\x01"))]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="immutable"):
            db.q(f"UPDATE address_registry SET {col} = %s WHERE id = %s", val, rid)
        db.q("ROLLBACK TO SAVEPOINT s")
    assert a.trust_score != 0.75
    db.q("UPDATE address_registry SET trust_score = 0.75 WHERE id = %s", rid)
    assert violations(db, "address_registry") == [("trust_mismatch", {"column": "trust_score"})]


def test_strict_mode_raises(db):
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="not well formed"):
        db.q("INSERT INTO address_registry (address_hash, address_cbor) VALUES ('h', '\\x00')")


def test_permissive_mode_logs(db):
    db.q("INSERT INTO address_registry (address_hash, address_cbor) VALUES ('h', '\\x00')")
    reasons = sorted(r for r, _ in violations(db))
    assert reasons == ["address_hash_format", "address_schema"]
    assert db.one("SELECT count(*) FROM v_all_violations WHERE module = 'addressing'") == 2


# ---------------------------------------------------------------------------
# Cache, gateways, DHT nodes, discovery log
# ---------------------------------------------------------------------------
def test_other_rows_agree_with_python(db):
    rng = random.Random(9)
    a = random_address(rng)
    register(db, a)
    registered = {a.address_hash()}
    seen = Counter()
    hashes = [a.address_hash(), "cd" * 32, "zz", "PQ1:" + "ab" * 64, "AB" * 32]
    for i in range(120):
        h = rng.choice(hashes)
        ptrs = rng.choice([["x"], [], ["x", "x"], [""], [3], "x", {"a": 1}])
        ttl = rng.choice([10, 1, 0, -5])
        cid = db.one("INSERT INTO address_cache (address_hash, pointers, ttl) VALUES (%s, %s, %s) "
                     "RETURNING id", h, json.dumps(ptrs), ttl)
        py = cache_problems(CacheRow(h, ptrs, ttl, None))
        assert canon(problems(db, "addr_cache_problems", cid)) == canon(py)
        seen.update(r for r, _ in py)
        ep = rng.choice(ENDPOINTS_OK + ENDPOINTS_BAD + [None])
        proto = rng.choice(["tcp", "https", "ftp", None, "TCP"])
        gid = db.one("INSERT INTO gateway_mapping (address_hash, ip_endpoint, protocol) "
                     "VALUES (%s, %s, %s) RETURNING id", h, ep, proto)
        py = gateway_problems(GatewayRow(h, ep, proto), registered)
        assert canon(problems(db, "addr_gateway_problems", gid)) == canon(py), (ep, proto)
        seen.update(r for r, _ in py)
        nid = bytes(rng.randrange(256) for _ in range(rng.choice([32, 32, 1, 33, 0])))
        did = db.one("INSERT INTO dht_node (node_id) VALUES (%s) ON CONFLICT DO NOTHING "
                     "RETURNING id", B(nid))
        if did:
            assert canon(problems(db, "addr_dht_problems", did)) == canon(dht_problems(DhtRow(nid)))
            seen.update(r for r, _ in dht_problems(DhtRow(nid)))
        k = rng.choice([1, 2, 0, -1, None])
        res = rng.choice([[], [1], [1, 2, 3], {"a": 1}, None])
        lat = rng.choice([5, 0, -1, None])
        vid = db.one("INSERT INTO discovery_log (k, results, latency_ms) VALUES (%s, %s, %s) "
                     "RETURNING id", k, None if res is None else json.dumps(res), lat)
        py = discovery_problems(DiscoveryRow(k, res, lat))
        assert canon(problems(db, "addr_discovery_problems", vid)) == canon(py), (k, res, lat)
        seen.update(r for r, _ in py)
    assert {"cache_typing", "gateway_typing", "gateway_unregistered", "dht_typing",
            "discovery_typing"} <= set(seen)


@pytest.mark.parametrize("ep", ENDPOINTS_OK + ENDPOINTS_BAD)
def test_endpoint_rule_agrees(db, ep):
    assert db.one("SELECT addr_endpoint_ok(%s)", ep) is endpoint_ok(ep)


def test_writers_refuse_bad_rows(db):
    a = random_address(random.Random(10))
    register(db, a)
    h = a.address_hash()
    for sql, args, msg in [
        ("SELECT cache_address_resolution(%s, '[\"x\"]', 0, 's')", (h,), "ttl"),
        ("SELECT cache_address_resolution(%s, '[\"x\"]', 5, 's')", ("zz",), "not an address hash"),
        ("SELECT cache_address_resolution(%s, '[\"x\", \"x\"]', 5, 's')", (h,), "pointers"),
        ("SELECT register_gateway(%s, '10.0.0.1', 'tcp')", ("cd" * 32,), "not a registered"),
        ("SELECT register_gateway(%s, '10.1', 'tcp')", (h,), "not an IP endpoint"),
        ("SELECT register_gateway(%s, '10.0.0.1', 'ftp')", (h,), "unsupported protocol"),
        ("SELECT register_dht_node(%s)", (B(b"\x01"),), "32 bytes"),
        ("SELECT record_discovery(NULL, 0, '[]', 1)", (), "k must be positive"),
        ("SELECT record_discovery(NULL, 1, '[1, 2]', 1)", (), "at most k"),
        ("SELECT record_discovery(NULL, 1, '[]', -1)", (), "negative latency"),
    ]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, *args)
        db.q("ROLLBACK TO SAVEPOINT s")
    g = db.one("SELECT register_gateway(%s, '[::1]:443', 'https')", h)
    assert db.one("SELECT register_gateway(%s, '[::1]:443', 'https')", h) == g
    n = db.one("SELECT register_dht_node(%s, 'n0')", B(bytes(32)))
    assert db.one("SELECT register_dht_node(%s)", B(bytes(32))) == n
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="another endpoint"):
        db.q("SELECT register_dht_node(%s, 'n1')", B(bytes(32)))
    db.q("ROLLBACK TO SAVEPOINT s")
    assert db.one("SELECT record_discovery(NULL, 2, '[1]', 3)") is not None
    assert violations(db) == []


def test_resolution_agrees_with_python(db):
    """Random cache timelines: resolve_address and purge_expired_cache behave as
    ``AddressBook.resolve`` / ``purge`` at every probe time."""
    rng = random.Random(11)
    t0 = db.one("SELECT now()")
    for trial in range(15):
        db.q("DELETE FROM address_cache")
        db.q("DELETE FROM address_registry")
        book = AddressBook()
        hashes = ["%064x" % rng.getrandbits(256) for _ in range(2)]
        if rng.random() < 0.3:
            a = random_address(rng)
            register(db, a, ["reg"])
            book.register_address(a.address_hash(), a.encode(), pointers=["reg"])
            hashes.append(a.address_hash())
        times = rng.sample(range(0, 40), 6)
        for j, t in enumerate(times):
            h, ttl = rng.choice(hashes), rng.choice([1, 3, 10, 0, -2])
            ptrs = rng.choice([[f"p{j}"], [f"p{j}", f"q{j}"], [""]])
            at = t0 + timedelta(seconds=t)
            db.q("INSERT INTO address_cache (address_hash, pointers, ttl, cached_at) "
                 "VALUES (%s, %s, %s, %s)", h, json.dumps(ptrs), ttl, at)
            book.cache.append(CacheRow(h, ptrs, ttl, at))
        for probe in range(0, 50, 3):
            at = t0 + timedelta(seconds=probe)
            for h in hashes:
                assert db.one("SELECT resolve_address(%s, %s)", h, at) == book.resolve(h, at), \
                    (trial, probe, h)
        cut = t0 + timedelta(seconds=rng.randint(0, 50))
        assert db.one("SELECT purge_expired_cache(%s)", cut) == book.purge(cut)
        assert db.one("SELECT count(*) FROM address_cache") == len(book.cache)


def test_dht_routing_agrees_with_python(db):
    rng = random.Random(12)
    nodes = [bytes(rng.randrange(256) for _ in range(32)) for _ in range(40)]
    for n in nodes:
        db.q("SELECT register_dht_node(%s)", B(n))
    db.q("INSERT INTO dht_node (node_id) VALUES ('\\x0102')")       # ill-formed: never routed to
    for _ in range(20):
        key = bytes(rng.randrange(256) for _ in range(32))
        k = rng.randint(0, 45)
        rows = db.q("SELECT node_id, distance, bucket FROM dht_closest_nodes(%s, %s)", B(key), k)
        got = [bytes(r[0]) for r in rows]
        assert got == closest_nodes(key, nodes, k)
        for nid, dist, bucket in rows:
            assert bytes(dist) == xor_distance(bytes(nid), key)
            assert bucket == bucket_index(bytes(nid), key)
    a = random_address(rng)
    h = a.address_hash()
    assert bytes(db.one("SELECT address_dht_key(%s)", h)) == dht_key(h) == \
        hashlib.sha3_256(h.encode()).digest()
    rows = db.q("SELECT node_id FROM dht_closest_to_address(%s, 3)", h)
    assert [bytes(r[0]) for r in rows] == closest_nodes(dht_key(h), nodes, 3)
    assert db.one("SELECT addr_bucket(%s, %s)", B(bytes(32)), B(bytes(32))) is None
    assert db.one("SELECT addr_xor('\\x01', '\\x0102')") is None
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="32 bytes"):
        db.q("SELECT * FROM dht_closest_nodes('\\x01', 1)")
    db.q("ROLLBACK TO SAVEPOINT s")


# ---------------------------------------------------------------------------
# Batch checks
# ---------------------------------------------------------------------------
def test_batch_checks(db):
    a = random_address(random.Random(13))
    rid = register(db, a)
    assert db.one("SELECT check_addressing()") == 0
    db.q("INSERT INTO address_cache (address_hash, pointers, ttl) VALUES ('zz', '[]', 0)")
    db.q("DELETE FROM address_violation")
    assert db.one("SELECT check_addressing()") == 2
    db.q("SELECT run_all_batch_checks()")
    assert db.one("SELECT count(*) FROM address_violation WHERE subject_table = 'address_cache'") \
        == 4
    assert db.one("SELECT check_address(%s)", rid) is True
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="problem"):
        db.q("SELECT check_addressing()")
    db.q("ROLLBACK TO SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not found"):
        db.q("SELECT check_address(gen_random_uuid())")


# ---------------------------------------------------------------------------
# Upgrade path from the original table layout
# ---------------------------------------------------------------------------
def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE address_registry, dht_node, address_cache, gateway_mapping, discovery_log, "
         "address_violation CASCADE")
    db.q("DROP FUNCTION register_address(TEXT, BYTEA, BYTEA, JSONB, DOUBLE PRECISION, INT, TEXT)")
    orig = """
      CREATE TABLE address_registry (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        address_hash TEXT NOT NULL UNIQUE, address_cbor BYTEA NOT NULL, owner_pubkey BYTEA,
        pointers JSONB DEFAULT '[]'::jsonb, trust_score DOUBLE PRECISION DEFAULT 0.0,
        verification_depth INT DEFAULT 0, created_at TIMESTAMPTZ DEFAULT now(),
        metadata JSONB DEFAULT '{}'::jsonb);
      CREATE TABLE dht_node (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        node_id BYTEA NOT NULL UNIQUE, endpoint TEXT, capacity JSONB DEFAULT '{}'::jsonb,
        last_seen TIMESTAMPTZ DEFAULT now());
      CREATE TABLE address_cache (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        address_hash TEXT NOT NULL, pointers JSONB NOT NULL, ttl INT NOT NULL,
        cached_at TIMESTAMPTZ DEFAULT now(), source TEXT);
      CREATE TABLE gateway_mapping (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        address_hash TEXT NOT NULL, ip_endpoint TEXT, protocol TEXT,
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE discovery_log (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        query_vector vector(1536), k INT, results JSONB, latency_ms INT,
        created_at TIMESTAMPTZ DEFAULT now());
      CREATE FUNCTION register_address(p_address_hash TEXT, p_address_cbor BYTEA,
        p_owner BYTEA DEFAULT NULL, p_pointers JSONB DEFAULT '[]'::jsonb,
        p_trust DOUBLE PRECISION DEFAULT 0.0, p_depth INT DEFAULT 0) RETURNS UUID AS $$
        SELECT NULL::uuid $$ LANGUAGE sql;
    """
    db.q(orig)
    db.q("INSERT INTO address_registry (address_hash, address_cbor) VALUES ('h', '\\x00')")
    a = random_address(random.Random(14))
    db.q("INSERT INTO address_registry (address_hash, address_cbor, trust_score, "
         "verification_depth) VALUES (%s, %s, %s, %s)", a.address_hash(), B(a.encode()),
         a.trust_score, a.verification_depth)
    path = Path(__file__).resolve().parents[2] / "migrations" / "013_addressing_protocol.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    # the old rows are checked, not hidden; the new writer is the only one
    assert db.one("SELECT check_addressing()") == 2
    assert sorted(r for r, _ in violations(db)) == ["address_hash_format", "address_schema"]
    assert db.one("SELECT count(*) FROM pg_proc WHERE proname = 'register_address'") == 1
    b = random_address(random.Random(15))
    assert register(db, b) is not None
