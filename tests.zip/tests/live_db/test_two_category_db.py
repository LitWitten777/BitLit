"""Migration 009 (2-categories) on a real PostgreSQL.

Formal backing: ``Formal/TwoCategory.lean`` — identity preservation and
interchange are exactly functoriality of horizontal composition
(``exists_bifunctor_iff``); neither implies the other
(``interchange_not_implied``, ``identity_preservation_not_implied``); on the
2-cells of an identity 1-morphism the laws force vertical = horizontal and
commutativity (``eckmannHilton_two_cells``), used below as an oracle.
"""

from __future__ import annotations

import itertools
import random
import uuid
from collections import Counter

import psycopg2
import pytest

from qbx.categorical.two_category import (
    TwoCategory,
    base_category,
    codiscrete_two_category,
    one_cell_two_category,
)


def base(db, tc="T"):
    """A --f,g--> B --h--> C and k : B → A, with hf = h ∘ f, hg = h ∘ g and the unit composites."""
    db.category("Base")
    for o in "ABC":
        db.obj("Base", o)
    db.mor("f", "A", "B")
    db.mor("g", "A", "B")
    db.mor("h", "B", "C")
    db.mor("k", "B", "A")
    db.mor("hf", "A", "C")
    db.mor("hg", "A", "C")
    db.comp("h", "f", "hf")
    db.comp("h", "g", "hg")
    for x, m in (("A", "f"), ("A", "g"), ("B", "h"), ("A", "hf"), ("A", "hg")):
        db.comp(m, "id_" + x, m)
    for y, m in (("B", "f"), ("B", "g"), ("C", "h"), ("C", "hf"), ("C", "hg")):
        db.comp("id_" + y, m, m)
    db.two_category(tc, "Base")


# ---------------------------------------------------------------------------
# The original migration's bugs
# ---------------------------------------------------------------------------
def test_non_parallel_cell_is_logged(db):
    """Original bug: a 2-cell f ⇒ k with f : A → B, k : B → A was accepted."""
    base(db)
    db.cell("T", "bad", "f", "k")
    assert db.two_violations("T") == ["cell_typing"]
    assert db.two_reasons("T") == ["cell_typing"]


def test_non_parallel_cell_raises_in_strict_mode(db):
    base(db)
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error):
        db.cell("T", "bad", "f", "k")


def test_horizontal_writer_checks_composability(db):
    """Original bug: f ⇒ g and g ⇒ f (both A → B) 'composed horizontally' to f ⇒ f."""
    base(db)
    db.cell("T", "a", "f", "g")
    db.cell("T", "b", "g", "f")
    with pytest.raises(psycopg2.Error, match="do not compose"):
        db.hcomp("T", "b", "a")


def test_horizontal_result_is_the_composite(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.identity2("T", "h")
    r = db.hcomp("T", "id2(h)", "a", name="1h*a")
    src, tgt = db.q("SELECT source_morphism_id, target_morphism_id FROM two_morphism WHERE id = %s",
                    db.ids[r])[0]
    assert (src, tgt) == (db.ids["hf"], db.ids["hg"])
    assert db.two_reasons("T") == []


def test_horizontal_row_with_wrong_result_is_logged(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.identity2("T", "h")
    db.hrow("T", "id2(h)", "a", "a")         # the original typing: source(left) ⇒ target(right)
    assert db.two_violations("T") == ["horizontal_typing"]


def test_missing_composite_is_reported(db):
    base(db)
    db.mor("h2", "B", "C")
    db.cell("T", "a", "f", "g")
    db.cell("T", "b", "h", "h2")
    with pytest.raises(psycopg2.Error, match="not recorded"):
        db.hcomp("T", "b", "a")
    db.conn.rollback()
    base(db)
    db.mor("h2", "B", "C")
    db.cell("T", "a", "f", "g")
    db.cell("T", "b", "h", "h2")
    db.hrow("T", "b", "a", "a")
    (reason, details), = db.two_problems("T")
    assert reason == "horizontal_typing" and details["missing_composite"] is True


def test_vertical_writer_missing_cell_is_clear(db):
    """Original bug: a missing upper cell surfaced as a NOT NULL error."""
    base(db)
    db.cell("T", "a", "f", "g")
    db.ids["ghost"] = str(uuid.uuid4())
    with pytest.raises(psycopg2.Error, match="not found"):
        db.vcomp("T", "ghost", "a")


def test_cells_of_another_two_category(db):
    """Original bug: cells from another 2-category were composed."""
    base(db)
    db.two_category("U", "Base")
    db.cell("T", "a", "f", "g")
    db.cell("U", "b", "g", "f")
    with pytest.raises(psycopg2.Error, match="not in 2-category"):
        db.vcomp("T", "b", "a")
    db.conn.rollback()
    base(db)
    db.two_category("U", "Base")
    db.cell("T", "a", "f", "g")
    db.cell("U", "b", "g", "f")
    db.cell("T", "r", "f", "f")
    db.vrow("T", "b", "a", "r")
    assert db.two_violations("T") == ["vertical_typing"]


def test_composing_twice_returns_the_same_cell(db):
    """Original bug: a second compose of the same pair raised a unique violation."""
    base(db)
    db.cell("T", "a", "f", "g")
    db.cell("T", "b", "g", "f")
    r1 = db.vcomp("T", "b", "a", name="ba")
    r2 = db.vcomp("T", "b", "a")
    assert db.ids[r1] == db.ids[r2]
    with pytest.raises(psycopg2.Error, match="already recorded"):
        db.vcomp("T", "b", "a", result="a")


def test_unit_laws_and_identity_preservation_writers(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.identity2("T", "g")
    assert db.ids[db.vcomp("T", "id2(g)", "a")] == db.ids["a"]
    db.identity2("T", "id_B")
    assert db.ids[db.hcomp("T", "id2(id_B)", "a")] == db.ids["a"]
    db.identity2("T", "h")
    db.identity2("T", "f")
    r = db.hcomp("T", "id2(h)", "id2(f)")
    assert db.ids[r] == db.one("SELECT two_identity_of(%s, %s)", db.ids["T"], db.ids["hf"])
    assert db.two_reasons("T") == []


def test_unit_law_violations_logged(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.cell("T", "a2", "f", "g")
    db.identity2("T", "g")
    db.identity2("T", "id_B")
    db.vrow("T", "id2(g)", "a", "a2")
    db.hrow("T", "id2(id_B)", "a", "a2")
    assert db.two_violations("T") == ["horizontal_unit", "vertical_unit"]


def test_identity_preservation_violation(db):
    base(db)
    db.identity2("T", "h")
    db.identity2("T", "f")
    db.identity2("T", "hf")
    db.cell("T", "z", "hf", "hf")
    db.hrow("T", "id2(h)", "id2(f)", "z")
    assert db.two_violations("T") == ["identity_preservation"]


def test_identity_cell_typing(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.identity2("T", "f", cell="a")
    assert db.two_violations("T") == ["identity_typing"]


def test_vertical_associativity(db):
    base(db)
    db.cell("T", "a", "f", "g")
    db.cell("T", "b", "g", "f")
    db.cell("T", "c", "f", "g")
    db.vcomp("T", "b", "a", name="ba")
    db.vcomp("T", "c", "b", name="cb")
    db.vcomp("T", "cb", "a", name="(cb)a")
    db.vcomp("T", "c", "ba", name="c(ba)")
    assert db.two_reasons("T") == ["vertical_associativity"]
    (_, d), = db.two_problems("T")
    assert d == {"c": "c", "b": "b", "a": "a", "left_assoc": "(cb)a", "right_assoc": "c(ba)"}


def test_interchange_detected_and_check_interchange_law(db):
    """Original bug: check_interchange_law was an empty loop."""
    base(db)
    db.cell("T", "a1", "f", "g")
    db.cell("T", "a2", "g", "f")
    db.identity2("T", "h")
    a = db.vcomp("T", "a2", "a1", name="a2a1")
    b = db.vcomp("T", "id2(h)", "id2(h)")
    x = db.hcomp("T", b, a, name="x")
    p = db.hcomp("T", "id2(h)", "a2", name="p")
    q = db.hcomp("T", "id2(h)", "a1", name="q")
    db.vcomp("T", p, q, name="y")
    assert db.two_reasons("T") == ["interchange"]
    assert db.one("SELECT check_interchange_law(%s)", db.ids["T"]) is False
    assert db.two_violations("T") == ["interchange"]
    # repair: identify y with x
    db.q("UPDATE two_morphism_vertical_comp SET result_id = %s WHERE result_id = %s",
         db.ids["x"], db.ids["y"])
    assert db.two_reasons("T") == []


def test_batch_check_strict_and_permissive(db):
    base(db)
    db.cell("T", "bad", "f", "k")
    db.clear_two_violations()
    assert db.check_two("T") is False
    assert db.two_violations("T") == ["cell_typing"]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="violates its laws"):
        db.check_two("T")


def test_run_all_batch_checks_and_summary_view(db):
    base(db)
    db.cell("T", "bad", "f", "k")
    db.clear_two_violations()
    db.q("SELECT run_all_batch_checks()")
    assert db.two_violations("T") == ["cell_typing"]
    rows = db.q("SELECT violation_type FROM v_all_violations WHERE module = 'two_category' "
                "AND subject = %s", db.ids["T"])
    assert rows == [("cell_typing",)]


# ---------------------------------------------------------------------------
# Whole models, and agreement with the Python reference
# ---------------------------------------------------------------------------
OBJECTS = "ABC"
MORPHISMS = {"f": ("A", "B"), "g": ("A", "B"), "h": ("B", "C"), "kk": ("B", "B"),
             "hf": ("A", "C"), "hg": ("A", "C")}
COMPOSITIONS = {("h", "f"): "hf", ("h", "g"): "hg", ("kk", "f"): "f", ("kk", "g"): "g",
                ("kk", "kk"): "kk", ("h", "kk"): "h"}


def test_codiscrete_two_category_passes(db):
    model = codiscrete_two_category(OBJECTS, MORPHISMS, COMPOSITIONS)
    db.load_two_category(model)
    assert db.two_reasons("T") == []
    assert db.check_two("T") is True
    assert db.two_violations("T") == []


def perms3():
    return ["".join(p) for p in itertools.permutations("012")]


def pmul(a, b):
    return "".join(a[int(b[i])] for i in range(3))


def test_eckmann_hilton_oracle_on_s3(db):
    """S₃ on the identity 1-morphism: only interchange fails, exactly as in Python."""
    model = one_cell_two_category(perms3(), "012", pmul, pmul)
    db.load_two_category(model)
    got = Counter(r for r, _ in db.two_problems("T"))
    assert got == Counter(r for r, _ in model.problems()) == Counter({"interchange": 648})


def canon(problems):
    return sorted((r, tuple(sorted(d.items()))) for r, d in problems)


def random_model(rng: random.Random) -> TwoCategory:
    """A random 2-category-like recording over the fixed base, with some bad rows."""
    tc = base_category(OBJECTS, MORPHISMS, COMPOSITIONS)
    mors = list(tc.morphisms)
    parallel = [(f, g) for f in mors for g in mors if tc.morphisms[f] == tc.morphisms[g]]
    cells = []
    for i in range(rng.randint(3, 9)):
        f, g = rng.choice(parallel)
        if rng.random() < 0.08:
            g = rng.choice(mors)                    # possibly non-parallel
        cells.append(tc.add_cell(f"c{i}", f, g))
    for f in rng.sample(mors, rng.randint(0, len(mors))):
        cid = tc.identity_cell(f)
        cells.append(cid)
    for _ in range(rng.randint(0, 25)):
        u, l = rng.choice(cells), rng.choice(cells)
        if (u, l) in tc.vertical:
            continue
        cand = [c for c in cells if tc.cells[c] == (tc.cells[l][0], tc.cells[u][1])]
        if tc.cells[l][1] != tc.cells[u][0] and rng.random() < 0.85:
            continue
        tc.vertical[(u, l)] = rng.choice(cand or cells)
    for _ in range(rng.randint(0, 25)):
        b, a = rng.choice(cells), rng.choice(cells)
        if (b, a) in tc.horizontal:
            continue
        src = tc.compositions.get((tc.cells[b][0], tc.cells[a][0]))
        tgt = tc.compositions.get((tc.cells[b][1], tc.cells[a][1]))
        if (src is None or tgt is None) and rng.random() < 0.85:
            continue
        cand = [c for c in cells if tc.cells[c] == (src, tgt)]
        tc.horizontal[(b, a)] = rng.choice(cand or cells)
    return tc


def random_one_cell_model(rng: random.Random) -> TwoCategory:
    """Random unital operations on {e, x, y} recorded on the identity 1-morphism,
    with a few composites dropped."""
    elems = ["e", "x", "y"]

    def random_op():
        table = {(a, b): rng.choice(elems) for a in "xy" for b in "xy"}
        return lambda a, b: b if a == "e" else a if b == "e" else table[(a, b)]

    tc = one_cell_two_category(elems, "e", random_op(), random_op())
    for comp in (tc.vertical, tc.horizontal):
        for key in rng.sample(sorted(comp), rng.randint(0, 3)):
            del comp[key]
    return tc


def test_database_agrees_with_python_reference(db):
    rng = random.Random(9009)
    total = Counter()
    for i in range(60):
        model = random_model(rng) if i % 3 else random_one_cell_model(rng)
        db.conn.rollback()
        db.ids.clear()
        db.cat_of.clear()
        db.morphisms.clear()
        db.composites.clear()
        db.load_two_category(model)
        py = canon(model.problems())
        sql = canon(db.two_problems("T"))
        assert sql == py, i
        total.update(r for r, _ in py)
    # the random models exercise most of the reasons
    assert {"cell_typing", "vertical_typing", "horizontal_typing",
            "vertical_associativity", "horizontal_associativity", "interchange",
            "vertical_unit", "horizontal_unit"} <= set(total)
