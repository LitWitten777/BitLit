"""Migration 008 (enriched categories) on a real PostgreSQL.

Formal backing: ``Formal/Enriched.lean`` — hom-values in an ordered commutative
monoid form an enriched category iff the unit and composition laws hold
(``exists_enriched_iff``); for Lawvere's [0, ∞] these are d(x, x) = 0 and the
triangle inequality (``lawvere_enriched_iff``), with only finite legs needing
a check (``triangle_iff_finite``); neither law suffices alone
(``unit_law_not_sufficient``, ``composition_law_not_sufficient``).
"""

from __future__ import annotations

import random
from fractions import Fraction

import psycopg2
import pytest

from qbx.categorical.enriched import EnrichedCategory


def metric_space(db, name="M", dists=None, objs="XYZ"):
    """A category with objects ``objs`` and a metric enrichment ``name``."""
    db.category("C")
    for o in objs:
        db.obj("C", o)
    db.enriched(name, "C", "metric")
    for (x, y), d in (dists or {}).items():
        db.hom(name, x, y, {"distance": d})


GOOD_METRIC = {
    ("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
    ("X", "Y"): 1, ("Y", "Z"): 1, ("X", "Z"): 2,
    ("Y", "X"): 3, ("Z", "Y"): 1, ("Z", "X"): 3,
}


# ---------------------------------------------------------------------------
# Metric (Lawvere) enrichment
# ---------------------------------------------------------------------------
def test_lawvere_metric_space_passes(db):
    metric_space(db, dists=GOOD_METRIC)
    assert db.enriched_reasons("M") == []
    assert db.check_enriched("M") is True
    assert db.enriched_violations("M") == []
    assert db.q("SELECT * FROM check_metric_triangle_inequality(%s)", db.ids["M"]) == []


def test_infinite_distances_allowed_when_consistent(db):
    # X, Y in one component, Z unreachable: d = ∞ between components
    dists = {("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0, ("X", "Y"): 1, ("Y", "X"): 1,
             ("X", "Z"): "Infinity"}
    metric_space(db, dists=dists)
    assert db.enriched_reasons("M") == []


def test_triangle_violation_reports_direct_distance(db):
    """Original bug: lhs was d(X, Y) = 1 instead of d(X, Z) = 5."""
    metric_space(db, dists={**GOOD_METRIC, ("X", "Z"): 5})
    assert db.enriched_reasons("M") == ["composition_law"]
    (reason, details), = db.enriched_problems("M")
    assert details["direct"] == 5 and details["through"] == 2
    assert details["source"] == db.ids["X"] and details["target"] == db.ids["Z"]
    rows = db.q("SELECT violating_src, violating_tgt, lhs, rhs "
                "FROM check_metric_triangle_inequality(%s)", db.ids["M"])
    assert rows == [(db.ids["X"], db.ids["Z"], 5.0, 2.0)]


def test_missing_direct_distance_is_infinite(db):
    """Original bug: a missing d(X, Z) was silently accepted."""
    dists = dict(GOOD_METRIC)
    del dists[("X", "Z")]
    metric_space(db, dists=dists)
    problems = db.enriched_problems("M")
    assert [p[0] for p in problems] == ["composition_law"]
    assert problems[0][1]["missing"] is True and problems[0][1]["direct"] == "Infinity"
    rows = db.q("SELECT lhs, rhs FROM check_metric_triangle_inequality(%s)", db.ids["M"])
    assert rows == [(float("inf"), 2.0)]


def test_unit_law(db):
    """Original bug: d(X, X) was never checked."""
    dists = {**GOOD_METRIC, ("X", "X"): 7}
    del dists[("Z", "Z")]
    metric_space(db, dists=dists)
    problems = db.enriched_problems("M")
    units = {(d["object"], d["missing"]) for r, d in problems if r == "unit_law"}
    assert units == {(db.ids["X"], False), (db.ids["Z"], True)}
    # d(X, X) = 7 also breaks the triangles X → Y → X (4) and X → Z → X (5), and the
    # missing d(Z, Z) = ∞ breaks Z → X → Z and Z → Y → Z
    loops = sorted((d["source"], d["middle"]) for r, d in problems if r == "composition_law")
    assert loops == sorted([(db.ids["X"], db.ids["Y"]), (db.ids["X"], db.ids["Z"]),
                            (db.ids["Z"], db.ids["X"]), (db.ids["Z"], db.ids["Y"])])


def test_unit_law_alone_is_not_enough(db):
    """composition_law_not_sufficient: d(x, x) = 0 everywhere, triangle fails."""
    metric_space(db, dists={("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
                            ("X", "Y"): 1, ("Y", "Z"): 1, ("X", "Z"): 3})
    assert db.enriched_reasons("M") == ["composition_law"]


def test_composition_law_alone_is_not_enough(db):
    """unit_law_not_sufficient: the constant distance 1."""
    metric_space(db, dists={(x, y): 1 for x in "XYZ" for y in "XYZ"})
    assert db.enriched_reasons("M") == ["unit_law"] * 3


def test_exact_decimal_arithmetic(db):
    """0.1 + 0.7 = 0.8 exactly (in binary floating point it is 0.7999999999999999)."""
    metric_space(db, dists={("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0,
                            ("X", "Y"): 0.1, ("Y", "Z"): 0.7, ("X", "Z"): 0.8})
    assert db.enriched_reasons("M") == []


def test_tolerance(db):
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.enriched("T", "C", "metric", tolerance=0.001)
    db.enriched("E", "C", "quantale", quantale="lawvere")
    for ec in ("T", "E"):
        for (x, y), d in {**GOOD_METRIC, ("X", "Z"): 2.0005}.items():
            db.hom(ec, x, y, {"distance": d})
    assert db.enriched_reasons("T") == []
    assert db.enriched_reasons("E") == ["composition_law"]


def test_bad_values_logged_at_write_time(db):
    """Original bug: negative, NaN and non-numeric distances were accepted."""
    metric_space(db, dists=GOOD_METRIC)
    db.hom("M", "Z", "Y", {"distance": -3})
    db.q("SELECT update_enriched_hom_metric(%s, %s, %s, 'NaN')",
         db.ids["M"], db.ids["Y"], db.ids["X"])
    db.hom("M", "Z", "X", {"foo": 1})
    assert db.enriched_violations("M") == ["malformed_value", "malformed_value", "out_of_range"]
    # malformed homs are reported, and left out of the laws (as missing)
    reasons = db.enriched_reasons("M")
    assert reasons.count("malformed_value") == 2 and reasons.count("out_of_range") == 1


def test_infinity_via_metric_writer(db):
    metric_space(db, dists={("X", "X"): 0, ("Y", "Y"): 0, ("Z", "Z"): 0})
    db.q("SELECT update_enriched_hom_metric(%s, %s, %s, 'Infinity')",
         db.ids["M"], db.ids["X"], db.ids["Y"])
    assert db.one("SELECT value FROM enriched_hom WHERE source_object_id = %s "
                  "AND target_object_id = %s", db.ids["X"], db.ids["Y"]) == {"distance": "Infinity"}
    assert db.enriched_reasons("M") == []


def test_strict_mode_rejects_bad_hom(db):
    metric_space(db, dists=GOOD_METRIC)
    db.set_mode("strict")
    with pytest.raises(psycopg2.errors.RaiseException):
        db.hom("M", "X", "Y", {"distance": -1})


def test_strict_mode_batch_check_raises(db):
    metric_space(db, dists={**GOOD_METRIC, ("X", "Z"): 5})
    db.set_mode("strict")
    with pytest.raises(psycopg2.errors.RaiseException):
        db.check_enriched("M")


def test_foreign_object(db):
    """Original bug: a hom could leave the base category."""
    metric_space(db, dists=GOOD_METRIC)
    db.category("D")
    db.obj("D", "W")
    db.hom("M", "X", "W", {"distance": 1})
    assert db.enriched_violations("M") == ["foreign_object"]
    assert db.enriched_reasons("M") == ["foreign_object"]


def test_metric_check_requires_metric_kind(db):
    """Original bug: the metric check ran on any enriched category."""
    db.category("C")
    db.obj("C", "X")
    db.enriched("O", "C", "ordered")
    with pytest.raises(psycopg2.errors.RaiseException):
        db.q("SELECT * FROM check_metric_triangle_inequality(%s)", db.ids["O"])


def test_space_constraints(db):
    with pytest.raises(psycopg2.errors.CheckViolation):
        db.q("SAVEPOINT s")
        db.q("INSERT INTO enrichment_space (name, kind, metadata) "
             "VALUES ('bad', 'quantale', '{\"quantale\": \"tropical\"}')")
    db.q("ROLLBACK TO SAVEPOINT s")
    with pytest.raises(psycopg2.errors.CheckViolation):
        db.q("INSERT INTO enrichment_space (name, kind, metadata) "
             "VALUES ('bad2', 'metric', '{\"tolerance\": \"0.1\"}')")


# ---------------------------------------------------------------------------
# Enriched compositions
# ---------------------------------------------------------------------------
def test_composition_rows(db):
    """Original bug: any row was accepted, and the writer could set verified."""
    metric_space(db, dists=GOOD_METRIC)
    # d(Y, Z) ∘ d(X, Y): composed value 1 + 1 = 2 ≤ d(X, Z) = 2
    _, ok = db.enriched_composite("M", ("Y", "Z"), ("X", "Y"), {"distance": 2})
    assert ok is True
    # X → Y twice does not compose
    _, ok = db.enriched_composite("M", ("X", "Y"), ("X", "Y"), {"distance": 2})
    assert ok is False
    # wrong composed value
    _, ok = db.enriched_composite("M", ("Y", "Z"), ("X", "Y"), {"distance": 1})
    assert ok is False
    assert db.enriched_violations("M") == ["composition_typing", "composition_value"]


def test_composition_row_checks_direct_hom(db):
    metric_space(db, dists={**GOOD_METRIC, ("X", "Z"): 5})
    db.clear_enriched_violations()
    _, ok = db.enriched_composite("M", ("Y", "Z"), ("X", "Y"), {"distance": 2})
    assert ok is False
    assert db.enriched_violations("M") == ["composition_law"]


def test_composition_row_from_other_category(db):
    metric_space(db, dists=GOOD_METRIC)
    db.enriched("N", "C", "quantale", quantale="lawvere")
    for (x, y), d in GOOD_METRIC.items():
        db.hom("N", x, y, {"distance": d})
    _, ok = db.q(
        "INSERT INTO enriched_composition (enriched_category_id, left_hom_id, right_hom_id, "
        "composed_value) VALUES (%s, %s, %s, '{\"distance\": 2}') RETURNING id, verified",
        db.ids["M"], db.ids["N:Y->Z"], db.ids["M:X->Y"])[0]
    assert ok is False
    assert db.enriched_violations("M") == ["composition_typing"]


# ---------------------------------------------------------------------------
# Other quantales
# ---------------------------------------------------------------------------
def quantale_category(db, kind, quantale=None):
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.enriched("Q", "C", kind, quantale=quantale)


def test_ordered_is_a_preorder(db):
    quantale_category(db, "ordered")
    for x in "XYZ":
        db.hom("Q", x, x, {"holds": True})
    db.hom("Q", "X", "Y", {"holds": True})
    db.hom("Q", "Y", "Z", {"holds": True})
    db.hom("Q", "Z", "X", {"holds": False})
    assert db.enriched_reasons("Q") == ["composition_law"]     # X ≤ Z missing
    db.hom("Q", "X", "Z", {"holds": 1})
    assert db.enriched_reasons("Q") == []
    db.hom("Q", "Y", "Y", {"holds": False})
    assert db.enriched_reasons("Q") == ["unit_law"]
    db.hom("Q", "Y", "Y", {"holds": 2})
    assert "out_of_range" in db.enriched_reasons("Q")


def test_ultrametric(db):
    quantale_category(db, "quantale", "ultrametric")
    for x in "XYZ":
        db.hom("Q", x, x, {"distance": 0})
    db.hom("Q", "X", "Y", {"distance": 1})
    db.hom("Q", "Y", "Z", {"distance": 2})
    db.hom("Q", "X", "Z", {"distance": 2})        # max(1, 2) = 2: fine
    assert db.enriched_reasons("Q") == []
    db.hom("Q", "X", "Z", {"distance": 2.5})      # a Lawvere metric, not an ultrametric
    assert db.enriched_reasons("Q") == ["composition_law"]


def test_goedel_and_product(db):
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.enriched("G", "C", "quantale", quantale="goedel")
    db.enriched("P", "C", "quantale", quantale="product")
    for ec in ("G", "P"):
        for x in "XYZ":
            db.hom(ec, x, x, {"value": 1})
        db.hom(ec, "X", "Y", {"value": 0.5})
        db.hom(ec, "Y", "Z", {"value": 0.5})
        db.hom(ec, "X", "Z", {"value": 0.3})
    # min(0.5, 0.5) = 0.5 > 0.3, but 0.5 × 0.5 = 0.25 ≤ 0.3
    assert db.enriched_reasons("G") == ["composition_law"]
    assert db.enriched_reasons("P") == []
    db.hom("P", "X", "Z", {"value": 1.5})
    assert "out_of_range" in db.enriched_reasons("P")


# ---------------------------------------------------------------------------
# Probabilistic enrichment (Markov kernels)
# ---------------------------------------------------------------------------
P01 = {"a": {"a": 0.5, "b": 0.5}, "b": {"b": 1}}
P12 = {"a": {"a": 0.9, "b": 0.1}, "b": {"a": 0.2, "b": 0.8}}
P02 = {"a": {"a": 0.55, "b": 0.45}, "b": {"a": 0.2, "b": 0.8}}   # = P01 ; P12
ID = {"a": {"a": 1}, "b": {"b": 1}}


def markov_chain(db):
    db.category("C")
    for o in ["T0", "T1", "T2"]:
        db.obj("C", o)
    db.enriched("K", "C", "probabilistic")
    db.hom("K", "T0", "T0", {"kernel": ID})
    db.hom("K", "T0", "T1", {"kernel": P01})
    db.hom("K", "T1", "T2", {"kernel": P12})
    db.hom("K", "T0", "T2", {"kernel": P02})


def test_markov_chain_passes(db):
    markov_chain(db)
    assert db.enriched_reasons("K") == []
    _, ok = db.enriched_composite("K", ("T1", "T2"), ("T0", "T1"), {"kernel": P02})
    assert ok is True


def test_chapman_kolmogorov(db):
    markov_chain(db)
    db.hom("K", "T0", "T2", {"kernel": {"a": {"a": 0.5, "b": 0.5}, "b": {"a": 0.2, "b": 0.8}}})
    assert db.enriched_reasons("K") == ["chapman_kolmogorov"]
    _, ok = db.enriched_composite("K", ("T1", "T2"), ("T0", "T1"), {"kernel": P02})
    assert ok is False      # the composite is right, but disagrees with the recorded h(T0, T2)
    _, ok = db.enriched_composite("K", ("T1", "T2"), ("T0", "T1"), {"kernel": P01})
    assert ok is False


def test_kernel_well_formedness(db):
    markov_chain(db)
    db.clear_enriched_violations()
    db.hom("K", "T1", "T1", {"kernel": {"a": {"a": 0.9}, "b": {"b": 1}}})
    db.hom("K", "T2", "T2", {"kernel": {"a": {"a": -1, "b": 2}}})
    db.hom("K", "T2", "T0", {"kernel": {"a": "x"}})
    assert db.enriched_violations("K") == ["malformed_value", "not_stochastic", "not_stochastic"]


def test_identity_state_space_and_support(db):
    markov_chain(db)
    db.hom("K", "T0", "T0", {"kernel": {"a": {"b": 1}, "b": {"a": 1}}})
    # the swap is not the identity, and breaks Chapman–Kolmogorov through T0
    assert db.enriched_reasons("K") == ["chapman_kolmogorov"] * 3 + ["identity_kernel"]
    db.hom("K", "T0", "T0", {"kernel": ID})
    db.hom("K", "T1", "T2", {"kernel": {"a": {"a": 1}}})          # T1 lost state b
    reasons = db.enriched_reasons("K")
    assert "kernel_support" in reasons                             # P01 charges T1's b
    db.hom("K", "T1", "T2", {"kernel": P12})
    db.hom("K", "T0", "T1", {"kernel": {"a": {"a": 1}, "b": {"b": 1}, "c": {"a": 1}}})
    assert "state_space" in db.enriched_reasons("K")               # rows abc vs ab out of T0


# ---------------------------------------------------------------------------
# Batch layer (017)
# ---------------------------------------------------------------------------
def test_run_all_batch_checks_includes_enriched(db):
    metric_space(db, dists={**GOOD_METRIC, ("X", "Z"): 5})
    db.clear_enriched_violations()
    db.q("SELECT run_all_batch_checks()")
    assert db.enriched_violations("M") == ["composition_law"]
    assert db.one("SELECT count(*) FROM v_all_violations WHERE module = 'enriched'") == 1


# ---------------------------------------------------------------------------
# Database and in-memory engine agree
# ---------------------------------------------------------------------------
VALUE_POOLS = {
    ("metric", None): [0, 0, 1, 2, 3, 0.5, "Infinity"],
    ("quantale", "ultrametric"): [0, 0, 1, 2, 3],
    ("ordered", None): [True, True, False],
    ("quantale", "goedel"): [1, 1, 0.5, 0.2, 0],
    ("quantale", "product"): [1, 1, 0.5, 0.25, 0.2, 0],
    # occasional malformed / out-of-range values
    ("quantale", "lawvere"): [0, 0, 1, 2, -1, "x"],
}

SWAP = {"a": {"b": 1}, "b": {"a": 1}}
KERNEL_POOL = [ID, ID, P01, P12, P02, SWAP, {"a": {"a": 0.5}, "b": {"b": 1}},
               {"a": {"a": 1}}, {"a": {"c": 1}, "b": {"a": 1}}, {"a": {"a": "p"}}]


def key_for(kind, quantale):
    if kind == "ordered":
        return "holds"
    if kind == "metric" or quantale == "ultrametric":
        return "distance"
    return "value"


def test_database_agrees_with_engine(db):
    rng = random.Random(8)
    objs = ["O0", "O1", "O2", "O3"]
    db.category("C")
    for o in objs:
        db.obj("C", o)
    n = 0
    for (kind, quantale), pool in VALUE_POOLS.items():
        for trial in range(12):
            name = f"E{n}"
            n += 1
            db.enriched(name, "C", kind, quantale=quantale)
            homs = {}
            for x in objs:
                for y in objs:
                    if rng.random() < 0.7:
                        v = {key_for(kind, quantale): rng.choice(pool)}
                        homs[(x, y)] = v
                        db.hom(name, x, y, v)
            check_agreement(db, name, objs, EnrichedCategory(objs, kind, homs, quantale=quantale),
                            (kind, quantale, homs))


def check_agreement(db, name, objs, engine, info):
    """The database reports the same problems as the in-memory engine."""
    want = sorted(
        (r, d.get("source"), d.get("middle"), d.get("target"), d.get("object"))
        for r, d in engine.problems())
    names = {db.ids[o]: o for o in objs}
    got = sorted(
        (r, names.get(d.get("source")), names.get(d.get("middle")),
         names.get(d.get("target")), names.get(d.get("object")))
        for r, d in db.enriched_problems(name))
    assert got == want, info


def test_database_agrees_with_engine_on_kernels(db):
    rng = random.Random(80)
    objs = ["O0", "O1", "O2"]
    db.category("C")
    for o in objs:
        db.obj("C", o)
    for n in range(40):
        name = f"K{n}"
        db.enriched(name, "C", "probabilistic")
        homs = {}
        for x in objs:
            for y in objs:
                if rng.random() < 0.6:
                    v = {"kernel": rng.choice(KERNEL_POOL)}
                    homs[(x, y)] = v
                    db.hom(name, x, y, v)
        check_agreement(db, name, objs, EnrichedCategory(objs, "probabilistic", homs), homs)


def test_kernel_composition_agrees_with_engine(db):
    from qbx.categorical.enriched import compose_kernels, parse_kernel
    import json
    f = {"kernel": {"a": {"a": 0.5, "b": 0.5}, "b": {"c": 1}}}
    g = {"kernel": {"a": {"a": 0.1, "b": 0.9}, "b": {"a": 0.3, "c": 0.7}, "c": {"c": 1}}}
    got = db.one("SELECT enriched_compose_kernels(%s::jsonb, %s::jsonb)",
                 json.dumps(f["kernel"]), json.dumps(g["kernel"]))
    want = compose_kernels(parse_kernel(f), parse_kernel(g))
    assert {s: {t: Fraction(str(p)) for t, p in row.items()} for s, row in got.items()} == want
