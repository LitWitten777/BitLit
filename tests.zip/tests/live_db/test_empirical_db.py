"""Migration 016 (empirical grounding: uncertainty types, measurement
contracts, bundles and validations, dynamical models, simulation runs, agent
models, mechanisms) on a real PostgreSQL.

The reference is ``qbx.empirical``: on random inputs the database reports
exactly the problems the Python code reports, with the same details, in the
same order.

Formal backing: ``Formal/Empirical.lean`` — ``rangeOk_iff`` (the range check is
"every allowed value is within the bounds"), ``report_eq_nil_iff`` /
``mem_report_iff`` (the report lists exactly the failing pairs),
``icFailures_eq_nil_iff`` / ``irFailures_eq_nil_iff`` (the failure lists are
IC / IR); they are used as oracles in ``tests/test_empirical.py``.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest
from psycopg2.extras import Json

from qbx.empirical.measurement import (
    bundle_problems,
    bundle_validated_problems,
    contract_problems,
    uncertainty_problems,
    validate,
    validation_problems,
)
from qbx.empirical.mechanism import mechanism_problems
from qbx.empirical.models import MODEL_TYPES, agent_problems, dynamical_model_problems, simulation_problems
from tests.empirical_examples import (
    good_bundle,
    good_contract,
    good_descriptor,
    random_bundle,
    random_constraints,
    random_contract,
    random_descriptor,
    random_names_json,
    random_object,
    random_safety,
    random_solver_config,
    random_spec,
    random_tolerance,
    random_window,
)
from tests.governance_examples import random_text

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "016_empirical_grounding.sql"


def J(x):
    """A JSON parameter; Python ``None`` is SQL NULL."""
    return None if x is None else Json(x)


def rows(db, sql, *args):
    return [tuple(r) for r in db.q(sql, *args)]


def problems_of(db, table, rid, batch=True):
    return rows(db, "SELECT reason, details FROM empirical_problems_of(%s, %s, %s)",
                table, rid, batch)


def canon(x):
    """JSON text with integral floats written as integers (1.0 and 1 are the
    same JSON number)."""
    def norm(v):
        if isinstance(v, float) and v.is_integer():
            return int(v)
        if isinstance(v, dict):
            return {k: norm(w) for k, w in v.items()}
        if isinstance(v, list):
            return [norm(w) for w in v]
        return v
    return json.dumps(norm(x), sort_keys=True)


def logged(db, rid):
    return Counter((r, canon(d)) for r, d in
                   rows(db, "SELECT reason, details FROM empirical_violation WHERE subject_id = %s",
                        rid))


def as_counter(problems):
    return Counter((r, canon(d)) for r, d in problems)


def savepoint_raises(db, match, sql, *args):
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match=match):
        db.q(sql, *args)
    db.q("ROLLBACK TO SAVEPOINT s")


def name_or_blank(x):
    return "" if x is None else x


def insert_uncertainty(db, name, descriptor):
    return db.one("INSERT INTO uncertainty_type (name, descriptor) VALUES (%s, %s) RETURNING id",
                  name, Json(descriptor))


def insert_contract(db, c, uncertainty_id=None):
    return db.one(
        "INSERT INTO measurement_contract (name, observable_id, version, body, expected_precision, "
        "validation_tests, uncertainty_type_id) VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id",
        name_or_blank(c["name"]), name_or_blank(c["observable_id"]), c["version"] or "",
        Json(c["body"]), J(c["expected_precision"]), J(c["validation_tests"]), uncertainty_id)


def insert_bundle(db, b, validated=False, report=None):
    return db.one(
        "INSERT INTO measurement_bundle (observations, context, provenance, validated, "
        "validation_report) VALUES (%s, %s, %s, %s, %s) RETURNING id",
        Json(b["observations"]), J(b["context"]), J(b["provenance"]), validated, J(report))


def nn(x, alt=3):
    """Columns that are NOT NULL get a (bad) non-null value instead of None."""
    return alt if x is None else x


# ---------------------------------------------------------------------------
# The bugs of the original migration
# ---------------------------------------------------------------------------
def test_original_bugs_are_refused_or_reported(db):
    cid = db.one("SELECT register_measurement_contract('c1', 'T', '[\"range_check\"]', "
                 "'{\"min\": 0, \"max\": 10}')")
    savepoint_raises(db, "not found", "SELECT validate_measurement_bundle(gen_random_uuid(), %s)", cid)
    savepoint_raises(db, "observation", "SELECT record_measurement_bundle('[{\"v\": 99}]')")
    b1 = db.one("INSERT INTO measurement_bundle (observations) VALUES ('[{\"v\": 99}]') RETURNING id")
    savepoint_raises(db, "validation_input", "SELECT validate_measurement_bundle(%s, %s)", b1, cid)
    db.q("INSERT INTO measurement_bundle (observations) VALUES ('{\"value\": 99}')")
    savepoint_raises(db, "bounds", "SELECT register_measurement_contract('c2', 'T', "
                     "'[\"rnage_check\"]', '{\"min\": 10, \"max\": 0}')")
    db.q("INSERT INTO measurement_contract (name, observable_id, validation_tests, body) "
         "VALUES ('c2', 'T', '[\"rnage_check\"]', '{\"min\": 10, \"max\": 0}')")
    b2 = db.one("INSERT INTO measurement_bundle (observations, validated) "
                "VALUES ('[{\"value\": 1e9}]', true) RETURNING id")
    db.q("INSERT INTO measurement_contract (name, observable_id, expected_precision) "
         "VALUES ('  ', '', '{\"absolute\": -1}')")
    savepoint_raises(db, "model_typing", "SELECT register_dynamical_model('', 'ODE', '', '[1]')")
    mid = db.one("INSERT INTO dynamical_model (name, model_type, model_spec, solver_config) "
                 "VALUES ('', 'ODE', '', '[1]') RETURNING id")
    db.q("INSERT INTO simulation_run (model_id, initial_conditions, tolerance, started_at, "
         "finished_at) VALUES (%s, '7', -1, now(), now() - interval '1 day')", mid)
    savepoint_raises(db, "mechanism_typing", "SELECT register_mechanism('', '\"x\"', '[]')")
    db.q("INSERT INTO uncertainty_type (name, descriptor) "
         "VALUES ('g', '{\"kind\": \"gaussian\", \"sigma\": -2}')")
    db.q("INSERT INTO agent_model (name, sensors) VALUES ('', '5')")
    reasons = Counter(r for r, _ in rows(db, "SELECT reason, details FROM empirical_violation"))
    assert reasons["bundle_typing"] == 2            # no value; observations an object
    assert reasons["contract_typing"] == 5          # bounds, test; name, observable, precision
    assert reasons["model_typing"] == 3 and reasons["simulation_typing"] == 3
    assert reasons["uncertainty_typing"] == 1 and reasons["agent_typing"] == 2
    db.q("DELETE FROM empirical_violation")
    db.q("SELECT check_empirical()")
    assert problems_of(db, "measurement_bundle", b2) == [("bundle_validated", {"field": "validated"})]
    assert ("empirical",) in rows(db, "SELECT module FROM violation_summary()")


# ---------------------------------------------------------------------------
# Random rows: the database reports what the reference reports
# ---------------------------------------------------------------------------
def test_uncertainty_types_match_reference(db):
    rng = random.Random(16)
    for n in range(150):
        db.q("SAVEPOINT r")
        name, d = name_or_blank(random_text(rng)), nn(random_descriptor(rng))
        uid = insert_uncertainty(db, name, d)
        expected = uncertainty_problems(name, d)
        assert problems_of(db, "uncertainty_type", uid) == expected
        assert logged(db, uid) == as_counter(expected)
        db.q("ROLLBACK TO SAVEPOINT r")


def test_contracts_match_reference(db):
    rng = random.Random(116)
    for n in range(300):
        db.q("SAVEPOINT r")
        c = random_contract(rng)
        c["name"], c["observable_id"] = name_or_blank(c["name"]), name_or_blank(c["observable_id"])
        c["body"] = nn(c["body"])
        cid = insert_contract(db, c)
        expected = contract_problems(c["name"], c["observable_id"], c["version"], c["body"],
                                     c["expected_precision"], c["validation_tests"])
        assert problems_of(db, "measurement_contract", cid) == expected, c
        assert logged(db, cid) == as_counter(expected)
        db.q("ROLLBACK TO SAVEPOINT r")


def test_bundles_match_reference(db):
    rng = random.Random(216)
    for n in range(300):
        db.q("SAVEPOINT r")
        b = random_bundle(rng)
        b["observations"] = nn(b["observations"])
        latest = None
        validated, report = rng.choice([(False, None), (True, []), (True, None),
                                        (False, [{"test": "unit_check", "index": 0}])])
        bid = insert_bundle(db, b, validated, report)
        expected = bundle_problems(b["observations"], b["context"], b["provenance"])
        assert problems_of(db, "measurement_bundle", bid, False) == expected, b
        assert logged(db, bid) == as_counter(expected)
        for _ in range(rng.randint(0, 2)):
            latest = rng.choice([(True, []), (False, [{"test": "unit_check", "index": 0}]),
                                 (None, None)])
            db.q("INSERT INTO measurement_validation (bundle_id, ok, report) VALUES (%s, %s, %s)",
                 bid, latest[0], J(latest[1]))
        assert problems_of(db, "measurement_bundle", bid) == \
            expected + bundle_validated_problems(validated, report, latest)
        db.q("ROLLBACK TO SAVEPOINT r")


def test_validations_match_reference(db):
    rng = random.Random(316)
    for n in range(300):
        db.q("SAVEPOINT r")
        good = rng.random() < 0.6
        c = good_contract(rng, f"c{n}") if good else random_contract(rng, f"c{n}")
        c["observable_id"] = name_or_blank(c["observable_id"])
        b = good_bundle(rng) if good and rng.random() < 0.9 else random_bundle(rng)
        b["observations"] = nn(b["observations"])
        unc = None
        uid = None
        if rng.random() < 0.6:
            d = good_descriptor(rng) if good else nn(random_descriptor(rng))
            if d is not None:
                unc = (f"u{n}", d)
                uid = insert_uncertainty(db, *unc)
        cid = insert_contract(db, c, uid)
        bid = insert_bundle(db, b)
        computed = None
        if not validation_problems(True, [], b, c, unc)[:1] or \
                validation_problems(True, [], b, c, unc)[0][0] == "validation_result":
            computed = validate(c, b, unc[1] if unc else None)
        r = rng.random()
        if computed is not None and r < 0.5:
            ok, report = computed
        else:
            ok, report = rng.choice([(True, []), (False, [{"test": "range_check", "index": 0}]),
                                     (None, None), (True, {"x": 1})])
        b_ref = None if rng.random() < 0.05 else bid
        c_ref = None if rng.random() < 0.05 else cid
        vid = db.one("INSERT INTO measurement_validation (bundle_id, contract_id, ok, report) "
                     "VALUES (%s, %s, %s, %s) RETURNING id", b_ref, c_ref, ok, J(report))
        expected = validation_problems(ok, report, b if b_ref else None, c if c_ref else None,
                                       unc if c_ref else None)
        assert problems_of(db, "measurement_validation", vid) == expected, (c, b, unc, ok, report)
        assert logged(db, vid) == as_counter(expected)
        db.q("ROLLBACK TO SAVEPOINT r")


def test_validate_writer_matches_reference(db):
    rng = random.Random(416)
    for n in range(200):
        db.q("SAVEPOINT r")
        c, b, d = good_contract(rng, f"c{n}"), good_bundle(rng), good_descriptor(rng)
        uname = None
        if d is not None:
            uname = f"u{n}"
            db.q("SELECT register_uncertainty_type(%s, %s)", uname, Json(d))
        cid = db.one("SELECT register_measurement_contract(%s, %s, %s, %s, %s, %s, %s)",
                     c["name"], c["observable_id"], Json(c["validation_tests"]), Json(c["body"]),
                     Json(c["expected_precision"]), c["version"], uname)
        bid = db.one("SELECT record_measurement_bundle(%s)", Json(b["observations"]))
        ok, report = validate(c, b, d)
        assert db.one("SELECT validate_measurement_bundle(%s, %s)", bid, cid) is ok
        assert rows(db, "SELECT validated, validation_report FROM measurement_bundle WHERE id = %s",
                    bid) == [(ok, report)]
        assert rows(db, "SELECT ok, report FROM measurement_validation WHERE bundle_id = %s",
                    bid) == [(ok, report)]
        assert db.one("SELECT check_empirical()") == 0
        db.q("ROLLBACK TO SAVEPOINT r")


def test_edited_bundle_is_caught_in_batch(db):
    cid = db.one("SELECT register_measurement_contract('c', 'T', '[\"range_check\"]', "
                 "'{\"min\": 0, \"max\": 10}')")
    bid = db.one("SELECT record_measurement_bundle('[{\"value\": 5, \"uncertainty\": 1}]')")
    assert db.one("SELECT validate_measurement_bundle(%s, %s)", bid, cid) is True
    db.q("UPDATE measurement_bundle SET observations = '[{\"value\": 1e9}]' WHERE id = %s", bid)
    db.q("DELETE FROM empirical_violation")
    assert db.one("SELECT check_empirical()") == 1
    vid = db.one("SELECT id FROM measurement_validation WHERE bundle_id = %s", bid)
    assert problems_of(db, "measurement_validation", vid) == \
        [("validation_result", {"recorded": True, "computed": False})]
    # re-validating records the new result; the bundle follows the latest one
    assert db.one("SELECT validate_measurement_bundle(%s, %s)", bid, cid) is False
    assert problems_of(db, "measurement_bundle", bid) == []


def test_models_runs_and_agents_match_reference(db):
    rng = random.Random(516)
    for n in range(200):
        db.q("SAVEPOINT r")
        name, spec = name_or_blank(random_text(rng)), name_or_blank(random_text(rng))
        mtype = rng.choice(MODEL_TYPES)
        conf, meta = random_solver_config(rng), random_object(rng, 0.9)
        mid = db.one("INSERT INTO dynamical_model (name, model_type, model_spec, solver_config, "
                     "metadata) VALUES (%s, %s, %s, %s, %s) RETURNING id",
                     name, mtype, spec, J(conf), J(meta))
        expected = dynamical_model_problems(name, mtype, spec, conf, meta)
        assert problems_of(db, "dynamical_model", mid) == expected
        assert logged(db, mid) == as_counter(expected)

        init = nn(random_object(rng, 0.8))
        solver, uri = random_text(rng), random_text(rng)
        tol, summary = random_tolerance(rng), rng.choice([None, {}, {"x": 1}, [1]])
        started, finished = random_window(rng)
        model_ref = mid if rng.random() < 0.9 else None
        sid = db.one("INSERT INTO simulation_run (model_id, initial_conditions, solver_used, "
                     "tolerance, result_uri, result_summary, started_at, finished_at) "
                     "VALUES (%s, %s, %s, %s, %s, %s, %s, %s) RETURNING id",
                     model_ref, J(init), solver, tol, uri, J(summary), started, finished)
        expected = simulation_problems(model_ref is not None, init, solver, tol, uri, summary,
                                       started, finished)
        assert problems_of(db, "simulation_run", sid) == expected
        assert logged(db, sid) == as_counter(expected)

        pool = ["arm", "leg", "cam"]
        sensors, actuators = random_names_json(rng, pool), random_names_json(rng, pool)
        body, learning = rng.choice([None, {}, [1]]), rng.choice([None, {"lr": 0.1}, "x"])
        safety, meta = random_safety(rng, pool), random_object(rng, 0.9)
        aname = name_or_blank(random_text(rng))
        aid = db.one("INSERT INTO agent_model (name, body_spec, sensors, actuators, "
                     "learning_module, safety_constraints, metadata) "
                     "VALUES (%s, %s, %s, %s, %s, %s, %s) RETURNING id",
                     aname, J(body), J(sensors), J(actuators), J(learning), J(safety), J(meta))
        expected = agent_problems(aname, body, sensors, actuators, learning, safety, meta)
        assert problems_of(db, "agent_model", aid) == expected, (sensors, actuators, safety)
        assert logged(db, aid) == as_counter(expected)
        db.q("ROLLBACK TO SAVEPOINT r")


def test_mechanisms_match_reference(db):
    rng = random.Random(616)
    kinds = Counter()
    for n in range(400):
        db.q("SAVEPOINT r")
        name, spec = name_or_blank(random_text(rng)), nn(random_spec(rng))
        cons, meta = random_constraints(rng), random_object(rng, 0.95)
        mid = db.one("INSERT INTO mechanism (name, mechanism_spec, incentive_constraints, "
                     "metadata) VALUES (%s, %s, %s, %s) RETURNING id",
                     name, Json(spec), J(cons), J(meta))
        expected = mechanism_problems(name, spec, cons, meta)
        assert problems_of(db, "mechanism", mid) == expected, (spec, cons)
        assert logged(db, mid) == as_counter(expected)
        kinds.update(r for r, _ in expected)
        db.q("ROLLBACK TO SAVEPOINT r")
    assert kinds["mechanism_ic"] > 20 and kinds["mechanism_ir"] > 20


# ---------------------------------------------------------------------------
# Writers, strict mode, the append-only log, batch checks
# ---------------------------------------------------------------------------
POSTED_PRICE = {
    "types": ["lo", "hi"], "outcomes": ["none", "item"],
    "allocation": {"lo": "none", "hi": "item"}, "payment": {"lo": 0, "hi": 1.5},
    "valuation": {"lo": {"none": 0, "item": 1}, "hi": {"none": 0, "item": 2}},
}


def test_writers(db):
    assert db.one("SELECT register_mechanism('posted price', %s, '{\"ic\": true, \"ir\": true}')",
                  Json(POSTED_PRICE))
    over = dict(POSTED_PRICE, payment={"lo": 0, "hi": 2.5})
    savepoint_raises(db, "mechanism_ic", "SELECT register_mechanism('m', %s, '{\"ic\": true}')",
                     Json(over))
    assert db.one("SELECT register_mechanism('m', %s)", Json(over))       # nothing claimed
    savepoint_raises(db, "unknown uncertainty type",
                     "SELECT register_measurement_contract('c', 'T', '[]', '{}', '{}', '1.0.0', 'nope')")
    db.q("INSERT INTO uncertainty_type (name, descriptor) VALUES ('bad', '{\"kind\": \"gaussian\"}')")
    savepoint_raises(db, "coverage_factor",
                     "SELECT register_measurement_contract('c', 'T', '[]', '{}', '{}', '1.0.0', 'bad')")
    savepoint_raises(db, "coverage_factor",
                     "SELECT register_uncertainty_type('g', '{\"kind\": \"gaussian\", \"coverage_factor\": 0}')")
    mid = db.one("SELECT register_dynamical_model('decay', 'ODE', 'dx/dt = -k x', "
                 "'{\"tolerance\": 1e-6}')")
    assert db.one("SELECT record_simulation_run(%s, '{\"x\": 1}', 'rk45', 1e-6)", mid)
    savepoint_raises(db, "window", "SELECT record_simulation_run(%s, '{}', NULL, NULL, NULL, NULL, "
                     "now(), now() - interval '1 hour')", mid)
    assert db.one("SELECT register_agent_model('rover', '{}', '[\"cam\"]', '[\"arm\"]', NULL, "
                  "'[{\"actuator\": \"arm\", \"min\": -1, \"max\": 1}]')")
    savepoint_raises(db, "safety_constraint", "SELECT register_agent_model('rover', NULL, NULL, "
                     "'[\"arm\"]', NULL, '[{\"actuator\": \"leg\"}]')")
    assert db.one("SELECT check_empirical()") == 1        # the 'bad' uncertainty type


def test_strict_mode_refuses(db):
    db.set_mode("strict")
    savepoint_raises(db, "not well formed",
                     "INSERT INTO measurement_bundle (observations) VALUES ('[{\"v\": 1}]')")
    savepoint_raises(db, "not well formed",
                     "INSERT INTO mechanism (name, mechanism_spec, incentive_constraints) "
                     "VALUES ('m', %s, '{\"ic\": true}')",
                     Json(dict(POSTED_PRICE, payment={"lo": 0, "hi": 2.5})))
    db.q("INSERT INTO measurement_bundle (observations) VALUES ('[{\"value\": 1}]')")


def test_validation_log_is_append_only(db):
    cid = db.one("SELECT register_measurement_contract('c', 'T', '[]')")
    bid = db.one("SELECT record_measurement_bundle('[{\"value\": 1}]')")
    db.q("SELECT validate_measurement_bundle(%s, %s)", bid, cid)
    db.q("UPDATE measurement_validation SET ok = false")
    db.q("DELETE FROM measurement_validation")
    assert rows(db, "SELECT reason, details FROM empirical_violation ORDER BY detected_at") == [
        ("log_mutation", {"table": "measurement_validation", "op": "UPDATE"}),
        ("log_mutation", {"table": "measurement_validation", "op": "DELETE"})]
    db.set_mode("strict")
    savepoint_raises(db, "append-only", "TRUNCATE measurement_validation")


def test_batch_checks_and_reapplying_the_migration(db):
    db.q("INSERT INTO agent_model (name) VALUES ('')")
    with db.conn.cursor() as cur:        # idempotent
        cur.execute(MIGRATION.read_text())
    db.q("DELETE FROM empirical_violation")
    db.q("SELECT run_all_batch_checks()")
    assert rows(db, "SELECT violation_type, details FROM v_all_violations WHERE module = 'empirical'") == \
        [("agent_typing", {"error": "name"})]


def test_upgrade_from_the_original_migration(db):
    """In a fresh schema: the original 016, old rows, then the rewrite."""
    original = (Path(__file__).resolve().parent / "data" / "016_empirical_grounding_original.sql")
    with db.conn.cursor() as cur:
        cur.execute("CREATE SCHEMA emp_upgrade; SET LOCAL search_path = emp_upgrade, public")
        cur.execute(original.read_text())
        cur.execute("INSERT INTO uncertainty_type (name, descriptor) VALUES ('old', '{}')")
        cur.execute("INSERT INTO measurement_bundle (observations, validated) "
                    "VALUES ('[{\"value\": 1}]', true)")
        cur.execute(MIGRATION.read_text())
        cur.execute("SELECT count(*) FROM information_schema.columns WHERE table_schema = "
                    "'emp_upgrade' AND table_name = 'measurement_contract' "
                    "AND column_name = 'uncertainty_type_id'")
        assert cur.fetchone()[0] == 1
        cur.execute("SELECT check_empirical()")
        assert cur.fetchone()[0] == 2
        cur.execute("SELECT subject_table, reason, details FROM empirical_violation "
                    "ORDER BY subject_table")
        assert cur.fetchall() == [
            ("measurement_bundle", "bundle_validated", {"field": "validated"}),
            ("uncertainty_type", "uncertainty_typing", {"error": "kind"})]
