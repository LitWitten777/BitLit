"""Live-database fixtures: apply every migration to a real PostgreSQL.

The server comes from ``QBX_TEST_DATABASE_URL`` (an empty database you own) or,
failing that, from the ``pgserver`` package, which ships PostgreSQL binaries
and starts a throwaway server.  When neither is available, every test in this
directory is skipped.

One install-time substitution is made, outside the migrations themselves:
``pgcrypto`` is optional: ``gen_random_uuid()`` is built in since
PostgreSQL 13, and ``digest(bytea, 'sha256')`` is provided from the built-in
``sha256()`` when the extension is missing.

(The former substitution for the ``now()`` partial index in ``001_init.sql``
is gone: amendment A-001 fixed the migration itself.)
"""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

psycopg2 = pytest.importorskip("psycopg2")

MIGRATIONS = sorted((Path(__file__).resolve().parents[2] / "migrations").glob("*.sql"))


def migration_sql(path: Path, have_pgcrypto: bool) -> str:
    sql = path.read_text()
    if not have_pgcrypto:
        sql = sql.replace("CREATE EXTENSION IF NOT EXISTS pgcrypto;", "")
    return sql


@pytest.fixture(scope="session")
def pg_uri():
    uri = os.environ.get("QBX_TEST_DATABASE_URL")
    if uri:
        yield uri
        return
    pgserver = pytest.importorskip("pgserver")
    srv = pgserver.get_server(tempfile.mkdtemp(prefix="qbx_pg_"), cleanup_mode="stop")
    try:
        yield srv.get_uri()
    finally:
        srv.cleanup()


@pytest.fixture(scope="session")
def migrated(pg_uri):
    conn = psycopg2.connect(pg_uri)
    conn.autocommit = True
    with conn.cursor() as cur:
        cur.execute("SELECT 1 FROM pg_available_extensions WHERE name = 'pgcrypto'")
        have_pgcrypto = cur.fetchone() is not None
        if not have_pgcrypto:
            cur.execute(
                "CREATE OR REPLACE FUNCTION digest(bytea, text) RETURNS bytea "
                "AS $$ SELECT sha256($1) $$ LANGUAGE sql IMMUTABLE;"
            )
        for path in MIGRATIONS:
            cur.execute(migration_sql(path, have_pgcrypto))
    conn.close()
    return pg_uri


@pytest.fixture
def db(migrated):
    """A `Ledger` inside a transaction that is rolled back after the test."""
    from tests.live_db.ledger import Ledger

    conn = psycopg2.connect(migrated)
    conn.autocommit = False
    try:
        yield Ledger(conn)
    finally:
        conn.rollback()
        conn.close()
