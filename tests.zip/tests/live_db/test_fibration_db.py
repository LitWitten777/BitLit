"""Migration 010 (fibrations and opfibrations) on a real PostgreSQL.

Formal backing: ``Formal/Fibration.lean`` — the check is exactly a strongly
(co)cartesian morphism (``isStronglyCartesian_iff_check``,
``isStronglyCocartesian_iff_check``); every ``(u, e)`` having a lift passing it
is exactly ``Functor.IsFibered`` (``isFibered_iff_cleavageCheck``); existence
and uniqueness are both needed (``cartesian_existence_not_sufficient``,
``cartesian_uniqueness_not_sufficient``); over a one-object base the cartesian
morphisms are the isomorphisms (``isStronglyCartesian_star_iff_isIso``), used
below as an oracle.
"""

from __future__ import annotations

import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx.categorical.fibration import all_monoids, monoid_over_point, units
from tests.fibration_examples import (
    elements_fibration,
    non_cartesian_example,
    random_fibration,
    transformation_monoid,
)


def reset(db) -> None:
    db.conn.rollback()
    db.ids.clear()
    db.cat_of.clear()
    db.morphisms.clear()
    db.composites.clear()


def canon(problems):
    return sorted((r, repr(sorted(d.items()))) for r, d in problems)


def small(db, register=True):
    """The non-cartesian example: a --φ--> b <--ψ-- c over x --u--> y."""
    db.load_fibration(non_cartesian_example() if register else _without_lifts())


def _without_lifts():
    fib = non_cartesian_example()
    fib.lifts = []
    return fib


# ---------------------------------------------------------------------------
# The original migration's bugs
# ---------------------------------------------------------------------------
def test_wrong_direction_functor_is_logged(db):
    """Original bug: a fibration whose projection functor goes B → E was accepted."""
    small(db, register=False)
    db.functor("q", "B", "E", {}, {})
    db.fibration("bad", "E", "B", "q")
    assert db.fib_violations("bad") == ["fibration_typing"]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="not well typed"):
        db.fibration("bad2", "E", "B", "q")


def test_writer_refuses_lift_not_over_base(db):
    """Original bug: φ with p(φ) = u was accepted as a lift of another morphism."""
    small(db, register=False)
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="does not lie over"):
        db.lift("F", "phi", "id_x")
    db.q("ROLLBACK TO SAVEPOINT s")
    db.lift_row("F", "phi", "id_x")             # direct insert: logged by the trigger
    assert db.fib_violations("F") == ["lift_not_over_base"]
    assert db.fib_reasons("F").count("lift_not_over_base") == 1


def test_writer_refuses_wrong_endpoints(db):
    """Original bug: recorded source / target need not be those of the lift."""
    small(db, register=False)
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="source / target"):
        db.lift("F", "phi", "u", src="c", tgt="b")
    db.q("ROLLBACK TO SAVEPOINT s")
    db.lift_row("F", "phi", "u", src="c", tgt="b")
    assert db.fib_violations("F") == ["lift_typing"]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.lift_row("F", "psi", "u", src="a", tgt="a")


def test_writer_never_replaces_a_lift(db):
    """Original bug: ON CONFLICT (fibration, base, source) DO UPDATE silently
    replaced a registered lift."""
    small(db, register=False)
    first = db.lift("F", "phi", "u")
    assert db.lift("F", "phi", "u") == first           # idempotent
    second = db.lift("F", "psi", "u")                  # same base and target: a new row
    assert second != first
    assert db.one("SELECT total_morphism_id FROM cartesian_lift WHERE id = %s", first) \
        == db.ids["phi"]
    assert db.one("SELECT count(*) FROM cartesian_lift") == 2
    with pytest.raises(psycopg2.Error, match="another base"):
        db.lift("F", "phi", "id_y")


def test_non_cartesian_lift_is_detected(db):
    """Original bug: verify_cartesian_property passed any lift whose source has
    an incoming morphism (e.g. its identity)."""
    small(db)
    lift = db.one("SELECT id FROM cartesian_lift")
    assert db.one("SELECT verify_cartesian_property(%s, %s)", db.ids["F"], lift) is False
    assert db.fib_violations("F") == ["cartesian_existence"]
    assert db.fib_problems("F") == [
        ("cartesian_existence", {"lift": "phi", "base": "u", "h": "psi", "w": "id_x"}),
        ("missing_lift", {"base": "u", "object": "b"}),
    ]


def test_verify_refuses_a_foreign_lift(db):
    small(db)
    lift = db.one("SELECT id FROM cartesian_lift")
    db.functor("p2", "E", "B", {}, {})
    db.fibration("G", "E", "B", "p2")
    with pytest.raises(psycopg2.Error, match="is not a lift of"):
        db.q("SELECT verify_cartesian_property(%s, %s)", db.ids["G"], lift)


def test_repair_with_factorization(db):
    """Adding k : c → a over id_x with φ ∘ k = ψ makes φ cartesian."""
    small(db)
    db.mor("k", "c", "a")
    db.comp("phi", "k", "psi")
    db.q("INSERT INTO functor_morphism_map (functor_id, source_morphism_id, target_morphism_id) "
         "VALUES (%s, %s, %s)", db.ids["p"], db.ids["k"], db.ids["id_x"])
    assert db.fib_problems("F") == []
    assert db.check_fibration("F") is True


def test_uniqueness_failure(db):
    small(db)
    for k in ("k1", "k2"):
        db.mor(k, "c", "a")
        db.comp("phi", k, "psi")
        db.q("INSERT INTO functor_morphism_map (functor_id, source_morphism_id, "
             "target_morphism_id) VALUES (%s, %s, %s)", db.ids["p"], db.ids[k], db.ids["id_x"])
    probs = db.fib_problems("F")
    assert [r for r, _ in probs] == ["cartesian_uniqueness", "missing_lift"]
    assert probs[0][1]["count"] == 2


# ---------------------------------------------------------------------------
# Fibrations and opfibrations
# ---------------------------------------------------------------------------
def test_category_of_elements_is_a_fibration(db):
    db.load_fibration(elements_fibration())
    assert db.fib_problems("F") == []
    db.set_mode("strict")
    assert db.check_fibration("F") is True


def test_category_of_elements_is_not_an_opfibration(db):
    model = elements_fibration("opfibration")
    db.load_fibration(model)
    assert canon(db.fib_problems("F")) == canon(model.problems())
    assert Counter(db.fib_reasons("F")) == Counter({"cocartesian_existence": 2,
                                                    "missing_lift": 3})


def test_kind_is_constrained(db):
    small(db, register=False)
    with pytest.raises(psycopg2.Error):
        db.fibration("bi", "E", "B", "p", kind="bifibration")


def test_batch_check_strict_and_permissive(db):
    small(db)
    db.clear_fib_violations()
    assert db.check_fibration("F") is False
    assert db.fib_violations("F") == ["cartesian_existence", "missing_lift"]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="violates its laws"):
        db.check_fibration("F")


def test_run_all_batch_checks_and_summary_view(db):
    small(db)
    db.clear_fib_violations()
    db.q("SELECT run_all_batch_checks()")
    assert db.fib_violations("F") == ["cartesian_existence", "missing_lift"]
    rows = db.q("SELECT violation_type FROM v_all_violations WHERE module = 'fibration' "
                "AND subject = %s", db.ids["F"])
    assert sorted(r[0] for r in rows) == ["cartesian_existence", "missing_lift"]


# ---------------------------------------------------------------------------
# Oracle: over the one-object base, cartesian = invertible
# ---------------------------------------------------------------------------
def test_monoids_over_a_point_cartesian_iff_unit(db):
    elems = ["id_*", "x", "y"]
    tables = list(all_monoids(elems, "id_*"))
    tables.append(transformation_monoid()[2])
    for mul in tables:
        reset(db)
        es = sorted({g for g, _ in mul})
        model = monoid_over_point(es, "id_*", mul)
        db.load_fibration(model)
        failing = {d["lift"] for _, d in db.fib_problems("F")}
        assert failing == set(es) - set(units(es, "id_*", mul)), mul
        assert canon(db.fib_problems("F")) == canon(model.problems())


# ---------------------------------------------------------------------------
# Upgrade path from the original table layout
# ---------------------------------------------------------------------------
def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE cartesian_lift, fibration_violation, fibration CASCADE")
    db.q("""
      CREATE TABLE fibration (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(), name TEXT NOT NULL UNIQUE,
        total_category_id UUID NOT NULL REFERENCES category(id),
        base_category_id UUID NOT NULL REFERENCES category(id),
        projection_functor_id UUID NOT NULL REFERENCES functor(id),
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE cartesian_lift (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        fibration_id UUID NOT NULL REFERENCES fibration(id) ON DELETE CASCADE,
        base_morphism_id UUID NOT NULL REFERENCES morphism(id),
        total_source_object_id UUID NOT NULL REFERENCES object(id),
        total_target_object_id UUID NOT NULL REFERENCES object(id),
        total_morphism_id UUID NOT NULL REFERENCES morphism(id),
        metadata JSONB DEFAULT '{}'::jsonb,
        UNIQUE (fibration_id, base_morphism_id, total_source_object_id));
    """)
    path = Path(__file__).resolve().parents[2] / "migrations" / "010_fibrations.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    cons = sorted(r[0] for r in db.q(
        "SELECT conname FROM pg_constraint WHERE conrelid = 'cartesian_lift'::regclass "
        "AND contype = 'u'"))
    assert cons == ["cartesian_lift_morphism_unique"]
    assert db.one("SELECT count(*) FROM information_schema.columns "
                  "WHERE table_name = 'fibration' AND column_name = 'kind'") == 1
    # and the upgraded tables work
    db.load_fibration(elements_fibration())
    assert db.fib_problems("F") == []


# ---------------------------------------------------------------------------
# Agreement with the in-memory reference engine
# ---------------------------------------------------------------------------
def test_database_agrees_with_python_reference(db):
    rng = random.Random(1010)
    total = Counter()
    for i in range(40):
        model = random_fibration(rng)
        reset(db)
        db.load_fibration(model)
        py = canon(model.problems())
        sql = canon(db.fib_problems("F"))
        assert sql == py, i
        total.update(r for r, _ in py)
    assert set(total) == {"lift_typing", "lift_not_over_base", "cartesian_existence",
                          "cartesian_uniqueness", "cocartesian_existence",
                          "cocartesian_uniqueness", "missing_lift"}
