"""Migration 018 (capability revocation, decision Q-001) and the amended 003 trigger (A-004)."""

from __future__ import annotations

import time

import psycopg2
import pytest
from qbx.core.signing import StubSigner

from qbx.core.capability import CapabilityIssuer, CapabilityVerifier, parse_token

T0 = 1_800_000_000


def store(db, token: str) -> None:
    claims, _, _ = parse_token(token)
    db.q(
        "SELECT register_signed_capability(%s, %s, %s, %s, to_timestamp(%s))",
        token, claims.token_id, claims.subject, list(claims.scopes), claims.expires_at,
    )


def active(db, token, scope=None, at=T0 + 1):
    return db.one("SELECT capability_token_is_active(%s, %s, to_timestamp(%s))", token, scope, at)


def signer(tmp_path, key_id="k1", name="k1"):
    return StubSigner(key_path=str(tmp_path / f"{name}.pem"), key_id=key_id)


@pytest.fixture
def issuer(tmp_path):
    return CapabilityIssuer(signer(tmp_path))


def test_active_expiry_scope_and_revocation(db, tmp_path, issuer):
    tok = issuer.issue("alice", ["weyl:expand"], 100, now=T0, token_id="t1")
    assert CapabilityVerifier({"k1": signer(tmp_path)}).is_valid(tok, "weyl:expand", now=T0 + 1)
    store(db, tok)
    assert active(db, tok)
    assert active(db, tok, "weyl:expand")
    assert not active(db, tok, "ledger:write")
    assert not active(db, tok, at=T0 + 100)
    assert not active(db, "unknown-token")
    db.q("SELECT revoke_capability('t1', 'compromised', 'security_engineer')")
    db.q("SELECT revoke_capability('t1', 'again', 'x')")  # idempotent
    assert not active(db, tok)
    assert db.one("SELECT reason FROM capability_revocation WHERE token_id = 't1'") == "compromised"


def test_wildcard_scope(db, issuer):
    tok = issuer.issue("a", ["*"], 100, now=T0)
    store(db, tok)
    assert active(db, tok, "anything")


def test_tokens_without_expiry_are_refused(db):
    with pytest.raises(psycopg2.Error):
        db.q("SELECT register_signed_capability('x', 'id', 'o', ARRAY['s'], NULL)")


def test_legacy_rows_without_expiry_are_inactive(db):
    db.q("INSERT INTO capability_token (token, scopes) VALUES ('legacy', ARRAY['*'])")
    assert not active(db, "legacy")


def test_enforce_signed_capability_trigger(db, issuer):
    db.q("CREATE TEMP TABLE artifact_t (id int, metadata jsonb)")
    db.q("CREATE TRIGGER cap BEFORE INSERT ON artifact_t FOR EACH ROW "
         "EXECUTE FUNCTION enforce_signed_capability('ledger:write')")
    # The trigger compares against now(), which is the *transaction start* time; the
    # db fixture opens its transaction before this line runs, so a token issued "now"
    # by the wall clock can have not_before one second after now() (flaky failure,
    # seen 2026-10-13).  Back-date issuance so the check is clock-independent.
    good = issuer.issue("a", ["ledger:write"], 10**9, now=int(time.time()) - 3600, token_id="g")
    store(db, good)
    db.q("INSERT INTO artifact_t VALUES (0, '{}')")  # not production: no check
    db.q("INSERT INTO artifact_t VALUES (1, jsonb_build_object('zone', 'production', "
         "'capability_token', %s::text))", good)
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error):
        db.q("INSERT INTO artifact_t VALUES (2, '{\"zone\": \"production\"}')")
    db.q("ROLLBACK TO SAVEPOINT s")
    db.q("SELECT revoke_capability('g')")
    with pytest.raises(psycopg2.Error):
        db.q("INSERT INTO artifact_t VALUES (3, jsonb_build_object('zone', 'production', "
             "'capability_token', %s::text))", good)


def _attach_003(db, table="artifact_f"):
    db.q(f"CREATE TEMP TABLE {table} (id int, metadata jsonb)")
    db.q(f"CREATE TRIGGER cap BEFORE INSERT ON {table} FOR EACH ROW "
         "EXECUTE FUNCTION enforce_capability_token()")


def _refused(db, sql, *args):
    db.q("SAVEPOINT s")
    try:
        with pytest.raises(psycopg2.Error, match="valid capability token"):
            db.q(sql, *args)
    finally:
        db.q("ROLLBACK TO SAVEPOINT s")


def test_amended_003_trigger_accepts_active_token(db, issuer):
    """Amendment A-004: the frozen ``enforce_capability_token()`` no longer
    fails with an ambiguous column reference; a production write carrying an
    active token is accepted."""
    _attach_003(db)
    good = issuer.issue("a", ["weyl:expand"], 10**9, token_id="g3")
    store(db, good)
    db.q("INSERT INTO artifact_f VALUES (0, '{}')")  # not production: no check
    db.q("INSERT INTO artifact_f VALUES (1, jsonb_build_object('zone', 'production', "
         "'capability_token', %s::text))", good)
    assert db.one("SELECT count(*) FROM artifact_f") == 2


def test_amended_003_trigger_refuses_bad_tokens(db, issuer):
    """A-004 option 1 applies the Q-001 policy: missing, unknown, expired,
    expiry-less and revoked tokens are all refused.  (Under
    ``variable_conflict = use_column`` the original body would have accepted
    *any* token as soon as one unexpired row existed.)"""
    _attach_003(db)
    good = issuer.issue("a", ["ledger:write"], 10**9, token_id="g4")
    store(db, good)
    prod = ("INSERT INTO artifact_f VALUES (9, jsonb_build_object('zone', 'production', "
            "'capability_token', %s::text))")
    _refused(db, "INSERT INTO artifact_f VALUES (2, '{\"zone\": \"production\"}')")
    _refused(db, prod, "not-a-stored-token")
    expired = issuer.issue("a", ["ledger:write"], 100, now=1_000_000_000, token_id="old")
    store(db, expired)
    _refused(db, prod, expired)
    db.q("INSERT INTO capability_token (token, scopes) VALUES ('legacy', ARRAY['*'])")
    _refused(db, prod, "legacy")
    db.q("SELECT revoke_capability('g4')")
    _refused(db, prod, good)
    assert db.one("SELECT count(*) FROM artifact_f") == 0


def test_amended_003_trigger_fails_closed_without_018(db, issuer):
    """If ``capability_token_is_active`` (migration 018) is missing, the
    trigger raises instead of letting the write through."""
    _attach_003(db)
    good = issuer.issue("a", ["ledger:write"], 10**9, token_id="g5")
    store(db, good)
    db.q("DROP FUNCTION capability_token_is_active(text, text, timestamptz)")
    with pytest.raises(psycopg2.Error, match="capability_token_is_active"):
        db.q("INSERT INTO artifact_f VALUES (1, jsonb_build_object('zone', 'production', "
             "'capability_token', %s::text))", good)


# ---------------------------------------------------------------------------
# Phase 1 sprint 14 (acceptance review): the gaps of the earlier 018
# ---------------------------------------------------------------------------
def _raises(db, match, sql, *args):
    db.q("SAVEPOINT s")
    try:
        with pytest.raises(psycopg2.Error, match=match):
            db.q(sql, *args)
    finally:
        db.q("ROLLBACK TO SAVEPOINT s")


def test_registration_must_match_the_claims(db, issuer):
    tok = issuer.issue("alice", ["weyl:expand"], 100, now=T0, token_id="t1")
    reg = "SELECT register_signed_capability(%s, %s, %s, %s, to_timestamp(%s))"
    # the earlier version accepted all of these and then honoured them
    _raises(db, "differ", reg, tok, "t1", "alice", ["*"], T0 + 100)
    _raises(db, "differ", reg, tok, "t1", "alice", ["weyl:expand"], T0 + 10**6)
    _raises(db, "differ", reg, tok, "other-id", "alice", ["weyl:expand"], T0 + 100)
    _raises(db, "differ", reg, tok, "t1", "mallory", ["weyl:expand"], T0 + 100)
    _raises(db, "well-formed", reg, "not-a-token", "t1", "alice", ["weyl:expand"], T0 + 100)
    _raises(db, "well-formed", reg, "qbxcap1.!!!.x", "t1", "alice", ["weyl:expand"], T0 + 100)
    db.q(reg, tok, "t1", "alice", ["weyl:expand", "weyl:expand"], T0 + 100)   # same set
    assert active(db, tok, "weyl:expand") and not active(db, tok, "ledger:write")


def test_not_before_is_honoured(db, issuer):
    tok = issuer.issue("bob", ["s"], 100, now=T0, token_id="t2")
    store(db, tok)
    assert not active(db, tok, "s", T0 - 50)       # the earlier version said active
    assert not active(db, tok, "s", T0 - 0.5)
    assert active(db, tok, "s", T0)
    assert active(db, tok, "s", T0 + 99.5)
    assert not active(db, tok, "s", T0 + 100)


def test_capability_claims_decodes_tokens(db, issuer):
    tok = issuer.issue("carol", ["a", "b"], 5, now=T0, token_id="t3")
    claims, _, _ = parse_token(tok)
    assert db.one("SELECT capability_claims(%s)", tok) == claims.to_dict()
    for bad in ("", "qbxcap1", "qbxcap2.e30.x", "qbxcap1.e30", "qbxcap1.WzFd.x", "qbxcap1.@@.x"):
        assert db.one("SELECT capability_claims(%s)", bad) is None, bad


def test_activity_matches_reference(db, tmp_path):
    """Random tokens, revocations and queries: capability_token_is_active agrees
    with CapabilityVerifier.is_valid for every stored, correctly signed token."""
    import random
    from qbx.core.capability import RevocationList

    rng = random.Random(18)
    s = signer(tmp_path)
    issuer = CapabilityIssuer(s)
    revocations = RevocationList()
    verifier = CapabilityVerifier({"k1": s}, revocations)
    scopes = ["ledger:write", "weyl:expand", "audit:read", "*"]
    tokens = []
    for i in range(60):
        tok = issuer.issue(f"u{i % 5}", rng.sample(scopes, rng.randint(1, 3)), rng.randint(1, 500),
                           now=T0 + rng.randint(-300, 300), token_id=f"r{i}")
        store(db, tok)
        tokens.append(tok)
    for i in rng.sample(range(60), 15):
        revocations.revoke(f"r{i}")
        db.q("SELECT revoke_capability(%s)", f"r{i}")
    seen = {True: 0, False: 0}
    for _ in range(1500):
        tok = rng.choice(tokens)
        scope = rng.choice(scopes[:3] + ["other"])
        at = T0 + rng.randint(-400, 900) + rng.choice([0, 0.25, 0.5, 0.75])
        want = verifier.is_valid(tok, scope, now=int(at))
        assert active(db, tok, scope, at) == want, (tok, scope, at)
        seen[want] += 1
    assert seen[True] > 100 and seen[False] > 100
