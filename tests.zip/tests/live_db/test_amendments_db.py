"""Live-database tests for the approved amendments A-001, A-002 and A-003
to the frozen migrations ``001_init.sql`` and ``002_enforced_functor.sql``
(see ``agents/memory/amendments/``).

These replace ``test_frozen_defects_db.py``, which pinned the defective
behaviour before the amendments were approved.
"""

import pytest

psycopg2 = pytest.importorskip("psycopg2")

from tests.live_db.conftest import MIGRATIONS  # noqa: E402


# ---------------------------------------------------------------------------
# A-001 — capability index
# ---------------------------------------------------------------------------

def test_A001_migration_has_no_now_predicate():
    sql = MIGRATIONS[0].read_text()
    assert "WHERE expires_at > now()" not in sql
    assert "ON capability_token (token, expires_at);" in sql


def test_A001_capability_index_installed(db):
    """001_init.sql installs unmodified, including the amended index."""
    indexdef = db.one(
        "SELECT indexdef FROM pg_indexes WHERE indexname = 'idx_capability_token_active'"
    )
    assert indexdef is not None
    assert "(token, expires_at)" in indexdef
    assert "WHERE" not in indexdef


# ---------------------------------------------------------------------------
# A-002 — functor-law triggers
# ---------------------------------------------------------------------------

def _arrow_with_composite(db):
    """C: X --f--> Y --g--> Z with h = g ∘ f;  D: a single object T."""
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("h", "X", "Z")
    db.comp("g", "f", "h")
    db.category("D")
    db.obj("D", "T")


def _target_arrow(db):
    """D: A --a--> B --b--> E with c = b ∘ a, plus a parallel c2: A → E."""
    db.category("D")
    for o in ("A", "B", "E"):
        db.obj("D", o)
    db.mor("a", "A", "B")
    db.mor("b", "B", "E")
    db.mor("c", "A", "E")
    db.mor("c2", "A", "E")
    db.comp("b", "a", "c")


def _laws(db, functor):
    return sorted(
        r[0] for r in db.q(
            "SELECT law FROM functor_law_violation WHERE functor_id = %s", db.ids[functor]
        )
    )


ORDERS = [
    ("h", "id_X", "id_Y", "id_Z", "f", "g"),   # composite first
    ("id_X", "id_Y", "id_Z", "f", "g", "h"),   # factors first
    ("f", "h", "g", "id_X", "id_Y", "id_Z"),   # mixed
]


@pytest.mark.parametrize("mode", ["permissive", "strict"])
@pytest.mark.parametrize("order", ORDERS)
def test_A002_constant_functor_accepted(db, mode, order):
    """The constant functor is a functor: no violation, no exception, in
    either mode and for every insertion order (unit laws applied)."""
    _arrow_with_composite(db)
    db.set_mode(mode)
    db.functor("K", "C", "D", {o: "T" for o in "XYZ"}, {m: "id_T" for m in order})
    assert _laws(db, "K") == []
    assert db.one("SELECT check_functor_laws(%s)", db.ids["K"]) == 0


def _C_to_D(db):
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("h", "X", "Z")
    db.comp("g", "f", "h")
    _target_arrow(db)


@pytest.mark.parametrize("order", ORDERS)
def test_A002_genuine_functor_accepted_in_strict_mode(db, order):
    _C_to_D(db)
    db.set_mode("strict")
    mors = {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c"}
    db.functor("F", "C", "D", {"X": "A", "Y": "B", "Z": "E"}, {m: mors[m] for m in order})
    assert _laws(db, "F") == []


@pytest.mark.parametrize("order", ORDERS)
def test_A002_composition_violation_detected_in_every_order(db, order):
    """F(h) = c2 ≠ c = F(g) ∘ F(f): logged exactly once whatever the order."""
    _C_to_D(db)
    db.set_mode("permissive")
    mors = {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c2"}
    db.functor("F", "C", "D", {"X": "A", "Y": "B", "Z": "E"}, {m: mors[m] for m in order})
    assert _laws(db, "F") == ["composition"]


def test_A002_composition_violation_raises_in_strict_mode(db):
    _C_to_D(db)
    db.set_mode("strict")
    mors = {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c2"}
    with pytest.raises(psycopg2.Error, match="Functor composition law violated"):
        db.functor("F", "C", "D", {"X": "A", "Y": "B", "Z": "E"}, mors)


def test_A002_missing_composite_is_a_violation(db):
    """F(g) ∘ F(f) not recorded in the target → 'composition_composite_missing'."""
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("h", "X", "Z")
    db.comp("g", "f", "h")
    db.category("D")
    for o in ("A", "B", "E"):
        db.obj("D", o)
    db.mor("a", "A", "B")
    db.mor("b", "B", "E")
    db.mor("c", "A", "E")      # b ∘ a deliberately not recorded
    db.functor(
        "F", "C", "D", {"X": "A", "Y": "B", "Z": "E"},
        {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c"},
    )
    assert _laws(db, "F") == ["composition_composite_missing"]


def test_A002_identity_violation_logged_in_permissive_mode(db):
    """Previously the identity trigger raised in every mode (and the log row
    was rolled back with the insert)."""
    _target_arrow(db)
    db.category("C")
    db.obj("C", "X")
    db.set_mode("permissive")
    db.functor("F", "C", "D", {"X": "A"}, {"id_X": "id_B"})
    assert _laws(db, "F") == ["identity"]


def test_A002_identity_violation_raises_in_strict_mode(db):
    _target_arrow(db)
    db.category("C")
    db.obj("C", "X")
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="Functor identity law violated"):
        db.functor("F", "C", "D", {"X": "A"}, {"id_X": "id_B"})


def test_A002_all_factorizations_checked(db):
    """h has two factorizations; only the second one fails under F."""
    db.category("C")
    for o in ("X", "Y", "W", "Z"):
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("f2", "X", "W")
    db.mor("g2", "W", "Z")
    db.mor("h", "X", "Z")
    db.comp("g", "f", "h")
    db.comp("g2", "f2", "h")
    _target_arrow(db)
    db.set_mode("permissive")
    db.functor(
        "F", "C", "D", {"X": "A", "Y": "B", "W": "A", "Z": "E"},
        # g2 ∘ f2 ↦ c2 ∘ id_A = c2 ≠ c = F(h)
        {"id_X": "id_A", "id_Y": "id_B", "id_W": "id_A", "id_Z": "id_E",
         "f": "a", "g": "b", "f2": "id_A", "g2": "c2", "h": "c"},
    )
    assert _laws(db, "F") == ["composition"]


def test_A002_batch_check_catches_later_composition(db):
    """A composition recorded after the maps is found by check_functor_laws."""
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("h", "X", "Z")
    _target_arrow(db)
    db.functor(
        "F", "C", "D", {"X": "A", "Y": "B", "Z": "E"},
        {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c2"},
    )
    assert _laws(db, "F") == []
    db.comp("g", "f", "h")
    assert db.one("SELECT check_functor_laws(%s)", db.ids["F"]) == 1
    assert _laws(db, "F") == ["composition"]


# ---------------------------------------------------------------------------
# A-003 — composition table constraints
# ---------------------------------------------------------------------------

def test_A003_endomorphism_composed_with_itself(db):
    """f ∘ f is recordable (an idempotent e: e ∘ e = e)."""
    db.category("M")
    db.obj("M", "S")
    db.mor("e", "S", "S")
    db.comp("e", "e", "e")
    assert db.one(
        "SELECT result_id FROM composition WHERE left_id = %s AND right_id = %s",
        db.ids["e"], db.ids["e"],
    ) == db.ids["e"]


def test_A003_one_result_per_pair(db):
    _target_arrow(db)
    with pytest.raises(psycopg2.Error, match="composition_pair_unique"):
        db.comp("b", "a", "c2")


def test_A003_rejects_non_composable_pair(db):
    _target_arrow(db)
    db.mor("d", "A", "B")
    with pytest.raises(psycopg2.Error, match="not composable"):
        db.comp("a", "d", "a")      # target(d) = B ≠ A = source(a)


def test_A003_rejects_ill_typed_result(db):
    _target_arrow(db)
    db.mor("d", "B", "E")
    with pytest.raises(psycopg2.Error, match="result must go from"):
        db.q(
            "INSERT INTO composition (category_id, left_id, right_id, result_id) "
            "VALUES (%s, %s, %s, %s)",
            db.ids["D"], db.ids["b"], db.ids["a"], db.ids["d"],   # d: B → E, not A → E
        )


def test_A003_rejects_cross_category_rows(db):
    _target_arrow(db)
    db.category("C")
    db.obj("C", "X")
    with pytest.raises(psycopg2.Error, match="not all in category"):
        db.q(
            "INSERT INTO composition (category_id, left_id, right_id, result_id) "
            "VALUES (%s, %s, %s, %s)",
            db.ids["C"], db.ids["b"], db.ids["a"], db.ids["c"],
        )


def test_A002_run_all_batch_checks_includes_functors(db):
    """run_all_batch_checks (migration 017) now re-checks every functor."""
    db.category("C")
    for o in "XYZ":
        db.obj("C", o)
    db.mor("f", "X", "Y")
    db.mor("g", "Y", "Z")
    db.mor("h", "X", "Z")
    _target_arrow(db)
    db.functor(
        "F", "C", "D", {"X": "A", "Y": "B", "Z": "E"},
        {"id_X": "id_A", "id_Y": "id_B", "id_Z": "id_E", "f": "a", "g": "b", "h": "c2"},
    )
    db.comp("g", "f", "h")
    db.q("SELECT run_all_batch_checks()")
    assert _laws(db, "F") == ["composition"]
