"""Migration 019 (braid ledger: braids, rewrite records, derivations) on a real
PostgreSQL.

The reference is ``qbx_ir.ledger``: on random data — including malformed
braids, wrong outputs, unknown rules, wrong declarations and hashes, and broken
chains — the database reports exactly the problems the Python code reports,
with the same details, in the same order.

Formal backing: ``Formal/BraidLedger.lean`` — ``step_iff_exists_applyRule``
(the rewrite check is exactly one QBX rewrite step), ``chainEnd_eval_eq`` and
``eval_eq_iff_exists_chain`` (accepted derivations certify equality in B_n, and
every equality has one).
"""

from __future__ import annotations

import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.rewriting import ALL_RULES, apply_rule, braid_hash, find_matches
from qbx_ir.ledger import (
    RULES,
    BraidRow,
    RewriteRow,
    apply_short,
    braid_problems,
    derivation_problems,
    record_rewrite,
    rewrite_problems,
    word_hash,
)

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "019_braid_ledger.sql"


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def random_word(rng, n, length):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(length)]


class Mirror:
    """Inserts rows directly (no writer) and keeps the Python twin of each."""

    def __init__(self, db):
        self.db = db
        self.braid_id = {}      # key -> id
        self.braid_row = {}     # id -> BraidRow
        self.rewrite_row = {}   # id -> RewriteRow
        self.rewrite_ids = []

    def braid(self, row: BraidRow) -> str:
        if row.key in self.braid_id:
            return self.braid_id[row.key]
        bid = self.db.one(
            "INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (%s, %s::int[], %s) "
            "RETURNING id", row.strand_count, list(row.word), row.braid_hash)
        self.braid_id[row.key] = bid
        self.braid_row[bid] = row
        return bid

    def existing(self, row: BraidRow) -> BraidRow:
        """The stored row with the same key (content addressing)."""
        bid = self.braid_id.get(row.key)
        return self.braid_row[bid] if bid else row

    def rewrite(self, r: RewriteRow) -> str:
        r = RewriteRow(self.existing(r.input), r.rule_id, r.position, self.existing(r.output),
                       r.input_hash, r.output_hash, r.preserved, r.changed)
        i, o = self.braid(r.input), self.braid(r.output)
        rid = self.db.one(
            "INSERT INTO braid_rewrite (input_braid_id, rule_id, position, output_braid_id, "
            "input_hash, output_hash, preserved, changed) "
            "VALUES (%s, %s, %s, %s, %s, %s, %s::text[], %s::text[]) RETURNING id",
            i, r.rule_id, r.position, o, r.input_hash, r.output_hash,
            list(r.preserved), list(r.changed))
        self.rewrite_row[rid] = r
        self.rewrite_ids.append(rid)
        return rid


def random_braid_row(rng) -> BraidRow:
    n = rng.randint(1, 5)
    w = random_word(rng, n, rng.randint(0, 6)) if n > 1 else []
    roll = rng.random()
    if roll < 0.05:
        return BraidRow(rng.choice([0, -1]), tuple(w), word_hash(max(n, 1), w))
    if roll < 0.12 and w:
        k = rng.randrange(len(w))
        w[k] = rng.choice([0, n, -n, n + 2])
        return BraidRow(n, tuple(w), "x" * 8)
    if roll < 0.18:
        return BraidRow(n, tuple(w), word_hash(n + 1, w))
    return BraidRow.of(n, w)


def random_rewrite(rng, m: Mirror) -> RewriteRow:
    ids = list(m.braid_row)
    inp = m.braid_row[rng.choice(ids)]
    options = [(r, k) for r in RULES for k in range(len(inp.word))
               if not braid_problems(inp) and apply_short(inp.word, r, k) is not None]
    if options and rng.random() < 0.75:
        rule, k = rng.choice(options)
        good = record_rewrite(inp, rule, k)
    else:
        rule = rng.choice(["R01", "R02", "R03"])
        k = rng.randint(-1, len(inp.word) + 1)
        out = m.braid_row[rng.choice(ids)]
        rr = RULES[rule]
        good = RewriteRow(inp, rule, k, out, inp.braid_hash, out.braid_hash, rr.preserved, rr.changed)
    roll = rng.random()
    if roll < 0.1:
        out = m.braid_row[rng.choice(ids)]
        return RewriteRow(good.input, good.rule_id, good.position, out, good.input_hash,
                          out.braid_hash, good.preserved, good.changed)
    if roll < 0.16:
        return RewriteRow(good.input, rng.choice(["R04", "r01", ""]), good.position, good.output,
                          good.input_hash, good.output_hash, good.preserved, good.changed)
    if roll < 0.22:
        return RewriteRow(good.input, good.rule_id, good.position, good.output, good.input_hash,
                          good.output_hash, good.preserved[::-1], ("word_length", "writhe"))
    if roll < 0.28:
        return RewriteRow(good.input, good.rule_id, good.position, good.output, "ab" * 4,
                          "cd" * 4, good.preserved, good.changed)
    if roll < 0.32:
        return RewriteRow(good.input, good.rule_id, (good.position or 0) + 1, good.output,
                          good.input_hash, good.output_hash, good.preserved, good.changed)
    return good


def build_random_ledger(db, rng, n_braids=40, n_rewrites=60):
    m = Mirror(db)
    for _ in range(n_braids):
        row = random_braid_row(rng)
        if row.key not in m.braid_id:
            m.braid(row)
    for _ in range(n_rewrites):
        m.rewrite(random_rewrite(rng, m))
    return m


def test_braid_hash_and_rule_application_agree_with_python(db):
    rng = random.Random(1)
    for _ in range(60):
        n = rng.randint(1, 5)
        w = random_word(rng, n, rng.randint(0, 6)) if n > 1 else []
        b = Braid.from_short_form(n, w)
        assert db.one("SELECT braid_word_hash(%s, %s::int[])", n, w) == braid_hash(b)
        for rule in ALL_RULES:
            matches = set(find_matches(b, rule))
            for k in range(-1, len(w) + 1):
                got = db.one("SELECT braid_apply_rule(%s::int[], %s, %s)", w, rule.name, k)
                if k in matches:
                    assert got == apply_rule(b, rule, k)[0].short_form()
                else:
                    assert got is None


def test_random_braids_and_rewrites_match_reference(db):
    seen = Counter()
    for seed in range(12):
        db.q("SAVEPOINT s")
        rng = random.Random(seed)
        m = build_random_ledger(db, rng)
        for bid, row in m.braid_row.items():
            got = rows(db, "SELECT * FROM braid_problems(%s)", bid)
            assert got == braid_problems(row), (seed, row)
            seen.update(r for r, _ in got)
        for rid, row in m.rewrite_row.items():
            got = rows(db, "SELECT * FROM braid_rewrite_problems(%s)", rid)
            assert got == rewrite_problems(row), (seed, row)
            seen.update(r for r, _ in got)
            if not got:
                seen["rewrite_ok"] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("strand_count", "letter", "hash", "input_not_well_formed",
                   "output_not_well_formed", "strand_count_mismatch", "rule_unknown",
                   "not_applicable", "output_mismatch", "declaration_mismatch",
                   "input_hash_mismatch", "output_hash_mismatch", "rewrite_ok"):
        assert seen[reason] > 0, reason


def test_random_derivations_match_reference(db):
    seen = Counter()
    for seed in range(12):
        db.q("SAVEPOINT s")
        rng = random.Random(100 + seed)
        m = build_random_ledger(db, rng)
        by_start = {}
        for rid, r in m.rewrite_row.items():
            by_start.setdefault((r.input.key, True), []).append(rid)
            by_start.setdefault((r.output.key, False), []).append(rid)
        for _ in range(30):
            src_id = rng.choice(list(m.braid_row))
            src = m.braid_row[src_id]
            steps, dirs = [], []
            cur = src.key
            for _ in range(rng.randint(0, 5)):
                if rng.random() < 0.8:
                    cands = [(rid, d) for d in (True, False) for rid in by_start.get((cur, d), [])]
                    if not cands:
                        break
                    rid, d = rng.choice(cands)
                else:
                    rid, d = rng.choice(m.rewrite_ids), rng.random() < 0.5
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = (r.output if d else r.input).key
            py_steps = [m.rewrite_row[s] for s in steps]
            roll = rng.random()
            if roll < 0.08 and steps:
                k = rng.randrange(len(steps))
                steps[k] = db.one("SELECT gen_random_uuid()")
                py_steps[k] = None
            elif roll < 0.12:
                dirs = dirs + [True]
            if rng.random() < 0.7 and cur in m.braid_id:
                tgt_id = m.braid_id[cur]
            else:
                tgt_id = rng.choice(list(m.braid_row))
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id",
                src_id, tgt_id, steps, dirs)
            got = rows(db, "SELECT * FROM braid_derivation_problems(%s)", did)
            want = derivation_problems(src, m.braid_row[tgt_id], py_steps, dirs)
            assert got == want, (seed, got, want)
            seen.update(r for r, _ in got)
            if not got:
                seen["derivation_ok"] += 1
                assert db.one("SELECT braid_equality_certified(%s, %s)", src_id, tgt_id)
                assert db.one("SELECT braid_equality_certified(%s, %s)", tgt_id, src_id)
                if not braid_problems(src):
                    t = m.braid_row[tgt_id]
                    assert braid_group_equal(Braid.from_short_form(src.strand_count, list(src.word)),
                                             Braid.from_short_form(t.strand_count, list(t.word)))
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("steps_shape", "step_unknown", "step_invalid", "step_disconnected",
                   "target_mismatch", "derivation_ok"):
        assert seen[reason] > 0, reason


def test_writers_build_a_certified_derivation(db):
    """σ1σ2σ1 σ1⁻¹  →  σ2σ1σ2 σ1⁻¹, then back via an inserted cancelling pair."""
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1, -1])")
    assert db.one("SELECT register_braid(3, ARRAY[1, 2, 1, -1])") == a    # content addressed
    r1 = db.one("SELECT record_braid_rewrite(%s, 'R01', 2)", a)          # → σ1σ2
    b = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r1)
    assert db.one("SELECT word FROM braid_word WHERE id = %s", b) == [1, 2]
    c = db.one("SELECT register_braid(3, ARRAY[2, 1, 2, -2])")
    r2 = db.one("SELECT record_braid_rewrite(%s, 'R01', 2)", c)          # σ2σ1σ2σ2⁻¹ → σ2σ1
    d = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r2)
    assert db.one("SELECT braid_equality_certified(%s, %s)", a, d) is False
    # σ1σ2 ← σ1σ2σ1σ1⁻¹ (backwards r1) ... connect a → b, nothing links b to d yet
    der = db.one("SELECT record_braid_derivation(%s, ARRAY[%s]::uuid[], ARRAY[true])", a, r1)
    assert db.one("SELECT target_braid_id FROM braid_derivation WHERE id = %s", der) == b
    assert db.one("SELECT braid_equality_certified(%s, %s)", b, a)
    # A full certificate σ1σ2σ1 = σ2σ1σ2 via one R03 step, used backwards from the right side.
    x = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    r3 = db.one("SELECT record_braid_rewrite(%s, 'R03', 0)", x)
    y = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r3)
    db.one("SELECT record_braid_derivation(%s, ARRAY[%s]::uuid[], ARRAY[false])", y, r3)
    assert db.one("SELECT braid_equality_certified(%s, %s)", x, y)
    assert db.one("SELECT count(*) FROM invariant_violation WHERE module = 'braid_ledger'") == 0


@pytest.mark.parametrize("sql, args, message", [
    ("SELECT register_braid(3, ARRAY[1, 3])", (), "letter"),
    ("SELECT register_braid(0, ARRAY[]::int[])", (), "strand_count"),
])
def test_register_braid_refuses(db, sql, args, message):
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match=message):
        db.q(sql, *args)
    db.q("ROLLBACK TO SAVEPOINT s")


def test_record_writers_refuse(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    for sql, msg in [("SELECT record_braid_rewrite(%s, 'R01', 0)", "not_applicable"),
                     ("SELECT record_braid_rewrite(%s, 'R07', 0)", "rule_unknown"),
                     ("SELECT record_braid_rewrite(%s, 'R03', 1)", "not_applicable")]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, a)
        db.q("ROLLBACK TO SAVEPOINT s")
    r = db.one("SELECT record_braid_rewrite(%s, 'R03', 0)", a)
    for steps, dirs, msg in [([r], [False], "step_disconnected"),
                             ([r], [], "steps_shape")]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q("SELECT record_braid_derivation(%s, %s::uuid[], %s::boolean[])", a, steps, dirs)
        db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_mode_rejects_a_bad_rewrite_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    insert = ("INSERT INTO braid_rewrite (input_braid_id, rule_id, position, output_braid_id, "
              "input_hash, output_hash, preserved, changed) "
              "VALUES (%s, 'R03', 0, %s, %s, %s, braid_rule_preserved('R03'), braid_rule_changed('R03'))")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not well formed"):
        db.q(insert, a, a, h, h)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, a, a, h, h)
    got = db.q("SELECT violation_type, details->>'table' FROM invariant_violation "
               "WHERE module = 'braid_ledger'")
    assert got == [("output_mismatch", "braid_rewrite")]
    assert db.one("SELECT count(*) FROM v_all_violations WHERE module = 'invariant' "
                  "AND violation_type = 'output_mismatch'") == 1


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R03', 0)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_rewrite SET position = 1 WHERE id = %s",
                "DELETE FROM braid_rewrite WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, r)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="append-only"):
        db.q("UPDATE braid_word SET word = ARRAY[2, 1, 2] WHERE id = %s", a)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q("UPDATE braid_word SET name = 'renamed' WHERE id = %s", a)
    assert db.q("SELECT violation_type, details->>'op' FROM invariant_violation "
                "WHERE module = 'braid_ledger'") == [("log_mutation", "UPDATE")]


def test_batch_check_finds_a_tampered_word(db):
    """A word changed after the fact (permissive mode) is caught by the batch check."""
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R03', 0)", a)
    der = db.one("SELECT record_braid_derivation(%s, ARRAY[%s]::uuid[], ARRAY[true])", a, r)
    b = db.one("SELECT target_braid_id FROM braid_derivation WHERE id = %s", der)
    assert db.one("SELECT braid_equality_certified(%s, %s)", a, b)
    db.q("UPDATE braid_word SET word = ARRAY[2, 2, 2] WHERE id = %s", b)
    db.q("DELETE FROM invariant_violation")
    assert db.one("SELECT check_braid_ledger()") > 0
    got = Counter(db.q("SELECT violation_type, details->>'table' FROM invariant_violation "
                       "WHERE module = 'braid_ledger'"))
    assert got[("hash", "braid_word")] == 1
    assert got[("output_not_well_formed", "braid_rewrite")] == 1
    assert got[("step_invalid", "braid_derivation")] == 1
    assert not db.one("SELECT braid_equality_certified(%s, %s)", a, b)
    db.q("SELECT run_phase2_batch_checks()")


def test_migration_is_reapplicable(db):
    with db.conn.cursor() as cur:
        cur.execute(MIGRATION.read_text())
    a = db.one("SELECT register_braid(4, ARRAY[1, 3, -1])")
    assert db.one("SELECT record_braid_rewrite(%s, 'R02', 0)", a)
