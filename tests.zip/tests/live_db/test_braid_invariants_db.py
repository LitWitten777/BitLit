"""Migration 020 (braid invariant certificates) on a real PostgreSQL.

The reference is ``qbx_ir.invariant_ledger``: on random data — including
certificates of malformed braids and certificates with wrong hashes,
permutations, writhes, components and linking numbers — the database reports
exactly the problems the Python code reports, with the same details, in the
same order.  The transport check (certificates agree along accepted rewrites
and derivations) and the inequality certificates are compared too.

Formal backing: ``Formal/BraidInvariantCert.lean`` — ``cert_eq_of_eval_eq``,
``linkTotal_eq_of_eval_eq`` (every certificate field is a braid invariant) and
``eval_ne_of_cert_ne`` (different certificates prove different braids).
"""

from __future__ import annotations

import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.invariant_ledger import (
    CertRow,
    certificate_problems,
    differences,
    invariant_values,
    transport_problems,
)
from qbx_ir.ledger import BraidRow, braid_problems, derivation_problems, rewrite_problems
from tests.live_db.test_braid_ledger_db import build_random_ledger, random_word

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "020_braid_invariants.sql"


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def test_values_agree_with_python(db):
    rng = random.Random(3)
    for _ in range(150):
        n = rng.randint(1, 6)
        w = random_word(rng, n, rng.randint(0, 10)) if n > 1 else []
        got = db.q("SELECT * FROM braid_invariant_values(%s, %s::int[])", n, w)[0]
        v = invariant_values(n, w)
        assert got == (list(v.permutation), v.writhe, list(v.components), list(v.linking)), (n, w)


def random_cert(rng, braid: BraidRow) -> CertRow:
    """A certificate for ``braid``: usually the right one, sometimes tampered with."""
    if braid_problems(braid):
        n = max(braid.strand_count, 1)
        return CertRow(braid, braid.braid_hash, tuple(range(1, n + 1)), 0, (0,) * n, ())
    good = CertRow.of(braid)
    roll = rng.random()
    n = braid.strand_count
    if roll < 0.08:
        return CertRow(braid, "f" * 8, good.permutation, good.writhe, good.components, good.linking)
    if roll < 0.16 and n > 1:
        perm = list(good.permutation)
        perm[0], perm[1] = perm[1], perm[0]
        return CertRow(braid, good.braid_hash, tuple(perm), good.writhe, good.components, good.linking)
    if roll < 0.24:
        return CertRow(braid, good.braid_hash, good.permutation, good.writhe + rng.choice([-2, 1, 2]),
                       good.components, good.linking)
    if roll < 0.30:
        return CertRow(braid, good.braid_hash, good.permutation, good.writhe,
                       tuple(reversed(good.components)) + (0,), good.linking)
    if roll < 0.38:
        return CertRow(braid, good.braid_hash, good.permutation, good.writhe, good.components,
                       good.linking + (1,))
    return good


def insert_cert(db, bid, c: CertRow):
    return db.one(
        "INSERT INTO braid_invariant (braid_id, braid_hash, permutation, writhe, components, linking) "
        "VALUES (%s, %s, %s::int[], %s, %s::int[], %s::int[]) RETURNING id",
        bid, c.braid_hash, list(c.permutation), c.writhe, list(c.components), list(c.linking))


def test_random_certificates_transport_and_inequality_match_reference(db):
    seen = Counter()
    for seed in range(10):
        db.q("SAVEPOINT s")
        rng = random.Random(200 + seed)
        m = build_random_ledger(db, rng)
        certs = {}
        for bid, braid in m.braid_row.items():
            if rng.random() < 0.85:
                c = random_cert(rng, braid)
                cid = insert_cert(db, bid, c)
                certs[bid] = c
                got = rows(db, "SELECT * FROM braid_invariant_problems(%s)", cid)
                assert got == certificate_problems(c), (seed, c)
                seen.update(r for r, _ in got)
                if not got:
                    seen["certificate_ok"] += 1
        ids = list(m.braid_row)
        # Inequality certificates on random pairs.
        for _ in range(60):
            a, b = rng.choice(ids), rng.choice(ids)
            got = db.one("SELECT braid_invariant_differences(%s, %s)", a, b)
            want = differences(certs.get(a), certs.get(b))
            assert got == want, (seed, got, want)
            assert db.one("SELECT braid_inequality_certified(%s, %s)", a, b) == bool(want)
            if want:
                seen["inequality_certified"] += 1
                ra, rb = m.braid_row[a], m.braid_row[b]
                assert not braid_group_equal(Braid.from_short_form(ra.strand_count, list(ra.word)),
                                             Braid.from_short_form(rb.strand_count, list(rb.word)))
        # Transport along every rewrite.
        for rid, r in m.rewrite_row.items():
            ok = not rewrite_problems(r)
            got = rows(db, "SELECT * FROM braid_rewrite_transport_problems(%s)", rid)
            want = transport_problems(ok, certs.get(m.braid_id[r.input.key]),
                                      certs.get(m.braid_id[r.output.key]))
            assert got == want == [], (seed, got, want)
            if ok and differences(certs.get(m.braid_id[r.input.key]),
                                  certs.get(m.braid_id[r.output.key])) == []:
                seen["transport_checked"] += 1
        # Transport along random derivations: an accepted derivation with two
        # valid certificates never reports a problem (Lean: cert_eq_of_eval_eq).
        for _ in range(20):
            src = rng.choice(ids)
            steps, dirs, cur = [], [], src
            for _ in range(rng.randint(0, 4)):
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = m.braid_id[(r.output if d else r.input).key]
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, cur, steps, dirs)
            accepted = not derivation_problems(m.braid_row[src], m.braid_row[cur],
                                               [m.rewrite_row[s] for s in steps], dirs)
            got = rows(db, "SELECT * FROM braid_derivation_transport_problems(%s)", did)
            assert got == transport_problems(accepted, certs.get(src), certs.get(cur)) == []
            if accepted and differences(certs.get(src), certs.get(cur)) == []:
                seen["derivation_transport_checked"] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("braid_not_well_formed", "braid_hash_mismatch", "permutation_mismatch",
                   "writhe_mismatch", "components_mismatch", "linking_mismatch",
                   "certificate_ok", "inequality_certified", "transport_checked",
                   "derivation_transport_checked"):
        assert seen[reason] > 0, reason


def test_transport_check_catches_an_inconsistent_ledger(db):
    """If a certified braid is changed after the fact (permissive mode), its certificate
    stops being valid; a tampered certificate of the other end makes the transport fail."""
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R03', 0)", a)
    b = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r)
    ca = db.one("SELECT certify_braid_invariants(%s)", a)
    cb = db.one("SELECT certify_braid_invariants(%s)", b)
    assert db.one("SELECT certify_braid_invariants(%s)", a) == ca      # one per braid
    assert db.one("SELECT braid_invariant_differences(%s, %s)", a, b) == []
    assert db.one("SELECT check_braid_invariants()") == 0
    # Tamper with b's certificate *and* make it look valid again is impossible: any
    # change of a field is a problem of the certificate itself.
    db.q("UPDATE braid_invariant SET writhe = 1 WHERE id = %s", cb)
    db.q("DELETE FROM invariant_violation")
    assert db.one("SELECT check_braid_invariants()") == 1
    assert db.q("SELECT violation_type, details->>'table' FROM invariant_violation "
                "WHERE module = 'braid_invariants'") == [("writhe_mismatch", "braid_invariant")]
    assert db.one("SELECT braid_invariant_differences(%s, %s)", a, b) is None
    assert ca


def test_writer_and_inequality(db):
    """σ1²σ2⁻² and ε in B_3 have the same permutation and writhe; the linking numbers of
    their closures certify that they differ (Lean: crossings_detect_more)."""
    x = db.one("SELECT register_braid(3, ARRAY[1, 1, -2, -2])")
    e = db.one("SELECT register_braid(3, ARRAY[]::int[])")
    assert db.one("SELECT braid_inequality_certified(%s, %s)", x, e) is False   # no certificates
    db.one("SELECT certify_braid_invariants(%s)", x)
    db.one("SELECT certify_braid_invariants(%s)", e)
    assert db.one("SELECT braid_invariant_differences(%s, %s)", x, e) == ["linking"]
    assert db.one("SELECT braid_inequality_certified(%s, %s)", x, e)
    assert db.one("SELECT braid_inequality_certified(%s, %s)", x, x) is False
    assert db.q("SELECT permutation, writhe, components, linking FROM braid_invariant "
                "WHERE braid_id = %s", x) == [([1, 2, 3], 0, [0, 1, 2], [1, 0, -1])]
    y = db.one("SELECT register_braid(4, ARRAY[1, 1])")
    db.one("SELECT certify_braid_invariants(%s)", y)
    assert db.one("SELECT braid_invariant_differences(%s, %s)", x, y) is None    # B_3 vs B_4
    assert db.one("SELECT count(*) FROM invariant_violation WHERE module = 'braid_invariants'") == 0


def test_certify_refuses_a_malformed_braid(db):
    db.q("INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (3, ARRAY[1, 7], 'h')")
    bid = db.one("SELECT id FROM braid_word WHERE braid_hash = 'h'")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="braid_not_well_formed"):
        db.q("SELECT certify_braid_invariants(%s)", bid)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="unknown braid"):
        db.q("SELECT certify_braid_invariants(gen_random_uuid())")
    db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_mode_rejects_a_bad_certificate_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(2, ARRAY[1, 1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    insert = ("INSERT INTO braid_invariant (braid_id, braid_hash, permutation, writhe, components, "
              "linking) VALUES (%s, %s, ARRAY[1, 2], 2, ARRAY[0, 1], ARRAY[0])")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q(insert, a, h)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, a, h)
    got = db.q("SELECT violation_type, details FROM invariant_violation "
               "WHERE module = 'braid_invariants'")
    assert got == [("linking_mismatch", {"recorded": [0], "expected": [1], "table": "braid_invariant"})]


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    c = db.one("SELECT certify_braid_invariants(%s)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_invariant SET writhe = 5 WHERE id = %s",
                "DELETE FROM braid_invariant WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, c)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q("DELETE FROM braid_invariant WHERE id = %s", c)
    assert db.q("SELECT violation_type, details->>'op' FROM invariant_violation "
                "WHERE module = 'braid_invariants'") == [("log_mutation", "DELETE")]


def test_phase2_batch_checks_include_the_certificates(db):
    a = db.one("SELECT register_braid(3, ARRAY[2, 1])")
    c = db.one("SELECT certify_braid_invariants(%s)", a)
    db.q("UPDATE braid_invariant SET components = ARRAY[0, 1, 2] WHERE id = %s", c)
    db.q("DELETE FROM invariant_violation")
    db.q("SELECT run_phase2_batch_checks()")
    assert db.q("SELECT violation_type FROM invariant_violation "
                "WHERE module = 'braid_invariants'") == [("components_mismatch",)]


def test_migration_is_reapplicable(db):
    with db.conn.cursor() as cur:
        cur.execute(MIGRATION.read_text())
    a = db.one("SELECT register_braid(4, ARRAY[1, 3, -1])")
    assert db.one("SELECT certify_braid_invariants(%s)", a)
