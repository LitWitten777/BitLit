"""Live-database tests for migration 005 (adjunction engine).

Fixture: the indiscrete category I on objects P, Q with the isomorphisms
p: P → Q and q: Q → P (q ∘ p = id_P, p ∘ q = id_Q).  With F: I → I constant at
P and G = Id_I there is an adjunction F ⊣ G with

    unit    η: Id ⇒ G∘F = F      η_P = id_P,  η_Q = q
    counit  ε: F∘G = F ⇒ Id      ε_P = id_P,  ε_Q = p

The right triangle at Q is G(ε_Q) ∘ η_Q = p ∘ q = id_Q — a genuine
composite.  The original migration looked up η ∘ G(ε) = q ∘ p = id_P instead,
which is not id_Q, so it flagged this genuine adjunction.
"""

import pytest

psycopg2 = pytest.importorskip("psycopg2")


def _indiscrete(db, cat="I"):
    db.category(cat)
    db.obj(cat, "P")
    db.obj(cat, "Q")
    db.mor("p", "P", "Q")
    db.mor("q", "Q", "P")
    db.comp("q", "p", "id_P")    # q ∘ p = id_P
    db.comp("p", "q", "id_Q")    # p ∘ q = id_Q


def _functors(db):
    """Id_I, and F: I → I constant at P (every morphism ↦ id_P).

    F sends every composite to a composite with identity factors; the functor
    trigger of migration 002 applies the unit laws (amendment A-002), so the
    insertion order no longer matters.
    """
    ms = db.morphisms["I"]
    db.functor("Id", "I", "I", {"P": "P", "Q": "Q"}, {m: m for m in ms})
    db.functor("F", "I", "I", {"P": "P", "Q": "P"}, {m: "id_P" for m in ms})


def _adjunction(db, unit=None, counit=None):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", unit or {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", counit or {"P": "id_P", "Q": "p"})
    return db.adjunction("F⊣Id", "F", "Id", "eta", "eps")


def test_genuine_adjunction_has_no_violation(db):
    _adjunction(db)
    assert db.adjunction_laws("F⊣Id") == []
    assert db.naturality_violations("eta") == []
    assert db.naturality_violations("eps") == []
    db.check_adjunction("F⊣Id")          # batch re-check is also clean
    assert db.adjunction_laws("F⊣Id") == []


def test_genuine_adjunction_passes_in_strict_mode(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.set_mode("strict")
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert db.adjunction_laws("F⊣Id") == []


def test_right_triangle_violation(db):
    _indiscrete(db)
    db.mor("q2", "Q", "P")
    db.mor("e", "Q", "Q")
    db.comp("p", "q2", "e")      # p ∘ q2 = e ≠ id_Q
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q2"})
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert db.adjunction_laws("F⊣Id") == ["triangle_right"]


def test_left_triangle_violation(db):
    _indiscrete(db)
    db.mor("e", "P", "P")
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "e", "Q": "p"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    # left triangle at X = P and X = Q: ε_{F(X)} ∘ F(η_X) = e ∘ id_P = e;
    # right triangle at Y = P: G(ε_P) ∘ η_P = e ∘ id_P = e.
    assert db.adjunction_laws("F⊣Id") == ["triangle_left", "triangle_left", "triangle_right"]


def test_missing_composite_is_a_violation(db):
    _indiscrete(db)
    db.q("DELETE FROM composition WHERE result_id = %s", db.ids["id_Q"])
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert db.adjunction_laws("F⊣Id") == ["triangle_right_composite_missing"]


def test_missing_component_is_a_violation(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert db.adjunction_laws("F⊣Id") == ["counit_component_missing", "triangle_right_missing"]


def test_component_typing_violation(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "id_Q"})   # η_Q must be Q → P
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert "unit_component_typing" in db.adjunction_laws("F⊣Id")


def test_unit_functor_mismatch(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "Id", {"P": "id_P", "Q": "id_Q"})  # target must be G∘F = F
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    laws = db.adjunction_laws("F⊣Id")
    assert laws.count("unit_functor_mismatch") == 4   # object Q, and id_Q, p, q
    assert "unit_component_typing" in laws            # η_Q = id_Q is not Q → P


def test_category_typing_violation(db):
    _indiscrete(db)
    _functors(db)
    db.category("J")
    db.obj("J", "Z")
    db.functor("H", "J", "J", {"Z": "Z"}, {"id_Z": "id_Z"})
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P", "Q": "p"})
    db.adjunction("F⊣H", "F", "H", "eta", "eps")          # G must go I → I
    assert db.adjunction_laws("F⊣H") == ["adjunction_typing"]


def test_strict_mode_rejects_violation(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P"})
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="Adjunction law"):
        db.adjunction("F⊣Id", "F", "Id", "eta", "eps")


def test_late_component_is_caught_by_batch_check(db):
    _indiscrete(db)
    _functors(db)
    db.nt("eta", "Id", "F", {"P": "id_P", "Q": "q"})
    db.nt("eps", "F", "Id", {"P": "id_P"})
    db.adjunction("F⊣Id", "F", "Id", "eta", "eps")
    assert db.adjunction_laws("F⊣Id") != []
    db.component("eps", "Q", "p")
    db.clear_adjunction_violations("F⊣Id")
    db.q("SELECT run_all_batch_checks()")
    assert db.adjunction_laws("F⊣Id") == []


# ---------------------------------------------------------------------------
# Random instances: the database reports what the reference reports
# (qbx.categorical.Adjunction; registry R-015)
# ---------------------------------------------------------------------------
import random  # noqa: E402
from collections import Counter  # noqa: E402

from qbx.categorical import Adjunction, NaturalTransformation  # noqa: E402
from qbx.core.enforced_functor import Category, EnforcedFunctor, EnforcementMode  # noqa: E402

PERMISSIVE = EnforcementMode.PERMISSIVE


class _Table(EnforcedFunctor):
    def __init__(self, fid, source, target, objs, mors):
        super().__init__(fid, fid, source, target, mode=PERMISSIVE)
        self.object_map.update(objs)
        self.morphism_map.update(mors)


def _random_category(rng, p, tag):
    objs = [f"{p}{tag}{i}" for i in range(rng.randint(1, 3))]
    mors = {f"{p}{tag}m{i}": (rng.choice(objs), rng.choice(objs)) for i in range(rng.randint(0, 4))}
    allm = dict(mors)
    allm.update({f"id_{o}": (o, o) for o in objs})
    comps = {}
    names = sorted(allm)
    for _ in range(rng.randint(0, 10)):
        f, g = rng.choice(names), rng.choice(names)
        if f.startswith("id_") or g.startswith("id_"):
            continue
        if allm[f][1] != allm[g][0] or (f, g) in comps:
            continue
        cands = [h for h, st in sorted(allm.items()) if st == (allm[f][0], allm[g][1])]
        if cands:
            comps[(f, g)] = rng.choice(cands)
    return {"objs": objs, "mors": mors, "all": allm, "comps": comps}


def _random_map(rng, src, tgt, typed_bias=0.8):
    objs = {o: rng.choice(tgt["objs"]) for o in src["objs"] if rng.random() < 0.95}
    mors = {}
    for m, (s, t) in sorted(src["all"].items()):
        r = rng.random()
        if r < 0.05:
            continue
        if m.startswith("id_") and s in objs and r < 0.85:
            mors[m] = f"id_{objs[s]}"
            continue
        typed = [n for n, st in sorted(tgt["all"].items())
                 if s in objs and t in objs and st == (objs[s], objs[t])]
        mors[m] = rng.choice(typed) if typed and r < typed_bias else rng.choice(sorted(tgt["all"]))
    return objs, mors


def _compose_maps(first, second):
    o = {k: second[0][v] for k, v in first[0].items() if v in second[0]}
    m = {k: second[1][v] for k, v in first[1].items() if v in second[1]}
    return o, m


def _perturb(rng, fmap, src, tgt):
    objs, mors = dict(fmap[0]), dict(fmap[1])
    if rng.random() < 0.75:
        return objs, mors
    if objs and rng.random() < 0.5:
        k = rng.choice(sorted(objs))
        objs[k] = rng.choice(tgt["objs"])
    elif mors:
        k = rng.choice(sorted(mors))
        if rng.random() < 0.3:
            del mors[k]
        else:
            mors[k] = rng.choice(sorted(tgt["all"]))
    return objs, mors


def _random_components(rng, cat, src_map, tgt_map):
    comps = {}
    for x in cat["objs"]:
        r = rng.random()
        if r < 0.08:
            continue
        typed = [n for n, st in sorted(cat["all"].items())
                 if st == (src_map[0].get(x), tgt_map[0].get(x))]
        comps[x] = rng.choice(typed) if typed and r < 0.85 else rng.choice(sorted(cat["all"]))
    return comps


def _random_adjunction(rng, p):
    C = _random_category(rng, p, "c")
    D = C if rng.random() < 0.3 else _random_category(rng, p, "d")
    F = _random_map(rng, C, D)
    G = _random_map(rng, D, C)
    idC = ({o: o for o in C["objs"]}, {m: m for m in C["all"]})
    idD = ({o: o for o in D["objs"]}, {m: m for m in D["all"]})
    inst = {"C": C, "D": D, "F": F, "G": G,
            "uF": _perturb(rng, idC, C, C), "uG": _perturb(rng, _compose_maps(F, G), C, C),
            "cF": _perturb(rng, _compose_maps(G, F), D, D), "cG": _perturb(rng, idD, D, D)}
    inst["eta"] = _random_components(rng, C, inst["uF"], inst["uG"])
    inst["eps"] = _random_components(rng, D, inst["cF"], inst["cG"])
    return inst


def _load_category(db, cat, name):
    if name in db.ids:
        return
    db.category(name)
    for o in cat["objs"]:
        db.obj(name, o)
    for m, (s, t) in sorted(cat["mors"].items()):
        db.mor(m, s, t)
    for (f, g), h in sorted(cat["comps"].items()):
        db.comp(g, f, h)


def _model_category(cat, name):
    K = Category(name, name)
    for o in cat["objs"]:
        K.add_object(o, o)
        K.add_identity(o, f"id_{o}")
    for m, (s, t) in cat["mors"].items():
        K.add_morphism(m, s, t)
    for (f, g), h in cat["comps"].items():
        K.add_composition(f, g, h)
    return K


def _adj_keys_db(db, name):
    back = {v: k for k, v in db.ids.items()}
    rows = db.q("SELECT law, object_id, details->>'morphism', left_side FROM adjunction_violation "
                "WHERE adjunction_id = %s", db.ids[name])
    out = Counter()
    for law, obj, mor, left in rows:
        comp = back.get(left) if law in ("triangle_left", "triangle_right") else None
        out[(law, back.get(obj or mor), comp)] += 1
    return out


def _adj_keys_ref(adj):
    out = Counter()
    for v in adj.violations:
        d = v["details"]
        subject = d.get("object", d.get("morphism", d.get("X", d.get("Y"))))
        out[(v["law"], subject, d.get("composite"))] += 1
    return out


def test_adjunction_check_matches_reference(db):
    rng = random.Random(5)
    seen = Counter()
    for i in range(200):
        p = f"r{i}_"
        inst = _random_adjunction(rng, p)
        same = inst["D"] is inst["C"]
        cn, dn = p + "C", (p + "C" if same else p + "D")
        _load_category(db, inst["C"], cn)
        _load_category(db, inst["D"], dn)
        for fname, (s, t) in (("F", (cn, dn)), ("G", (dn, cn)), ("uF", (cn, cn)), ("uG", (cn, cn)),
                              ("cF", (dn, dn)), ("cG", (dn, dn))):
            db.functor(p + fname, s, t, *inst[fname])
        db.nt(p + "eta", p + "uF", p + "uG", inst["eta"])
        db.nt(p + "eps", p + "cF", p + "cG", inst["eps"])
        db.adjunction(p + "adj", p + "F", p + "G", p + "eta", p + "eps")

        KC = _model_category(inst["C"], cn)
        KD = KC if same else _model_category(inst["D"], dn)
        tf = {}
        for fname, (s, t) in (("F", (KC, KD)), ("G", (KD, KC)), ("uF", (KC, KC)), ("uG", (KC, KC)),
                              ("cF", (KD, KD)), ("cG", (KD, KD))):
            tf[fname] = _Table(p + fname, s, t, *inst[fname])
        eta = NaturalTransformation(p + "eta", "eta", tf["uF"], tf["uG"], mode=PERMISSIVE)
        eta.components.update(inst["eta"])
        eps = NaturalTransformation(p + "eps", "eps", tf["cF"], tf["cG"], mode=PERMISSIVE)
        eps.components.update(inst["eps"])
        adj = Adjunction(p + "adj", "adj", tf["F"], tf["G"], eta, eps, mode=PERMISSIVE)
        adj.verify_typing() and (adj.verify_functors(), adj.verify_components(), adj.verify_triangles())
        ref = _adj_keys_ref(adj)
        assert _adj_keys_db(db, p + "adj") == ref, i
        seen.update(k[0] for k in ref)
        seen["clean" if not ref else "dirty"] += 1
    for law in ("unit_functor_mismatch", "counit_functor_mismatch", "unit_component_missing",
                "unit_component_typing", "counit_component_typing", "triangle_left_missing",
                "triangle_right_missing", "triangle_left_composite_missing", "triangle_left",
                "triangle_right", "triangle_right_composite_missing", "clean"):
        assert seen[law] > 0, (law, seen)
