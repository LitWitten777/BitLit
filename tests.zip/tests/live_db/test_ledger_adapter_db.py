"""QBX-IR ↔ ledger adapter (Phase 2 sprint 5) on a real PostgreSQL.

``qbx_ir.ledger_adapter`` writes a braid and its ``Transformation`` trace
through the SQL writers of migration 019, reads it back and verifies it.  Here
the PostgreSQL backend (``qbx.db.braid_ledger.PostgresBraidLedger``) is run
side by side with the in-memory reference backend (``InMemoryBraidLedger``):
on random braids and random traces both accept and refuse exactly the same
writes, hold the same rows, and report the same verification and certificate
problems.

Formal backing: ``Formal/BraidTrace.lean`` — ``normalFormTrace_chainEnd`` (the
derivation written for a ``normal_form_with_trace`` trace is accepted and ends
at the reduced word) and ``normalFormTrace_reduced`` (with enough fuel that
word has no R01 or sorting-R02 redex).
"""

from __future__ import annotations

import random
from dataclasses import replace

import pytest

from qbx.db.braid_ledger import PostgresBraidLedger
from qbx_ir import Braid
from qbx_ir.algebra.rewriting import normal_form_with_trace
from qbx_ir.ledger_adapter import (
    InMemoryBraidLedger,
    LedgerRefusal,
    TraceRecord,
    certificate_problems_of_trace,
    read_trace,
    round_trip,
    trace_problems,
    verify_trace,
    write_trace,
)
from tests.qbx_ir.test_ledger_adapter import random_braid, random_rewrite_trace


def shape(ledger, record):
    """Backend-independent view of what a written trace holds."""
    src, steps, tgt = read_trace(ledger, record.derivation_id)
    return (src.strand_count, src.short_form(), [(t, fwd) for t, fwd in steps],
            tgt.short_form(), len(record.rewrite_ids))


def test_round_trip_matches_reference(db):
    pg = PostgresBraidLedger(db.conn)
    rng = random.Random(17)
    for _ in range(40):
        b = random_braid(rng, n_max=5, len_max=10)
        mem = InMemoryBraidLedger()
        r_pg, p_pg = round_trip(pg, b, certify=True)
        r_mem, p_mem = round_trip(mem, b, certify=True)
        assert p_pg == p_mem == []
        assert shape(pg, r_pg) == shape(mem, r_mem)
        assert pg.derivation_problems(r_pg.derivation_id) == []
        assert pg.invariant_differences(r_pg.source_id, r_pg.target_id) == []
        assert pg.normal_forms_equal(r_pg.source_id, r_pg.target_id) is True


def test_arbitrary_traces_match_reference(db):
    pg = PostgresBraidLedger(db.conn)
    rng = random.Random(29)
    for _ in range(40):
        b = random_braid(rng, n_max=6, len_max=8)
        _, trace = random_rewrite_trace(rng, b, rng.randint(0, 6))
        mem = InMemoryBraidLedger()
        r_pg, r_mem = write_trace(pg, b, trace), write_trace(mem, b, trace)
        assert verify_trace(pg, r_pg, b, trace) == verify_trace(mem, r_mem, b, trace) == []
        assert shape(pg, r_pg) == shape(mem, r_mem)


def test_writers_accept_and_refuse_alike(db):
    """Random writer calls: PostgreSQL refuses exactly when the reference does,
    and an accepted rewrite records the same row."""
    pg = PostgresBraidLedger(db.conn)
    mem = InMemoryBraidLedger()
    rng = random.Random(41)
    ids = []   # (pg id, mem id)
    for _ in range(150):
        n = rng.randint(0, 5)
        word = [rng.choice([1, -1]) * rng.randint(0, max(n, 1)) for _ in range(rng.randint(0, 6))]
        outcomes = []
        for L in (pg, mem):
            try:
                outcomes.append(L.register_braid(n, word))
            except LedgerRefusal:
                outcomes.append(None)
        assert (outcomes[0] is None) == (outcomes[1] is None), (n, word)
        if outcomes[0] is not None:
            ids.append(tuple(outcomes))
    assert ids
    rewrites = []
    for _ in range(300):
        bp, bm = rng.choice(ids)
        rule = rng.choice(["R01", "R02", "R03", "R04"])
        pos = rng.randint(-1, 6)
        try:
            rp = pg.record_rewrite(bp, rule, pos)
        except LedgerRefusal:
            rp = None
        try:
            rm = mem.record_rewrite(bm, rule, pos)
        except LedgerRefusal:
            rm = None
        assert (rp is None) == (rm is None), (rule, pos)
        if rp is not None:
            assert pg.rewrite_row(rp) == mem.rewrite_row(rm)
            out_p, out_m = pg.rewrite_ends(rp)[1], mem.rewrite_ends(rm)[1]
            ids.append((out_p, out_m))
            rewrites.append((rp, rm))
    assert rewrites
    for _ in range(100):
        k = rng.randint(0, 3)
        chosen = [rng.choice(rewrites) for _ in range(k)]
        dirs = [rng.random() < 0.7 for _ in range(k)]
        src = rng.choice(ids)
        res = []
        for side, L in enumerate((pg, mem)):
            try:
                did = L.record_derivation(src[side], [c[side] for c in chosen], dirs)
                d = L.derivation(did)
                res.append((L.braid_row(d.target_id), len(d.steps)))
            except LedgerRefusal:
                res.append(None)
        assert res[0] == res[1]


def test_refusal_keeps_transaction_usable(db):
    pg = PostgresBraidLedger(db.conn)
    bid = pg.register_braid(3, [1, 2])
    with pytest.raises(LedgerRefusal):
        pg.record_rewrite(bid, "R01", 0)
    with pytest.raises(LedgerRefusal):
        pg.register_braid(3, [4])
    assert pg.register_braid(3, [1, 2]) == bid


def test_preflight_refuses_what_the_database_refuses(db):
    pg = PostgresBraidLedger(db.conn)
    b = Braid.from_short_form(4, [3, 1, -1, 2, 1, -3, 3])
    _, trace = normal_form_with_trace(b)
    bad = [replace(trace[0], rule_id="R03")] + trace[1:]
    assert trace_problems(b, bad)
    with pytest.raises(ValueError):
        write_trace(pg, b, bad)
    # Sent straight to the writer, the database refuses the same step.
    bid = pg.register_braid(4, b.short_form())
    with pytest.raises(LedgerRefusal):
        pg.record_rewrite(bid, "R03", trace[0].position)


def test_tampered_derivation_detected_alike(db):
    """A derivation row inserted around the writer, with the wrong target, is
    reported identically by both backends."""
    pg = PostgresBraidLedger(db.conn)
    mem = InMemoryBraidLedger()
    b = Braid.from_short_form(4, [3, 1, -1, 2, 1, -3, 3])
    _, trace = normal_form_with_trace(b)
    r_pg, r_mem = write_trace(pg, b, trace), write_trace(mem, b, trace)
    bad_pg = db.one(
        "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
        "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id",
        r_pg.source_id, r_pg.source_id, list(r_pg.rewrite_ids), [True] * len(trace))
    from qbx_ir.ledger_adapter import DerivationRecord
    bad_mem = "tampered"
    mem.derivations[bad_mem] = DerivationRecord(r_mem.source_id, r_mem.source_id,
                                                r_mem.rewrite_ids, (True,) * len(trace))
    t_pg = TraceRecord(r_pg.source_id, r_pg.rewrite_ids, str(bad_pg), r_pg.target_id)
    t_mem = TraceRecord(r_mem.source_id, r_mem.rewrite_ids, bad_mem, r_mem.target_id)
    p_pg, p_mem = verify_trace(pg, t_pg, b, trace), verify_trace(mem, t_mem, b, trace)
    assert p_pg == p_mem
    assert [r for r, _ in p_pg] == ["target_mismatch", "derivation_problem"]
    # The genuine derivation still certifies the two ends.
    assert pg.equality_certified(r_pg.source_id, r_pg.target_id)


def test_certificates_missing_then_agree(db):
    pg = PostgresBraidLedger(db.conn)
    mem = InMemoryBraidLedger()
    b = Braid.from_short_form(5, [4, 2, -2, 3, 1, -4, 4, 2, 1])
    _, trace = normal_form_with_trace(b)
    r_pg, r_mem = write_trace(pg, b, trace), write_trace(mem, b, trace)
    before = certificate_problems_of_trace(pg, r_pg)
    assert before == certificate_problems_of_trace(mem, r_mem)
    assert [r for r, _ in before] == ["invariant_missing", "normal_form_missing",
                                      "representation_missing"]
    for L, r in ((pg, r_pg), (mem, r_mem)):
        L.certify(r.source_id)
        L.certify(r.target_id)
    assert certificate_problems_of_trace(pg, r_pg) == certificate_problems_of_trace(mem, r_mem) == []


def test_batch_checks_clean_after_adapter_writes(db):
    pg = PostgresBraidLedger(db.conn)
    rng = random.Random(53)
    for _ in range(10):
        round_trip(pg, random_braid(rng, n_max=4, len_max=8), certify=True)
    db.q("SELECT run_phase2_batch_checks()")
    modules = ("braid_ledger", "braid_invariants", "braid_normal_forms", "braid_representations")
    n = db.one("SELECT count(*) FROM invariant_violation WHERE module = ANY(%s)", list(modules))
    assert n == 0
