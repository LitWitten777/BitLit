"""Migration 015 (governance modalities: modalities, policies, assignments,
frames and policy checks, approval workflows and tokens, the audit hash chain)
on a real PostgreSQL.

The reference is ``qbx.governance``: on random inputs the database reports
exactly the problems the Python code reports, with the same details.

Formal backing: ``Formal/Modality.lean`` — ``box_subset_self_iff`` /
``box_subset_box_box_iff`` / ``box_subset_dia_iff_serial`` (the frame checks
are the modal axioms T, 4, D), ``result_eq_pass_iff`` (the computed result is
the Kripke semantics), ``holds_dual``, and ``chainHash_injective`` (the newest
record hash commits to the log) are used as oracles in ``tests/test_governance.py``
and below.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from datetime import timedelta
from pathlib import Path

import psycopg2
import pytest

from qbx.governance.approval import is_approved, token_problems, workflow_problems, workflow_roles
from qbx.governance.audit import GENESIS, chain_problems, record_hash
from qbx.governance.modality import SEED, modality_problems, modality_table_problems
from qbx.governance.policy import (
    accessible_from,
    assignment_problems,
    check_problems,
    computed_result,
    frame_problems,
    policy_problems,
)
from tests.governance_examples import (
    CONTEXT_NAMES,
    KINDS,
    NAMES,
    T0,
    random_frame,
    random_json,
    random_outcomes,
    random_steps,
    random_text,
    random_time,
    random_timeout,
    random_version,
    random_window,
)
from tests.live_db.test_monad_db import _z2, _z3

LEVELS = ["soft", "hard", "block_and_alert"]


def rows(db, sql, *args):
    return [tuple(r) for r in db.q(sql, *args)]


def srt(problems):
    """Problems logged by one statement share detected_at: compare as multisets."""
    return sorted(problems, key=lambda p: (p[0], json.dumps(p[1], sort_keys=True)))


def violations(db, table=None):
    if table is None:
        return srt(rows(db, "SELECT reason, details FROM governance_violation"))
    return srt(rows(db, "SELECT reason, details FROM governance_violation "
                        "WHERE subject_table = %s", table))


def savepoint_raises(db, match, sql, *args):
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match=match):
        db.q(sql, *args)
    db.q("ROLLBACK TO SAVEPOINT s")


def js(x):
    return json.dumps(x, ensure_ascii=False)


def modality_id(db, name):
    return db.one("SELECT id FROM modality WHERE name = %s", name)


def policy(db, name, modality="□", level="hard"):
    return db.one("SELECT register_policy(%s, 'personal_data', '{}'::jsonb, %s, %s)",
                  name, modality, level)


def frame(db, ctx, rel, frame_name="alethic"):
    for c in ctx:
        if db.one("SELECT id FROM governance_context WHERE name = %s", c) is None:
            db.q("SELECT register_governance_context(%s)", c)
    for a, b in sorted(rel):
        db.q("SELECT register_governance_access(%s, %s, %s)", frame_name, a, b)


# ---------------------------------------------------------------------------
# The bugs of the original migration
# ---------------------------------------------------------------------------
def test_original_bugs_are_refused_or_reported(db):
    savepoint_raises(db, "unknown modality", "SELECT register_policy('p1','write','{}','nope')")
    savepoint_raises(db, "body", "SELECT register_policy('p2','x','42','□')")
    db.q("INSERT INTO policy (name, body, version) VALUES ('p3', '{}', 'banana')")
    db.q("UPDATE modality SET kind = 'possibility' WHERE name = '□'")
    db.q("DELETE FROM modality WHERE name = '?'")
    pid = policy(db, "p4")
    db.q("INSERT INTO policy_modality_assignment (policy_id, modality_id, scope) "
         "VALUES (%s, %s, 'fly')", pid, modality_id(db, "◇"))
    db.q("INSERT INTO policy_check_log (result) VALUES ('pass')")
    db.q("UPDATE policy_check_log SET result = 'fail'")
    db.q("INSERT INTO approval_workflow (name, steps, timeout_days) VALUES ('w', '\"x\"', -3)")
    db.q("INSERT INTO approval_token (workflow_id, approver_role, approved_at, expires_at) "
         "SELECT id, 'nobody', now(), now() - interval '1 day' FROM approval_workflow")
    db.q("SELECT record_audit('a', 'x', NULL, NULL, '{}')")
    db.q("UPDATE audit_record SET actor = 'mallory'")
    reasons = Counter(r for r, _ in violations(db))
    assert reasons["policy_typing"] == 2          # version, modality of p3
    assert reasons["modality_kind"] >= 1 and reasons["modality_missing"] >= 1
    assert reasons["assignment_modality"] == 1 and reasons["assignment_typing"] == 1
    assert reasons["check_typing"] == 3           # policy, context, outcomes
    assert reasons["log_mutation"] == 2
    assert reasons["workflow_typing"] == 2 and reasons["token_typing"] == 3
    assert db.one("SELECT check_audit_chain()") == 1          # the edited record's hash
    assert ("governance",) in rows(db, "SELECT module FROM violation_summary()")


# ---------------------------------------------------------------------------
# Modalities
# ---------------------------------------------------------------------------
def test_seed_is_the_python_seed(db):
    got = rows(db, "SELECT name, kind, frame, structure FROM governance_seed_modalities() "
                   "ORDER BY ordinal")
    assert got == [tuple(s) for s in SEED]
    assert rows(db, "SELECT name, kind FROM modality ORDER BY name COLLATE \"C\"") == \
        sorted((n, k) for n, k, _, _ in SEED)
    assert rows(db, "SELECT * FROM governance_modality_table_problems()") == []


def test_random_modality_tables_agree(db):
    rng = random.Random(1520)
    for _ in range(30):
        db.q("SAVEPOINT t")
        for _ in range(rng.randint(1, 3)):
            act = rng.random()
            name = rng.choice(NAMES)
            if act < 0.4:
                db.q("UPDATE modality SET kind = %s WHERE name = %s", rng.choice(KINDS), name)
            elif act < 0.7:
                db.q("DELETE FROM modality WHERE name = %s", name)
            else:
                db.q("INSERT INTO modality (name, kind) VALUES (%s, %s) ON CONFLICT DO NOTHING",
                     rng.choice(["X", "Ω", "□□", "a"]), rng.choice(KINDS))
        table = rows(db, "SELECT name, kind FROM modality")
        expected = modality_table_problems(table)
        assert rows(db, "SELECT * FROM governance_modality_table_problems()") == expected
        # a statement (even one changing no row) compares the table with the seed
        db.q("DELETE FROM governance_violation")
        db.q("UPDATE modality SET description = description WHERE FALSE")
        assert violations(db, "modality") == srt(expected)
        db.q("ROLLBACK TO SAVEPOINT t")
    db.set_mode("strict")
    savepoint_raises(db, "differs from the seed", "DELETE FROM modality WHERE name = '!'")


def test_random_modality_values_agree(db):
    rng = random.Random(1521)
    for _ in range(300):
        kind = rng.choice(KINDS + [None, "other"])
        m, c = rng.random() < 0.5, rng.random() < 0.5
        mv = rng.choice([None, 0, 0, 1, 3])
        cv = rng.choice([None, 0, 0, 2])
        got = rows(db, "SELECT * FROM governance_modality_values_problems(%s, %s, %s, %s, %s)",
                   kind, m, c, mv, cv)
        assert got == modality_problems(kind, "m" if m else None, "c" if c else None, mv, cv)


def test_backing_by_real_monads(db):
    """◇ backed by the Z/2 monad and □ by the Z/2 comonad are clean; a monad on
    □ is reported at write time; the unlawful Z/3 comonad is reported in batch."""
    _z2(db)
    db.nt("eta", "Id", "T", {"S": "s"})
    db.nt("mu", "TT", "T", {"S": "s"})
    db.monad("Z2", "M", "T", "eta", "mu")
    db.nt("eps", "T", "Id", {"S": "s"})
    db.nt("delta", "T", "TT", {"S": "s"})
    db.comonad("Z2c", "M", "T", "eps", "delta")
    db.q("UPDATE modality SET monad_id = %s WHERE name = '◇'", db.ids["Z2"])
    db.q("UPDATE modality SET comonad_id = %s WHERE name = '□'", db.ids["Z2c"])
    assert db.one("SELECT check_governance()") == 0
    db.q("UPDATE modality SET monad_id = %s WHERE name = '□'", db.ids["Z2"])
    assert violations(db, "modality") == [("modality_backing", {"error": "monad"})]
    db.q("UPDATE modality SET monad_id = NULL WHERE name = '□'")
    db.q("DELETE FROM governance_violation")
    # an unlawful comonad (Z/3, ε = δ = g): both counit laws fail
    db.q("SAVEPOINT z3")
    db.q("DELETE FROM modality WHERE name = '□'")     # free the comonad names
    db.q("ROLLBACK TO SAVEPOINT z3")
    cat = "M3"
    db.category(cat)
    db.obj(cat, "S3")
    for e in ("g", "g2"):
        db.mor(e, "S3", "S3")
    table = {("g", "g"): "g2", ("g", "g2"): "id_S3", ("g2", "g"): "id_S3", ("g2", "g2"): "g"}
    for (x, y), h in table.items():
        db.comp(x, y, h)
    for n in ("Id3", "T3", "TT3"):
        db.functor(n, cat, cat, {"S3": "S3"}, {m: m for m in db.morphisms[cat]})
    db.nt("eps3", "T3", "Id3", {"S3": "g"})
    db.nt("delta3", "T3", "TT3", {"S3": "g"})
    db.comonad("Z3", cat, "T3", "eps3", "delta3")
    assert db.comonad_laws("Z3") == ["left_counit", "right_counit"]
    db.q("UPDATE modality SET comonad_id = %s WHERE name = '□'", db.ids["Z3"])
    assert violations(db, "modality") == []          # lawfulness is a batch check
    mid = modality_id(db, "□")
    assert rows(db, "SELECT * FROM governance_modality_problems(%s)", mid) == [
        ("modality_backing_unlawful", {"structure": "comonad", "violations": 2})]


# ---------------------------------------------------------------------------
# Policies and assignments
# ---------------------------------------------------------------------------
def test_random_policy_values_agree(db):
    rng = random.Random(1522)
    seen = Counter()
    for _ in range(500):
        name, scope = random_text(rng), random_text(rng)
        version, body = random_version(rng), random_json(rng)
        has_m = rng.random() < 0.8
        level = rng.choice(LEVELS + [None])
        got = rows(db, "SELECT * FROM governance_policy_values_problems(%s, %s, %s::jsonb, %s, %s, %s)",
                   name, version, js(body), has_m, scope, level)
        expected = policy_problems(name, version, body, "m" if has_m else None, scope, level)
        assert got == expected
        seen.update(d["error"] for _, d in expected)
    assert set(seen) == {"name", "version", "body", "modality", "scope", "enforcement"}


def test_policy_rows_and_writer(db):
    pid = policy(db, "privacy", "!", "soft")
    assert rows(db, "SELECT * FROM governance_policy_problems(%s)", pid) == []
    assert db.one("SELECT version FROM policy WHERE id = %s", pid) == "1.0.0"
    db.q("UPDATE policy SET version = '1.0', modality_id = NULL WHERE id = %s", pid)
    assert violations(db, "policy") == srt([("policy_typing", {"error": "version"}),
                                            ("policy_typing", {"error": "modality"})])
    savepoint_raises(db, "version", "SELECT register_policy('p', NULL, '{}', '□', 'soft', '2')")
    savepoint_raises(db, "scope", "SELECT register_policy('p', ' ', '{}', '□')")
    db.set_mode("strict")
    savepoint_raises(db, "not well formed",
                     "INSERT INTO policy (name, body, modality_id) VALUES ('q', '[]', %s)",
                     modality_id(db, "□"))


def test_random_assignment_values_agree(db):
    rng = random.Random(1523)
    for _ in range(300):
        pm = rng.choice(NAMES + [None])
        m = rng.choice(NAMES) if rng.random() < 0.4 else pm
        scope = rng.choice(["read", "write", "execute", "fly", None, "Read", ""])
        ex = rng.choice([None, True, False])
        dup = rng.choice([None, 1, 2, 3])
        got = rows(db, "SELECT * FROM governance_assignment_values_problems(%s, %s, %s, %s, %s)",
                   pm, m, scope, ex, dup)
        assert got == assignment_problems(pm, m, scope, ex, dup)


def test_assignment_rows(db):
    pid = policy(db, "p")
    db.category("C")
    db.obj("C", "A")
    art = db.one("SELECT gen_random_uuid()")
    aid = db.one("SELECT assign_policy(%s, 'write', %s, %s)", pid, art, db.ids["id_A"])
    assert rows(db, "SELECT * FROM governance_assignment_problems(%s)", aid) == []
    savepoint_raises(db, "assignment_typing", "SELECT assign_policy(%s, 'fly')", pid)
    savepoint_raises(db, "morphism", "SELECT assign_policy(%s, 'read', NULL, gen_random_uuid())",
                     pid)
    # identical rows (NULLs defeat the UNIQUE constraint): a batch problem
    for _ in range(2):
        db.q("INSERT INTO policy_modality_assignment (policy_id, modality_id, scope) "
             "VALUES (%s, %s, 'read')", pid, modality_id(db, "□"))
    savepoint_raises(db, "assignment_duplicate", "SELECT assign_policy(%s, 'read')", pid)
    ids = [r[0] for r in rows(db, "SELECT id FROM policy_modality_assignment WHERE scope = 'read'")]
    for i in ids:
        assert rows(db, "SELECT * FROM governance_assignment_problems(%s)", i) == [
            ("assignment_duplicate", {"count": 2})]
        assert rows(db, "SELECT * FROM governance_assignment_problems(%s, FALSE)", i) == []


# ---------------------------------------------------------------------------
# Frames
# ---------------------------------------------------------------------------
def test_random_frames_agree(db):
    rng = random.Random(1524)
    seen = Counter()
    for _ in range(80):
        db.q("SAVEPOINT f")
        ctx, rel = random_frame(rng)
        frame(db, ctx, rel, "alethic")
        frame(db, ctx, {(a, b) for a, b in rel if rng.random() < 0.8}, "deontic")
        ids = dict(rows(db, "SELECT name, id FROM governance_context"))
        drel = set(rows(db, "SELECT f.name, t.name FROM governance_access a "
                            "JOIN governance_context f ON f.id = a.from_context_id "
                            "JOIN governance_context t ON t.id = a.to_context_id "
                            "WHERE a.frame = 'deontic'"))
        for fr, r in (("alethic", rel), ("deontic", drel)):
            expected = frame_problems(fr, ctx, r)
            got = rows(db, "SELECT * FROM governance_frame_problems(%s)", fr)
            assert [(x, d) for _, x, d in got] == expected
            for sid, reason, d in got:
                name = d.get("context", d.get("from"))
                assert sid == ids[name]
            seen.update(x for x, _ in expected)
        for c in ctx:
            assert rows(db, "SELECT unnest(governance_accessible('alethic', %s))", ids[c]) == \
                [(x,) for x in accessible_from(c, rel)]
        db.q("ROLLBACK TO SAVEPOINT f")
    assert set(seen) == {"frame_reflexive", "frame_transitive", "frame_serial"}


def test_frame_writers(db):
    savepoint_raises(db, "context_typing", "SELECT register_governance_context(' ')")
    frame(db, ["dev"], set())
    savepoint_raises(db, "unknown frame", "SELECT register_governance_access('epistemic', 'dev', 'dev')")
    savepoint_raises(db, "unknown context", "SELECT register_governance_access('alethic', 'dev', 'x')")
    a = db.one("SELECT register_governance_access('alethic', 'dev', 'dev')")
    assert db.one("SELECT register_governance_access('alethic', 'dev', 'dev')") == a
    db.q("INSERT INTO governance_context (name) VALUES ('')")
    assert violations(db, "governance_context") == [("context_typing", {"error": "name"})]


# ---------------------------------------------------------------------------
# Policy checks
# ---------------------------------------------------------------------------
def test_random_check_values_agree(db):
    rng = random.Random(1525)
    seen = Counter()
    for _ in range(800):
        ctx, rel = random_frame(rng, rng.randint(0, 4))
        w = rng.choice(ctx) if ctx else None
        acc = accessible_from(w, rel) if rng.random() < 0.9 else None
        outcomes = random_outcomes(rng, ctx)
        has_p = rng.random() < 0.93
        kind = rng.choice(KINDS) if rng.random() < 0.93 else None
        level = rng.choice(LEVELS + [None])
        has_c = rng.random() < 0.95
        recorded = rng.choice(["pass", "fail", "warn"])
        sql_outcomes = None if outcomes is None and rng.random() < 0.5 else js(outcomes)
        got = rows(db, "SELECT * FROM governance_check_values_problems(%s, %s, %s, %s, %s::jsonb, "
                       "%s, %s::text[])", has_p, kind, level, has_c, sql_outcomes, recorded, acc)
        expected = check_problems(has_p, kind, level, "w" if has_c else None, outcomes, recorded,
                                  acc)
        assert got == expected
        seen.update(r if r != "check_typing" else d["error"] for r, d in expected)
        if not expected:
            seen["clean"] += 1
    assert set(seen) >= {"policy", "modality", "context", "outcomes", "check_outcome_missing",
                         "check_result", "clean"}


def test_random_check_rows_agree(db):
    """Checks inserted directly: the stored snapshot is the frame's accessible
    set, and the row problems are the Python problems."""
    rng = random.Random(1526)
    pols = {(k, lvl): policy(db, "p_%s_%s" % (k, lvl), n, lvl)
            for n, k, _, _ in SEED for lvl in LEVELS}
    for _ in range(25):
        db.q("SAVEPOINT c")
        ctx, rel = random_frame(rng, rng.randint(1, 4))
        frame(db, ctx, rel, "alethic")
        frame(db, ctx, rel, "deontic")
        for _ in range(8):
            kind, lvl = rng.choice(KINDS), rng.choice(LEVELS)
            w = rng.choice(ctx)
            outcomes = random_outcomes(rng, ctx)
            recorded = rng.choice(["pass", "fail", "warn"])
            lid = db.one("INSERT INTO policy_check_log (policy_id, context_id, outcomes, result, "
                         "accessible) SELECT %s, id, %s::jsonb, %s, ARRAY['forged'] "
                         "FROM governance_context WHERE name = %s RETURNING id",
                         pols[(kind, lvl)], js(outcomes), recorded, w)
            acc = accessible_from(w, rel)
            assert (db.one("SELECT accessible FROM policy_check_log WHERE id = %s", lid) or []) == acc
            expected = check_problems(True, kind, lvl, w, outcomes, recorded, acc)
            assert rows(db, "SELECT * FROM governance_check_problems(%s)", lid) == expected
        db.q("ROLLBACK TO SAVEPOINT c")


def test_log_policy_check_computes_the_result(db):
    frame(db, ["dev", "staging", "prod"],
          {("dev", "dev"), ("staging", "staging"), ("prod", "prod"), ("dev", "staging"),
           ("dev", "prod"), ("staging", "prod")})
    frame(db, ["dev", "staging", "prod"], {("dev", "prod"), ("staging", "prod"), ("prod", "prod")},
          "deontic")
    assert db.one("SELECT check_governance_frames()") == 0
    rng = random.Random(1527)
    for _ in range(60):
        n, kind, _, _ = rng.choice(SEED)
        lvl = rng.choice(LEVELS)
        pid = policy(db, "p%d" % rng.randrange(10**9), n, lvl)
        w = rng.choice(["dev", "staging", "prod"])
        out = {c: rng.random() < 0.6 for c in ["dev", "staging", "prod"]}
        lid = db.one("SELECT log_policy_check(NULL, %s, %s, %s::jsonb)", pid, w, js(out))
        acc = db.one("SELECT accessible FROM policy_check_log WHERE id = %s", lid)
        assert db.one("SELECT result FROM policy_check_log WHERE id = %s", lid) == \
            computed_result(kind, lvl, acc, out)
        assert rows(db, "SELECT * FROM governance_check_problems(%s)", lid) == []
    pid = policy(db, "strict_one", "□", "hard")
    savepoint_raises(db, "check_outcome_missing",
                     "SELECT log_policy_check(NULL, %s, 'dev', '{\"dev\": true}')", pid)
    savepoint_raises(db, "unknown context",
                     "SELECT log_policy_check(NULL, %s, 'nowhere', '{}')", pid)
    savepoint_raises(db, "outcomes",
                     "SELECT log_policy_check(NULL, %s, 'dev', '{\"dev\": 1}')", pid)
    # a check stays as evaluated: the frame can change later
    lid = db.one("SELECT log_policy_check(NULL, %s, 'dev', "
                 "'{\"dev\": true, \"staging\": true, \"prod\": true}')", pid)
    db.q("DELETE FROM governance_access WHERE frame = 'alethic'")
    assert rows(db, "SELECT * FROM governance_check_problems(%s)", lid) == []


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------
def test_random_workflow_values_agree(db):
    rng = random.Random(1528)
    seen = Counter()
    for _ in range(500):
        name, steps, timeout = random_text(rng), random_steps(rng), random_timeout(rng)
        got = rows(db, "SELECT * FROM governance_workflow_values_problems(%s, %s::jsonb, %s)",
                   name, js(steps), timeout)
        expected = workflow_problems(name, steps, timeout)
        assert got == expected
        seen.update(d["error"] for _, d in expected)
    assert set(seen) == {"name", "steps", "step", "duplicate_role", "timeout"}


def test_random_token_values_agree(db):
    rng = random.Random(1529)
    seen = Counter()
    for _ in range(600):
        roles = rng.choice([None, ["author"], ["author", "reviewer", "owner"]])
        timeout = rng.choice([1, 7, 30])
        role = rng.choice(["author", "reviewer", "owner", "nobody", None])
        a, e = random_window(rng, timeout)
        has_art = rng.random() < 0.9
        got = rows(db, "SELECT * FROM governance_token_values_problems(%s::text[], %s, %s, %s, "
                       "%s::timestamptz, %s::timestamptz)", roles, timeout, has_art, role, a, e)
        expected = token_problems(roles, timeout, "art" if has_art else None, role, a, e)
        assert got == expected
        seen.update(d["error"] for _, d in expected)
    assert set(seen) == {"workflow", "role", "artifact", "approved_at", "expires_at", "window",
                         "timeout"}


def test_token_timeout_is_24_hour_days_in_every_time_zone(db):
    db.q("SET LOCAL TimeZone = 'Europe/Berlin'")      # T0 is just before a DST change
    a = T0
    for e, ok in ((a + timedelta(days=1), True), (a + timedelta(days=1, microseconds=1), False)):
        got = rows(db, "SELECT * FROM governance_token_values_problems(ARRAY['r'], 1, TRUE, 'r', "
                       "%s::timestamptz, %s::timestamptz)", a, e)
        assert (got == []) == ok


def test_random_token_rows_and_approval_status_agree(db):
    rng = random.Random(1530)
    roles = ["author", "reviewer", "owner"]
    wid = db.one("SELECT register_approval_workflow('release', %s::jsonb, 2)",
                 js([{"role": r} for r in roles]))
    for _ in range(25):
        db.q("SAVEPOINT k")
        art = db.one("SELECT gen_random_uuid()")
        toks = []
        for _ in range(rng.randint(1, 6)):
            role = rng.choice(roles + ["nobody"])
            a = random_time(rng)
            e = a + timedelta(hours=rng.randint(-2, 60))
            tid = db.one("INSERT INTO approval_token (workflow_id, artifact_id, approver_role, "
                         "approved_at, expires_at) VALUES (%s, %s, %s, %s, %s) RETURNING id",
                         wid, art, role, a, e)
            toks.append((tid, role, a, e))
        others = [(r, a) for _, r, a, _ in toks]
        good = []
        for tid, role, a, e in toks:
            expected = token_problems(roles, 2, art, role, a, e, others)
            assert rows(db, "SELECT * FROM governance_token_problems(%s)", tid) == expected
            if not expected:
                good.append((role, a, e))
        for _ in range(6):
            at = random_time(rng)
            assert db.one("SELECT approval_status(%s, %s, %s)", wid, art, at) == \
                is_approved(roles, good, at)
        db.q("ROLLBACK TO SAVEPOINT k")


def test_approval_writers(db):
    savepoint_raises(db, "workflow_typing",
                     "SELECT register_approval_workflow('w', '[{\"role\": \"a\"}, {\"role\": \"a\"}]')")
    wid = db.one("SELECT register_approval_workflow('w', '[{\"role\": \"author\"}, "
                 "{\"role\": \"reviewer\"}]', 3)")
    art = db.one("SELECT gen_random_uuid()")
    savepoint_raises(db, "token_order", "SELECT record_approval(%s, %s, 'reviewer')", wid, art)
    savepoint_raises(db, "role", "SELECT record_approval(%s, %s, 'nobody')", wid, art)
    savepoint_raises(db, "not found", "SELECT record_approval(gen_random_uuid(), %s, 'a')", art)
    t1 = db.one("SELECT record_approval(%s, %s, 'author', %s)", wid, art, T0)
    assert db.one("SELECT expires_at - approved_at FROM approval_token WHERE id = %s", t1) == \
        timedelta(days=3)
    db.q("SELECT record_approval(%s, %s, 'reviewer', %s)", wid, art, T0 + timedelta(hours=1))
    assert db.one("SELECT approval_status(%s, %s, %s)", wid, art, T0 + timedelta(hours=2))
    assert not db.one("SELECT approval_status(%s, %s, %s)", wid, art, T0 + timedelta(days=3))
    assert not db.one("SELECT approval_status(%s, %s, %s)", wid, art, T0)


# ---------------------------------------------------------------------------
# Audit hash chain
# ---------------------------------------------------------------------------
AUDIT_COLS = ("seq, prev_hash, record_hash, actor, action, artifact_id::text, morphism_id::text, "
              "details::text, signature, created_at")


def audit_rows(db):
    return [(r[0], r[1], r[2], r[3], r[4], r[5], r[6], r[7],
             None if r[8] is None else bytes(r[8]), r[9])
            for r in db.q("SELECT %s FROM audit_record ORDER BY seq NULLS LAST, id" % AUDIT_COLS)]


def test_chain_hashes_are_the_python_hashes(db):
    rng = random.Random(1531)
    for i in range(40):
        details = rng.choice([{}, {"a": 1}, {"ü": [1, None, "x"]}, {"b": {"c": True}}])
        art = db.one("SELECT gen_random_uuid()") if rng.random() < 0.5 else None
        if rng.random() < 0.3:
            db.q("INSERT INTO audit_record (actor, action, details, signature, seq, prev_hash, "
                 "record_hash) VALUES (%s, 'sign', %s::jsonb, %s, 99, 'forged', 'forged')",
                 "actor%d" % i, js(details), psycopg2.Binary(bytes([i, 255, 0])))
        else:
            db.q("SELECT record_audit(%s, %s, %s, NULL, %s::jsonb)",
                 rng.choice(["alice", "bob", "ünï"]), "act:%d" % i, art, js(details))
    recs = audit_rows(db)
    assert [r[0] for r in recs] == list(range(1, 41))
    assert recs[0][1] == GENESIS
    for r in recs:
        assert r[2] == record_hash(r[1], r[0], *r[3:])
    assert chain_problems(recs) == []
    assert db.one("SELECT check_audit_chain()") == 0


def test_random_tampering_is_detected_like_python(db):
    rng = random.Random(1532)
    for i in range(12):
        db.q("SELECT record_audit(%s, 'step', NULL, NULL, %s::jsonb)", "a%d" % i, js({"i": i}))
    seen = Counter()
    for _ in range(40):
        db.q("SAVEPOINT a")
        n_logged = len(violations(db))
        for _ in range(rng.randint(1, 3)):
            seq = rng.randint(1, 12)
            act = rng.random()
            if act < 0.25:
                db.q("UPDATE audit_record SET actor = 'mallory' WHERE seq = %s", seq)
            elif act < 0.45:
                db.q("DELETE FROM audit_record WHERE seq = %s", seq)
            elif act < 0.6:
                db.q("UPDATE audit_record SET details = '{\"i\": -1}' WHERE seq = %s", seq)
            elif act < 0.75:
                db.q("UPDATE audit_record SET record_hash = repeat('f', 64) WHERE seq = %s", seq)
            elif act < 0.9:
                db.q("UPDATE audit_record SET seq = seq + 100 WHERE seq = %s", seq)
            else:
                db.q("UPDATE audit_record SET created_at = created_at + interval '1 microsecond' "
                     "WHERE seq = %s", seq)
        recs = audit_rows(db)
        ids = [r[0] for r in rows(db, "SELECT id FROM audit_record ORDER BY seq NULLS LAST, id")]
        expected = [(ids[i], r, d) for i, (r, d) in chain_problems(recs)]
        got = rows(db, "SELECT * FROM governance_audit_chain_problems()")
        assert got == expected
        seen.update(d["error"] for _, _, d in expected)
        # every change was logged when it happened
        logged = violations(db)
        assert len(logged) > n_logged and all(r == "log_mutation" for r, _ in logged
                                              if r != "audit_typing")
        db.q("ROLLBACK TO SAVEPOINT a")
    assert set(seen) == {"gap", "link", "hash"}


def test_logs_are_append_only_in_strict_mode(db):
    pid = policy(db, "p")
    frame(db, ["dev"], {("dev", "dev")})
    db.q("SELECT log_policy_check(NULL, %s, 'dev', '{\"dev\": true}')", pid)
    db.q("SELECT record_audit('alice', 'create', NULL, NULL, '{}')")
    db.set_mode("strict")
    for sql in ("UPDATE audit_record SET actor = 'm'", "DELETE FROM audit_record",
                "TRUNCATE audit_record", "UPDATE policy_check_log SET result = 'fail'",
                "DELETE FROM policy_check_log", "TRUNCATE policy_check_log"):
        savepoint_raises(db, "append-only", sql)
    savepoint_raises(db, "audit_typing", "SELECT record_audit(' ', 'x', NULL, NULL, '{}')")
    savepoint_raises(db, "audit_typing", "SELECT record_audit('a', 'x', NULL, NULL, '[]')")
    db.set_mode("permissive")
    db.q("TRUNCATE audit_record")
    assert ("log_mutation", {"table": "audit_record", "op": "TRUNCATE"}) in violations(db)


# ---------------------------------------------------------------------------
# Batch, strict-mode flows and the upgrade path
# ---------------------------------------------------------------------------
def test_writers_work_in_strict_mode(db):
    """The intended flows raise nothing in strict mode and pass the batch check."""
    db.set_mode("strict")
    for c in ("dev", "staging", "prod"):
        db.q("SELECT register_governance_context(%s)", c)
    for a, b in (("dev", "dev"), ("staging", "staging"), ("prod", "prod"), ("dev", "staging"),
                 ("staging", "prod"), ("dev", "prod")):
        db.q("SELECT register_governance_access('alethic', %s, %s)", a, b)
    for a in ("dev", "staging", "prod"):
        db.q("SELECT register_governance_access('deontic', %s, 'prod')", a)
    art = db.one("SELECT gen_random_uuid()")
    for n, lvl in (("□", "hard"), ("◇", "soft"), ("!", "block_and_alert"), ("?", "soft")):
        pid = db.one("SELECT register_policy(%s, 'release', '{\"rule\": \"tests pass\"}', %s, %s)",
                     "policy " + n, n, lvl)
        db.q("SELECT assign_policy(%s, 'execute', %s)", pid, art)
        db.q("SELECT log_policy_check(%s, %s, 'dev', "
             "'{\"dev\": true, \"staging\": true, \"prod\": false}')", art, pid)
    wid = db.one("SELECT register_approval_workflow('release', "
                 "'[{\"role\": \"author\"}, {\"role\": \"security\"}]', 7)")
    db.q("SELECT record_approval(%s, %s, 'author', now() - interval '1 hour')", wid, art)
    db.q("SELECT record_approval(%s, %s, 'security')", wid, art)
    assert db.one("SELECT approval_status(%s, %s)", wid, art)
    db.q("SELECT record_audit('alice', 'release', %s, NULL, '{}')", art)
    assert db.one("SELECT check_governance()") == 0
    db.q("SELECT run_all_batch_checks()")
    assert violations(db) == []
    results = rows(db, "SELECT m.name, l.result FROM policy_check_log l JOIN policy p "
                       "ON p.id = l.policy_id JOIN modality m ON m.id = p.modality_id "
                       "ORDER BY m.name COLLATE \"C\"")
    # from dev: □ over {dev, staging, prod} fails (hard), ◇ passes, ! over {prod}
    # fails (blocking), ? over {prod} warns (soft)
    assert results == [("!", "fail"), ("?", "warn"), ("□", "fail"), ("◇", "pass")]


def test_check_governance_reports_and_raises(db):
    frame(db, ["dev", "prod"], {("dev", "prod")})
    n = db.one("SELECT check_governance()")
    reasons = sorted(r for r, _ in violations(db))
    assert n == len(reasons)
    assert reasons == ["frame_reflexive", "frame_reflexive", "frame_serial", "frame_serial"]
    db.set_mode("strict")
    savepoint_raises(db, "Governance tables have problems", "SELECT check_governance()")
    savepoint_raises(db, "problems", "SELECT run_all_batch_checks()")


def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE policy_check_log, audit_record, approval_token, governance_violation, "
         "governance_access, governance_context CASCADE")
    db.q("""
      CREATE TABLE policy_check_log (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        artifact_id UUID, morphism_id UUID,
        policy_id UUID REFERENCES policy(id) ON DELETE SET NULL,
        result TEXT NOT NULL CHECK (result IN ('pass','fail','warn')),
        details JSONB DEFAULT '{}'::jsonb, checked_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE approval_token (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        workflow_id UUID NOT NULL REFERENCES approval_workflow(id) ON DELETE CASCADE,
        artifact_id UUID, approver_role TEXT, approved_at TIMESTAMPTZ, expires_at TIMESTAMPTZ,
        signature BYTEA, metadata JSONB DEFAULT '{}'::jsonb);
      CREATE TABLE audit_record (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        actor TEXT NOT NULL, action TEXT NOT NULL, artifact_id UUID, morphism_id UUID,
        details JSONB DEFAULT '{}'::jsonb, signature BYTEA, created_at TIMESTAMPTZ DEFAULT now());
      DROP TRIGGER trg_check_governance_row ON policy;
      DROP TRIGGER trg_check_governance_modalities ON modality;
    """)
    db.q("INSERT INTO policy (name, body, version) VALUES ('old', '{}', '1.0.0')")
    db.q("INSERT INTO policy_check_log (result) VALUES ('pass')")
    for i, actor in enumerate(["alice", "bob", "carol"]):
        db.q("INSERT INTO audit_record (actor, action, created_at) "
             "VALUES (%s, 'x', now() + %s * interval '1 second')", actor, i)
    path = Path(__file__).resolve().parents[2] / "migrations" / "015_governance_modalities.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    # the old rows are checked, not hidden; old audit records are chained
    assert sorted(r for r, _ in rows(db, "SELECT * FROM governance_policy_problems("
                                         "(SELECT id FROM policy WHERE name = 'old'))")) == \
        ["policy_typing"]
    assert [r[3] for r in audit_rows(db)] == ["alice", "bob", "carol"]
    assert db.one("SELECT check_audit_chain()") == 0
    assert db.one("SELECT check_governance()") == 4   # policy modality; check: policy, context, outcomes
    db.q("SELECT record_audit('dave', 'y', NULL, NULL, '{}')")
    assert db.one("SELECT max(seq) FROM audit_record") == 4
    assert db.one("SELECT check_audit_chain()") == 0
