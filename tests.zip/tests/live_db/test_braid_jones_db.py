"""Migration 023 (Kauffman bracket / Jones certificates) on a real PostgreSQL.

The reference is ``qbx_ir.jones_ledger``: on random data — including
certificates of malformed braids and certificates with wrong hashes, windows
and coefficients — the database reports exactly the problems the Python code
reports, with the same details, in the same order.  The equality answers
(bracket and Jones polynomial), the transport check along accepted rewrites and
derivations and the consistency check with the normal-form certificates of
migration 021 are compared too.

Written 2026-10-15 without a PostgreSQL server; not yet run.  The algorithm of
``braid_jones_values`` is checked without a database by
``tests/qbx_ir/test_jones_sql_model.py``.

Formal backing: ``Formal/KauffmanBracket.lean`` and ``Formal/KauffmanBracket/*.lean``
(``quantumTrace_eq_bracket``, ``jonesPoly_markov``, ``bracketPoly_conj``,
``certPoly_inj``, ``not_markovEquiv_of_jonesCert_ne``, ``jones_agrees_with_python``)
— registry H-278 … H-281.
"""

from __future__ import annotations

import random
from collections import Counter

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import left_normal_form
from qbx_ir.jones_ledger import (
    JonesRow,
    bracket_equal,
    certificate_problems,
    jones_equal,
    jones_values,
    nf_consistency_problems,
    non_conjugacy_certified,
    non_isotopy_certified,
    transport_problems,
)
from qbx_ir.ledger import BraidRow, braid_problems, derivation_problems, rewrite_problems
from qbx_ir.normal_form_ledger import NFRow
from tests.live_db.test_braid_ledger_db import build_random_ledger, random_word


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def values(db, n, w):
    blo, bw, bc, jlo, jw, jc = db.q("SELECT * FROM braid_jones_values(%s, %s::int[])", n, w)[0]
    return blo, bw, tuple(int(x) for x in bc), jlo, jw, tuple(int(x) for x in jc)


def py_values(n, w):
    v = jones_values(n, w)
    return (v.bracket_exp_min, v.bracket_width, v.bracket_coefficients,
            v.jones_exp_min, v.jones_width, v.jones_coefficients)


def test_values_agree_with_python(db):
    rng = random.Random(21)
    for _ in range(250):
        n = rng.randint(1, 6)
        w = random_word(rng, n, rng.randint(0, 12)) if n > 1 else []
        assert values(db, n, w) == py_values(n, w), (n, w)


def test_values_on_more_strands(db):
    rng = random.Random(22)
    for _ in range(10):
        n = rng.randint(7, 9)
        w = random_word(rng, n, rng.randint(0, 14))
        assert values(db, n, w) == py_values(n, w), (n, w)


def test_values_on_known_braids(db):
    assert values(db, 1, []) == (0, 1, (1,), 0, 1, (1,))                  # unknot
    assert values(db, 2, []) == py_values(2, [])                          # 2-component unlink
    trefoil = values(db, 2, [1, 1, 1])
    mirror = values(db, 2, [-1, -1, -1])
    assert trefoil[3:] != mirror[3:]                                      # chirality
    assert values(db, 3, [1, 2, 1]) == values(db, 3, [2, 1, 2])           # braid relation
    assert values(db, 3, [1, 2])[3:] == values(db, 1, [])[3:]             # Markov: unknot
    assert db.one("SELECT braid_jones_binom(5, 2)") == 10
    assert db.one("SELECT braid_jones_loops('2,3,0,1', 2)") == 2          # identity on 2 strands
    assert db.one("SELECT braid_jones_loops('1,0,3,2', 2)") == 1          # e_1 closes to 1 loop
    assert db.q("SELECT * FROM braid_jones_cup('2,3,0,1', 2, 0)") == [("1,0,3,2", False)]
    assert db.q("SELECT * FROM braid_jones_cup('1,0,3,2', 2, 0)") == [("1,0,3,2", True)]


def random_jones(rng, braid: BraidRow) -> JonesRow:
    """A certificate for ``braid``: usually the right one, sometimes tampered with."""
    if braid_problems(braid):
        return JonesRow(braid, braid.braid_hash, 0, 1, (1,), 0, 1, (1,))
    good = JonesRow.of(braid)
    roll = rng.random()
    f = lambda **kw: JonesRow(**{**good.__dict__, **kw})
    if roll < 0.06:
        return f(braid_hash="e" * 8)
    if roll < 0.12:
        return f(bracket_width=good.bracket_width + 1,
                 bracket_coefficients=good.bracket_coefficients + (0,))
    if roll < 0.18:
        cs = list(good.bracket_coefficients)
        cs[rng.randrange(len(cs))] += rng.choice([-1, 1])
        return f(bracket_coefficients=tuple(cs))
    if roll < 0.24:
        return f(jones_exp_min=good.jones_exp_min + 4)
    if roll < 0.30:
        return f(jones_coefficients=tuple(-x for x in good.jones_coefficients))
    return good


def insert_jones(db, bid, c: JonesRow):
    return db.one(
        "INSERT INTO braid_jones (braid_id, braid_hash, bracket_exp_min, bracket_width, "
        "bracket_coefficients, jones_exp_min, jones_width, jones_coefficients) "
        "VALUES (%s, %s, %s, %s, %s::numeric[], %s, %s, %s::numeric[]) RETURNING id",
        bid, c.braid_hash, c.bracket_exp_min, c.bracket_width, list(c.bracket_coefficients),
        c.jones_exp_min, c.jones_width, list(c.jones_coefficients))


def test_random_certificates_equality_transport_and_consistency_match_reference(db):
    seen = Counter()
    for seed in range(5):
        db.q("SAVEPOINT s")
        rng = random.Random(800 + seed)
        m = build_random_ledger(db, rng, n_braids=25, n_rewrites=30)
        certs, cert_ids, nfs = {}, [], {}
        for bid, braid in m.braid_row.items():
            if not braid_problems(braid) and rng.random() < 0.8:
                db.one("SELECT certify_braid_normal_form(%s)", bid)
                nfs[bid] = NFRow.of(braid)
            r = rng.random()
            if r < 0.35:
                c = random_jones(rng, braid)
                cid = insert_jones(db, bid, c)
            elif r < 0.9 and not braid_problems(braid) and braid.strand_count <= 12:
                cid = db.one("SELECT certify_braid_jones(%s)", bid)
                c = JonesRow.of(braid)
            else:
                continue
            certs[bid] = c
            cert_ids.append((bid, cid, c))
            got = rows(db, "SELECT * FROM braid_jones_problems(%s)", cid)
            assert got == certificate_problems(c), (seed, c)
            seen.update(r for r, _ in got)
            if not got:
                seen["certificate_ok"] += 1
        ids = list(m.braid_row)
        canon = {bid: (row.strand_count,
                       left_normal_form(Braid.from_short_form(row.strand_count, list(row.word))))
                 for bid, row in m.braid_row.items() if not braid_problems(row)}
        pairs = [(rng.choice(ids), rng.choice(ids)) for _ in range(60)]
        pairs += [(a, b) for a in canon for b in canon if a != b and canon[a] == canon[b]]
        for a, b in pairs:
            ca, cb = certs.get(a), certs.get(b)
            assert db.one("SELECT braid_bracket_equal(%s, %s)", a, b) == bracket_equal(ca, cb)
            assert db.one("SELECT braid_jones_equal(%s, %s)", a, b) == jones_equal(ca, cb)
            assert db.one("SELECT braid_bracket_non_conjugacy_certified(%s, %s)", a, b) == \
                non_conjugacy_certified(ca, cb)
            assert db.one("SELECT braid_jones_non_isotopy_certified(%s, %s)", a, b) == \
                non_isotopy_certified(ca, cb)
            if jones_equal(ca, cb) is False:
                seen["certified_not_isotopic"] += 1
        for bid, cid, c in cert_ids:
            got = rows(db, "SELECT * FROM braid_jones_nf_problems(%s)", cid)
            others = [(oc, nfs.get(ob)) for ob, _, oc in cert_ids]
            assert got == nf_consistency_problems(c, nfs.get(bid), others) == [], (seed, got)
        for rid, r in m.rewrite_row.items():
            ok = not rewrite_problems(r)
            a, b = m.braid_id[r.input.key], m.braid_id[r.output.key]
            got = rows(db, "SELECT * FROM braid_rewrite_jones_transport_problems(%s)", rid)
            assert got == transport_problems(ok, certs.get(a), certs.get(b)) == [], (seed, got)
            if ok and jones_equal(certs.get(a), certs.get(b)):
                seen["transport_checked"] += 1
        for _ in range(10):
            src = rng.choice(ids)
            steps, dirs, cur = [], [], src
            for _ in range(rng.randint(0, 4)):
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = m.braid_id[(r.output if d else r.input).key]
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, cur, steps, dirs)
            accepted = not derivation_problems(m.braid_row[src], m.braid_row[cur],
                                               [m.rewrite_row[s] for s in steps], dirs)
            got = rows(db, "SELECT * FROM braid_derivation_jones_transport_problems(%s)", did)
            assert got == transport_problems(accepted, certs.get(src), certs.get(cur)) == []
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("braid_not_well_formed", "braid_hash_mismatch", "bracket_window_mismatch",
                   "bracket_coefficients_mismatch", "jones_window_mismatch",
                   "jones_coefficients_mismatch", "certificate_ok", "certified_not_isotopic",
                   "transport_checked"):
        assert seen[reason] > 0, reason


def test_writer_and_non_isotopy(db):
    t = db.one("SELECT register_braid(2, ARRAY[1, 1, 1])")
    tm = db.one("SELECT register_braid(2, ARRAY[-1, -1, -1])")
    u3 = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    u1 = db.one("SELECT register_braid(1, ARRAY[]::int[])")
    for x in (t, tm, u3, u1):
        db.one("SELECT certify_braid_jones(%s)", x)
    ct = db.one("SELECT id FROM braid_jones WHERE braid_id = %s", t)
    assert db.one("SELECT certify_braid_jones(%s)", t) == ct          # one per braid
    assert db.one("SELECT braid_jones_non_isotopy_certified(%s, %s)", t, tm) is True
    assert db.one("SELECT braid_jones_equal(%s, %s)", u3, u1) is True   # both close to the unknot
    assert db.one("SELECT braid_bracket_equal(%s, %s)", u3, u1) is None  # B_3 vs B_1
    assert db.one("SELECT check_braid_jones()") == 0
    assert db.one("SELECT count(*) FROM invariant_violation WHERE module = 'braid_jones'") == 0


def test_certify_refusals(db):
    db.q("INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (3, ARRAY[1, 7], 'h')")
    bad = db.one("SELECT id FROM braid_word WHERE braid_hash = 'h'")
    big = db.one("SELECT register_braid(13, ARRAY[1, 12])")
    for sql, args, msg in [
        ("SELECT certify_braid_jones(%s)", (bad,), "braid_not_well_formed"),
        ("SELECT certify_braid_jones(gen_random_uuid())", (), "unknown braid"),
        ("SELECT certify_braid_jones(%s)", (big,), "strand_count_too_large"),
    ]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, *args)
        db.q("ROLLBACK TO SAVEPOINT s")


def test_strict_mode_rejects_a_bad_certificate_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(2, ARRAY[1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    good = JonesRow.of(BraidRow.of(2, [1]))
    insert = ("INSERT INTO braid_jones (braid_id, braid_hash, bracket_exp_min, bracket_width, "
              "bracket_coefficients, jones_exp_min, jones_width, jones_coefficients) "
              "VALUES (%s, %s, %s, %s, %s::numeric[], %s, %s, %s::numeric[])")
    args = (a, h, good.bracket_exp_min, good.bracket_width, list(good.bracket_coefficients),
            good.jones_exp_min + 1, good.jones_width, list(good.jones_coefficients))
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q(insert, *args)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, *args)
    got = db.q("SELECT violation_type FROM invariant_violation WHERE module = 'braid_jones'")
    assert got == [("jones_window_mismatch",)]


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    c = db.one("SELECT certify_braid_jones(%s)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_jones SET jones_width = 5 WHERE id = %s",
                "DELETE FROM braid_jones WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, c)
        db.q("ROLLBACK TO SAVEPOINT s")


def test_phase3_batch_checks_include_both_certificate_kinds(db):
    a = db.one("SELECT register_braid(3, ARRAY[2, 1])")
    cj = db.one("SELECT certify_braid_jones(%s)", a)
    cb = db.one("SELECT certify_braid_burau(%s)", a)
    db.q("UPDATE braid_jones SET jones_coefficients = ARRAY[7] WHERE id = %s", cj)
    db.q("UPDATE braid_burau SET alexander = ARRAY[7] WHERE id = %s", cb)
    db.q("DELETE FROM invariant_violation")
    db.q("SELECT run_phase3_batch_checks()")
    got = db.q("SELECT module, violation_type FROM invariant_violation "
               "WHERE module IN ('braid_jones', 'braid_burau') ORDER BY module")
    assert got == [("braid_burau", "alexander_mismatch"),
                   ("braid_jones", "jones_coefficients_mismatch")]
