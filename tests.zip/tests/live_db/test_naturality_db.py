"""Live-database tests for migration 004 (naturality enforcement).

The reference is the in-memory checker ``qbx.categorical.NaturalTransformation``;
the random tests below compare the two (registry R-015).

Regression tests for two runtime bugs that static parsing could not catch:

* ``check_naturality_for_component`` selected ``INTO nt`` from a query that
  also used ``nt`` as a table alias, so PL/pgSQL resolved ``nt.…`` to the
  unassigned record and *every* component insert failed;
* ``nt_compose`` looked composites up in the reverse order, so every
  non-identity square was reported as ``naturality_composite_missing``.
"""

import random
from collections import Counter
from pathlib import Path

import pytest

psycopg2 = pytest.importorskip("psycopg2")

from qbx.categorical import NaturalTransformation  # noqa: E402
from qbx.core.enforced_functor import Category, EnforcedFunctor, EnforcementMode  # noqa: E402

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "004_natural_transformations.sql"
ORIGINAL = Path(__file__).resolve().parent / "data" / "004_natural_transformations_original.sql"


def _square(db, commuting=True):
    """C = (X --f--> Y);  D holds the square a ; ey  vs  ex ; b."""
    db.category("C")
    db.category("D")
    db.obj("C", "X")
    db.obj("C", "Y")
    db.mor("f", "X", "Y")
    for o in "ABPQ":
        db.obj("D", o)
    db.mor("a", "A", "B")
    db.mor("b", "P", "Q")
    db.mor("ex", "A", "P")
    db.mor("ey", "B", "Q")
    db.mor("d", "A", "Q")
    db.mor("d2", "A", "Q")
    db.comp("ey", "a", "d")                          # ey ∘ a = d
    db.comp("b", "ex", "d" if commuting else "d2")   # b ∘ ex = d (or d2)
    db.functor("F", "C", "D", {"X": "A", "Y": "B"}, {"id_X": "id_A", "id_Y": "id_B", "f": "a"})
    db.functor("G", "C", "D", {"X": "P", "Y": "Q"}, {"id_X": "id_P", "id_Y": "id_Q", "f": "b"})


@pytest.mark.parametrize("order", [("X", "Y"), ("Y", "X")])
def test_natural_transformation_has_no_violation(db, order):
    _square(db)
    db.nt("eta", "F", "G")
    comps = {"X": "ex", "Y": "ey"}
    for x in order:
        db.component("eta", x, comps[x])
    assert db.naturality_violations("eta") == []


@pytest.mark.parametrize("order", [("X", "Y"), ("Y", "X")])
def test_non_commuting_square_is_logged_in_either_order(db, order):
    _square(db, commuting=False)
    db.nt("eta", "F", "G")
    comps = {"X": "ex", "Y": "ey"}
    for x in order:
        db.component("eta", x, comps[x])
    assert db.naturality_violations("eta") == [("naturality_square", db.ids["f"])]


def test_missing_composite_is_a_violation(db):
    _square(db)
    db.q("DELETE FROM composition WHERE result_id = %s", db.ids["d"])
    db.nt("eta", "F", "G", {"X": "ex", "Y": "ey"})
    assert db.naturality_violations("eta") == [("naturality_composite_missing", db.ids["f"])]


def test_strict_mode_rejects_non_natural_component(db):
    _square(db, commuting=False)
    db.nt("eta", "F", "G", {"X": "ex"})
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="Naturality law violated"):
        db.component("eta", "Y", "ey")


def test_batch_recheck_runs(db):
    _square(db, commuting=False)
    db.nt("eta", "F", "G", {"X": "ex", "Y": "ey"})
    db.q("DELETE FROM naturality_violation")
    db.q("SELECT run_all_batch_checks()")
    # each problem once (the version before sprint 14 logged it once per component)
    assert db.naturality_violations("eta") == [("naturality_square", db.ids["f"])]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def savepoint_raises(db, match, sql, *args):
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match=match):
        db.q(sql, *args)
    db.q("ROLLBACK TO SAVEPOINT s")


def laws(db, nt):
    return Counter(r for r, _ in db.naturality_violations(nt))


# ---------------------------------------------------------------------------
# The gaps of the version before sprint 14 (each confirmed on PostgreSQL 16)
# ---------------------------------------------------------------------------
def test_ill_typed_component_is_reported(db):
    _square(db)
    db.nt("eta", "F", "G")
    db.component("eta", "X", "d")                    # d : A → Q, but η_X : A → P
    # and then G(id_X) ∘ η_X = id_P ∘ d is not composable
    assert sorted(db.naturality_violations("eta"), key=str) == sorted(
        [("component_typing", None), ("naturality_composite_missing", db.ids["id_X"])], key=str)
    details = db.one("SELECT details FROM naturality_violation WHERE law = 'component_typing'")
    assert details["expected"] == [db.ids["A"], db.ids["P"]]
    assert details["actual"] == [db.ids["A"], db.ids["Q"]]


def test_component_from_the_source_category_is_refused_in_strict_mode(db):
    _square(db)
    db.nt("eta", "F", "G")
    db.set_mode("strict")
    savepoint_raises(db, "Naturality law violated", "INSERT INTO natural_transformation_component "
                     "(transformation_id, object_id, morphism_id) VALUES (%s, %s, %s)",
                     db.ids["eta"], db.ids["X"], db.ids["f"])


def test_component_on_a_foreign_object_is_reported(db):
    _square(db)
    db.nt("eta", "F", "G")
    db.component("eta", "A", "id_A")                 # A is an object of D, not of C
    assert db.naturality_violations("eta") == [("component_unknown_object", None)]
    db.q("DELETE FROM naturality_violation")
    db.q("SELECT check_natural_transformation(%s)", db.ids["eta"])
    assert laws(db, "eta") == Counter({"component_unknown_object": 1, "component_missing": 2,
                                       "naturality_missing_data": 3})


def test_mismatched_functors_are_reported_and_refused(db):
    _square(db)
    db.category("E")
    db.obj("E", "Z")
    db.functor("H", "E", "D", {"Z": "A"}, {"id_Z": "id_A"})
    db.nt("eta", "F", "H")
    assert db.naturality_violations("eta") == [("transformation_typing", None)]
    savepoint_raises(db, "transformation_typing",
                     "SELECT register_natural_transformation('eta2', %s, %s)", db.ids["F"], db.ids["H"])
    db.set_mode("strict")
    savepoint_raises(db, "not well typed", "INSERT INTO natural_transformation "
                     "(name, source_functor_id, target_functor_id) VALUES ('eta3', %s, %s)",
                     db.ids["F"], db.ids["H"])


def test_unmapped_morphism_is_reported(db):
    _square(db)
    db.q("DELETE FROM functor_morphism_map WHERE source_morphism_id = %s", db.ids["f"])
    db.nt("eta", "F", "G", {"X": "ex", "Y": "ey"})
    assert db.naturality_violations("eta") == [("naturality_missing_data", db.ids["f"])]


def test_identity_square_and_composability_are_checked(db):
    """F(id_X) = id_B (an identity of the wrong object): the earlier nt_compose
    'composed' η_X ∘ id_B to η_X and the identity square was never looked at."""
    _square(db)
    db.q("UPDATE functor_morphism_map SET target_morphism_id = %s "
         "WHERE functor_id = %s AND source_morphism_id = %s", db.ids["id_B"], db.ids["F"], db.ids["id_X"])
    db.q("DELETE FROM naturality_violation")
    db.nt("eta", "F", "G", {"X": "ex", "Y": "ey"})
    assert db.naturality_violations("eta") == [("naturality_composite_missing", db.ids["id_X"])]


def test_batch_reports_missing_components(db):
    _square(db)
    db.nt("eta", "F", "G", {"X": "ex"})
    assert db.naturality_violations("eta") == []      # incremental: nothing checkable yet
    assert db.one("SELECT check_natural_transformation(%s)", db.ids["eta"]) is False
    assert laws(db, "eta") == Counter({"component_missing": 1, "naturality_missing_data": 2})


def test_writers_refuse_ill_typed_components(db):
    _square(db)
    tid = db.one("SELECT register_natural_transformation('eta', %s, %s)", db.ids["F"], db.ids["G"])
    db.ids["eta"] = tid
    savepoint_raises(db, "component_typing", "SELECT register_nt_component(%s, %s, %s)",
                     tid, db.ids["X"], db.ids["d"])
    savepoint_raises(db, "component_unknown_object", "SELECT register_nt_component(%s, %s, %s)",
                     tid, db.ids["A"], db.ids["id_A"])
    savepoint_raises(db, "not found", "SELECT register_nt_component(gen_random_uuid(), %s, %s)",
                     db.ids["X"], db.ids["ex"])
    savepoint_raises(db, "blank name", "SELECT register_natural_transformation(' ', %s, %s)",
                     db.ids["F"], db.ids["G"])
    db.q("SELECT register_nt_component(%s, %s, %s)", tid, db.ids["X"], db.ids["ex"])
    db.q("SELECT register_nt_component(%s, %s, %s)", tid, db.ids["Y"], db.ids["ey"])
    assert db.naturality_violations("eta") == []
    assert db.one("SELECT check_natural_transformation(%s)", tid) is True


# ---------------------------------------------------------------------------
# Random instances: the database reports what the reference reports
# ---------------------------------------------------------------------------
class _Table(EnforcedFunctor):
    def __init__(self, fid, source, target, objs, mors):
        super().__init__(fid, fid, source, target, mode=EnforcementMode.PERMISSIVE)
        self.object_map.update(objs)
        self.morphism_map.update(mors)


def _random_instance(rng, p):
    """Names (prefixed by p) of a random C, D, F, G : C → D and components."""
    inst = {"C_objs": [f"{p}x{i}" for i in range(rng.randint(1, 3))],
            "D_objs": [f"{p}a{i}" for i in range(rng.randint(1, 3))]}
    inst["C_mors"] = {f"{p}f{i}": (rng.choice(inst["C_objs"]), rng.choice(inst["C_objs"]))
                      for i in range(rng.randint(0, 3))}
    inst["D_mors"] = {f"{p}m{i}": (rng.choice(inst["D_objs"]), rng.choice(inst["D_objs"]))
                      for i in range(rng.randint(2, 7))}
    d_all = dict(inst["D_mors"])
    d_all.update({f"id_{a}": (a, a) for a in inst["D_objs"]})
    comps = {}
    names = sorted(inst["D_mors"])
    for _ in range(rng.randint(0, 8)):
        f, g = rng.choice(names), rng.choice(names)
        if d_all[f][1] != d_all[g][0] or (f, g) in comps:
            continue
        cands = [h for h, st in sorted(d_all.items()) if st == (d_all[f][0], d_all[g][1])]
        if cands:
            comps[(f, g)] = rng.choice(cands)
    inst["D_comps"] = comps
    c_all = dict(inst["C_mors"])
    c_all.update({f"id_{x}": (x, x) for x in inst["C_objs"]})
    inst["C_all"], inst["D_all"] = c_all, d_all

    def functor():
        objs = {x: rng.choice(inst["D_objs"]) for x in inst["C_objs"] if rng.random() < 0.93}
        mors = {}
        for m, (s, t) in sorted(c_all.items()):
            r = rng.random()
            if r < 0.07:
                continue
            if m.startswith("id_") and s in objs and r < 0.85:
                mors[m] = f"id_{objs[s]}"
            else:
                typed = [n for n, st in sorted(d_all.items())
                         if s in objs and t in objs and st == (objs[s], objs[t])]
                mors[m] = rng.choice(typed) if typed and r < 0.8 else rng.choice(sorted(d_all))
        return objs, mors

    inst["F"], inst["G"] = functor(), functor()
    comps = {}
    for x in inst["C_objs"]:
        r = rng.random()
        fx, gx = inst["F"][0].get(x), inst["G"][0].get(x)
        typed = [n for n, st in sorted(d_all.items()) if st == (fx, gx)]
        if r < 0.12:
            continue
        if typed and r < 0.8:
            comps[x] = rng.choice(typed)
        elif r < 0.95:
            comps[x] = rng.choice(sorted(d_all))
        else:
            comps[x] = rng.choice(sorted(c_all))            # wrong category
    inst["eta"] = comps
    return inst


def _load(db, inst, p):
    db.category(p + "C")
    db.category(p + "D")
    for x in inst["C_objs"]:
        db.obj(p + "C", x)
    for a in inst["D_objs"]:
        db.obj(p + "D", a)
    for m, (s, t) in sorted(inst["C_mors"].items()):
        db.mor(m, s, t)
    for m, (s, t) in sorted(inst["D_mors"].items()):
        db.mor(m, s, t)
    for (f, g), h in sorted(inst["D_comps"].items()):
        db.comp(g, f, h)
    db.functor(p + "F", p + "C", p + "D", *inst["F"])
    db.functor(p + "G", p + "C", p + "D", *inst["G"])


def _model(inst, p):
    C, D = Category(p + "C", p + "C"), Category(p + "D", p + "D")
    for x in inst["C_objs"]:
        C.add_object(x, x)
        C.add_identity(x, f"id_{x}")
    for a in inst["D_objs"]:
        D.add_object(a, a)
        D.add_identity(a, f"id_{a}")
    for m, (s, t) in inst["C_mors"].items():
        C.add_morphism(m, s, t)
    for m, (s, t) in inst["D_mors"].items():
        D.add_morphism(m, s, t)
    for (f, g), h in inst["D_comps"].items():
        D.add_composition(f, g, h)
    F = _Table(p + "F", C, D, *inst["F"])
    G = _Table(p + "G", C, D, *inst["G"])
    return NaturalTransformation(p + "eta", "eta", F, G, mode=EnforcementMode.PERMISSIVE)


def _key(law, d, name):
    """Comparable summary of a problem; d maps reference keys to names."""
    if law in ("component_missing", "component_unknown_object"):
        return (law, name(d.get("X", d.get("obj_id"))))
    if law == "component_typing":
        return (law, name(d.get("X", d.get("obj_id"))), name(d.get("eta_x")))
    return (law, name(d.get("f")), name(d.get("left", d.get("eta_y∘Ff"))),
            name(d.get("right", d.get("Gf∘eta_x"))))


def _db_keys(db, nt):
    back = {v: k for k, v in db.ids.items()}
    rows = db.q("SELECT law, details FROM naturality_violation WHERE transformation_id = %s",
                db.ids[nt])
    return Counter(_key(law, d, lambda u: back.get(u, u)) for law, d in rows)


def _ref_keys(nt):
    return Counter(_key(v["law"], v["details"], lambda n: n) for v in nt.violations)


def test_batch_check_matches_reference(db):
    rng = random.Random(4)
    seen = Counter()
    for i in range(150):
        p = f"b{i}_"
        inst = _random_instance(rng, p)
        _load(db, inst, p)
        db.nt(p + "eta", p + "F", p + "G")
        for x, m in sorted(inst["eta"].items()):
            db.component(p + "eta", x, m)
        db.q("DELETE FROM naturality_violation WHERE transformation_id = %s", db.ids[p + "eta"])
        ok = db.one("SELECT check_natural_transformation(%s)", db.ids[p + "eta"])
        ref = _model(inst, p)
        ref.components.update(inst["eta"])
        assert ok == ref.verify_all_laws()
        assert _db_keys(db, p + "eta") == _ref_keys(ref), i
        seen.update(k[0] for k in _ref_keys(ref))
        seen["ok" if ok else "not_ok"] += 1
    for law in ("component_missing", "component_typing", "naturality_missing_data",
                "naturality_composite_missing", "naturality_square", "ok"):
        assert seen[law] > 0, (law, seen)


def test_incremental_checks_match_reference(db):
    rng = random.Random(40)
    seen = Counter()
    for i in range(150):
        p = f"w{i}_"
        inst = _random_instance(rng, p)
        order = sorted(inst["eta"].items())
        rng.shuffle(order)
        if rng.random() < 0.1:
            order.insert(rng.randint(0, len(order)), (rng.choice(inst["D_objs"]), "id_" + inst["D_objs"][0]))
        _load(db, inst, p)
        db.nt(p + "eta", p + "F", p + "G")
        ref = _model(inst, p)
        for x, m in order:
            db.component(p + "eta", x, m)
            ref.set_component(x, m)
        assert _db_keys(db, p + "eta") == _ref_keys(ref), i
        seen.update(k[0] for k in _ref_keys(ref))
    for law in ("component_typing", "component_unknown_object", "naturality_missing_data",
                "naturality_composite_missing", "naturality_square"):
        assert seen[law] > 0, (law, seen)


# ---------------------------------------------------------------------------
# Re-applying the migration, and upgrading from the version before sprint 14
# ---------------------------------------------------------------------------
def test_migration_is_reapplicable(db):
    _square(db, commuting=False)
    db.nt("eta", "F", "G", {"X": "ex", "Y": "ey"})
    with db.conn.cursor() as cur:
        cur.execute(MIGRATION.read_text())
    db.q("DELETE FROM naturality_violation")
    assert db.one("SELECT check_natural_transformation(%s)", db.ids["eta"]) is False
    assert db.naturality_violations("eta") == [("naturality_square", db.ids["f"])]


def test_upgrade_from_the_earlier_version(db):
    """In a fresh schema: the earlier 004, an ill-typed component it accepted,
    then the rewrite, whose batch check reports it."""
    _square(db)
    with db.conn.cursor() as cur:
        cur.execute("CREATE SCHEMA nt_upgrade; SET LOCAL search_path = nt_upgrade, public")
        cur.execute(ORIGINAL.read_text())
        cur.execute("INSERT INTO natural_transformation (name, source_functor_id, target_functor_id) "
                    "VALUES ('old', %s, %s) RETURNING id", (db.ids["F"], db.ids["G"]))
        tid = cur.fetchone()[0]
        cur.execute("INSERT INTO natural_transformation_component (transformation_id, object_id, "
                    "morphism_id) VALUES (%s, %s, %s), (%s, %s, %s)",
                    (tid, db.ids["X"], db.ids["f"], tid, db.ids["Y"], db.ids["ey"]))
        cur.execute("SELECT law FROM naturality_violation")
        assert "component_typing" not in {r[0] for r in cur.fetchall()}   # not seen before
        cur.execute(MIGRATION.read_text())
        cur.execute("DELETE FROM naturality_violation")
        cur.execute("SELECT check_natural_transformation(%s)", (tid,))
        assert cur.fetchone()[0] is False
        cur.execute("SELECT law, coalesce(details->>'f', details->>'X') FROM naturality_violation")
        got = set(cur.fetchall())
        assert ("component_typing", db.ids["X"]) in got
        assert ("naturality_composite_missing", db.ids["f"]) in got
