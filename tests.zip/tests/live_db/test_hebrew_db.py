"""Migration 014 (Hebrew primacy: letters, words, gematria functors, Torah
sites, language adjunctions) on a real PostgreSQL.

The reference is ``qbx.hebrew``: on random inputs the database reports exactly
the problems the Python code reports, with the same details.

Formal backing: ``Formal/Gematria.lean`` — ``wordValue_append`` (the
naturality square commutes for every scheme), ``additive_eq_wordValue`` (a
scheme is its 27 letter values), ``obligation_value_mismatch_of_square`` (a
failed square comes with a wrong value), ``standard_injective`` /
``final_ne_base`` (the seed), and ``textSheaf_locality_and_gluing`` /
``textSheaf_subsingleton`` / ``textSheaf_nonempty_iff`` (the passage presheaf
is a sheaf with one section exactly over the opens whose verses all have a
text) are used as oracles below.
"""

from __future__ import annotations

import json
import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx.hebrew.functor import (
    functor_problems,
    functor_value,
    letter_values,
    obligation_problems,
    rules_problems,
)
from qbx.hebrew.gematria import GEMATRIA, gematria_value, gematria_vector
from qbx.hebrew.text import LETTER_TABLE, letter_table_problems, text_problems, word_row_problems
from qbx.hebrew.torah import (
    language_adjunction_problems,
    passage_label,
    passage_sections,
    section_problems,
    verse_ref_problems,
)
from tests.hebrew_examples import (
    LETTERS,
    random_language_case,
    random_obligation,
    random_root,
    random_rules,
    random_text,
    random_verse_ref,
)
from tests.live_db.test_adjunction_db import _adjunction

VERSE_TEXTS = ["בְּרֵאשִׁית בָּרָא אֱלֹהִים", "אֵת הַשָּׁמַיִם וְאֵת הָאָרֶץ׃", "וְהָאָרֶץ הָיְתָה תֹהוּ וָבֹהוּ",
               "וַיֹּאמֶר אֱלֹהִים יְהִי אוֹר", "עַל־פְּנֵי הַמָּיִם׃"]


def rows(db, sql, *args):
    return [tuple(r) for r in db.q(sql, *args)]


def violations(db, table=None):
    if table is None:
        return rows(db, "SELECT reason, details FROM hebrew_violation ORDER BY detected_at, id")
    return rows(db, "SELECT reason, details FROM hebrew_violation WHERE subject_table = %s",
                table)


def savepoint_raises(db, match, sql, *args):
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match=match):
        db.q(sql, *args)
    db.q("ROLLBACK TO SAVEPOINT s")


def vec(v):
    return "[" + ",".join(repr(float(x)) for x in v) + "]"


# ---------------------------------------------------------------------------
# The seed (standard_injective, final_ne_base)
# ---------------------------------------------------------------------------
def test_seed_is_the_python_and_lean_table(db):
    got = rows(db, "SELECT letter, gematria_value, ordinal, is_final FROM hebrew_letter "
                   "ORDER BY ordinal")
    assert got == list(LETTER_TABLE)
    assert rows(db, "SELECT * FROM hebrew_seed_letters() ORDER BY ordinal") == list(LETTER_TABLE)
    assert rows(db, "SELECT * FROM hebrew_letter_table_problems()") == []
    assert db.one("SELECT check_hebrew_letters()") is True


def test_letter_table_changes_are_reported(db):
    """The original accepted any change (א = 7, a letter 'X' = −5)."""
    db.q("UPDATE hebrew_letter SET gematria_value = 7 WHERE letter = 'א'")
    db.q("INSERT INTO hebrew_letter (letter, gematria_value, ordinal) VALUES ('X', -5, 99)")
    db.q("DELETE FROM hebrew_letter WHERE letter = 'ץ'")
    db.q("UPDATE hebrew_letter SET is_final = NULL WHERE letter = 'ם'")
    table = rows(db, "SELECT letter, gematria_value, ordinal, is_final FROM hebrew_letter")
    expected = letter_table_problems(table)
    assert rows(db, "SELECT * FROM hebrew_letter_table_problems()") == expected
    assert [r for r, _ in expected] == ["letter_value", "letter_value", "letter_missing",
                                        "letter_unknown"]
    # each statement was checked when it ran; the last one logged the final state
    assert violations(db, "hebrew_letter")[-len(expected):] == expected
    db.set_mode("strict")
    savepoint_raises(db, "differs from the seed",
                     "UPDATE hebrew_letter SET ordinal = 3 WHERE letter = 'ב'")


def test_random_letter_tables_agree(db):
    rng = random.Random(1411)
    seen = Counter()
    for i in range(40):
        db.q("SAVEPOINT t")
        for _ in range(rng.randint(1, 3)):
            letter = rng.choice(LETTERS)
            act = rng.random()
            if act < 0.3:
                db.q("UPDATE hebrew_letter SET gematria_value = %s WHERE letter = %s",
                     rng.randint(-5, 1000), letter)
            elif act < 0.5:
                db.q("UPDATE hebrew_letter SET ordinal = %s WHERE letter = %s",
                     rng.randint(1, 30), letter)
            elif act < 0.65:
                db.q("UPDATE hebrew_letter SET is_final = %s WHERE letter = %s",
                     rng.choice([True, False, None]), letter)
            elif act < 0.8:
                db.q("DELETE FROM hebrew_letter WHERE letter = %s", letter)
            else:
                db.q("INSERT INTO hebrew_letter (letter, gematria_value, ordinal) "
                     "VALUES (%s, 1, 1) ON CONFLICT DO NOTHING",
                     rng.choice(["X", "ﬠ", "\u05B8", "אא", "Ω"]))
        table = rows(db, "SELECT letter, gematria_value, ordinal, is_final FROM hebrew_letter")
        got = rows(db, "SELECT * FROM hebrew_letter_table_problems()")
        assert got == letter_table_problems(table)
        seen.update(r for r, _ in got)
        db.q("ROLLBACK TO SAVEPOINT t")
    assert set(seen) == {"letter_value", "letter_missing", "letter_unknown"}


# ---------------------------------------------------------------------------
# Words
# ---------------------------------------------------------------------------
def test_text_checks_agree(db):
    rng = random.Random(1401)
    seen = Counter()
    for i in range(1500):
        kind = "word" if i % 2 == 0 else "verse"
        t = random_text(rng, kind)
        got = rows(db, "SELECT reason, details FROM hebrew_text_problems(%s, %s)", t, kind)
        assert got == text_problems(t, kind), t
        seen.update(d["error"] for _, d in got)
    assert set(seen) == {"empty", "non_nfc", "character", "leading_mark", "no_letter"}


def test_seed_value_and_vector_agree(db):
    rng = random.Random(1402)
    for _ in range(300):
        t = random_text(rng, "word")
        assert db.one("SELECT hebrew_seed_value(%s)", t) == gematria_value(t)
        assert db.one("SELECT compute_gematria(%s)", t) == gematria_value(t)
    for t in ("שלום", "", "תורה", "ab"):
        assert db.one("SELECT hebrew_gematria_vector(%s)", t) == gematria_vector(t)


def test_word_rows_agree(db):
    """Random rows, written directly (the total trigger off for half of them)."""
    rng = random.Random(1403)
    seen = Counter()
    for i in range(300):
        if i == 150:
            db.q("ALTER TABLE hebrew_word DISABLE TRIGGER trg_hebrew_word_gematria")
        text = random_text(rng, "word")
        root = random_root(rng)
        total = rng.choice([gematria_value(text), rng.randint(0, 2000), None])
        r = rng.random()
        emb = None
        if r < 0.3:
            emb = gematria_vector(text)
        elif r < 0.6:
            emb = list(gematria_vector(text))
            k = rng.randrange(256)
            emb[k] = rng.choice([x / 128 for x in range(-128, 128) if x / 128 != emb[k]])
        wid = db.one("INSERT INTO hebrew_word (text, root, total_gematria, embedding_vector) "
                     "VALUES (%s, %s, %s, %s::vector) RETURNING id", text, root, total,
                     None if emb is None else vec(emb))
        stored = db.q("SELECT total_gematria, embedding_vector::real[] FROM hebrew_word "
                      "WHERE id = %s", wid)[0]
        if i < 150:
            assert stored[0] == gematria_value(text)      # the trigger recomputes
        got = rows(db, "SELECT reason, details FROM hebrew_word_problems(%s)", wid)
        assert got == word_row_problems(text, root, stored[0], stored[1])
        seen.update(r for r, _ in got)
    assert set(seen) == {"word_typing", "root_typing", "gematria_mismatch", "embedding_mismatch"}


def test_original_bug_total_cannot_be_forged(db):
    """The original recomputed the total only on UPDATE OF text."""
    wid = db.one("SELECT register_hebrew_word('שלום')")
    db.q("UPDATE hebrew_word SET total_gematria = 1 WHERE id = %s", wid)
    assert db.one("SELECT total_gematria FROM hebrew_word WHERE id = %s", wid) == 936
    assert db.one("SELECT check_hebrew_word(%s)", wid) is True


def test_original_bug_stale_totals_are_reported(db):
    """A total written before the letter table changed is reported in batch."""
    wid = db.one("SELECT register_hebrew_word('אב')")
    db.q("UPDATE hebrew_letter SET gematria_value = 7 WHERE letter = 'א'")
    db.q("UPDATE hebrew_word SET root = NULL WHERE id = %s", wid)   # recomputed: 9
    assert db.one("SELECT total_gematria FROM hebrew_word WHERE id = %s", wid) == 9
    assert db.one("SELECT check_hebrew_word(%s)", wid) is False
    assert ("gematria_mismatch", {"recorded": 9, "computed": 3}) in violations(db, "hebrew_word")


def test_original_bug_non_words_are_refused(db):
    savepoint_raises(db, "word_typing", "SELECT register_hebrew_word('hello world 123')")
    savepoint_raises(db, "root_typing", "SELECT register_hebrew_word('שלום', '!!')")
    savepoint_raises(db, "non_nfc", "SELECT register_hebrew_word(%s)", "\uFB2A")
    # direct inserts are logged, and raise in strict mode
    db.q("INSERT INTO hebrew_word (text) VALUES ('abc')")
    assert ("word_typing", {"error": "no_letter"}) in violations(db, "hebrew_word")
    db.set_mode("strict")
    savepoint_raises(db, "not well formed", "INSERT INTO hebrew_word (text) VALUES ('abc')")


def test_embeddings(db):
    """Rule R4: a stored embedding must be gematria_vector(text)."""
    wid = db.one("SELECT register_hebrew_word('תורה')")
    db.q("SELECT store_hebrew_embedding(%s)", wid)
    assert db.one("SELECT embedding_vector::real[] FROM hebrew_word WHERE id = %s",
                  wid) == gematria_vector("תורה")
    assert db.one("SELECT check_hebrew_word(%s)", wid) is True
    db.q("UPDATE hebrew_word SET embedding_vector = %s::vector WHERE id = %s",
         vec([0.5] * 256), wid)
    assert db.one("SELECT check_hebrew_word(%s)", wid) is False


# ---------------------------------------------------------------------------
# Gematria functors and naturality obligations
# ---------------------------------------------------------------------------
def test_rules_agree(db):
    rng = random.Random(1404)
    seen = Counter()
    for _ in range(400):
        rules = random_rules(rng)
        got = rows(db, "SELECT reason, details FROM gematria_rules_problems(%s::jsonb)",
                   json.dumps(rules))
        assert got == rules_problems(rules), rules
        seen.update(d["error"] for _, d in got)
        t = random_text(rng)
        assert db.one("SELECT gematria_rules_value(%s::jsonb, %s)", json.dumps(rules),
                      t) == functor_value(rules, t)
    assert set(seen) == {"not_object", "unknown_letter", "value", "missing"}


def test_obligations_agree(db):
    rng = random.Random(1405)
    seen = Counter()
    for _ in range(500):
        rules = random_rules(rng)
        left, right, lv, rv, cv = random_obligation(rng, rules)
        got = rows(db, "SELECT reason, details FROM gematria_obligation_values_problems("
                       "%s::jsonb, %s, %s, %s, %s, %s)", json.dumps(rules), left, right, lv, rv, cv)
        expected = obligation_problems(rules, left, right, lv, rv, cv)
        assert got == expected
        reasons = [r for r, _ in got]
        seen.update(reasons)
        # obligation_value_mismatch_of_square
        if "naturality_square" in reasons and letter_values(rules) is not None:
            assert "naturality_value" in reasons
    assert set(seen) == {"obligation_typing", "naturality_value", "naturality_square"}


def test_naturality_square_commutes_in_the_database(db):
    """``wordValue_append`` for random valid schemes, computed by the database."""
    rng = random.Random(1406)
    n = 0
    while n < 60:
        rules = random_rules(rng)
        if letter_values(rules) is None:
            continue
        u, w = random_text(rng), random_text(rng)
        r = json.dumps(rules)
        a, b, c = db.q("SELECT gematria_rules_value(%s::jsonb, %s), gematria_rules_value("
                       "%s::jsonb, %s), gematria_rules_value(%s::jsonb, %s)",
                       r, u, r, w, r, u + w)[0]
        assert a + b == c
        n += 1


def _functor(db, name="gem", rules="{}"):
    for cat in ("Words", "Numbers"):
        if cat not in db.ids:
            db.category(cat)
    return db.one("SELECT register_gematria_functor(%s, %s, %s, %s::jsonb, NULL)", name,
                  db.ids["Words"], db.ids["Numbers"], rules)


def test_functor_lifecycle(db):
    fid = _functor(db)
    # R2: a functor without an obligation is reported in batch
    assert db.one("SELECT check_gematria_functor(%s)", fid) is False
    assert violations(db, "gematria_functor") == [("naturality_missing", {})]
    oid = db.one("SELECT record_gematria_obligation(%s, 'של', 'ום')", fid)
    assert db.q("SELECT left_value, right_value, concat_value FROM gematria_obligation "
                "WHERE id = %s", oid)[0] == (330, 606, 936)
    db.q("DELETE FROM hebrew_violation")
    assert db.one("SELECT check_gematria_functor(%s)", fid) is True
    assert db.one("SELECT gematria_functor_value(%s, 'שלום')", fid) == 936
    # claimed values are checked by the writer, and by the row checks
    savepoint_raises(db, "naturality_value",
                     "SELECT record_gematria_obligation(%s, 'של', 'ום', 330, 606, 937)", fid)
    db.q("INSERT INTO gematria_obligation (functor_id, left_text, right_text, left_value, "
         "right_value, concat_value) VALUES (%s, 'א', 'ב', 1, 2, 4)", fid)
    assert db.one("SELECT check_gematria_functor(%s)", fid) is False
    assert sorted(r for r, _ in violations(db, "gematria_obligation")) == [
        "naturality_square", "naturality_square", "naturality_value", "naturality_value"]


def test_functor_rows_agree(db):
    rng = random.Random(1407)
    db.category("Words")
    db.category("Numbers")
    cats = [None, db.ids["Words"], db.ids["Numbers"]]
    seen = Counter()
    for i in range(80):
        base, target = rng.choice(cats), rng.choice(cats)
        rules = random_rules(rng)
        fid = db.one("INSERT INTO gematria_functor (name, base_category_id, target_category_id, "
                     "mapping_rules) VALUES (%s, %s, %s, %s::jsonb) RETURNING id",
                     "f%d" % i, base, target, json.dumps(rules))
        n_ob = 0
        for _ in range(rng.randint(0, 2)):
            left, right, lv, rv, cv = random_obligation(rng, rules)
            oid = db.one("INSERT INTO gematria_obligation (functor_id, left_text, right_text, "
                         "left_value, right_value, concat_value) VALUES (%s, %s, %s, %s, %s, %s) "
                         "RETURNING id", fid, left, right, lv, rv, cv)
            n_ob += 1
            got = rows(db, "SELECT reason, details FROM gematria_obligation_problems(%s)", oid)
            assert got == obligation_problems(rules, left, right, lv, rv, cv)
        stored = db.one("SELECT mapping_rules FROM gematria_functor WHERE id = %s", fid)
        for batch, obl in ((False, None), (True, n_ob)):
            got = rows(db, "SELECT reason, details FROM gematria_functor_problems(%s, %s)",
                       fid, batch)
            assert got == functor_problems(base, target, stored, obl)
            seen.update(r for r, _ in got)
    assert set(seen) == {"functor_typing", "functor_rules", "naturality_missing"}


def test_original_bug_functor_rules_are_checked(db):
    """The original accepted rules {"א": -3, "zz": "x"} and no categories."""
    savepoint_raises(db, "functor_rules",
                     "SELECT register_gematria_functor('g', NULL, NULL, %s::jsonb, NULL)",
                     json.dumps({"א": -3, "zz": "x"}))
    savepoint_raises(db, "base_category",
                     "SELECT register_gematria_functor('g', NULL, NULL, '{}', NULL)")
    db.category("Words")
    savepoint_raises(db, "same_category",
                     "SELECT register_gematria_functor('g', %s, %s, '{}', NULL)",
                     db.ids["Words"], db.ids["Words"])
    # a custom total scheme (mispar katan-like values) is a valid functor
    rules = {l: (v % 9) or 9 for l, v in GEMATRIA.items()}
    fid = _functor(db, "katan", json.dumps(rules))
    db.q("SELECT record_gematria_obligation(%s, 'של', 'ום')", fid)
    assert db.one("SELECT check_gematria_functor(%s)", fid) is True


# ---------------------------------------------------------------------------
# Torah sites and sections
# ---------------------------------------------------------------------------
def test_verse_refs_and_sections_agree(db):
    rng = random.Random(1408)
    seen = Counter()
    for _ in range(600):
        ref = random_verse_ref(rng)
        got = rows(db, "SELECT reason, details FROM torah_verse_ref_problems(%s)", ref)
        assert got == verse_ref_problems(ref), ref
        text = random_text(rng, "verse")
        points = rng.choice([None, [], [ref], ["Genesis 1:1", ref], ["Exodus 2:3"]])
        got = rows(db, "SELECT reason, details FROM torah_section_values_problems(%s, %s, "
                       "%s::text[])", ref, text, points)
        assert got == section_problems(ref, text, points)
        seen.update(r if r != "verse_ref_format" else d["error"] for r, d in got)
    assert {"syntax", "book", "chapter", "verse_not_point", "section_text_typing"} <= set(seen)


def _closure(sets):
    sets = {frozenset(s) for s in sets}
    while True:
        new = {a | b for a in sets for b in sets} | {a & b for a in sets for b in sets}
        if new <= sets:
            return sets
        sets |= new


def _torah_site(db, name, points, opens, texts, cover=True):
    """A finite site on `points` with the given opens, a Torah site on it and
    the sections `texts`; returns (torah site id, site id, {open name: points})."""
    if "Top" not in db.ids:
        db.category("Top")
    names = {}
    for i, o in enumerate(sorted(opens, key=lambda s: (len(s), sorted(s)))):
        n = "%s_U%d" % (name, i)
        db.obj("Top", n)
        names[n] = sorted(o)
    base = next(n for n, pts in names.items() if set(pts) == set(points))
    sid = db.one("SELECT register_site(%s, %s)", name, db.ids[base])
    for n, pts in names.items():
        db.q("SELECT register_site_open(%s, %s, %s::text[])", sid, db.ids[n], pts)
    proper = [n for n in names if n != base and names[n]]
    if cover and proper and set().union(*(set(names[n]) for n in proper)) == set(points):
        db.q("SELECT register_site_cover(%s, 'proper', %s, %s::uuid[])", sid, db.ids[base],
             [db.ids[n] for n in proper])
    tid = db.one("SELECT register_torah_site(%s, %s)", "torah:" + name, sid)
    for ref, text in texts.items():
        db.q("SELECT register_torah_section(%s, %s, %s)", tid, ref, text)
    return tid, sid, names


def _sections(db, pid, names):
    return {n: sorted(r[0] for r in db.q("SELECT label FROM presheaf_section WHERE "
                                         "presheaf_id = %s AND open_object_id = %s",
                                         pid, db.ids[n]))
            for n in names}


def test_passage_presheaf_is_a_sheaf(db):
    """``textSheaf_locality_and_gluing``, ``textSheaf_subsingleton`` and
    ``textSheaf_nonempty_iff`` on random finite sites."""
    rng = random.Random(1409)
    refs = ["Genesis 1:%d" % i for i in range(1, 5)]
    for i in range(15):
        pts = refs[:rng.randint(1, 4)]
        subsets = [set(rng.sample(pts, rng.randint(0, len(pts)))) for _ in range(rng.randint(1, 3))]
        opens = _closure(subsets + [set(), set(pts)])
        texts = {p: rng.choice(VERSE_TEXTS) for p in pts if rng.random() < 0.7}
        tid, sid, names = _torah_site(db, "S%d" % i, pts, opens, texts)
        pid = db.one("SELECT build_torah_presheaf(%s)", tid)
        assert db.one("SELECT presheaf_id FROM torah_site WHERE id = %s", tid) == pid
        secs = _sections(db, pid, names)
        assert secs == passage_sections(names, texts)
        for n, pts_n in names.items():
            assert len(secs[n]) <= 1
            assert (len(secs[n]) == 1) == all(p in texts for p in pts_n)
        assert db.one("SELECT check_torah_site(%s)", tid) is True
        assert db.one("SELECT is_sheaf FROM presheaf WHERE id = %s", pid) is True
    assert violations(db) == []


def test_torah_site_problems(db):
    db.category("Top")
    pts = ["Genesis 1:1", "Genesis 1:2"]
    opens = [set(), {"Genesis 1:1"}, set(pts)]
    tid, sid, names = _torah_site(db, "T", pts, opens, {"Genesis 1:1": VERSE_TEXTS[0]})
    assert violations(db, "torah_site") == []        # under construction: batch only
    assert db.one("SELECT check_torah_site(%s)", tid) is False
    assert violations(db, "torah_site") == [("torah_no_presheaf", {})]
    pid = db.one("SELECT build_torah_presheaf(%s)", tid)
    db.q("DELETE FROM hebrew_violation")
    assert db.one("SELECT check_torah_site(%s)", tid) is True
    # a second section over the singleton {Genesis 1:1}: not a sheaf, and not the verse text
    single = next(n for n, p in names.items() if p == ["Genesis 1:1"])
    db.q("INSERT INTO presheaf_section (presheaf_id, open_object_id, label) VALUES "
         "(%s, %s, 'other')", pid, db.ids[single])
    assert db.one("SELECT check_torah_site(%s)", tid) is False
    assert violations(db, "torah_site") == [
        ("torah_not_sheaf", {"presheaf": pid}),
        ("torah_section_mismatch", {"verse": "Genesis 1:1"})]
    # a presheaf of another site
    tid2, sid2, _ = _torah_site(db, "T2", pts, opens, {})
    db.q("DELETE FROM hebrew_violation")
    db.q("UPDATE torah_site SET presheaf_id = %s WHERE id = %s", pid, tid2)
    assert violations(db, "torah_site") == [("torah_presheaf_typing", {"presheaf": pid})]


def test_original_bug_flat_corpus_and_bad_sections(db):
    """The original accepted a site with no sheaf and a section 'nonsense 999'."""
    tid = db.one("INSERT INTO torah_site (name) VALUES ('flat') RETURNING id")
    assert violations(db, "torah_site") == [("torah_no_site", {})]
    db.q("INSERT INTO torah_section (site_id, verse_ref, section_text) "
         "VALUES (%s, 'nonsense 999', 'abc')", tid)
    assert [r for r, _ in violations(db, "torah_section")] == [
        "verse_ref_format"] + ["section_text_typing"] * 4
    savepoint_raises(db, "verse_ref_format",
                     "SELECT register_torah_section(%s, 'Genesis 51:1', 'א')", tid)
    savepoint_raises(db, "site .* not found", "SELECT register_torah_site('x', NULL)")
    db.set_mode("strict")
    savepoint_raises(db, "not well formed", "INSERT INTO torah_site (name) VALUES ('flat2')")


# ---------------------------------------------------------------------------
# Language adjunctions
# ---------------------------------------------------------------------------
def test_language_adjunctions_agree(db):
    aid = _adjunction(db)
    ms = db.morphisms["I"]
    db.functor("K", "I", "I", {"P": "P", "Q": "Q"}, {m: m for m in ms})
    lean = db.one("INSERT INTO proof_artifact (artifact_type, payload_hash) VALUES "
                  "('lean4', 'h') RETURNING id")
    coq = db.one("INSERT INTO proof_artifact (artifact_type, payload_hash) VALUES "
                 "('coq', 'h') RETURNING id")
    types = {None: None, lean: "lean4", coq: "coq"}
    rng = random.Random(1410)
    seen = Counter()
    for _ in range(300):
        left, right, status = random_language_case(rng)
        fname = rng.choice(["F", "Id", "K"])
        adj = rng.choice([None, aid])
        art = rng.choice([None, lean, coq])
        got = rows(db, "SELECT reason, details FROM language_adjunction_values_problems("
                       "%s, %s, %s, %s, %s, %s)", left, right, db.ids[fname], adj, status, art)
        expected = language_adjunction_problems(
            left, right, db.ids[fname], (db.ids["F"], db.ids["Id"]) if adj else None, status,
            types[art], art is not None)
        assert got == expected
        seen.update(r for r, _ in got)
    assert set(seen) == {"language_typing", "adjunction_mismatch", "status_value",
                         "unverified_claim"}


def test_original_bug_language_adjunctions(db):
    """The original had no status (R6) and accepted Hebrew ⊣ Hebrew."""
    aid = _adjunction(db)
    savepoint_raises(db, "same", "SELECT register_language_adjunction('Hebrew', 'Hebrew', %s)",
                     db.ids["F"])
    lid = db.one("SELECT register_language_adjunction('Hebrew', 'Greek', %s, %s)",
                 db.ids["F"], aid)
    assert db.one("SELECT status FROM language_adjunction WHERE id = %s", lid) == "provisional"
    savepoint_raises(db, "unverified_claim",
                     "SELECT register_language_adjunction('Hebrew', 'Latin', %s, NULL, "
                     "'lean_verified')", db.ids["F"])
    db.q("UPDATE language_adjunction SET status = 'lean_verified' WHERE id = %s", lid)
    assert violations(db, "language_adjunction") == [
        ("unverified_claim", {"error": "no_artifact"})]


# ---------------------------------------------------------------------------
# Batch checks, the violation view, strict mode, unknown rows
# ---------------------------------------------------------------------------
def test_batch_checks_and_view(db):
    db.q("INSERT INTO hebrew_word (text) VALUES ('abc')")
    db.q("INSERT INTO torah_site (name) VALUES ('flat')")
    db.q("DELETE FROM hebrew_violation")
    assert db.one("SELECT check_hebrew()") == 6     # 3 characters + no_letter, 2 for the site
    db.q("DELETE FROM hebrew_violation")
    db.q("SELECT run_all_batch_checks()")
    got = Counter(r for r, in db.q("SELECT violation_type FROM v_all_violations "
                                   "WHERE module = 'hebrew'"))
    assert got == Counter({"word_typing": 4, "torah_no_site": 1, "torah_no_presheaf": 1})


def test_strict_checks_raise(db):
    wid = db.one("INSERT INTO hebrew_word (text) VALUES ('abc') RETURNING id")
    db.set_mode("strict")
    savepoint_raises(db, "not valid", "SELECT check_hebrew_word(%s)", wid)
    savepoint_raises(db, "have problems", "SELECT check_hebrew()")


def test_checks_refuse_unknown_rows(db):
    for f in ("check_hebrew_word", "check_gematria_functor", "check_torah_site"):
        savepoint_raises(db, "not found", "SELECT %s(gen_random_uuid())" % f)


# ---------------------------------------------------------------------------
# Upgrade path from the original table layout
# ---------------------------------------------------------------------------
def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE torah_section, torah_site, language_adjunction, gematria_obligation, "
         "hebrew_violation CASCADE")
    db.q("""
      CREATE TABLE torah_site (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        name TEXT NOT NULL UNIQUE, base_object_id UUID REFERENCES object(id) ON DELETE SET NULL,
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE torah_section (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        site_id UUID NOT NULL REFERENCES torah_site(id) ON DELETE CASCADE,
        verse_ref TEXT NOT NULL, section_text TEXT, metadata JSONB DEFAULT '{}'::jsonb,
        UNIQUE (site_id, verse_ref));
      CREATE TABLE language_adjunction (id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        left_language TEXT NOT NULL, right_language TEXT NOT NULL,
        functor_id UUID NOT NULL REFERENCES functor(id) ON DELETE CASCADE,
        adjunction_id UUID REFERENCES adjunction(id) ON DELETE SET NULL,
        metadata JSONB DEFAULT '{}'::jsonb);
      DROP TRIGGER trg_check_hebrew_row ON hebrew_word;
      DROP TRIGGER trg_check_hebrew_row ON gematria_functor;
      DROP TRIGGER trg_check_hebrew_letters ON hebrew_letter;
    """)
    db.q("ALTER TABLE hebrew_word DISABLE TRIGGER trg_hebrew_word_gematria")
    db.q("INSERT INTO hebrew_word (text, total_gematria) VALUES ('שלום', 1)")
    tid = db.one("INSERT INTO torah_site (name) VALUES ('old') RETURNING id")
    db.q("INSERT INTO torah_section (site_id, verse_ref, section_text) "
         "VALUES (%s, 'Genesis 1:1', 'א')", tid)
    db.q("ALTER TABLE hebrew_word ENABLE TRIGGER trg_hebrew_word_gematria")
    path = Path(__file__).resolve().parents[2] / "migrations" / "014_hebrew_primacy.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    # the old rows are checked, not hidden
    assert db.one("SELECT check_hebrew()") == 3
    assert sorted(r for r, _ in violations(db)) == [
        "gematria_mismatch", "torah_no_presheaf", "torah_no_site"]
    assert db.one("SELECT count(*) FROM hebrew_letter") == 27
    assert db.one("SELECT status FROM language_adjunction LIMIT 1") is None


def test_writers_work_in_strict_mode(db):
    """The intended flows raise nothing in strict mode and pass the batch check."""
    db.set_mode("strict")
    wid = db.one("SELECT register_hebrew_word('בְּרֵאשִׁית', 'ראש')")
    db.q("SELECT store_hebrew_embedding(%s)", wid)
    fid = _functor(db)
    db.q("SELECT record_gematria_obligation(%s, 'תו', 'רה')", fid)
    pts = ["Genesis 1:1", "Genesis 1:2"]
    tid, _, _ = _torah_site(db, "strict", pts, [set(), {"Genesis 1:1"}, {"Genesis 1:2"}, set(pts)],
                            {"Genesis 1:1": VERSE_TEXTS[0], "Genesis 1:2": VERSE_TEXTS[2]})
    db.q("SELECT build_torah_presheaf(%s)", tid)
    aid = _adjunction(db)
    db.q("SELECT register_language_adjunction('Hebrew', 'Greek', %s, %s)", db.ids["F"], aid)
    assert db.one("SELECT check_hebrew()") == 0
    assert violations(db) == []
