"""Migration 022 (exact representation certificates) on a real PostgreSQL.

The reference is ``qbx_ir.representation_ledger``: on random data — including
certificates of malformed braids, invalid parameters, and certificates with
wrong hashes, dimensions, denominators and numerators — the database reports
exactly the problems the Python code reports, with the same details, in the
same order.  The equality answers, the transport check (certificates agree
along accepted rewrites and derivations) and the consistency check with the
normal-form certificates of migration 021 are compared too.

Formal backing: ``Formal/BraidRepCert.lean`` — ``repCert_eq_iff`` (equal
certificates iff equal exact matrices), ``repCert_eq_of_eval_eq`` (equal braids
have equal certificates) and ``eval_ne_of_repCert_ne`` (different certificates
prove different braids).
"""

from __future__ import annotations

import random
from collections import Counter
from fractions import Fraction
from pathlib import Path

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import left_normal_form
from qbx_ir.ledger import BraidRow, braid_problems, derivation_problems, rewrite_problems, word_hash
from qbx_ir.normal_form_ledger import NFRow
from qbx_ir.representation_ledger import (
    RepRow,
    certificate_problems,
    inequality_certified,
    nf_consistency_problems,
    representation_values,
    representations_equal,
    transport_problems,
)
from tests.live_db.test_braid_ledger_db import build_random_ledger, random_word

MIGRATION = Path(__file__).resolve().parents[2] / "migrations" / "022_braid_representations.sql"

PARAMS = [(2, 1), (3, 2), (-1, 3), (5, 7), (-2, 1)]


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def values(db, n, w, p, r):
    dim, nums, den = db.q("SELECT * FROM braid_representation_values(%s, %s::int[], %s, %s)",
                          n, w, p, r)[0]
    return dim, tuple(int(x) for x in nums), int(den)


def test_values_agree_with_python(db):
    rng = random.Random(7)
    for _ in range(120):
        n = rng.randint(1, 5)
        w = random_word(rng, n, rng.randint(0, 8)) if n > 1 else []
        p, r = rng.choice(PARAMS)
        v = representation_values(n, w, p, r)
        assert values(db, n, w, p, r) == (v.dimension, v.numerators, v.denominator), (n, w, p, r)


def test_values_on_known_braids(db):
    # σ1 on two strands at q = 2: (1/2)·[[4,0,0,0],[0,0,2,0],[0,2,3,0],[0,0,0,4]].
    assert values(db, 2, [1], 2, 1) == (4, (4, 0, 0, 0, 0, 0, 2, 0, 0, 2, 3, 0, 0, 0, 0, 4), 2)
    assert values(db, 1, [], 2, 1) == (2, (1, 0, 0, 1), 1)
    # The braid relation holds exactly.
    assert values(db, 3, [1, 2, 1], 3, 2) == values(db, 3, [2, 1, 2], 3, 2)
    # σ1σ1⁻¹ is the identity.
    assert values(db, 3, [1, -1], 5, 7) == values(db, 3, [], 5, 7)
    # The commutator σ1²σ2²σ1⁻²σ2⁻² is not (Lean: representation_detects_more).
    assert values(db, 3, [1, 1, 2, 2, -1, -1, -2, -2], 2, 1)[2] == 64


def random_rep(rng, braid: BraidRow) -> RepRow:
    """A certificate for ``braid``: usually the right one, sometimes tampered with."""
    p, r = rng.choice(PARAMS)
    if braid_problems(braid):
        return RepRow(braid, p, r, braid.braid_hash, 2, (1, 0, 0, 1), 1)
    roll = rng.random()
    if roll < 0.05:
        bad = rng.choice([(0, 1), (2, 4), (3, -1), (4, 2)])
        return RepRow(braid, bad[0], bad[1], braid.braid_hash, 2, (1, 0, 0, 1), 1)
    good = RepRow.of(braid, p, r)
    if roll < 0.11:
        return RepRow(braid, p, r, "e" * 8, good.dimension, good.numerators, good.denominator)
    if roll < 0.16:
        return RepRow(braid, p, r, good.braid_hash, good.dimension * 2, good.numerators,
                      good.denominator)
    if roll < 0.22:
        # Not reduced: the same value, but a different (non-canonical) fraction.
        return RepRow(braid, p, r, good.braid_hash, good.dimension,
                      tuple(3 * x for x in good.numerators), 3 * good.denominator)
    if roll < 0.28:
        nums = list(good.numerators)
        k = rng.randrange(len(nums))
        nums[k] += rng.choice([-1, 1])
        return RepRow(braid, p, r, good.braid_hash, good.dimension, tuple(nums), good.denominator)
    if roll < 0.32:
        return RepRow(braid, p, r, good.braid_hash, good.dimension, good.numerators[:-1],
                      good.denominator)
    return good


def insert_rep(db, bid, c: RepRow):
    return db.one(
        "INSERT INTO braid_representation (braid_id, q_num, q_den, braid_hash, dimension, "
        "numerators, denominator) VALUES (%s, %s, %s, %s, %s, %s::numeric[], %s) RETURNING id",
        bid, c.q_num, c.q_den, c.braid_hash, c.dimension, list(c.numerators), c.denominator)


def test_random_certificates_equality_transport_and_consistency_match_reference(db):
    seen = Counter()
    for seed in range(6):
        db.q("SAVEPOINT s")
        rng = random.Random(900 + seed)
        m = build_random_ledger(db, rng, n_braids=30, n_rewrites=40)
        reps = {}      # braid id -> list of RepRow
        rep_ids = []   # (braid id, cert id, RepRow)
        nfs = {}
        for bid, braid in m.braid_row.items():
            reps[bid] = []
            if not braid_problems(braid) and rng.random() < 0.8:
                db.one("SELECT certify_braid_normal_form(%s)", bid)
                nfs[bid] = NFRow.of(braid)
            for _ in range(rng.choice([1, 1, 2])):
                c = random_rep(rng, braid)
                if any(x.q == c.q for x in reps[bid]):
                    continue
                cid = insert_rep(db, bid, c)
                reps[bid].append(c)
                rep_ids.append((bid, cid, c))
                got = rows(db, "SELECT * FROM braid_representation_problems(%s)", cid)
                assert got == certificate_problems(c), (seed, c)
                seen.update(r for r, _ in got)
                if not got:
                    seen["certificate_ok"] += 1
            # A valid certificate at q = 2 for most well-formed braids (for the comparisons).
            if (not braid_problems(braid) and rng.random() < 0.8
                    and not any(x.q == (2, 1) for x in reps[bid])):
                cid = db.one("SELECT certify_braid_representation(%s)", bid)
                c = RepRow.of(braid)
                reps[bid].append(c)
                rep_ids.append((bid, cid, c))
        ids = list(m.braid_row)

        def at(bid, q):
            return next((c for c in reps.get(bid, []) if c.q == q), None)

        # Equality answers on random pairs, plus every pair of braids equal in B_n.
        canon = {bid: (row.strand_count,
                       left_normal_form(Braid.from_short_form(row.strand_count, list(row.word))))
                 for bid, row in m.braid_row.items() if not braid_problems(row)}
        pairs = [(rng.choice(ids), rng.choice(ids)) for _ in range(60)]
        pairs += [(a, b) for a in canon for b in canon if a != b and canon[a] == canon[b]]
        for a, b in pairs:
            qs = sorted({c.q for c in reps[a]} | {c.q for c in reps[b]})
            for q in qs:
                got = db.one("SELECT braid_representation_equal(%s, %s, %s, %s)", a, b, *q)
                want = representations_equal(at(a, q), at(b, q))
                assert got == want, (seed, a, b, q, got, want)
                assert db.one("SELECT braid_representation_inequality_certified(%s, %s, %s, %s)",
                              a, b, *q) == inequality_certified(at(a, q), at(b, q))
                if want is not None:
                    truth = canon[a] == canon[b]
                    if truth:
                        assert want is True          # equal braids: equal certificates
                        if a != b:
                            seen["equal_braids_distinct_words"] += 1
                    else:
                        seen["certified_different" if want is False else "rep_equal_only"] += 1
        # Consistency with the normal forms: never fires on a sound ledger.
        for bid, cid, c in rep_ids:
            got = rows(db, "SELECT * FROM braid_rep_nf_problems(%s)", cid)
            others = [(oc, nfs.get(ob)) for ob, _, oc in rep_ids]
            want = nf_consistency_problems(c, nfs.get(bid), others)
            assert got == want == [], (seed, got, want)
        # Transport along every rewrite.
        for rid, r in m.rewrite_row.items():
            ok = not rewrite_problems(r)
            a, b = m.braid_id[r.input.key], m.braid_id[r.output.key]
            got = rows(db, "SELECT * FROM braid_rewrite_rep_transport_problems(%s)", rid)
            assert got == transport_problems(ok, reps[a], reps[b]) == [], (seed, got)
            if ok and any(representations_equal(c, at(b, c.q)) for c in reps[a]):
                seen["transport_checked"] += 1
        # Transport along random derivations.
        for _ in range(15):
            src = rng.choice(ids)
            steps, dirs, cur = [], [], src
            for _ in range(rng.randint(0, 4)):
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = m.braid_id[(r.output if d else r.input).key]
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, cur, steps, dirs)
            accepted = not derivation_problems(m.braid_row[src], m.braid_row[cur],
                                               [m.rewrite_row[s] for s in steps], dirs)
            got = rows(db, "SELECT * FROM braid_derivation_rep_transport_problems(%s)", did)
            assert got == transport_problems(accepted, reps[src], reps[cur]) == []
            if accepted and steps and any(representations_equal(c, at(cur, c.q))
                                          for c in reps[src]):
                seen["derivation_transport_checked"] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("braid_not_well_formed", "parameter_invalid", "braid_hash_mismatch",
                   "dimension_mismatch", "denominator_mismatch", "numerators_mismatch",
                   "certificate_ok", "equal_braids_distinct_words", "certified_different",
                   "transport_checked", "derivation_transport_checked"):
        assert seen[reason] > 0, reason


def test_writer_and_equality(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    b = db.one("SELECT register_braid(3, ARRAY[2, 1, 2])")
    c = db.one("SELECT register_braid(3, ARRAY[1])")
    d = db.one("SELECT register_braid(3, ARRAY[2])")
    assert db.one("SELECT braid_representation_equal(%s, %s, 2, 1)", a, b) is None
    assert db.one("SELECT braid_representation_inequality_certified(%s, %s)", c, d) is False
    for x in (a, b, c, d):
        db.one("SELECT certify_braid_representation(%s)", x)
        db.one("SELECT certify_braid_representation(%s, 3, 2)", x)
    ca = db.one("SELECT id FROM braid_representation WHERE braid_id = %s AND q_num = 2", a)
    assert db.one("SELECT certify_braid_representation(%s)", a) == ca   # one per braid and q
    assert db.one("SELECT braid_representation_equal(%s, %s, 2, 1)", a, b) is True
    assert db.one("SELECT braid_representation_equal(%s, %s, 3, 2)", a, b) is True
    assert db.one("SELECT braid_representation_equal(%s, %s, 2, 1)", c, d) is False
    assert db.one("SELECT braid_representation_inequality_certified(%s, %s)", c, d) is True
    assert db.one("SELECT braid_representation_equal(%s, %s, 5, 7)", a, b) is None  # no cert
    e = db.one("SELECT register_braid(4, ARRAY[1, 2, 1])")
    db.one("SELECT certify_braid_representation(%s)", e)
    assert db.one("SELECT braid_representation_equal(%s, %s, 2, 1)", a, e) is None  # B_3 vs B_4
    dim, den = db.q("SELECT dimension, denominator FROM braid_representation "
                    "WHERE braid_id = %s AND q_num = 2", c)[0]
    assert (dim, int(den)) == (8, 2)
    assert db.one("SELECT check_braid_representations()") == 0
    assert db.one("SELECT count(*) FROM invariant_violation "
                  "WHERE module = 'braid_representations'") == 0


def test_exact_equality_matches_qbx_ir(db):
    """The Python equality API with the exact representation gives the database answer."""
    from qbx_ir.core.equality import EqualityKind, check_equality
    from qbx_ir.quantum.exact import ExactSL2Representation

    rho = ExactSL2Representation(Fraction(3, 2))
    pairs = [([1, 2, 1], [2, 1, 2]), ([1], [2]), ([1, -1, 2], [2]), ([1, 1, 2, 2, -1, -1, -2, -2], [])]
    for w1, w2 in pairs:
        a = db.one("SELECT register_braid(3, %s::int[])", w1)
        b = db.one("SELECT register_braid(3, %s::int[])", w2)
        db.one("SELECT certify_braid_representation(%s, 3, 2)", a)
        db.one("SELECT certify_braid_representation(%s, 3, 2)", b)
        res = check_equality(Braid.from_short_form(3, w1), Braid.from_short_form(3, w2),
                             EqualityKind.REPRESENTATION, representation_fn=rho)
        assert res.certain
        assert db.one("SELECT braid_representation_equal(%s, %s, 3, 2)", a, b) == res.equal


def test_certify_refusals(db):
    db.q("INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (3, ARRAY[1, 7], 'h')")
    bad = db.one("SELECT id FROM braid_word WHERE braid_hash = 'h'")
    ok = db.one("SELECT register_braid(3, ARRAY[1])")
    big = db.one("SELECT register_braid(7, ARRAY[1, 6])")
    for sql, args, msg in [
        ("SELECT certify_braid_representation(%s)", (bad,), "braid_not_well_formed"),
        ("SELECT certify_braid_representation(gen_random_uuid())", (), "unknown braid"),
        ("SELECT certify_braid_representation(%s, 0, 1)", (ok,), "parameter_invalid"),
        ("SELECT certify_braid_representation(%s, 2, 4)", (ok,), "parameter_invalid"),
        ("SELECT certify_braid_representation(%s, 2, -1)", (ok,), "parameter_invalid"),
        ("SELECT certify_braid_representation(%s)", (big,), "strand_count_too_large"),
    ]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, *args)
        db.q("ROLLBACK TO SAVEPOINT s")


def test_too_many_strands_is_a_problem(db):
    big = db.one("SELECT register_braid(7, ARRAY[1, 6])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", big)
    cid = db.one("INSERT INTO braid_representation (braid_id, q_num, q_den, braid_hash, dimension, "
                 "numerators, denominator) VALUES (%s, 2, 1, %s, 128, '{}', 1) RETURNING id",
                 big, h)
    row = RepRow(BraidRow.of(7, [1, 6]), 2, 1, h, 128, (), 1)
    assert rows(db, "SELECT * FROM braid_representation_problems(%s)", cid) == \
        certificate_problems(row) == [("strand_count_too_large", {"strand_count": 7, "max": 6})]


def test_strict_mode_rejects_a_bad_certificate_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(2, ARRAY[1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    # The right value 1/2·[...] written as the unreduced fraction 2/4·[...].
    insert = ("INSERT INTO braid_representation (braid_id, q_num, q_den, braid_hash, dimension, "
              "numerators, denominator) VALUES (%s, 2, 1, %s, 4, "
              "ARRAY[8,0,0,0, 0,0,4,0, 0,4,6,0, 0,0,0,8], 4)")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q(insert, a, h)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, a, h)
    got = db.q("SELECT violation_type, details FROM invariant_violation "
               "WHERE module = 'braid_representations' ORDER BY detected_at, id")
    assert sorted(got, key=lambda t: t[0]) == [
        ("denominator_mismatch", {"recorded": "4", "expected": "2",
                                  "table": "braid_representation"}),
        ("numerators_mismatch", {"recorded_length": 16, "expected_length": 16, "first_index": 0,
                                 "table": "braid_representation"}),
    ]


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    c = db.one("SELECT certify_braid_representation(%s)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_representation SET denominator = 5 WHERE id = %s",
                "DELETE FROM braid_representation WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, c)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q("DELETE FROM braid_representation WHERE id = %s", c)
    assert db.q("SELECT violation_type, details->>'op' FROM invariant_violation "
                "WHERE module = 'braid_representations'") == [("log_mutation", "DELETE")]


def test_phase2_batch_checks_include_the_representations(db):
    a = db.one("SELECT register_braid(3, ARRAY[2, 1])")
    c = db.one("SELECT certify_braid_representation(%s)", a)
    db.q("UPDATE braid_representation SET denominator = 7 WHERE id = %s", c)
    db.q("DELETE FROM invariant_violation")
    db.q("SELECT run_phase2_batch_checks()")
    assert db.q("SELECT violation_type FROM invariant_violation "
                "WHERE module = 'braid_representations'") == [("denominator_mismatch",)]


def break_values(db):
    """Replace the values function by one that ignores inverse letters (a deliberate bug)."""
    db.q("ALTER FUNCTION braid_representation_values(INT, INT[], BIGINT, BIGINT) "
         "RENAME TO braid_representation_values_orig")
    db.q("""
      CREATE FUNCTION braid_representation_values(p_n INT, p_word INT[], p_num BIGINT,
                                                  p_den BIGINT)
      RETURNS TABLE(dimension INT, numerators NUMERIC[], denominator NUMERIC) AS $$
        SELECT * FROM braid_representation_values_orig(
          p_n, ARRAY(SELECT x FROM unnest(p_word) AS u(x) WHERE x > 0), p_num, p_den) $$
      LANGUAGE sql""")


def test_transport_check_catches_a_broken_computation(db):
    """With the broken computation, the two ends of the R01 rewrite σ1σ1⁻¹ → ε get 'valid'
    certificates that differ: the transport check reports it (on a sound ledger it cannot
    fire — Lean: repCert_eq_of_eval_eq)."""
    x = db.one("SELECT register_braid(3, ARRAY[1, -1])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R01', 0)", x)
    e = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r)
    break_values(db)
    db.one("SELECT certify_braid_representation(%s)", x)
    db.one("SELECT certify_braid_representation(%s)", e)
    assert db.one("SELECT braid_representation_equal(%s, %s, 2, 1)", x, e) is False
    assert rows(db, "SELECT * FROM braid_rewrite_rep_transport_problems(%s)", r) == [
        ("representation_not_preserved", {"q_num": 2, "q_den": 1})]


def test_consistency_check_catches_a_broken_computation(db):
    """With the broken computation, σ2σ1σ1⁻¹ and σ2 (certified equal by their normal forms)
    get different 'valid' certificates: the consistency check reports it on both."""
    x = db.one("SELECT register_braid(3, ARRAY[2, 1, -1])")
    y = db.one("SELECT register_braid(3, ARRAY[2])")
    db.one("SELECT certify_braid_normal_form(%s)", x)
    db.one("SELECT certify_braid_normal_form(%s)", y)
    break_values(db)
    cx = db.one("SELECT certify_braid_representation(%s)", x)
    db.one("SELECT certify_braid_representation(%s)", y)
    hx = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", x)
    hy = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", y)
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", x, y) is True
    assert rows(db, "SELECT * FROM braid_rep_nf_problems(%s)", cx) == [
        ("representation_contradicts_normal_form", {"other_braid_hash": hy})]
    db.q("DELETE FROM invariant_violation")
    assert db.one("SELECT check_braid_representations()") == 2
    got = db.q("SELECT details->>'other_braid_hash' FROM invariant_violation "
               "WHERE module = 'braid_representations' "
               "AND violation_type = 'representation_contradicts_normal_form'")
    assert sorted(r[0] for r in got) == sorted([hx, hy])


def test_migration_is_reapplicable(db):
    with db.conn.cursor() as cur:
        cur.execute(MIGRATION.read_text())
    a = db.one("SELECT register_braid(4, ARRAY[1, 3, -1])")
    assert db.one("SELECT certify_braid_representation(%s)", a)
    assert word_hash(4, [1, 3, -1]) == db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
