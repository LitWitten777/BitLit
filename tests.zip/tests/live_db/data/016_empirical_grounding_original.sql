-- ============================================================================
-- Categorical Ledger — Migration 016: Empirical Grounding
-- ============================================================================
-- Measurement contracts, measurement bundles, uncertainty types, dynamical
-- models, agent models, and economic mechanisms.
-- ============================================================================

CREATE TABLE IF NOT EXISTS measurement_contract (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  observable_id TEXT NOT NULL,
  mapping_function TEXT,
  expected_precision JSONB DEFAULT '{}'::jsonb,
  validation_tests JSONB DEFAULT '[]'::jsonb,
  body JSONB NOT NULL DEFAULT '{}'::jsonb,
  version TEXT NOT NULL DEFAULT '1.0.0',
  active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS measurement_bundle (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  sensor_id TEXT,
  observations JSONB NOT NULL,
  context JSONB DEFAULT '{}'::jsonb,
  provenance JSONB DEFAULT '{}'::jsonb,
  validated BOOLEAN DEFAULT FALSE,
  validation_report JSONB,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_measurement_bundle_sensor
  ON measurement_bundle (sensor_id, created_at DESC);

CREATE TABLE IF NOT EXISTS uncertainty_type (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  descriptor JSONB NOT NULL
);

CREATE TABLE IF NOT EXISTS dynamical_model (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  model_type TEXT NOT NULL CHECK (model_type IN ('ODE','SDE','PDE','discrete')),
  model_spec TEXT NOT NULL,
  solver_config JSONB DEFAULT '{}'::jsonb,
  verification_proof UUID REFERENCES proof_artifact(id) ON DELETE SET NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS agent_model (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  body_spec JSONB,
  sensors JSONB,
  actuators JSONB,
  learning_module JSONB,
  safety_constraints JSONB,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS mechanism (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  mechanism_spec JSONB NOT NULL,
  incentive_constraints JSONB,
  verification_proof UUID REFERENCES proof_artifact(id) ON DELETE SET NULL,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS simulation_run (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  model_id UUID REFERENCES dynamical_model(id) ON DELETE CASCADE,
  initial_conditions JSONB NOT NULL,
  solver_used TEXT,
  tolerance DOUBLE PRECISION,
  result_uri TEXT,
  result_summary JSONB,
  started_at TIMESTAMPTZ DEFAULT now(),
  finished_at TIMESTAMPTZ
);

-- ---------------------------------------------------------------------------
-- Validate a measurement bundle against a contract.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION validate_measurement_bundle(
  p_bundle_id UUID, p_contract_id UUID
) RETURNS BOOLEAN AS $$
DECLARE
  b RECORD;
  c RECORD;
  obs RECORD;
  test TEXT;
  ok BOOLEAN := TRUE;
  report JSONB := '[]'::jsonb;
BEGIN
  SELECT * INTO b FROM measurement_bundle WHERE id = p_bundle_id;
  SELECT * INTO c FROM measurement_contract WHERE id = p_contract_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Bundle or contract not found';
  END IF;

  FOR test IN
    SELECT jsonb_array_elements_text(c.validation_tests)
  LOOP
    IF test = 'range_check' THEN
      FOR obs IN
        SELECT * FROM jsonb_array_elements(b.observations)
      LOOP
        IF (obs.value->>'value')::DOUBLE PRECISION
             < coalesce((c.body->>'min')::DOUBLE PRECISION, -1e18)
           OR (obs.value->>'value')::DOUBLE PRECISION
             > coalesce((c.body->>'max')::DOUBLE PRECISION, 1e18)
        THEN
          ok := FALSE;
          report := report || jsonb_build_object(
            'test', 'range_check',
            'failed_value', obs.value->>'value'
          );
        END IF;
      END LOOP;
    END IF;
  END LOOP;

  UPDATE measurement_bundle
     SET validated = ok, validation_report = report
   WHERE id = p_bundle_id;

  RETURN ok;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- Register a dynamical model.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION register_dynamical_model(
  p_name TEXT, p_type TEXT, p_spec TEXT, p_config JSONB DEFAULT '{}'::jsonb
) RETURNS UUID AS $$
DECLARE new_id UUID;
BEGIN
  INSERT INTO dynamical_model (name, model_type, model_spec, solver_config)
  VALUES (p_name, p_type, p_spec, p_config)
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- Register a mechanism.
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION register_mechanism(
  p_name TEXT, p_spec JSONB, p_constraints JSONB DEFAULT '{}'::jsonb
) RETURNS UUID AS $$
DECLARE new_id UUID;
BEGIN
  INSERT INTO mechanism (name, mechanism_spec, incentive_constraints)
  VALUES (p_name, p_spec, p_constraints)
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;