-- ============================================================================
-- Categorical Ledger — Migration 004: Natural Transformations
-- ============================================================================
-- Enforces naturality squares:
--
--     F(X) --F(f)--> F(Y)
--      |              |
--     η_X            η_Y
--      |              |
--      v              v
--     G(X) --G(f)--> G(Y)
--
-- i.e.  η_Y ∘ F(f) = G(f) ∘ η_X   for every f: X → Y.
-- ============================================================================

---

-- Tables

---

CREATE TABLE IF NOT EXISTS natural_transformation (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
name TEXT NOT NULL,
source_functor_id UUID NOT NULL REFERENCES functor(id) ON DELETE CASCADE,
target_functor_id UUID NOT NULL REFERENCES functor(id) ON DELETE CASCADE,
metadata JSONB DEFAULT '{}'::jsonb,
created_at TIMESTAMPTZ DEFAULT now(),
UNIQUE (name, source_functor_id, target_functor_id)
);

CREATE TABLE IF NOT EXISTS natural_transformation_component (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
transformation_id UUID NOT NULL REFERENCES natural_transformation(id) ON DELETE CASCADE,
object_id UUID NOT NULL REFERENCES object(id) ON DELETE CASCADE,
morphism_id UUID NOT NULL REFERENCES morphism(id) ON DELETE CASCADE,
metadata JSONB DEFAULT '{}'::jsonb,
UNIQUE (transformation_id, object_id)
);

CREATE INDEX IF NOT EXISTS idx_nt_component_transformation
ON natural_transformation_component (transformation_id);

---

-- Violation log

---

CREATE TABLE IF NOT EXISTS naturality_violation (
id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
transformation_id UUID NOT NULL REFERENCES natural_transformation(id) ON DELETE CASCADE,
object_x UUID,
object_y UUID,
morphism_f UUID,
eta_x UUID,
eta_y UUID,
f_mapped_by_F UUID,
f_mapped_by_G UUID,
left_composite UUID,
right_composite UUID,
law TEXT NOT NULL DEFAULT 'naturality_square',   -- read by v_all_violations (017)
details JSONB DEFAULT '{}'::jsonb,
detected_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_naturality_violation_transformation
ON naturality_violation (transformation_id, detected_at DESC);

---

-- Helper view: NT components joined with their transformation

---

CREATE OR REPLACE VIEW v_nt_components AS
SELECT
ntc.id              AS component_id,
ntc.transformation_id,
nt.source_functor_id,
nt.target_functor_id,
ntc.object_id,
ntc.morphism_id     AS eta_x
FROM natural_transformation_component ntc
JOIN natural_transformation nt ON nt.id = ntc.transformation_id;

---

-- Naturality enforcement (row-level trigger)
--
-- Runs on every component insert/update. For the affected object X, walks every
-- morphism f with one endpoint X — out of X, into X, and endomorphisms of X
-- (identities excluded) — whose other endpoint already has a component. For
-- each such f with F(f), G(f) mapped, verifies the naturality square.
--
-- Phase 1 fix: the original trigger only walked f: X → Y and skipped every
-- endomorphism, so the square of f: X → Y was never checked when η_X was
-- registered before η_Y (Formal/Naturality.lean: trigger_misses_forward,
-- trigger_misses_endo). Checking both directions makes incremental enforcement
-- complete (checkedBy_of_mem). A missing composite is now a violation instead
-- of a silent pass.

---

-- Composite `p_second ∘ p_first` (p_first applied first), using the unit laws
-- for identity morphisms; NULL when the composite is not recorded.
--
-- Composition convention (shared with qbx.db.repositories.add_composition and
-- migrations 002, 005, 006): composition(left_id = g, right_id = f, result_id = h)
-- records h = g ∘ f, i.e. the RIGHT morphism is applied first.
--
-- Phase 1 sprint 2 fix: this helper previously looked up
-- (left_id = p_first, right_id = p_second), i.e. p_first ∘ p_second — the
-- reverse of what its callers mean — so every non-identity naturality square
-- was reported as 'naturality_composite_missing' (found with the live-database
-- tests in tests/live_db/).
CREATE OR REPLACE FUNCTION nt_compose(p_first UUID, p_second UUID)
RETURNS UUID AS $$
-- Same as qbx_compose (migration 002, amendment A-002): second ∘ first with
-- the unit laws applied.
SELECT qbx_compose(p_first, p_second);
$$ LANGUAGE sql STABLE;

CREATE OR REPLACE FUNCTION check_naturality_for_component(p_component_id UUID)
RETURNS VOID AS $$
DECLARE
nt RECORD;
eta_x_id UUID;
x_id UUID;
f RECORD;
eta_y_id UUID;
eta_s_id UUID;
Ff_id UUID;
Gf_id UUID;
left_comp UUID;
right_comp UUID;
is_strict BOOLEAN;
BEGIN
is_strict := coalesce(current_setting('qbx.enforcement_mode', true), 'permissive') = 'strict';

SELECT ntc.transformation_id,
ntc.object_id,
ntc.morphism_id,
ntr.source_functor_id,
ntr.target_functor_id
INTO nt
FROM natural_transformation_component ntc
JOIN natural_transformation ntr ON ntr.id = ntc.transformation_id
WHERE ntc.id = p_component_id;

IF NOT FOUND THEN
RETURN;
END IF;

eta_x_id := nt.morphism_id;
x_id     := nt.object_id;

-- Walk every non-identity morphism f: S → T with X ∈ {S, T}
FOR f IN
SELECT m.id AS f_id, m.source_id AS s_id, m.target_id AS y_id
FROM morphism m
WHERE (m.source_id = x_id OR m.target_id = x_id)
AND NOT EXISTS (SELECT 1 FROM identity_morphism im WHERE im.morphism_id = m.id)
LOOP
-- η_S and η_T must both exist
SELECT morphism_id INTO eta_s_id
FROM natural_transformation_component
WHERE transformation_id = nt.transformation_id
AND object_id = f.s_id;
SELECT morphism_id INTO eta_y_id
FROM natural_transformation_component
WHERE transformation_id = nt.transformation_id
AND object_id = f.y_id;
IF eta_s_id IS NULL OR eta_y_id IS NULL THEN
CONTINUE;
END IF;

-- F(f) and G(f) must be mapped
SELECT target_morphism_id INTO Ff_id
FROM functor_morphism_map
WHERE functor_id = nt.source_functor_id
AND source_morphism_id = f.f_id;
SELECT target_morphism_id INTO Gf_id
FROM functor_morphism_map
WHERE functor_id = nt.target_functor_id
AND source_morphism_id = f.f_id;
IF Ff_id IS NULL OR Gf_id IS NULL THEN
CONTINUE;
END IF;

-- left  = G(f) ∘ η_S
left_comp := nt_compose(eta_s_id, Gf_id);

-- right = η_T ∘ F(f)
right_comp := nt_compose(Ff_id, eta_y_id);

IF left_comp IS NULL OR right_comp IS NULL OR left_comp <> right_comp THEN
INSERT INTO naturality_violation
(transformation_id, object_x, object_y, morphism_f,
eta_x, eta_y, f_mapped_by_F, f_mapped_by_G,
left_composite, right_composite, law, details)
VALUES
(nt.transformation_id, f.s_id, f.y_id, f.f_id,
eta_s_id, eta_y_id, Ff_id, Gf_id,
left_comp, right_comp,
CASE WHEN left_comp IS NULL OR right_comp IS NULL
THEN 'naturality_composite_missing' ELSE 'naturality_square' END,
jsonb_build_object('reason',
CASE WHEN left_comp IS NULL OR right_comp IS NULL
THEN 'composite_not_recorded' ELSE 'naturality_square_does_not_commute' END));

IF is_strict THEN
RAISE EXCEPTION 'Naturality law violated for NT % on f=%',
nt.transformation_id, f.f_id;
END IF;
END IF;
END LOOP;
END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION trg_check_naturality() RETURNS trigger AS $$
BEGIN
  PERFORM check_naturality_for_component(NEW.id);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_check_naturality ON natural_transformation_component;
CREATE TRIGGER trg_check_naturality
AFTER INSERT OR UPDATE ON natural_transformation_component
FOR EACH ROW EXECUTE FUNCTION trg_check_naturality();

-- ---------------------------------------------------------------------------
-- Batch checker: re-verify all components of a transformation
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION recheck_naturality(p_transformation_id UUID)
RETURNS VOID AS $$
DECLARE
  comp RECORD;
BEGIN
  FOR comp IN
    SELECT id FROM natural_transformation_component
     WHERE transformation_id = p_transformation_id
  LOOP
    PERFORM check_naturality_for_component(comp.id);
  END LOOP;
END;
$$ LANGUAGE plpgsql;

-- ---------------------------------------------------------------------------
-- Convenience: register a component and immediately verify it
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION register_nt_component(
  p_transformation_id UUID,
  p_object_id UUID,
  p_morphism_id UUID
) RETURNS UUID AS $$
DECLARE
  new_id UUID;
BEGIN
  INSERT INTO natural_transformation_component
    (transformation_id, object_id, morphism_id)
  VALUES
    (p_transformation_id, p_object_id, p_morphism_id)
  RETURNING id INTO new_id;
  RETURN new_id;
END;
$$ LANGUAGE plpgsql;