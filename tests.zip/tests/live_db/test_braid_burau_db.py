"""Migration 024 (reduced Burau / Alexander certificates) on a real PostgreSQL.

The reference is ``qbx_ir.burau_ledger``: on random data — including
certificates of malformed braids and certificates with wrong hashes, sizes,
windows, coefficients and Alexander polynomials — the database reports exactly
the problems the Python code reports, with the same details, in the same order.
The equality answers (matrix and Alexander polynomial), the transport check
along accepted rewrites and derivations and the consistency check with the
normal-form certificates of migration 021 are compared too.

Formal backing: ``Formal/BurauRep.lean`` (the Burau matrices define a
representation of B_n for every n; det(I - ρ̄) is a conjugacy invariant) and
``Formal/BraidBurauCert.lean`` (``burauCert_eq_iff``, ``burauCert_eq_of_eval_eq``,
``eval_ne_of_burauCert_ne``, ``not_isConj_of_alexCert_ne``,
``burau_agrees_with_python``) — registry H-063, H-064.
"""

from __future__ import annotations

import random
from collections import Counter

import psycopg2
import pytest

from qbx_ir import Braid
from qbx_ir.algebra.garside import left_normal_form
from qbx_ir.burau_ledger import (
    BurauRow,
    alexander_equal,
    burau_equal,
    burau_values,
    certificate_problems,
    inequality_certified,
    nf_consistency_problems,
    non_conjugacy_certified,
    transport_problems,
)
from qbx_ir.ledger import BraidRow, braid_problems, derivation_problems, rewrite_problems
from qbx_ir.normal_form_ledger import NFRow
from tests.live_db.test_braid_ledger_db import build_random_ledger, random_word


def rows(db, sql, *args):
    return [(r, d) for r, d in db.q(sql, *args)]


def values(db, n, w):
    size, lo, width, coeffs, alex = db.q("SELECT * FROM braid_burau_values(%s, %s::int[])",
                                         n, w)[0]
    return size, lo, width, tuple(int(x) for x in coeffs), tuple(int(x) for x in alex)


def py_values(n, w):
    v = burau_values(n, w)
    return v.size, v.exp_min, v.width, v.coefficients, v.alexander


def test_values_agree_with_python(db):
    rng = random.Random(11)
    for _ in range(250):
        n = rng.randint(1, 7)
        w = random_word(rng, n, rng.randint(0, 12)) if n > 1 else []
        assert values(db, n, w) == py_values(n, w), (n, w)


def test_values_on_more_strands_and_longer_words(db):
    rng = random.Random(12)
    for _ in range(40):
        n = rng.randint(8, 12)
        w = random_word(rng, n, rng.randint(0, 25))
        assert values(db, n, w) == py_values(n, w), (n, w)


def test_values_on_known_braids(db):
    assert values(db, 1, []) == (0, 0, 0, (), (1,))
    assert values(db, 2, [1]) == (1, 1, 1, (-1,), (1,))
    assert values(db, 2, [1, 1, 1])[4] == (1, -1, 1)            # trefoil
    assert values(db, 3, [1, -2, 1, -2])[4] == (1, -3, 1)       # figure-eight
    assert values(db, 2, [])[4] == ()                           # 2-component unlink
    assert values(db, 3, [1, 2, 1]) == values(db, 3, [2, 1, 2])  # braid relation
    assert values(db, 4, [1, -1, 3]) == values(db, 4, [3])      # R01
    # The commutator σ1²σ2²σ1⁻²σ2⁻² has a non-identity Burau matrix.
    assert values(db, 3, [1, 1, 2, 2, -1, -1, -2, -2]) != values(db, 3, [])


def test_polynomial_helpers(db):
    # (1 + t)(1 - t) = 1 - t², and back.
    prod = db.one("SELECT braid_burau_poly_mul(ARRAY[1,1,0,0]::numeric[], "
                  "ARRAY[1,-1,0,0]::numeric[], 4)")
    assert [int(x) for x in prod] == [1, 0, -1, 0]
    q = db.one("SELECT braid_burau_poly_divexact(ARRAY[1,0,-1,0]::numeric[], "
               "ARRAY[1,1,0,0]::numeric[], 4)")
    assert [int(x) for x in q] == [1, -1, 0, 0]
    assert db.one("SELECT braid_burau_poly_deg(ARRAY[0,0,0]::numeric[])") == -1
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not divisible"):
        db.q("SELECT braid_burau_poly_divexact(ARRAY[1,0,1,0]::numeric[], "
             "ARRAY[1,1,0,0]::numeric[], 4)")
    db.q("ROLLBACK TO SAVEPOINT s")


def random_burau(rng, braid: BraidRow) -> BurauRow:
    """A certificate for ``braid``: usually the right one, sometimes tampered with."""
    if braid_problems(braid):
        return BurauRow(braid, braid.braid_hash, 1, 0, 1, (1,), ())
    good = BurauRow.of(braid)
    roll = rng.random()
    if roll < 0.06:
        return BurauRow(braid, "e" * 8, good.size, good.exp_min, good.width, good.coefficients,
                        good.alexander)
    if roll < 0.11:
        return BurauRow(braid, good.braid_hash, good.size + 1, good.exp_min, good.width,
                        good.coefficients, good.alexander)
    if roll < 0.17:
        # Not the smallest window: the same matrix, padded with a zero column.
        if good.width == 0:
            return good
        w = good.width
        padded = []
        for x in range(good.size * good.size):
            padded.extend(good.coefficients[x * w:(x + 1) * w] + (0,))
        return BurauRow(braid, good.braid_hash, good.size, good.exp_min, w + 1, tuple(padded),
                        good.alexander)
    if roll < 0.23 and good.coefficients:
        cs = list(good.coefficients)
        k = rng.randrange(len(cs))
        cs[k] += rng.choice([-1, 1])
        return BurauRow(braid, good.braid_hash, good.size, good.exp_min, good.width, tuple(cs),
                        good.alexander)
    if roll < 0.28:
        alex = tuple(-x for x in good.alexander) if good.alexander else (1,)
        return BurauRow(braid, good.braid_hash, good.size, good.exp_min, good.width,
                        good.coefficients, alex)
    return good


def insert_burau(db, bid, c: BurauRow):
    return db.one(
        "INSERT INTO braid_burau (braid_id, braid_hash, size, exp_min, width, coefficients, "
        "alexander) VALUES (%s, %s, %s, %s, %s, %s::numeric[], %s::numeric[]) RETURNING id",
        bid, c.braid_hash, c.size, c.exp_min, c.width, list(c.coefficients), list(c.alexander))


def test_random_certificates_equality_transport_and_consistency_match_reference(db):
    seen = Counter()
    for seed in range(6):
        db.q("SAVEPOINT s")
        rng = random.Random(700 + seed)
        m = build_random_ledger(db, rng, n_braids=30, n_rewrites=40)
        certs = {}     # braid id -> BurauRow (at most one)
        cert_ids = []  # (braid id, cert id, BurauRow)
        nfs = {}
        for bid, braid in m.braid_row.items():
            if not braid_problems(braid) and rng.random() < 0.8:
                db.one("SELECT certify_braid_normal_form(%s)", bid)
                nfs[bid] = NFRow.of(braid)
            r = rng.random()
            if r < 0.35:
                c = random_burau(rng, braid)
                cid = insert_burau(db, bid, c)
            elif r < 0.9 and not braid_problems(braid):
                cid = db.one("SELECT certify_braid_burau(%s)", bid)
                c = BurauRow.of(braid)
            else:
                continue
            certs[bid] = c
            cert_ids.append((bid, cid, c))
            got = rows(db, "SELECT * FROM braid_burau_problems(%s)", cid)
            assert got == certificate_problems(c), (seed, c)
            seen.update(r for r, _ in got)
            if not got:
                seen["certificate_ok"] += 1
        ids = list(m.braid_row)

        canon = {bid: (row.strand_count,
                       left_normal_form(Braid.from_short_form(row.strand_count, list(row.word))))
                 for bid, row in m.braid_row.items() if not braid_problems(row)}
        pairs = [(rng.choice(ids), rng.choice(ids)) for _ in range(80)]
        pairs += [(a, b) for a in canon for b in canon if a != b and canon[a] == canon[b]]
        for a, b in pairs:
            ca, cb = certs.get(a), certs.get(b)
            got = db.one("SELECT braid_burau_equal(%s, %s)", a, b)
            want = burau_equal(ca, cb)
            assert got == want, (seed, a, b, got, want)
            assert db.one("SELECT braid_alexander_equal(%s, %s)", a, b) == alexander_equal(ca, cb)
            assert db.one("SELECT braid_burau_inequality_certified(%s, %s)", a, b) == \
                inequality_certified(ca, cb)
            assert db.one("SELECT braid_burau_non_conjugacy_certified(%s, %s)", a, b) == \
                non_conjugacy_certified(ca, cb)
            if want is not None:
                if canon[a] == canon[b]:
                    assert want is True and alexander_equal(ca, cb) is True
                    if a != b:
                        seen["equal_braids_distinct_words"] += 1
                else:
                    seen["certified_different" if want is False else "burau_equal_only"] += 1
                if alexander_equal(ca, cb) is False:
                    seen["certified_not_conjugate"] += 1
        for bid, cid, c in cert_ids:
            got = rows(db, "SELECT * FROM braid_burau_nf_problems(%s)", cid)
            others = [(oc, nfs.get(ob)) for ob, _, oc in cert_ids]
            want = nf_consistency_problems(c, nfs.get(bid), others)
            assert got == want == [], (seed, got, want)
        for rid, r in m.rewrite_row.items():
            ok = not rewrite_problems(r)
            a, b = m.braid_id[r.input.key], m.braid_id[r.output.key]
            got = rows(db, "SELECT * FROM braid_rewrite_burau_transport_problems(%s)", rid)
            assert got == transport_problems(ok, certs.get(a), certs.get(b)) == [], (seed, got)
            if ok and burau_equal(certs.get(a), certs.get(b)):
                seen["transport_checked"] += 1
        for _ in range(15):
            src = rng.choice(ids)
            steps, dirs, cur = [], [], src
            for _ in range(rng.randint(0, 4)):
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
                r = m.rewrite_row[rid]
                steps.append(rid)
                dirs.append(d)
                cur = m.braid_id[(r.output if d else r.input).key]
            did = db.one(
                "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
                "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, cur, steps, dirs)
            accepted = not derivation_problems(m.braid_row[src], m.braid_row[cur],
                                               [m.rewrite_row[s] for s in steps], dirs)
            got = rows(db, "SELECT * FROM braid_derivation_burau_transport_problems(%s)", did)
            assert got == transport_problems(accepted, certs.get(src), certs.get(cur)) == []
            if accepted and steps and burau_equal(certs.get(src), certs.get(cur)):
                seen["derivation_transport_checked"] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    for reason in ("braid_not_well_formed", "braid_hash_mismatch", "size_mismatch",
                   "window_mismatch", "coefficients_mismatch", "alexander_mismatch",
                   "certificate_ok", "equal_braids_distinct_words", "certified_different",
                   "certified_not_conjugate", "transport_checked",
                   "derivation_transport_checked"):
        assert seen[reason] > 0, reason


def test_writer_equality_and_non_conjugacy(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2, 1])")
    b = db.one("SELECT register_braid(3, ARRAY[2, 1, 2])")
    c = db.one("SELECT register_braid(3, ARRAY[1])")
    d = db.one("SELECT register_braid(3, ARRAY[2])")
    f8 = db.one("SELECT register_braid(3, ARRAY[1, -2, 1, -2])")
    u = db.one("SELECT register_braid(3, ARRAY[1, -2])")
    assert db.one("SELECT braid_burau_equal(%s, %s)", a, b) is None
    for x in (a, b, c, d, f8, u):
        db.one("SELECT certify_braid_burau(%s)", x)
    ca = db.one("SELECT id FROM braid_burau WHERE braid_id = %s", a)
    assert db.one("SELECT certify_braid_burau(%s)", a) == ca     # one per braid
    assert db.one("SELECT braid_burau_equal(%s, %s)", a, b) is True
    assert db.one("SELECT braid_burau_equal(%s, %s)", c, d) is False
    assert db.one("SELECT braid_burau_inequality_certified(%s, %s)", c, d) is True
    # σ1 and σ2 are conjugate (σ1σ2 · σ1 · (σ1σ2)⁻¹ = σ2): same Alexander polynomial.
    assert db.one("SELECT braid_alexander_equal(%s, %s)", c, d) is True
    # Figure-eight braid vs σ1σ2⁻¹ (Lean: figureEight_not_conj).
    assert db.one("SELECT braid_burau_non_conjugacy_certified(%s, %s)", f8, u) is True
    e = db.one("SELECT register_braid(4, ARRAY[1, 2, 1])")
    db.one("SELECT certify_braid_burau(%s)", e)
    assert db.one("SELECT braid_burau_equal(%s, %s)", a, e) is None   # B_3 vs B_4
    assert db.one("SELECT check_braid_burau()") == 0
    assert db.one("SELECT count(*) FROM invariant_violation WHERE module = 'braid_burau'") == 0


def test_kind_view_lists_both_representations(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    db.one("SELECT certify_braid_representation(%s)", a)
    db.one("SELECT certify_braid_burau(%s)", a)
    got = db.q("SELECT kind, parameter FROM v_braid_exact_representations WHERE braid_id = %s "
               "ORDER BY kind", a)
    assert got == [("reduced_burau", None), ("sl2_quantum", {"q_num": 2, "q_den": 1})]


def test_certify_refusals(db):
    db.q("INSERT INTO braid_word (strand_count, word, braid_hash) VALUES (3, ARRAY[1, 7], 'h')")
    bad = db.one("SELECT id FROM braid_word WHERE braid_hash = 'h'")
    big = db.one("SELECT register_braid(13, ARRAY[1, 12])")
    for sql, args, msg in [
        ("SELECT certify_braid_burau(%s)", (bad,), "braid_not_well_formed"),
        ("SELECT certify_braid_burau(gen_random_uuid())", (), "unknown braid"),
        ("SELECT certify_braid_burau(%s)", (big,), "strand_count_too_large"),
    ]:
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            db.q(sql, *args)
        db.q("ROLLBACK TO SAVEPOINT s")


def test_too_many_strands_is_a_problem(db):
    big = db.one("SELECT register_braid(13, ARRAY[1, 12])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", big)
    cid = db.one("INSERT INTO braid_burau (braid_id, braid_hash, size, exp_min, width, "
                 "coefficients, alexander) VALUES (%s, %s, 12, 0, 0, '{}', '{}') RETURNING id",
                 big, h)
    row = BurauRow(BraidRow.of(13, [1, 12]), h, 12, 0, 0, (), ())
    assert rows(db, "SELECT * FROM braid_burau_problems(%s)", cid) == \
        certificate_problems(row) == [("strand_count_too_large", {"strand_count": 13, "max": 12})]


def test_strict_mode_rejects_a_bad_certificate_and_permissive_logs_it(db):
    a = db.one("SELECT register_braid(2, ARRAY[1])")
    h = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", a)
    # The right matrix (-t) with the window padded: (exp_min 1, width 2, [-1, 0]).
    insert = ("INSERT INTO braid_burau (braid_id, braid_hash, size, exp_min, width, coefficients, "
              "alexander) VALUES (%s, %s, 1, 1, 2, ARRAY[-1, 0], ARRAY[1])")
    db.set_mode("strict")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not valid"):
        db.q(insert, a, h)
    db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q(insert, a, h)
    got = db.q("SELECT violation_type, details FROM invariant_violation "
               "WHERE module = 'braid_burau' ORDER BY detected_at, id")
    assert sorted(got, key=lambda t: t[0]) == [
        ("coefficients_mismatch", {"recorded_length": 2, "expected_length": 1, "first_index": 1,
                                   "table": "braid_burau"}),
        ("window_mismatch", {"recorded": [1, 2], "expected": [1, 1], "table": "braid_burau"}),
    ]


def test_append_only(db):
    a = db.one("SELECT register_braid(3, ARRAY[1, 2])")
    c = db.one("SELECT certify_braid_burau(%s)", a)
    db.set_mode("strict")
    for sql in ("UPDATE braid_burau SET width = 5 WHERE id = %s",
                "DELETE FROM braid_burau WHERE id = %s"):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match="append-only"):
            db.q(sql, c)
        db.q("ROLLBACK TO SAVEPOINT s")
    db.set_mode("permissive")
    db.q("DELETE FROM braid_burau WHERE id = %s", c)
    assert db.q("SELECT violation_type, details->>'op' FROM invariant_violation "
                "WHERE module = 'braid_burau'") == [("log_mutation", "DELETE")]


def test_phase3_batch_checks_include_the_burau_certificates(db):
    a = db.one("SELECT register_braid(3, ARRAY[2, 1])")
    c = db.one("SELECT certify_braid_burau(%s)", a)
    db.q("UPDATE braid_burau SET alexander = ARRAY[7] WHERE id = %s", c)
    db.q("DELETE FROM invariant_violation")
    db.q("SELECT run_phase3_batch_checks()")
    assert db.q("SELECT violation_type FROM invariant_violation "
                "WHERE module = 'braid_burau'") == [("alexander_mismatch",)]


def break_values(db):
    """Replace the values function by one that ignores inverse letters (a deliberate bug)."""
    db.q("ALTER FUNCTION braid_burau_values(INT, INT[]) RENAME TO braid_burau_values_orig")
    db.q("""
      CREATE FUNCTION braid_burau_values(p_n INT, p_word INT[])
      RETURNS TABLE(size INT, exp_min INT, width INT, coefficients NUMERIC[],
                    alexander NUMERIC[]) AS $$
        SELECT * FROM braid_burau_values_orig(
          p_n, ARRAY(SELECT x FROM unnest(p_word) AS u(x) WHERE x > 0)) $$
      LANGUAGE sql""")


def test_transport_check_catches_a_broken_computation(db):
    """With the broken computation, the two ends of the R01 rewrite σ1σ1⁻¹σ2 → σ2 get 'valid'
    certificates that differ: the transport check reports it (on a sound ledger it cannot
    fire — Lean: burauCert_eq_of_eval_eq, alexCert_eq_of_eval_eq)."""
    x = db.one("SELECT register_braid(3, ARRAY[1, -1, 2])")
    r = db.one("SELECT record_braid_rewrite(%s, 'R01', 0)", x)
    e = db.one("SELECT output_braid_id FROM braid_rewrite WHERE id = %s", r)
    break_values(db)
    db.one("SELECT certify_braid_burau(%s)", x)
    db.one("SELECT certify_braid_burau(%s)", e)
    assert db.one("SELECT braid_burau_equal(%s, %s)", x, e) is False
    assert rows(db, "SELECT * FROM braid_rewrite_burau_transport_problems(%s)", r) == [
        ("burau_not_preserved", {}), ("alexander_not_preserved", {})]


def test_consistency_check_catches_a_broken_computation(db):
    """With the broken computation, σ2σ1σ1⁻¹ and σ2 (certified equal by their normal forms)
    get different 'valid' certificates: the consistency check reports it on both."""
    x = db.one("SELECT register_braid(3, ARRAY[2, 1, -1])")
    y = db.one("SELECT register_braid(3, ARRAY[2])")
    db.one("SELECT certify_braid_normal_form(%s)", x)
    db.one("SELECT certify_braid_normal_form(%s)", y)
    break_values(db)
    cx = db.one("SELECT certify_braid_burau(%s)", x)
    db.one("SELECT certify_braid_burau(%s)", y)
    hx = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", x)
    hy = db.one("SELECT braid_hash FROM braid_word WHERE id = %s", y)
    assert db.one("SELECT braid_nf_equality_certified(%s, %s)", x, y) is True
    assert rows(db, "SELECT * FROM braid_burau_nf_problems(%s)", cx) == [
        ("burau_contradicts_normal_form", {"other_braid_hash": hy})]
    db.q("DELETE FROM invariant_violation")
    assert db.one("SELECT check_braid_burau()") == 2
    got = db.q("SELECT details->>'other_braid_hash' FROM invariant_violation "
               "WHERE module = 'braid_burau' "
               "AND violation_type = 'burau_contradicts_normal_form'")
    assert sorted(r[0] for r in got) == sorted([hx, hy])
