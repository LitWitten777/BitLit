"""Phase 2 acceptance review (sprint 6): the whole braid ledger at once.

Each Phase 2 migration (019 – 022) was compared with its reference function by
function in its own sprint.  This review compares what the database actually
*logs* — at write time and in ``run_phase2_batch_checks()`` — on random ledgers
that use all four migrations together (malformed braids, wrong rewrite
records, broken derivations, tampered invariant, normal-form and
representation certificates), with the problems the references
(``qbx_ir.ledger``, ``qbx_ir.invariant_ledger``, ``qbx_ir.normal_form_ledger``,
``qbx_ir.representation_ledger``) predict for every row, and checks that
strict mode refuses exactly the rows the references reject.

Registry: R-022 (``Formal/HYPOTHESIS_REGISTRY.md``).
"""

from __future__ import annotations

import json
import random
from collections import Counter

import psycopg2

from qbx_ir import invariant_ledger as inv_ref
from qbx_ir import normal_form_ledger as nf_ref
from qbx_ir import representation_ledger as rep_ref
from qbx_ir.ledger import RewriteRow, braid_problems, derivation_problems, rewrite_problems
from qbx_ir.representation_ledger import RepRow
from tests.live_db.test_braid_invariants_db import insert_cert, random_cert
from tests.live_db.test_braid_ledger_db import Mirror, random_braid_row, random_rewrite
from tests.live_db.test_braid_normal_forms_db import insert_nf, random_nf
from tests.live_db.test_braid_representations_db import insert_rep, random_rep

MODULES = ("braid_ledger", "braid_invariants", "braid_normal_forms", "braid_representations")


def key(module, table, object_id, reason, details):
    d = dict(details or {})
    d["table"] = table
    return (module, str(object_id), reason, json.dumps(d, sort_keys=True))


def logged(db, exclude=frozenset()):
    """Phase 2 violations in the log (``exclude``: ids of rows logged earlier)."""
    out = Counter()
    for vid, module, obj, reason, details in db.q(
            "SELECT id, module, object_id, violation_type, details FROM invariant_violation "
            "WHERE module = ANY(%s)", list(MODULES)):
        if vid in exclude:
            continue
        d = dict(details)
        table = d.pop("table")
        out[key(module, table, obj, reason, d)] += 1
    return out


def violation_ids(db):
    return frozenset(r[0] for r in db.q("SELECT id FROM invariant_violation"))


class WholeLedger:
    """A random ledger using migrations 019 – 022, with the Python twin of every row."""

    def __init__(self, db, rng, n_braids=30, n_rewrites=40, n_derivations=25):
        self.db = db
        self.m = m = Mirror(db)
        for _ in range(n_braids):
            row = random_braid_row(rng)
            if row.key not in m.braid_id:
                m.braid(row)
        for _ in range(n_rewrites):
            m.rewrite(random_rewrite(rng, m))
        self.derivations = []        # (id, source id, target id, py steps, directions)
        self.invs, self.nfs, self.reps = {}, {}, {}   # braid id -> row(s)
        self.inv_ids, self.nf_ids, self.rep_ids = {}, {}, []
        for bid, braid in m.braid_row.items():
            if rng.random() < 0.75:
                c = random_cert(rng, braid)
                self.inv_ids[bid] = insert_cert(db, bid, c)
                self.invs[bid] = c
            if rng.random() < 0.8:
                c = random_nf(rng, braid)
                self.nf_ids[bid] = insert_nf(db, bid, c)
                self.nfs[bid] = c
            self.reps[bid] = []
            for _ in range(rng.choice([0, 1, 1, 2])):
                c = random_rep(rng, braid)
                if any(x.q == c.q for x in self.reps[bid]):
                    continue
                self.rep_ids.append((bid, insert_rep(db, bid, c), c))
                self.reps[bid].append(c)
            # A valid certificate at q = 2 for many well-formed braids, so that the
            # transport checks have certificates at the same parameter on both ends.
            if (not braid_problems(braid) and rng.random() < 0.6
                    and not any(x.q == (2, 1) for x in self.reps[bid])):
                c = RepRow.of(braid)
                self.rep_ids.append((bid, insert_rep(db, bid, c), c))
                self.reps[bid].append(c)
        for _ in range(n_derivations):
            self.derivation(rng)

    def derivation(self, rng):
        src, tgt, steps, dirs, py_steps = self.random_derivation(rng)
        did = self.db.one(
            "INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, directions) "
            "VALUES (%s, %s, %s::uuid[], %s::boolean[]) RETURNING id", src, tgt, steps, dirs)
        self.derivations.append((did, src, tgt, py_steps, dirs))

    def random_derivation(self, rng):
        """A derivation (mostly connected chains, sometimes broken) and its Python twin."""
        m = self.m
        src = rng.choice(list(m.braid_row))
        steps, dirs, py_steps, cur = [], [], [], src
        for _ in range(rng.randint(0, 4)):
            if rng.random() < 0.85:
                cands = [(rid, True) for rid, r in m.rewrite_row.items()
                         if m.braid_id[r.input.key] == cur]
                cands += [(rid, False) for rid, r in m.rewrite_row.items()
                          if m.braid_id[r.output.key] == cur]
                if not cands:
                    break
                rid, d = rng.choice(cands)
            else:
                rid, d = rng.choice(m.rewrite_ids), rng.random() < 0.5
            r = m.rewrite_row[rid]
            steps.append(rid)
            dirs.append(d)
            py_steps.append(r)
            cur = m.braid_id[(r.output if d else r.input).key]
        roll = rng.random()
        if roll < 0.06 and steps:
            k = rng.randrange(len(steps))
            steps[k] = self.db.one("SELECT gen_random_uuid()")
            py_steps[k] = None
        elif roll < 0.1:
            dirs = dirs + [True]
        tgt = cur if rng.random() < 0.8 else rng.choice(list(m.braid_row))
        return src, tgt, steps, dirs, py_steps

    # -- what the references predict ----------------------------------------
    def derivation_problems(self, src, tgt, py_steps, dirs):
        return derivation_problems(self.m.braid_row[src], self.m.braid_row[tgt], py_steps, dirs)

    def write_time(self) -> Counter:
        """Problems the write-time triggers must log: each row's own problems."""
        m, out = self.m, Counter()
        for bid, row in m.braid_row.items():
            for r, d in braid_problems(row):
                out[key("braid_ledger", "braid_word", bid, r, d)] += 1
        for rid, row in m.rewrite_row.items():
            for r, d in rewrite_problems(row):
                out[key("braid_ledger", "braid_rewrite", rid, r, d)] += 1
        for did, src, tgt, py_steps, dirs in self.derivations:
            for r, d in self.derivation_problems(src, tgt, py_steps, dirs):
                out[key("braid_ledger", "braid_derivation", did, r, d)] += 1
        for bid, c in self.invs.items():
            for r, d in inv_ref.certificate_problems(c):
                out[key("braid_invariants", "braid_invariant", self.inv_ids[bid], r, d)] += 1
        for bid, c in self.nfs.items():
            for r, d in nf_ref.certificate_problems(c):
                out[key("braid_normal_forms", "braid_normal_form", self.nf_ids[bid], r, d)] += 1
        for bid, cid, c in self.rep_ids:
            for r, d in rep_ref.certificate_problems(c):
                out[key("braid_representations", "braid_representation", cid, r, d)] += 1
        return out

    def batch(self, seen: Counter) -> Counter:
        """Problems ``run_phase2_batch_checks()`` must log: the write-time ones again, plus
        the transport checks on every rewrite and derivation and the consistency checks of
        the normal-form and representation certificates."""
        m, out = self.m, self.write_time()
        for bid, c in self.nfs.items():
            others = [(oc, self.invs.get(ob)) for ob, oc in self.nfs.items()]
            for r, d in nf_ref.invariant_consistency_problems(c, self.invs.get(bid), others):
                out[key("braid_normal_forms", "braid_normal_form", self.nf_ids[bid], r, d)] += 1
        for bid, cid, c in self.rep_ids:
            others = [(oc, self.nfs.get(ob)) for ob, _, oc in self.rep_ids]
            for r, d in rep_ref.nf_consistency_problems(c, self.nfs.get(bid), others):
                out[key("braid_representations", "braid_representation", cid, r, d)] += 1
        edges = [("braid_rewrite", rid, not rewrite_problems(row),
                  m.braid_id[row.input.key], m.braid_id[row.output.key])
                 for rid, row in m.rewrite_row.items()]
        edges += [("braid_derivation", did, not self.derivation_problems(src, tgt, st, dirs),
                   src, tgt) for did, src, tgt, st, dirs in self.derivations]
        for table, oid, ok, a, b in edges:
            for r, d in inv_ref.transport_problems(ok, self.invs.get(a), self.invs.get(b)):
                out[key("braid_invariants", table, oid, r, d)] += 1
            for r, d in nf_ref.transport_problems(ok, self.nfs.get(a), self.nfs.get(b)):
                out[key("braid_normal_forms", table, oid, r, d)] += 1
            for r, d in rep_ref.transport_problems(ok, self.reps[a], self.reps[b]):
                out[key("braid_representations", table, oid, r, d)] += 1
            if ok and a != b:
                if inv_ref.differences(self.invs.get(a), self.invs.get(b)) == []:
                    seen[f"{table}_invariants_transported"] += 1
                if nf_ref.normal_forms_equal(self.nfs.get(a), self.nfs.get(b)) is True:
                    seen[f"{table}_normal_form_transported"] += 1
                if any(rep_ref.representations_equal(c, rep_ref._at(self.reps[b], c.q))
                       for c in self.reps[a]):
                    seen[f"{table}_representation_transported"] += 1
        return out


def test_logged_violations_match_reference(db):
    """Write-time logs and batch logs of the whole ledger equal the reference prediction."""
    seen = Counter()
    for seed in range(8):
        db.q("SAVEPOINT s")
        rng = random.Random(2600 + seed)
        led = WholeLedger(db, rng)
        want_write = led.write_time()
        assert logged(db) == want_write, seed
        before = violation_ids(db)
        db.q("SELECT run_phase2_batch_checks()")
        got_batch = logged(db, exclude=before)
        assert got_batch == led.batch(seen), seed
        for module, _, reason, details in want_write:
            seen[(module, reason)] += 1
            seen[(module, json.loads(details)["table"])] += 1
        db.q("ROLLBACK TO SAVEPOINT s")
    # Every module logs problems on every kind of row it checks.
    for module, table in [("braid_ledger", "braid_word"), ("braid_ledger", "braid_rewrite"),
                          ("braid_ledger", "braid_derivation"),
                          ("braid_invariants", "braid_invariant"),
                          ("braid_normal_forms", "braid_normal_form"),
                          ("braid_representations", "braid_representation")]:
        assert seen[(module, table)] > 0, (module, table)
    for table in ("braid_rewrite", "braid_derivation"):
        for what in ("invariants", "normal_form", "representation"):
            assert seen[f"{table}_{what}_transported"] > 0, (table, what)


def table_of(sql):
    return sql.split()[2]


def test_strict_mode_refuses_exactly_what_the_references_reject(db):
    """In strict mode a row is refused iff its reference reports a problem; a refused row
    leaves nothing behind (neither the row nor a logged violation)."""
    seen = Counter()
    for seed in range(4):
        db.q("SAVEPOINT s")
        rng = random.Random(2700 + seed)
        led = WholeLedger(db, rng, n_braids=25, n_rewrites=25, n_derivations=10)
        db.set_mode("strict")
        m = led.m

        def attempt(sql, *args, rejected):
            db.q("SAVEPOINT a")
            n_before = len(violation_ids(db))
            try:
                db.q(sql, *args)
            except psycopg2.Error:
                db.q("ROLLBACK TO SAVEPOINT a")
                assert rejected, (seed, sql, args)
                assert len(violation_ids(db)) == n_before
                seen[(table_of(sql), "refused")] += 1
                return
            assert not rejected, (seed, sql, args)
            assert len(violation_ids(db)) == n_before
            seen[(table_of(sql), "accepted")] += 1
            db.q("RELEASE SAVEPOINT a")

        tried = set(m.braid_id)
        for _ in range(25):
            row = random_braid_row(rng)
            if row.key in tried:
                continue
            tried.add(row.key)
            attempt("INSERT INTO braid_word (strand_count, word, braid_hash) "
                    "VALUES (%s, %s::int[], %s)", row.strand_count, list(row.word), row.braid_hash,
                    rejected=bool(braid_problems(row)))
        for _ in range(25):
            r = random_rewrite(rng, m)
            if r.output.key not in m.braid_id:
                if braid_problems(r.output):
                    continue
                m.braid(r.output)        # a new well-formed output: accepted in strict mode
            # Start and end at the stored braids (content addressing), as Mirror does.
            r = RewriteRow(m.existing(r.input), r.rule_id, r.position, m.existing(r.output),
                           r.input_hash, r.output_hash, r.preserved, r.changed)
            attempt("INSERT INTO braid_rewrite (input_braid_id, rule_id, position, output_braid_id, "
                    "input_hash, output_hash, preserved, changed) "
                    "VALUES (%s, %s, %s, %s, %s, %s, %s::text[], %s::text[])",
                    m.braid_id[r.input.key], r.rule_id, r.position, m.braid_id[r.output.key],
                    r.input_hash, r.output_hash, list(r.preserved), list(r.changed),
                    rejected=bool(rewrite_problems(r)))
        for _ in range(20):
            src, tgt, steps, dirs, py_steps = led.random_derivation(rng)
            attempt("INSERT INTO braid_derivation (source_braid_id, target_braid_id, steps, "
                    "directions) VALUES (%s, %s, %s::uuid[], %s::boolean[])",
                    src, tgt, steps, dirs,
                    rejected=bool(led.derivation_problems(src, tgt, py_steps, dirs)))
        fresh = [bid for bid in m.braid_row if bid not in led.invs]
        for bid in fresh:
            c = random_cert(rng, m.braid_row[bid])
            attempt("INSERT INTO braid_invariant (braid_id, braid_hash, permutation, writhe, "
                    "components, linking) VALUES (%s, %s, %s::int[], %s, %s::int[], %s::int[])",
                    bid, c.braid_hash, list(c.permutation), c.writhe, list(c.components),
                    list(c.linking), rejected=bool(inv_ref.certificate_problems(c)))
        for bid in [b for b in m.braid_row if b not in led.nfs]:
            c = random_nf(rng, m.braid_row[bid])
            attempt("INSERT INTO braid_normal_form (braid_id, braid_hash, power, factors, "
                    "normal_word) VALUES (%s, %s, %s, %s::int[], %s::int[])",
                    bid, c.braid_hash, c.power, [list(f) for f in c.factors],
                    list(c.normal_word), rejected=bool(nf_ref.certificate_problems(c)))
        for bid in list(m.braid_row)[:15]:
            c = random_rep(rng, m.braid_row[bid])
            if any(x.q == c.q for x in led.reps[bid]):
                continue
            attempt("INSERT INTO braid_representation (braid_id, q_num, q_den, braid_hash, "
                    "dimension, numerators, denominator) "
                    "VALUES (%s, %s, %s, %s, %s, %s::numeric[], %s)",
                    bid, c.q_num, c.q_den, c.braid_hash, c.dimension, list(c.numerators),
                    c.denominator, rejected=bool(rep_ref.certificate_problems(c)))
        db.q("ROLLBACK TO SAVEPOINT s")
    for table in ("braid_word", "braid_rewrite", "braid_derivation", "braid_invariant",
                  "braid_normal_form", "braid_representation"):
        assert seen[(table, "refused")] > 0 and seen[(table, "accepted")] > 0, table


CHECKS = {"braid_ledger": "check_braid_ledger", "braid_invariants": "check_braid_invariants",
          "braid_normal_forms": "check_braid_normal_forms",
          "braid_representations": "check_braid_representations"}


def test_strict_batch_raises_iff_the_references_report_a_problem(db):
    """In strict mode each Phase 2 batch check (and ``run_phase2_batch_checks()``) raises
    iff the references predict a problem for its module."""
    outcomes = Counter()

    def raises(sql):
        db.q("SAVEPOINT b")
        try:
            db.q(sql)
            return False
        except psycopg2.Error:
            return True
        finally:
            db.q("ROLLBACK TO SAVEPOINT b")

    for seed in range(8):
        db.q("SAVEPOINT s")
        rng = random.Random(2800 + seed)
        led = WholeLedger(db, rng, n_braids=rng.choice([4, 8, 12]), n_rewrites=rng.choice([2, 10]),
                          n_derivations=rng.choice([0, 5]))
        want = led.batch(Counter())
        db.set_mode("strict")
        for module, check in CHECKS.items():
            expected = any(k[0] == module for k in want)
            assert raises(f"SELECT {check}()") == expected, (seed, module)
            outcomes[(module, expected)] += 1
        assert raises("SELECT run_phase2_batch_checks()") == bool(want), seed
        db.q("ROLLBACK TO SAVEPOINT s")
    for module in CHECKS:
        assert outcomes[(module, True)] > 0, module


def test_a_clean_ledger_passes_the_strict_batch(db):
    """A ledger written only through the writers has no problem at all."""
    db.set_mode("strict")
    rng = random.Random(29)
    ids = []
    for _ in range(12):
        n = rng.randint(2, 4)
        w = [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(rng.randint(0, 6))]
        bid = db.one("SELECT register_braid(%s, %s::int[])", n, w)
        db.one("SELECT certify_braid_invariants(%s)", bid)
        db.one("SELECT certify_braid_normal_form(%s)", bid)
        db.one("SELECT certify_braid_representation(%s)", bid)
        ids.append(bid)
    before = violation_ids(db)
    db.q("SELECT run_phase2_batch_checks()")
    assert logged(db, exclude=before) == Counter()
