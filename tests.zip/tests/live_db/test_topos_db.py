"""Migration 011 (topos kernel: subobject classifiers) on a real PostgreSQL.

Formal backing: ``Formal/Topos.lean`` — the pullback check is exactly Mathlib's
``IsPullback`` (``isPullback_iff_pullbackCheck``); "every mono has exactly one
χ passing it" is exactly Mathlib's ``Classifier``
(``classifierCheck_of_classifier``, ``Classifier.ofCheck``,
``hasClassifier_iff_exists_check``); existence and uniqueness are both needed
(``classifier_existence_not_sufficient`` — sets with a three-element Ω, used
below — and ``classifier_uniqueness_not_sufficient``); χ(id_X) = true ∘ !_X
(``chi_id_eq``); a nonempty partial order has a classifier iff it has one
element (``partialOrder_hasClassifier_iff``), used below as an oracle.
"""

from __future__ import annotations

import random
from collections import Counter
from pathlib import Path

import psycopg2
import pytest

from qbx.categorical.topos import all_partial_orders, finite_sets, poset
from tests.topos_examples import injective, random_classifier, surjective


def reset(db) -> None:
    db.conn.rollback()
    db.ids.clear()
    db.cat_of.clear()
    db.morphisms.clear()
    db.composites.clear()


def canon(problems):
    return sorted((r, repr(sorted(d.items()))) for r, d in problems)


def sets012(db, **kw):
    """Finite sets of sizes 0, 1, 2 with Ω = s2, truth = (0 ↦ 1)."""
    model = finite_sets([0, 1, 2], **kw)
    db.load_classifier(model)
    return model


def subobject(db, mono, of=None):
    return db.one("SELECT register_subobject(%s, %s, %s)", db.ids["Set"], db.ids[mono],
                  db.ids[of] if of else None)


def attach(db, sub_id, chi):
    db.q("SELECT attach_characteristic(%s, %s)", sub_id, db.ids[chi])


# ---------------------------------------------------------------------------
# The original migration's bugs
# ---------------------------------------------------------------------------
def test_ill_typed_classifier_is_logged(db):
    """Original bug: a classifier whose true does not end at Ω was accepted."""
    db.category("D")
    db.obj("D", "one")
    db.obj("D", "X")
    db.mor("t", "one", "X")
    db.obj("D", "Om")
    db.classifier("bad", "D", "Om", "t")
    assert db.topos_violations("D") == ["classifier_typing"]
    assert db.topos_problems("bad") == [("classifier_typing", {"omega": "Om", "truth": "t"})]
    db.set_mode("strict")
    db.q("DELETE FROM subobject_classifier WHERE id = %s", db.ids["bad"])
    with pytest.raises(psycopg2.Error, match="not well typed"):
        db.classifier("bad2", "D", "Om", "t")


def test_classifier_without_truth_is_logged(db):
    db.category("D")
    db.obj("D", "Om")
    db.classifier("bad", "D", "Om", None)
    assert db.topos_problems("bad") == [("classifier_typing", {"omega": "Om", "truth": None})]


def test_register_subobject_refuses_ill_typed_input(db):
    """Original bug: a morphism of another category, and an object that is not
    the morphism's target, were accepted."""
    sets012(db)
    db.category("D")
    db.obj("D", "Y")
    for mono, of, msg in (("id_Y", None, "not in the category"),
                          ("s1s2_0", "s1", "not the target")):
        db.q("SAVEPOINT s")
        with pytest.raises(psycopg2.Error, match=msg):
            subobject(db, mono, of)
        db.q("ROLLBACK TO SAVEPOINT s")
    first = subobject(db, "s1s2_0", "s2")
    assert subobject(db, "s1s2_0") == first               # registered once
    db.subobject_row("Set", "s1s2_0", "s1")               # direct insert: logged
    assert db.topos_violations("Set") == ["subobject_typing"]


def test_non_mono_subobject_is_detected(db):
    """Original bug: a morphism that is not a monomorphism was accepted.

    s2 → s1 identifies the four maps s2 → s2 (6 pairs) and the two maps
    s1 → s2 (1 pair)."""
    sets012(db)
    subobject(db, "s2s1_00")
    assert db.topos_problems("Om") == [("not_mono", {"mono": "s2s1_00", "count": 7})]


def test_attach_characteristic_refuses_and_never_replaces(db):
    """Original bug: any morphism was accepted as χ, and ON CONFLICT ... DO
    UPDATE silently replaced an attached χ."""
    sets012(db)
    sub = subobject(db, "s1s2_0")
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="not a morphism X → Ω"):
        attach(db, sub, "s1s2_1")                         # s1 → s2, not s2 → Ω
    db.q("ROLLBACK TO SAVEPOINT s")
    attach(db, sub, "s2s2_10")
    attach(db, sub, "s2s2_10")                            # same χ: no-op
    with pytest.raises(psycopg2.Error, match="already has a characteristic"):
        attach(db, sub, "s2s2_11")
    db.conn.rollback()


def test_ill_typed_characteristic_row_is_logged(db):
    sets012(db)
    sub = subobject(db, "s1s2_0")
    db.characteristic_row(sub, "s1s2_1")
    assert db.topos_violations("Set") == ["characteristic_typing"]
    assert db.topos_problems("Om") == [
        ("characteristic_typing", {"mono": "s1s2_0", "chi": "s1s2_1"})]
    db.set_mode("strict")
    sub2 = subobject(db, "s1s2_1")
    with pytest.raises(psycopg2.Error, match="not well typed"):
        db.characteristic_row(sub2, "s1s2_0")


def test_wrong_characteristic_fails_the_pullback_check(db):
    """Original bug: nothing checked the pullback square.  For m = (0 ↦ 0) the
    right χ is the swap; id_s2 does not even make the square commute, and the
    maps (0 ↦ 1) and the constant 1 do not factor through m."""
    model = sets012(db)
    sub = subobject(db, "s1s2_0")
    attach(db, sub, "id_s2")
    model.register_subobject("s1s2_0")
    model.attach_characteristic("s1s2_0", "id_s2")
    probs = db.topos_problems("Om")
    assert Counter(r for r, _ in probs) == Counter({"pullback_not_commuting": 1,
                                                    "pullback_existence": 2})
    assert ("pullback_existence", {"mono": "s1s2_0", "chi": "id_s2", "f": "s1s2_1"}) in probs
    assert canon(probs) == canon(model.problems())


def test_registered_correct_characteristic_passes(db):
    sets012(db)
    sub = subobject(db, "s1s2_0")
    attach(db, sub, "s2s2_10")
    db.q("INSERT INTO truth_value (classifier_id, name, morphism_id) VALUES (%s, 'true', %s), "
         "(%s, 'false', %s)", db.ids["Om"], db.ids["s1s2_1"], db.ids["Om"], db.ids["s1s2_0"])
    assert db.topos_problems("Om") == []
    db.set_mode("strict")
    assert db.check_topos("Om") is True


def test_truth_value_typing(db):
    sets012(db)
    db.truth_value_row("Om", "half", "s2s2_10")
    assert db.topos_violations("Set") == ["truth_value_typing"]
    assert db.topos_problems("Om") == [("truth_value_typing",
                                        {"name": "half", "morphism": "s2s2_10"})]


def test_terminal_check(db):
    """With true : s2 → s2 the source s2 is not terminal: two maps s1 → s2,
    four maps s2 → s2.  Nothing universal is checked then."""
    model = finite_sets([0, 1, 2])
    model.truth = "s2s2_11"
    db.load_classifier(model)
    assert db.topos_problems("Om") == [
        ("terminal_uniqueness", {"object": o, "count": n})
        for o, n in sorted([("s1", 2), ("s2", 4)], key=lambda p: db.ids[p[0]])]
    assert canon(db.topos_problems("Om")) == canon(model.problems())


def test_register_classifier_writer(db):
    model = finite_sets([0, 1, 2])
    cat = model.category
    db.category(cat.id)
    for o in cat.objects:
        db.obj(cat.id, o)
    for m, (s, t) in cat.morphisms.items():
        if m not in db.ids:
            db.mor(m, s, t)
    for (f, g), h in cat.compositions.items():
        db.comp(g, f, h)
    reg = "SELECT register_subobject_classifier(%s, %s, %s)"
    db.q("SAVEPOINT s")
    with pytest.raises(psycopg2.Error, match="true is not a morphism"):
        db.q(reg, db.ids["Set"], db.ids["s2"], db.ids["id_s1"])
    db.q("ROLLBACK TO SAVEPOINT s")
    cid = db.one(reg, db.ids["Set"], db.ids["s2"], db.ids["s1s2_1"])
    assert db.one(reg, db.ids["Set"], db.ids["s2"], db.ids["s1s2_1"]) == cid
    with pytest.raises(psycopg2.Error, match="already has a classifier"):
        db.q(reg, db.ids["Set"], db.ids["s2"], db.ids["s1s2_0"])


# ---------------------------------------------------------------------------
# Finite sets: Ω = 2 classifies, Ω = 3 does not (uniquely)
# ---------------------------------------------------------------------------
def test_finite_sets_have_a_classifier(db):
    sets012(db)
    assert db.topos_problems("Om") == []
    db.set_mode("strict")
    assert db.check_topos("Om") is True


def test_classify_mono_in_finite_sets(db):
    model = sets012(db)
    assert db.classify("Set", "s1s2_0") == "s2s2_10"      # χ of {0} ⊂ 2 swaps
    assert db.classify("Set", "s1s2_1") == "id_s2"
    assert db.classify("Set", "s0s2_") == "s2s2_00"       # empty subobject: false
    assert db.classify("Set", "s2s1_00") is None          # not a monomorphism
    for m in model.category.morphisms:
        assert db.classify("Set", m) == model.classify(m), m


def test_characteristic_of_identity_is_true_after_bang(db):
    """chi_id_eq: χ(id_X) = true ∘ !_X."""
    model = sets012(db)
    for x in model.category.objects:
        expected = {"s0": "s0s2_", "s1": "s1s2_1", "s2": "s2s2_11"}[x]
        assert db.classify("Set", f"id_{x}") == expected


def test_three_element_omega_classifies_but_not_uniquely(db):
    """classifier_existence_not_sufficient: with Ω = 3 every mono has a
    characteristic morphism, the non-surjective ones several (2^|X∖U|)."""
    model = finite_sets([0, 1, 3], omega_size=3)
    db.load_classifier(model)
    probs = db.topos_problems("Om")
    assert {r for r, _ in probs} == {"characteristic_not_unique"}
    expected = {m for m in model.category.morphisms if injective(m) and not surjective(m)}
    assert {d["mono"] for _, d in probs} == expected
    for _, d in probs:
        a, b = (int(x) for x in d["mono"].split("_")[0].split("s")[1:])
        assert d["count"] == 2 ** (b - a)
    assert canon(probs) == canon(model.problems())


# ---------------------------------------------------------------------------
# Oracle: a partial order has a classifier iff it has one element
# ---------------------------------------------------------------------------
def test_partial_orders_classifier_iff_one_element(db):
    names = ["a", "b", "c"]
    seen = 0
    for n in (1, 2, 3):
        elems = names[:n]
        for rel in all_partial_orders(elems):
            for t in elems:
                for om in elems:
                    if t != om and (t, om) not in rel:
                        continue
                    reset(db)
                    model = poset(elems, rel, t, om)
                    db.load_classifier(model)
                    probs = db.topos_problems("Om")
                    assert (probs == []) == (n == 1), (rel, t, om)
                    assert canon(probs) == canon(model.problems())
                    seen += 1
    assert seen > 50


# ---------------------------------------------------------------------------
# Batch checks
# ---------------------------------------------------------------------------
def test_batch_check_strict_and_permissive(db):
    sets012(db)
    subobject(db, "s2s1_00")
    db.clear_topos_violations()
    assert db.check_topos("Om") is False
    assert db.topos_violations("Set") == ["not_mono"]
    db.set_mode("strict")
    with pytest.raises(psycopg2.Error, match="violates its laws"):
        db.check_topos("Om")


def test_run_all_batch_checks_and_summary_view(db):
    sets012(db)
    subobject(db, "s2s1_00")
    db.clear_topos_violations()
    db.q("SELECT run_all_batch_checks()")
    assert db.topos_violations("Set") == ["not_mono"]
    rows = db.q("SELECT violation_type FROM v_all_violations WHERE module = 'topos' "
                "AND subject = %s", db.ids["Set"])
    assert [r[0] for r in rows] == ["not_mono"]


def test_check_refuses_unknown_classifier(db):
    with pytest.raises(psycopg2.Error, match="not found"):
        db.q("SELECT check_subobject_classifier(gen_random_uuid())")


# ---------------------------------------------------------------------------
# Upgrade path from the original table layout
# ---------------------------------------------------------------------------
def test_upgrade_from_original_layout(db):
    db.q("DROP TABLE truth_value, characteristic_morphism, subobject, subobject_classifier, "
         "topos_violation CASCADE")
    db.q("""
      CREATE TABLE subobject_classifier (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        category_id UUID NOT NULL REFERENCES category(id) ON DELETE CASCADE,
        omega_object_id UUID NOT NULL REFERENCES object(id) ON DELETE CASCADE,
        true_morphism_id UUID REFERENCES morphism(id),
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now(),
        UNIQUE (category_id));
      CREATE TABLE subobject (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        category_id UUID NOT NULL REFERENCES category(id) ON DELETE CASCADE,
        mono_morphism_id UUID NOT NULL REFERENCES morphism(id) ON DELETE CASCADE,
        subobject_of_object_id UUID NOT NULL REFERENCES object(id) ON DELETE CASCADE,
        metadata JSONB DEFAULT '{}'::jsonb, created_at TIMESTAMPTZ DEFAULT now());
      CREATE TABLE characteristic_morphism (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        subobject_id UUID NOT NULL REFERENCES subobject(id) ON DELETE CASCADE,
        morphism_id UUID NOT NULL REFERENCES morphism(id) ON DELETE CASCADE,
        metadata JSONB DEFAULT '{}'::jsonb, UNIQUE (subobject_id));
      CREATE TABLE truth_value (
        id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
        classifier_id UUID NOT NULL REFERENCES subobject_classifier(id) ON DELETE CASCADE,
        name TEXT NOT NULL, data JSONB DEFAULT '{}'::jsonb, UNIQUE (classifier_id, name));
    """)
    path = Path(__file__).resolve().parents[2] / "migrations" / "011_topos_kernel.sql"
    with db.conn.cursor() as cur:
        cur.execute(path.read_text())          # no parameters: '%' is literal
    assert db.one("SELECT count(*) FROM information_schema.columns "
                  "WHERE table_name = 'truth_value' AND column_name = 'morphism_id'") == 1
    # and the upgraded tables work
    sets012(db)
    sub = subobject(db, "s1s2_0")
    attach(db, sub, "s2s2_10")
    assert db.topos_problems("Om") == []


# ---------------------------------------------------------------------------
# Agreement with the in-memory reference engine
# ---------------------------------------------------------------------------
def test_database_agrees_with_python_reference(db):
    rng = random.Random(1111)
    total = Counter()
    for i in range(60):
        model = random_classifier(rng)
        reset(db)
        db.load_classifier(model)
        py = canon(model.problems())
        sql = canon(db.topos_problems("Om"))
        assert sql == py, i
        total.update(r for r, _ in py)
    assert set(total) == {"classifier_typing", "terminal_existence", "terminal_uniqueness",
                          "truth_value_typing", "subobject_typing", "not_mono",
                          "characteristic_typing", "pullback_not_commuting",
                          "pullback_existence", "pullback_uniqueness", "unclassified_mono",
                          "characteristic_not_unique"}
