"""Tests for qbx_bible.manifold: chunked / parallel / prefix / atlas processing must give
exactly what one sequential pass gives."""

import random

import pytest

from qbx_bible import Encoding, encode_text, load_corpus
from qbx_bible.encode import tokenize
from qbx_bible import manifold as mf
from qbx_ir.algebra import invariants as inv


ENCODINGS = [Encoding(8, True), Encoding(8, False), Encoding(23, True)]


@pytest.fixture(scope="module")
def verses():
    return [v.text for v in load_corpus()]


def _fields(s):
    return (s.letters, s.finals, s.writhe, s.positions, s.crossings, s.burau, s.hash_scale,
            s.hash_value, s.words, s.short)


@pytest.mark.parametrize("enc", ENCODINGS)
def test_summary_matches_encoder_and_invariants(verses, enc):
    text = " ".join(verses[:6])
    s = mf.summarize(text, enc)
    braid = encode_text(text, "t", enc).braid
    assert list(s.short) == braid.short_form()
    assert s.positions == inv.permutation(braid)
    assert s.writhe == inv.writhe(braid)
    assert s.words == len(tokenize(text))
    assert mf.closure_components(s) == inv.closure_components(braid)
    assert mf.linking_matrix(s) == inv.linking_matrix(braid)


@pytest.mark.parametrize("enc", ENCODINGS)
def test_random_cuts_merge_exactly(verses, enc):
    rng = random.Random(1234)
    text = "".join(verses)
    whole = mf.summarize(text, enc)
    for _ in range(5):
        cuts = sorted(rng.sample(range(1, len(text)), 12))
        pieces = [text[a:b] for a, b in zip([0] + cuts, cuts + [len(text)])]
        merged = mf.reduce_tree([mf.summarize(p, enc) for p in pieces], enc)
        assert _fields(merged) == _fields(whole)


def test_merge_associative_and_unital(verses):
    enc = Encoding()
    a, b, c = (mf.summarize(v, enc) for v in verses[:3])
    assert _fields(mf.merge(mf.merge(a, b), c)) == _fields(mf.merge(a, mf.merge(b, c)))
    e = mf.identity(enc)
    assert _fields(mf.merge(e, a)) == _fields(a) == _fields(mf.merge(a, e))


def test_burau_fingerprint_respects_braid_relations():
    n = 5
    g = lambda k: mf._burau_generator(n, k)  # noqa: E731
    m = mf._mat_mul
    assert m(m(g(1), g(2)), g(1)) == m(m(g(2), g(1)), g(2))
    assert m(g(1), g(3)) == m(g(3), g(1))
    assert m(g(2), g(-2)) == mf._mat_identity(n)


def test_parallel_equals_sequential(verses):
    enc = Encoding()
    seq = mf.summarize("".join(verses), enc, keep_word=False)
    par = mf.summarize_parallel(verses, enc, workers=2)
    assert _fields(par) == _fields(seq)


def test_prefix_index_segments(verses):
    enc = Encoding()
    idx = mf.PrefixIndex(verses, enc)
    for i, j in [(0, 31), (3, 9), (10, 11), (5, 5), (17, 30)]:
        direct = mf.summarize("".join(verses[i:j]), enc, keep_word=False)
        seg = idx.segment(i, j)
        assert seg["letters"] == direct.letters
        assert seg["finals"] == direct.finals
        assert seg["writhe"] == direct.writhe
        assert seg["positions"] == direct.positions
        assert seg["burau"] == direct.burau
        assert seg["hash"] == direct.hash_value


def test_power_and_memo(verses):
    enc = Encoding()
    refrain = "וַֽיְהִי־עֶ֥רֶב וַֽיְהִי־בֹ֖קֶר "
    for k in (0, 1, 2, 7, 13):
        assert _fields(mf.power(mf.summarize(refrain, enc), k)) == \
            _fields(mf.summarize(refrain * k, enc))
    text = "".join(verses)
    memo, distinct = mf.summarize_words_memo(text, enc)
    assert _fields(memo) == _fields(mf.summarize(text, enc, keep_word=False))
    assert distinct < len(tokenize(text))


def test_rolling_hash_is_horner(verses):
    enc = Encoding()
    s = mf.summarize(verses[0], enc)
    h = 0
    for g in s.short:
        h = (h * mf.HASH_BASE + g) % mf.PRIME
    assert s.hash_value == h
    assert s.hash_scale == pow(mf.HASH_BASE, s.letters, mf.PRIME)


@pytest.mark.parametrize("k", [1, 2, 3, 4])
def test_kgram_atlas_equals_direct(verses, k):
    seq = mf.letter_ordinals("".join(verses))
    direct = mf.kgram_counts(seq, k)
    for size in (1, 2, 3, 7, 50, 10_000):
        assert mf.kgram_counts_atlas(seq, k, size) == direct
    assert mf.kgram_counts_atlas(seq, k, 97, workers=2) == direct
