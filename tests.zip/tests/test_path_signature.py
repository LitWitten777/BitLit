"""Tests for PathSignature and PathValidator."""

import pytest

from qbx.path.signature import PathSignature
from qbx.path.validator import PathValidator
from qbx.core.signing import StubSigner

def _make_sig():
    return PathSignature.build(
        category_id="00000000-0000-0000-0000-000000000001",
        start_object_id="00000000-0000-0000-0000-000000000010",
        end_object_id="00000000-0000-0000-0000-000000000020",
        morphism_chain=["00000000-0000-0000-0000-0000000000a1"],
        metadata={"note": "test path"},
    )

def test_path_signature_build_and_integrity():
    sig = _make_sig()
    assert sig.is_integrity_ok()
    assert len(sig.proof_hash) > 0
    assert len(sig.address_hash) > 0

def test_path_signature_deterministic_proof_hash():
    """Two sigs with same payload (but different path_id) will have different
    proof_hash because path_id is part of canonical bytes. But if we bypass
    path_id... this test just confirms integrity is stable."""
    sig = _make_sig()
    assert sig.recompute_proof_hash() == sig.proof_hash

def test_validator_accepts_untampered():
    sig = _make_sig()
    validator = PathValidator()
    result = validator.validate(sig)
    assert result.ok, result.diagnostics

def test_validator_rejects_tampered_bytes():
    sig = _make_sig()
    # Tamper with canonical_bytes while keeping the stored proof_hash
    tampered = PathSignature(
        path_id=sig.path_id,
        category_id=sig.category_id,
        start_object_id=sig.start_object_id,
        end_object_id=sig.end_object_id,
        morphism_chain=sig.morphism_chain,
        canonical_bytes=b"\xff\xff\xff",  # garbage
        proof_hash=sig.proof_hash,
        address_hash=sig.address_hash,
        metadata=sig.metadata,
    )
    validator = PathValidator()
    result = validator.validate(tampered)
    assert not result.ok
    assert any("mismatch" in d for d in result.diagnostics)

def test_validator_chain_well_formed():
    sig = PathSignature.build(
        category_id="c1",
        start_object_id="X",
        end_object_id="Z",
        morphism_chain=["f", "g"],
    )
    endpoints = {"f": ("X", "Y"), "g": ("Y", "Z")}
    validator = PathValidator()
    result = validator.validate(sig, morphism_endpoints=endpoints)
    assert result.ok, result.diagnostics

def test_validator_chain_broken():
    sig = PathSignature.build(
        category_id="c1",
        start_object_id="X",
        end_object_id="Z",
        morphism_chain=["f", "g"],
    )
    endpoints = {"f": ("X", "Y"), "g": ("Y_bad", "Z")}  # broken!
    validator = PathValidator()
    result = validator.validate(sig, morphism_endpoints=endpoints)
    assert not result.ok
    assert any("broken" in d for d in result.diagnostics)