"""In-memory sheaf checker (``qbx.categorical.sheaf``), Phase 1 sprint 9.

Formal backing: ``Formal/Sheaf.lean`` — locality and gluing over every cover
are exactly Mathlib's ``IsSheaf`` (``isSheaf_iff_locality_and_gluing``); a sheaf
has one section over ∅ (``uniqueBot``); neither half implies the other
(``constBool_gluing_not_locality``, ``constEmpty_locality_not_gluing``); for a
sheaf, compatible families on a cover ↔ sections (``card_compatible_eq``); the
presheaf of all functions passes (``presheafToTypes_locality_and_gluing``).
"""

from __future__ import annotations

import random
from collections import Counter

import pytest

from qbx.categorical.sheaf import (
    PRESHEAF_REASONS,
    SITE_REASONS,
    CohomologyRecord,
    FiniteSite,
    LinearPresheaf,
    Presheaf,
    SheafChecker,
    SheafViolation,
    constant_linear,
    constant_presheaf,
    finite_space,
    functions_presheaf,
    generated_topology,
    matmul_f2,
    rank_f2,
)
from qbx.core.enforced_functor import EnforcementMode
from tests.sheaf_examples import (
    canon,
    hollow_triangle,
    random_presheaf,
    random_site,
    random_topology,
    register_all_covers,
    two_point_discrete,
)


# ---------------------------------------------------------------------------
# Sites
# ---------------------------------------------------------------------------
def test_generated_topologies_are_valid():
    rng = random.Random(7)
    for _ in range(100):
        S = random_topology(rng)
        assert S.problems() == []


def test_site_reasons():
    S = finite_space([[], ["a"], ["b"], ["a", "b", "c"]])
    assert canon(S.problems()) == canon([("topology_union", {"opens": ["U_a", "U_b"]})])
    S = finite_space([["a"], ["b"], ["a", "b"]])
    S.base = "U_a"
    assert sorted(r for r, _ in S.problems()) == ["base_typing", "topology_empty",
                                                  "topology_intersection"]
    S = two_point_discrete()
    S.add_cover("short", "U_ab", ["U_a"])
    S.add_cover("bad", "U_a", ["U_b"])
    S.add_cover("nowhere", "U_x", [])
    assert canon(S.problems()) == canon([
        ("cover_not_covering", {"cover": "short"}),
        ("cover_typing", {"cover": "bad", "open": "U_b"}),
        ("cover_typing", {"cover": "nowhere", "open": "U_x"}),
    ])
    with pytest.raises(ValueError):
        S.add_open("again", ["a"])


def test_presheaf_on_invalid_site_reports_only_that():
    S = finite_space([["a"], ["a", "b"]])          # no empty open
    F = functions_presheaf(S, {"a": ["0"], "b": ["0"]})
    assert F.problems() == [("site_invalid", {"site": "S"})]


# ---------------------------------------------------------------------------
# The Lean results, checked on finite spaces
# ---------------------------------------------------------------------------
def test_functions_presheaf_is_a_sheaf():
    """``presheafToTypes_locality_and_gluing``: passes every check, every cover."""
    rng = random.Random(11)
    for _ in range(40):
        S = random_topology(rng)
        values = {p: ["0", "1", "2"][:rng.randint(1, 3)]
                  for p in frozenset().union(*S.opens.values())}
        register_all_covers(S)
        F = functions_presheaf(S, values)
        assert F.problems() == []
        assert F.is_sheaf()


def test_compatible_families_count_sections_for_a_sheaf():
    """``card_compatible_eq``: on every cover, #H⁰ = #F(U)."""
    rng = random.Random(12)
    for _ in range(30):
        S = random_topology(rng)
        F = functions_presheaf(S, {p: ["0", "1"] for p in frozenset().union(*S.opens.values())})
        for u in S.opens:
            for members in S.all_covers(u):
                assert len(F.compatible_families(u, members)) == len(F.F(u))


def test_constant_two_values_glues_but_fails_locality():
    """``constBool_gluing_not_locality``, on every cover of every open."""
    S = generated_topology(["a", "b", "c"], [["a"], ["b", "c"]])
    F = constant_presheaf(S, ["x", "y"])
    assert F.is_presheaf()
    for u in S.opens:
        for members in S.all_covers(u):
            assert F.gluing_failures(u, members) == 0
    assert F.locality_failures("U_empty", []) == 1
    assert F.problems() == [("sheaf_empty_open", {"count": 2})]
    assert not F.is_sheaf()


def test_constant_empty_has_locality_but_does_not_glue():
    """``constEmpty_locality_not_gluing``."""
    S = generated_topology(["a", "b"], [["a"]])
    F = constant_presheaf(S, [])
    for u in S.opens:
        for members in S.all_covers(u):
            assert F.locality_failures(u, members) == 0
    assert F.gluing_failures("U_empty", []) == 1
    assert F.problems() == [("sheaf_empty_open", {"count": 0})]


def test_constant_presheaf_fails_gluing_on_disjoint_cover():
    """F(U) = {x, y}, F(∅) = {*}: on {a} ⊔ {b} the families (x, y), (y, x) do not glue."""
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    F = constant_presheaf(S, ["x", "y"], ["*"])
    assert F.problems() == [("sheaf_gluing", {"cover": "split", "count": 2})]


def test_sheaf_has_one_section_over_empty():
    """``uniqueBot``: whenever the exhaustive check passes, #F(∅) = 1."""
    rng = random.Random(13)
    n_sheaves = 0
    for _ in range(150):
        S = random_topology(rng)
        F = random_presheaf(rng, S)
        if F.is_sheaf():
            n_sheaves += 1
            assert len(F.F(S.empty_open)) == 1
    assert n_sheaves > 10


def test_registered_covers_check_matches_exhaustive_check():
    """With every cover registered, the checker's verdict is ``is_sheaf``
    (``isSheaf_iff_locality_and_gluing`` on finite spaces)."""
    rng = random.Random(14)
    verdicts = Counter()
    for _ in range(150):
        S = random_topology(rng)
        register_all_covers(S)
        F = random_presheaf(rng, S)
        F.cohomology.clear()
        F.cochains.clear()
        assert (F.problems() == []) == F.is_sheaf()
        verdicts[F.is_sheaf()] += 1
    assert verdicts[True] > 10 and verdicts[False] > 10


# ---------------------------------------------------------------------------
# Presheaf reasons
# ---------------------------------------------------------------------------
def test_functoriality_reasons():
    S = generated_topology(["a", "b"], [["a"]])
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]})
    del F.restrictions[("U_ab", "U_a", "a=0,b=0")]
    assert F.problems() == [("restriction_missing",
                             {"from": "U_ab", "to": "U_a", "section": "a=0,b=0"})]
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]})
    F.restrictions[("U_a", "U_a", "a=0")] = "a=1"
    assert F.problems() == [("restriction_identity", {"open": "U_a", "section": "a=0"})]
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]})
    F.restrictions[("U_ab", "U_a", "a=0,b=0")] = "a=1"
    F.sections["U_empty"].append("()'")
    F.restrictions[("U_a", "U_empty", "a=1")] = "()'"
    F.restrictions[("U_empty", "U_empty", "()'")] = "()'"
    assert canon(F.problems()) == canon([
        ("restriction_composition",
         {"from": "U_ab", "via": "U_a", "to": "U_empty", "section": "a=0,b=0"}),
        ("restriction_composition",
         {"from": "U_ab", "via": "U_a", "to": "U_empty", "section": "a=1,b=0"})])


def test_typing_reasons_stop_later_stages():
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    F = functions_presheaf(S, {"a": ["0"], "b": ["0"]})
    F.sections["U_x"] = ["s"]
    F.restrictions[("U_a", "U_ab", "a=0")] = "a=0,b=0"   # wrong direction
    F.cohomology.append(CohomologyRecord(-1, None, {"rank": 0}))
    F.cohomology.append(CohomologyRecord(0, "split", {"cardinality": True}))
    F.cohomology.append(CohomologyRecord(2, "nope", {"rank": 1}))
    del F.restrictions[("U_ab", "U_a", "a=0,b=0")]       # would be restriction_missing
    assert canon(F.problems()) == canon([
        ("cohomology_typing", {"degree": -1, "cover": None}),
        ("cohomology_typing", {"degree": 0, "cover": "split"}),
        ("cohomology_typing", {"degree": 2, "cover": "nope"}),
        ("restriction_typing", {"from": "U_a", "to": "U_ab", "section": "a=0"}),
        ("section_typing", {"open": "U_x", "section": "s"}),
    ])


def test_h0_descriptor_is_checked():
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0", "1", "2"]})
    F.cohomology.append(CohomologyRecord(0, "split", {"cardinality": 6}))
    assert F.problems() == []
    F.cohomology.append(CohomologyRecord(0, "split", {"cardinality": 5}))
    assert F.problems() == [("cohomology_h0_mismatch",
                             {"cover": "split", "recorded": 5, "computed": 6})]


def test_locality_failure_counts_pairs():
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    F = functions_presheaf(S, {"a": ["0"], "b": ["0"]})
    for extra in ("t1", "t2"):
        F.sections["U_ab"].append(extra)
        F.restrictions[("U_ab", "U_ab", extra)] = extra
        for v in ("U_a", "U_b", "U_empty"):
            F.restrictions[("U_ab", v, extra)] = F.restrictions[("U_ab", v, "a=0,b=0")]
    assert F.problems() == [("sheaf_locality", {"cover": "split", "count": 3})]


def test_descent_verification():
    S = two_point_discrete()
    S.add_cover("split", "U_ab", ["U_a", "U_b"])
    F = functions_presheaf(S, {"a": ["0", "1"], "b": ["0"]})
    C = constant_presheaf(S, ["x", "y"], ["*"])
    assert len(F.gluings("U_ab", ["U_a", "U_b"], ("a=1", "b=0"))) == 1
    assert C.gluings("U_ab", ["U_a", "U_b"], ("x", "y")) == []


def test_checker_modes():
    S = two_point_discrete()
    F = constant_presheaf(S, ["x", "y"])
    chk = SheafChecker(EnforcementMode.PERMISSIVE)
    assert chk.check(F) is False and chk.violations == [("sheaf_empty_open", {"count": 2})]
    assert chk.check_site(S) is True
    with pytest.raises(SheafViolation):
        SheafChecker(EnforcementMode.STRICT).check(F)


def test_random_presheaves_exercise_every_reason():
    rng = random.Random(15)
    site_seen, seen = Counter(), Counter()
    for _ in range(600):
        S = random_site(rng)
        site_seen.update(r for r, _ in S.problems())
        F = random_presheaf(rng, S)
        seen.update(r for r, _ in F.problems())
    assert set(site_seen) == set(SITE_REASONS)
    assert set(seen) == set(PRESHEAF_REASONS)


# ---------------------------------------------------------------------------
# Čech cohomology over F₂
# ---------------------------------------------------------------------------
def test_rank_f2():
    assert rank_f2([[1, 1], [1, 1]]) == 1
    assert rank_f2([[1, 0, 1], [0, 1, 1], [1, 1, 0]]) == 2
    assert rank_f2([]) == 0


def test_nerve_of_hollow_and_filled_triangle():
    S = hollow_triangle()
    L = constant_linear(S)
    assert L.is_functorial()
    assert L.cohomology(S.covers["tri"].members) == [1, 1, 0]
    T = generated_topology(["p", "q", "r", "z"], [["p", "q", "z"], ["p", "r", "z"],
                                                  ["q", "r", "z"]])
    assert constant_linear(T).cohomology(["U_pqz", "U_prz", "U_qrz"]) == [1, 0, 0]


def test_two_components():
    S = two_point_discrete()
    assert constant_linear(S, 2).cohomology(["U_a", "U_b"]) == [4, 0]


def _functions_linear(S: FiniteSite) -> LinearPresheaf:
    """U ↦ F₂^U with projections: the sheaf of all F₂-valued functions."""
    L = LinearPresheaf(S)
    order = {u: sorted(S.opens[u]) for u in S.opens}
    for u in S.opens:
        L.dims[u] = len(order[u])
    for u in S.opens:
        for v in S.opens:
            if S.subset(v, u):
                L.maps[(u, v)] = [[int(p == q) for q in order[u]] for p in order[v]]
    return L


def test_function_sheaf_is_cech_acyclic():
    """Pointwise, the Čech complex is a full simplex: H⁰ = F₂^U, Hⁿ = 0 above."""
    rng = random.Random(16)
    for _ in range(40):
        S = random_topology(rng, max_points=4)
        L = _functions_linear(S)
        assert L.is_functorial()
        for u in S.opens:
            covers = list(S.all_covers(u))
            members = rng.choice(covers)
            H = L.cohomology(members)
            if members:
                assert H == [len(S.opens[u])] + [0] * (len(members) - 1)


def test_d_squared_and_euler_characteristic():
    rng = random.Random(17)
    for _ in range(40):
        S = random_topology(rng, max_points=4)
        L = constant_linear(S, rng.randint(1, 2))
        u = S.base
        members = rng.choice(list(S.all_covers(u)))
        n = len(members)
        dims = [L.cochain_dim(members, k) for k in range(n)]
        for k in range(n - 2):
            d0 = L.differential(members, k)
            d1 = L.differential(members, k + 1)
            assert all(x == 0 for row in matmul_f2(d1, d0, dims[k + 1], dims[k]) for x in row)
        H = L.cohomology(members)
        assert sum((-1) ** k * dims[k] for k in range(n)) == sum((-1) ** k * H[k]
                                                                 for k in range(n))
