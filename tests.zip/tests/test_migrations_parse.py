"""Static check: every migration parses as PostgreSQL, including PL/pgSQL bodies.

Uses `pglast` (libpg_query, the real PostgreSQL parser).  Skipped when
`pglast` is not installed.  This does not execute the SQL.
"""

from pathlib import Path

import pytest

pglast = pytest.importorskip("pglast")
from pglast.parser import parse_plpgsql_json, split  # noqa: E402

MIGRATIONS = sorted((Path(__file__).resolve().parent.parent / "migrations").glob("*.sql"))


@pytest.mark.parametrize("path", MIGRATIONS, ids=lambda p: p.name)
def test_migration_parses(path):
    sql = path.read_text()
    statements = split(sql)   # raises on a SQL syntax error
    for stmt in statements:
        head = stmt.lstrip().upper()
        if head.startswith("CREATE") and " FUNCTION " in head[:80]:
            parse_plpgsql_json(stmt)   # raises on a PL/pgSQL syntax error


def _table_columns():
    """Column names of every `CREATE TABLE` across all migrations (via the parser)."""
    from pglast import ast, parse_sql

    cols = {}
    for path in MIGRATIONS:
        for raw in parse_sql(path.read_text()):
            stmt = raw.stmt
            if isinstance(stmt, ast.CreateStmt):
                cols[stmt.relation.relname] = {
                    e.colname for e in (stmt.tableElts or ()) if isinstance(e, ast.ColumnDef)
                }
    return cols


def test_all_violations_view_references_existing_columns():
    """`v_all_violations` (017) must only read columns that exist (it read a
    missing `naturality_violation.law` before Phase 1)."""
    from pglast import ast, parse_sql

    cols = _table_columns()
    sql = (MIGRATIONS[0].parent / "017_all_triggers.sql").read_text()
    view = next(
        r.stmt for r in parse_sql(sql)
        if isinstance(r.stmt, ast.ViewStmt) and r.stmt.view.relname == "v_all_violations"
    )
    selects, node = [], view.query
    while node.op != 0 and node.larg is not None:   # unwrap UNION ALL tree
        selects.append(node.rarg)
        node = node.larg
    selects.append(node)
    assert len(selects) == 17   # + enriched (sprint 5), topos (sprint 8), address_violation (sprint 10), hebrew_violation (sprint 11), governance_violation (sprint 12), empirical_violation (sprint 13)
    for sel in selects:
        table = sel.fromClause[0].relname
        for target in sel.targetList:
            if isinstance(target.val, ast.ColumnRef):
                name = target.val.fields[-1].sval
                assert name in cols[table], f"{table}.{name} does not exist"
