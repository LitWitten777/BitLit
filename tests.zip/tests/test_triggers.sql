-- ============================================================================
-- Categorical Ledger — SQL test suite
-- ============================================================================
-- Run with: psql "$PG_DSN" -f tests/test_triggers.sql
-- Assumes migrations 001–019 have been applied.
-- ============================================================================

\set ON_ERROR_STOP off

BEGIN;

-- ---------------------------------------------------------------------------
-- Test 1: Functor identity law (strict mode)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  cat UUID;
  x UUID;
  id_x UUID;
  bogus UUID;
  F UUID;
  violation_count INT;
BEGIN
  RAISE NOTICE 'Test 1: Functor identity law in strict mode';

  PERFORM qbx_set_strict();

  INSERT INTO category (name) VALUES ('C_test1_' || gen_random_uuid()::text) RETURNING id INTO cat;
  INSERT INTO object (category_id, name) VALUES (cat, 'X') RETURNING id INTO x;
  INSERT INTO morphism (category_id, source_id, target_id, name)
    VALUES (cat, x, x, 'id_X') RETURNING id INTO id_x;
  INSERT INTO identity_morphism (category_id, object_id, morphism_id)
    VALUES (cat, x, id_x);
  INSERT INTO morphism (category_id, source_id, target_id, name)
    VALUES (cat, x, x, 'bogus') RETURNING id INTO bogus;

  INSERT INTO functor (name, source_category_id, target_category_id)
    VALUES ('F_test1_' || gen_random_uuid()::text, cat, cat) RETURNING id INTO F;
  INSERT INTO functor_object_map (functor_id, source_object_id, target_object_id)
    VALUES (F, x, x);

  -- This should raise
  BEGIN
    INSERT INTO functor_morphism_map (functor_id, source_morphism_id, target_morphism_id)
      VALUES (F, id_x, bogus);
    RAISE EXCEPTION 'FAIL: identity law should have been enforced';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE '  PASS: strict mode raised on identity law violation';
  END;
END $$;

-- ---------------------------------------------------------------------------
-- Test 2: Functor identity law (permissive mode)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  cat UUID;
  x UUID;
  id_x UUID;
  bogus UUID;
  F UUID;
  violation_count INT;
BEGIN
  RAISE NOTICE 'Test 2: Functor identity law in permissive mode';

  PERFORM qbx_set_permissive();

  INSERT INTO category (name) VALUES ('C_test2_' || gen_random_uuid()::text) RETURNING id INTO cat;
  INSERT INTO object (category_id, name) VALUES (cat, 'X') RETURNING id INTO x;
  INSERT INTO morphism (category_id, source_id, target_id, name)
    VALUES (cat, x, x, 'id_X') RETURNING id INTO id_x;
  INSERT INTO identity_morphism (category_id, object_id, morphism_id)
    VALUES (cat, x, id_x);
  INSERT INTO morphism (category_id, source_id, target_id, name)
    VALUES (cat, x, x, 'bogus') RETURNING id INTO bogus;

  INSERT INTO functor (name, source_category_id, target_category_id)
    VALUES ('F_test2_' || gen_random_uuid()::text, cat, cat) RETURNING id INTO F;
  INSERT INTO functor_object_map (functor_id, source_object_id, target_object_id)
    VALUES (F, x, x);

  INSERT INTO functor_morphism_map (functor_id, source_morphism_id, target_morphism_id)
    VALUES (F, id_x, bogus);

  SELECT COUNT(*) INTO violation_count
    FROM functor_law_violation WHERE functor_id = F;

  IF violation_count > 0 THEN
    RAISE NOTICE '  PASS: permissive mode logged % violation(s)', violation_count;
  ELSE
    RAISE EXCEPTION 'FAIL: permissive mode should log a violation';
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- Test 3: Path signature integrity
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  cat UUID;
  x UUID;
  y UUID;
  f UUID;
BEGIN
  RAISE NOTICE 'Test 3: Path signature integrity';

  INSERT INTO category (name) VALUES ('C_test3_' || gen_random_uuid()::text) RETURNING id INTO cat;
  INSERT INTO object (category_id, name) VALUES (cat, 'X') RETURNING id INTO x;
  INSERT INTO object (category_id, name) VALUES (cat, 'Y') RETURNING id INTO y;
  INSERT INTO morphism (category_id, source_id, target_id, name)
    VALUES (cat, x, y, 'f') RETURNING id INTO f;

  BEGIN
    INSERT INTO path_signature
      (category_id, start_object_id, end_object_id, morphism_chain,
       canonical_bytes, proof_hash, address_hash)
    VALUES (cat, x, y, ARRAY[f]::UUID[], ''::bytea, '', '');
    RAISE EXCEPTION 'FAIL: empty proof_hash should be rejected';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE '  PASS: empty proof_hash rejected';
  END;

  BEGIN
    INSERT INTO path_signature
      (category_id, start_object_id, end_object_id, morphism_chain,
       canonical_bytes, proof_hash, address_hash)
    VALUES (cat, x, y, ARRAY[]::UUID[], 'data'::bytea, 'hash', 'addr');
    RAISE EXCEPTION 'FAIL: empty morphism_chain should be rejected';
  EXCEPTION WHEN OTHERS THEN
    RAISE NOTICE '  PASS: empty morphism_chain rejected';
  END;
END $$;

-- ---------------------------------------------------------------------------
-- Test 4: Hebrew gematria auto-computation
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  w UUID;
  gem INT;
  expected INT := 300 + 30 + 6 + 600;  -- shin lamed vav final-mem = 936 (finals 500–900, skill R7)
BEGIN
  RAISE NOTICE 'Test 4: Hebrew gematria auto-computation';

  INSERT INTO hebrew_word (text, root) VALUES ('שלום', 'שלם') RETURNING id INTO w;
  SELECT total_gematria INTO gem FROM hebrew_word WHERE id = w;

  IF gem = expected THEN
    RAISE NOTICE '  PASS: gematria(שלום) = %', gem;
  ELSE
    RAISE EXCEPTION 'FAIL: expected %, got %', expected, gem;
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- Test 5: Enforcement mode helpers
-- ---------------------------------------------------------------------------
DO $$
BEGIN
  RAISE NOTICE 'Test 5: enforcement mode helpers';

  PERFORM qbx_set_strict();
  IF NOT qbx_is_strict() THEN
    RAISE EXCEPTION 'FAIL: qbx_is_strict should be true after qbx_set_strict';
  END IF;

  PERFORM qbx_set_permissive();
  IF qbx_is_strict() THEN
    RAISE EXCEPTION 'FAIL: qbx_is_strict should be false after qbx_set_permissive';
  END IF;

  RAISE NOTICE '  PASS: mode toggle works';
END $$;

-- ---------------------------------------------------------------------------
-- Test 6: Policy registration
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  p UUID;
BEGIN
  RAISE NOTICE 'Test 6: Policy registration';

  p := register_policy('test_policy_' || gen_random_uuid()::text, 'test',
                       '{"rules":[]}'::jsonb, '□', 'soft');

  IF p IS NOT NULL THEN
    RAISE NOTICE '  PASS: policy registered %', p;
  END IF;
END $$;

-- ---------------------------------------------------------------------------
-- Test 7: Governance (migration 015): computed check results, audit chain
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  p UUID;
  l UUID;
  r TEXT;
  n INT;
BEGIN
  RAISE NOTICE 'Test 7: Governance modalities';
  PERFORM register_governance_context('t7_dev');
  PERFORM register_governance_context('t7_prod');
  PERFORM register_governance_access('alethic', 't7_dev', 't7_dev');
  PERFORM register_governance_access('alethic', 't7_prod', 't7_prod');
  PERFORM register_governance_access('alethic', 't7_dev', 't7_prod');
  p := register_policy('t7_policy', 'release', '{}'::jsonb, '□', 'hard');
  l := log_policy_check(NULL, p, 't7_dev', '{"t7_dev": true, "t7_prod": false}'::jsonb);
  SELECT result INTO r FROM policy_check_log WHERE id = l;
  IF r <> 'fail' THEN
    RAISE EXCEPTION '  FAIL: □ over {dev, prod} with prod false should fail, got %', r;
  END IF;
  PERFORM record_audit('t7', 'release', NULL, NULL, '{}'::jsonb);
  n := check_audit_chain();
  IF n <> 0 THEN
    RAISE EXCEPTION '  FAIL: audit chain has % problem(s)', n;
  END IF;
  RAISE NOTICE '  PASS: check result computed, audit chain intact';
END $$;

-- ---------------------------------------------------------------------------
-- Test 8: Empirical grounding (migration 016): validation, incentive claims
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  c UUID;
  b UUID;
  ok BOOLEAN;
  refused BOOLEAN := FALSE;
BEGIN
  RAISE NOTICE 'Test 8: Empirical grounding';
  c := register_measurement_contract('t8_contract', 'temperature', '["range_check"]'::jsonb,
                                     '{"min": 0, "max": 10}'::jsonb);
  b := record_measurement_bundle('[{"value": 9.7, "uncertainty": 0.3}]'::jsonb);
  ok := validate_measurement_bundle(b, c);
  IF NOT ok THEN
    RAISE EXCEPTION '  FAIL: [9.4, 10.0] lies within [0, 10]';
  END IF;
  b := record_measurement_bundle('[{"value": 9.8, "uncertainty": 0.3}]'::jsonb);
  IF validate_measurement_bundle(b, c) THEN
    RAISE EXCEPTION '  FAIL: [9.5, 10.1] does not lie within [0, 10]';
  END IF;
  BEGIN
    PERFORM register_mechanism('t8_overpriced',
      '{"types": ["lo", "hi"], "outcomes": ["none", "item"],
        "allocation": {"lo": "none", "hi": "item"}, "payment": {"lo": 0, "hi": 2.5},
        "valuation": {"lo": {"none": 0, "item": 1}, "hi": {"none": 0, "item": 2}}}'::jsonb,
      '{"ic": true}'::jsonb);
  EXCEPTION WHEN others THEN
    refused := TRUE;
  END;
  IF NOT refused THEN
    RAISE EXCEPTION '  FAIL: a mechanism claiming IC with a profitable misreport was accepted';
  END IF;
  RAISE NOTICE '  PASS: range check exact at the boundary, false IC claim refused';
END $$;


-- ---------------------------------------------------------------------------
-- Test 9: Braid ledger (migration 019): checked rewrites, derivations
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  a UUID;
  r UUID;
  b UUID;
  refused BOOLEAN := FALSE;
BEGIN
  RAISE NOTICE 'Test 9: Braid ledger';
  a := register_braid(3, ARRAY[1, 2, 1]);
  r := record_braid_rewrite(a, 'R03', 0);
  SELECT output_braid_id INTO b FROM braid_rewrite WHERE id = r;
  IF (SELECT word FROM braid_word WHERE id = b) <> ARRAY[2, 1, 2] THEN
    RAISE EXCEPTION '  FAIL: R03 on σ1σ2σ1 must give σ2σ1σ2';
  END IF;
  PERFORM record_braid_derivation(b, ARRAY[r], ARRAY[false]);
  IF NOT braid_equality_certified(a, b) THEN
    RAISE EXCEPTION '  FAIL: the derivation certifies σ1σ2σ1 = σ2σ1σ2';
  END IF;
  BEGIN
    PERFORM record_braid_rewrite(a, 'R01', 0);
  EXCEPTION WHEN others THEN
    refused := TRUE;
  END;
  IF NOT refused THEN
    RAISE EXCEPTION '  FAIL: R01 does not apply to σ1σ2σ1 at position 0';
  END IF;
  RAISE NOTICE '  PASS: rewrite recomputed, derivation certified, inapplicable rule refused';
END $$;

-- ---------------------------------------------------------------------------
-- Test 10: Braid invariant certificates (migration 020)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  x UUID;
  e UUID;
  a UUID;
  r UUID;
  b UUID;
BEGIN
  RAISE NOTICE 'Test 10: Braid invariant certificates';
  x := register_braid(3, ARRAY[1, 1, -2, -2]);
  e := register_braid(3, ARRAY[]::int[]);
  PERFORM certify_braid_invariants(x);
  PERFORM certify_braid_invariants(e);
  IF braid_invariant_differences(x, e) IS DISTINCT FROM ARRAY['linking'] THEN
    RAISE EXCEPTION '  FAIL: σ1²σ2⁻² and ε must differ exactly in their linking numbers';
  END IF;
  a := register_braid(3, ARRAY[1, 2, 1]);
  r := record_braid_rewrite(a, 'R03', 0);
  SELECT output_braid_id INTO b FROM braid_rewrite WHERE id = r;
  PERFORM certify_braid_invariants(a);
  PERFORM certify_braid_invariants(b);
  IF braid_inequality_certified(a, b) OR check_braid_invariants() <> 0 THEN
    RAISE EXCEPTION '  FAIL: certificates must agree along an accepted rewrite';
  END IF;
  RAISE NOTICE '  PASS: certificates recomputed, inequality certified, transport consistent';
END $$;

-- ---------------------------------------------------------------------------
-- Test 11: Garside normal-form certificates (migration 021)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  a UUID;
  b UUID;
  c UUID;
  r UUID;
  e UUID;
BEGIN
  RAISE NOTICE 'Test 11: Garside normal-form certificates';
  a := register_braid(3, ARRAY[1, 2, 1]);
  b := register_braid(3, ARRAY[2, 1, 2]);
  c := register_braid(3, ARRAY[1]);
  PERFORM certify_braid_normal_form(a);
  PERFORM certify_braid_normal_form(b);
  PERFORM certify_braid_normal_form(c);
  IF NOT braid_nf_equality_certified(a, b) THEN
    RAISE EXCEPTION '  FAIL: σ1σ2σ1 and σ2σ1σ2 must be certified equal (both are Δ)';
  END IF;
  IF braid_normal_form_equal(a, c) IS DISTINCT FROM FALSE THEN
    RAISE EXCEPTION '  FAIL: Δ and σ1 must have different normal forms';
  END IF;
  r := record_braid_rewrite(register_braid(3, ARRAY[1, -1, 2]), 'R01', 0);
  SELECT output_braid_id INTO e FROM braid_rewrite WHERE id = r;
  PERFORM certify_braid_normal_form((SELECT input_braid_id FROM braid_rewrite WHERE id = r));
  PERFORM certify_braid_normal_form(e);
  IF check_braid_normal_forms() <> 0 THEN
    RAISE EXCEPTION '  FAIL: normal forms must agree along an accepted rewrite';
  END IF;
  RAISE NOTICE '  PASS: normal forms recomputed, equality certified, transport consistent';
END $$;

-- ---------------------------------------------------------------------------
-- Test 12: exact representation certificates (migration 022)
-- ---------------------------------------------------------------------------
DO $$
DECLARE
  a UUID;
  b UUID;
  c UUID;
  x UUID;
  y UUID;
  r UUID;
BEGIN
  RAISE NOTICE 'Test 12: exact representation certificates';
  a := register_braid(3, ARRAY[1, 2, 1]);
  b := register_braid(3, ARRAY[2, 1, 2]);
  c := register_braid(3, ARRAY[1, 1, 2, 2, -1, -1, -2, -2]);
  x := register_braid(3, ARRAY[]::int[]);
  PERFORM certify_braid_representation(a);
  PERFORM certify_braid_representation(b);
  PERFORM certify_braid_representation(c);
  PERFORM certify_braid_representation(x);
  PERFORM certify_braid_representation(a, 3, 2);
  PERFORM certify_braid_representation(b, 3, 2);
  IF braid_representation_equal(a, b, 2, 1) IS DISTINCT FROM TRUE
     OR braid_representation_equal(a, b, 3, 2) IS DISTINCT FROM TRUE THEN
    RAISE EXCEPTION '  FAIL: σ1σ2σ1 and σ2σ1σ2 must have the same exact matrix';
  END IF;
  IF NOT braid_representation_inequality_certified(c, x) THEN
    RAISE EXCEPTION '  FAIL: the commutator σ1²σ2²σ1⁻²σ2⁻² must be certified different from ε';
  END IF;
  r := record_braid_rewrite(register_braid(3, ARRAY[1, -1, 2]), 'R01', 0);
  y := (SELECT output_braid_id FROM braid_rewrite WHERE id = r);
  PERFORM certify_braid_representation((SELECT input_braid_id FROM braid_rewrite WHERE id = r));
  PERFORM certify_braid_representation(y);
  IF check_braid_representations() <> 0 THEN
    RAISE EXCEPTION '  FAIL: representation certificates must agree along an accepted rewrite';
  END IF;
  RAISE NOTICE '  PASS: exact matrices recomputed, inequality certified, transport consistent';
END $$;

ROLLBACK;

\echo '================================================================='
\echo 'SQL test suite complete.'
\echo '================================================================='