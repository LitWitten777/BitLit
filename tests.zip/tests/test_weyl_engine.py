"""Tests for the E8 Weyl reflection engine."""

import pytest

from qbx.core.exceptions import CapabilityRequiredError
from qbx.weyl.e8_roots import E8_ROOTS, is_e8_root, norm_squared
from qbx.weyl.engine import WeylEngine

def test_e8_has_240_roots():
    assert len(E8_ROOTS) == 240
    for r in E8_ROOTS:
        assert abs(norm_squared(r) - 2.0) < 1e-9

def test_is_e8_root():
    assert is_e8_root((1.0, -1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))
    assert not is_e8_root((1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0))

def test_reflection_of_root_is_root():
    engine = WeylEngine()
    seed = E8_ROOTS[0]
    # Reflecting a root across another root stays in the root system
    for i in range(10):
        result = engine.reflect(seed, i)
        assert is_e8_root(result), f"reflection by root {i} left the root system"

def test_reflection_is_involution():
    """Reflecting twice by the same root returns the original."""
    engine = WeylEngine()
    seed = E8_ROOTS[5]
    for i in range(5):
        once = engine.reflect(seed, i)
        twice = engine.reflect(once, i)
        assert twice == seed, f"reflection by root {i} is not an involution"

def test_orbit_of_root_is_finite_and_cached():
    engine = WeylEngine()
    seed = E8_ROOTS[0]
    orbit = engine.orbit(seed, max_size=300)
    assert len(orbit) > 0
    assert len(orbit) <= 300
    assert orbit.canonical == min(orbit.members)

def test_capability_required_for_large_expansion():
    engine = WeylEngine(cache_max=0, require_capability=True)
    seed = (0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5)
    with pytest.raises(CapabilityRequiredError):
        engine.orbit(seed, max_size=1000, capability_token=None)

def test_capability_granted_allows_expansion():
    engine = WeylEngine(cache_max=0, require_capability=True)
    engine.grant_capability("test-token")
    seed = E8_ROOTS[0]
    orbit = engine.orbit(seed, max_size=500, capability_token="test-token")
    assert len(orbit) > 0

def test_orbit_cached_on_second_call():
    engine = WeylEngine()
    seed = E8_ROOTS[3]
    o1 = engine.orbit(seed, max_size=300)
    o2 = engine.orbit(seed, max_size=300)
    assert o1.canonical == o2.canonical
    assert len(o1) == len(o2)