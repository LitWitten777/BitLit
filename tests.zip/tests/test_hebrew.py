"""The Hebrew primacy reference checks (``qbx.hebrew``; migration 014).

The live-database tests (``tests/live_db/test_hebrew_db.py``) show the
database reports the same problems; these tests pin the reference itself and
use the results of ``Formal/Gematria.lean`` as oracles.
"""

from __future__ import annotations

import itertools
import random

import pytest

from qbx.hebrew.functor import (
    functor_problems,
    functor_value,
    letter_values,
    obligation_problems,
    rules_problems,
)
from qbx.hebrew.gematria import GEMATRIA, gematria_value, gematria_vector
from qbx.hebrew.text import (
    LETTER_TABLE,
    expected_embedding,
    letter_table_problems,
    root_problems,
    text_problems,
    word_row_problems,
)
from qbx.hebrew.torah import (
    language_adjunction_problems,
    parse_verse_ref,
    passage_label,
    passage_sections,
    section_problems,
    site_problems,
    verse_ref_problems,
)
from tests.hebrew_examples import random_obligation, random_rules, random_text

LETTERS = [l for l, *_ in LETTER_TABLE]


# ---------------------------------------------------------------------------
# The seeded table (Formal/Gematria.lean: standard, standard_strictMono,
# standard_injective, final_ne_base)
# ---------------------------------------------------------------------------
LEAN_STANDARD = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 200, 300,
                 400, 500, 600, 700, 800, 900]


def test_letter_table_is_the_lean_table():
    assert [v for _, v, _, _ in LETTER_TABLE] == LEAN_STANDARD
    assert [o for _, _, o, _ in LETTER_TABLE] == list(range(1, 28))
    assert [f for *_, f in LETTER_TABLE] == [False] * 22 + [True] * 5


def test_final_forms_are_distinct_letters():
    """R7 and ``final_ne_base``: ך ם ן ף ץ differ from כ מ נ פ צ."""
    for final, base in zip("ךםןףץ", "כמנפצ"):
        assert GEMATRIA[final] != GEMATRIA[base]
    assert len(set(GEMATRIA.values())) == 27   # standard_injective


def test_shalom():
    assert gematria_value("שלום") == 936


def test_letter_table_problems():
    rows = [(l, v, o, f) for l, v, o, f in LETTER_TABLE]
    assert letter_table_problems(rows) == []
    rows[0] = ("א", 7, 1, None)
    del rows[5]
    rows.append(("X", -5, 99, False))
    assert letter_table_problems(rows) == [
        ("letter_value", {"letter": "א", "field": "gematria_value", "expected": 1, "found": 7}),
        ("letter_value", {"letter": "א", "field": "is_final", "expected": False, "found": None}),
        ("letter_missing", {"letter": "ו"}),
        ("letter_unknown", {"letter": "X"}),
    ]


# ---------------------------------------------------------------------------
# Words, roots, verse texts
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("text,expected", [
    ("שלום", []),
    ("בְּרֵאשִׁית", []),
    ("", [("word_typing", {"error": "empty"})]),
    ("\uFB2A", [("word_typing", {"error": "non_nfc"})]),
    ("ב\u05BC\u05B7", [("word_typing", {"error": "non_nfc"})]),
    ("\u05B8ש", [("word_typing", {"error": "leading_mark", "offset": 0})]),
    ("ab", [("word_typing", {"error": "character", "offset": 0, "codepoint": "U+0061"}),
            ("word_typing", {"error": "character", "offset": 1, "codepoint": "U+0062"}),
            ("word_typing", {"error": "no_letter"})]),
    ("א ב", [("word_typing", {"error": "character", "offset": 1, "codepoint": "U+0020"})]),
    ("\U0001F600א", [("word_typing", {"error": "character", "offset": 0,
                                      "codepoint": "U+1F600"})]),
])
def test_word_problems(text, expected):
    assert text_problems(text, "word") == expected


def test_verse_text_problems():
    assert text_problems("בְּרֵאשִׁית בָּרָא אֱלֹהִים׃", "verse") == []
    assert text_problems("עַל־פְּנֵי", "verse") == []
    assert text_problems("א \u05B8", "verse") == [
        ("section_text_typing", {"error": "leading_mark", "offset": 2})]
    assert text_problems(None, "verse") == [("section_text_typing", {"error": "empty"})]
    assert text_problems("׃", "verse") == [("section_text_typing", {"error": "no_letter"})]


def test_root_problems():
    assert root_problems(None) == []
    assert root_problems("שלם") == []
    assert root_problems("") == [("root_typing", {"error": "empty"})]
    assert root_problems("!!") == [
        ("root_typing", {"error": "character", "offset": 0, "codepoint": "U+0021"}),
        ("root_typing", {"error": "character", "offset": 1, "codepoint": "U+0021"})]


def test_word_row_problems_and_embedding():
    emb = expected_embedding("שלום")
    assert emb == gematria_vector("שלום")            # rule R4
    assert word_row_problems("שלום", None, 936, emb) == []
    bad = list(emb)
    bad[17] = 0.25 if bad[17] != 0.25 else 0.5
    assert word_row_problems("שלום", None, 1, bad) == [
        ("gematria_mismatch", {"recorded": 1, "computed": 936}),
        ("embedding_mismatch", {"index": 17}),
    ]


def test_marks_carry_no_value():
    assert gematria_value("בְּרֵאשִׁית") == gematria_value("בראשית") == 913


# ---------------------------------------------------------------------------
# Gematria functors (wordValue_append, additive_eq_wordValue,
# obligation_value_mismatch_of_square, wordValue_not_injective)
# ---------------------------------------------------------------------------
def test_rules_problems():
    assert rules_problems({}) == []
    assert rules_problems(dict(GEMATRIA)) == []
    assert rules_problems([]) == [("functor_rules", {"error": "not_object"})]
    r = dict(GEMATRIA)
    r["א"] = -3
    r["zz"] = "x"
    del r["ץ"]
    assert rules_problems(r) == [
        ("functor_rules", {"error": "unknown_letter", "key": "zz"}),
        ("functor_rules", {"error": "value", "key": "א"}),
        ("functor_rules", {"error": "missing", "letter": "ץ"}),
    ]
    r = dict(GEMATRIA)
    r["ב"] = 2.0
    r["ג"] = True
    assert rules_problems(r) == [("functor_rules", {"error": "value", "key": "ג"})]


def test_empty_rules_are_the_seeded_table():
    assert letter_values({}) == GEMATRIA
    assert functor_value({}, "שלום") == 936


def test_naturality_square_commutes_for_every_valid_scheme():
    """``wordValue_append``: gem(u ++ w) = gem(u) + gem(w)."""
    rng = random.Random(3)
    checked = 0
    for _ in range(300):
        rules = random_rules(rng)
        if letter_values(rules) is None:
            continue
        u, w = random_text(rng), random_text(rng)
        assert functor_value(rules, u + w) == functor_value(rules, u) + functor_value(rules, w)
        checked += 1
    assert checked > 100


def test_scheme_is_determined_by_letters():
    """``additive_eq_wordValue``: the value of a word is the sum over its letters."""
    rng = random.Random(4)
    rules = {l: rng.randint(0, 50) for l in LETTERS}
    for n in range(4):
        for word in itertools.product("אבךץ", repeat=n):
            word = "".join(word)
            assert functor_value(rules, word) == sum(rules[c] for c in word)


def test_gematria_does_not_identify_words():
    """``wordValue_not_injective``: אב and ג are both 3."""
    assert gematria_value("אב") == gematria_value("ג") == 3


def test_obligation_problems():
    assert obligation_problems({}, "של", "ום", 330, 606, 936) == []
    assert obligation_problems({}, "של", "ום", 330, 606, 937) == [
        ("naturality_value", {"which": "concat", "recorded": 937, "computed": 936}),
        ("naturality_square", {"left": 330, "right": 606, "concat": 937}),
    ]
    assert obligation_problems([], "a", "ום", 1, 2, 3) == [
        ("obligation_typing", {"error": "left"}),
        ("obligation_typing", {"error": "rules"}),
    ]


def test_square_failure_implies_value_failure():
    """``obligation_value_mismatch_of_square``."""
    rng = random.Random(5)
    seen = 0
    for _ in range(600):
        rules = random_rules(rng)
        left, right, lv, rv, cv = random_obligation(rng, rules)
        reasons = [r for r, _ in obligation_problems(rules, left, right, lv, rv, cv)]
        if "naturality_square" in reasons and letter_values(rules) is not None:
            assert "naturality_value" in reasons
            seen += 1
    assert seen > 20


def test_functor_problems():
    assert functor_problems("b", "t", {}) == []
    assert functor_problems("b", "t", {}, obligations=0) == [("naturality_missing", {})]
    assert functor_problems(None, None, {}) == [
        ("functor_typing", {"error": "base_category"}),
        ("functor_typing", {"error": "target_category"})]
    assert functor_problems("c", "c", {}) == [("functor_typing", {"error": "same_category"})]


# ---------------------------------------------------------------------------
# Torah sites (textSheaf_*) and language adjunctions
# ---------------------------------------------------------------------------
@pytest.mark.parametrize("ref,expected", [
    ("Genesis 1:1", []),
    ("בראשית 50:26", []),
    ("Deuteronomy 34:12", []),
    ("Genesis 51:1", [("verse_ref_format", {"error": "chapter"})]),
    ("Leviticus 28:1", [("verse_ref_format", {"error": "chapter"})]),
    ("Isaiah 9:6", [("verse_ref_format", {"error": "book"})]),
    ("nonsense 999", [("verse_ref_format", {"error": "syntax"})]),
    ("Genesis 1:0", [("verse_ref_format", {"error": "syntax"})]),
    ("Genesis 1:1\n", [("verse_ref_format", {"error": "syntax"})]),
])
def test_verse_refs(ref, expected):
    assert verse_ref_problems(ref) == expected
    assert (parse_verse_ref(ref) is not None) == (expected == [])


def test_section_problems():
    assert section_problems("Genesis 1:1", "בְּרֵאשִׁית", ["Genesis 1:1"]) == []
    assert section_problems("Genesis 1:1", "abc", None) == [
        ("section_text_typing", {"error": "character", "offset": i,
                                 "codepoint": "U+%04X" % ord(c)}) for i, c in enumerate("abc")
    ] + [("section_text_typing", {"error": "no_letter"})]
    assert section_problems("Genesis 1:2", "א", ["Genesis 1:1"]) == [("verse_not_point", {})]


def test_passage_presheaf_shape():
    """``textSheaf_subsingleton`` / ``textSheaf_nonempty_iff``: at most one
    section, present exactly when every verse of the open has a text."""
    opens = {"E": [], "A": ["Genesis 1:1"], "B": ["Genesis 1:2"],
             "AB": ["Genesis 1:1", "Genesis 1:2"]}
    texts = {"Genesis 1:1": "בְּרֵאשִׁית"}
    secs = passage_sections(opens, texts)
    assert secs == {"E": ["{}"], "A": ['{"Genesis 1:1":"בְּרֵאשִׁית"}'], "B": [], "AB": []}
    for name, pts in opens.items():
        assert len(secs[name]) <= 1
        assert (len(secs[name]) == 1) == all(p in texts for p in pts)
    assert passage_label({"b": "x", "a": "y"}) == '{"a":"y","b":"x"}'


def test_site_problems():
    assert site_problems(None, None, None) == [("torah_no_site", {})]
    assert site_problems(None, None, None, batch=True) == [("torah_no_site", {}),
                                                           ("torah_no_presheaf", {})]
    assert site_problems("s", "p", "other") == [("torah_presheaf_typing", {"presheaf": "p"})]
    assert site_problems("s", "p", "s") == []
    label = passage_label({"Genesis 1:1": "א"})
    assert site_problems("s", "p", "s", True, True, [("Genesis 1:1", "א", [label])]) == []
    assert site_problems("s", "p", "s", True, False,
                         [("Genesis 1:1", "א", [label, "x"])]) == [
        ("torah_not_sheaf", {"presheaf": "p"}),
        ("torah_section_mismatch", {"verse": "Genesis 1:1"})]


def test_language_adjunction_problems():
    assert language_adjunction_problems("Hebrew", "Greek", "F", ("F", "G"), "provisional",
                                        None, False) == []
    assert language_adjunction_problems("Hebrew", "Hebrew", "H", ("F", "G"), "lean_verified",
                                        None, False) == [
        ("language_typing", {"error": "same"}),
        ("adjunction_mismatch", {}),
        ("unverified_claim", {"error": "no_artifact"})]
    assert language_adjunction_problems(" ", "", "F", None, "verified", None, False) == [
        ("language_typing", {"error": "left"}),
        ("language_typing", {"error": "right"}),
        ("status_value", {"status": "verified"})]
    assert language_adjunction_problems("Hebrew", "Greek", "F", None, "lean_verified",
                                        "coq", True) == [
        ("unverified_claim", {"error": "artifact_type", "found": "coq"})]
    assert language_adjunction_problems("Hebrew", "Greek", "F", None, "lean_verified",
                                        "lean4", True) == []
