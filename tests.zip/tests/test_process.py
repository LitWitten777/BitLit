"""Conformance of ``qbx.process`` with the formal pipeline (decision RUN-001).

The Lean file ``Formal/BibleBraidGenesis1.lean`` holds, for the 31 verses of Genesis 1, the braid
words of the encoding on 8 strands (sofit rule on and off) and on 23 strands, and proves
(``genesis_1_model_agrees_with_python``) that the Lean model of the encoding produces exactly these
words.  Here ``qbx.process`` must produce the same 93 words, and on every verse its numerical
re-checks of the Lean identities (rewriting preserves the braid; the forward-backward pass is pure
with the single pass's crossing matrix as linking matrix) must pass.
"""

from __future__ import annotations

import re
from pathlib import Path

import pytest

import qbx
from qbx.process import bipass_word, process

LEAN = Path(__file__).resolve().parents[1] / "Formal" / "BibleBraidGenesis1.lean"
_REC = re.compile(r'⟨"(Genesis 1:\d+)", "([^"]+)",\s*\[([^\]]*)\],\s*\[([^\]]*)\],\s*\[([^\]]*)\]⟩', re.S)


def _ints(s):
    return [int(x) for x in s.replace("\n", " ").split(",") if x.strip()]


VERSES = [(m.group(1), m.group(2), _ints(m.group(3)), _ints(m.group(4)), _ints(m.group(5)))
          for m in _REC.finditer(LEAN.read_text(encoding="utf-8"))]


def test_table_parsed():
    assert len(VERSES) == 31


@pytest.mark.parametrize("ref,text,w8,w8n,w23", VERSES, ids=[v[0] for v in VERSES])
def test_process_matches_lean_table(ref, text, w8, w8n, w23):
    assert process(text, strands=8, certificate=False).short_form == w8
    assert process(text, strands=8, sofit_rule=False, certificate=False).short_form == w8n
    assert process(text, strands=23, certificate=False).short_form == w23


@pytest.mark.parametrize("ref,text,w8,w8n,w23", VERSES[:10], ids=[v[0] for v in VERSES[:10]])
def test_process_checks_pass(ref, text, w8, w8n, w23):
    r = process(text, strands=8, bidirectional=True)
    assert all(r.checks.values()), r.checks
    assert r.pure and len(r.components) == 8
    assert r.short_form == bipass_word(w8)


def test_event_stream_and_verdicts():
    r = qbx.process([1, 1], strands=2)          # Hopf link sigma_1^2
    assert r.verdict == "link (2 components, pure)"
    assert r.linking_matrix == [[0, 1], [1, 0]]
    r = qbx.process([1, 1, 1], strands=2)       # trefoil
    assert r.verdict == "knot (1 component)"
    r = qbx.process([1], strands=2, bidirectional=True)   # sigma_1 -> Hopf link
    assert r.linking_matrix == [[0, 1], [1, 0]] and all(r.checks.values())


def test_bipass_trivial_iff_mirror_symmetric():
    # Lean: bipass_eq_one_iff.  The empty word is its own mirror; sigma_1 sigma_1^{-1} is
    # trivial; a single positive crossing is not.
    assert process([1, -1], strands=2, bidirectional=True).reduced_short_form == []
    assert process([1], strands=2, bidirectional=True).reduced_short_form != []


def test_layouts_and_schemes():
    a = process("אב גד", strands=8, certificate=False)
    b = process(["אב", "דג"], strands=8, layout="boustrophedon", certificate=False)
    assert a.short_form == b.short_form
    std = process("שלום", gematria="standard", certificate=False).gematria["total"]
    base = process("שלום", gematria="base", certificate=False).gematria["total"]
    assert (std, base) == (936, 376)   # ש300 ל30 ו6 + ם600 (standard) or מ40 (base)
    with pytest.raises(ValueError):
        process("א", gematria="nope")
