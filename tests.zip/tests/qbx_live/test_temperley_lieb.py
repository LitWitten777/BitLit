from fractions import Fraction

import pytest

from qbx_live.temperley_lieb import (
    check_kauffman,
    check_wenzl,
    jones_wenzl,
    q_int,
)


@pytest.mark.parametrize("n", [2, 3, 4])
def test_wenzl_spin_chain(n):
    r = check_wenzl(Fraction(2), n)
    assert r["tl_relations"]
    assert r["idempotent"]
    assert r["killed"]
    assert r["trace"] == n + 1  # spin n/2 has dimension n + 1
    assert r["quantum_trace"] == r["expected_quantum_trace"]


def test_three_spins_matches_lean():
    # Lean: spinTL_trace_jw3 (trace 4) and spinTL_qtrace_jw3 ([4] = δ³ - 2δ)
    q = Fraction(2)
    d = q + 1 / q
    r = check_wenzl(q, 3)
    assert r["trace"] == 4
    assert r["quantum_trace"] == d ** 3 - 2 * d


def test_quantum_integers():
    d = Fraction(5, 2)
    assert q_int(d, 2) == d
    assert q_int(d, 3) == d * d - 1


def test_root_of_unity_truncation():
    # δ = 1 (q a primitive 6th root of unity) has [3] = 0: p_3 does not exist
    assert q_int(Fraction(1), 3) == 0


@pytest.mark.parametrize("n", [3, 4])
def test_kauffman(n):
    r = check_kauffman(Fraction(2), n)
    assert r["braid"]
    assert r["absorb"]


def test_p2_formula():
    q = Fraction(3)
    p = jones_wenzl(q, 2)
    d = q + 1 / q
    assert p[1][1] == 1 - q / d
