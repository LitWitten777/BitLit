"""Three-fold-way routing: same verdict as the five-channel machine; folded sweep equals
the full sweep (Lean: ThreeFoldWay.two_pi_sub_mem_resonanceSet)."""

import random

import pytest

from qbx_ir import Braid
from qbx_ir.algebra import multiprover as mp
from qbx_live import routing


def _rand(rng, n, length):
    return Braid.from_short_form(n, [rng.choice([1, -1]) * rng.randint(1, n - 1)
                                     for _ in range(length)])


@pytest.mark.parametrize("n", [2, 3, 4])
def test_folded_sweep_matches_full(n):
    rng = random.Random(100 + n)
    for _ in range(25):
        b = _rand(rng, n, rng.randint(0, 14))
        assert routing.harmonic_reading_folded(b) == mp.harmonic_reading(b)


def test_full_sweep_is_symmetric():
    rng = random.Random(3)
    for _ in range(20):
        pat = mp.harmonic_reading(_rand(rng, 3, 10))
        N = len(pat)
        assert all(pat[k] == pat[N - k] for k in range(1, N))


def test_burau_at_minus_one_is_integral_and_sound():
    b1 = Braid.from_short_form(3, [1, 2, 1])
    b2 = Braid.from_short_form(3, [2, 1, 2])
    m = routing.burau_at_minus_one(b1)
    assert all(isinstance(x, int) for row in m for x in row)
    assert m == routing.burau_at_minus_one(b2)


@pytest.mark.parametrize("n", [3, 4])
def test_route_agrees_with_verdict(n):
    rng = random.Random(n)
    pairs = []
    for _ in range(25):
        b = _rand(rng, n, rng.randint(0, 8))
        pairs.append((b, _rand(rng, n, rng.randint(0, 8))))
        # a true identity: insert a cancelling pair
        w = list(b.short_form())
        i = rng.randint(1, n - 1)
        k = rng.randint(0, len(w))
        pairs.append((b, Braid.from_short_form(n, w[:k] + [i, -i] + w[k:])))
    pairs.append((Braid.from_short_form(n, [1, 2, 1]), Braid.from_short_form(n, [2, 1, 2])))
    for b1, b2 in pairs:
        r = routing.route(b1, b2)
        assert r.verdict == mp.verdict(b1, b2).verdict
        if r.verdict == "PROVED":
            assert r.decided_by_fold and r.refuted_by is None


def test_hidden_harmonic_refuted_by_real_point():
    """σ₁²σ₂⁻² vs the identity: permutation and writhe agree; the exact Burau matrix at
    t = −1 refutes (Machine.hidden_harmonic_refutes is the θ = π statement)."""
    r = routing.route(Braid.from_short_form(3, [1, 1, -2, -2]), Braid.identity(3))
    assert r.verdict == "REFUTED"
    assert r.refuted_by.name == "burau_at_-1"
    assert r.steps_run == ("permutation", "writhe", "burau_at_-1")


def test_channel_types_cover_all_channels():
    assert set(routing.CHANNEL_TYPES) == set(mp.CHANNELS)
