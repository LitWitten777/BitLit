"""Node step 8: Genesis 1 end to end over the simulated network."""

import os
import re

import pytest

from qbx_bible import Encoding
from qbx_live import network_run as nr
from qbx_live.dht import AddressSpace

LEAN_TABLE = os.path.join(os.path.dirname(__file__), "..", "..", "Formal", "BibleBraidGenesis1.lean")


@pytest.fixture(scope="module")
def text():
    return nr.genesis_text()


def test_network_matches_single_node(text):
    report = nr.run(text, AddressSpace(2, (3, 4)), n_workers=8)
    assert report["matches_single_node"]
    assert report["network_digest"] == report["single_node_digest"]
    assert report["verifiers"] == 48
    assert report["ledger_flat"] and report["ledger_unanimous"]
    assert report["consensus_state_is_coordinator"]
    assert report["max_hops"] <= report["diameter"]


def lean_words(field: int):
    """The braid words of the 31 verses as checked in BibleBraidGenesis1.lean
    (field 0: 8 strands with sofit, 1: 8 strands without, 2: 23 strands with)."""
    src = open(LEAN_TABLE, encoding="utf-8").read()
    recs = re.findall(r"def gen1_\d+ : VerseRecord :=\s*⟨\"[^\"]*\", \"[^\"]*\",\s*"
                      r"\[([^\]]*)\],\s*\[([^\]]*)\],\s*\[([^\]]*)\]⟩", src)
    assert len(recs) == 31
    return [int(x) for r in recs for x in r[field].split(",") if x.strip()]


@pytest.mark.parametrize("field,enc", [(0, Encoding(8, True)), (1, Encoding(8, False)),
                                       (2, Encoding(23, True))])
def test_network_word_matches_lean_table(text, field, enc):
    """The braid word the network computes for Genesis 1 is the concatenation of the
    per-verse words checked in Lean (genesis_1_model_agrees_with_python)."""
    from qbx_live.dht import Network
    from qbx_live.distributed import distributed_summary
    sp = AddressSpace(2, (3, 4))
    s = distributed_summary(text, list(sp.addresses())[::5], enc, network=Network(sp))
    assert list(s.short) == lean_words(field)
