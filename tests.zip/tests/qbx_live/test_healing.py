"""Tests for qbx_live.healing — numerical mirrors of QBX/Formal/Sovereign."""

import math
import random

import numpy as np
import pytest

from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.core.braid import Braid
from qbx_live import healing as H

B = Braid.from_short_form


def rand_word(n, k, rng):
    return [rng.choice([1, -1]) * rng.randint(1, n - 1) for _ in range(k)]


# ---------------------------------------------------------------- energy


def test_energy_trivial_braids_zero():
    assert H.arc_energy(B(3, [])) == 0.0
    assert H.arc_energy(B(3, [1, 2, 1, -2, -1, -2])) < 1e-12
    assert H.arc_energy(B(5, [1, 3, -1, -3])) < 1e-12


def test_energy_detects_nontrivial_three_strand():
    """specEnergy_arc_iff_trivial_three: positive energy on the arc for every
    nontrivial 3-braid (sampled)."""
    rng = random.Random(1)
    for _ in range(60):
        b = B(3, rand_word(3, rng.randint(1, 8), rng))
        trivial = braid_group_equal(b, B(3, []))
        assert (H.arc_energy(b) < 1e-9) == trivial


def test_single_angle_not_enough():
    """specEnergy_sigmaOneSq_zero / sigmaOneSq_ne_one."""
    b = B(3, [1, 1])
    assert H.spectral_energy(b, 0.0) < 1e-12
    assert H.arc_energy(b) > 0.1
    assert not braid_group_equal(b, B(3, []))


def test_eigenvalues_unimodular_on_arc():
    rng = random.Random(2)
    for n in (3, 4, 5, 6):
        for _ in range(10):
            b = B(n, rand_word(n, 6, rng))
            for th in H.arc_angles(n, 9):
                lam = H.burau_eigenvalues(b, th)
                assert np.allclose(np.abs(lam), 1, atol=1e-7)


def test_burau_trivial_exact():
    assert H.is_burau_trivial(B(4, [1, -1, 3, 2, -2, -3]))
    assert not H.is_burau_trivial(B(4, [1, 1]))


# ---------------------------------------------------------------- flows


def test_phase_flow_bound_and_monotone():
    rng = np.random.default_rng(0)
    phi0 = rng.uniform(-math.pi, math.pi, 5)
    for kappa in (0.1, 0.5, 1.0):
        flow = H.phase_flow(phi0, kappa, 30)
        e = H.phase_energy(flow)
        bound = ((1 - kappa) ** 2) ** np.arange(31) * np.sum(phi0 ** 2)
        assert np.all(e <= bound + 1e-12)
        assert np.all(np.diff(e) <= 1e-12)


def test_heat_step_sum_and_max_principle():
    rng = np.random.default_rng(1)
    x = rng.normal(size=11)
    for alpha in (0.0, 0.2, 0.5):
        y = H.heat_step(x, alpha)
        assert abs(y.sum() - x.sum()) < 1e-12
        assert y.max() <= x.max() + 1e-12 and y.min() >= x.min() - 1e-12


# ---------------------------------------------------------------- Fano / Hamming

LEAN_ORIENTED_LINES = [
    (1, 2, 3), (1, 4, 5), (1, 7, 6), (2, 3, 1), (2, 4, 6), (2, 5, 7), (3, 1, 2),
    (3, 4, 7), (3, 6, 5), (4, 5, 1), (4, 6, 2), (4, 7, 3), (5, 1, 4), (5, 3, 6),
    (5, 7, 2), (6, 1, 7), (6, 2, 4), (6, 5, 3), (7, 2, 5), (7, 3, 4), (7, 6, 1),
]


def test_octonion_orientation_matches_lean():
    ours = [(i, j, i ^ j) for i in range(1, 8) for j in range(1, 8)
            if i != j and H.octonion_product(i, j)[0] == 1]
    assert ours == LEAN_ORIENTED_LINES
    for i in range(1, 8):
        for j in range(1, 8):
            if i != j:
                assert H.octonion_product(j, i)[0] == -H.octonion_product(i, j)[0]


def test_fano_completion_and_closure():
    for i in range(1, 8):
        for j in range(1, 8):
            if i != j:
                k = H.fano_third(i, j)
                assert k not in (i, j) and H.is_collinear(i, j, k)
    sizes = set()
    for mask in range(128):
        S = [p for p in range(1, 8) if mask >> (p - 1) & 1]
        c = H.fano_close(S)
        sizes.add(len(c))
        full = any(a != b and c_ not in (a, b) and not H.is_collinear(a, b, c_)
                   for a in S for b in S for c_ in S)
        assert (len(c) == 7) == full
    assert sizes == {0, 1, 3, 7}


def test_hamming_code():
    words = H.hamming_codewords()
    assert len(words) == 16
    assert min(sum(w) for w in words if any(w)) == 3
    weight3 = sorted(tuple(j + 1 for j in range(7) if w[j]) for w in words if sum(w) == 3)
    assert weight3 == sorted(H.FANO_LINES)
    for w in words:
        for j in range(7):
            e = list(w)
            e[j] ^= 1
            assert H.hamming_syndrome(e) == j + 1
            assert tuple(H.hamming_decode(e)) == w


def test_uv_span():
    assert H.uv_span(B(8, [1, 2])) == (1, 2, 3)
    assert H.uv_completion(B(8, [1, 2])) == [3]
    assert H.uv_complete(B(8, [1, 2, -4]))


# ---------------------------------------------------------------- gap filling


def test_single_gap_unique_and_healed():
    rng = random.Random(3)
    for n in (3, 4):
        for _ in range(12):
            w = rand_word(n, 5, rng)
            pos = rng.randrange(len(w))
            partial = list(w)
            partial[pos] = H.GAP
            r = H.fill_gaps(partial, B(n, w))
            assert r.status == "healed", r.notes
            assert r.word == w
            assert len(r.candidates) == 1
            assert all(a.passed for a in r.anchors if a.kind == "exact")


def test_fano_candidate_on_balanced_words():
    rng = random.Random(4)
    for _ in range(10):
        w = H.balance(rand_word(8, 4, rng))
        if H.fano_checksum(w) != 0:
            continue
        pos = rng.randrange(len(w))
        partial = list(w)
        partial[pos] = H.GAP
        assert H.fano_gap_candidate(partial, sum(1 if g > 0 else -1 for g in w)) == w[pos]
        r = H.fill_gaps(partial, B(8, w), use_fano=True)
        assert r.status == "healed" and r.fano_choice == w


def test_conflict_detects_unbalanced():
    w = [1, 2, 4]  # checksum 7: not balanced
    partial = [1, H.GAP, 4]
    r = H.fill_gaps(partial, B(8, w), use_fano=True)
    assert r.status == "inconsistent"
    assert r.word == w and r.fano_choice != w


def test_two_gaps_can_be_ambiguous():
    # σ1 ? ? σ1 = σ1 σ1 : many fillings (x x⁻¹ pairs)
    r = H.fill_gaps([1, H.GAP, H.GAP, 1], B(3, [1, 1]))
    assert r.status == "ambiguous" and len(r.candidates) >= 2


def test_checksum_not_invariant():
    a, b = B(8, [1, 2, 1]), B(8, [2, 1, 2])
    assert braid_group_equal(a, b)
    assert H.fano_checksum([1, 2, 1]) == 2 and H.fano_checksum([2, 1, 2]) == 1


# ---------------------------------------------------------------- geometry


def test_point_cloud_and_backends():
    comps = H.strand_point_cloud(B(3, [1, 2, 1, 2]), samples=8)
    assert len(comps) == 1 and comps[0].shape[1] == 3
    g = H.geometry_backend()
    k = g.curvature(comps[0])
    assert k.shape == (len(comps[0]),) and np.all(k >= 0)
    sm = g.heat_smooth(comps[0], k)
    assert sm.shape == k.shape
    gnp = H.geometry_backend(lambda pts: np.ones(len(pts)))
    assert gnp.name == "gnp" and np.all(gnp.curvature(comps[0]) == 1)


def test_curve_shortening_reduces_length():
    t = np.linspace(0, 2 * np.pi, 100, endpoint=False)
    c = np.stack([np.cos(t) + 0.3 * np.cos(5 * t), np.sin(t), 0 * t], 1)
    flow = H.curve_shortening(c, 30, 0.2)
    length = lambda x: np.sum(np.linalg.norm(np.roll(x, -1, 0) - x, axis=1))
    assert length(flow[-1]) < length(flow[0])
