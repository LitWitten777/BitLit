"""Single-node evaluator: verdicts on known cases, the CLI, and the Lean names reported."""

import json

from qbx_ir import Braid
from qbx_live import evaluate as ev


def test_braid_relation_proved():
    out = ev.evaluate(Braid.from_short_form(3, [1, 2, 1]), Braid.from_short_form(3, [2, 1, 2]))
    assert out["verdict"] == "PROVED"
    assert out["disagree"] == []
    assert out["summaries"][0] == out["summaries"][1]
    assert out["routed"]["decided_by_fold"]
    assert ev.Braid.from_short_form(3, out["defect"]).short_form() == out["defect"]


def test_trefoil_vs_identity_refuted():
    out = ev.evaluate(Braid.from_short_form(2, [1, 1, 1]), Braid.identity(2))
    assert out["verdict"] == "REFUTED"
    assert "fold" in out["disagree"]
    assert out["summaries"][0] != out["summaries"][1]


def test_text_reordering(capsys):
    assert ev.main(["--text", "בראשית ברא", "--text", "ברא בראשית"]) == 0
    out = json.loads(capsys.readouterr().out)
    assert out["verdict"] in ("PROVED", "REFUTED")
    assert out["routed"]["verdict"] == out["verdict"]
    assert out["lean"]["verdict"].endswith("verdict_eq_proved_iff")


def test_cli_words(capsys):
    assert ev.main(["--strands", "3", "--word", "1 2 1", "--word", "2 1 2"]) == 0
    assert json.loads(capsys.readouterr().out)["verdict"] == "PROVED"
