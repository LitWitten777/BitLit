"""Node step 6: distributed scheduling (Lean: NodeNetwork.distributed_correct)."""

import pytest

from qbx_bible import Encoding, load_corpus
from qbx_bible import manifold as mf
from qbx_live import distributed as ds
from qbx_live.dht import AddressSpace, Network


@pytest.fixture(scope="module")
def text():
    return " ".join(v.text for v in load_corpus())


@pytest.mark.parametrize("N,m", [(1, 0), (1, 5), (3, 10), (7, 3), (8, 537), (48, 537)])
def test_balanced_sizes(N, m):
    """sum_balancedSizes, balancedSizes_bounds."""
    sizes = ds.balanced_sizes(N, m)
    assert len(sizes) == N and sum(sizes) == m
    assert all(m // N <= s <= m // N + 1 for s in sizes)


def test_blocks_flatten():
    """flatten_blocks."""
    items = list(range(11))
    for sizes in ([], [3], [3, 0, 4], [20], [2, 2, 2, 2, 2]):
        assert [x for b in ds.blocks(sizes, items) for x in b] == items


@pytest.mark.parametrize("N", [1, 2, 3, 5, 8, 13])
@pytest.mark.parametrize("enc", [Encoding(8, True), Encoding(23, False)])
def test_distributed_equals_single_node(text, N, enc):
    """distributed_correct: N workers give the single-node summary."""
    assert ds.distributed_summary(text, [None] * N, enc) == mf.summarize(text, enc)


def test_distributed_through_network(text):
    sp = AddressSpace(2, (3, 4))
    net = Network(sp)
    nodes = list(sp.addresses())[::6]
    assert ds.distributed_summary(text, nodes, network=net) == mf.summarize(text)


def test_round_robin_is_wrong(text):
    """roundRobin_wrong: per-node products of round-robin chunks are not the summary."""
    direct = mf.summarize(text)
    for N in (2, 3, 8):
        rr = ds.round_robin_summary(text, N)
        assert rr != direct
        assert rr.writhe == direct.writhe          # the commutative part survives
        assert rr.positions != direct.positions or rr.burau != direct.burau


def test_coordinator_rejects_bad_gathers(text):
    res = ds.worker_results(text, [None] * 4)
    with pytest.raises(ds.ScheduleError):
        ds.combine(res[:3], 4)
    with pytest.raises(ds.ScheduleError):
        ds.combine(res + [res[0]], 4)
    with pytest.raises(ds.ScheduleError):
        ds.combine(res + [(9, res[0][1])], 4)
    assert ds.combine(list(reversed(res)), 4) == mf.summarize(text)
