"""The window cache composes with map–reduce: cached summaries recombine to exactly the
summary of one sequential pass (Lean: TextManifold.mapReduce)."""

import random

import pytest

from qbx_bible import Encoding, load_corpus
from qbx_bible import manifold as mf
from qbx_live import window_cache as wc


@pytest.fixture(scope="module")
def text():
    return " ".join(v.text for v in load_corpus())


@pytest.mark.parametrize("k", [1, 3, 4, 7])
@pytest.mark.parametrize("enc", [Encoding(8, True), Encoding(23, False)])
def test_cached_equals_direct(text, k, enc):
    cache = wc.WindowCache()
    for keep in (True, False):
        assert wc.summarize_cached(text, cache, encoding=enc, k=k, keep_word=keep) == \
            mf.summarize(text, enc, keep)


def test_second_pass_is_all_hits(text):
    cache = wc.WindowCache()
    first = wc.summarize_cached(text, cache)
    misses = cache.stats.misses
    assert misses == len(cache) == cache.stats.writes
    second = wc.summarize_cached(text, cache)
    assert first == second
    assert cache.stats.misses == misses
    assert cache.stats.hits + cache.stats.misses == 2 * len(wc.windows_of(text))


def test_normalization_is_exact(text):
    """Marks stripped and non-letters mapped to one space: same summary."""
    for enc in (Encoding(8, True), Encoding(12, False)):
        assert mf.summarize(wc.normalize(text), enc) == mf.summarize(text, enc)


def test_window_bound(text):
    """Distinct normalised windows over a letters (+ separator) number at most (a+1)^k."""
    for k in (1, 2, 4):
        distinct = set(wc.windows_of(text, k))
        assert len(distinct) <= 28 ** k


def test_random_texts_shared_cache():
    rng = random.Random(5)
    letters = "אבגדהוזחטיכלמנסעפצקרשתךםןףץ ."
    cache = wc.WindowCache()
    for _ in range(20):
        t = "".join(rng.choice(letters) for _ in range(rng.randint(0, 60)))
        assert wc.summarize_cached(t, cache, k=3) == mf.summarize(t)


def test_keys_separate_parameters():
    w = "ברא "
    keys = {wc.window_key(w, "hebrew-wlc"), wc.window_key(w, "hebrew-wlc", Encoding(9)),
            wc.window_key(w, "hebrew-wlc", Encoding(8, False)),
            wc.window_key(w, "hebrew-wlc", keep_word=False),
            wc.window_key(w, "hebrew-other"), wc.window_key(w, "hebrew-wlc", version=2)}
    assert len(keys) == 6
    # length prefixes: shifting a character between fields changes the key
    assert wc.window_key("bc", "a") != wc.window_key("c", "ab")


def test_collision_detected_on_write_and_read():
    cache = wc.WindowCache()
    s = mf.summarize("אב")
    cache.put("k", "אב", s)
    cache.put("k", "אב", s)            # same window: idempotent
    with pytest.raises(wc.CacheCollision):
        cache.put("k", "גד", mf.summarize("גד"))
    with pytest.raises(wc.CacheCollision):
        cache.get("k", "גד")
    assert cache.stats.collisions == 2
    assert cache.get("k", "אב") == s
    trusting = wc.WindowCache(verify_reads=False)
    trusting.put("k", "אב", s)
    assert trusting.get("k", "גד") == s     # trusts the hash


def test_persistent_cache(tmp_path, text):
    path = str(tmp_path / "windows.sqlite")
    c1 = wc.WindowCache(path)
    expected = wc.summarize_cached(text, c1)
    n = len(c1)
    c1.close()
    c2 = wc.WindowCache(path)
    assert len(c2) == n
    assert wc.summarize_cached(text, c2) == expected
    assert c2.stats.misses == 0
