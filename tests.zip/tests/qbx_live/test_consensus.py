"""Node step 7: consensus as flatness (Lean: NodeNetwork.addrGraph_single_liar_isFlat_iff,
AddressBlindSpots.addrGraph_perturb_detected, GaugeFlatness.perturb_detected_iff_not_isBridge)."""

import random

import pytest

from qbx_live import consensus as cs
from qbx_live.dht import AddressSpace

SPACES = [AddressSpace(2, (3, 4)), AddressSpace(3, ()), AddressSpace(0, (5,)), AddressSpace(1, (2,))]


def states(sp, rng):
    return {a: rng.randrange(cs.P) for a in sp.addresses()}


@pytest.mark.parametrize("sp", SPACES)
def test_honest_is_flat(sp):
    """claimConn_isFlat_of_consistent."""
    rng = random.Random(1)
    assert cs.is_flat(sp, cs.transports(cs.honest_claims(sp, states(sp, rng))))


@pytest.mark.parametrize("sp", SPACES)
def test_no_bridges(sp):
    """addrGraph_not_isBridge covers at least two non-trivial coordinates; a single cycle
    of length ≥ 3 (the 5-cycle here) has no bridges either."""
    assert cs.nontrivial_coords(sp) >= 2 or sp.moduli == (5,)
    assert cs.bridges(sp) == set()


def test_q1_has_a_bridge():
    """addrGraph_cube_one_isBridge: the hypothesis cannot be dropped."""
    sp = AddressSpace(1, ())
    assert len(cs.bridges(sp)) == 1


@pytest.mark.parametrize("sp", SPACES)
def test_single_link_fork_detected(sp):
    """addrGraph_perturb_detected: every single-link fork of a flat ledger is detected."""
    rng = random.Random(2)
    t = cs.transports(cs.honest_claims(sp, states(sp, rng)))
    for (a, b) in list(t)[::3]:
        assert not cs.is_flat(sp, cs.perturb(t, a, b, rng.randrange(1, cs.P)))


def test_bridge_fork_undetected():
    """perturb_detected_iff_not_isBridge: on a bridge a fork stays flat."""
    sp = AddressSpace(1, ())
    rng = random.Random(4)
    t = cs.transports(cs.honest_claims(sp, states(sp, rng)))
    (a, b), = [tuple(e) for e in cs.bridges(sp)]
    assert cs.is_flat(sp, cs.perturb(t, a, b, 12345))


@pytest.mark.parametrize("sp", SPACES)
def test_single_liar(sp):
    """addrGraph_single_liar_isFlat_iff: with one deviating node the ledger is flat iff it
    tells all neighbours the same thing."""
    rng = random.Random(5)
    st = states(sp, rng)
    for u in list(sp.addresses())[::5]:
        claims = cs.honest_claims(sp, st)
        # consistent lie: flat (a gauge change), but no longer unanimous with the truth
        x = rng.randrange(cs.P)
        for w in sp.neighbors(u):
            claims[(u, w)] = x
        assert cs.is_flat(sp, cs.transports(claims))
        # equivocation: tell one neighbour something else
        if sp.degree >= 2:
            w0 = sp.neighbors(u)[0]
            claims[(u, w0)] = (x + 1) % cs.P
            assert not cs.is_flat(sp, cs.transports(claims))


def test_consistent_liar_caught_by_unanimity():
    """Flatness does not see a consistent lie; comparing the states does."""
    sp = AddressSpace(2, (3, 4))
    same = {a: 42 for a in sp.addresses()}
    claims = cs.honest_claims(sp, same)
    assert cs.verdict(sp, claims) == {"flat": True, "unanimous": True, "states": 1}
    u = sp.decode(7)
    for w in sp.neighbors(u):
        claims[(u, w)] = 43
    v = cs.verdict(sp, claims)
    assert v["flat"] and not v["unanimous"]
