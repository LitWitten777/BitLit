"""Node step 5: lookup on Q_n □ T^k_M (Lean: QBX/Formal/MultiProver/NodeNetwork.lean)."""

import itertools
import os
import random
import sys

import pytest

from qbx_bible import Encoding, load_corpus
from qbx_bible import manifold as mf
from qbx_live import window_cache as wc
from qbx_live.dht import AddressSpace, Network, key_address

SPACES = [AddressSpace(1, ()), AddressSpace(3, ()), AddressSpace(0, (5,)), AddressSpace(2, (3, 4)),
          AddressSpace(1, (2, 6))]


@pytest.mark.parametrize("sp", SPACES)
def test_decode_encode_bijective(sp):
    seen = {sp.decode(i) for i in range(sp.size)}
    assert len(seen) == sp.size
    assert all(sp.encode(sp.decode(i)) == i for i in range(sp.size))


@pytest.mark.parametrize("sp", SPACES)
def test_every_address_reached_greedily(sp):
    """greedy_arrives / greedyRoute_arrives: every node reaches every address in
    exactly distance(a, b) hops, each hop a single move."""
    addrs = list(sp.addresses())
    for a, b in itertools.product(addrs, addrs):
        path = sp.greedy_route(a, b)
        assert path[0] == a and path[-1] == b
        assert len(path) - 1 == sp.distance(a, b) <= sp.diameter
        assert all(y in sp.neighbors(x) for x, y in zip(path, path[1:]))


@pytest.mark.parametrize("sp", SPACES)
def test_diameter_attained(sp):
    """exists_addrDist_eq_addrDiam."""
    addrs = list(sp.addresses())
    assert max(sp.distance(a, b) for a in addrs for b in addrs) == sp.diameter


@pytest.mark.parametrize("sp", SPACES)
def test_degree_and_replica_set(sp):
    """addrGraph_ncard_neighborSet, ncard_replicaSet."""
    for a in sp.addresses():
        nb = sp.neighbors(a)
        assert len(set(nb)) == len(nb) == sp.degree
        assert len(set(sp.replica_set(a))) == sp.degree + 1


def test_matches_foundation_space():
    """Same neighbour order and metric as foundation/ws1_geometry (if importable)."""
    root = os.path.join(os.path.dirname(__file__), "..", "..", "foundation")
    sys.path.insert(0, os.path.abspath(root))
    try:
        from ws1_geometry.mixed_radix import MixedRadixSpace
        from contracts.types import Address
    except Exception:  # pragma: no cover
        pytest.skip("foundation package not importable")
    finally:
        sys.path.pop(0)
    sp = AddressSpace(2, (3, 4))
    ms = MixedRadixSpace(2, (3, 4))
    for a in sp.addresses():
        fa = Address(*a)
        assert [(x.bits, x.cycles) for _, x in ms.neighbors(fa)] == sp.neighbors(a)
        for b in sp.addresses():
            assert ms.distance(fa, Address(*b)) == sp.distance(a, b)


def test_link_failures_below_degree():
    """lookup_survives_link_failures: with degree − 1 failed links every address stays
    reachable (random trials)."""
    sp = AddressSpace(2, (3, 4))
    addrs = list(sp.addresses())
    links = sorted({frozenset((a, b)) for a in addrs for b in sp.neighbors(a)}, key=sorted)
    rng = random.Random(7)
    for _ in range(20):
        net = Network(sp)
        for link in rng.sample(links, sp.degree - 1):
            a, b = tuple(link)
            net.fail_link(a, b)
        src = rng.choice(addrs)
        for b in addrs:
            p = net.path(src, b)
            assert p is not None and p[0] == src and p[-1] == b
            assert all(net.link_up(x, y) for x, y in zip(p, p[1:]))


def test_degree_link_failures_can_isolate():
    """The bound is sharp (addrGraph_not_isEdgeConnected): cutting all links of a node
    isolates it."""
    sp = AddressSpace(2, (3, 4))
    net = Network(sp)
    a = sp.decode(5)
    for b in sp.neighbors(a):
        net.fail_link(a, b)
    assert net.path(sp.decode(0), a) is None


def test_replica_survives_node_failures():
    """replica_survives: after `degree` node failures a replica of every key is alive;
    replicas_can_all_fail: degree + 1 can remove them."""
    sp = AddressSpace(2, (3, 4))
    rng = random.Random(3)
    addrs = list(sp.addresses())
    for _ in range(50):
        owner = rng.choice(addrs)
        failed = set(rng.sample(addrs, sp.degree))
        assert any(r not in failed for r in sp.replica_set(owner))
    owner = addrs[0]
    assert all(r in set(sp.replica_set(owner)) for r in sp.replica_set(owner))


def test_network_cache_equals_direct():
    """Window summaries fetched through the network recombine to the single-pass summary."""
    text = " ".join(v.text for v in load_corpus())
    sp = AddressSpace(2, (3, 4))
    net = Network(sp)
    addrs = list(sp.addresses())
    for origin in (addrs[0], addrs[17], addrs[-1]):
        assert net.summarize_text(text, origin) == mf.summarize(text)
    assert net.stats.max_hops <= sp.diameter
    assert net.stats.detours == 0


def test_lookup_after_owner_failure():
    """A key whose owner has failed is still served by a replica."""
    sp = AddressSpace(2, (3, 4))
    net = Network(sp)
    origin = sp.decode(0)
    window = "בראש"
    s = net.summary(window, origin)
    key = wc.window_key(window, "hebrew-wlc")
    owner = key_address(key, sp)
    net.fail_node(owner)
    if owner == origin:
        origin = sp.decode(1)
    assert net.get(key, window, origin) == s
