"""Smoke tests for qbx_live.output (plots and audio)."""

import matplotlib

matplotlib.use("Agg")

import numpy as np

from qbx_ir.core.braid import Braid
from qbx_live import output as O


def test_dashboard_and_panels():
    import matplotlib.pyplot as plt

    for n, w in ((3, [1, -2, 1]), (4, [1, 2, 3, -1]), (8, [1, 2, 4])):
        fig = O.dashboard(Braid.from_short_form(n, w))
        assert len(fig.axes) >= 7
        plt.close(fig)
    fig, ax = plt.subplots(1, 2)
    O.plot_healing_flow(Braid.from_short_form(3, [1, 2]), ax)
    plt.close(fig)


def test_sonify_and_wav():
    b = Braid.from_short_form(3, [1, -2, 1, 1])
    a = O.sonify(b, duration=0.5)
    assert a.shape == (int(0.5 * O.SAMPLE_RATE), 2)
    assert np.max(np.abs(a)) <= 1.0
    h = O.sonify_healing(b, steps=3, step_duration=0.2)
    assert h.shape[1] == 2
    wav = O.to_wav_bytes(a)
    assert wav[:4] == b"RIFF" and wav[8:12] == b"WAVE"


def test_chords():
    assert O.chord_for_cycle_type((1, 1, 1)) == (0, 4, 7)
    assert O.chord_for_cycle_type((2, 1)) == (0, 3, 7)
    assert O.chord_for_cycle_type((3,)) == (0, 3, 6)
