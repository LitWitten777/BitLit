"""Round-trip and validation tests for the summary wire format (qbx_live.wire)."""

import random

import pytest

from qbx_bible import Encoding, load_corpus
from qbx_bible import manifold as mf
from qbx_ir import Braid
from qbx_ir.algebra import multiprover as mp
from qbx_live import wire


def _random_braid(rng, n, length):
    return Braid.from_short_form(n, [rng.choice([1, -1]) * rng.randint(1, n - 1)
                                     for _ in range(length)])


@pytest.mark.parametrize("n", [2, 3, 4, 6])
def test_reading_round_trip(n):
    rng = random.Random(n)
    for _ in range(10):
        b = _random_braid(rng, n, rng.randint(0, 25))
        r = mp.scheduled_reading(b, 5)
        assert wire.from_cbor(wire.to_cbor(r)) == r
        assert wire.from_json(wire.to_json(r)) == r


def test_one_strand_reading():
    r = mp.scheduled_reading(Braid.identity(1), 4)
    assert wire.decode(wire.encode(r)) == r
    assert wire.encode(r)["burau"] == {"rows": 0, "emin": 0, "emax": 0, "coeffs": []}


def test_encoding_is_canonical():
    """Equal summaries computed along different chunkings give identical bytes."""
    rng = random.Random(7)
    b = _random_braid(rng, 4, 40)
    a = mp.scheduled_reading(b, 3)
    c = mp.scheduled_reading(b, 17)
    assert a == c
    assert wire.to_cbor(a) == wire.to_cbor(c)
    assert wire.digest(a) == wire.digest(c)


def test_decoded_readings_merge():
    """A receiver can merge decoded summaries (monoid product survives the wire)."""
    rng = random.Random(11)
    b1, b2 = _random_braid(rng, 3, 12), _random_braid(rng, 3, 9)
    r1 = wire.from_cbor(wire.to_cbor(mp.scheduled_reading(b1, 4)))
    r2 = wire.from_cbor(wire.to_cbor(mp.scheduled_reading(b2, 4)))
    assert mp.merge_readings(r1, r2) == mp.scheduled_reading(b1 * b2, 64)


@pytest.mark.parametrize("enc", [Encoding(8, True), Encoding(23, False)])
def test_text_summary_round_trip(enc):
    verses = [v.text for v in load_corpus()][:5]
    for keep in (True, False):
        s = mf.summarize(" ".join(verses), enc, keep)
        assert wire.from_cbor(wire.to_cbor(s)) == s
        assert wire.from_json(wire.to_json(s)) == s
    assert wire.decode(wire.encode(mf.identity(enc))) == mf.identity(enc)


def test_rejects_malformed():
    r = mp.scheduled_reading(Braid.from_short_form(3, [1, -2, 1]), 2)
    good = wire.encode(r)
    bad_version = dict(good, v=99)
    bad_perm = dict(good, perm=[1, 1, 3])
    bad_len = dict(good, burau=dict(good["burau"], coeffs=good["burau"]["coeffs"][:-1]))
    wide = dict(good["burau"])
    wide["emin"] -= 1
    wide["coeffs"] = [x for i in range(0, len(good["burau"]["coeffs"]),
                                       good["burau"]["emax"] - good["burau"]["emin"] + 1)
                      for x in [0] + good["burau"]["coeffs"][i:i + good["burau"]["emax"]
                                                               - good["burau"]["emin"] + 1]]
    bad_window = dict(good, burau=wide)
    for obj in (bad_version, bad_perm, bad_len, bad_window, {"kind": "chunk-reading"}, [1, 2]):
        with pytest.raises(wire.WireError):
            wire.decode(obj)
    with pytest.raises(wire.WireError):
        wire.from_cbor(b"\xff\x00garbage")
