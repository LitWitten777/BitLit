"""Tests for gematria mapping and Hebrew mixing."""

from qbx.hebrew.gematria import GEMATRIA, gematria_value, gematria_vector
from qbx.hebrew.mixing import HebrewMixer

def test_gematria_known_values():
    assert gematria_value("א") == 1
    assert gematria_value("ת") == 400
    # Final letters use the extended values ך=500 … ץ=900 (the convention of both
    # qbx.hebrew.gematria.GEMATRIA and migration 014's hebrew_letter seed), so the
    # final mem in שלום counts 600, not 40.
    assert gematria_value("שלום") == 300 + 30 + 6 + 600  # 936
    assert gematria_value("תורה") == 400 + 6 + 200 + 5  # 611 (no final letters)

def test_gematria_vector_deterministic():
    v1 = gematria_vector("שלום")
    v2 = gematria_vector("שלום")
    assert v1 == v2
    assert len(v1) == 256
    assert all(-1.0 <= x < 1.0 for x in v1)

def test_gematria_vector_differs_for_different_words():
    v1 = gematria_vector("שלום")
    v2 = gematria_vector("תורה")
    assert v1 != v2

def test_hebrew_mixer_deterministic():
    mixer = HebrewMixer(enabled=True)
    data = b"hello world"
    h1 = mixer.mix(data, label="שלום", nonce=b"0" * 8)
    h2 = mixer.mix(data, label="שלום", nonce=b"0" * 8)
    assert h1 == h2

def test_hebrew_mixer_disabled_falls_back_to_pq_hash():
    from qbx.core.hashing import pq_hash
    mixer = HebrewMixer(enabled=False)
    data = b"hello"
    assert mixer.mix(data, label="שלום") == pq_hash(data)

def test_hebrew_mixer_label_changes_hash():
    mixer = HebrewMixer(enabled=True)
    data = b"hello"
    h1 = mixer.mix(data, label="שלום", nonce=b"0" * 8)
    h2 = mixer.mix(data, label="תורה", nonce=b"0" * 8)
    assert h1 != h2