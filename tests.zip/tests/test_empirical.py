"""The empirical-grounding reference checks (``qbx.empirical``; migration 016).

The live-database tests (``tests/live_db/test_empirical_db.py``) show the
database reports the same problems; these tests pin the reference itself and
use the results of ``Formal/Empirical.lean`` as oracles.
"""

from __future__ import annotations

import itertools
import random
from datetime import timedelta
from fractions import Fraction

from qbx.empirical.measurement import (
    bundle_problems,
    bundle_validated_problems,
    contract_problems,
    half_width_factor,
    precision_ok,
    range_ok,
    uncertainty_problems,
    validate,
    validation_problems,
)
from qbx.empirical.mechanism import ic_failures, ir_failures, mechanism_problems, spec_problems, utility
from qbx.empirical.models import agent_problems, dynamical_model_problems, simulation_problems
from qbx.empirical.values import exact
from tests.empirical_examples import (
    good_bundle,
    good_contract,
    good_descriptor,
    random_spec,
)
from tests.governance_examples import T0

F = Fraction


def contract(**kw):
    c = {"name": "c", "observable_id": "T", "version": "1.0.0", "body": {"min": 0, "max": 10,
         "unit": "K"}, "expected_precision": {"absolute": 0.5},
         "validation_tests": ["range_check", "precision_check", "unit_check"]}
    c.update(kw)
    return c


def cp(c):
    return contract_problems(c["name"], c["observable_id"], c["version"], c["body"],
                             c["expected_precision"], c["validation_tests"])


# ---------------------------------------------------------------------------
# Uncertainty types
# ---------------------------------------------------------------------------
def test_uncertainty_types():
    assert uncertainty_problems("i", {"kind": "interval"}) == []
    assert uncertainty_problems("g", {"kind": "gaussian", "coverage_factor": 2}) == []
    assert uncertainty_problems("g", {"kind": "gaussian", "sigma": -2}) == \
        [("uncertainty_typing", {"error": "coverage_factor"})]
    assert uncertainty_problems(" ", 42) == [("uncertainty_typing", {"error": "name"}),
                                             ("uncertainty_typing", {"error": "descriptor"})]
    assert uncertainty_problems("x", {"kind": ["interval"]}) == \
        [("uncertainty_typing", {"error": "kind"})]
    assert half_width_factor(None) == 1
    assert half_width_factor({"kind": "uniform"}) == 1
    assert half_width_factor({"kind": "gaussian", "coverage_factor": 1.5}) == F(3, 2)


# ---------------------------------------------------------------------------
# Contracts and bundles
# ---------------------------------------------------------------------------
def test_contract_problems():
    assert cp(contract()) == []
    # the original migration's misspelled test and inverted bounds
    assert cp(contract(body={"min": 10, "max": 0}, validation_tests=["rnage_check"])) == [
        ("contract_typing", {"error": "bounds"}),
        ("contract_typing", {"error": "test", "test": "rnage_check"})]
    assert cp(contract(name="  ", observable_id="", expected_precision={"absolute": -1})) == [
        ("contract_typing", {"error": "name"}), ("contract_typing", {"error": "observable"}),
        ("contract_typing", {"error": "precision"})]
    assert cp(contract(expected_precision={}, validation_tests=["precision_check"])) == [
        ("contract_typing", {"error": "precision_check"})]
    assert cp(contract(body=[], validation_tests=["unit_check", "unit_check"])) == [
        ("contract_typing", {"error": "body"}),
        ("contract_typing", {"error": "duplicate_test", "test": "unit_check"}),
        ("contract_typing", {"error": "unit_check"})]
    assert cp(contract(version="banana", validation_tests="range_check",
                       body={"min": None, "unit": ""})) == [
        ("contract_typing", {"error": "version"}), ("contract_typing", {"error": "bounds"}),
        ("contract_typing", {"error": "unit"}), ("contract_typing", {"error": "tests"})]
    assert cp(contract(body={"min": True})) == [("contract_typing", {"error": "bounds"}),
                                                ("contract_typing", {"error": "unit_check"})]


def test_bundle_problems():
    assert bundle_problems([{"value": 1, "uncertainty": 0, "unit": "K"}], {}, {}) == []
    assert bundle_problems({"value": 99}, {}, {}) == [("bundle_typing", {"error": "observations"})]
    assert bundle_problems([], None, 5) == [("bundle_typing", {"error": "observations"}),
                                            ("bundle_typing", {"error": "context"}),
                                            ("bundle_typing", {"error": "provenance"})]
    assert bundle_problems([{"v": 99}, 3, {"value": True, "uncertainty": -1, "unit": " "}],
                           {}, {}) == [
        ("bundle_typing", {"error": "observation", "index": 0, "field": "value"}),
        ("bundle_typing", {"error": "observation", "index": 1, "field": "object"}),
        ("bundle_typing", {"error": "observation", "index": 2, "field": "value"}),
        ("bundle_typing", {"error": "observation", "index": 2, "field": "uncertainty"}),
        ("bundle_typing", {"error": "observation", "index": 2, "field": "unit"})]
    assert bundle_problems([{"value": float("nan")}], {}, {})[0][1]["field"] == "value"


# ---------------------------------------------------------------------------
# Validation — oracles from Formal/Empirical.lean
# ---------------------------------------------------------------------------
def in_bounds(lo, hi, x):
    return (lo is None or lo <= x) and (hi is None or x <= hi)


def test_range_ok_iff_every_allowed_value_in_bounds():
    """``rangeOk_iff``: for h ≥ 0 the check holds iff every x with |x − v| ≤ h
    is in bounds.  The allowed values form an interval, so its endpoints and
    a grid of interior points decide the right-hand side."""
    vals = [F(n, 4) for n in range(-8, 9)]
    for lo, hi, h, v in itertools.product([None, F(-1), F(0), F(1, 2)], [None, F(0), F(1)],
                                          [F(0), F(1, 4), F(1)], vals[::3]):
        allowed = [v - h + (2 * h) * F(k, 8) for k in range(9)]
        assert range_ok(lo, hi, h, v) == all(in_bounds(lo, hi, x) for x in allowed)


def test_range_ok_factor_antitone():
    """``rangeOk_factor_antitone``."""
    rng = random.Random(16)
    for _ in range(500):
        lo, hi = F(rng.randint(-5, 0)), F(rng.randint(0, 5))
        u, v = F(rng.randint(0, 4), 2), F(rng.randint(-6, 6), 2)
        k, k2 = sorted([F(rng.randint(0, 6), 2), F(rng.randint(0, 6), 2)])
        if range_ok(lo, hi, k2 * u, v):
            assert range_ok(lo, hi, k * u, v)


def passes(c, factor, t, o):
    v, u = exact(o["value"]), exact(o.get("uncertainty", 0))
    body, prec = c["body"], c["expected_precision"]
    if t == "range_check":
        return range_ok(exact(body["min"]) if "min" in body else None,
                        exact(body["max"]) if "max" in body else None, factor * u, v)
    if t == "precision_check":
        return precision_ok(exact(prec.get("absolute", 0)), exact(prec.get("relative", 0)), u, v)
    return o.get("unit") == body.get("unit")


def test_report_is_the_failing_pairs():
    """``mem_report_iff`` and ``report_eq_nil_iff``."""
    rng = random.Random(1016)
    for n in range(800):
        c, b, d = good_contract(rng, f"c{n}"), good_bundle(rng), good_descriptor(rng)
        assert cp(c) == [] and bundle_problems(b["observations"], {}, {}) == []
        ok, report = validate(c, b, d)
        factor = half_width_factor(d)
        expected = [{"test": t, "index": i} for t in c["validation_tests"]
                    for i, o in enumerate(b["observations"]) if not passes(c, factor, t, o)]
        assert report == expected
        assert ok == all(passes(c, factor, t, o) for t in c["validation_tests"]
                         for o in b["observations"])


def test_exact_boundary():
    c = contract()
    assert validate(c, {"observations": [{"value": 9.7, "uncertainty": 0.3, "unit": "K"}]}) == \
        (True, [])
    assert validate(c, {"observations": [{"value": 9.8, "uncertainty": 0.6}]}) == (False, [
        {"test": "range_check", "index": 0}, {"test": "precision_check", "index": 0},
        {"test": "unit_check", "index": 0}])
    # a gaussian coverage factor widens the interval
    obs = {"observations": [{"value": 9, "uncertainty": 0.5, "unit": "K"}]}
    assert validate(c, obs, {"kind": "gaussian", "coverage_factor": 2})[0]
    assert not validate(c, obs, {"kind": "gaussian", "coverage_factor": 3})[0]


def test_validation_problems():
    c = contract()
    b = {"observations": [{"value": 5, "unit": "K"}], "context": {}, "provenance": {}}
    assert validation_problems(True, [], b, c) == []
    assert validation_problems(False, [], b, c) == \
        [("validation_result", {"recorded": False, "computed": True})]
    assert validation_problems(True, [{"test": "range_check", "index": 0}], b, c) == \
        [("validation_result", {"recorded": True, "computed": True})]
    assert validation_problems(None, None, None, None) == [
        ("validation_typing", {"error": "bundle"}), ("validation_typing", {"error": "contract"}),
        ("validation_typing", {"error": "ok"}), ("validation_typing", {"error": "report"})]
    bad = dict(b, observations=[{"v": 99}])
    assert validation_problems(True, [], bad, contract(body={"min": 10, "max": 0}),
                               ("g", {"kind": "gaussian"})) == [
        ("validation_input", {"error": "bundle"}), ("validation_input", {"error": "contract"}),
        ("validation_input", {"error": "uncertainty"})]


def test_bundle_validated():
    assert bundle_validated_problems(False, None, None) == []
    assert bundle_validated_problems(True, None, None) == [("bundle_validated", {"field": "validated"})]
    assert bundle_validated_problems(True, [], (True, [])) == []
    assert bundle_validated_problems(True, [], (False, [{"test": "unit_check", "index": 0}])) == [
        ("bundle_validated", {"field": "validated"}), ("bundle_validated", {"field": "report"})]


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------
def test_dynamical_models_and_runs():
    assert dynamical_model_problems("m", "ODE", "dx/dt = -x", {"tolerance": 1e-6}, {}) == []
    assert dynamical_model_problems("", "ODE", "", [1], {}) == [
        ("model_typing", {"error": "name"}), ("model_typing", {"error": "spec"}),
        ("model_typing", {"error": "solver_config"})]
    assert dynamical_model_problems("m", "chaos", "x", {"tolerance": 0}, None) == [
        ("model_typing", {"error": "model_type"}), ("model_typing", {"error": "tolerance"}),
        ("model_typing", {"error": "metadata"})]
    assert simulation_problems(True, {"x": 1}, "rk45", 1e-6, "s3://r", {}, T0, T0) == []
    # the original migration's run: tolerance −1, finished before it started
    assert simulation_problems(True, 7, None, -1.0, None, None, T0, T0 - timedelta(days=1)) == [
        ("simulation_typing", {"error": "initial_conditions"}),
        ("simulation_typing", {"error": "tolerance"}), ("simulation_typing", {"error": "window"})]
    assert simulation_problems(False, {}, " ", float("nan"), "", [], None, T0) == [
        ("simulation_typing", {"error": e}) for e in
        ("model", "solver", "tolerance", "result_uri", "result_summary", "started_at")]


def test_agent_models():
    assert agent_problems("a", {}, ["cam"], ["arm"], None,
                          [{"actuator": "arm", "min": -1, "max": 1}], {}) == []
    assert agent_problems("", None, 5, None, None, None, {}) == [
        ("agent_typing", {"error": "name"}), ("agent_typing", {"error": "sensors"})]
    assert agent_problems("a", [], ["c", "c", "c"], ["arm", "arm"], 3,
                          [{"actuator": "arm", "min": 2, "max": 1}, {"actuator": "leg"}, 7],
                          {}) == [
        ("agent_typing", {"error": "body_spec"}),
        ("agent_typing", {"error": "duplicate_sensor", "name": "c"}),
        ("agent_typing", {"error": "duplicate_sensor", "name": "c"}),
        ("agent_typing", {"error": "duplicate_actuator", "name": "arm"}),
        ("agent_typing", {"error": "learning_module"}),
        ("agent_typing", {"error": "safety_constraint", "index": 0}),
        ("agent_typing", {"error": "safety_constraint", "index": 1}),
        ("agent_typing", {"error": "safety_constraint", "index": 2})]
    assert agent_problems("a", None, None, None, None, {"actuator": "arm"}, []) == [
        ("agent_typing", {"error": "safety"}), ("agent_typing", {"error": "metadata"})]


# ---------------------------------------------------------------------------
# Mechanisms — oracles from Formal/Empirical.lean
# ---------------------------------------------------------------------------
POSTED_PRICE = {
    "types": ["lo", "hi"], "outcomes": ["none", "item"],
    "allocation": {"lo": "none", "hi": "item"}, "payment": {"lo": 0, "hi": 1.5},
    "valuation": {"lo": {"none": 0, "item": 1}, "hi": {"none": 0, "item": 2}},
}


def test_posted_price_is_ic_and_ir_and_overpricing_is_caught():
    assert mechanism_problems("posted price", POSTED_PRICE, {"ic": True, "ir": True}, {}) == []
    over = dict(POSTED_PRICE, payment={"lo": 0, "hi": 2.5})
    assert mechanism_problems("m", over, {"ic": True, "ir": True}, {}) == [
        ("mechanism_ic", {"type": "hi", "report": "lo", "gain": 0.5}),
        ("mechanism_ir", {"type": "hi", "utility": -0.5})]
    # unclaimed properties are not checked
    assert mechanism_problems("m", over, {}, {}) == []
    assert mechanism_problems("", "x", [], {}) == [
        ("mechanism_typing", {"error": "name"}), ("mechanism_typing", {"error": "spec"}),
        ("mechanism_typing", {"error": "constraints"})]


def test_spec_problems():
    assert spec_problems({"types": ["a", "a"], "outcomes": []}) == [
        ("mechanism_typing", {"error": "types"}), ("mechanism_typing", {"error": "outcomes"})]
    bad = dict(POSTED_PRICE, allocation={"lo": "none", "hi": "ghost"},
               payment={"lo": 0, "hi": "1"}, valuation={"lo": {"none": 0}, "hi": {}})
    assert spec_problems(bad) == [("mechanism_typing", {"error": e})
                                  for e in ("allocation", "payment", "valuation")]


def is_ic(spec):
    return all(utility(spec, t, r) <= utility(spec, t, t)
               for t in spec["types"] for r in spec["types"])


def is_ir(spec):
    return all(utility(spec, t, t) >= 0 for t in spec["types"])


def test_failure_lists_are_ic_and_ir():
    """``icFailures_eq_nil_iff``, ``irFailures_eq_nil_iff``, and the gains are
    the utility differences."""
    rng = random.Random(2016)
    seen_ic = seen_not_ic = 0
    for _ in range(2000):
        spec = random_spec(rng)
        if spec_problems(spec):
            continue
        assert (ic_failures(spec) == []) == is_ic(spec)
        assert (ir_failures(spec) == []) == is_ir(spec)
        for _, d in ic_failures(spec):
            assert F(d["gain"]).limit_denominator(100) == \
                utility(spec, d["type"], d["report"]) - utility(spec, d["type"], d["type"])
        seen_ic += is_ic(spec)
        seen_not_ic += not is_ic(spec)
    assert seen_ic > 50 and seen_not_ic > 50


def test_ic_payment_bounds_and_weak_monotonicity():
    """``ic_payment_bounds``, ``ic_weak_monotone``."""
    rng = random.Random(3016)
    checked = 0
    for _ in range(3000):
        spec = random_spec(rng)
        if spec_problems(spec) or not is_ic(spec):
            continue
        a, p, val = spec["allocation"], spec["payment"], spec["valuation"]
        for t, r in itertools.product(spec["types"], repeat=2):
            v = lambda x, o: exact(val[x][o])
            dp = exact(p[t]) - exact(p[r])
            assert v(r, a[t]) - v(r, a[r]) <= dp <= v(t, a[t]) - v(t, a[r])
            assert v(r, a[t]) + v(t, a[r]) <= v(t, a[t]) + v(r, a[r])
        checked += 1
    assert checked > 50


def test_single_parameter_monotone():
    """``ic_single_parameter_monotone``: valuations θ_t · q_o."""
    rng = random.Random(4016)
    theta = {"lo": 1, "mid": 2, "hi": 3}
    q = {"none": 0, "half": 1, "item": 2}
    checked = 0
    for _ in range(4000):
        types = rng.sample(list(theta), rng.randint(2, 3))
        spec = {"types": types, "outcomes": list(q),
                "allocation": {t: rng.choice(list(q)) for t in types},
                "payment": {t: rng.choice([0, 1, 2, 3, 4]) for t in types},
                "valuation": {t: {o: theta[t] * q[o] for o in q} for t in types}}
        if not is_ic(spec):
            continue
        for t, r in itertools.product(types, repeat=2):
            if theta[r] < theta[t]:
                assert q[spec["allocation"][r]] <= q[spec["allocation"][t]]
        checked += 1
    assert checked > 50
