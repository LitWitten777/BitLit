"""Tests for canonical serialization."""

import pytest

from qbx.core.canonical import canonical_cbor, canonical_json, canonical_bytes

def test_canonical_json_deterministic():
    obj = {"b": 2, "a": 1, "nested": {"z": [3, 2, 1], "y": 0.5}}
    c1 = canonical_json(obj)
    c2 = canonical_json(obj)
    assert c1 == c2

def test_canonical_json_key_order():
    obj1 = {"b": 1, "a": 2}
    obj2 = {"a": 2, "b": 1}
    assert canonical_json(obj1) == canonical_json(obj2)

def test_canonical_cbor_deterministic():
    obj = {"x": [1, 2, 3], "y": {"a": 1}}
    c1 = canonical_cbor(obj)
    c2 = canonical_cbor(obj)
    assert c1 == c2

def test_canonical_cbor_map_key_order():
    obj1 = {"b": 1, "a": 2}
    obj2 = {"a": 2, "b": 1}
    assert canonical_cbor(obj1) == canonical_cbor(obj2)

def test_canonical_bytes_dispatch():
    obj = {"a": 1}
    assert canonical_bytes(obj, "cbor") == canonical_cbor(obj)
    assert canonical_bytes(obj, "json") == canonical_json(obj)