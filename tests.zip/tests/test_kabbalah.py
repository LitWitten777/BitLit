"""Regression harness for ``docs/research/harmonic_bible_braid_bridge.md``.

The bridge document proposes five tests ("Test 1" … "Test 5") and a number of numerical
claims.  This file runs the ones that are precise statements about the existing code, with the
corrections found while checking them.  The Lean counterparts (proofs, not tests) are in
``Formal/BibleBridgeAudit.lean`` and ``Formal/StructuralBraid.lean``; each test names its
theorem.

Not covered here: Test 3 (the adjunction) needs a choice of categories and functors that the
document leaves open, and Test 5 is the Lean build itself (``lake build QBXFormal``).
"""

import os
import random
import sys

import pytest

from qbx_ir import Braid, EqualityKind, check_equality
from qbx_ir.algebra.garside import braid_group_equal
from qbx_ir.algebra.invariants import permutation, writhe
from qbx_ir.algebra.polynomial_invariants import burau_matrix

from qbx_bible import Encoding, encode_text
from qbx_bible.encode import HEBREW

FOUNDATION = os.path.join(os.path.dirname(__file__), "..", "foundation")

#: Mispar hechrachi: final letters take the value of their base letter.
HECHRACHI = dict(zip(HEBREW, [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 20, 30, 40, 50, 60, 70, 80, 90,
                              100, 200, 300, 400]))
HECHRACHI.update({"ך": 20, "ם": 40, "ן": 50, "ף": 80, "ץ": 90})
#: The table seeded by migration 014 (`Gematria.standard` in Lean): finals 500–900.
SEEDED = dict(HECHRACHI)
SEEDED.update({"ך": 500, "ם": 600, "ן": 700, "ף": 800, "ץ": 900})


def value(word, table):
    return sum(table[c] for c in word if c in table)


def identity(n):
    return tuple(range(1, n + 1))


# ---------------------------------------------------------------------------
# The lexical encoder (`lexical_conflates_eq_lt`, `lexical_not_alpha_invariant`)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("strands", [8, 23])
def test_lexical_encoder_reads_letters_only(strands):
    enc = Encoding(strands)
    eq = encode_text("a+b=b+a", encoding=enc).braid
    lt = encode_text("a+b<b+a", encoding=enc).braid
    xy = encode_text("x+y=y+x", encoding=enc).braid
    assert eq.short_form() == lt.short_form()          # '=' and '<' are invisible
    assert not braid_group_equal(eq, xy)               # renaming changes the braid


# ---------------------------------------------------------------------------
# Test 1: the 22 letters on 23 strands (`alphabet_braid_23`, `alphabet_gen_injective_iff`)
# ---------------------------------------------------------------------------

def test_alphabet_is_the_22_generators_of_B23():
    word = encode_text("".join(HEBREW), encoding=Encoding(23)).braid.short_form()
    assert word == list(range(1, 23))


@pytest.mark.parametrize("strands", range(3, 23))
def test_alphabet_collides_below_23_strands(strands):
    word = encode_text("".join(HEBREW), encoding=Encoding(strands)).braid.short_form()
    assert len(set(word)) < 22


# ---------------------------------------------------------------------------
# Gematria is not a braid invariant (`gematria_not_braid_function`)
# ---------------------------------------------------------------------------

def test_gematria_is_not_a_function_of_the_braid():
    enc = Encoding(23)
    aba = encode_text("אבא", encoding=enc).braid
    bab = encode_text("באב", encoding=enc).braid
    assert braid_group_equal(aba, bab)                  # σ1σ2σ1 = σ2σ1σ2
    assert value("אבא", HECHRACHI) == 4 and value("באב", HECHRACHI) == 5


# ---------------------------------------------------------------------------
# Name values (`names_hechrachi`, `names_standard`)
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("word,expected", [
    ("אלהים", 86), ("יהוה", 26), ("אדני", 65), ("אל שדי", 345), ("משה", 345),
    ("אברם", 3 ** 5), ("אברהם", 248), ("מה", 45), ("אדם", 45), ("בליעל", 142),
    ("תאומיאל", 488),
])
def test_name_values_hechrachi(word, expected):
    assert value(word, HECHRACHI) == expected


@pytest.mark.parametrize("word,expected", [
    ("אלהים", 646), ("אדם", 605), ("אברם", 803), ("אברהם", 808),
])
def test_name_values_seeded_table(word, expected):
    assert value(word, SEEDED) == expected


# ---------------------------------------------------------------------------
# Test 2 and the three joinings (`hidden_braid_layers`, `adam_bride_eq_one`,
# `adam_lilith_layers`)
# ---------------------------------------------------------------------------

def test_lilith_is_a_nontrivial_pure_braid():
    lilith = Braid.from_short_form(3, [1, 1, -2, -2])
    adam = Braid.from_short_form(3, [])
    assert permutation(lilith) == permutation(adam)
    assert writhe(lilith) == writhe(adam)
    assert not check_equality(lilith, adam, EqualityKind.WORD).equal
    assert burau_matrix(lilith) != burau_matrix(adam)


def test_three_joinings():
    adam = Braid.from_short_form(3, [1, 2])
    adam_lilith = Braid.from_short_form(3, [1, 2, 1, 1, -2, -2])
    adam_bride = Braid.from_short_form(3, [1, 2, -2, -1])
    assert permutation(adam_lilith) == permutation(adam)
    assert writhe(adam_lilith) == writhe(adam)
    assert not braid_group_equal(adam_lilith, adam)
    assert braid_group_equal(adam_bride, Braid.identity(3))


# ---------------------------------------------------------------------------
# Correction: the commutator is not pure (`commutator_not_pure`)
# ---------------------------------------------------------------------------

def test_commutator_is_not_a_pure_braid():
    c = Braid.from_short_form(3, [1, 2, -1, -2])
    assert writhe(c) == 0
    perm = permutation(c)
    assert perm != identity(3)                          # the document says "trivial"
    assert sorted(perm) == [1, 2, 3] and all(perm[i] != i + 1 for i in range(3))  # a 3-cycle


# ---------------------------------------------------------------------------
# Test 4: the Fall as nonzero holonomy (Lean: `perturb_detected_iff_not_isBridge`)
# ---------------------------------------------------------------------------

def test_fork_is_detected_as_holonomy():
    sys.path.insert(0, FOUNDATION)
    try:
        from ws1_geometry.mixed_radix import MixedRadixSpace
        from ws2_gauge.groups import PermGroup
        from ws3_consensus.event_graph import build_flat_events, build_forked_events
        from ws3_consensus.flatness import consensus_check
    finally:
        sys.path.remove(FOUNDATION)
    space = MixedRadixSpace(n=2, moduli=(2, 2))
    group = PermGroup(3)
    rng = random.Random(42)
    flat, _ = build_flat_events(space, group, rng, edge_prob=1.0)
    assert consensus_check(flat, group).flat
    forked, _, _edge = build_forked_events(space, group, rng, edge_prob=1.0)
    assert not consensus_check(forked, group).flat
