"""Every test named in docs/phase_2_acceptance.md exists.

Keeps the Phase 2 acceptance checklist honest: a renamed or deleted test makes
this fail instead of leaving a dangling reference.
"""

from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOC = ROOT / "docs" / "phase_2_acceptance.md"


def _references():
    return sorted(set(re.findall(r"`(tests/[\w/]+\.py)(?:::(\w+))?`", DOC.read_text())))


def test_document_names_tests():
    assert len(_references()) >= 20


def test_every_referenced_test_exists():
    missing = []
    for path, name in _references():
        source = ROOT / path
        if not source.is_file():
            missing.append(path)
        elif name and not re.search(rf"^def {name}\(", source.read_text(), re.MULTILINE):
            missing.append(f"{path}::{name}")
    assert missing == []


def test_every_phase2_item_is_reviewed():
    text = DOC.read_text()
    for n in range(19, 23):
        assert re.search(rf"^\| 0{n} ", text, re.MULTILINE), n
    assert re.search(r"^\| QBX-IR ↔ ledger adapter ", text, re.MULTILINE)
