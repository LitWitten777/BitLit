"""Signed capability tokens with revocation (decision Q-001, option 2)."""

from __future__ import annotations

import pytest
from qbx.core.signing import StubSigner

from qbx.core.capability import (
    WEYL_EXPANSION_SCOPE,
    CapabilityIssuer,
    CapabilityVerifier,
    InvalidCapabilityError,
    RevocationList,
    VerifiedCapabilityGate,
    _b64d,
    _b64e,
    parse_token,
)
from qbx.core.exceptions import CapabilityRequiredError
from qbx.weyl.e8_roots import E8_ROOTS
from qbx.weyl.engine import WeylEngine

T0 = 1_800_000_000


def signer(tmp_path, key_id="k1", name="k1"):
    return StubSigner(key_path=str(tmp_path / f"{name}.pem"), key_id=key_id)


@pytest.fixture
def issuer(tmp_path):
    return CapabilityIssuer(signer(tmp_path))


@pytest.fixture
def verifier(tmp_path, issuer):
    return CapabilityVerifier({"k1": signer(tmp_path)})  # same key file: same key


def reason(verifier, token, scope="weyl:expand", now=T0):
    with pytest.raises(InvalidCapabilityError) as e:
        verifier.verify(token, scope, now)
    return e.value.reason


def test_valid_token_round_trip(issuer, verifier):
    tok = issuer.issue("alice", ["weyl:expand"], 3600, now=T0, token_id="t1")
    c = verifier.verify(tok, "weyl:expand", now=T0 + 10)
    assert (c.token_id, c.subject, c.scopes, c.key_id) == ("t1", "alice", ("weyl:expand",), "k1")
    assert c.expires_at == T0 + 3600


def test_window_is_half_open(issuer, verifier):
    tok = issuer.issue("a", ["s"], 100, now=T0)
    assert verifier.is_valid(tok, "s", now=T0)
    assert verifier.is_valid(tok, "s", now=T0 + 99)
    assert reason(verifier, tok, "s", now=T0 + 100) == "expired"
    assert reason(verifier, tok, "s", now=T0 - 1) == "not_yet_valid"


def test_clock_skew(issuer, verifier):
    v = CapabilityVerifier(verifier.trusted_keys, clock_skew_seconds=5)
    tok = issuer.issue("a", ["s"], 100, now=T0)
    assert v.is_valid(tok, "s", now=T0 - 5)
    assert v.is_valid(tok, "s", now=T0 + 104)
    assert not v.is_valid(tok, "s", now=T0 + 105)


def test_scope(issuer, verifier):
    tok = issuer.issue("a", ["weyl:expand"], 100, now=T0)
    assert reason(verifier, tok, "ledger:write") == "scope_not_granted"
    star = issuer.issue("a", ["*"], 100, now=T0)
    assert verifier.is_valid(star, "ledger:write", now=T0)


def test_revocation(issuer, verifier):
    tok = issuer.issue("a", ["s"], 100, now=T0, token_id="t9")
    verifier.revocations.revoke("t9", "compromised")
    assert reason(verifier, tok, "s") == "revoked"
    assert "t9" in verifier.revocations


def test_untrusted_key_and_forged_signature(tmp_path, issuer, verifier):
    other = CapabilityIssuer(signer(tmp_path, "k1", "other"))  # same id, different key
    assert reason(verifier, other.issue("a", ["s"], 100, now=T0), "s") == "bad_signature"
    stranger = CapabilityIssuer(signer(tmp_path, "k2", "stranger"))
    assert reason(verifier, stranger.issue("a", ["s"], 100, now=T0), "s") == "unknown_key"


def test_tampered_claims_rejected(issuer, verifier):
    tok = issuer.issue("a", ["s"], 100, now=T0)
    v, body, sig = tok.split(".")
    raw = _b64d(body).replace(b'"subject":"a"', b'"subject":"b"')
    assert reason(verifier, f"{v}.{_b64e(raw)}.{sig}", "s") == "bad_signature"
    # Re-encoding the same claims non-canonically is refused before any key lookup.
    spaced = _b64d(body).replace(b",", b", ")
    assert reason(verifier, f"{v}.{_b64e(spaced)}.{sig}", "s") == "non_canonical_claims"


@pytest.mark.parametrize("bad", ["", "abc", "a.b", "qbxcap1.!!!.x", "qbxcap2.e30.e30",
                                 "qbxcap1." + _b64e(b"[]") + ".AA",
                                 "qbxcap1." + _b64e(b'{"token_id":1}') + ".AA"])
def test_malformed(verifier, bad):
    with pytest.raises(InvalidCapabilityError):
        verifier.verify(bad, "s", now=T0)


def test_invalid_is_a_capability_required_error(verifier):
    with pytest.raises(CapabilityRequiredError):
        verifier.verify("junk", "s", now=T0)


def test_issue_rejects_empty_scope_and_bad_ttl(issuer):
    with pytest.raises(ValueError):
        issuer.issue("a", [], 10)
    with pytest.raises(ValueError):
        issuer.issue("a", ["s"], 0)


def test_parse_token_is_deterministic(issuer):
    tok = issuer.issue("a", ["b", "a", "a"], 10, now=T0, token_id="x")
    claims, _, _ = parse_token(tok)
    assert claims.scopes == ("a", "b")


def test_gate_admits_verified_token_into_weyl_engine(issuer, verifier):
    engine = WeylEngine(cache_max=0, require_capability=True)
    gate = VerifiedCapabilityGate(engine, verifier)
    tok = issuer.issue("alice", [WEYL_EXPANSION_SCOPE], 3600, now=T0, token_id="w1")
    gate.admit(tok, now=T0)
    assert len(engine.orbit(E8_ROOTS[0], max_size=500, capability_token=tok)) > 0

    gate.revoke("w1", "rotation")
    engine.clear_cache()
    with pytest.raises(CapabilityRequiredError):
        engine.orbit(E8_ROOTS[0], max_size=500, capability_token=tok)
    with pytest.raises(InvalidCapabilityError):
        gate.admit(tok, now=T0)


def test_gate_refuses_wrong_scope_and_sweeps_expired(issuer, verifier):
    engine = WeylEngine(cache_max=0, require_capability=True)
    gate = VerifiedCapabilityGate(engine, verifier)
    with pytest.raises(InvalidCapabilityError):
        gate.admit(issuer.issue("a", ["ledger:write"], 10, now=T0), now=T0)
    tok = issuer.issue("a", [WEYL_EXPANSION_SCOPE], 10, now=T0, token_id="e1")
    gate.admit(tok, now=T0)
    assert gate.sweep(now=T0 + 5) == frozenset()
    assert gate.sweep(now=T0 + 10) == frozenset({"e1"})
    with pytest.raises(CapabilityRequiredError):
        engine.orbit(E8_ROOTS[0], max_size=500, capability_token=tok)


def test_revocation_list_standalone():
    r = RevocationList()
    assert not r.is_revoked("x")
    r.revoke("x")
    assert r.is_revoked("x")
