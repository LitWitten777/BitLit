"""Tests for the Phase 1 limit / colimit engine (in-memory reference)."""

import itertools
import math

import pytest

from qbx.categorical import (
    Cone,
    Diagram,
    LimitChecker,
    LimitViolation,
    all_cones,
    cone_problems,
    is_limit,
)
from qbx.core.enforced_functor import Category, EnforcementMode

STRICT = EnforcementMode.STRICT
PERMISSIVE = EnforcementMode.PERMISSIVE


def poset(elements, leq):
    """The poset as a category: one morphism x→y iff x ≤ y; all composites recorded."""
    C = Category(id="P", name="poset")
    for x in elements:
        C.add_object(x, x)
        C.add_identity(x, f"id_{x}")
    for x, y in itertools.product(elements, repeat=2):
        if x != y and leq(x, y):
            C.add_morphism(f"{x}<{y}", x, y)

    def hom(x, y):
        return f"id_{x}" if x == y else f"{x}<{y}"

    for x, y, z in itertools.product(elements, repeat=3):
        if leq(x, y) and leq(y, z) and x != y and y != z:
            C.add_composition(hom(x, y), hom(y, z), hom(x, z))
    return C, hom


# Divisors of 12 under divisibility: limits are gcds, colimits are lcms.
DIV12 = ["1", "2", "3", "4", "6", "12"]


def divides(a, b):
    return int(b) % int(a) == 0


def product_category():
    C = Category(id="C", name="C")
    for o in ["A", "B", "P", "X"]:
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    for m, s, t in [("p", "P", "A"), ("q", "P", "B"), ("x1", "X", "A"), ("x2", "X", "B"),
                    ("u", "X", "P")]:
        C.add_morphism(m, s, t)
    C.add_composition("u", "p", "x1")
    C.add_composition("u", "q", "x2")
    D = Diagram(C, {"a": "A", "b": "B"})
    return C, D


def test_product_is_limit():
    C, D = product_category()
    lim = Cone(D, "P", {"a": "p", "b": "q"}, name="lim")
    other = Cone(D, "X", {"a": "x1", "b": "x2"}, name="other")
    chk = LimitChecker(PERMISSIVE)
    assert chk.verify_universality(lim, [other])
    assert chk.verify_universality(lim)          # exhaustively
    assert is_limit(lim)
    assert not is_limit(other)


def test_second_mediator():
    C, D = product_category()
    C.add_morphism("u2", "X", "P")
    C.add_composition("u2", "p", "x1")
    C.add_composition("u2", "q", "x2")
    lim = Cone(D, "P", {"a": "p", "b": "q"}, name="lim")
    other = Cone(D, "X", {"a": "x1", "b": "x2"}, name="other")
    chk = LimitChecker(PERMISSIVE)
    assert not chk.verify_universality(lim, [other])
    assert chk.reasons() == ["legs_not_jointly_monic", "non_unique_mediator"]
    with pytest.raises(LimitViolation):
        LimitChecker(STRICT).verify_universality(lim, [other])


def test_missing_composite_reported():
    C, D = product_category()
    C.add_morphism("u2", "X", "P")
    C.add_composition("u2", "p", "x1")
    lim = Cone(D, "P", {"a": "p", "b": "q"}, name="lim")
    chk = LimitChecker(PERMISSIVE)
    assert not chk.verify_universality(lim, [])
    assert chk.reasons() == ["missing_composite"]


def test_cone_problem_kinds():
    C = Category(id="C", name="C")
    for o in ["A", "B", "Z"]:
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("f", "A", "B")
    C.add_morphism("h", "B", "A")
    C.add_morphism("k", "Z", "A")
    D = Diagram(C, {"a": "A", "b": "B", "lonely": "Z", "blank": None},
                {"e": ("a", "b", "f"), "typo": ("a", "b", "h"), "none": ("a", "b", None)})
    c = Cone(D, "Z", {"a": "k", "lonely": "k", "ghost": "k"})
    assert sorted(r for r, _ in cone_problems(c)) == sorted([
        "arrow_typing", "arrow_without_morphism", "foreign_leg", "leg_typing",
        "missing_leg", "node_without_object",
    ])
    assert [r for r, _ in cone_problems(Cone(D, "W", {}))].count("apex_category") == 1


def test_identity_leg_triangles():
    C = Category(id="C", name="C")
    for o in ["A", "B"]:
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("f", "A", "B")
    D = Diagram(C, {"a": "A", "b": "B"}, {"e": ("a", "b", "f")})
    lim = Cone(D, "A", {"a": "id_A", "b": "f"})
    colim = Cone(D, "B", {"a": "f", "b": "id_B"}, cocone=True)
    assert cone_problems(lim) == [] and cone_problems(colim) == []
    assert is_limit(lim) and is_limit(colim)
    assert LimitChecker(PERMISSIVE).verify_universality(lim, [Cone(D, "A", dict(lim.legs))])


def test_non_commuting_and_missing_composite_triangles():
    C = Category(id="C", name="C")
    for o in ["X", "A", "B"]:
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("f", "A", "B")
    C.add_morphism("x", "X", "A")
    C.add_morphism("y", "X", "B")
    C.add_morphism("y2", "X", "B")
    D = Diagram(C, {"a": "A", "b": "B"}, {"e": ("a", "b", "f")})
    c = Cone(D, "X", {"a": "x", "b": "y"})
    assert [r for r, _ in cone_problems(c)] == ["missing_composite"]
    C.add_composition("x", "f", "y2")
    assert [r for r, _ in cone_problems(c)] == ["non_commuting_triangle"]
    chk = LimitChecker(PERMISSIVE)
    assert not chk.check_cone(c)
    assert chk.reasons() == ["non_commuting_triangle"]


def test_empty_diagram_terminal_and_independence():
    """Mirrors Formal/Limits.lean: existence alone and joint monicity alone
    each fail to make a limit."""
    C = Category(id="C", name="C")
    for o in ["T", "Y"]:
        C.add_object(o, o)
        C.add_identity(o, f"id_{o}")
    C.add_morphism("t", "Y", "T")
    E = Diagram(C, {})
    assert is_limit(Cone(E, "T", {}))
    # Jointly monic (vacuously: at most one morphism into Y from each object) but no mediator.
    chk = LimitChecker(PERMISSIVE)
    assert not chk.verify_universality(Cone(E, "Y", {}))
    assert chk.reasons() == ["no_mediator"]
    # Existence holds but not joint monicity.
    C.add_morphism("t2", "Y", "T")
    chk = LimitChecker(PERMISSIVE)
    assert not chk.verify_universality(Cone(E, "T", {}), [Cone(E, "T", {}, name="self")])
    assert chk.reasons() == ["legs_not_jointly_monic"]


@pytest.mark.parametrize("cocone", [False, True])
def test_poset_limits_are_meets_and_split_check_agrees(cocone):
    """In the divisor lattice of 12, for every set of nodes (discrete diagram)
    and every apex: the existence + uniqueness split (verify_universality,
    exhaustive) agrees with the definition (is_limit) and with gcd / lcm."""
    C, hom = poset(DIV12, divides)
    for k in range(0, 4):
        for nodes in itertools.combinations(DIV12, k):
            D = Diagram(C, {n: n for n in nodes})
            if cocone:
                target = str(math.lcm(*map(int, nodes))) if nodes else "1"
            else:
                target = str(math.gcd(*map(int, nodes))) if nodes else "12"
            for apex in DIV12:
                legs = {}
                ok = True
                for n in nodes:
                    if cocone and divides(n, apex):
                        legs[n] = hom(n, apex)
                    elif not cocone and divides(apex, n):
                        legs[n] = hom(apex, n)
                    else:
                        ok = False
                if not ok:
                    continue
                c = Cone(D, apex, legs, cocone=cocone)
                split = LimitChecker(PERMISSIVE).verify_universality(c)
                assert split == is_limit(c) == (apex == target), (nodes, apex)


def test_all_cones_over_arrow_diagram():
    C, hom = poset(DIV12, divides)
    D = Diagram(C, {"a": "2", "b": "4"}, {"e": ("a", "b", hom("2", "4"))})
    apexes = sorted(c.apex for c in all_cones(D))
    assert apexes == ["1", "2"]
    lim = next(c for c in all_cones(D) if c.apex == "2")
    assert is_limit(lim)
