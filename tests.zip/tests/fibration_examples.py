"""Shared fibration examples for ``tests/test_fibration.py`` and
``tests/live_db/test_fibration_db.py``."""

from __future__ import annotations

import random
from typing import Dict, Tuple

from qbx.categorical.fibration import Fibration, Lift, category


def elements_fibration(kind: str = "fibration") -> Fibration:
    """The category of elements of the presheaf F on B = (x --u--> y) with
    F(y) = {1, 2}, F(x) = {a, b, c} and F(u) : 1 ↦ a, 2 ↦ a.

    Its objects are ya1 = (y, 1), y2 = (y, 2), xa, xb, xc; its non-identity
    morphisms are the two lifts of u, l1 : xa → y1 and l2 : xa → y2.  It is a
    (discrete) fibration — every morphism is cartesian — but not an
    opfibration (u has no lift starting at xb or xc)."""
    B = category("B", ["x", "y"], {"u": ("x", "y")}, {})
    E = category("E", ["xa", "xb", "xc", "y1", "y2"],
                 {"l1": ("xa", "y1"), "l2": ("xa", "y2")}, {})
    obj = {"xa": "x", "xb": "x", "xc": "x", "y1": "y", "y2": "y"}
    mor = {f"id_{o}": f"id_{b}" for o, b in obj.items()}
    mor.update({"l1": "u", "l2": "u"})
    fib = Fibration(E, B, obj, mor, kind=kind)
    fib.register_lift("l1", "u")
    fib.register_lift("l2", "u")
    return fib


def non_cartesian_example() -> Fibration:
    """B = x --u--> y; E = a --φ--> b <--ψ-- c with a, c over x, b over y, and
    φ, ψ over u.  There is no morphism c → a, so φ is not cartesian: ψ factors
    through u ∘ id_x but not through φ (the original 010 accepted φ)."""
    B = category("B", ["x", "y"], {"u": ("x", "y")}, {})
    E = category("E", ["a", "b", "c"], {"phi": ("a", "b"), "psi": ("c", "b")}, {})
    obj = {"a": "x", "b": "y", "c": "x"}
    mor = {"id_a": "id_x", "id_b": "id_y", "id_c": "id_x", "phi": "u", "psi": "u"}
    fib = Fibration(E, B, obj, mor)
    fib.register_lift("phi", "u")
    return fib


def transformation_monoid() -> Tuple[list, str, Dict[Tuple[str, str], str]]:
    """The full transformation monoid T₂ of {0, 1}: identity, the swap s and the
    two constants c0, c1.  ``mul[(g, f)] = g ∘ f``.  Its units are id and s."""
    maps = {"id_*": (0, 1), "s": (1, 0), "c0": (0, 0), "c1": (1, 1)}
    rev = {v: k for k, v in maps.items()}
    mul = {(g, f): rev[tuple(maps[g][maps[f][i]] for i in range(2))]
           for g in maps for f in maps}
    return list(maps), "id_*", mul


def random_fibration(rng: random.Random) -> Fibration:
    """A random recording over B = (x ⇉ y, arrows u, v), with some bad rows:
    unmapped morphisms, partial composition tables, lifts over the wrong base
    morphism or with wrong endpoints."""
    B = category("B", ["x", "y"], {"u": ("x", "y"), "v": ("x", "y")}, {})
    objs = [f"e{i}" for i in range(rng.randint(2, 4))]
    obj = {o: rng.choice("xy") for o in objs}
    morphisms: Dict[str, Tuple[str, str]] = {}
    mor: Dict[str, str] = {f"id_{o}": f"id_{obj[o]}" for o in objs}
    for i in range(rng.randint(2, 7)):
        s, t = rng.choice(objs), rng.choice(objs)
        if (obj[s], obj[t]) == ("y", "x"):
            continue
        m = f"m{i}"
        morphisms[m] = (s, t)
        if rng.random() < 0.1:
            continue                                   # unmapped
        mor[m] = rng.choice("uv") if obj[s] != obj[t] else f"id_{obj[s]}"
    comps: Dict[Tuple[str, str], str] = {}
    for f, (fs, ft) in morphisms.items():
        for g, (gs, gt) in morphisms.items():
            if ft != gs or rng.random() > 0.6:
                continue
            cand = [h for h, st in morphisms.items() if st == (fs, gt)]
            if fs == gt and rng.random() < 0.3:
                cand.append(f"id_{fs}")
            if cand:
                comps[(g, f)] = rng.choice(cand)
    E = category("E", objs, morphisms, comps)
    fib = Fibration(E, B, obj, mor, kind=rng.choice(["fibration", "opfibration"]))
    for m in list(E.morphisms):
        if rng.random() > 0.5:
            continue
        s, t = E.morphisms[m]
        base = mor.get(m) or rng.choice(["u", "v"])
        if rng.random() < 0.1:
            base = rng.choice(["u", "v", "id_x", "id_y"])
        if rng.random() < 0.05:
            s, t = t, s
        fib.lifts.append(Lift(m, base, s, t))
    return fib
