# Review of the J. L. Nielsen (JLN) corpus for QBX

Scope: the 22 PDFs in `QBX/docs/design/` (prefixed `JLN_`), read against `plan.md`, `plan_2.md`
and `rigor_check.md`.  Goal: (1) pull out every insight QBX can use, (2) check every claim that
is precise enough to check, in Lean where possible, and (3) build the features that remove the
obstacles that keep recurring in this work.

Status labels used below:

* **Lean ✓** — proved in Lean, builds with `lake build QBXFormal`, no `sorry`, standard axioms only.
* **Lean ✗ (corrected)** — the claim as written is refuted in Lean; a corrected statement is proved.
* **Analytic note** — a mathematical observation made in this review but **not** machine-checked.
* **Out of formal scope** — physics identifications, empirical claims, philosophy, history.

All Lean files are under `QBX/Formal/JLN/` (audits) and `QBX/Formal/LinkingMatrix.lean` (new
feature), and are imported from `QBX/Formal.lean`.

---

## 1. The recurring obstacles

Reading the corpus as a whole, the same few failure modes keep blocking the work. They are the
ones the JLN Furey and Connes critiques themselves name (`rigor_check.md`, Part 3), and they show
up in JLN's own papers too:

| # | Obstacle | Where it bites | What QBX now provides |
|---|---|---|---|
| O1 | **× vs ⋊ vs ⊗ vs ⊕ vs ⊂**: the operation used is not the one the conclusion needs | Connes critique (direct vs semidirect product), Forcing Core Kernel 2 (ring product vs tensor product), Furey critique (⊕ vs ⊂) | `ConnesAudit`, `ForcingCoreAudit`, `FureyAudit`: each case proved both ways, with the exact condition under which the argument goes through |
| O2 | **Lean certifies a restatement of the hypothesis** | Forcing Core Kernels 1, 3, 4; Connes "proof" skeleton | `ConnesSkeleton.skeletonAxioms_iff_connes`: the 10-axiom package is *equivalent* to the conjecture; `ForcingCore.every_field_configuration_eq_field`: Kernel 4 is a field of its hypothesis, by `rfl` |
| O3 | **Axioms that say more (or other) than the cited theorem** | `kazhdan_finite_abelianisation` uses *functions*, not homomorphisms | `Connes.kazhdanFunctionSchema_kills_SL3`: that axiom denies property (T) to `SL(3, ℤ)` |
| O4 | **"Local ⇒ protected" without a gauge condition** | Microtubule QEC Theorem 1 | `Microtubule.triangle_local_change_detected` (counterexample) and `holonomy_gaugeTransform_closed_comm` (the correct statement), on the existing QBX gauge layer |
| O5 | **Finite per step ≠ finite overall** | Double Hopf "closure"; Verlinde/Page curve dimension count | `HopfSpectral.cgReach_unbounded`, `Verlinde.bipartition_dim_iff` |
| O6 | **Operator / spectrum mismatches** | `⋆d` vs scalar Laplacian, mass vs mass² | `HopfSpectral.scalar_eigenvalue_not_square`, exact `ζ_B(s) = ζ(s−2) − ζ(s)` and `ζ_B(0) = 1/2` |
| O7 | **Small arithmetic slips that propagate into tables** | 145 vs 232 intersections, `t = ⌊d/2⌋`, equal-trace ratios | `MicrotubuleAudit`, `FureyAudit` |

The practical rule that falls out (now applied throughout QBX): *state the object exactly, prove
the theorem about that object, and when a hypothesis carries the content, prove the equivalence so
the reader can see it.*

---

## 2. Paper-by-paper

### 2.1 *On the Invalidity of the Claimed Disproof of Connes' Rigidity Conjecture*

* **Insight kept.** "A correct proof of the wrong theorem" is the central risk of AI-assisted
  formalisation; check hypotheses on the concrete objects. QBX adopts this as policy (§1).
* **Direct-product steps — Lean ✓.** `prod_not_isICC`, `prod_center_infinite`,
  `fstHom_surjective`: for `A × G` with `A` abelian non-trivial (infinite), the centre contains
  `A`, the group is not ICC, and it surjects onto `A`.
* **Application to the published groups — Lean ✗ (corrected).** The critique's own table lists
  `Λ = D ⋊ K`, `Γ = E(n) ⋊ K` (semidirect, non-trivial action). "Zero cocycle" splits
  `0 → V → D → B → 0`; it does not make the action of `K` trivial. In a semidirect product a lattice
  element is central iff fixed by the action (`SemidirectProduct.inl_mem_center_iff'`), and the
  lattice projection is a homomorphism iff the action is trivial (`left_mul_hom_iff`). For
  `ℤ² ⋊ SL(2,ℤ)`: trivial centre (`affSL_center_eq_bot`), infinite conjugacy classes of lattice
  elements (`affSL_conjugatesOf_inl_infinite`), lattice projection not a homomorphism
  (`affSL_left_not_hom`). So neither obstruction applies to the groups actually in the code.
  (JLN's later paper restricts the obstructions to the "trivial-action reading", which is the right
  scope.)
* **Appendix A axiom — Lean ✗.** `kazhdan_finite_abelianisation` forbids surjective *functions*
  onto infinite abelian groups; `kazhdanFunctionSchema_kills_SL3` shows this rules out property (T)
  for `SL(3, ℤ)`, contradicting Kazhdan's theorem.
* Also noted (no Lean needed): the critique's table identifies `K` with a congruence subgroup of
  `SL₄(ℤ[t])` and `V = F₂[t]⁴`, not `Sp(2n, ℤ)` and `ℤ^{2n}`; the two descriptions should not be
  used interchangeably.

### 2.2 *Connes' Rigidity Conjecture: Disproof of the Counterexamples and Proof of the Theorem*

* **Appendix §A** — the corrected obstructions with homomorphisms; see 2.1 for their scope.
* **Appendix §B ("proof" of the conjecture) — Lean ✓ (status made exact).**
  `ConnesSkeleton.skeletonAxioms_iff_connes`: over any interpretation of `L`, `VNIso`, `IsICC`,
  `HasPropertyT`, the appendix's remaining ten declarations are satisfiable **iff** the conjecture
  holds for that interpretation. The skeleton checks the case analysis; the mathematical content is
  entirely in `rigid_d2_surjective` and `not_degenerateI/II`. The appendix is honest that it is a
  skeleton; this theorem makes precise that it adds no evidence beyond the cited results, and the
  conjecture should still be described as open.
* The operator-algebra argument (Ioana's classification, Bernoulli deformation, Popa finite index
  ⇒ surjectivity) is **out of formal scope** here; the step "finite index + finite depth ⇒ `δ₂`
  surjective" is where an expert referee should look first.

### 2.3 *A Critique of N. Furey*

* **Dimension count — Lean ✓.** `nested_vs_direct_finrank`: a `1 ⊂ 2 ⊂ 4 ⊂ 8` chain spans 8
  dimensions, the external direct sum 15; `finrank_direct_sum_HCR = 7`, `…_OHCR = 15`.
* **Strongest form of the core point — Lean ✓.** `no_injective_ringHom_prod`: a componentwise
  direct sum of two non-trivial rings has no injective ring map into any domain (the idempotent
  `(1,0)` has nowhere to go); `no_algebra_embedding_HCR`: `ℍ ⊕ ℂ ⊕ ℝ` does not embed in `ℍ`.
* **Equal-trace arithmetic — Lean ✗ (corrected).** Ranks `8, 4, 2` give `1/4 : 1/2 : 1`
  (`equal_trace_ratios_842`); `1/3 : 1/2 : 1` needs ranks `3 : 2 : 1`
  (`equal_trace_ranks_of_third_half_one`). The point (the constraint is imposed) stands; the stated
  ranks do not produce the stated ratios.
* **"Unit quaternions are a subset of CP¹" — Lean ✗ (corrected).** `hopf_not_injective_on_sphere`:
  `S³ → CP¹` identifies whole circles; `S³` fibres over `CP¹`. Likewise `S⁷ → CP³` uses only the
  complex structure and does not see the octonion product (the octonionic fibration is
  `S⁷ → S¹⁵ → S⁸`, cf. the existing `CayleyDicksonHopf`, which also confirms the sedenion failure
  JLN points to).
* `256 − 244 = 12` unexplained degrees of freedom: arithmetic correct.

### 2.4 *Canonical Field … and Particle Mass Derivations* (Appendix B, Lean Forcing Core)

* **Kernels 1, 3, 5 — correct.** Kernel 3 is the Yoneda uniqueness of classifying objects (ported:
  `ForcingCore.classifying_unique`).
* **Kernel 4 — Lean ✓, but it is the hypothesis.** `every_field_configuration_eq_field` shows the
  theorem's proof term is literally the fields of `Classifies`.
* **Kernel 2 — Lean ✗ (inference corrected).** "A domain has no product splitting" is right
  (`prod_not_isDomain`), but product *bundles* are classified by maps to `BG₁ × BG₂`, whose
  cohomology is a **tensor** product (Künneth), and `ℤ[x] ⊗ ℤ[y] ≅ ℤ[x, y]` is a domain
  (`tensor_polynomial_isDomain`). `CP^∞ × CP^∞ = B(U(1)×U(1))` classifies decomposable bundles
  and has domain cohomology, so Kernel 2 cannot certify indecomposability (Corollary 4).
* **Analytic note.** `Classifies` holds for `CP^∞` only; the finite shells `S^{2n+1} → CP^n`
  used later classify line bundles only over complexes of dimension `≤ 2n`.

### 2.5 *The Complex Hopf Fibration as the Canonical Space …* (spectral sections)

* **Exact input — Lean ✓.** With the spectrum recorded in `plan.md` (eigenvalue `ℓ+1`,
  multiplicity `ℓ(ℓ+2)`), `zetaB_eq_tsum`: `ζ_B(s) = ζ(s−2) − ζ(s)` for `Re s > 3`, and
  `zetaB_zero`: `ζ_B(0) = 1/2`. Hence (classical values, not formalised)
  `ζ_B'(0) = −ζ(3)/(4π²) + ½ log 2π`. This is the number any "zeta-regularised determinant" of the
  `S³` shell must start from.
* **Mass identification — Lean ✗ (inconsistency).** Thm 23: eigenvalue = mass; Thm 24(iii):
  eigenvalue = mass²; Prop 5: `Λ_k = k(k+2n−2)`, which is the *scalar Laplacian* spectrum, not
  `⋆d`. `scalar_eigenvalue_not_square`: `k(k+2)` is never a square, so `Λ_k ≠ λ_k²` either.
* **Analytic note (Theorem 17).** The symbol argument fixes `⋆d` only up to lower-order terms:
  `a·⋆d + b` (with `b` a constant) is also first-order, `SO(4)`-equivariant, self-adjoint and
  elliptic on coexact 1-forms. A constant shift changes every zeta determinant, so "unique up to a
  scalar multiple" needs an extra normalisation (e.g. homogeneity) to support the mass formulas.
* Theorems 5/6 (`SU(2)`, `SU(3)` from `S³`, `S⁵`), 28 (three generations), 46 (α) — **out of
  formal scope**; they depend on physical identifications.

### 2.6 *Topological Quantum Error Correction on the Microtubule Bundle*

* **Insight kept.** The paper's own distinction — a code on a *fibre* vs a code on the *bundle*
  (holonomy) — is exactly the QBX gauge-layer picture (connections on graphs, holonomy, flatness).
* **Theorem 1 (holonomy protection) — Lean ✗.** `triangle_local_change_detected`: a single-edge
  change of a flat connection on a 3-cycle changes the cycle holonomy (the QBX library already has
  the general form `perturb_detected_iff_not_isBridge`). Correct statement:
  `holonomy_gaugeTransform` / `holonomy_gaugeTransform_closed_comm` — holonomy is invariant under
  *gauge* transformations, not arbitrary local perturbations. Protection needs syndrome
  measurement + correction.
* **Tree-shaped base stores nothing — Lean ✓.** `acyclic_perturb_flat`: on an acyclic base every
  single-edge change of a flat connection stays flat.
* **Arithmetic — Lean ✗/✓.** 232 intersections over all left/right pairings, 145 only over
  unordered pairs (`intersections_all_pairings`, `intersections_unordered_pairs`);
  correctable errors are `⌊(d−1)/2⌋` (`unique_decoding`, `distance_twelve_not_six_correcting`): the
  12-protofilament value should be `t = 5`; `C(13,7)=1716`, `C(11,6)=462` correct
  (`binomial_values`).

### 2.7 *Paradox Lost: … Total Verlinde Formula …*

* **Bipartition — Lean ✗.** `bipartition_dim_iff`: `(k−m+1)(m+1) = k+1` only at `m = 0, k`, so the
  black-hole ⊗ radiation split of a `(k+1)`-dimensional space does not exist at intermediate
  steps; the dimensions don't add up either (`direct_sum_dim`).
* **`Z(S³)` — Lean ✗.** `S00_pos_lt_one`, `S00_not_nat`: `Z(S³) = S₀₀ ∈ (0,1)` for `k ≥ 1`; `k+1`
  is `dim H(T²)`.
* **Fusion rule — Lean ✗.** `verlinde_k2_half_half_half` (Verlinde formula gives
  `N_{½½}^{½} = 0` at `k = 2`) vs `nielsenRule_two_one_one_one` (stated rule gives 1): a parity
  condition is missing.

### 2.8 *The Double Hopf Framework with Complex Time*

* **Closure argument — Lean ✗.** `cgReach_all_of_one`, `cgReach_unbounded`: iterated
  Clebsch–Gordan coupling reaches every spin; selection rules bound growth per step, not the
  cascade. (Spectrum `k(k+2)` of `Δ_{S³}` with multiplicity `(k+1)²` is correct.)
* The note "the answer is no [for real time]" cites a reference for a Millennium problem that is
  open; **out of formal scope**, flagged for the author.

### 2.9 *HUFT? Critique of the Holomorphic UFT*

* **Insight kept, already in QBX.** "A contractible base trivialises every bundle" has an exact
  discrete counterpart: on a forest every flat connection is pure gauge and single-edge changes
  are invisible (`GaugeFlatness.isFlat_perturb_of_isBridge`, `MicrotubuleAudit.acyclic_perturb_flat`).
  Charge quantisation needing `H²(M; ℤ) ≠ 0` is standard. "Unification requires
  indecomposability" is a definition, not a theorem; see 2.4 for why cohomology-is-a-domain does
  not certify it.

### 2.10 Other physics papers

* *TUFT on `S¹ → S⁹ → CP⁴`*, *Equivalence Tables*, *Einstein's teleparallel notes*, *Spacetime
  Torsion Is Not Spin Density*, *Experimental Confirmation (holonomic wobble)*, *World Enough From
  Time (Hopf time-chaos theorem)*, *Gauge Theory teaching notes* — **out of formal scope** for this
  pass (physical identifications, PDE/ergodic theory, or empirical claims). Two notes:
  the Equivalence Tables list structures (e.g. `Spin(10)`, Pati–Salam) as "mathematically
  equivalent" to TUFT; they share some invariants but are not equivalent as structures, and the
  tables should say "compatible with" rather than "equivalent to". The teaching notes' dictionary
  (field = connection, charge = Chern class) is the same dictionary as the top of `plan.md`, which
  QBX's gauge layer implements.

### 2.11 Philosophy and other writing

* *Math Over Mechanism* / *Rational-Relational Theory of Explanation* — **insight kept**: the
  "invariance reading" (explain by what survives transformation) is the design principle QBX
  already follows (invariants of braids under R01–R03, holonomy under gauge). Each QBX invariant
  is now stated together with the transformation group it is invariant under (e.g. the linking
  matrix below).
* *Extended Mind*, *IsBitIt*, *SMASH THE PATRIARCHY*, *The Heart is a Dust Board* (Abu'l Wafa
  dissections) — out of scope for QBX formal work; no technical claims were extracted.

### 2.12 Yang–Mills paper: the `Λ⁺⁺` invariant (Def. 4.19, Thm. 6.11)

`QBX/Formal/JLN/LambdaPlusPlusAudit.lean` (H-191).  The definition is formalised verbatim for any
group (`lambdaPP`).  **Correct part:** a conjugation-invariant defect makes `Λ⁺⁺` gauge-invariant,
and on a gauge orbit the infimum over encodings is trivial (`lambdaPP_gauge_orbit`).  **Gap:** in
the one-plaquette `SU(2)` model with the paper's defect `1 - ½ Re tr`, `τ(a) = a⁴` and effective
coupling `κ(a)`, one has `Λ⁺⁺(a) = (1 - cos(a²κ))/a⁴`, pinned between `(2/π²)κ²` and `κ²/2`.  So a
uniform bound `Λ⁺⁺ ≥ ε > 0` holds **iff** the coupling is bounded away from zero
(`uniform_bound_iff`), and with an asymptotically free coupling (`κ² = 1/log(1/a)`) `Λ⁺⁺(a) → 0`
(`no_uniform_bound_running`).  Positivity uniformly in `a` is an input about the coupling, not a
consequence of the definition.

### 2.13 Riemann Hypothesis paper: the Lambda Irreducibility Theorem (Thm. 1.6.1)

`QBX/Formal/JLN/LambdaIrreducibilityAudit.lean` (H-192).  Formalised for an arbitrary satisfaction
system and instantiated with Mathlib's first-order logic (provability = truth in all models, i.e.
via Gödel completeness, cited).  **What the argument proves** (`independent_of_irreducible`): if
the round trip `R_L` preserves validity and refutation on the `L`-paradigm, Λ-irreducibility gives
independence — a hypothesis on the translation pair.  **Vacuity:** a round-trip-sound pair has no
Λ-irreducible sentences (`not_irreducible_of_sound`).  **As stated the theorem is false:** for the
pair `(id, ¬)` every sentence, provable ones included, is Λ-irreducible
(`FO.lambdaIrreducibility_false`, for every first-order theory with a model); irreducibility
depends on the pair, provability does not (`irreducibility_depends_on_pair`); a theory proves `S_L`
from `S_C` and `S_L ↔ S_C` with no translation (`FO.provable_and_irreducible`); and condition (3)
of Def. 1.4.3 holds automatically for every map on sentences (`FO.roundTrip_elementary_invariant`).

---

## 3. Features built for QBX

1. **Strand linking matrix** (`QBX/Formal/LinkingMatrix.lean`) — the integer, symmetric matrix
   proposed in `plan_2.md`, built as a homomorphism `crossHom : Bₙ →* ℤ^{n×n} ⋊ Sₙ`. Proved: well
   defined on braids (braid relations checked), permutation part = `permHom`, symmetric, zero
   diagonal, invariant under R01–R03, Hopf link entry 2 (linking number 1). This replaces the
   continuous Gauss-integral proposal with an exact, verified integer invariant.
2. **Semidirect-product toolkit** (`ConnesAudit`): centre and projection criteria for `N ⋊ G`,
   the affine group `ℤ² ⋊ SL(2,ℤ)` with trivial centre and infinite lattice classes.
3. **Specification equivalence pattern** (`ConnesSkeleton`): how to show that an axiom package is
   exactly as strong as the target statement. Reusable for any "skeleton" formalisation.
4. **Gauge transformations on graphs** (`MicrotubuleAudit`): `gaugeTransform` and its holonomy law,
   complementing the existing flatness/perturbation results.
5. **Exact spectral input** (`HopfSpectralAudit`): `ζ_B` for the `S³` shell and its value at 0.
6. **Modular data checks** (`VerlindeAudit`): the `SU(2)_k` S-matrix with exact evaluations.
7. **Closure linking numbers** (`QBX/Formal/ClosureLinking.lean`, registry H-132) — the step from
   the strand matrix of item 1 to a genuine *link* invariant, which is what `plan_2.md` actually
   asks for ("topologically stable").  Components of the closure are the cycles of the braid
   permutation; the linking number of two components is `½ Σ_{a ∈ C, b ∈ D} M a b`.  Proved:
   modulo 2, `M` is the inversion pattern of the permutation (`crossMatrix_mod_two`), so the
   halving is exact (`two_mul_linkingNumber`); the number of components and the multiset of
   pairwise linking numbers are unchanged by conjugation and by stabilisation, hence by every
   Markov move (`numComponents_markov`, `linkingSpectrum_markov`).  Worked examples: Hopf link
   `{1, 1}`, mirror Hopf `{−1, −1}`, unlink `{0, 0}`, so these three closed braids are pairwise
   not Markov equivalent.  Analytic note (not machine-checked): the raw strand matrix itself is
   not a link invariant (stabilisation adds a strand and a crossing, conjugation relabels
   strands), so any "70 × 70 language matrix" must be read per closure component, not per
   strand.

## 4. What remains open / suggested next steps

* Prove `ζ_B'(0)` in Lean (needs `ζ'(0)` and `ζ'(−2)`, not currently in Mathlib).
* ~~Formalise the closure-linking formula~~ — done (`ClosureLinking.lean`, item 7 of §3).
  Still open: the self-linking / framing part of plan_2's "total Hopf invariant" (writhe changes
  by ±1 under stabilisation, so only the inter-component part is a link invariant without a
  framing convention).
* Ask the author to (a) restate the Connes obstruction scope as "trivial action only", (b) mark
  the Connes proof as conditional on the cited inputs, (c) fix Kernel 2's inference, (d) reconcile
  Theorems 23/24/Prop 5, (e) replace Microtubule Theorem 1 by the gauge-invariance statement.

A ranked list of next steps for the whole project (including the open items above) is in
`QBX/docs/PROJECT_OVERVIEW_2026-10-09.md` §4.
