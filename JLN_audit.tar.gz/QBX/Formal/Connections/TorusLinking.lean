module

public import QBX.Formal.ClosureLinking
public import QBX.Formal.Connections.TorusLinks

@[expose] public section

/-!
# Linking numbers of torus links: `lk = (p/d)(q/d)`

The torus link `T(p, q)` is the closure of `torusBraid n q = (σ₁ ⋯ σ_{p-1})^q`, `p = n + 1`; it
has `d = gcd(p, q)` components (`torusBraid_components`).  Here we compute the linking number of
any two of them, with the braid-closure linking numbers of `ClosureLinking.lean`:

  **`lk(Cᵢ, Cⱼ) = (p/d)·(q/d)` for any two distinct components** (`torusBraid_linkingNumber`).

Every entry of the linking spectrum is therefore `(p/d)(q/d)` (`torusBraid_linkingSpectrum`).

## Proof

* `crossMatrix_cycBraid`, `crossMatrix_delta`: in `δ = σ₁ ⋯ σ_{p-1}` the strand labelled `0`
  crosses every other strand once, and no other pair of strands crosses.
* `crossMatrix_torusBraid`: since `δ` rotates the labels, the crossing matrix of `δ^q` is
  `Σ_{k<q} M_δ(a - k, b - k)`; for `a ≠ b` this is `cnt a + cnt b`, where
  `cnt x = #{k < q : k ≡ x (mod p)}` (`crossMatrix_torusBraid_of_ne`).
* `sameCycle_torus_iff`: two strand labels lie on the same component iff they agree modulo `d`.
  So a component has `p/d` labels (`card_closureComponent_torus`) and is hit by exactly `q/d` of
  the residues `0, …, q-1` (`sum_cnt_closureComponent`), because `d ∣ q`.
* Summing, the block sum is `2 (p/d)(q/d)`.
-/

namespace QBX.Formal.Connections

open Equiv QBX.Formal Finset Fin.NatCast

variable {n : ℕ}

/-! ### The crossing matrix of `δ = σ₁ ⋯ σ_{p-1}` -/

theorem crossMatrix_cycBraid (k : ℕ) (hk : k ≤ n) (a b : Fin (n + 1)) :
    crossMatrix (cycBraid n k) a b =
      if (a.val = 0 ∧ 0 < b.val ∧ b.val ≤ k) ∨ (b.val = 0 ∧ 0 < a.val ∧ a.val ≤ k) then 1
      else 0 := by
  induction k generalizing a b with
  | zero => simp [cycBraid, crossMatrix_one]; omega
  | succ k ih =>
    have hk' : k < n := by omega
    have hL : cycPerm n k (siteL (n := n + 1) ⟨k, hk'⟩) = 0 := by
      ext; rw [cycPerm_val k (by omega)]; simp [siteL]
    have hR : cycPerm n k (siteR (n := n + 1) ⟨k, hk'⟩) = ⟨k + 1, by omega⟩ := by
      ext; rw [cycPerm_val k (by omega)]; simp [siteR]
    rw [cycBraid, dif_pos hk', crossMatrix_mul, crossMatrix_sigma, permHom_cycBraid,
      crossE_relabel, hL, hR, ih (by omega)]
    unfold crossE
    simp only [Fin.ext_iff, Fin.val_zero]
    split_ifs <;> omega

theorem crossMatrix_delta (a b : Fin (n + 1)) :
    crossMatrix (cycBraid n n) a b = if a ≠ b ∧ (a = 0 ∨ b = 0) then 1 else 0 := by
  rw [crossMatrix_cycBraid n le_rfl]
  simp only [ne_eq, Fin.ext_iff, Fin.val_zero]
  have := a.isLt
  have := b.isLt
  split_ifs <;> omega

/-! ### The crossing matrix of `δ^q` -/

theorem crossMatrix_torusBraid (q : ℕ) (a b : Fin (n + 1)) :
    crossMatrix (torusBraid n q) a b =
      ∑ k ∈ range q, crossMatrix (cycBraid n n) (a - (k : Fin (n + 1))) (b - (k : Fin (n + 1))) := by
  induction q generalizing a b with
  | zero => simp [torusBraid, crossMatrix_one]
  | succ q ih =>
    rw [show torusBraid n (q + 1) = torusBraid n q * cycBraid n n from pow_succ _ _,
      crossMatrix_mul, ih, permHom_torusBraid, sum_range_succ]
    have hinv : ∀ x : Fin (n + 1), (Equiv.addRight (q : ZMod (n + 1)))⁻¹ x = x - (q : Fin (n + 1)) := by
      intro x
      rw [Perm.inv_def, Equiv.symm_apply_eq, Equiv.coe_addRight]
      exact (sub_add_cancel x _).symm
    exact congrArg _ (congrArg₂ (crossMatrix (cycBraid n n)) (hinv a) (hinv b))

/-- The number of `k < q` with `k ≡ x (mod p)`. -/
def residueCount (n q : ℕ) (x : Fin (n + 1)) : ℕ :=
  ((range q).filter fun k : ℕ => ((k : ℕ) : Fin (n + 1)) = x).card

theorem crossMatrix_torusBraid_of_ne (q : ℕ) {a b : Fin (n + 1)} (hab : a ≠ b) :
    crossMatrix (torusBraid n q) a b = residueCount n q a + residueCount n q b := by
  rw [crossMatrix_torusBraid]
  have : ∀ k : ℕ, crossMatrix (cycBraid n n) (a - (k : Fin (n + 1))) (b - (k : Fin (n + 1))) =
      (if (k : Fin (n + 1)) = a then 1 else 0) + (if (k : Fin (n + 1)) = b then 1 else 0) := by
    intro k
    rw [crossMatrix_delta]
    have h1 : (a - (k : Fin (n + 1)) = 0) ↔ (k : Fin (n + 1)) = a := by
      rw [sub_eq_zero, eq_comm]
    have h2 : (b - (k : Fin (n + 1)) = 0) ↔ (k : Fin (n + 1)) = b := by
      rw [sub_eq_zero, eq_comm]
    have h3 : (a - (k : Fin (n + 1)) ≠ b - (k : Fin (n + 1))) := fun h => hab (sub_left_inj.mp h)
    by_cases ha : (k : Fin (n + 1)) = a <;> by_cases hb : (k : Fin (n + 1)) = b
    · exact absurd (ha.symm.trans hb) hab
    · rw [if_pos ⟨h3, Or.inl (h1.mpr ha)⟩, if_pos ha, if_neg hb]; rfl
    · rw [if_pos ⟨h3, Or.inr (h2.mpr hb)⟩, if_neg ha, if_pos hb]; rfl
    · rw [if_neg (fun h => h.2.elim (fun h' => ha (h1.mp h')) (fun h' => hb (h2.mp h'))),
        if_neg ha, if_neg hb]; rfl
  simp only [this, sum_add_distrib, residueCount, card_filter]
  push_cast
  rfl

/-! ### Components of the closure -/

theorem card_range_filter_mod (m d r : ℕ) (hd : d ∣ m) (hr : r < d) :
    ((range m).filter (fun k => k % d = r)).card = m / d := by
  have h0 : 0 < d := by omega
  have := Nat.count_modEq_card m h0 r
  rw [Nat.count_eq_card_filter_range, Nat.mod_eq_zero_of_dvd hd] at this
  simp only [Nat.not_lt_zero, if_false, add_zero] at this
  rw [← this]
  congr 1
  ext k
  simp [Nat.ModEq, Nat.mod_eq_of_lt hr]

theorem zmod_shift_iff {p : ℕ} [NeZero p] (q : ℕ) (x y : ZMod p) :
    (∃ i : ℤ, x + i • (q : ZMod p) = y) ↔ ((Nat.gcd p q : ℕ) : ℤ) ∣ (y.val : ℤ) - x.val := by
  have hx : ((x.val : ℤ) : ZMod p) = x := by simp
  have hy : ((y.val : ℤ) : ZMod p) = y := by simp
  constructor
  · rintro ⟨i, hi⟩
    have h : (((x.val : ℤ) + i * q : ℤ) : ZMod p) = ((y.val : ℤ) : ZMod p) := by
      push_cast; rw [ZMod.natCast_zmod_val, ZMod.natCast_zmod_val, ← hi, zsmul_eq_mul]
    rw [ZMod.intCast_eq_intCast_iff_dvd_sub] at h
    have h1 : ((Nat.gcd p q : ℕ) : ℤ) ∣ (p : ℤ) := by exact_mod_cast Nat.gcd_dvd_left p q
    have h2 : ((Nat.gcd p q : ℕ) : ℤ) ∣ (q : ℤ) := by exact_mod_cast Nat.gcd_dvd_right p q
    have h3 := dvd_trans h1 h
    have h4 : ((Nat.gcd p q : ℕ) : ℤ) ∣ i * q := dvd_mul_of_dvd_right h2 i
    have := dvd_add h3 h4
    convert this using 1; ring
  · rintro ⟨m, hm⟩
    refine ⟨m * Nat.gcdB p q, ?_⟩
    rw [← hx, ← hy, zsmul_eq_mul]
    have hb := Nat.gcd_eq_gcd_ab p q
    rw [show ((m * Nat.gcdB p q : ℤ) : ZMod p) * (q : ZMod p) = (((m * Nat.gcdB p q * q : ℤ)) : ZMod p) by push_cast; ring,
      ← Int.cast_add, ZMod.intCast_eq_intCast_iff_dvd_sub]
    refine ⟨m * Nat.gcdA p q, ?_⟩
    have : (y.val : ℤ) = x.val + (Nat.gcd p q : ℤ) * m := by linarith
    rw [this, hb]; ring

/-- **Two strand labels lie on the same component of `T(p, q)` iff they agree modulo
`d = gcd(p, q)`.** -/
theorem sameCycle_torus_iff (q : ℕ) (x y : Fin (n + 1)) :
    (permHom (n + 1) (torusBraid n q)).SameCycle x y ↔
      x.val % Nat.gcd (n + 1) q = y.val % Nat.gcd (n + 1) q := by
  rw [permHom_torusBraid]
  unfold Perm.SameCycle
  simp only [addRight_zpow_apply]
  rw [zmod_shift_iff (p := n + 1) q x y, ← Nat.modEq_iff_dvd]
  rfl

theorem mem_closureComponent_torus (q : ℕ) (a x : Fin (n + 1)) :
    x ∈ closureComponent (torusBraid n q) a ↔
      x.val % Nat.gcd (n + 1) q = a.val % Nat.gcd (n + 1) q := by
  simp only [closureComponent, mem_filter, mem_univ, true_and, sameCycle_torus_iff]
  exact eq_comm

theorem gcd_pos_torus (q : ℕ) : 0 < Nat.gcd (n + 1) q := Nat.gcd_pos_of_pos_left _ (by omega)

/-- Each component of `T(p, q)` consists of `p/d` strand labels. -/
theorem card_closureComponent_torus (q : ℕ) (a : Fin (n + 1)) :
    (closureComponent (torusBraid n q) a).card = (n + 1) / Nat.gcd (n + 1) q := by
  set d := Nat.gcd (n + 1) q
  have hfilt : closureComponent (torusBraid n q) a = univ.filter fun x : Fin (n + 1) =>
      x.val % d = a.val % d := by
    ext x; rw [mem_closureComponent_torus]; simp [d]
  rw [hfilt, card_filter, Fin.sum_univ_eq_sum_range (fun k => if k % d = a.val % d then 1 else 0),
    ← card_filter]
  exact card_range_filter_mod _ _ _ (Nat.gcd_dvd_left _ _) (Nat.mod_lt _ (gcd_pos_torus q))

/-- Exactly `q/d` of the residues `0, 1, …, q-1` land on each component. -/
theorem sum_residueCount_closureComponent (q : ℕ) (a : Fin (n + 1)) :
    ∑ x ∈ closureComponent (torusBraid n q) a, residueCount n q x = q / Nat.gcd (n + 1) q := by
  set d := Nat.gcd (n + 1) q
  set C := closureComponent (torusBraid n q) a
  have hmaps : Set.MapsTo (fun k : ℕ => ((k : ℕ) : Fin (n + 1)))
      ↑((range q).filter fun k : ℕ => ((k : ℕ) : Fin (n + 1)) ∈ C) ↑C := by
    intro k hk
    simp only [coe_filter, Set.mem_setOf_eq] at hk
    exact hk.2
  have h1 := card_eq_sum_card_fiberwise hmaps
  have h2 : ∑ x ∈ C, residueCount n q x =
      ((range q).filter fun k : ℕ => ((k : ℕ) : Fin (n + 1)) ∈ C).card := by
    rw [h1]
    refine sum_congr rfl fun x hx => ?_
    unfold residueCount
    congr 1
    ext k
    simp only [mem_filter]
    constructor
    · rintro ⟨hk, rfl⟩; exact ⟨⟨hk, hx⟩, rfl⟩
    · rintro ⟨⟨hk, -⟩, h⟩; exact ⟨hk, h⟩
  rw [h2]
  have h3 : ((range q).filter fun k : ℕ => ((k : ℕ) : Fin (n + 1)) ∈ C) =
      (range q).filter fun k => k % d = a.val % d := by
    refine filter_congr fun k _ => ?_
    rw [mem_closureComponent_torus, Fin.val_natCast, Nat.mod_mod_of_dvd _ (Nat.gcd_dvd_left _ _)]
  rw [h3]
  exact card_range_filter_mod _ _ _ (Nat.gcd_dvd_right _ _) (Nat.mod_lt _ (gcd_pos_torus q))

/-! ### The linking numbers -/

/-- **Linking numbers of torus links.**  Any two distinct components of `T(p, q)` (`p = n + 1`,
`d = gcd(p, q)`) have linking number `(p/d)·(q/d)`. -/
theorem torusBraid_linkingNumber (q : ℕ) {a b : Fin (n + 1)}
    (hab : a.val % Nat.gcd (n + 1) q ≠ b.val % Nat.gcd (n + 1) q) :
    linkingNumber (torusBraid n q) (closureComponent (torusBraid n q) a)
        (closureComponent (torusBraid n q) b) =
      (((n + 1) / Nat.gcd (n + 1) q * (q / Nat.gcd (n + 1) q) : ℕ) : ℤ) := by
  set g := torusBraid n q
  set C := closureComponent g a
  set D := closureComponent g b
  have h2 := two_mul_linkingNumber g (closureComponent_invariant g a) (closureComponent_invariant g b)
  have hblock : blockSum (crossMatrix g) C D =
      (D.card : ℤ) * ∑ x ∈ C, (residueCount n q x : ℤ) +
        (C.card : ℤ) * ∑ y ∈ D, (residueCount n q y : ℤ) := by
    unfold blockSum
    have : ∀ x ∈ C, ∑ y ∈ D, crossMatrix g x y =
        ∑ y ∈ D, ((residueCount n q x : ℤ) + residueCount n q y) := by
      intro x hx
      refine sum_congr rfl fun y hy => ?_
      rw [crossMatrix_torusBraid_of_ne]
      rintro rfl
      exact hab (((mem_closureComponent_torus q a x).mp hx).symm.trans
        ((mem_closureComponent_torus q b x).mp hy))
    rw [sum_congr rfl this]
    simp only [sum_add_distrib, sum_const, nsmul_eq_mul, ← mul_sum]
  rw [hblock, card_closureComponent_torus, card_closureComponent_torus] at h2
  have e1 := sum_residueCount_closureComponent q a
  have e2 := sum_residueCount_closureComponent q b
  have e1' : ∑ x ∈ C, (residueCount n q x : ℤ) = ((q / Nat.gcd (n + 1) q : ℕ) : ℤ) := by
    rw [← e1]; push_cast; rfl
  have e2' : ∑ x ∈ D, (residueCount n q x : ℤ) = ((q / Nat.gcd (n + 1) q : ℕ) : ℤ) := by
    rw [← e2]; push_cast; rfl
  rw [e1', e2'] at h2
  rw [Nat.cast_mul]
  linarith

/-- Components through labels with the same residue mod `d` coincide. -/
theorem closureComponent_torus_eq (q : ℕ) {a b : Fin (n + 1)}
    (h : a.val % Nat.gcd (n + 1) q = b.val % Nat.gcd (n + 1) q) :
    closureComponent (torusBraid n q) a = closureComponent (torusBraid n q) b := by
  ext x
  rw [mem_closureComponent_torus, mem_closureComponent_torus, h]

/-- **Every linking number of `T(p, q)` between distinct components is `(p/d)(q/d)`.** -/
theorem torusBraid_linkingSpectrum (q : ℕ) :
    ∀ z ∈ linkingSpectrum (torusBraid n q),
      z = (((n + 1) / Nat.gcd (n + 1) q * (q / Nat.gcd (n + 1) q) : ℕ) : ℤ) := by
  intro z hz
  simp only [linkingSpectrum, Multiset.mem_map, mem_val, mem_offDiag] at hz
  obtain ⟨⟨C, D⟩, ⟨hC, hD, hCD⟩, rfl⟩ := hz
  obtain ⟨a, -, rfl⟩ := mem_image.mp hC
  obtain ⟨b, -, rfl⟩ := mem_image.mp hD
  exact torusBraid_linkingNumber q fun h => hCD (closureComponent_torus_eq q h)

/-! Examples of the formula: the Hopf link `T(2, 2)` has linking number `1`; the two components
of `T(4, 6)` have linking number `6`. -/
example : ((2 : ℕ) / Nat.gcd 2 2 * (2 / Nat.gcd 2 2) : ℕ) = 1 := by decide
example : ((4 : ℕ) / Nat.gcd 4 6 * (6 / Nat.gcd 4 6) : ℕ) = 6 := by decide

end QBX.Formal.Connections
