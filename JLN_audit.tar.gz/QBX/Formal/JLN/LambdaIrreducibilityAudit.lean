module

public import Mathlib

@[expose] public section

/-!
# Audit of the Lambda Irreducibility Theorem (Riemann Hypothesis paper, Thm. 1.6.1)

Source: J. L. Nielsen's Riemann Hypothesis paper, Definitions 1.4.3, 1.5.3, 1.5.4 and Theorem
1.6.1 (see `todo.md`).  Two paradigms `L` (linear) and `C` (curved) each come with a class of
models; a *translation pair* `(T_{L→C}, T_{C→L})` gives round-trip operators
`R_L = T_{C→L} ∘ T_{L→C}` and `R_C = T_{L→C} ∘ T_{C→L}`.  The paper defines

* the **Λ-obstruction** `Λ_P(S) := S_P △ R_P(S)_P`, the models of paradigm `P` on which `S` and
  its round trip disagree (Def. 1.5.3);
* `S` is **Λ-irreducible** if `Λ_L(S) ≠ ∅` and `Λ_C(T_{L→C}(S)) ≠ ∅` (Def. 1.5.4);

and claims (Thm. 1.6.1): *if `S` is Λ-irreducible then `ZFC ⊬ S` and `ZFC ⊬ ¬S`.*

Everything is stated for an arbitrary *satisfaction system* — a type of sentences, a type of
models and a satisfaction relation `sat` — and then instantiated with Mathlib's first-order logic
(`FO.*`).  Provability over a theory is modelled semantically, as truth in all its models; for
first-order theories this is equivalent to derivability by Gödel's completeness theorem (cited,
not formalised here).

## Results

* `obstruction_eq_symmDiff`: `obstruction` is Def. 1.5.3 verbatim (`S_P △ R_P(S)_P`).
* **What the argument actually proves** (`obstruction_eq_empty_of_provable`,
  `independent_of_irreducible`): *if the round trip `R_L` sends sentences valid on the
  `L`-paradigm to valid ones, and refuted ones to refuted ones*, then Λ-irreducibility gives
  independence.  This is a hypothesis about the **translation pair**, not about ZFC.
* **Vacuity for sound pairs** (`not_irreducible_of_sound`): if the pair is semantically
  round-trip sound on the `L`-paradigm (the condition the paper derives for any translation that a
  ZFC proof would "induce"), then *no* sentence is Λ-irreducible.  So on the paper's own reading
  the hypothesis of Thm. 1.6.1 can be satisfied only by pairs the proof does not talk about.
* **The theorem is false as stated** (`irreducible_idNeg`, `lambdaIrreducibility_false`): for the
  pair `(id, ¬)` *every* sentence is Λ-irreducible as soon as both paradigms have a model, provable
  sentences included.  `FO.lambdaIrreducibility_false` instantiates this for every first-order
  theory with a model (in particular for ZFC, if ZFC is consistent).
* **Irreducibility is a property of the pair, not of the sentence**
  (`irreducibility_depends_on_pair`): the same provable sentence is Λ-irreducible for one pair
  and not for another (the identity pair), while provability does not mention any pair.
* **ZFC needs no translation** (`provable_of_equiv`, `FO.provable_and_irreducible`): if the
  theory proves `S_C` and proves `S_L ↔ S_C`, it proves `S_L` directly — and this is compatible
  with `S_L` being Λ-irreducible for some pair.  This is the critique's main point: RH_L and RH_C
  are both sentences of the one theory, and their equivalence is a theorem of that theory.
* **Condition (3) of Def. 1.4.3 is empty for syntactic translations**
  (`FO.roundTrip_elementary_invariant`): truth of *any* sentence, in particular of `R(S)` for any
  map `R` on sentences, is preserved by elementary embeddings.
-/

namespace QBX.Formal.JLN.LambdaIrreducibility

section Abstract

variable {Sen Mod : Type*} (sat : Mod → Sen → Prop)

/-- The models of `S` in the paradigm `P`, `S_P`. -/
def modelsOf (P : Set Mod) (S : Sen) : Set Mod := {M | M ∈ P ∧ sat M S}

/-- **Definition 1.5.3.**  The Λ-obstruction: models of `P` on which exactly one of `S`, `R S`
holds. -/
def obstruction (P : Set Mod) (R : Sen → Sen) (S : Sen) : Set Mod :=
  {M | M ∈ P ∧ ¬ (sat M S ↔ sat M (R S))}

theorem obstruction_eq_symmDiff (P : Set Mod) (R : Sen → Sen) (S : Sen) :
    obstruction sat P R S = symmDiff (modelsOf sat P S) (modelsOf sat P (R S)) := by
  ext M
  simp only [obstruction, modelsOf, Set.mem_symmDiff, Set.mem_setOf_eq]
  tauto

/-- A translation pair `(T_{L→C}, T_{C→L})`. -/
structure TranslationPair (Sen : Type*) where
  /-- `T_{L→C}`. -/
  toC : Sen → Sen
  /-- `T_{C→L}`. -/
  toL : Sen → Sen

namespace TranslationPair

/-- `R_L = T_{C→L} ∘ T_{L→C}`. -/
def roundL (τ : TranslationPair Sen) : Sen → Sen := τ.toL ∘ τ.toC

/-- `R_C = T_{L→C} ∘ T_{C→L}`. -/
def roundC (τ : TranslationPair Sen) : Sen → Sen := τ.toC ∘ τ.toL

/-- The identity pair. -/
def id : TranslationPair Sen := ⟨fun S => S, fun S => S⟩

end TranslationPair

/-- **Definition 1.5.4.**  `S` is Λ-irreducible for the pair `τ`. -/
def IsIrreducible (PL PC : Set Mod) (τ : TranslationPair Sen) (S : Sen) : Prop :=
  (obstruction sat PL τ.roundL S).Nonempty ∧ (obstruction sat PC τ.roundC (τ.toC S)).Nonempty

/-- `S` is provable over the theory whose models are `Th` (semantically). -/
def Provable (Th : Set Mod) (S : Sen) : Prop := ∀ M ∈ Th, sat M S

/-- `S` is refutable over the theory whose models are `Th` (semantically). -/
def Refutable (Th : Set Mod) (S : Sen) : Prop := ∀ M ∈ Th, ¬ sat M S

/-- **Theorem 1.6.1, as stated**: every Λ-irreducible sentence (for every translation pair) is
neither provable nor refutable. -/
def LambdaIrreducibilityStatement (Th PL PC : Set Mod) : Prop :=
  ∀ (τ : TranslationPair Sen) (S : Sen), IsIrreducible sat PL PC τ S →
    ¬ Provable sat Th S ∧ ¬ Refutable sat Th S

/-- Semantic round-trip soundness of a pair on the `L`-paradigm: `R_L` preserves truth in every
model of `PL`. -/
def RoundTripSoundL (PL : Set Mod) (τ : TranslationPair Sen) : Prop :=
  ∀ M ∈ PL, ∀ S, sat M (τ.roundL S) ↔ sat M S

/-! #### What the argument proves: a theorem about the pair -/

/-- If `R` sends `P`-valid sentences to `P`-valid ones and `P` consists of models of the theory,
a provable sentence has empty obstruction. -/
theorem obstruction_eq_empty_of_provable {Th P : Set Mod} (hP : P ⊆ Th) {R : Sen → Sen} {S : Sen}
    (hR : (∀ M ∈ P, sat M S) → ∀ M ∈ P, sat M (R S)) (hS : Provable sat Th S) :
    obstruction sat P R S = ∅ := by
  have hRS := hR fun M hM => hS M (hP hM)
  ext M
  simp only [obstruction, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false, not_and, not_not]
  exact fun hM => iff_of_true (hS M (hP hM)) (hRS M hM)

/-- If `R` sends `P`-refuted sentences to `P`-refuted ones, a refutable sentence has empty
obstruction. -/
theorem obstruction_eq_empty_of_refutable {Th P : Set Mod} (hP : P ⊆ Th) {R : Sen → Sen} {S : Sen}
    (hR : (∀ M ∈ P, ¬ sat M S) → ∀ M ∈ P, ¬ sat M (R S)) (hS : Refutable sat Th S) :
    obstruction sat P R S = ∅ := by
  have hRS := hR fun M hM => hS M (hP hM)
  ext M
  simp only [obstruction, Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false, not_and, not_not]
  exact fun hM => iff_of_false (hS M (hP hM)) (hRS M hM)

/-- **The correct, relative form of Theorem 1.6.1.**  If the round trip `R_L` preserves validity
and refutation on the `L`-paradigm (which consists of models of the theory), then a sentence with
nonempty `L`-obstruction — in particular a Λ-irreducible one — is independent.  The hypotheses
`hval`, `href` are properties of the chosen translation pair; nothing about provability in the
theory forces them. -/
theorem independent_of_irreducible {Th PL PC : Set Mod} (hPL : PL ⊆ Th)
    {τ : TranslationPair Sen} {S : Sen}
    (hval : (∀ M ∈ PL, sat M S) → ∀ M ∈ PL, sat M (τ.roundL S))
    (href : (∀ M ∈ PL, ¬ sat M S) → ∀ M ∈ PL, ¬ sat M (τ.roundL S))
    (h : IsIrreducible sat PL PC τ S) :
    ¬ Provable sat Th S ∧ ¬ Refutable sat Th S := by
  obtain ⟨⟨M, hM⟩, -⟩ := h
  refine ⟨fun hS => ?_, fun hS => ?_⟩
  · rw [obstruction_eq_empty_of_provable sat hPL hval hS] at hM; exact hM
  · rw [obstruction_eq_empty_of_refutable sat hPL href hS] at hM; exact hM

/-- **Vacuity for sound pairs**: a round-trip-sound pair admits no Λ-irreducible sentence. -/
theorem not_irreducible_of_sound {PL PC : Set Mod} {τ : TranslationPair Sen}
    (hτ : RoundTripSoundL sat PL τ) (S : Sen) : ¬ IsIrreducible sat PL PC τ S := by
  rintro ⟨⟨M, hM, hne⟩, -⟩
  exact hne (hτ M hM S).symm

theorem roundTripSoundL_id (PL : Set Mod) : RoundTripSoundL sat PL (TranslationPair.id (Sen := Sen)) :=
  fun _ _ _ => Iff.rfl

/-! #### The statement as given is false -/

variable {sat}

/-- The pair `(id, ¬)`, for a negation `neg` on sentences. -/
def idNeg (neg : Sen → Sen) : TranslationPair Sen := ⟨fun S => S, neg⟩

/-- For the pair `(id, ¬)` **every** sentence is Λ-irreducible once both paradigms have a model. -/
theorem irreducible_idNeg {neg : Sen → Sen} (hneg : ∀ M S, sat M (neg S) ↔ ¬ sat M S)
    {PL PC : Set Mod} (hL : PL.Nonempty) (hC : PC.Nonempty) (S : Sen) :
    IsIrreducible sat PL PC (idNeg neg) S := by
  obtain ⟨M, hM⟩ := hL
  obtain ⟨N, hN⟩ := hC
  refine ⟨⟨M, hM, ?_⟩, ⟨N, hN, ?_⟩⟩ <;>
    simp [TranslationPair.roundL, TranslationPair.roundC, idNeg, hneg]

/-- **Theorem 1.6.1 is false as stated**: in any satisfaction system with a negation, if the
theory proves some sentence and both paradigms have a model, the statement fails. -/
theorem lambdaIrreducibility_false {neg : Sen → Sen} (hneg : ∀ M S, sat M (neg S) ↔ ¬ sat M S)
    {Th PL PC : Set Mod} (hL : PL.Nonempty) (hC : PC.Nonempty) {S₀ : Sen}
    (hS₀ : Provable sat Th S₀) :
    ¬ LambdaIrreducibilityStatement sat Th PL PC :=
  fun h => (h (idNeg neg) S₀ (irreducible_idNeg hneg hL hC S₀)).1 hS₀

/-- **Irreducibility depends on the pair**: every sentence is Λ-irreducible for `(id, ¬)` and
not Λ-irreducible for the identity pair. -/
theorem irreducibility_depends_on_pair {neg : Sen → Sen} (hneg : ∀ M S, sat M (neg S) ↔ ¬ sat M S)
    {PL PC : Set Mod} (hL : PL.Nonempty) (hC : PC.Nonempty) (S : Sen) :
    IsIrreducible sat PL PC (idNeg neg) S ∧ ¬ IsIrreducible sat PL PC TranslationPair.id S :=
  ⟨irreducible_idNeg hneg hL hC S, not_irreducible_of_sound sat (roundTripSoundL_id sat PL) S⟩

/-- **No translation is needed**: if the theory proves `S_C` and proves `S_L ↔ S_C`, it proves
`S_L`. -/
theorem provable_of_equiv {Th : Set Mod} {SL SC : Sen} (hC : Provable sat Th SC)
    (hLC : ∀ M ∈ Th, sat M SL ↔ sat M SC) : Provable sat Th SL :=
  fun M hM => (hLC M hM).mpr (hC M hM)

end Abstract

/-! ### Instantiation: first-order logic -/

namespace FO

open FirstOrder FirstOrder.Language

universe u v w

variable {L : FirstOrder.Language.{u, v}} (T : L.Theory)

/-- Satisfaction of a sentence in a model of `T`. -/
def foSat (M : Theory.ModelType.{u, v, w} T) (φ : L.Sentence) : Prop := M ⊨ φ

theorem sat_not (M : Theory.ModelType.{u, v, w} T) (φ : L.Sentence) :
    foSat T M φ.not ↔ ¬ foSat T M φ :=
  Sentence.realize_not M

/-- The tautology `⊤ → ⊤`, true in every structure. -/
def taut : L.Sentence := (⊤ : L.Sentence).imp ⊤

theorem sat_taut (M : Theory.ModelType.{u, v, w} T) : foSat T M taut := fun h => h

/-- **Theorem 1.6.1 fails for every consistent first-order theory** (taking both paradigms to be
all models): the tautology `⊤ → ⊤` is provable and Λ-irreducible for the pair `(id, ¬)`. -/
theorem lambdaIrreducibility_false [h : Nonempty (Theory.ModelType.{u, v, w} T)] :
    ¬ LambdaIrreducibilityStatement (foSat.{u, v, w} T) Set.univ Set.univ Set.univ := by
  obtain ⟨M⟩ := h
  exact LambdaIrreducibility.lambdaIrreducibility_false (sat_not T) ⟨M, Set.mem_univ M⟩ ⟨M, Set.mem_univ M⟩
    (S₀ := taut) fun M _ => sat_taut T M

/-- A theory may prove `S_L` directly, through `S_L ↔ S_C` and `S_C`, while `S_L` is
Λ-irreducible for some translation pair. -/
theorem provable_and_irreducible [h : Nonempty (Theory.ModelType.{u, v, w} T)] {SL SC : L.Sentence}
    (hC : Provable (foSat.{u, v, w} T) Set.univ SC) (hLC : ∀ M : Theory.ModelType.{u, v, w} T, foSat T M SL ↔ foSat T M SC) :
    Provable (foSat.{u, v, w} T) Set.univ SL ∧
      IsIrreducible (foSat.{u, v, w} T) Set.univ Set.univ (idNeg Formula.not) SL := by
  obtain ⟨M⟩ := h
  exact ⟨provable_of_equiv hC fun M _ => hLC M,
    irreducible_idNeg (sat_not T) ⟨M, Set.mem_univ M⟩ ⟨M, Set.mem_univ M⟩ SL⟩

/-- **Condition (3) of Def. 1.4.3 is automatic**: for *any* map `R` on sentences, the truth of
`R S` is invariant under elementary embeddings. -/
theorem roundTrip_elementary_invariant {M N : Type*} [L.Structure M] [L.Structure N]
    (f : M ↪ₑ[L] N) (R : L.Sentence → L.Sentence) (S : L.Sentence) :
    (M ⊨ R S ↔ N ⊨ R S) ∧ (M ⊨ S ↔ N ⊨ S) :=
  ⟨f.map_sentence (R S), f.map_sentence S⟩

end FO

end QBX.Formal.JLN.LambdaIrreducibility
