module

public import Mathlib

@[expose] public section

/-!
# Audit of the `Λ⁺⁺` invariant (Yang–Mills paper, Def. 4.19)

Source: J. L. Nielsen's Yang–Mills paper, Definition 4.19, Theorem 6.11 and the "Path 1" chain
(see `todo.md`).  For a family of admissible encodings `E`, a generating set of loops `Γ`, loop
holonomies `H_{γ,E} ∈ G`, a conjugation-invariant defect functional `Δ` and a local defect scale
`τ(a) > 0` (with `τ(a) ∼ a⁴`), the paper defines

  `Λ⁺⁺(a) := inf_E sup_γ Δ(H_{γ,E}) / τ(a)`

and claims `Λ⁺⁺(a) ≥ ε(G) > 0` uniformly for small `a`.

## What is checked here

* `lambdaPP` is Definition 4.19, verbatim, for an arbitrary group `G`.
* **The correct part** (`worstDefect_conj`, `lambdaPP_gauge_orbit`): since `Δ` is
  conjugation-invariant, a re-encoding that acts on the loop holonomies by conjugation (a gauge
  transformation) cannot change the worst-case normalised defect.  On a single gauge orbit the
  infimum over encodings is attained by every encoding.  So "no admissible encoding can flatten the
  holonomy" holds for gauge re-encodings, and it holds trivially.
* **The gap** — uniformity in `a` is the whole content, and it is a statement about the coupling.
  In the one-plaquette `SU(2)` model (`modelLambda`), the plaquette holonomy at lattice scale `a`
  and effective coupling `κ` is the torus element `diag(e^{i a²κ}, e^{-i a²κ})`, the defect is the
  paper's `Δ(U) = 1 - ½ Re tr U` (`su2Defect`, conjugation-invariant by `su2Defect_conj`), the
  encodings are all `SU(2)` gauge transformations, and `τ(a) = a⁴`.  Then
  (`modelLambda_eq`) `Λ⁺⁺(a) = (1 - cos(a²κ)) / a⁴`, and
  - `modelLambda_le`: `Λ⁺⁺(a) ≤ κ² / 2`;
  - `modelLambda_ge`: `Λ⁺⁺(a) ≥ (2/π²) κ²` as long as `a²|κ| ≤ π`.

  So `Λ⁺⁺(a)` is pinned between two constant multiples of `κ(a)²`:
  - `uniform_bound_iff`: **a uniform bound `Λ⁺⁺(a) ≥ ε > 0` for `a ∈ (0, a₀)` holds iff the
    effective coupling is bounded away from zero on `(0, a₀)`**;
  - `modelLambda_tendsto_zero`, `no_uniform_bound_of_tendsto_zero`: if the coupling runs to zero
    as `a → 0⁺` (asymptotic freedom), then `Λ⁺⁺(a) → 0` and **no `ε(G) > 0` exists**;
  - `runningCoupling`, `no_uniform_bound_running`: the one-loop running form
    `κ(a)² = 1 / log(1/a)` is such a coupling.

  Every ingredient of Definition 4.19 is present in this model (non-Abelian `G = SU(2)`, a
  conjugation-invariant defect built from a faithful representation, `τ(a) = a⁴`, an infimum over a
  nontrivial class of encodings).  Positivity of `Λ⁺⁺` uniformly in `a` is therefore **not** a
  structural consequence of the definition: it is equivalent to the coupling not running to zero,
  which is exactly the input the paper assumes ("fixed `μ_a`") rather than derives.

  `modelLambda_const_pos` records the other side: at *fixed* coupling `κ ≠ 0` the bound does hold,
  `Λ⁺⁺(a) ≥ 2κ²/π²` for all small `a`, which is the regime the paper's argument actually treats.
-/

namespace QBX.Formal.JLN.LambdaPlusPlus

open Real Filter Topology

/-! ### Definition 4.19 for an arbitrary group -/

section Abstract

variable {G : Type*} [Group G]

/-- A defect functional on `G` is conjugation-invariant. -/
def ConjInvariant (Δ : G → ℝ) : Prop := ∀ g h : G, Δ (h * g * h⁻¹) = Δ g

/-- **Definition 4.19.**  `Λ⁺⁺ := inf_E sup_γ Δ(H_{γ,E}) / τ`, for holonomies `hol E γ`. -/
noncomputable def lambdaPP {E Γ : Type*} (hol : E → Γ → G) (Δ : G → ℝ) (τ : ℝ) : ℝ :=
  ⨅ e : E, ⨆ γ : Γ, Δ (hol e γ) / τ

/-- The worst-case normalised defect of one encoding is unchanged when every loop holonomy is
conjugated (by a loop-dependent element): a gauge re-encoding cannot flatten the holonomy. -/
theorem worstDefect_conj {Γ : Type*} {Δ : G → ℝ} (hΔ : ConjInvariant Δ) (τ : ℝ)
    (hol hol' : Γ → G) (c : Γ → G) (h : ∀ γ, hol' γ = c γ * hol γ * (c γ)⁻¹) :
    (⨆ γ, Δ (hol' γ) / τ) = ⨆ γ, Δ (hol γ) / τ := by
  congr 1
  funext γ
  rw [h, hΔ]

/-- **On a gauge orbit the infimum over encodings is trivial**: if every encoding's holonomies are
loopwise conjugate to those of a reference encoding `hol₀`, then `Λ⁺⁺` is the worst normalised
defect of `hol₀`. -/
theorem lambdaPP_gauge_orbit {E Γ : Type*} [Nonempty E] {Δ : G → ℝ} (hΔ : ConjInvariant Δ)
    (τ : ℝ) (hol : E → Γ → G) (hol₀ : Γ → G)
    (h : ∀ e, ∃ c : Γ → G, ∀ γ, hol e γ = c γ * hol₀ γ * (c γ)⁻¹) :
    lambdaPP hol Δ τ = ⨆ γ, Δ (hol₀ γ) / τ := by
  unfold lambdaPP
  have : ∀ e, (⨆ γ, Δ (hol e γ) / τ) = ⨆ γ, Δ (hol₀ γ) / τ := fun e => by
    obtain ⟨c, hc⟩ := h e
    exact worstDefect_conj hΔ τ hol₀ (hol e) c hc
  simp only [this, ciInf_const]

end Abstract

/-! ### The paper's defect functional on `SU(2)` -/

/-- The group `SU(2)`. -/
abbrev SU2 := Matrix.specialUnitaryGroup (Fin 2) ℂ

/-- The defect functional `Δ(U) = 1 - ½ Re tr U` of the fundamental (faithful) representation. -/
noncomputable def su2Defect (U : SU2) : ℝ := 1 - (Matrix.trace (U : Matrix (Fin 2) (Fin 2) ℂ)).re / 2

/-- `Δ` is conjugation-invariant. -/
theorem su2Defect_conj : ConjInvariant su2Defect := by
  intro g h
  unfold su2Defect
  congr 3
  have hinv : ((h⁻¹ : SU2) : Matrix (Fin 2) (Fin 2) ℂ) * (h : Matrix (Fin 2) (Fin 2) ℂ) = 1 := by
    rw [← Submonoid.coe_mul, inv_mul_cancel]; rfl
  simp only [Submonoid.coe_mul]
  rw [Matrix.trace_mul_cycle, hinv, Matrix.one_mul]

/-- The torus element `diag(e^{iθ}, e^{-iθ})`. -/
noncomputable def torusMat (θ : ℝ) : Matrix (Fin 2) (Fin 2) ℂ :=
  !![Complex.exp (θ * Complex.I), 0; 0, Complex.exp (-(θ * Complex.I))]

theorem torusMat_mem (θ : ℝ) : torusMat θ ∈ Matrix.specialUnitaryGroup (Fin 2) ℂ := by
  rw [Matrix.mem_specialUnitaryGroup_iff, Matrix.mem_unitaryGroup_iff]
  have hs : (starRingEnd ℂ) (Complex.exp (θ * Complex.I)) = Complex.exp (-(θ * Complex.I)) := by
    rw [← Complex.exp_conj]; congr 1; simp [Complex.conj_ofReal]
  have hs' : (starRingEnd ℂ) (Complex.exp (-(θ * Complex.I))) = Complex.exp (θ * Complex.I) := by
    rw [← Complex.exp_conj]; congr 1; simp [Complex.conj_ofReal]
  refine ⟨?_, ?_⟩
  · ext i j
    fin_cases i <;> fin_cases j <;>
      simp [torusMat, Matrix.mul_apply, Matrix.star_apply, Fin.sum_univ_two, hs, hs',
        ← Complex.exp_add]
  · simp [torusMat, Matrix.det_fin_two, ← Complex.exp_add]

/-- The torus element as an element of `SU(2)`. -/
noncomputable def torus (θ : ℝ) : SU2 := ⟨torusMat θ, torusMat_mem θ⟩

theorem su2Defect_torus (θ : ℝ) : su2Defect (torus θ) = 1 - Real.cos θ := by
  unfold su2Defect torus
  simp only [torusMat, Matrix.trace_fin_two, Matrix.of_apply, Matrix.cons_val',
    Matrix.cons_val_zero, Matrix.cons_val_one, Matrix.empty_val', Matrix.cons_val_fin_one,
    Complex.add_re]
  rw [Complex.exp_ofReal_mul_I_re, show -(↑θ * Complex.I) = ↑(-θ) * Complex.I by push_cast; ring,
    Complex.exp_ofReal_mul_I_re, Real.cos_neg]
  ring

/-! ### The one-plaquette weak-coupling model -/

/-- The one-plaquette model at lattice scale `a` and effective coupling `κ`: the encodings are all
`SU(2)` gauge transformations `e`, there is one loop (the plaquette), its holonomy is
`e · diag(e^{i a²κ}, e^{-i a²κ}) · e⁻¹`, and `τ(a) = a⁴`. -/
noncomputable def modelLambda (κ a : ℝ) : ℝ :=
  lambdaPP (fun (e : SU2) (_ : Unit) => e * torus (a ^ 2 * κ) * e⁻¹) su2Defect (a ^ 4)

theorem modelLambda_eq (κ a : ℝ) : modelLambda κ a = (1 - Real.cos (a ^ 2 * κ)) / a ^ 4 := by
  unfold modelLambda
  rw [lambdaPP_gauge_orbit su2Defect_conj _ _ (fun _ => torus (a ^ 2 * κ))
    (fun e => ⟨fun _ => e, fun _ => rfl⟩)]
  simp [su2Defect_torus]

/-- Upper bound: `Λ⁺⁺(a) ≤ κ² / 2`. -/
theorem modelLambda_le (κ : ℝ) {a : ℝ} (ha : a ≠ 0) : modelLambda κ a ≤ κ ^ 2 / 2 := by
  rw [modelLambda_eq, div_le_iff₀ (by positivity)]
  have := Real.one_sub_sq_div_two_le_cos (x := a ^ 2 * κ)
  nlinarith

/-- Lower bound: `Λ⁺⁺(a) ≥ (2/π²) κ²` while `a²|κ| ≤ π`. -/
theorem modelLambda_ge (κ : ℝ) {a : ℝ} (ha : a ≠ 0) (h : a ^ 2 * |κ| ≤ π) :
    2 / π ^ 2 * κ ^ 2 ≤ modelLambda κ a := by
  rw [modelLambda_eq, le_div_iff₀ (by positivity)]
  have habs : |a ^ 2 * κ| ≤ π := by rw [abs_mul, abs_of_nonneg (by positivity)]; exact h
  have := Real.cos_le_one_sub_mul_cos_sq habs
  have e : 2 / π ^ 2 * κ ^ 2 * a ^ 4 = 2 / π ^ 2 * (a ^ 2 * κ) ^ 2 := by ring
  linarith

theorem modelLambda_nonneg (κ a : ℝ) : 0 ≤ modelLambda κ a := by
  rw [modelLambda_eq]
  exact div_nonneg (by linarith [Real.cos_le_one (a ^ 2 * κ)]) (by positivity)

/-- At *fixed* coupling `κ ≠ 0` the uniform bound holds: `Λ⁺⁺(a) ≥ 2κ²/π²` for `0 < a ≤ 1`
once `|κ| ≤ π`.  (This is the regime the paper's argument treats.) -/
theorem modelLambda_const_pos {κ : ℝ} (hκ : κ ≠ 0) (hκπ : |κ| ≤ π) :
    ∃ ε > 0, ∀ a, 0 < a → a ≤ 1 → ε ≤ modelLambda κ a := by
  refine ⟨2 / π ^ 2 * κ ^ 2, by positivity, fun a ha ha1 => modelLambda_ge κ ha.ne' ?_⟩
  have : a ^ 2 ≤ 1 := by nlinarith
  nlinarith [abs_nonneg κ]

/-- **A uniform positive lower bound on `Λ⁺⁺` is equivalent to the coupling being bounded away
from zero** (on a range of scales where `a²|κ(a)| ≤ π`, i.e. the plaquette angle has not wrapped). -/
theorem uniform_bound_iff (κ : ℝ → ℝ) {a₀ : ℝ}
    (hwrap : ∀ a, 0 < a → a < a₀ → a ^ 2 * |κ a| ≤ π) :
    (∃ ε > 0, ∀ a, 0 < a → a < a₀ → ε ≤ modelLambda (κ a) a) ↔
      (∃ c > 0, ∀ a, 0 < a → a < a₀ → c ≤ |κ a|) := by
  constructor
  · rintro ⟨ε, hε, h⟩
    refine ⟨Real.sqrt (2 * ε), by positivity, fun a ha ha₀ => ?_⟩
    have h1 := h a ha ha₀
    have h2 := modelLambda_le (κ a) ha.ne'
    rw [← Real.sqrt_sq_eq_abs]
    exact Real.sqrt_le_sqrt (by linarith)
  · rintro ⟨c, hc, h⟩
    refine ⟨2 / π ^ 2 * c ^ 2, by positivity, fun a ha ha₀ => ?_⟩
    refine le_trans ?_ (modelLambda_ge (κ a) ha.ne' (hwrap a ha ha₀))
    have : c ^ 2 ≤ κ a ^ 2 := by
      rw [← sq_abs (κ a)]; exact pow_le_pow_left₀ hc.le (h a ha ha₀) 2
    gcongr

/-- **Asymptotic freedom kills the bound**: if the coupling runs to zero as `a → 0⁺`, then
`Λ⁺⁺(a) → 0`. -/
theorem modelLambda_tendsto_zero {κ : ℝ → ℝ} (hκ : Tendsto κ (𝓝[>] 0) (𝓝 0)) :
    Tendsto (fun a => modelLambda (κ a) a) (𝓝[>] 0) (𝓝 0) := by
  have hup : Tendsto (fun a => κ a ^ 2 / 2) (𝓝[>] 0) (𝓝 0) := by
    simpa using (hκ.pow 2).div_const 2
  refine tendsto_of_tendsto_of_tendsto_of_le_of_le' tendsto_const_nhds hup ?_ ?_
  · exact Eventually.of_forall fun a => modelLambda_nonneg _ _
  · filter_upwards [self_mem_nhdsWithin] with a (ha : 0 < a)
    exact modelLambda_le _ ha.ne'

/-- Consequently **no `ε(G) > 0` bounds `Λ⁺⁺(a)` from below for small `a`** when the coupling runs
to zero. -/
theorem no_uniform_bound_of_tendsto_zero {κ : ℝ → ℝ} (hκ : Tendsto κ (𝓝[>] 0) (𝓝 0)) :
    ¬ ∃ ε > 0, ∀ᶠ a in 𝓝[>] 0, ε ≤ modelLambda (κ a) a := by
  rintro ⟨ε, hε, h⟩
  have h2 := (modelLambda_tendsto_zero hκ).eventually (gt_mem_nhds hε)
  have hne : (𝓝[>] (0 : ℝ)).NeBot := inferInstance
  obtain ⟨a, h1, h3⟩ := (h.and h2).exists
  linarith

/-- The one-loop running coupling, `κ(a)² = 1 / log(1/a)`. -/
noncomputable def runningCoupling (a : ℝ) : ℝ := Real.sqrt (Real.log a⁻¹)⁻¹

theorem runningCoupling_tendsto : Tendsto runningCoupling (𝓝[>] 0) (𝓝 0) := by
  have h1 : Tendsto (fun a : ℝ => Real.log a⁻¹) (𝓝[>] 0) atTop :=
    Real.tendsto_log_atTop.comp tendsto_inv_nhdsGT_zero
  have h2 := (h1.inv_tendsto_atTop).sqrt
  rw [Real.sqrt_zero] at h2
  exact h2

/-- With the one-loop running coupling, `Λ⁺⁺(a) → 0`: there is no uniform `ε(G) > 0`. -/
theorem no_uniform_bound_running :
    ¬ ∃ ε > 0, ∀ᶠ a in 𝓝[>] 0, ε ≤ modelLambda (runningCoupling a) a :=
  no_uniform_bound_of_tendsto_zero runningCoupling_tendsto

end QBX.Formal.JLN.LambdaPlusPlus
