module

public import QBX.Formal.Connections.QuaternionHopf
public import QBX.Formal.Connections.CayleyDicksonHopf
public import QBX.Formal.Connections.HypercubeTorusGray
public import QBX.Formal.Connections.BraidTorusSL2
public import QBX.Formal.Connections.TorusLinks
public import QBX.Formal.Connections.TorusLinking
public import QBX.Formal.Connections.HurwitzLattice
public import QBX.Formal.Connections.HurwitzBraid
public import QBX.Formal.Connections.E8Roots
public import QBX.Formal.Connections.IdeaCheckSpectralGap
public import QBX.Formal.Connections.HopfStrands

/-!
# Connections between the QBX layers

Cross-layer results linking braids, tori, hypercubes, lattices, spheres, Hopf fibrations and the
Cayley–Dickson tower.  See `QBX/docs/CONNECTIONS.md` for the map and the log.
-/
