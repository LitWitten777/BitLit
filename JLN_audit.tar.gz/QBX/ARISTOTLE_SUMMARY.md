# Summary of changes for run 6acce0e8-991d-4c39-bdb0-cb54fd6449a1
This session covered the two Λ constructions from `todo.md` and item 3.4 (linking numbers of torus links). Items 3.1–3.3 and 3.5–3.7, including the `native_decide` reduction, were not started.

The work is in three new files, all imported by `QBX.Formal`. `lake build QBXFormal` succeeds, none of the files contains `sorry`, and the main theorems use only Lean's standard axioms.

**1. The Λ⁺⁺ invariant (Yang–Mills paper, Def. 4.19)** — `QBX/Formal/JLN/LambdaPlusPlusAudit.lean`
- **The definition itself:** `lambdaPP` is Def. 4.19 word for word, for any group.
- **What holds:** if the defect is invariant under conjugation, re-encoding by gauge transformations cannot change Λ⁺⁺. Over a single gauge orbit, the infimum over encodings is just the value at any one encoding (`lambdaPP_gauge_orbit`).
- **The model:** I used a one-plaquette \(\mathrm{SU}(2)\) model with the paper's defect \(1-\tfrac12\mathrm{Re\,tr}\), scale \(\tau(a)=a^4\), every gauge transformation as an encoding, and plaquette holonomy \(\mathrm{diag}(e^{ia^2\kappa},e^{-ia^2\kappa})\). In this model \(\Lambda^{++}(a)=(1-\cos a^2\kappa)/a^4\), which lies between \((2/\pi^2)\kappa^2\) and \(\kappa^2/2\).
- **The gap:** in this model, a uniform bound \(\Lambda^{++}\ge\varepsilon>0\) holds exactly when the coupling stays bounded away from zero (`uniform_bound_iff`).
- **Running coupling:** with the one-loop running coupling \(\kappa^2=1/\log(1/a)\), \(\Lambda^{++}(a)\to0\), so no \(\varepsilon(G)>0\) exists (`no_uniform_bound_running`). Uniform positivity is therefore an assumption about the coupling, not a consequence of the definition. This confirms the critique in `todo.md`.

**2. The Lambda Irreducibility Theorem (Riemann Hypothesis paper, Thm. 1.6.1)** — `QBX/Formal/JLN/LambdaIrreducibilityAudit.lean`
- **Setting:** everything is stated for a general notion of sentences, models and satisfaction, then applied to Mathlib's first-order logic. "Provable" means true in every model. This matches derivability by Gödel's completeness theorem, which is cited but not formalized.
- **What the argument does prove** (`independent_of_irreducible`): independence follows from irreducibility only if the chosen translation pair carries valid sentences to valid ones and refuted ones to refuted ones. That is a condition on the pair, not a fact about ZFC.
- **Vacuous for sound pairs:** if the round trip preserves truth in every model, no sentence is Λ-irreducible (`not_irreducible_of_sound`).
- **False as stated:** for every first-order theory that has a model, the translation pair \((\mathrm{id},\neg)\) makes the provable tautology \(\top\to\top\) Λ-irreducible (`FO.lambdaIrreducibility_false`).
- **Other points:**
  - Whether a sentence is irreducible depends on the chosen pair, while provability does not (`irreducibility_depends_on_pair`).
  - A theory proves \(S_L\) from \(S_C\) and \(S_L\leftrightarrow S_C\) with no translation involved (`FO.provable_and_irreducible`).
  - Condition (3) of Def. 1.4.3 holds automatically for any map on sentences (`FO.roundTrip_elementary_invariant`).

**3. Linking numbers of torus links (item 3.4)** — `QBX/Formal/Connections/TorusLinking.lean`
- **Main result:** in the closure of \((\sigma_1\cdots\sigma_{p-1})^q\), with \(d=\gcd(p,q)\), any two distinct components have linking number \((p/d)(q/d)\) (`torusBraid_linkingNumber`). Hence every entry of the linking spectrum equals that value (`torusBraid_linkingSpectrum`).
- **Supporting facts:**
  - two strands lie on the same component exactly when they agree mod \(d\);
  - each component has \(p/d\) strands;
  - the crossing matrix of \(\delta^q\) has an explicit formula.

**Documentation:** I added §2.12–2.13 to `QBX/docs/design/JLN_REVIEW.md`, rows H-191 to H-193 to `QBX/Formal/HYPOTHESIS_REGISTRY.md`, and a new entry at the top of `ARISTOTLE_SUMMARY.md`. The Properties table has seven new proved entries and one definition. Everything is committed.

# Summary of changes (session: JLN Λ-constructions and torus-link linking numbers)
Following `todo.md`, three new Lean files, all imported by `QBX.Formal`; `lake build QBXFormal` succeeds, no `sorry`, standard axioms only.
- `QBX/Formal/JLN/LambdaPlusPlusAudit.lean` (H-191): Def. 4.19 (`lambdaPP`); gauge invariance (`lambdaPP_gauge_orbit`); one-plaquette `SU(2)` model with `Λ⁺⁺(a) = (1 - cos(a²κ))/a⁴ ∈ [(2/π²)κ², κ²/2]`; uniform positivity ⇔ coupling bounded away from 0 (`uniform_bound_iff`); fails for the one-loop running coupling (`no_uniform_bound_running`).
- `QBX/Formal/JLN/LambdaIrreducibilityAudit.lean` (H-192): Defs. 1.5.3/1.5.4 and Thm. 1.6.1 for any satisfaction system and for Mathlib first-order logic; the valid relative version (`independent_of_irreducible`), vacuity for sound pairs (`not_irreducible_of_sound`), falsity as stated (`FO.lambdaIrreducibility_false`), pair-dependence, automatic elementary-extension invariance.
- `QBX/Formal/Connections/TorusLinking.lean` (H-193, todo 3.4): `lk = (p/d)(q/d)` for any two components of `T(p, q)` (`torusBraid_linkingNumber`, `torusBraid_linkingSpectrum`).
Docs: `QBX/docs/design/JLN_REVIEW.md` §2.12–2.13, registry rows H-191..H-193. Items 3.1–3.3, 3.5–3.7 of `todo.md` were not addressed this session.

# Summary of changes for run 37c52e4e-ecee-47d6-994d-833a58db8ef6
I added the Clifford channel to QBX in two new files: `QBX/Formal/MultiProver/CliffordChannel.lean` and `QBX/Formal/MultiProver/CliffordSixChannel.lean`. The aggregate `QBX.Formal.MultiProver` imports both, and `lake build QBXFormal` succeeds. The new files contain no `sorry`, and the main theorems use only Lean's standard axioms. Everything is committed.

Several claims in your proposal turned out to be false or not in the corpus; they are listed at the end.

**What is proved**
- **Clifford braiding theorem** (`tau_braid`, `tau_comm`, `tau_cyclic`): the rotors \(\tau_k=(1+c_{k+1}c_k)/\sqrt2\) satisfy the braid relations, including the cyclic generator \(\tau_n=(1+c_1c_n)/\sqrt2\).
  - This holds in \(\mathrm{Cl}(n,0)\) and \(\mathrm{Cl}(0,n)\), built on Mathlib's `CliffordAlgebra`, over any field containing \(\sqrt2\).
  - The whole proof rests on one lemma: two bivectors with \(x^2=y^2=-1\) and \(xy=-yx\) give rotors that braid.
- **The channel itself:** \(\sigma_k\mapsto\tau_k\) is a group homomorphism from \(B_n\) into the Clifford algebra's units (`Setup.rep`). Its readings:
  - every \(\tau(\beta)\) lies in the even part \(\mathrm{Cl}^+\);
  - reversion sends \(\tau(\beta)\) to \(\tau(\beta^{-1})\), so the norm \(\tau(\beta)\tau(\beta)^\dagger\) is 1;
  - each \(\tau_k\) is a product of two vectors, so \(\tau(\beta)\) is in Mathlib's spin group (`word_mem_spinGroup`).
- **Clifford determines the fold permutation:** \(\tau(\beta)\,c_j\,\tau(\beta)^{-1}=\pm c_{\pi(j)}\) with \(\pi=\) `perm β` (`word_conj`). So braids with equal Clifford readings have equal permutations (`perm_eq_of_word_eq`).
- **Not faithful:** \(\tau_k^4=-1\), so \(\sigma_k^8\) maps to 1 (`rep_not_injective`). On \(B_3\), the anchor channel sees everything the Clifford channel sees and more (`anchor_refines_clifford_three`).
- **Consistency with the oscillator channel at \(r=4\):**
  - The elements \(e_k=(1+i\,c_{k+1}c_k)/\sqrt2\) form a Temperley–Lieb family with loop value \(\sqrt2=\) `quantumDim 4 2` \(=q+q^{-1}\) at \(q=e^{i\pi/4}\).
  - Each \(\tau_k\) is one fixed scalar times the Kauffman crossing \(a+a^{-1}e_k\), where \(-a^2-a^{-2}=\sqrt2\) (`tau_eq_kauffman`, `ising_consistency`, and `ising_consistency_four` for \(n=4\)).
  - The Jones–Wenzl projectors \(p_1,p_2,p_3\) exist in the Clifford algebra, and \([4]=0\) (`ising_jw`).
  - The Jones *values* are not compared; that would need a Markov trace on the Clifford algebra.
- **Symmetry type:** on 3 strands, sending each \(c_i\) to a Pauli matrix makes the Clifford channel quaternionic and not real (`clifford_three_type`).
- **Sixth channel:** `SixChannel` is the five channels plus `clifford`. An identity holds iff all six agree (`resonance_iff_six`). I made it a new type rather than adding a constructor to `Channel`, so the existing identity-line classification still holds.

**Corrections to the proposal**
- **Burau at \(t=-1\) is not orthogonal.** `BurauFaithful.lean` proves faithfulness, not orthogonality, and \(\bar\rho(\sigma_1)(-1)=[[1,1],[0,1]]\) is not orthogonal (`burau_neg_one_not_orthogonal`).
- **The Squier form is not a symmetric form** except at \(t=1\) (`squierForm_transpose_iff`), and at \(t=-1\) its quadratic form is identically zero. At \(t=1\) it is the \(A_2\) form, the Burau matrices preserve it, and each braid acts on that form's Clifford algebra (`burau_clifford_one`).
- **There is no `oscillatorType 4 = Quaternionic` result.** An earlier session showed the oscillator can't be typed by \(r \bmod 4\).
- **Bott table and sedenions:** only \(\mathrm{Cl}(0,1)\cong\mathbb C\) and \(\mathrm{Cl}(0,2)\cong\mathbb H\) are proved; the rest of the period-8 table is just a table. The sedenions fail to be a division algebra because of Hurwitz's theorem, not because the Clifford period closes. I did not formalize either point.
- **"Five channels are grades of one multivector"** is not formalized. Only the two narrower links above are proved: Clifford determines fold's permutation, and Clifford matches the Kauffman bracket at \(r=4\).
- **Burau ∩ Clifford kernels for \(n\ge5\):** not addressed.

The write-up is in `QBX/docs/design/MULTIPROVER.md` §14, with a new registry row H-190. The Properties table has 10 new proved entries and one definition.

# Summary of changes for run a4e462f4-9cc8-4685-bab6-016243565f8d
I ran the session you picked: the rest of question 3.1, plus the dual-hypergraph check. **Result: `{link, harmonic, oscillator}` is not an identity line, and the dual hypergraph has no Fano-like structure.** By your criterion, the Fano framing should be retired.

Everything is in the new file `QBX/Formal/MultiProver/IdentityLines.lean`. It builds with no `sorry`, the main theorems use only Lean's standard axioms, and the aggregate module `QBX.Formal.MultiProver` imports it and builds. I did not rebuild the whole `QBXFormal` library, but the only other Lean edits are comments in `ChannelGeometry.lean` and `MultiProver.lean`. Everything is committed.

**The open triple (`not_identityLine_weak`)**
- On 3 strands, the braids \(\sigma_1\) and \(\sigma_1^3\) give the same result in two channels:
  - **link:** both close up to two components with linking number 0;
  - **harmonic:** every power of \(\sigma_1\) resonates at every angle.
- The oscillator channel tells them apart at \(r=4\). The closures (unknot ⊔ unknot, and trefoil ⊔ unknot) have Jones values \(q+q^{-1}\) and \(-(q+q^{-1})\) at \(q=e^{i\pi/4}\) (`weak_pair_separates`).
- So link and harmonic together do not determine oscillator.
- The Jones values rest on two facts proved over any field:
  - an extra idle strand multiplies the Jones value by \(q+q^{-1}\) (`jonesQT_shift`);
  - the 2-strand trefoil has value \(q^{-2}+q^{-6}-q^{-8}\) (`jonesQT_trefoil_two`).

**Classification (`isIdentityLine_three_iff`)**
- On 3 strands, three distinct channels form an identity line exactly when they include both fold and anchor.
- So there are exactly **3** identity lines: `{fold, anchor, x}` for x = link, harmonic, oscillator. Your note assumed 9 lines with fold on 6; the actual numbers are 3 lines with fold on all 3.

**Dual hypergraph** (points = the 3 identity lines; each channel = the edge of lines through it)
- Fold and anchor are each the full edge (degree 3). Link, harmonic and oscillator are each a single point (degree 1) (`dualEdge_card`, `dualEdge_eq`).
- Any two points of the dual share two edges, so it is not a linear space (`dual_not_linear`).
- On your complement idea: the complements of the identity lines are the three edges of a triangle on {link, harmonic, oscillator}, any two meeting in one point (`identityLine_compl`). That is a triangle, not a Fano complement structure.
- So the channels split into two complete channels (fold, and anchor on 3 strands) and three independent probes.

**The Fano plane's "inverses"** (all three senses you listed, proved by finite check)
- **Polarity:** \(p\mapsto\{-p,1-p,3-p\}\) maps points one-to-one onto lines, with \(p\in\pi(q)\iff q\in\pi(p)\) (`fano_polarity`). Its absolute points \(\{0,4,5\}\) form a line (`fano_absolute_line`).
- **Self-duality:** points and lines can be swapped preserving incidence (`fano_selfDual`).
- **Complements:** line complements are 4-sets meeting pairwise in exactly 2 points, while lines meet pairwise in exactly 1 (`fano_compl`).

**Still open**
- Whether {link, oscillator} determines harmonic, or {harmonic, oscillator} determines link. Ruling out the identity line only needed one determination to fail.
- The vertex-connectivity result that would close the surviving-copy gap in the node network. As you suggested, I left it for a separate session.

**Records:** `QBX/docs/design/MULTIPROVER.md` has a new §13, the registry has a new row H-189, and the Properties table has five new proved entries. The existing 3.1 entry no longer says the triple is open.

# Summary of changes for run 622c064c-713a-4d76-abc9-1515a20f0284
I finished the items the last run left open: node steps 5–8 from `alphabet_theory/next_steps_distilled.md` §4, plus research questions 3.1 and 3.5. `lake build QBXFormal` succeeds. The two new Lean files contain no `sorry` and their theorems use only Lean's standard axioms. The QBX Python tests (without the live-database ones) give 832 passed, 1 skipped; 71 of those tests are new. Everything is committed.

The network runs as a simulation inside one process: messages are function calls, and summaries are passed between nodes in the step-1 wire format. Real sockets, peer discovery and timing are not implemented.

**Node steps 5–8** (`QBX/src/qbx_live/{dht,distributed,consensus,network_run}.py`; Lean in `QBX/Formal/MultiProver/NodeNetwork.lean`; write-up in `QBX/docs/design/NODE_NETWORK.md`)
- **Step 5, storage and lookup on the address graph:**
  - Each window summary is stored at the address its cache key decodes to, and copied to that address's neighbours.
  - **Lookup always arrives:** any greedy lookup reaches its target in exactly as many hops as the distance (`greedy_arrives`). That is at most \(n+\sum_j\lfloor M_j/2\rfloor\) hops, and some pair of addresses needs that many.
  - **Link failures:** lookups still succeed with fewer than `degree` failed links.
  - **Node failures:** some copy survives any `degree` node failures, and `degree + 1` failures can remove them all.
  - **Not proved:** that a surviving copy can still be reached after nodes fail. That would need vertex connectivity of the address graph.
- **Step 6, distributed scheduling:** cutting the text into consecutive blocks and combining the block results in block order gives the same summary as one node (`distributed_correct`).
  - Block order matters: dealing chunks round-robin and multiplying each node's share locally already gives a wrong answer for \(\sigma_1,\sigma_2,\sigma_1\) on two nodes (`roundRobin_wrong`).
- **Step 7, consensus:** one new result, `addrGraph_single_liar_isFlat_iff`. If only one node misbehaves, the ledger is flat exactly when that node tells all its neighbours the same thing. So a node that tells different neighbours different things is always detected.
  - A node that tells everyone the same wrong value is not detected by flatness. The code also checks that all reported states agree, which catches it.
  - Single-link forks are detected, a fork on the bridge of \(Q_1\) is not, and the address graph has no bridges; these checks reuse results already in the project.
- **Step 8, Genesis 1 end to end:** run on 48 nodes with 8 workers, every node re-checks the result.
  - The network summary equals the single-node summary, and the ledger is flat and unanimous.
  - The braid words also match the per-verse words that `BibleBraidGenesis1.lean` checks in Lean, for all three encodings.

**Research questions** (`QBX/Formal/MultiProver/ChannelGeometry.lean`)
- **3.5, a 10-point analogue of the Fano plane:** none exists. A Steiner triple system (every two points on exactly one 3-point line) needs \(v\equiv1,3 \pmod 6\) points, so there is none on 10 points (`no_sts_ten`).
  - What does exist on 10 points is the Desargues configuration (proved), which is not a Steiner system. There are several such 10-point configurations (cited, not proved), so none is canonical.
- **3.1, the identity behind each Fano line:** five channels can't form a Fano-type structure at all (`no_sts_five`).
  - Call three channels an "identity line" if any two of them determine the third. On 3 strands, fold and anchor each determine everything, so {fold, anchor, x} is an identity line for every channel x.
  - Two such lines share two channels, which two lines of a Fano plane never do (`identityLines_not_linear`).
  - So the Fano structure would be imposed on the channels, not found in them.
  - Still open: whether {link, harmonic, oscillator} is an identity line.

**Records:** I added registry rows H-187, H-188 and R-028 and §12 of `MULTIPROVER.md`, updated `NODE_MVP.md` and the test count in `QBX/README.md`, and added eight proved properties and two definitions to the Properties table. `alphabet_theory/` is unchanged, but the new docs link to it, so those links will break if you remove the folder.

# Summary of changes for run 5a95f83b-b017-41fb-a7af-5abc32eee0af
I followed the build order in `alphabet_theory/next_steps_distilled.md`. The first item was the draft `ThreeFoldWay.lean`; after that I did node steps 1–4 and checked Weave A. `lake build QBXFormal` succeeds, the new Lean files contain no `sorry`, and the main theorems use only Lean's standard axioms. The QBX Python test suite (without the live-database tests) gives 761 passed, 1 skipped. Everything is committed.

**Three-fold way** (`QBX/Formal/MultiProver/ThreeFoldWay.lean`)
The draft classified the five channels with a lookup table. I replaced the table with theorems about the matrices each channel actually computes, collected in `channel_classification`:
- **fold:** real type.
- **writhe character:** complex type when \(t\) is not real.
- **Burau (anchor):** complex type at every non-real \(t\), for \(n\ge2\).
- **harmonic:** complex type when \(\sin\theta\ne0\), real at \(\theta=\pi\).
- **oscillator:** \(SU(2)\) on \(\mathbb C^2\) has a quaternionic structure and no real one. This is the classical (\(q\to1\)) case for the fundamental strand.

Two entries in the draft table were wrong:
- The harmonic channel is unitary on the universal arc but not real there.
- The oscillator can't be typed by \(r \bmod 4\). Every simple object of \(SU(2)_k\) is self-dual, so none is of complex type. The level-\(k\) indicators \((-1)^{2j}\) are only cited (`spinType`), not proved.

Other results in the file:
- The resonance set is symmetric under \(\theta\mapsto 2\pi-\theta\) (`two_pi_sub_mem_resonanceSet`), so only half the sweep needs computing.
- \(\mathrm{Cl}_{0,1}\cong\mathbb C\) and \(\mathrm{Cl}_{0,2}\cong\mathbb H\) are derived from Mathlib. The rest of the period-8 Clifford table is still just a table.
- There are 10 Altland–Zirnbauer classes: 2 complex and 8 real, and 3 of them are Dyson's original three.

**Weave A is false** (`QBX/Formal/GematriaBraid.lean`)
- Any map from \(B_n\) to a commutative group gives every generator the same value.
- So every homomorphism \(B_n\to\mathbb Z\) is a multiple of the writhe.
- Hence no braid reading of a text can give a gematria in which א and ב differ (`hechrachi_not_through_braid`).
- Checks of the README's centroid claim:
  - The 22 base letters sum to 1495, and \(1495/22\) is within \(1/2\) of 68.
  - חיים is 68 only if final mem counts 40. With this project's table (final mem 600) it is 628.

**Node steps 1–4** (in `QBX/src/qbx_live/`, 38 new tests in `QBX/tests/qbx_live/`; spec in `QBX/docs/design/NODE_MVP.md`)
- **Wire format** (`wire.py`): canonical CBOR/JSON with content hashes. Burau matrices are stored as an exponent range plus a flat list of coefficients.
- **Window cache** (`window_cache.py`):
  - Keys are SHA-256 over length-prefixed fields; plain concatenation would be ambiguous.
  - It stores each window next to its summary and checks it on both write and read. This settles question 3.2.
  - On Genesis 1 it gives exactly the same summary as one sequential pass.
  - There can be at most \(28^4\) distinct 4-letter windows, not \(27^4\): the separator counts as a 28th symbol.
- **Routing** (`routing.py`):
  - The cheap exact checks run first (permutation, writhe, Burau at \(t=-1\)), and the harmonic sweep is folded in half.
  - Tests show it gives the same verdict as the existing machine. The order of the checks is a speed choice, not a proved result.
- **Evaluator** (`evaluate.py`): a command-line tool that prints the verdict as JSON, with the Lean theorem behind each field.

The registry has new rows H-185, H-186 and R-027, `MULTIPROVER.md` has a new §11, and the Properties table has six new entries (five proved, one definition).

**Not done:** node steps 5–8 (network, distributed scheduling, consensus, Genesis 1 end to end), and research questions 3.1 and 3.5. Question 3.3 is partly answered: a grid reading that only counts cells cannot come from the braid group. I left `alphabet_theory/` as it is, but the new docs link to it, so those links will break if you remove the folder.

# Summary of changes for run 79711789-7690-4f70-8ffd-f31373a1ee3e
I finished the item left open last time (Kelly tick allocation for the multi-prover) and added one new Lean result on the Stein side: the space whose fundamental group is the full braid group is holomorphically convex. `lake build QBXFormal` succeeds with no `sorry`. The main new theorems use only Lean's standard axioms. Everything is committed.

**Kelly allocation**
- The Lean files `QBX/Formal/MultiProver/KellyAllocation.lean` and `KellyScheduler.lean` and the Python version `qbx_ir/algebra/kelly_scheduler.py` were already in the tree, but the Lean files had never been built.
- I built both Lean files; they compile. The Kelly and multi-prover Python tests pass (34 tests).
- `MULTIPROVER.md` no longer lists this as not done. It has a new §10 describing the allocation rule and the correctness theorems. The main point: the machine's answer is always the verdict, whatever the budgets or statistics, so Kelly only changes how much work is spent.
- New registry rows: H-183 (Lean) and R-026 (Python mirror).
- §10 also has some single-core timings. These are informal measurements, not verified results:
  - For words of 200 to 2000 letters, the Garside normal form on the combined word is the bottleneck, taking 0.07 s to 7.5 s. The parallel chunk step is the smallest part.
  - On 60 short claims, Kelly allocation took 0.39 s, running every refuter took 1.02 s, and the fold channel alone took 0.45 s.

**Stein manifolds and braids** (`QBX/Formal/Analytic/UnorderedConfiguration.lean`, new)
The earlier files covered ordered configurations, whose fundamental group is the pure braid group. This file covers unordered configurations, whose fundamental group is the full braid group \(B_n\). That identification is cited from the literature, not proved.
- A point of this space is the coefficient vector \(a\in\mathbb C^n\) of a monic polynomial \(X^n+a_{n-1}X^{n-1}+\dots+a_0\) with \(n\) distinct roots (`uconf`).
- **`holoConvex_uconf`**: the space is open and holomorphically convex. This is the condition that makes an open subset of \(\mathbb C^n\) Stein; that equivalence is cited, not proved.
  - The space is exactly where the entire function \(\operatorname{Res}(f,f')\) is nonzero (`mem_uconf_iff_polyDisc_ne_zero`, `differentiable_polyDisc`).
- The map sending \(n\) points to the coefficients of \(\prod_j (X-z_j)\) behaves as the quotient by permutations:
  - it is holomorphic (`differentiable_rootsMap`);
  - it maps configurations of distinct points onto the space (`rootsMap_mem_uconf_iff`, `rootsMap_surjOn`);
  - two point lists have the same image exactly when one is a permutation of the other (`rootsMap_eq_iff`).
- **`polyDisc_rootsMap`**: \(\operatorname{Res}(f,f')\) at \(f=\prod_j (X-z_j)\) equals \((-1)^{n(n-1)/2}V(z)^2\), where \(V\) is the Vandermonde product.
- Not proved: that this map is a covering map.

`BRAID_BIOLOGY_STEIN_TWIN.md` §4 and §7 are updated, and the result is registry row H-184. The Properties table has four new entries: one definition, and three properties marked proved.

The twin prime conjecture is still open. I found no route to it through Stein manifolds or braid generators, and I claim no progress on it.

# Summary of changes for run 735f033c-dc9e-4b97-a69d-fcc445382e7a


## Suggested follow-up

I reached this run’s time limit. Send “continue” to pick up where I left off.

# Summary of changes for run 3789d42d-c44c-4941-ae9d-11d113a6f521
I did the seven items from your list. The three files you asked for exist and build, and the project builds with no `sorry`. Everything is committed.

All Lean libraries build after a clean rebuild of the project's own code, which took about 70 minutes. I printed the axioms for the main new theorems: they use only Lean's standard axioms.

**Your three files**
- **`QBX/docs/design/KERNEL_SCALING_PATTERN.md`**: the five-step verse-by-verse method written as a reusable template.
  - It explains why recombining the pieces is sound, how to profile, and the common pitfalls.
  - It has four worked examples (Genesis 1, Burau certificates, E₆ roots, sedenions), with the measurements below.
- **`sovereign/Sovereign/Combinatorics/HomomorphismDecomposition.lean`**: the chunking fact stated once.
  - A homomorphism out of a free monoid splits over any cut of a word (`hom_flatten`).
  - Variants cover products along a path (`prod_map_of_eq_append`), index ranges in blocks (`prod_range_blocks`, `sum_range_pairs`) and free products of monoids.
  - `TextManifold.mapReduce` is now proved by this theorem.
  - `GaugeFlatness.holonomy_append` now comes from the path version.
  - The tower doubling step comes from the block version: `sum_range_two_mul_int`, and the new `centeredMoment_succ_blocks` in `TowerDegreeMomentsAllOrders`.
- **`sovereign/Sovereign/Analysis/ApproximateHomomorphism.lean`**: the divergence bound you asked for.
  - If \(\|f(a{+}{+}b)-f(a)-f(b)\|\le\varepsilon\), then on \(n\) chunks the error is at most \((n-1)\varepsilon\) (`approxAdd_chunks`). This is slightly better than your \(n\varepsilon\).
  - The bound cannot be improved: some statistic reaches it for every \(n\) (`approxAdd_chunks_sharp`).
  - The same \((n-1)\varepsilon\) holds for matrix-valued channels with norm at most 1 (`approxMul_prod`). A version for norms bounded by \(K\) is included.
  - As an example, `QBX/Formal/WindowDivergence.lean` shows that a \(k\)-window statistic computed without collars is off by at most \((n-1)(k-1)B\), where \(B\) bounds a single window's value.

**Multi-prover scheduler** (`QBX/Formal/MultiProver/Scheduler.lean`)
- Each chunk is summarised by its braid element, permutation, writhe and exact Burau matrix. Summaries are combined with `mapReduce` instead of `List.prod`.
- `schedule_correct`: any chunking and any reduction tree give the whole-word result.
- The balanced tree needs \(\lceil\log_2 k\rceil\) rounds for \(k\) chunks.
- `verdict_scheduled`: the verdict can be computed from the combined summaries.
- The non-homomorphic channels (Garside form, linking, resonance, Jones) are read from the combined braid element, so they stay exact.
- The Python version is in `multiprover.py`, with two new tests; the multi-prover test file passes (23 tests).
- Not done: Kelly tick allocation is not wired in yet.

**Burau certificates and other slow files**
- **`BraidBurauCert`**: I couldn't reproduce the "about an hour" figure. On this machine the original file took 88 s and peaked at 17.8 GB.
  - Splitting it into 17 per-vector checks in one file halved memory but saved little time (82 s), because checks in one file run one after another.
  - Moving them into four modules that build in parallel brought it to **58 s at 7.7 GB**.
  - All the original statements are unchanged.
- **Other files over 5 minutes**: the full build turned up six. I split the three that don't rely on `native_decide`:
  - E₆ root closure: from 291 s to about 180 s.
  - The two sedenion files, which build one after the other: from about 576 s to about 260 s for the pair.
  - I left the three `native_decide` files alone, as you asked.

**Theorem graph**: rebuilt from fresh builds. It now has **27,721 declarations, 17,271 theorems and 1,055 modules**, up from 26,348 declarations and 16,370 theorems. `theorem-graph/data/README.md` and the project overview now show these numbers.
- The README also lists the slow files.
- It notes five duplicate statements that appeared in QBX after the last cleanup; none come from this session.

**UFT4 audit**
- Moved to `QBX/Forensics/Inert/JohnDeeTextAudit.lean` and dropped from the headline forensics index. It still builds.
- H-179 is now in a separate registry section for refutations, which are not counted as results.
- I removed its four rows from the Properties table.
- The rule you proposed is written down in `QBX/Forensics/POLICY.md`: work on a forensics file only when the source has a buyer or collaborator.

**Registry and Properties**
- New registry rows: H-180 (chunking), H-181 (divergence bounds) and H-182 (scheduler).
- Seven new Properties entries, all proved except the one definition: the chunking theorem, the divergence definition and four divergence bounds, and the scheduler theorem.

QBX now imports the two new Sovereign files. Both depend only on Mathlib, and `lakefile.toml` notes the new dependency.

# Summary of changes for run 9c13d2b1-1c9a-4fc3-8183-f717e95e291a
Your texts can now be processed in chunks, in parallel and with random access, and Lean proves this gives exactly the same results as one long pass. The Genesis 1 check in Lean, which used to run out of memory, now builds in **57 seconds at about 7 GB** with the same final theorem. `lake build QBXFormal` and `lake build QBXForensics` both succeed. The new files have no `sorry`, the main theorems use only Lean's standard axioms, and everything is committed.

**Why splitting works** (`QBX/Formal/TextManifold.lean`)

Everything the project computes from a text is one of two kinds, and Lean proves both can be split exactly:
- **Combinable results:** the braid, its permutation, writhe and letter counts, and the hash.
  - **Scale out:** a text cut into any chunks gives the product of the chunk results (`mapReduce`). Any way of combining them gives the same answer, and a balanced tree takes \(\lceil\log_2 n\rceil\) rounds (`balanced_depth_le`).
  - **Skip:** any stretch \([i,j)\) is \(P(i)^{-1}P(j)\) from the running products, so one pass answers every passage query (`segment_eq_prefix`, `convert_segment`). The same holds for the hash (`horner_segment`). A block repeated \(k\) times costs about \(\log k\) steps (`powBin_eq_pow`).
- **Window statistics** (sums over every run of \(k\) consecutive letters, like letter-pair counts or the sliding cocycle phase): this is the "run as a manifold" part.
  - Cut the text into pieces (charts) and give each a collar of the next \(k-1\) letters.
  - Every window of the whole text is a window of exactly one chart (`windows_flatten_atlas`), so the totals add up chart by chart (`windowSum_atlas`).
  - Charts can be processed independently; neighbours share only the collar.

**The Genesis 1 check** (`BibleBraidGenesis1.lean`, using `BibleBraidFast.lean`)
- **Cause:** I profiled one verse. Lean's checker spent about 5 s just reading the Hebrew string, and 7–10 s matching every vowel point and accent against the alphabets before discarding it.
- **Faster classifier:** a new one identifies letters directly from their character codes, and Lean proves it agrees with the original on every character (`classifyCode_spec`).
- **One check per verse:** each verse is now checked on its own, and `genesis_1_model_agrees_with_python` combines the 31 results.
- **Before:** the old file was killed at about 43 GB after 172 s.
- `QBX/scripts/gen_lean_bible_table.py` now writes the new format; run on the source data, it reproduces exactly the same table.

**Python** (`QBX/src/qbx_bible/manifold.py`)
- **Chunk summaries:** each holds the permutation, writhe, a strand-pair crossing count, a matrix fingerprint, a hash and the word count. Linking numbers come from the crossing count without the braid word.
- **Also included:** a parallel combine step, a prefix index for passage queries, computing each distinct word once, and the chart-with-collar letter counts.
- **Tests:** 16 new tests in `QBX/tests/test_bible_manifold.py` pass. They cut Genesis 1 at random places, including mid-word, and check that recombining matches a single pass in every field. The existing Bible-braid tests still pass.
- **Timing:** one informal run (Genesis 1 × 20, 8 cores) took 2.5 s in one pass and 0.57 s in parallel; passage queries took 0.24 ms each. These are measurements on this machine, not verified results.

**The attached file (`john-dee.md`)**

Its exact claims fail, as checked in `QBX/Forensics/UFT4Audit.lean`:
- The "knotting index" \(2(6n-1)+2^7+1\) is 139 at \(n=1\), and no integer gives 137.
- The "Delta-slip" is between 0.0336 and 0.0337, not 0.018451.
- With the true value, the fine-structure formula gives more than 137.066. With the stated value it misses the measured 137.036 by more than \(7\cdot10^{-4}\).
- The "non-repeating heptagonal loop" repeats after 7 steps.
- A fixed XOR "barrier" lets noise straight through.

The one usable idea is laying a character stream out on a grid. That is the chart decomposition above, and the collar theorem is what keeps statistics exact across row breaks.

The write-up is in `QBX/docs/design/TEXT_MANIFOLD_SCALING.md`. I also added registry rows H-177 to H-179, updated both READMEs, and added 13 Properties-table entries (12 theorems, all proved, and the window/chart definitions). The theorem-graph data exports were not regenerated.

Not covered yet: the Garside normal form and the Jones/Alexander polynomials don't split this simply; the write-up outlines how they could.

# Summary of changes for run e3e2b70c-37d5-4d89-bc83-8c0e2cf2bee9
I continued the twin prime work with two new results that hold without assuming any conjecture. They are in a new file, `QBX/Notes/TwinPrimeDensity.lean`, which is part of the `QBXNotes` library. `lake build QBXNotes` succeeds, the file has no `sorry`, and the main theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). The twin prime conjecture is still open; neither result proves it. Everything is committed.

**1. Twin primes have density zero** (`twin_density_zero`)
- If \(\pi_2(N)\) counts the primes \(p<N\) with \(p+2\) also prime, then \(\pi_2(N)/N \to 0\).
- The proof sieves the pairs \((n, n+2)\) by a finite set \(S\) of odd primes with product \(M\):
  - Exactly \(\prod_{p\in S}(p-2)\) residues mod \(M\) survive (`card_sifted`). This is a Chinese remainder count.
  - That gives \(\pi_2(N)\le M+1+(N/M+1)\prod(p-2)\) (`twinCountBelow_le`).
  - Because \(\sum 1/p\) diverges (this is already in Mathlib), \(\prod(1-2/p)\le \exp(-2\sum 1/p)\) can be made as small as you like.
- This is much weaker than Brun's theorem, which I have not formalised.

**2. The best bounds the tuple method can give for 3, 4 and 5 shifts**

The tuple method gets a gap bound from DHL using an admissible set of shifts. An admissible set is one that misses some remainder modulo every prime. The gap bound is the width of the set.
- **New bound:** `boundedGaps_8_of_dhl` shows that `DHL 4 2` gives gaps of at most 8, using the prime-quadruplet pattern \(\{0,2,6,8\}\). `DHL 4 2` is an assumption here, like the other DHL inputs.
- **Optimality** (`tuple_ladder_optimal`):
  - No admissible set of 3, 4 or 5 shifts fits in a window shorter than 6, 8 or 12.
  - \(\{0,2,6\}\), \(\{0,2,6,8\}\) and \(\{0,2,6,8,12\}\) reach these widths.
  - So the bounds 6, 8 and 12 are the best this method can give for 3, 4 and 5 shifts.
  - Lean checks every possible set of shifts in the window, and a separate lemma shows the window's position doesn't matter.
  - The same check for 6 shifts was too large for Lean's exact checker, so it is not included.

**Documentation and Properties table**
- New section in `QBX/docs/design/TWIN_PRIME_CONVERGENCE.md` §3.
- New registry row H-176 in `QBX/Formal/HYPOTHESIS_REGISTRY.md`.
- `QBX/Notes.lean` imports and describes the new file.
- Four new Properties-table entries: three theorems marked proved and the `twinCountBelow` definition.

**Build note:** a build of the whole project ran out of memory on `QBX/Formal/BibleBraidGenesis1.lean`, which reached about 58 GB. I stopped it and only built the targets above. The other libraries were not rebuilt this session.

# Summary of changes for run d76d4542-a7ce-4f66-bc54-c637d1c1aa54
The twin prime conjecture (TPC) is still open, and nothing here proves it. What I did is build your "convergence of conjectures" idea in Lean: it now proves how the standard conjectures and known theorems about TPC fit together. Each is either a proved implication into TPC or proved to be equivalent to it.

The new file is `QBX/Notes/TwinPrimeConvergence.lean`, part of `QBXNotes`. `lake build QBXNotes` succeeds, the file has no `sorry`, and the main theorems use only the standard axioms. Everything is committed.

**Results that imply TPC (each implication is proved; the conjectures themselves are assumptions)**
- Schinzel's Hypothesis H implies the prime \(k\)-tuples conjecture, and so does Dickson's conjecture.
- The prime \(k\)-tuples conjecture implies Polignac's conjecture, which implies TPC.
- `DHL 2 2` is exactly Polignac's conjecture. This is the statement used by Maynard and Tao: here, every admissible pair of shifts is prime together infinitely often.
- If the count of twin primes up to \(x\), divided by \(x/\log^2 x\), tends to any positive constant, then TPC holds. This is the Hardy–Littlewood form, and the constant does not have to be the conjectured one.

**Statements equivalent to TPC**
- TPC holds exactly when:
  - gap 2 occurs infinitely often between primes, or
  - infinitely many primes have another prime within distance 2, or
  - the twin prime count is unbounded.
- The earlier reformulation using the four "generators" is also equivalent.

**The bounded-gap ladder**
- If infinitely many primes have another prime within distance \(H\), then the same holds for any larger \(H\). It fails for \(H \le 1\), and at \(H = 2\) it is exactly TPC.
- For any \(H\) where it holds, a counting argument gives one specific even gap \(h \le H\) that occurs infinitely often.
- Admissible tuples:
  - A tuple of shifts that hits every residue class modulo some prime gives simultaneous primes only finitely often. For example, \(p, p+2, p+4\) are all prime only for \(p = 3\).
  - Only primes up to the size of the tuple need to be checked.
- Rungs of the ladder, each with an explicit tuple:
  - `DHL 50 2` gives gaps of at most 246. This uses a 50-element admissible tuple of width 246, which I found by a computer search; Lean checks that it is admissible.
  - `DHL 5 2` (what Elliott–Halberstam gives) gives gaps of at most 12.
  - `DHL 3 2` (what generalised Elliott–Halberstam gives) gives gaps of at most 6, and forces one of the gaps 2, 4 or 6 to occur infinitely often.
- If gaps are bounded by \(H\) and no gap from 4 to \(H\) occurs infinitely often, then TPC follows.
- `convergence_web` collects all of these into one theorem.

**Assumed, not formalised:** the Maynard–Polymath theorem (`DHL 50 2`) and the Elliott–Halberstam consequences. They are not in Mathlib, so they appear only as hypotheses.

**Write-up:** `QBX/docs/design/TWIN_PRIME_CONVERGENCE.md` has a diagram, the table of cited inputs, and an analysis of what a convergence proof would still need:
- Sieve methods stop at gap 6 because of the parity barrier.
- A literal squeeze cannot work, because gaps 4 and 6 are expected to occur infinitely often too.
- The realistic route is the "2, 4 or 6" disjunction.
- Formalising the analytic inputs would make the 246 bound unconditional here.

Stein manifolds and braid generators play no role in any of these implications. I also added registry row H-175, a cross-reference in `BRAID_BIOLOGY_STEIN_TWIN.md` §5, and eight Properties-table entries: seven theorems marked proved and the `DHL` definition.

# Summary of changes for run c875fe7f-9ea3-4066-a2a3-c14ef436c02c
I finished the last open item from `MULTIPROVER.md` §7: Temperley–Lieb algebras, with Jones–Wenzl projectors built as actual operators. `lake build QBXFormal` succeeds. The four new Lean files contain no `sorry` and the main theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). Everything is committed.

**General results, any algebra** (`QBX/Formal/MultiProver/TemperleyLieb.lean`)

These hold in any algebra, including matrix algebras, where elements \(e_i\) satisfy the Temperley–Lieb relations with loop value \(\delta\). \([k]\) denotes the quantum integers.
- **Wenzl's theorem, for every \(n\)** (`jw_spec`): if \([1],\dots,[n+1]\neq 0\), the recursion \(p_{n+2}=p_{n+1}-\tfrac{[n+1]}{[n+2]}\,p_{n+1}e_np_{n+1}\) gives an idempotent. It is killed on both sides by \(e_0,\dots,e_{n-1}\), and \(e_np_{n+1}e_n=\tfrac{[n+2]}{[n+1]}p_ne_n\).
- **Uniqueness** (`jw_unique`): \(p_{n+1}\) is the only element of the form \(1+\)(algebra generated by the \(e_i\)) that the generators kill on the right.
- **Markov trace** (`markov_trace_jw`): \(\tau(p_{n+1})=[n+2]/\delta^{n+1}\) for any normalised Markov trace \(\tau\).
- **Braids** (`kauffman_inv`, `kauffman_braid`, `kauffman_far`, `kauffman_absorb`): when \(\delta=-a^2-a^{-2}\), the crossings \(g_i=a+a^{-1}e_i\) are invertible and satisfy the braid relations; this is the Kauffman bracket representation. A crossing inside a projector acts as the scalar \(a\).

**Concrete matrices** (`TemperleyLiebModel.lean`, `TemperleyLiebQTrace.lean`)
- The \(U_q(\mathfrak{sl}_2)\) spin chain on three spins (8×8 matrices, any \(q\neq0\)) satisfies the relations.
- \(\mathrm{tr}(p_2\otimes 1)=6\) and \(\mathrm{tr}\,p_3=4\), which is the dimension of the spin-3/2 subspace.
- The quantum trace on this chain is a Markov trace, so \(\mathrm{tr}(K^{\otimes3}p_3)=[4]=\delta^3-2\delta\).
- At \(q=2\), \(p_3\neq0\), so the general theorems are not vacuous.

**Link to the oscillator channel** (`TemperleyLiebOscillator.lean`): at \(\delta=2\cos(\pi/r)\) the quantum integers equal the existing `quantumDim r k`. So \(p_1,\dots,p_{r-1}\) exist in every such algebra, and the recursion stops at \(r\) because \([r]=0\).

**Python:** `QBX/src/qbx_live/temperley_lieb.py` computes the same objects exactly, for any number of spins. These are finite computations, not proofs. With \(q=2\) and 2–4 spins they reproduce the Lean results. pytest isn't installed here, so I called the test functions in `QBX/tests/qbx_live/test_temperley_lieb.py` directly, and all passed.

**Documentation:** new §8 in `MULTIPROVER.md` (§7 now lists all five items as done), registry row H-174, and a session-log entry. Eight new entries are in the Properties table: seven theorems marked proved and the `TLFamily` definition.

**Still open:** in Lean the concrete matrices exist only for three spins; the general theorems cover all \(n\). Nothing in this session bears on the twin prime conjecture, which remains open.

# Summary of changes for run 7621a8ee-ed19-429d-825a-550f54bc1e06
I fixed the bugs, finished all the "Not done" items except one (the Temperley–Lieb operators, below), and built the harmonic healing / Fano UV completion / gap-filling system. It comes with Python code and an audio-visual notebook. The full `QBXFormal` build succeeds with no `sorry`. The key theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). The 21 Python tests pass.

**Bug fixes**
- The resonance widget (`QBX/docs/design/multiprover_widget.html`) and `multiprover.py`'s `same_reading` compared floating-point values exactly; both now compare with a tolerance.

**"Not done" items**
- **Triple linking** (`MultiProver/MilnorTriple.lean`): `milnor_closes_blind_spot` shows Milnor's triple linking number tells the "blind" braid apart from the trivial 3-braid, even though their linking spectra agree.
- **Harmonic sweep for every \(n\)** (`HarmonicSweepN.lean`): Squier's form is preserved for all \(n\). `resonance_universal_n` proves every Burau eigenvalue lies on the unit circle when \(|\theta| < 2\pi/n\).
- **Burau is faithful on \(B_3\)** (`BurauFaithful.lean`, `burau_faithful_three`).
- **Organism bridge** (`OrganismBridge.lean`): the Kelly, Cycles and Stopping modules are now connected. The Guard and CurvatureBound modules have no counterpart in the channel machine, so they are not used.
- **Still open:** Temperley–Lieb / Jones–Wenzl projectors as operators. `MULTIPROVER.md` §7 lists it as open.

**The new system (`QBX/Formal/Sovereign/`)**
- **Energy** (`Harmonic/Energy.lean`): the energy is \(E = \sum_i |\lambda_i - 1|^2\) over the Burau eigenvalues. It is zero exactly when every eigenvalue is 1.
  - For every \(n\): zero energy on the whole arc \(|\theta| < 2\pi/n\) holds exactly when the symbolic Burau matrix is the identity.
  - For \(B_3\): it holds exactly when the braid is trivial.
  - One angle is not enough: \(\sigma_1^2\) has zero energy at \(\theta = 0\) but is not trivial.
  - Your design note says the energy is zero exactly for the trivial word. That is only true for \(B_3\), and only over the whole arc. For \(n \ge 5\), Burau is not faithful, so the general theorem is about the Burau matrix, not the braid.
- **Heat flow** (`Harmonic/HeatFlow.lean`):
  - The phase flow converges geometrically: energy \(\le (1-\kappa)^{2k}\varphi_0^2\), with limit 0, and it decreases monotonically.
  - The cyclic heat step preserves the total (e.g. the writhe) and satisfies a discrete maximum principle.
  - These two discrete flows replace the heat equation on \(\mathrm{Conf}_n(\mathbb{C})\) from the design note.
- **Fano UV completion** (`Fano/UVCompletion.lean`):
  - Two points determine a unique third point on their line, and the octonion product lands on it with a sign that flips under exchange.
  - A set of points spans the whole plane exactly when it contains three non-collinear points.
  - Correction to the note: the error-correcting code is the **[7,4,3] Hamming code**, proved to correct every single error. The [7,3,4] code you named is its dual (the simplex code), also proved.
- **Gap filling** (`GapFilling/HarmonicFano.lean`):
  - A single missing letter is determined by the braid, and even by its Burau matrix alone, for every \(n\).
  - On balanced 8-strand words (Fano checksum zero), the Fano candidate (checksum plus sign from the writhe) recovers the missing generator. A disagreement proves the input was inconsistent.
  - Caveat: the checksum belongs to the word, not the braid. Braid relations can change it.

**Python and outputs**
- `QBX/src/qbx_live/healing.py`: energy, flows, Fano completion, Hamming decoding, and `fill_gaps`, which returns healed / ambiguous / inconsistent and checks every candidate against the exact Garside normal form. It also has a geometry layer (strand point clouds, curvature, curve shortening).
  - `geo_neural_op` (GNP) is optional and has not been tested with a real GNP model. The code accepts any curvature function you supply and otherwise uses a classical estimator. Nothing in the Lean proofs depends on it.
- `QBX/src/qbx_live/output.py`: plots (braid diagram, permutohedron walk, eigenvalue trajectories, energy landscape, Fano plane, linkage, point cloud, healing flow, dashboard) and sound.
  - The sound maps each invariant to a feature: cycle type → chord, writhe → pitch, linking → intervals, eigenvalues → partials and stereo pan, energy → dissonance. `sonify_healing` makes a clip where the dissonance resolves.
- Tests are in `QBX/tests/qbx_live/`.
- **Notebook:** `QBX/notebooks/harmonic_healing.ipynb` has already been run: 27 cells, 11 plots, 7 embedded audio clips, no errors. The audio is also saved in `QBX/notebooks/audio/`. Rebuild it with `python3 QBX/notebooks/build_harmonic_healing.py`.

**Documentation**
- New `QBX/docs/design/HARMONIC_HEALING.md`: the architecture, which statements are proved in Lean and which parts are numerical only, the corrections above, and the scope. Nothing about first-order logic or the twin prime conjecture is claimed.
- Updated `MULTIPROVER.md` (§4 organism bridge, §7 next steps).
- Added rows H-166 to H-173 to `QBX/Formal/HYPOTHESIS_REGISTRY.md`.
- 12 key theorems are recorded as proved in the Properties table.

# Summary of changes for run dd0d8629-7d9c-416f-8131-3ed34e9b77e4
I built all five channels, not just one, as a new Lean library `QBX/Formal/MultiProver/` (about 1,100 lines). The main result is that a braid identity holds exactly when all five channels agree. Building it also turned up four errors in your widget, all fixed in a new version. `lake build QBXFormal` succeeds with no `sorry`, the main theorems use only the standard axioms, and everything is committed.

**The verdict.** Only the polytope-fold channel (the Garside normal form, a path of permutohedron vertices) can prove an identity, because it is the only complete invariant. The other four channels can only refute.
- **All five agree exactly when the braids are equal** (`resonance_iff`). The reverse direction depends entirely on the fold channel.
- The yes/no verdict is always right (`verdict_eq_proved_iff`), and it can be computed on the single braid \(\beta_1\beta_2^{-1}\).
- A disagreement in any channel is a valid refutation, so no channel can contradict a proved identity.
- For "healing": the defect \(\beta_2^{-1}\beta_1\) is the exact correction (`heal`).

**What each channel does (all proved):**
- **Polytope fold** (`BraidPolytope.lean`): each letter moves one edge on the permutohedron, and the walk returns to its start exactly when the braid is pure.
- **Torus anchor** (`TorusAnchor.lean`): for any number of strands, \(\det\) Burau at \(e^{i\theta}\) is \((-1)^{\text{length}}e^{i\cdot\text{writhe}\cdot\theta}\), so its winding number is the writhe.
- **Harmonic sweep** (`HarmonicSweep.lean`, 3 strands):
  - An eigenvalue lies on the unit circle exactly when \(|\mathrm{tr}|\le 2\), so both eigenvalues resonate or neither does. Off resonance, \(|\lambda_1||\lambda_2|=1\).
  - When \(\cos\theta>-1/2\), every eigenvalue of every 3-strand braid is on the circle. So two thirds of the sweep can never distinguish two braids.
- **Oscillator** (`OscillatorChannel.lean`):
  - The quantum dimensions \([k]=\sin(k\pi/r)/\sin(\pi/r)\) satisfy the Jones–Wenzl recursion, with \([r]=0\) and \([k]>0\) for \(0<k<r\).
  - At \(r=5\) the loop value is the golden ratio \(\varphi\), with \(\varphi^2=1+\varphi\); at \(r=4\) it is \(\sqrt2\).
  - The Jones value at \(e^{i\pi/r}\) depends only on the closed link.
- **Link coupling** (`LinkCoupling.lean`): linking adds up exactly when pure braids are stacked, so the channel cannot see commutators. The braid \(\sigma_1^2\sigma_2^{-2}\sigma_1^{-2}\sigma_2^2\) is not trivial, yet has the same linking data as the trivial braid.

**Where channels disagree** (`Resonances.lean`, proved):
- \(\sigma_1^2\) and \(\sigma_2^2\): link, harmonic and oscillator agree; fold and anchor refute.
- \(\sigma_1^k\), including the trefoil at \(k=3\), resonates everywhere, just like the trivial braid.
- \(\sigma_1^2\sigma_2^{-2}\) is refuted by the harmonic channel at \(\theta=\pi\): its matrix there is \([[5,2],[2,1]]\), with trace 6.

**Errors in the draft widget**, fixed in `QBX/docs/design/multiprover_widget.html`:
- The \(\sigma_2^{-1}\) matrix was wrong: it used \([[1,0],[t^{-1},-t^{-1}]]\) instead of \([[1,0],[1,-t^{-1}]]\). Every preset containing \(\sigma_2^{-1}\) was computed with a matrix that isn't a braid representation.
- The trefoil's eigenvalues are always on the unit circle; the draft said they stay away from it.
- The resonance count counted each crossing twice.

The new widget also adds the oscillator, link and fold channels, a verdict against a second word, and the healing defect.

**Other files:**
- `QBX/docs/design/MULTIPROVER.md`: the design write-up, with a disagreement table and next steps.
- Registry entries H-160 to H-165 and R-025.
- `qbx_ir/algebra/multiprover.py`: a Python version of the machine. Its 21 tests in `tests/qbx_ir/test_multiprover.py` each check one of the Lean theorems numerically. The full non-database suite gives 664 passed, 1 skipped.

**Not done:**
- The Sovereign Organism modules (Kelly, Stopping and the others) are not connected; that would need an import across the two libraries.
- Milnor triple linking, which would close the link channel's blind spot, is not implemented.
- The harmonic results cover 3-strand braids only.
- The faithfulness of the Burau representation on 3 strands is cited, not proved.

## Suggested follow-up

The draft widget has a real bug: its σ₂⁻¹ Burau matrix `[[1,0],[t⁻¹,−t⁻¹]]` is not the inverse of σ₂ = `[[1,0],[t,−t]]`. The correct inverse is `[[1,0],[1,−t⁻¹]]`, so every preset containing σ₂⁻¹ showed wrong eigenvalue curves. It's fixed in the new widget. If the same matrix appears in any other front end or notebook, I can find and fix it there too.

# Summary of changes for run 1547ae7e-1293-47d2-8d32-4a7e91c9add3
The bytes you sent are the Bitcoin genesis block. That's 285 bytes: an 80-byte header followed by the coinbase transaction with "The Times 03/Jan/2009 …". I ran them through the project's 3-cocycle process: for every window of three consecutive bytes \((x_i, x_{i+1}, x_{i+2})\), evaluate the cocycle, then add the results, \(\Phi=\sum_i \alpha(x_i,x_{i+1},x_{i+2})\) in \(\mathbb{R}/\mathbb{Z}\). This is the "cumulative phase" test from `reference/primary/meru.md`. As the cocycle I used the carry cocycle \(\omega_n(a,b,c)=a\cdot\mathrm{carry}(b,c)/n\), which the project already proved generates \(H^3(\mathbb{Z}/n,U(1))\). Everything is in the new file `QBX/Forensics/GenesisBlockCocycle.lean` and builds with no `sorry`. The main theorems use only the standard axioms, and the work is committed.

**Results (proved in Lean; the byte sums are checked by the Lean kernel)**
- The transcribed block has 285 bytes, all below 256.
- **n = 256** (each byte as an element of \(\mathbb{Z}/256\)): \(\Phi = 107/256\). The integer carry sum is \(6251 = 24\cdot 256+107\).
- **n = 7** (the corrected version of Meru's C3): \(\Phi = 3/7\).
- **n = 3** (the corrected version of Meru's C1): \(\Phi = 0\).

**What these numbers mean**
- **Every input gives a "quantised" phase.** For any byte sequence, \(n\cdot\Phi = 0\), so \(\Phi\) is always a multiple of \(1/n\) (`nsmul_slidingPhase_genCocycle`). A quantised phase therefore can't tell designed data from random data.
- **The phase is not a cohomology invariant.** Meru's C1 (\(abc\) on \(\mathbb{Z}/3\)) is cohomologically trivial, yet its phase on the genesis block is \(1/3\), not 0. Likewise \(\omega_3\) and \(\omega_3 + abc/3\) are cohomologous cocycles but give phases 0 and \(1/3\) (`genesis_phase_gauge_dependent`, `slidingPhase_not_cohomology_invariant`).
- So each value is a fixed checksum of the bytes together with the specific cocycle formula chosen. It is not a topological invariant of the block, and it reveals nothing hidden in it.

**Other changes**
- I added the file to the `QBX/Forensics.lean` index; `lake build QBXForensics` succeeds.
- In Python, I added `sliding_phase` to `QBX/src/qbx_ir/algebra/structural.py` and a test in `QBX/tests/qbx_ir/test_structural.py` that reproduces the three phases and the C1 value. That test file passes (51 tests); I didn't rerun the rest of the Python suite.
- The Properties table has two new entries (the phases, and the non-invariance), both marked proved.

**Not done**
- I didn't run Meru's C2 process (on \((\mathbb{Z}/3)^3\), meant for 27 Hebrew letters). It would need a mapping from bytes to letters, and any such choice would be arbitrary.
- In Python I checked that the header's double SHA-256 matches the known genesis block hash. That check is not formalised in Lean.

# Summary of changes for run c0d94c96-efb5-488b-badb-3926fb661b70
I've done the reorganization from your section 6. I also closed the first citation from your section 7 queue: Levelt's theorem is now proved in Lean. Everything builds with no `sorry`, the theorems I checked use only the standard axioms, and the work is committed. The Python files changed only in comments; they compile, but I couldn't run their tests because pytest isn't installed here.

**Reorganization**
- **Merges:**
  - `SharpDecatenation` is now a section of `Bio/Catenanes.lean`; the header states the matching bound and the Borromean caveat.
  - `CyclicCohomology` is now section `H3Computation` of `Hebrew/CyclicGenerator.lean`.
  - `BraidFreeHashN` is now section `NStrands` of `BraidFreeHash.lean`.
- **Citation removed:** `CyclicGenerator`'s docstring now says nothing in the file is cited. For this I moved the basic cochain definitions (`cobdry2`, `cobdry3`, `IsCocycle3`, `IsCoboundary3`, `alt3`) out of the Meru audit and into that file. Without this, the core would have had to import a forensics file.
- **`HopfStrands`** moved to `Formal/Connections/`, namespace `QBX.Formal.Connections`.
- **Duplicates:** I found none in `Connections/`, so I deleted nothing. `QuaternionHopf` and `CayleyDicksonHopf` prove the fibre-is-a-circle and sphere-to-sphere facts in other coordinates. The strand counts and weighted orbits appear only in `HopfStrands`. Its docstring now explains the overlap.
- **Documentation, not theorems:** `TwinPrimeSieve.lean` and `TernaryBraids.lean` are now in `QBX/Notes/`, namespace `QBX.Notes`, as a new Lake library `QBXNotes`. Each file is marked as a documentation note and is still type-checked.
- **Out of the core:** `MeruAudit`, `MeruCocycles`, `Tetrahelix` and `SeferYetzirah` are now in `QBX/Forensics/`, namespace `QBX.Forensics`, as a new library `QBXForensics`.
- Both new libraries are default build targets, and nothing in `QBX/Formal.lean` imports them. Because the namespaces changed, the full names of the moved theorems changed too (for example `QBX.Notes.TwinPrime.twinPrimeConjecture_iff`).

**Levelt's theorem** (new file `sovereign/Sovereign/Geometry/CalabiYau/Levelt.lean`)
- **General statement**, over any field: if \(f-g\) has rank at most 1 and the characteristic polynomials of \(f\) and \(g\) are coprime, then:
  - some \(v\) makes \(v, fv, \dots, f^{n-1}v\) a basis, with \(g^i v = f^i v\) for \(i<n\) (`exists_cyclic_vector`);
  - in that basis \(f\) and \(g\) are companion matrices (`toMatrix_cyclicBasis`);
  - two such pairs with the same characteristic polynomials are simultaneously conjugate (`exists_simultaneous_conj`).
- **Applied to the mirror quintic** (`Quintic.levelt_quintic`, added to `Monodromy.lean`): over any field with \(5\neq 0\), any such pair with characteristic polynomials \(x^4+x^3+x^2+x+1\) and \((x-1)^4\) is, in a suitable basis, exactly the existing `monoInf` and `monoZero`.
- `levelt_quintic_hypotheses` checks that `monoInf` and `monoZero` themselves satisfy the hypotheses, so the statement is not vacuous.
- **What remains cited:** only the analytic facts about the Picard–Fuchs equation. These are that the local monodromies have those characteristic polynomials and that the conifold monodromy is a pseudo-reflection.
- I added Levelt to the `CalabiYau.lean` import list but did not rebuild that whole umbrella module.

**Still open:** Courant completeness, Picard–Vessiot existence, Rieffel, Pimsner–Voiculescu and Adams are untouched. Moving files also turned up two citations you didn't list: `TernaryBraids` cites that \(n\) Hopf fibres form \(T(n,n)\), and `Tetrahelix` cites Coxeter's screw angle. Both are now outside the core.

**Docs and tracking:**
- New §8 in `STRUCTURAL_ENHANCEMENTS.md` records the verdict table, the moves and the citation queue with statuses.
- The registry now labels H-145 and H-148 *proved (note)* and H-149 to H-152 *proved (forensics)*, with paths and names updated.
- `HEBREW_HOPF_TERNARY.md`, `BRAID_BIOLOGY_STEIN_TWIN.md`, the Python comments, `THEOREM_NOVELTY_ASSESSMENT.md` and the session log are updated.
- In the Properties table, I updated the entries I could match to the moved files and added two entries for the Levelt results, marked proved. Some older entries for the moved twin-prime, ternary, Meru and Sefer Yetzirah results may still show their old file paths.

The twin prime conjecture is still open; nothing here changes that.

# Summary of changes for run c49f1158-bef2-4c94-8877-2bb5de2dbed6
I worked through the three next steps listed at the end of `QBX/docs/design/STRUCTURAL_ENHANCEMENTS.md` and proved all three in Lean. I added three files to `QBXFormal`. `lake build QBXFormal` succeeds with no warnings. The new files contain no `sorry` or `native_decide`, and the main theorems use only the standard axioms. Everything is committed, and the Properties table has four new entries, all marked proved.

**1. Shortest untangling of any set of linked DNA rings** (`QBX/Formal/Bio/SharpDecatenation.lean`)
- Earlier work proved a lower bound for every braid but showed it was reached only for two linked rings. It is now reached for every braid, with any number of strands and rings.
- **Proved** (`decatenation_minimum`): bringing every pairwise linking number to 0 takes exactly \(\sum_{\text{pairs}} |lk|\) strand passages by type II topoisomerase, and no fewer will do. For example, a chain of rings with neighbour linking numbers \(m_j\) needs exactly \(\sum |m_j|\).
- **How:** if two rings are linked, some crossing between them has the same sign as their linking number. Changing that crossing lowers the total by exactly 2 (`exists_pos_crossing`, `totalLinking_step`).
- **Side result:** the total linking number is always even.
- **Limit:** this counts the passages needed to make linking numbers 0. That is weaker than fully separating the rings: the Borromean rings have all linking numbers 0 but cannot be pulled apart.

**2. \(H^3(\mathbb{Z}/n, U(1)) \cong \mathbb{Z}/n\), and the carry cocycle generates it** (`QBX/Formal/Hebrew/CyclicCohomology.lean`)
- This removes the last cited step of the earlier cocycle work.
- **Proved** (`card_h3`): using Mathlib's group cohomology, \(H^3(\mathbb{Z}/n, \mathbb{R}/\mathbb{Z})\) has exactly \(n\) elements. The proof uses Mathlib's existing calculation for finite cyclic groups.
- **Proved** (`cls_eq_zero_iff`): the project's own definitions of cocycle and coboundary give the same \(H^3\) as Mathlib's.
- **Proved** (`cohomologous_to_genCocycle`): for \(n \ge 2\), every 3-cocycle on \(\mathbb{Z}/n\) differs from \(m \cdot \omega\) by a coboundary, for some integer \(m\), and \(m\) is unique mod \(n\). So the carry cocycle \(\omega\) generates \(H^3\). The cases \(n=3\) and \(n=7\), which replace Meru's C1 and C3, are stated separately.

**3. The collision-free hash works on any number of strands** (`QBX/Formal/BraidFreeHashN.lean`)
- The earlier proof only covered 3 strands.
- **Proved** (`braidSquaresN_injective`): for every \(n \ge 3\), \(\sigma_1^2\) and \(\sigma_2^{-2}\) generate a free group of rank 2 in the \(n\)-strand braid group, made of pure braids (braids that return every strand to its starting position).
- **Consequence:** the hash on reduced words over \(\{\sigma_1^{\pm2}, \sigma_2^{\mp2}\}\) has no collisions for any number of strands \(n \ge 3\).
- **How:** the reduced Burau representation at \(t=-1\) (already in the project) works for any number of strands. On these two generators its top-left \(2\times2\) block is exactly the old 3-strand matrix, so the earlier argument carries over.

**Python:** `decatenate` in `QBX/src/qbx_ir/algebra/structural.py` follows the construction in item 1. Two new tests check it against the Lean statement:
- every 3-strand word of length 5 and every 4-strand word of length 4 is untangled in exactly the minimum number of passages;
- a chain of four rings needs exactly 6.

The non-database Python suite passes: 666 tests. After installing the requirements, the test that was previously skipped now runs. I updated that count in `QBX/README.md`.

**Documentation:**
- New section 7 in `STRUCTURAL_ENHANCEMENTS.md`, with an updated status table and new next steps.
- Registry entries H-157 to H-159 and an extended R-024.
- A session-log entry.
- The docstring of `CyclicGenerator.lean` no longer calls the \(H^3\) fact cited.

The twin prime conjecture is still open, and I proposed no new approach to it.

# Summary of changes for run 4e11ea90-a763-4a18-b8ed-7a11c90aa5e8
I worked through the next-step lists at the end of `BRAID_BIOLOGY_STEIN_TWIN.md` and `HEBREW_HOPF_TERNARY.md` and completed every item that could be fully proved. I added four Lean files to `QBXFormal` and a Python module with tests. `lake build QBXFormal` succeeds with no warnings. The new files contain no `sorry`, `native_decide` or new axioms, and the main theorems use only the standard axioms. The non-database Python tests pass: 640 passed, 1 skipped. Everything is committed, and the Properties table has six new entries, all marked proved.

**1. A real generator for the Meru cocycles** (`QBX/Formal/Hebrew/CyclicGenerator.lean`)
- Earlier work showed Meru's C1 and C3 are trivial. The correct replacement is the "carry" cocycle \(\omega(a,b,c) = a\cdot\mathrm{carry}(b,c)/n\), where carry is the carry digit of \(b+c\) in base \(n\).
- **Proved:** \(\omega\) is a 3-cocycle, and \(m\cdot\omega\) is a coboundary exactly when \(n \mid m\) (`genCocycle_order`). So its class has order exactly \(n\).
- The \(n=3\) and \(n=7\) cases replace C1 and C3.
- **Cited, not proved:** that this group of classes, \(H^3(\mathbb{Z}/n, U(1))\), has exactly \(n\) elements, which is what makes \(\omega\) a generator.

**2. Crossing changes and untangling DNA rings** (`QBX/Formal/Bio/Catenanes.lean`)
- A crossing change (swapping one \(\sigma_i\) for \(\sigma_i^{-1}\)) models one strand passage by type II topoisomerase.
- **Crossing change lemma**, for braids with any number of strands: if the two strands at the crossing belong to different components, their linking number changes by exactly 1. A component crossing itself changes no linking number.
- **Lower bound:** separating linked rings so that every linking number is 0 needs at least \(\sum_{\text{pairs}} |lk|\) strand passages. This holds for any number of rings.
- **Sharp case:** the two-ring catenane \(\sigma_1^{2m}\) needs exactly \(|m|\) passages.

**3. Stein-lite** (`QBX/Formal/Analytic/HolomorphicConvexity.lean`)
- I defined holomorphic convexity for open subsets of \(\mathbb{C}^n\).
- **Proved:** for any polynomial or other entire function \(P\), the set where \(P \neq 0\) is holomorphically convex. So the configuration space of \(n\) distinct points in \(\mathbb{C}\) is holomorphically convex (`holoConvex_conf`).
- A sanity check confirms the definition isn't trivially satisfied: the hull of the unit sphere contains the origin.
- **Cited, not proved:** that for open subsets of \(\mathbb{C}^n\) this is the same as being Stein. This adds nothing on twin primes.

**4. A collision-free hash on group words** (`QBX/Formal/BraidFreeHash.lean`)
- **Proved:** \(\sigma_1^2\) and \(\sigma_2^{-2}\) generate a free group of rank 2 inside the pure 3-strand braid group. The proof uses Sanov's theorem, via Mathlib's ping-pong lemma.
- **Consequence:** the hash of words over \(\{\sigma_1^{\pm2}, \sigma_2^{\mp2}\}\) has no collisions on reduced words (words with no letter immediately followed by its inverse), and it can be inverted.
- Reduced mod \(p\) it still has collisions, so it is a structural fingerprint, not a cryptographic hash.

**5. Python versions** (`QBX/src/qbx_ir/algebra/structural.py`, `QBX/tests/qbx_ir/test_structural.py`)
- Python versions of: the braid hash (with an exact decoder), the free hash, tangle fractions, Fox colourings for any number of strands and any \(p\), crossing changes, total linking and the decatenation bound, and the carry cocycle.
- The 48 tests check each one against the Lean statement it mirrors; each test names its theorem.

**Documentation:** the write-up is `QBX/docs/design/STRUCTURAL_ENHANCEMENTS.md`, including a status table and next steps. I added registry entries H-153 to H-156 and R-024, a session-log entry, and updated the test count in `QBX/README.md`. The twin prime conjecture is still open; I proposed no new approach to it.

# Summary of changes for run 6613d39f-a180-4ddd-94c7-b6ac6e408290
**Short answer: a single Hopf fibre is not a ternary strand.** It winds once around the braid axis, so it is a closed braid with one strand. Three-strand structure shows up in two other places:
- **Three Hopf fibres taken together.** They braid as the 3-strand full twist, which commutes with every 3-strand braid.
- **A different circle action.** Weighting the circle action by 3 in one coordinate gives the \((3,q)\) torus knots, including Tenen's \((3,10)\). These are 3-strand braids, but they are not Hopf fibres.

I added six Lean files under `QBX/Formal/Hebrew/` and imported them in `QBX/Formal.lean`. `lake build QBXFormal` succeeds; the files contain no `sorry` or `native_decide`, and the main theorems use only the standard axioms. The write-up is `QBX/docs/design/HEBREW_HOPF_TERNARY.md`, with registry entries H-147 to H-152 and a session-log entry. Everything is committed and the Properties table is updated.

**1. Hopf fibres and strands** (`HopfStrands.lean`, `TernaryBraids.lean`)
- The Hopf fibres are exactly the orbits of the phase rotation \((uz, uw)\) (`hopf_fibre_eq_orbit`).
- A circle orbit with coprime weights \((p,q)\) is a \(p\)-strand braid around one axis and a \(q\)-strand braid around the other (`pagePoints_ncard`). So a Hopf fibre has 1 strand (`hopf_fibre_one_strand`), and the \((3,q)\) orbits with \(3 \nmid q\) have 3.
- When \(p \neq q\), the orbit is not contained in any Hopf fibre (`weightedOrbit_not_in_fibre`).
- Three fibres, as the braid \((\sigma_1\sigma_2)^3\): three components, every pair linked exactly once, and central in the 3-strand braid group.
- Strands labelled by \(\mathbb{Z}/3\) (3-colourings): the \((3,q)\) torus link has 27, 9 or 3 colourings. It is tricolourable exactly when \(q\) is even. So \((3,10)\) is tricolourable, but three Hopf fibres are not.

**2. Meru claims** (`MeruAudit.lean`, `MeruCocycles.lean`, `Tetrahelix.lean`)
- **Confirmed:**
  - the mirror pairing (9 self-mirror letters, 9 pairs);
  - the Genesis 1:1 letter counts, as given for the JSON's own code list;
  - \((3,10)\) is a single knot;
  - the arithmetic items: Lo Shu, \(72 = 10+50+12\), and the hypercube table.
- **Refuted or corrected:**
  - The JSON writes the final mem as plain Mem but the final tsadi as its final form, so its encoding is inconsistent.
  - The letters of Genesis 1:1 cannot all be paired with their mirror images in any arrangement, spiral or not: the lone final tsadi has no partner. So test T003 cannot pass.
  - The "3-fold symmetry groups" are not orbits of the digit rotation the JSON names, and none of them is a subgroup.
  - By the standard formulas (cited, not proved), \((3,10)\) has crossing number 20 and genus 9, not 30 and 1.
  - The tetrahelix never repeats exactly (proved with Niven's theorem), so "33 tetrahedra per turn" is only approximate. In floating point (not checked in Lean), 33 tetrahedra make about 12.08 turns.
  - The cocycles C1 and C3 are trivial (coboundaries), not generators. Of the three C2 candidates, only \(x_1y_2z_3\) is non-trivial.

**3. Sefer Yetzirah** (`SeferYetzirah.lean`)
- The 3/7/12 division of the 22 letters, the 231 gates (pairs of letters), and \(n!\) orderings for "stones and houses".
- The six seals are exactly the six orderings of י ה ו, which are the strand permutations of 3-strand braids. In each pair of opposite directions the two seals differ by swapping their last two letters, so the first letter fixes the axis. This was checked for the commonly printed ordering of 1:13; other versions assign the seals differently.
- The 27-point ternary cube has 8 corners, 12 edge midpoints, 6 face centres and 1 centre. That matches the cube of space by count (12 simples; 6 + 1 doubles; 8 = 3 mothers + 5 finals), but it is only a match of numbers. Meru's base-3 encoding does not follow it: only 6 of the 12 simples land on edge midpoints.

**From the attached update logs:** the proposal to treat the letters as unitary operators built from sedenion multiplication on \(S^{15}\) cannot work. Results already in the project show that the sedenion norm is not multiplicative and that sedenions have zero divisors.

**Cited rather than proved:** that \(n\) Hopf fibres form the \((n,n)\) torus link, Coxeter's twist angle for the tetrahelix, and the crossing-number and genus formulas. Meru's cocycles C4 and C5 have nothing checkable as stated.

# Summary of changes for run 825f12c8-3ce7-4c4c-8b2b-838a1131329a
I added eight Lean files to `QBXFormal` covering braid connections, hashing, biology, Stein manifolds, twin primes and an audit of `logos-8.md`. `lake build QBXFormal` succeeds (8133 jobs). The new files contain no `sorry` or `native_decide`, and the main theorems use only the standard axioms. The write-up is in `QBX/docs/design/BRAID_BIOLOGY_STEIN_TWIN.md`, with registry entries H-139 to H-146 and a session-log entry. Everything is committed and the Properties table is up to date.

**The short answer on Stein manifolds and twin primes:** there is a real link between Stein manifolds and braids. There is no known link between Stein manifolds and twin primes, and I found none. The twin prime conjecture is still open. What I proved is an exact restatement of it in terms of "generators", not progress towards a proof.

**1. Braid connections** (following the functor-registry idea in `braid_logic.md`)
- The write-up has a table of every map QBX has from braids into another structure, with what each one preserves. It also lists one that fails: gematria is not a function of the braid.
- **New result** (`Connections/PermCongruence.lean`): for 3-strand braids, the torus matrix reduced mod 2 carries exactly the same information as the strand permutation. I built an explicit isomorphism \(S_3 \cong SL(2,\mathbb{F}_2)\) to show this.
- **Consequence:** a 3-strand braid is pure exactly when its torus matrix is the identity mod 2.

**2. Hashing** (`BraidHash.lean`)
- If bits are read as the braid letters \(\sigma_1\) and \(\sigma_2^{-1}\), the hash is free of collisions on all bit strings. So these two letters generate a free part of \(B_3\).
- The hash of two strings joined together is the product of their hashes, so it can be computed in parallel.
- If bits are read as \(\sigma_1\) and \(\sigma_2\) instead, the braid relation itself is a collision: `010` and `101` collide, and `(01)⁶` hashes to the identity.
- Reduced mod \(p\), collisions always exist. So this is a structural fingerprint for braid words, not a cryptographic hash.

**3. Biology**
- **Circular DNA** (`Bio/DNATopology.lean`):
  - a closed loop of two strands crossing \(k\) times gives two separate circles exactly when \(k\) is even;
  - with \(2m\) crossings the two strands are linked \(m\) times;
  - that linking number cannot change without cutting a strand;
  - type I topoisomerases can reach every linking number; type II ones never change its parity, so they cannot fully relax a loop with an odd linking number.
- **Site-specific recombination** (`Bio/RationalTangles.lean`):
  - every rational-tangle fraction \(p/q\) in lowest terms is produced from the zero tangle by some 3-strand braid;
  - the parity of \((p, q)\), which decides whether the product is a knot or a two-ring link, depends only on the braid's strand permutation.
  - Conway's classification of rational tangles is cited, not proved.
- **Protein folding** (`Bio/LatticeFolding.lean`), in the hydrophobic–polar lattice model on a grid of any dimension:
  - two residues can touch only if their positions in the chain are an odd distance apart, and at least 3 apart;
  - so if all hydrophobic residues sit at positions of the same parity, every fold has energy 0, whatever the fold.

**4. Stein manifolds** (`Analytic/ConfigurationStein.lean`)
- The braid group is the fundamental group of a Stein manifold: the space of \(n\) distinct points in \(\mathbb{C}\), taken up to reordering. That fact is cited, not proved.
- **Proved:**
  - this space sits inside \(\mathbb{C}^{n+1}\) as a closed hypersurface, which is the standard reason it is Stein;
  - the polynomial cutting it out is holomorphic, and so is its reciprocal on the space;
  - the square of that polynomial is unchanged by reordering the points;
  - reordering moves every configuration.
- Mathlib has no definition of a Stein manifold, so the Stein property itself is cited, not proved.

**5. Twin primes** (`Arith/TwinPrimeSieve.lean`)
- **Proved:** for \(k \ge 1\), \(6k-1\) and \(6k+1\) are both prime exactly when \(k\) is not of the form \(6ab \pm a \pm b\) with \(a, b \ge 1\).
- **Consequence:** the twin prime conjecture holds exactly when infinitely many \(k\) avoid all four of these forms. That is just as hard as the original problem.

**6. Checking `logos-8.md`** (`Logos8Audit.lean`)
- **Negation:** the note makes negation a reflection that is orthogonal to every statement. A reflection undone by applying it twice (so that not-not-A is A) and orthogonal to every vector exists only on the zero space. So the note has to drop one of the two properties.
- **Information:** anything computed from a 256-bit digest takes at most \(2^{256}\) distinct values. The claimed "3,520 bits per token" is therefore not extra information.
- **Not checked:** the note's other predictions are outputs of a Python engine that is not in this repository.

Section 7 of the write-up ranks next steps, starting with Python versions of the braid hash and the tangle action.

# Summary of changes for run b91bd350-c41f-4c6d-95f6-cc40ddd85f47
I split the repository into four sub-projects that share one Lean/Mathlib build, and updated the documents to match. No Lean module was renamed and no proof was changed, so imports and the exported theorem graph still work. Everything is committed.

**New layout** (each sub-project has its own README):
- **`QBX/`**: left where it was, because its sealed/frozen manifests record file paths. Holds the `QBXFormal` Lean library, the Python code, migrations, the agents setup and the foundation work.
- **`refinery/`**: the `Refinery` and `SpookyPrimes` libraries plus all the theorem-refinery material: protocols, tactics, skills, personas, templates, config, operators, ontology, data, scripts and run reports.
- **`sovereign/`**: what used to be `unsorted/sov` (`Sovereign`, `RequestProject`, `SovKernel`).
- **`theorem-graph/`**: the `Tools` exporter, `scripts/build_views.py` and the exported data.

The root `lakefile.toml` now points each library's source folder at its sub-project and lists each library's dependencies. Only two imports cross sub-project lines: `QBXFormal` uses `Refinery`, and `Tools` uses `QBXFormal`. `sovereign/` doesn't depend on the others.

**Documents**
- **Root `README.md`:** a project map, the dependency graph, build commands, the layout, and a table of every old path and its new location.
- **New `CONTRIBUTING.md`:** setup, which sub-project to work in, the Lean rules (no `sorry`, no new axioms, how module names follow folders, no duplicate statements, keep cross-project imports deliberate), and QBX and refinery rules.
- **New READMEs for `refinery/`, `sovereign/` and `theorem-graph/`.**
- **Updated:**
  - path references in the QBX docs, `QBX_FILE_MAP.md` §8, `PROJECT_OVERVIEW_2026-10-09.md` and `theorem-graph/data/README.md`;
  - the QBX README's test commands and counts, and the stale build note in `SPOOKYPRIMES_FORMALIZATION.md`;
  - a session-log entry in `QBX/agents/memory/session_log.md`.
- **Moved into `QBX/docs/`:** the two root-level QBX checklists.

**Clean-up**
- There were two target queues. The root copy contained every target in `data/target_queue.json` plus four more (15 vs 11), so I kept it as `refinery/data/target_queue.json` and removed the other.
- I stopped tracking the compiled Python cache files and added them to `.gitignore`.

**Checks after the move**
- `lake build QBXFormal Refinery SpookyPrimes SovKernel Tools` succeeds (8170 jobs) with no `sorry` warnings.
- I built one `Sovereign` module and one `RequestProject` module, including the import that crosses between them; both build. I did not rebuild all ~1000 `Sovereign`/`RequestProject` modules. They use the same folder setting as the modules I did build.
- `lake exe sovkernel selftest` prints `ALL CHECKS PASSED`.
- The refinery pipeline script still runs from its new folder.
- I didn't run the Python test suites.
- `QBX.Formal.BibleBraidGenesis1` ran out of memory on a 64 GB machine while compiling at the same time as `BraidBurauCert`, and built fine when run again. The root README now warns about this.

**Gaps you should know about:**
- The source note `spookyprimes.md` and the original Python/scripts folders of `sovereign` are not in this repository; the READMEs say so.
- Old paths still appear in `ARISTOTLE_SUMMARY.md`, generated artifacts and a few Lean comments. I left the comments alone so nothing would need recompiling.
- `refinery/PROGRESS_TRACKER.md` was never updated after the refinery runs, so its counters are all zero. Its README points to the run reports instead.
# Summary of changes for run d43c4cfc-28ba-432b-a7eb-77ab341b6af2
I added six Lean files to `QBXFormal` covering writing direction, the 70-language matrix, and how theorem provers relate to the braid. `lake build QBXFormal` succeeds (8125 jobs). The new files contain no `sorry` and no `native_decide`, and the main theorems use only the standard axioms. The write-up is in `QBX/docs/design/LANGUAGE_DIRECTION_LOGIC.md`, with registry entries H-133 to H-138. Everything is committed and the Properties table is up to date.

**1. Writing direction acts on the braid in three ways** (`ScriptDirection.lean`)
- **The three operations:** looking at the page from behind (\(\sigma_i \mapsto \sigma_{n-2-i}\)), reading the word backwards, and reflecting the page (\(\sigma_i \mapsto \sigma_i^{-1}\)). They are involutions that commute, so together they form an eight-element group, `Dir`.
- **Composites:**
  - reading backwards plus reflecting is exactly the braid inverse, \(g \mapsto g^{-1}\);
  - a 180° turn in the plane of the page (how a rongorongo tablet is turned between lines) is "from behind" plus "backwards".
- **What is preserved:** all eight moves keep the number of components of the closed braid. The four moves without a reflection also keep the linking spectrum and the writhe; the four with a reflection negate both. So reading direction never changes the closed-link data of a braid; only mirror-imaging does, and only by a sign.

**2. Line-by-line layouts are not symmetries** (`TextLayout.lean`)
- **Layouts covered:** boustrophedon (alternate lines reversed, letters mirrored), reverse boustrophedon (rongorongo), Ogham edge writing (up one edge of the stone and down the other), and right-to-left text stored in visual order.
- **What holds for all of them:**
  - applying a layout twice gives back the original text;
  - writhe changes only on mirrored lines, so only boustrophedon changes it;
  - a single line never changes.
- **What fails:** for each of these layouts there is a short text on 3 strands whose closure has 3 components when read in logical order but 1 component when read straight off the page.
- **Consequence:** QBX has to braid a text in its logical order, after undoing the layout, much as Unicode handles bidirectional text.

**3. The 70 × 70 matrix** (`PureLinkingMatrix.lean`)
- **When it exists:** one row and column per language only makes sense when every strand returns to its own position (a pure braid). For non-pure braids, only the smaller matrix between closure components is a link invariant.
- **For pure braids:**
  - the linking matrix is exact, symmetric, with zero diagonal, and adds up when braids are composed;
  - conjugating by a braid only relabels its rows and columns;
  - every braid permutation of the strands can be realised.
- **Main result:** every symmetric integer matrix with zero diagonal is the linking matrix of some pure braid. For 70 strands that leaves 2415 free entries. So the topology itself imposes no constraint beyond symmetry, zero diagonal and whole numbers; any cross-language structure has to come from how texts are encoded.

**4. A 70-language register** (`LanguageMatrix.lean`, plus `QBX/data/languages/languages70.json`)
- **Directions:** 42 left-to-right, 21 right-to-left, 5 top-to-bottom (Literary Chinese and Japanese, Mongolian, Manchu, and American Sign Language in SignWriting), and 2 bottom-to-top (Hanunó'o, Ogham).
- **Layouts:** 3 boustrophedon (archaic Greek, Sabaean, Luwian), rongorongo, Ogham, and Egyptian, whose direction depends on which way the signs face.
- **Other fields:** whether the language is tonal, whether it is still spoken, and whether it is spoken or signed.
- **Caveat:** these facts are reference data I entered by hand, not derived. Lean checks only what is stated about the table: 70 distinct ISO codes, the counts, and that exactly five languages (`pgl`, `grc`, `xsa`, `hlu`, `rap`) need their layout undone before braiding.

**5. Theorem provers and logics**
- **Mainstream provers see only the permutation** (`ProverExchange.lean`). A logic that lets hypotheses be reordered freely sees only a braid's permutation: two braids act the same on hypotheses exactly when their permutations agree.
  - Crossing twice, \(\sigma_i^2\), is invisible to such a logic but is not the trivial braid.
  - Each permutation comes from infinitely many braids, and what such a logic cannot see includes the whole linking matrix.
- **Prover register:** I listed 16 provers. 15 allow free reordering (Lean, Rocq, Agda, Isabelle, the HOL systems, Mizar, Metamath, …); Grail, a grammar prover, allows none; none uses braided reordering. So these provers can hold a braid only as data defined inside the logic, as QBX already does in Lean, never through their built-in rules.
- **Lambek calculus** (`LambekDirection.lean`). This is the logic of word order, with no reordering. Reversing the writing direction and swapping its two implications, `/` and `\`, turns valid derivations into valid derivations. Example: the English verb type `(np\s)/np` becomes `np\(s/np)`. I also proved that reordering is not allowed there: `p, q ⊢ p•q` holds but `q, p ⊢ p•q` does not.

**Other structural features to integrate.** Section 6 of the design note ranks them. The ones forced by these results:
- a step that converts text to logical order before braiding;
- recording the mirror-image convention used for each braid;
- either keeping language strands returning to their own positions, or reporting only the component-level linking numbers.

Further suggestions there:
- direction operations in the Python braid code;
- nested right-to-left/left-to-right runs;
- stacked marks such as vowel points, which are not a simple sequence;
- annotating Egyptian sign direction;
- translation as a map between braid groups;
- a framing convention, needed before tone or self-linking can be recorded.

The correspondences for speech (speech has a single time direction; signs made simultaneously with two hands match crossings that commute) and for proof direction are recorded as design observations and are not formalised. Markov's theorem is still not formalised, so "link invariant" here means "unchanged by Markov moves". No Python code was changed.

# Summary of changes for run cec11261-9dff-42e6-8a42-f1252c76480f
I fixed the `twinClass` name clash, removed the duplicate theorems, and wrote the project overview. The libraries `QBXFormal`, `Sovereign`, `RequestProject`, `SovKernel`, `Refinery`, `SpookyPrimes` and `Tools` all build, and no `sorry` was added. Everything is committed.

**1. The `twinClass` clash.** The two definitions were different things, so I renamed one rather than merging them:
- `Sovereign` keeps `twinClass`, the map from a sector vertex to its index pair.
- `RequestProject`'s version (the vertex set of a twin class in any simple graph) is now `Sovereign.Graph.twinFiber`, and `mem_twinClass` is now `mem_twinFiber`. Four files changed.

All six libraries can now be imported into one Lean file. The only clash left is that `Sovereign.Organism.Demo` and `ResearchSwarm` both define `main`, as before.

**2. Duplicate theorems.** Of the 186 groups of identical statements, every group inside a single library is now down to one copy. In total I removed **213 declarations**: 137 theorems and 76 `@[deprecated]` aliases left over from an earlier renaming. This includes three new duplicate pairs in QBX that appeared after the original export.
- Every reference now points to the kept name.
- `@[simp]` and similar attributes were moved onto the kept copy, so each file's simp lemmas are unchanged.
- I added 24 imports, all within a single library.
- I first tried four other imports, but with them several files didn't finish building after 30 minutes. I withdrew those four and handled those groups by stating the lemma once in a file both sides already import, or by importing in the other direction. For example, `CD.ext` is now stated once in `CayleyDickson.lean`.

I regenerated the theorem graph: 26,348 declarations and 16,370 theorems. Eight duplicate groups remain, on purpose:
- **Seven pairs across libraries.** For example, `Refinery` re-proves five XOR lemmas from `Sovereign`. Merging these would make one library depend on another, such as the default `Refinery` target depending on all of `Sovereign`.
- **One instance.** `instIsFiniteMeasureRealμ` is just the structure field `isFinite`, but typeclass search needs it as an instance.

Every removed name and its replacement is listed in `data/theorem_graph/DEDUP_2026-10-09.md`, and `data/theorem_graph/README.md` has the new numbers. Some old audit reports in `unsorted/sov/artifacts/` still mention removed names; the table resolves them.

**3. Overview and directions:** `QBX/docs/PROJECT_OVERVIEW_2026-10-09.md`, linked from `JLN_REVIEW.md`. It covers what is in each library and the Python and database side, what has been machine-checked, what the JLN review established, and how the parts connect. The ranked directions are:
- **Small and ready now:**
  - The four unproved Lean claims the planned "QBX Live" engine relies on (merges, fixed points, coded decoding, and the "final chord" depending only on the braid; the fourth is nearly free).
  - The rest of `plan_2.md`'s total Hopf invariant, with the framing convention made explicit. Simple counting shows `writhe − n` is unchanged by conjugation and positive stabilisation but drops by 2 under negative stabilisation; this is arithmetic only, not yet proved in Lean.
  - Linking numbers of torus-link components.
  - A second round of clean-up: a shared core library for the cross-library pairs, and replacing `native_decide` (used in 55 files) where possible.
- **Medium effort:**
  - A ledger attribute to replace the habit of re-stating theorems as `…_settled` entries, which caused most of today's duplicates.
  - An automatic specification audit that flags theorems whose proof just restates a hypothesis — the problem JLN's critiques keep hitting.
  - The error-correction half of topological protection on the existing toric code.
  - Language translation stated as a braid-group map, with proofs of which invariants it preserves.
- **Larger:** ζ_B′(0) in Lean, the structural encoder's targets S5/S6, a real 70×70 linking pipeline, and Markov's theorem.

The overview also lists the decisions that need you or the author: the open Phase 3 items, starting Phase 4, the JLN corrections, and which gematria convention to use.

I didn't run the Python tests; Python code wasn't touched.

# Summary of changes for run 41115c20-e3f2-4ae3-bf05-3dae3c653257
I picked up the first open item from `QBX/docs/design/JLN_REVIEW.md` §4, the closure-linking formula. Last session's strand linking matrix is now a proved invariant of the closed link, which is what `plan_2.md` asks for when it calls linking numbers "integer-valued and topologically stable". `lake build QBXFormal` succeeds (8119 jobs). The new file has no `sorry`, and its main theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

**New file: `QBX/Formal/ClosureLinking.lean`** (imported from `QBX/Formal.lean`, registry entry H-132)
- **Definitions:**
  - The components of a braid's closure are the cycles of its permutation (`closureComponents`); `numComponents` counts them.
  - The linking number of two components is \(\tfrac12\sum_{a\in C,\,b\in D} M_{ab}\), where \(M\) is the crossing matrix (`linkingNumber`).
  - `linkingSpectrum` is the list (multiset) of linking numbers over ordered pairs of distinct components.
- **The linking numbers are whole numbers.** `crossMatrix_mod_two` shows that, mod 2, the crossing matrix just records which pairs of strands the braid's permutation swaps in order. So block sums over whole closure components are even (`blockSum_even`), and halving them is exact (`two_mul_linkingNumber`).
- **They are link invariants.** The number of components and the linking spectrum are unchanged by conjugation by any braid (`*_conj`) and by stabilisation \(B \mapsto \sigma_1^{\pm1}\cdot\mathrm{shift}(B)\) (`*_stab`). So they are equal for any two braid words related by Markov moves (`numComponents_markov`, `linkingSpectrum_markov`); this uses the project's existing `MarkovEquiv` relation from `JonesMarkov.lean`. Markov's theorem, which says Markov classes are exactly the isotopy classes of closed links, is classical and not formalised.
- **Examples:** the Hopf link \(\sigma_1^2\) has spectrum \(\{1,1\}\), its mirror image \(\sigma_1^{-2}\) has \(\{-1,-1\}\), and the two-component unlink has \(\{0,0\}\). So no two of these three are related by Markov moves (`hopf_not_markovEquiv_unlink`, `hopf_not_markovEquiv_mirror`, `mirrorHopf_not_markovEquiv_unlink`).

**Documentation:**
- `JLN_REVIEW.md` has a new §3 item 7, and the §4 open item is marked done.
- §4 now notes the part of `plan_2.md`'s "total Hopf invariant" that is still open: the self-linking (writhe) part changes under stabilisation, so it is not a link invariant without extra conventions.
- I also updated `HYPOTHESIS_REGISTRY.md` (H-132), a docstring pointer in `LinkingMatrix.lean`, and the session log.

**Practical consequence for the "70×70 matrix" idea:** the stable quantities are linking numbers between closure components, not the raw strand-by-strand matrix. I argue in the review that the raw matrix is not itself a link invariant; that argument is not machine-checked.

The Properties table has one new definition and three new results, all marked proved. All work is committed.

# Summary of changes for run d331462a-5415-4643-9a71-3fa1826a2b55
I reviewed JLN's work against `plan.md`, `plan_2.md` and `rigor_check.md`, and added Lean files that check her key claims plus one new feature. Everything builds cleanly as part of `QBXFormal`, with no `sorry` and only the standard axioms. All the work is committed, and the 10 results in the Properties table are marked proved.

**Audits** (in `QBX/Formal/JLN/`):
- **Connes rigidity:** `ConnesAudit.lean` shows that the critique's obstructions work for direct products but fail for the semidirect product \(\mathbb{Z}^2 \rtimes SL(2,\mathbb{Z})\): its centre is trivial, the conjugacy classes of lattice elements are infinite, and projecting onto the lattice is not a homomorphism. It also shows that her function-valued Kazhdan axiom wrongly rules out \(SL(3,\mathbb{Z})\), which does have property (T). `ConnesSkeleton.lean` proves her ten-axiom package can be satisfied exactly when Connes' conjecture holds, so the Lean appendix adds no evidence beyond the results it cites.
- **Furey:** `FureyAudit.lean` proves that a direct sum of two non-trivial rings never maps injectively into a domain, so \(\mathbb{H}\oplus\mathbb{C}\oplus\mathbb{R}\) does not embed in \(\mathbb{H}\). It also covers the dimension count (8 vs 15), the corrected equal-trace ratio, and the fact that the Hopf map is not injective.
- **Forcing Core:** `ForcingCoreAudit.lean` shows that \(\mathbb{Z}[x]\otimes\mathbb{Z}[y]\) is a domain, so "the cohomology is a domain" does not rule out product decompositions (Kernel 2). Kernel 4 turns out to be an assumed hypothesis, not something derived.
- **Hopf spectral:** `HopfSpectralAudit.lean` proves \(\zeta_B(s)=\zeta(s-2)-\zeta(s)\) and \(\zeta_B(0)=1/2\). It also shows that \(k(k+2)\) is never a perfect square and that the Clebsch–Gordan cascade reaches arbitrarily large spins.
- **Microtubule QEC:** `MicrotubuleAudit.lean` gives a counterexample to her Theorem 1 ("holonomy protection") and proves the corrected version: holonomy is unchanged by gauge transformations. It also checks the count of 232 intersections vs 145, and that a distance-12 code corrects only \(\lfloor (d-1)/2\rfloor = 5\) errors, not 6.
- **Verlinde / Paradox Lost:** `VerlindeAudit.lean` proves the black-hole ⊗ radiation split exists only at \(m\in\{0,k\}\) and that \(S_{00}\in(0,1)\). At level 2 the Verlinde formula gives \(N=0\) where her rule gives 1.

**Feature:** `QBX/Formal/LinkingMatrix.lean` implements the strand linking matrix from `plan_2.md`. It is a homomorphism from the braid group \(B_n\) to \(\mathbb{Z}^{n\times n}\rtimes S_n\). The matrix is unchanged under the R01–R03 moves, is symmetric, and has a zero diagonal; the Hopf link entry is 2.

**Documentation:** `QBX/docs/design/JLN_REVIEW.md` has the obstacles found (O1–O7), a verdict for each paper, the features added, and the open items. Registry entries H-124 to H-131 are in `QBX/Formal/HYPOTHESIS_REGISTRY.md`.

**Not machine-checked:** some analytic points in the review are cited, not formalised. These include the Theorem 17 uniqueness statement (it holds only up to \(a\star d+b\)), the classical value of \(\zeta_B'(0)\), the Künneth identification of the cohomology rings, and the S³ spectrum as recorded in `plan.md`.

# Summary of changes for run 870b7c3e-4462-434a-91fe-6ebffc1a89a0
I reviewed the bridge document and checked in Lean every claim in it that makes a precise statement about something QBX already defines. Most hold, but three are wrong as written. I also built and proved the structural braid encoder the document recommends building first. `lake build QBXFormal` and `lake build Tools.StructuralBraid` succeed, the new files contain no `sorry`, and the main theorems use only the standard axioms.

The file isn't at `QBX/docs/harmonic_bible_braid_bridge.md`; it's in `QBX/docs/research/`, and the copy in `QBX/docs/design/` is identical. The full claim-by-claim review is in `QBX/docs/research/harmonic_bible_braid_bridge_REVIEW.md`.

**Three claims are false** (proofs in `QBX/Formal/BibleBridgeAudit.lean`):
- **Gematria and the braid layer (claims A4/F5).** The document says gematria is a coarser view of the braid that factors through its abelianization. It isn't even a function of the braid: `אבא` and `באב` give the same braid on 23 strands but have values 4 and 5 (`gematria_not_braid_function`). Every map from the braid group to an abelian group gives all generators the same value, so gematria cannot be one of them. What gematria is actually unchanged by is reordering the letters.
- **The commutator \(\sigma_1\sigma_2\sigma_1^{-1}\sigma_2^{-1}\).** Its writhe is 0, but its permutation is a 3-cycle, not the identity, so it is not a pure braid (`commutator_not_pure`).
- **The name values.** The quoted values (Elohim 86, Adam 45, Abram 243, …) are only right when final letters count as their base letter. QBX's seeded table counts finals as 500–900, which gives Elohim 646, Adam 605 and Abram 803, so `מה ≠ אדם` (`names_standard`, `names_hechrachi`). A smaller error: 81/80 is the syntonic comma, not the Pythagorean comma.

**Confirmed claims** (same file):
- The current letter-based encoder gives `a+b=b+a` and `a+b<b+a` the same braid, and gives `x+y=y+x` a different one.
- Test 1, sharpened: the 22 letters get 22 distinct generators exactly when there are at least 23 strands.
- Adam·bride is the trivial braid; Adam·Lilith has Adam's permutation and writhe but is a different braid.
- The permutations reachable from 7-strand braids number \(7! = 5040\), and a nontrivial braid maps to the identity permutation.
- The 2-strand braid group is commutative; with 3 or more strands it is not.
- For odd \(p \ge 3\) there are \((p-3)/2\) star polygons, so 4 for \(p = 11\).
- The arithmetic facts: \(49/50\), \(969 = 3 \cdot 17 \cdot 19\), 127 is a Mersenne prime, \(147 = 3 \cdot 7^2\).

**The structural encoder** (`QBX/Formal/StructuralBraid.lean`) reads a model of the elaborated Lean term instead of its characters. Four of the document's six targets are proved:
- **S1:** renaming free variables, or changing binder names, doesn't change the braid.
- **S2:** the braid depends only on a canonical form, and that form doesn't change under renaming either.
- **S3:** for any choice of constant codes and any number of strands, `∀ a b : ℕ, a + b = b + a` and `∀ a b : ℕ, a + b < b + a` get different braids (writhe 41 vs 43).
- **S4:** for terms without free variables, the braid of an application is the function's braid, then the argument's, then a fixed coupling braid.

S5 can't be proved as written because it needs a definition the document doesn't give, and S6 is still open. A new command, `#structural_braid Nat.add_comm` (in `Tools/StructuralBraid.lean`), runs the encoder on real declarations; the step that reads Lean's terms into the model is not verified. A check that runs during the build confirms that `Nat.add_comm`'s type reads in as exactly the term used in S3.

**Python:** the new `QBX/tests/test_kabbalah.py` (43 tests) repeats these checks against the Python code, including the doc's Tests 1, 2 and 4. Test 3 is left out because the document leaves the choice of categories open. `pytest` installed from `QBX/requirements/`; numpy, cbor2, pyyaml and hypothesis came from PyPI, since the network was available and the cbor2 wheel there is a Windows build. Results: `QBX/tests` has 592 passed and 2 skipped; `QBX/foundation/tests` has 325 passed.

I added registry entries H-122 and H-123, README rows, a session-log entry, and the main results to the Properties table. Everything is committed.

## Suggested follow-up

One inconsistency in the project itself: the Lean gematria table seeded by migration 014 (`Gematria.standard`) values the final letters at 500–900. The Python tests (`test_bible_braid.py`) and the bridge document value them as their base letters, so the same word can get two different values. I can make the two agree on whichever convention you choose.

# Summary of changes for run 3082d170-c891-4526-8c18-7c6810299930
**Short answer:** QBX's Lean library was working. The Sovereign/SovKernel body under `unsorted/sov` had never been wired into the root project, because the root `lakefile.toml` pointed those three libraries (`Sovereign`, `RequestProject`, `SovKernel`) at `srcDir = "."`. There are no such folders at the root, so Lake found no source files. I pointed them at `unsorted/sov` and added the `sovkernel` executable, which until now was only declared in the sub-project's lakefile. After that, everything compiled without any changes to the theorem files.

**Build status after the fix**
- Default build (`QBXFormal`, `Refinery`, `SpookyPrimes`): 8138 jobs, success.
- `lake build Sovereign RequestProject`: 8995 jobs, success.
- `SovKernel`: builds, and `lake exe sovkernel selftest` prints `ALL CHECKS PASSED`.
- No `sorry` warnings in any library.

**Two limits remain:**
- `Sovereign` and `RequestProject` can't be imported into the same Lean file, because both define `Sovereign.Graph.twinClass`. It is the only declaration name the six libraries share. Every other combination loads together.
- `Sovereign.Organism.Demo` can't be imported alongside the rest of `Sovereign`, because it and `Sovereign.Organism.ResearchSwarm` both define `main`. It is therefore left out of the export.

**Converting the theorems to the format you asked for**
- **Exporter:** `Tools/TheoremGraph.lean` is a new command, `lake exe theoremgraph <outDir> <Modules…>`. It reads the compiled libraries, so it sees statements and proofs exactly as Lean checked them. For every written declaration it outputs:
  - the statement as an AST tree (nested JSON; variables numbered by position rather than name, nodes past a 4000-node cap replaced by a marker);
  - a pretty-printed statement and its source line;
  - the project declarations used by the statement and by the proof.
  Automatically generated helper declarations are skipped.
- **View builder:** `scripts/theorem_graph/build_views.py` (standard-library Python) turns an export into:
  - **Hypergraph:** each declaration is one hyperedge whose tail is its premises (one for the statement, one for the proof). It is saved in HIF format (`hypergraph.hif.json.gz`).
  - **AST index:** a hash of each statement that ignores variable names, plus `duplicates.json`, which groups theorems with identical statements.
  - **Poincaré-disk embedding:** the library → module → declaration tree is placed with Sarkar's construction (`poincare.csv/json`, plus a picture in `poincare.svg`). The distance formula is the same as `poincareDist` in `RequestProject/Hyperbolic/PoincareMetric.lean`, and the placement steps rely on isometry facts proved in that file. The Python code itself is not verified.

**Results** (in `data/theorem_graph/`, raw exports gzipped per library, merged view in `all/`)
- 26,230 declarations: 16,370 theorems and 8,498 definitions, across 981 modules, with 42,675 hyperedges.
- 504 statement trees were cut off at the size cap.
- 186 groups of theorems have identical statements. Most are restated Cayley–Dickson lemmas, for example `CD_add_im`, `cd_add_im`, `CD.add_im'` and `TowerStrong.cd_add_im`; these are candidates for merging.
- Embedding quality: over 20,000 random pairs, hyperbolic distance divided by tree distance has median 0.78 and maximum 1.0, and 99 % of pairs are at least 0.38. The lowest values are siblings in very large modules. Only the module tree sets the positions; the premise hypergraph is a separate output and does not affect them.

Formats, commands and the numbers above are written up in `data/theorem_graph/README.md`. No new theorems were proved, so the Properties table is unchanged. All work is committed.

## Suggested follow-up

One issue that may be unintended: `Sovereign.Graph.twinClass` is defined in both `unsorted/sov/Sovereign/Graph/SectorTwinQuotient.lean` and `unsorted/sov/RequestProject/SectorTwinQuotient.lean`. Because of this, `Sovereign` and `RequestProject` can't be loaded into one Lean environment, which means no single theorem graph covers all six libraries at once. If you like, I can rename or merge the duplicate copy and then go through the 186 groups of identical statements in `data/theorem_graph/all/duplicates.json`.

# Summary of changes for run f5c09e0a-2ba1-4127-835f-199c46296641
I wrote the Phase 4 fast-track plan, called **QBX Live**, in `QBX/docs/phase_4_fast_track.md`. It is based on the research brief in `docs/phase_4_planning.md`, the paper library in `docs/quanta/`, the ESP32-S3 hardware notes in `reference/primary/`, and what Phases 0–3 and the foundation workstreams already built. This was planning only: no code, migrations or Lean files changed, and nothing was built or tested.

**The main ideas**
- **How the work changes:** Phases 0–3 required every item to be done three ways (SQL migration, Python reference, Lean proof) and then frozen. Phase 4 becomes a live engine in a new package `src/qbx_live/` that only reads frozen code. The rules that stay are: no edits to frozen interfaces, exact answers checked against the Phase 2/3 reference, honest claims, and tests and Lean builds kept passing.
- **Lean moves off the critical path:** it becomes a trailing "seal lane" that proves only the six claims the engine actually relies on (S1–S6). S1 and S2 are already proved: Garside normal form decides braid equality (`GarsideUniqueness.lean`), and the rewrite loop terminates (`BraidTrace.lean`).
- **Much of it already exists:** Garside normal forms already merge equivalent histories into one answer (the brief's goal G5). `fingerprint_hash` gives the same cache key for equal braids, rewrite traces become an event stream, and the ws3 consensus checks serve as the consistency test. DHT routing, the anyon and Burau representations (sound sources), the SVG and view code (picture) and the ws7 benchmark harness are reused as well.
- **Architecture:** an event bus feeds a loop that repeats an update until the state stops changing (the fixed-point approach), with caching that recomputes only what changed and coded workers that tolerate slow ones. An adaptive controller picks a strategy from live time, work, communication and memory measurements. Output goes to the browser (sound, picture, live dashboard) and to CSV logs.
- **Sound mapping:** each crossing plays a note and each rewrite rule has its own sound. Writhe controls stereo position, the permutation sets the chord, and eigenphases become drone partials. How far the engine is from the fixed point is played as dissonance, so you hear it settle into a clean chord when it converges. The final chord depends only on which braid it is, so equal braids sound equal (seal-lane item S6).
- **Hardware:** the ESP32-S3's 14 touch pads cover exactly σ₁…σ₇ and their inverses, giving live input for 8-strand braids. One core runs the touch sensing and radio, the other a small local rewrite engine; up to 3 boards can mesh over ESP-NOW. The Fano-plane mapping is an artistic option behind a flag, with no mathematical claim.

**Schedule:** a 2-day bootstrap, then 6 one-week sprints with a Friday demo each. Every sprint has a numeric exit target:
1. Baseline measurements.
2. First sound and picture.
3. Caching and the fixed-point loop.
4. Coded computation and the adaptive controller.
5. Hardware and the decisive A/B/C experiment from the brief.
6. Hardening, the seal lane, and a show.

**Also in the plan:**
- Metrics and real-time targets.
- The brief's nine benchmark classes A–I mapped to concrete QBX workloads.
- A sorting of the `docs/quanta/` papers into "use now", "Phase 5", "limits and negative results" and "background".
- Guardrails: no quantum or time-travel advantage is claimed; finding fixed points can itself be very hard; strategies are compared against a strong classical baseline; and a stop rule says that if the new approach doesn't beat the baseline, that is reported as a negative result.
- A draft acceptance checklist, risks, and a first-48-hours checklist.

**Decision for you (Q-009 in `agents/memory/open_questions.md`):**
- Do you accept this as Phase 4?
- Is the proposed stack OK: a Python engine with browser WebAudio/Canvas and Dask?
- Will ESP32-S3 boards be available for Sprint 5?

The plan moves on-chain anchoring (the old "Phase 4" placeholder) to the Phase 5 backlog. The unfinished Phase 3 items (2, 5, 6) can run alongside in the seal lane.

I also added a Phase 4 section to `QBX/README.md` and a session entry to `agents/memory/session_log.md`. All changes are committed.

# Summary of changes for run 20a23a31-f3ab-444b-89df-2d79596833c2
I indexed the 79 PDFs in `QBX/docs/reference/` by relevance in `QBX/docs/reference/README.md`. The surface-braid papers by Bellingeri and coauthors are the closest to the formal layer, so I formalized parts of two of them in two new Lean files. `lake build QBXFormal` succeeds (8108 jobs) and neither new file contains `sorry`. The axiom audit now covers 239 declarations, all using only the standard axioms.

Indexing: \(\Gamma_1\) is the whole group, as in the papers. Lean's `lowerCentralSeries k` is \(\Gamma_{k+1}\).

**`QBX/Formal/TorusBraidLCS.lean` (registry H-120, SPEC TB6–TB7)** follows Bellingeri–Gervais–Guaschi, *Lower central series for surface braid groups*: Theorem 1 at genus 1 and Proposition 4.
- For \(n \ge 2\), the abelianization of \(B_n(T^2)\) is \(\mathbb{Z}^2 \oplus \mathbb{Z}/2\) (`abelianizationEquiv`). The project previously only checked this value numerically.
- For \(n \ge 3\):
  - \(\Gamma_3 = \Gamma_4 = \cdots = \ker(\text{heisRep})\).
  - \(B_n(T^2)/\Gamma_3 \cong \mathrm{Heis}(2n)\) and \(\Gamma_2/\Gamma_3 \cong \mathbb{Z}/n\).
  - The group is not residually nilpotent.
  - Every homomorphism to a nilpotent group factors through `heisRep` (`exists_factor_heisRep`).
- The planar writhe does not extend to torus braids (`not_exists_writhe`).
- For planar braids with \(n \ge 2\), \(\Gamma_i(B_n) = \ker(\text{writhe})\) for all \(i \ge 2\), and the abelianization of \(B_n\) is \(\mathbb{Z}\).

**`QBX/Formal/TorusBraidTwoStrand.lean` (H-121, SPEC TB8)** follows Bellingeri–Godelle, *Questions on surface braid groups* §4, together with Theorem 3(b)(i) of the first paper. It works in `TorusBraidGroup 2` with \(t=\sigma^{-1}\), \(P=\sigma^{-1}a\), \(Q=\sigma^{-1}b\), \(C=tPQ\).
- \(P^2\) and \(Q^2\) are central, and \(C^2 = P^2Q^2\).
- `toW` maps the group onto \(\mathbb{Z}/2 * \mathbb{Z}/2 * \mathbb{Z}/2\), and its kernel lies inside the subgroup generated by \(P^2\) and \(Q^2\).
- A 2-strand torus braid is determined by its image under `toW` and its total winding (`toW_prod_windHom_injective`, `eq_iff_toW_windHom`).
- For \(i \ge 2\), \(\Gamma_i(B_2(T^2)) \cong \Gamma_i(\mathbb{Z}/2 * \mathbb{Z}/2 * \mathbb{Z}/2)\) via `toW` (`lowerCentralSeriesEquivW`).
- Not formalized: the conjugacy problem, and the positive presentations for higher genus.

**Docs:** I updated the registry, SPEC, `QBX/README.md`, `PHASE_D_INTEGRATION_LOG.md`, the D3 status file and `ARISTOTLE_SUMMARY.md`. In `torus_braid_full/heisenberg.py` and `abelian.py` only the docstrings changed. I couldn't run the Python tests because pytest isn't installed. The main results are listed in the Properties table, and all the theorem entries are marked proved.

# Summary of changes (reference-PDF follow-up, 2026-10-05)
I went through the new PDFs in `QBX/docs/reference/` and indexed all 79 by relevance in `QBX/docs/reference/README.md`. The surface-braid papers by Bellingeri and coauthors are the ones closest to the formal layer, so I formalized two of them. `lake build QBXFormal` succeeds (8108 jobs). Neither new file contains `sorry`, and the axiom audit now covers 239 declarations, all using only the standard axioms.

**`QBX/Formal/TorusBraidLCS.lean` (registry H-120, SPEC TB6–TB7):** Bellingeri–Gervais–Guaschi, *Lower central series for surface braid groups*, Theorem 1 at genus 1 and Proposition 4.
- `abelianizationEquiv`: \(B_n(T^2)^{ab} \cong \mathbb{Z}^2 \oplus \mathbb{Z}/2\) for \(n \ge 2\). This value was previously only checked numerically.
- For \(n \ge 3\): \(\Gamma_3 = \Gamma_4 = \cdots = \ker(\text{heisRep})\) (`lowerCentralSeries_eq_ker_heisRep`, `lowerCentralSeries_three_eq_two`), \(B_n(T^2)/\Gamma_3 \cong \mathrm{Heis}(2n)\), \(\Gamma_2/\Gamma_3 \cong \mathbb{Z}/n\), and the group is not residually nilpotent.
- `exists_factor_heisRep`: every homomorphism to a nilpotent group factors through `heisRep`.
- `not_exists_writhe`: the planar writhe does not extend to torus braids.
- For planar braids: \(\Gamma_k(B_n) = \ker(\text{writhe})\) for \(k \ge 1\) (Mathlib index), and \(B_n^{ab} \cong \mathbb{Z}\).

**`QBX/Formal/TorusBraidTwoStrand.lean` (H-121, SPEC TB8):** Bellingeri–Godelle, *Questions on surface braid groups*, §4, and Bellingeri–Gervais–Guaschi, Theorem 3(b)(i). It works in `TorusBraidGroup 2` with \(t=\sigma^{-1}\), \(P=\sigma^{-1}a\), \(Q=\sigma^{-1}b\), \(C=tPQ\).
- \(P^2\) and \(Q^2\) are central, and \(C^2=P^2Q^2\).
- `toW` maps onto \(\mathbb{Z}/2 * \mathbb{Z}/2 * \mathbb{Z}/2\), and its kernel lies inside \(\langle P^2, Q^2\rangle\).
- `toW_prod_windHom_injective`: a 2-strand torus braid is determined by its image under `toW` together with its total winding.
- `lowerCentralSeriesEquivW`: \(\Gamma_k(B_2(T^2)) \cong \Gamma_k(\mathbb{Z}/2*\mathbb{Z}/2*\mathbb{Z}/2)\) for \(k \ge 1\).

**Docs:** the registry, SPEC, `QBX/README.md`, `PHASE_D_INTEGRATION_LOG.md`, the D3 status file and the Python docstrings in `torus_braid_full/` now point to these proofs.

# Summary of changes for run 22fe260c-1900-4ee0-8b40-9b22358262f5
I checked D3's relations for the torus braid group \(B_n(T^2)\) against the Bellingeri paper in `QBX/docs/reference/` (it is the arXiv:math/0110129v2 version). The relations are correct; the only mistake was which theorem they cite. I also added a Lean proof that the D3 group is the paper's group at genus 1. `lake build QBXFormal` succeeds (8106 jobs, no warnings), the new file has no `sorry`, and the axiom audit now covers 205 declarations, all using only the standard axioms.

**Comparison with the paper (Theorem 1.2, closed orientable surfaces, p. 2), at genus 1:**
- The braid relations and (R1) match.
- (R2) \(\sigma_1^{-1}a\sigma_1^{-1}a = a\sigma_1^{-1}a\sigma_1^{-1}\), and the same for \(b\), matches.
- (R3) only involves pairs of different handles, so it has no relations at genus 1.
- (R4) \(\sigma_1^{-1}a\sigma_1^{-1}b = b\sigma_1^{-1}a\sigma_1\) matches, including the final \(\sigma_1\) (not \(\sigma_1^{-1}\)).
- (TR) \([a,b^{-1}] = \sigma_1\cdots\sigma_{n-1}^2\cdots\sigma_1\), with \([x,y]=xyx^{-1}y^{-1}\), matches. I confirmed the exponents from the rendered page, not just the extracted text.

**The citation:** the code and docs cited Theorem 1.1. That theorem covers punctured surfaces and has no (TR) relation. I changed it to Theorem 1.2 in `TorusBraid.lean`, `torus_braid_full/words.py`, `PRESENTATION.md`, the SPEC, the registry and the D3 status file. Page and theorem numbers are from the arXiv copy; I couldn't compare against the J. Algebra version.

**New Lean file `QBX/Formal/TorusBraidBellingeri.lean` (SPEC TB5, registry H-119):**
- `closedRels g n` writes out Theorem 1.2's relations as printed, for any genus \(g\), including (R3) and far commutation for \(|i-j|\ge 2\).
- `torusBraidEquivBellingeri` proves `TorusBraidGroup n ≃* PresentedGroup (closedRels 1 n)`, sending \(\sigma_i\mapsto\sigma_i\), \(a\mapsto a_1\), \(b\mapsto b_1\).
- This does not prove that the paper's presentation describes the braid group itself (the fundamental group of the configuration space); that is still taken from the paper.

**Docs and other updates:**
- `ws5_braid_ops/PRESENTATION.md` has a table comparing each relation with the paper, in place of the old caveat.
- The "compare with the paper" item is closed in the phase_d README, the D3 status file, `ASPECTS_REGISTER.md` (B-04) and `AGENT_WORKSTREAMS.md`.
- New entries in the registry, the axiom audit and the `README.md` table; `PHASE_D_INTEGRATION_LOG.md` and `ARISTOTLE_SUMMARY.md` are updated.
- I only edited a docstring in the Python code and checked that the file still parses. The Python tests weren't run, because `pytest` isn't installed here.

**Still open, unchanged by this run:** your `./seal.sh` signature, D5's learned curvature, and Phase E. Everything is committed.

# Summary of changes for the D3 source-check run (2026-10-04)
D3's presentation of `B_n(T²)` was compared line by line with Bellingeri's paper (arXiv:math/0110129v2, in `QBX/docs/reference/`). All relations match **Theorem 1.2** (closed orientable surfaces) at genus 1: the braid relations, (R1), (R2), (R4) and (TR). (R3) is empty for genus 1. The one error was the citation, which said Theorem 1.1; that theorem is the punctured-surface presentation and has no (TR). The citation is corrected everywhere it appeared. New `QBX/Formal/TorusBraidBellingeri.lean` (SPEC TB5, registry H-119) writes Theorem 1.2 out for every genus as printed and proves `TorusBraidGroup n ≃* PresentedGroup (closedRels 1 n)`. `lake build QBXFormal` succeeds (8106 jobs). The axiom audit covers 205 declarations, all on standard axioms, with no `sorry`.

# Summary of changes for run 7741b3aa-26cb-466c-ba18-28361c1ecdb1
The stray top-level `$QBX/` folder is merged into `QBX/`, and Phase D and WS9 are finished. Every open decision followed the recommendation. One step is left for you: run `cd QBX && ./seal.sh` once to sign the updated contract files. Until you do, `bash QBX/health.sh` will show 4 expected failures: the `frozen` check and 3 signature tests.

**Checks:** `lake build QBXFormal` succeeds (8105 jobs) with no `sorry`. The axiom audit covers 202 declarations, and all of them use only the standard axioms. `health.sh` passes `imports`, `phase_d`, `lean`, `sorry`, `bench` and `demo`. In `tests`, 871 passed, 1 was skipped and 3 failed; those 3 are the signature tests above.

**The merge:** the Connections layer (`Formal/Connections/*`, `Formal/Connections.lean`, `docs/CONNECTIONS.md`) is now in `QBX/` and imported from `QBX/Formal.lean`. A duplicate `TorusLinks.lean` was dropped.

**Phase D (`QBX/foundation/phase_d/`), closed apart from your signature**
- Amendments FA-010 (edge connectivity and fork kinds in the consensus report) and FA-020 (hyperbolic factor in `Address`) are applied.
- D6's `SU(2)_k` code moved to `qbx_ir.anyon` (`su2k_model`), with its tests (19 pass). `phase_d/` now holds only records.
- The phase_d README, the D4/D5/D6 status files and manifests, and `QBX/docs/foundation/PHASE_D_INTEGRATION_LOG.md` are updated.

**WS9 (`ws9_integration/`, `ws9_protocol/`): roadmap steps 1–12 are done; only step 13 (Phase E) remains**
- **Decisions D-1 to D-5** are recorded in `DECISIONS_REQUIRED.md`. `ws8_spec/ARCHITECTURE.md` is rewritten around them: two registers, one role per torus with time on a path, the ordering policy, and the adversary and timing model ("authentic events").
- **Amendments FA-050 to FA-053** are applied: XOR mask and Toffoli gate, `RepresentedGateProtocol` with `Circuit` and `linear_apply`, the strand-indexed torus with `WreathGate`, and `unlinked_components`. Together with FA-010 and FA-020 this makes interface version 1.2.0, queued for your signature.
- **Six new Lean files in `QBX/Formal/`** (SPEC rows W9–W14, registry H-113–H-118):
  - `AddressEdgeConnectivity.lean`: the edge connectivity of \(Q_n \square T^k_M\) equals its degree, \(n + \sum_j (1 \text{ if } M_j = 2 \text{ else } 2)\).
  - `ToricAnyons.lean`: the toric-code anyon model satisfies the pentagon and hexagon equations, and the `e`–`m` monodromy is \(-1\). It is also added in Python as `toric_code_model`.
  - `GateLocality.lean`: `σ_i` moves an address by 0 or 2. Masked gates are isometries and can map any address to any other. No masked gate is a Toffoli gate.
  - `StrandTorus.lean`: \(B_n(T^2)\) acts on \(Q_n \square (T^2_m)^n\), and this action tells `a` apart from \(\sigma_1 a \sigma_1^{-1}\), which the existing total-winding gate cannot do.
  - `ToricBraidLogicals.lean`: torus braids map to logical Pauli operators of the toric code. The image acts trivially iff both total windings are even, and `e`/`m` commutation is the mod-2 intersection form of the windings.
  - `AddressTorusLedger.lean`: findings F-4 and F-5 restated on the address graph \(T^2_m\).
- The SPEC, hypothesis registry, axiom audit, `LAYER_MAP.md`, register (new status table), roadmap, log, READMEs, file map and `ARISTOTLE_SUMMARY.md` are updated. Six headline theorems are in the Properties table, marked proved.

**Still open:**
- The D3 relations for \(B_n(T^2)\) were transcribed from Bellingeri (2004) without the paper at hand, so someone should check them against the source.
- D5's learned curvature was not done.
- Phase E: real signatures (first item), a decoder, and a quantum representation.

Everything is committed.

# Summary of changes for the closing run (2026-10-04): `$QBX/` merged, Phase D and WS9 finished
Every open decision followed the recommendation. The stray top-level `$QBX/` folder (the Connections layer) was merged into `QBX/`. Phase D is closed, and WS9 roadmap steps 1–12 are done. `lake build QBXFormal` succeeds (8105 jobs). The axiom audit covers 202 declarations, all on standard axioms, with no `sorry`. `bash QBX/health.sh` passes everything except the signed-hash checks of the contract files. Those checks are expected to fail until you sign them: **run `cd QBX && ./seal.sh` once.**

- **Merge:** `Formal/Connections/*`, `Formal/Connections.lean` and `docs/CONNECTIONS.md` moved into `QBX/` and are imported from `QBX/Formal.lean`. A duplicate `TorusLinks.lean` was dropped.
- **Amendments (interface 1.2.0, queued for seal):**
  - FA-010: report edge connectivity and fork kinds.
  - FA-020: hyperbolic factor in `Address`.
  - FA-050: XOR mask and Toffoli.
  - FA-051: `RepresentedGateProtocol`, `Circuit`, `linear_apply`.
  - FA-052: strand-indexed torus, `WreathGate`.
  - FA-053: `unlinked_components`.
- **D6:** `SU(2)_k` moved to `qbx_ir.anyon` (`su2k_model`). `phase_d/` now holds only records.
- **New Lean files (SPEC W9–W14, registry H-113–H-118):**
  - `AddressEdgeConnectivity.lean`: L-1, \(\lambda(Q_n \square T^k_M) = \delta\).
  - `ToricAnyons.lean`: toric-code anyons are coherent, and the `e`–`m` monodromy is \(-1\).
  - `GateLocality.lean`: `σ_i` moves an address by 0 or 2. Masked gates act transitively. Toffoli is not a masked gate.
  - `StrandTorus.lean`: `B_n(T²)` acts on \(Q_n \square (T^2_m)^n\) and sees each strand's winding.
  - `ToricBraidLogicals.lean`: torus braids map to toric logical Paulis.
  - `AddressTorusLedger.lean`: F-4 and F-5 restated on the address graph.
- **Docs:** decisions recorded and `ARCHITECTURE.md` rewritten (two registers, torus roles, ordering policy, adversary model). `LAYER_MAP.md`, the register, roadmap, log, READMEs and the Phase D log are updated (`QBX/docs/foundation/PHASE_D_INTEGRATION_LOG.md`).
- **Still open:** your `./seal.sh` signature; comparing D3's presentation with Bellingeri (2004); and Phase E (signatures, decoder, quantum representation).

# Summary of changes for run 1d1b5eff-0c17-47ec-bde7-8d94125c2577
D3, D6 and D5 are now merged into the shared tree. The four WS9 cross-layer Lean files are in `QBX/Formal/`, and three items WS9 had left open are now proved in Lean. `lake build QBXFormal` succeeds (8084 jobs, no warnings). The axiom audit covers 153 declarations, and all of them use only the standard axioms. The last full `bash ./health.sh` run passed all eight checks: 832 tests passed and 1 was skipped, plus 16 Phase D tests. Everything is committed.

**Phase D (`phase_d/`), merged in the order D3 → D6 → D5**
- **D3:** `TorusBraid.lean` moved to `QBX/Formal/`, with SPEC rows TB1–TB4, registry row H-085 and audit entries. The Python code is now `ws5_braid_ops/torus_braid_full/`; its 46 tests pass under `foundation/tests/`. `BRAID_FULL_TWIST_NOTE` now points to the new code.
  - **Still to check:** the relations were copied from Bellingeri (2004) without the paper at hand, so they should be compared with the source.
- **D6:** `surface_code.py` is now in `ws4_toric/`, its results in `ws4_toric/SURFACE_CODES.md`, and the proposed Lean targets in `ws6_certificates/LEAN_TARGETS_D6.md`.
  - The `SU(2)_k` code stays in its own folder because its destination, `qbx_ir.anyon`, is outside the foundation. That move is your call.
- **D5:** `hyperbolic`, `cell_complex`, `curvature` and `product` are now in `ws1_geometry/`. `capacity.py` is in `ws7_benchmarks/`; it reproduces every table line of `ws1_geometry/CAPACITY.md`. I added property rows P1.6–P1.7; these are tested numerically only, with no Lean proofs. 42 tests pass.
  - **One change from the manifest:** I kept `cell_complex.py` as its own module instead of merging it into `curvature.py`.
- **Not applied:** the contract changes FA-020 (D5) and FA-010 (D4) need your decision. Nothing has been sealed.

**WS9 (`ws9_integration/`, `ws9_protocol/`)**
- **Moved unchanged:** `GateReachability`, `AddressBlindSpots`, `ToricTranslation` and `TorusLedgerSectors` (SPEC W1–W5).
- **Registry numbering:** the WS9 manifest suggested H-104 – H-107, but H-104 and H-105 were already taken. The rows are H-106 – H-112.
- **New Lean proofs (no `sorry`):**
  - `ToricDistance.lean` (W6): the toric code distance is exactly \(m\) for every \(m \ge 1\) (`toric_distance_eq`).
  - `ToricAddressEdges.lean` (W7): for \(m \ge 3\), the toric-code qubits correspond one-to-one with the edges of the address graph `addrGraph 0 2 (m,m)` (`toricEdgeEquiv`). For \(m = 2\) this fails (`toricEdge_not_injective_two`).
  - `WitnessRule.lean` (W8): this proves the layer-9 witness rule (P9.1), which had only a paper proof before. Every event graph the square rule produces sits inside the address graph and has no bridges, so every single-event fork is detected (`protocol_witnessGraph_not_isBridge`, `witnessGraph_perturb_detected`). The model includes only finalised squares, not message loss or retries.
- **Docs updated:** SPEC, registry, audit, `LAYER_MAP.md`, `ARCHITECTURE.md`, READMEs, `MASTER_PLAN.md`, `AGENT_WORKSTREAMS.md`, `ws9_protocol/PROPERTIES.md` and `WITNESS.md`.
  - **WS9 records:** its manifest, log, roadmap and decisions file are updated. `ASPECTS_REGISTER.md` has a new status table at the top; WS9 had marked D4 as missing, and that entry is now resolved.

**Still open**
- **L-1 not attempted:** whether the edge connectivity of the address graph equals its minimum degree. Only \(\lambda \ge 2\) is proved.
- Owner decisions D-1 to D-4 and the amendment sketches A-1 to A-4.
- The "WS9" name is used for two unrelated folders (`ws9_integration/` and `ws9_protocol/`); both READMEs now note this.

# Summary of changes for the 2026-10-04 integration run (D3, D6, D5, WS9)
D3, D6 and D5 are merged into the shared tree (in that order). The four WS9 cross-layer Lean files are in `QBX/Formal/`. Three items left open by WS9 are now proved in Lean: the toric code distance, the toric-qubit/address-edge bijection, and the protocol's witness rule. `lake build QBXFormal` succeeds (8084 jobs). The axiom audit covers 153 declarations, all on the standard axioms. `bash ./health.sh` passes all eight checks (832 tests passed, 1 skipped; 16 Phase D tests). Log: `QBX/docs/foundation/PHASE_D_INTEGRATION_LOG.md` (second run).

# Summary of changes for run d783bdb1-60f8-4ac8-aa15-cf5542ff3200
I added a new formal layer, `QBX/Formal/Connections/` (9 Lean files), that proves links between the braid, torus, hypercube, lattice, sphere, Hopf and Cayley–Dickson parts of QBX. I also tested 12 claims from `ideas/` in Lean, treating them only as candidates: 5 hold, 6 are false, and 1 is not a mathematical statement as written. Progress is documented in `QBX/docs/CONNECTIONS.md`, which has a map of the connections, a results table, the idea-claim verdicts, suggested uses for QBX, open items and a log.

The full library builds (`lake build QBXFormal`, 8091 jobs, imported via `QBX/Formal.lean`). The new files contain no `sorry`, `axiom` or `native_decide`, and every main theorem uses only the standard axioms.

**Results proved:**
- **Hopf maps along the Cayley–Dickson tower (C1):** the map \((x,y)\mapsto(2x\bar y,\ |x|^2-|y|^2)\) sends unit spheres to unit spheres exactly at levels \(n\le 3\) (ℝ, ℂ, ℍ, 𝕆), giving S¹→S¹, S³→S², S⁷→S⁴, S¹⁵→S⁸. At the sedenion level, a unit zero-divisor point on S³¹ goes to the origin. Over ℤ, the Hopf identity is equivalent to the composition law.
- **Quaternion Hopf fibration S³→S² (C2):** the map is onto, every fibre is exactly one circle, and it is equivariant under SU(2). In QBX terms, global phases are exactly the fibres.
- **Braids act on the torus (C3):** \(B_3 \twoheadrightarrow SL(2,\mathbb Z)\), with \(\Delta^2\mapsto -1\) and \(\Delta^4\mapsto 1\). The library's existing reduced Burau matrix at \(t=-1\) is exactly this map. It gives new gates on the torus factor \(T^2_m\), but these do **not** preserve address distances, so don't use them where distance preservation is assumed.
- **Hypercube ↔ torus (C4):** \(Q_{2k}\cong T^k_4\) via the Gray code, both as metric spaces and as graphs. A length-4 torus factor and two hypercube bits are interchangeable.
- **Lattices and spheres (C5, C6):** the 24 Hurwitz units are exactly characterised. They form a group, and the Hopf map sends them 4-to-1 onto the octahedron \(\{\pm i,\pm j,\pm k\}\). Multiplying by \(1+i\) matches them one-to-one with the 24 roots of \(D_4\). Three-strand braids map onto these 24 units, again with \(\Delta^2\mapsto -1\).
- **Torus links (C7):** the closure of \((\sigma_1\cdots\sigma_{p-1})^q\) has \(\gcd(p,q)\) components, counted as cycles of its permutation; the writhe is \((p-1)q\). So the Hopf link has 2 components and the trefoil 1.
- **E₈ (C8):** all 240 roots are classified, and every root has 56 neighbours in the root graph.

**Idea-file claims shown false in Lean:**
- The "sedenion Hopf projection" in `hopf_soliton_engine.py` is not sphere-valued.
- The "S³¹→S¹⁵→S⁷ Hopf collapse" in `sovereign_mathematics.md` fails for the Cayley–Dickson construction. The general topological impossibility (Adams' theorem) is not formalised.
- In `spectral_gap_e8.py`: \(\ln\coth\beta\ge 2\beta\) fails, the stated "algebraic lower bound" fails, the derivative formula is wrong (the correct one is \(-1/(\sinh\beta\cosh\beta)\)), and the E₈ root graph has diameter at least 3, not 2.

**Records:** I added rows H-106 to H-113 to `QBX/Formal/HYPOTHESIS_REGISTRY.md` and a row to `QBX/README.md`, and registered the results in the Properties table, all marked proved.

**Not done:** the isomorphism between the 24-element group above and \(SL(2,\mathbb F_3)\), E₈ from integral octonions, and closure of the E₈ roots under the Weyl group. These are listed as open in `QBX/docs/CONNECTIONS.md`.

# Summary of changes for run 303426d2-2d1e-4ccf-9e4e-80a26a509b7b
All three requested parts are done: D1 and D4 are moved into the shared tree, and D3, D5 and D6 have been carried out in their own `phase_d/` folders. D3, D5 and D6 are not yet merged into the shared tree. Their integration manifests are ready and list the order D3 → D6 → D5. The last full `bash ./health.sh` run passed every check: 737 foundation tests, 135 Phase D tests, the full Lean build, and the scan for `sorry`/`admit`/`axiom`.

**1. Integration of D1 and D4**
- **D1:** now lives at `QBX/Formal/Equivocation.lean` and is imported by `QBX/Formal.lean`. I added registry row H-076 and SPEC rows E1–E6. The axiom audit covers 111 declarations, and all use standard axioms only. Its tests moved to `foundation/tests/`.
- **D4:** now the new layer 9, `foundation/ws9_protocol/`, with its docs and a regenerated report giving the same results. It has a new `PROPERTIES.md` with P9.1–P9.3, a LAYER_MAP row and a `LAYERS` entry.
- **Bug fixed during integration:** `brute_force_edge_connectivity` now returns 0 for a graph with no edges.
- **Log:** `QBX/docs/foundation/PHASE_D_INTEGRATION_LOG.md`.
- **Not applied:** D4's optional contract change FA-010. It needs your decision, and sealing it needs your key.

**2. D3 — braid group of the torus (Lean + Python)**
- **Lean file:** `phase_d/D3_torus_braids/lean/TorusBraid.lean`. It has no `sorry` and uses standard axioms only. It defines \(B_n(T^2)\) by generators and relations and proves:
  - the map to \(S_n \ltimes (\mathbb{Z}^2)^n\) is a well-defined homomorphism (`shadow_rels`), and on ordinary planar braids it agrees with the existing permutation map;
  - torus braids act on \(Q_n \,\square\, T^k\) addresses, and that action respects composition (`torusGate_mul`);
  - for \(n \ge 2\): \(\sigma_i^2 \ne 1\), \(ab \ne ba\), and the shadow map is not injective.
- **Caveat:** I wrote down the relations from the published presentation without having the paper available in this run. This is noted in `docs/PRESENTATION.md`; please check them against the source.
- **Tests:** 46 Python tests pass.

**3. D6 — surface codes and anyons (numerical only)**
- Surface codes on genus-\(g\) surfaces give \(2g\) logical qubits.
- They agree with the existing toric code at \(g = 1\).
- The SU(2)\(_k\) pentagon and hexagon equations hold to within \(1.3\times10^{-15}\) for \(k = 2, \dots, 5\).
- SU(2)\(_2\) is not the same theory as Ising, and the integer part of SU(2)\(_3\) is Fibonacci.
- 47 tests pass.

**4. D5 — hyperbolic factor and curvature (numerical only)**
- **Hyperbolic factor:** finite balls of the \(\{p,q\}\) tilings and of regular trees, with exact distance and routing.
- **Product space:** \(Q_n \,\square\, T^k_m \,\square\, \mathbb{H}\), using local address types plus an adapter to the frozen contract types.
- **Curvature:** exact Ollivier–Ricci (Lin–Lu–Yau) and Forman curvature.
- **Capacity table:** `docs/CAPACITY.md`. Every number in it is generated by code, none typed in.
- **Findings:**
  - Hypercube \(Q_n\): curvature \(2/n\) (Forman 2), positive.
  - Torus \(T^k_m\): curvature 0 only for \(m \ge 6\). For \(m = 3, 4, 5\) it is positive: \(3/(2k)\), \(1/k\), \(1/(2k)\). So the brief's "flat for \(m \ge 5\)" is off by one.
  - Tilings: negative everywhere inside the ball. Forman curvature is \(16 - 2p - 2q\), with a short argument written out in `docs/CAPACITY.md`. The Lin–Lu–Yau values fit \(c_p/q - 2\) on every tiling tested; that formula is an observation, not a proof.
  - In products, an edge's Forman curvature is the same as in its own factor. Its Lin–Lu–Yau curvature is scaled by \(d_i / \sum_j d_j\).
- **Contract change drafted:** `FA-020_hyperbolic_factor.md` proposes an optional `hyper` field on `Address` and a new edge kind `"hyp"`. It is backward compatible and checks every place that builds an `Address`. It needs your decision and can go in the same seal as FA-010.
- **Not done:** the optional Ricci-flow experiment.
- 42 tests pass.

**Records and Properties table**
- Updated: `MASTER_PLAN.md`, `AGENT_WORKSTREAMS.md`, the `phase_d/README.md`, the integration log, the session log, and a `STATUS.md` plus manifest for D3, D5 and D6.
- Properties table: the D1 theorems point to `QBX/Formal/Equivocation.lean` and are marked proved. New entries cover D3: `TorusBraidGroup` (definition) and `shadow_rels`, `shadow_not_injective`, `tsigma_sq_ne_one`, `torusGate_mul` (proved). Their file links still point into the D3 folder because D3 has not been merged into the shared tree yet.

Everything is committed.

# Summary of changes for run 09db9906-0c63-474a-b587-0b657cbec0cd
I followed the plan you approved: a WS8 session (which included integrating WS7's Lean file), then Phase D workstreams D1 and D4. The full library builds (`lake build QBXFormal`, 8075 jobs, no warnings), and the full health check passes all eight checks (699 tests, plus 35 in the Phase D folders). Everything is committed. As in earlier sessions, I had to install the Python requirements first. `health.sh` and `seal.sh` are stored without the executable bit in this tree, so I ran the check as `bash ./health.sh`.

**WS7 integration**
- `ShortLoops.lean` moved unchanged into `QBX/Formal/` and is imported by `QBX/Formal.lean`.
- I added SPEC rows F4c–F4d, registry row H-105, a row in the README table, and an index entry for the log, which moved to `QBX/docs/foundation/WS7_LOG.md`.
- The axiom audit now covers 101 declarations, all on `propext`, `Classical.choice` and `Quot.sound` only.

**WS8** (log: `foundation/ws8_spec/WS8_LOG.md`)
- `ARCHITECTURE.md` and `LAYER_MAP.md` now reflect the current state, with each layer's Lean files, `merge_events`/equivocations, the multi-edge fork results, the toric rank and the gate group.
- **Doc/test mismatch found:** the layer map said WS7 and the examples import only layers 1–5, but both import `contracts`. The import test never read the map, so nothing caught it.
- I corrected the map and added `test_layer_map_matches_rule`, which fails if the test's rule table and `LAYER_MAP.md` disagree. Restoring the old row makes it fail. The import check now also scans subfolders.

**D1** (`phase_d/D1_fork_theory/`)
- `lean/Equivocation.lean` models a ledger as a family of events, allowing parallel events in either direction and self-loops, and defines flatness by closed walks over events.
- The file has no errors, warnings or `sorry` and uses only the standard axioms. It proves:
  - **Equivocation is a fork:** two disagreeing events on one pair, in the same or opposite direction, make the ledger non-flat.
  - **`isFlat_iff`:** a ledger is flat exactly when self-loops are trivial, parallel events agree and the merged connection is flat. This shows `merge_events` + `consensus_check` give the right verdict. A suitable merged connection always exists, so the statement isn't vacuous.
  - Flat holds exactly when node potentials exist.
  - **`isBridgeEvent_iff`:** an event is a bridge exactly when its pair is a bridge of the merged graph and carries no other event. This shows the `blind_spots` filter is correct, and that a pair with two events is never a blind spot.
  - **Single-event forks:** changing one event of a flat ledger is detected exactly when that event is not a bridge.
- Self-loops are covered here, at the ledger level (WS2 open item 4).
- 9 tests check `consensus_check` against these statements on random ledgers. A planted bug makes them fail.
- I did not re-prove geodesic convexity (G1); WS1 already proved it and the brief says to cite it. `SPEC_D1.md`, `STATUS.md` and the integration manifest are written; the manifest proposes registry row H-076.

**D4** (`phase_d/D4_consensus_protocol/`)
- **Package `d4_protocol`:**
  - a 100-node network on `Q_2 □ T²_5` with S₄ transports and message loss;
  - a witness rule: an event is final only once it closes a 4-cycle. `docs/WITNESS.md` proves on paper that this leaves no bridges; the tests check it exhaustively on five small spaces and by sampling on 100 nodes;
  - edge connectivity λ computed three independent ways that agree;
  - all the attack scenarios from the brief.
- **Report (`docs/REPORT.md`):** 1000 trials per scenario, reproducible from seed 2026. Both witness regimes give 100% detection and localization of single forks and equivocations, and 100% detection of forks on fewer than λ pairs. There were 0 false alarms in 3000 honest runs and 0 blind spots.
- **Undetected, as theory predicts:** forks on a whole minimum cut, blind-spot forks with the witness rule off (each one listed in `blind_spots`), and reorderings with an abelian group.
- `docs/ATTACKS.md` lists every attack with its theorem; all 14,000 runs agree with theory.
- **Limitations:** the witness rule only guarantees λ ≥ 2, and finding the loop behind each reported fork needs more than the frozen report exposes. A draft amendment, FA-010, proposes adding that information.
- The 26 tests run in about 5 s. The manifest proposes a new layer `ws9_protocol`.

**Not done:** the Phase D integration step (moving D1 and D4 into the shared tree) hasn't started; both folders have manifests ready for it. D3, D5 and D6 were not started. The Properties table now lists the D1 theorems as proved, and the WS7 entries point to their new location.

# Summary of changes for run ebad3e0d-2b1e-46e2-8ffa-2381cdfc1a16
I merged the two summary files, checked and finished integrating WS2, and completed a first WS7 session. The full `health.sh` passes all eight checks (698 tests), `lake build QBXFormal` succeeds (8074 jobs), and everything is committed. To run the Python checks I had to install the Python requirements in this environment; the repository doesn't depend on that step.

**Summary files.** `ARISTOTLE_SUMMARY_2.md` was the shared history plus one new WS2 entry. Everything from the WS6 entry down matched the root file exactly. I put the WS2 entry at the top of `ARISTOTLE_SUMMARY.md` and deleted `ARISTOTLE_SUMMARY_2.md`.

**Checking the WS2 work**
- **Present and correct:** the Python fix (`normalize` and canonical `equal` in `ws2_gauge/groups.py`, normalization in `connection.py`), the 14 new tests, and `QBX/Formal/GaugeForest.lean`, which has no `sorry`.
- **One claim was wrong:** the WS2 summary and log say the import was added to `QBX/Formal.lean`, but it wasn't there, so `GaugeForest.lean` was outside the library build. I added the import and rebuilt the full library; WS2 hadn't managed a full rebuild.
- **WS2 open items I closed:**
  - Registry row H-104.
  - New SPEC section with rows F4a–F4b.
  - Four new entries in the axiom audit, which now covers 98 declarations, all on the standard axioms.
  - `README.md` and file-map rows, and an updated test count in `foundation/README.md`.
  - The log moved to `QBX/docs/foundation/WS2_LOG.md`, with an integration entry, an index row and `ws2_gauge/integration/MANIFEST.md`.
- **Still open:** WS2's items 1, 4 and 5 (a contract amendment for `normalize`, self-loops not covered by the Lean model, and `Connection.transports` still being changeable after construction).

**WS7, session 1** (log: `foundation/ws7_benchmarks/WS7_LOG.md`)
- **What was wrong with the harness:** three of its four flatness methods all live in `ws2_gauge/holonomy.py` and propagate along the same BFS forest. The fourth (closed walks up to length 4) can only confirm "flat", never "not flat". And the fork check relied on the Tarjan `bridges` routine without ever checking it.
- **New independent checks:**
  - `union_find_flat`: an exact flatness test that shares no code with the gauge engine and merges edges in random order.
  - `brute_force_flat`: walks of length up to \(2D+1\), with \(D\) the BFS depth of each component.
  - `brute_force_bridges`: deletes each edge and tests reachability, which is the definition the Lean proofs use.
  - New report rows `cross_validate_bridges` and `cross_validate_exact_walks`.
- **Lean proof (`ws7_benchmarks/lean/ShortLoops.lean`):** `isFlat_iff_short_firstReturn` shows a connection is flat exactly when every closed walk that first returns to its root within \(2D+1\) steps has trivial holonomy. That makes the new brute force an exact test rather than a one-sided one. The file has no errors, warnings or `sorry`, and uses only the standard axioms. `health.sh` doesn't check it yet: `integration/MANIFEST.md` proposes moving it into `QBX/Formal/`, as with WS3 and WS5.
- **Tests:**
  - New `tests/test_prop_harness.py` with property tests P7.1–P7.3.
  - New unit cases, including a 7-cycle where the old length-4 check misses the loop and the new one finds it.
  - A planted-bug test: a deliberately broken flatness check and a deliberately broken bridge routine are both reported as FAIL.
  - The full foundation suite has 148 tests, all passing.
- **Report:** `benchmarks/report.md` was regenerated from a 1000-trial run, and all 12 checks pass. Of the 3000 exact brute-force trials, the step cap cut 15 short; those were skipped rather than counted.
- **WS2's tests reviewed:** I accepted them. I couldn't re-check WS2's claim that they fail on the old code, because that code isn't in this repository's history.

The Properties table lists the two WS2 theorems and the two WS7 theorems (marked proved), plus the WS7 first-return definition.

# Summary of changes for run 2832e9a7-7c29-4da8-9e4d-0d417fc621b6
I read both READMEs and the WS2 brief, audited the gauge engine, fixed a bug that broke one of its guarantees, and added a Lean proof covering the flatness check as the code actually runs it. Everything is recorded in the new log, `QBX/foundation/ws2_gauge/WS2_LOG.md`.

**Starting point.** All the WS2 files were already there, and the 17 existing gauge tests passed. Running them needed `pip install pytest hypothesis`, which was missing from the environment.

**Bug found: `is_flat` and `is_pure_gauge` could disagree (guarantee 1).** Group elements were compared with plain `==`, but every product is reduced mod n or mod p. So a transport written in a non-standard form made the two checks give different answers. Examples: `-1` or `7` in `Z/7`, or matrix entries ≥ p in `GL(n,p)`; `{(0,1): -1, (1,0): 1}` in `Z/7` returned True from one and False from the other. Invalid inputs, such as a tuple that isn't a permutation, a singular matrix or `5` in the trivial group, were also accepted without complaint.
- **Fix:** each group now has `normalize`, which returns a standard form or raises `ValueError` for a non-element, and `equal` compares standard forms. `Connection` normalizes every transport when it is built and names the edge if one is rejected.
- **Contract:** `contracts/` is unchanged. A group that only provides the contract's methods is stored as given.
- **Docs:** `README.md` now has a guarantee 5 and a modelling-notes section; `PROPERTIES.md` has a new P2.6.

**Tests.** I added a P2.6 property test and unit tests for the reported cases, rejection of invalid inputs, `normalize` on valid elements, and self-loops. The new tests fail on the old code (13 failures) and pass now. The whole foundation suite passes (135 tests). A 200-trial run of the cross-validation report passes with no disagreements. A 10⁴-node timing run, printed but not saved, was no slower than the committed figures. Note that the test files belong to WS7, so they should review these additions.

**Lean addition: `QBX/Formal/GaugeForest.lean`.** The existing theorem F4 checks every edge, but the Python code skips the spanning-tree edges. Two new results close that gap:
- `isFlat_iff_nonForest`: checking only the non-tree edges is sound and complete, provided the tree paths satisfy the update `T[v] = T[u]·g(u,v)`.
- `forest_recursion`: that update holds for paths built by extending the parent's path by one edge, as BFS/DFS does.

`lake build QBX.Formal.GaugeForest` succeeds, with no `sorry` and only the standard axioms. I added the matching import line to `QBX/Formal.lean`. A full `lake build QBXFormal` got through 8066 of 8070 jobs with no errors. I stopped it after about 1.5 hours spent on two existing files (`BibleBraidGenesis1`, `BraidBurauCert`), so the full library was not rebuilt in this session.

**Open items, listed in the log for other workstreams:**
- An optional contract amendment to add `normalize` to the `Group` interface.
- WS6 should register `GaugeForest.lean`.
- WS8 should update the test count in the foundation README.
- Self-loops are accepted in Python but not covered by the Lean model.
- `Connection.transports` can still be changed after construction, which skips the checks.

# Summary of changes for run b3457789-f228-480c-bc60-bdeeccc90561
Work streams 3, 4, 5 and 6 are now integrated into the QBX project, and all the side copies are merged and deleted. `lake build QBXFormal` succeeds with no errors or warnings, the integrated Lean files contain no `sorry`, and the full `./health.sh` passes all eight checks (675 tests; the foundation suite alone is 125). Before running `health.sh` I had to install the Python requirements (`pytest`, `hypothesis`, `cbor2`, `numpy`, …) in this environment; nothing in the repository depends on that step. Everything is committed.

**Merging the side copies.** The copies were in `QBX/`, not `QBX/foundation/`.
- `ARISTOTLE_SUMMARY1/5/6.md`, `foundation/ARISTOTLE_SUMMARY.md` and `ws3_consensus/ARISTOTLE_SUMMARY.md`: each one is a single new session entry on top of an identical shared history (I compared them byte for byte). Copy 1 is WS4's second session, 5 is WS5, and 6 is WS6; `foundation/ARISTOTLE_SUMMARY.md` is the same as copy 6. I added the four new entries to the top of the root `ARISTOTLE_SUMMARY.md` and deleted the copies.
- `Formal1.lean` is WS4's version and adds the `ToricRank` import. `Formal2.lean` was the same as the current `Formal.lean`. The merged `QBX/Formal.lean` keeps both the WS1 and WS4 imports and adds `Consensus` and `GateGroup`.
- `README1.md` is WS4's version. I added its `ToricRank.lean` row to `QBX/README.md` and kept the WS1 row.

**Lean files added to the library** (moved without changes into `QBX/Formal/`)
- `Consensus.lean` (WS3): fork localization, gauge invariance, and `round_to_cycles` is a bijection and periodic.
- `ToricRank.lean` (WS4): toric-code stabilizer rank \(2m^2-2\), degeneracy 4, and the four logical operators are independent modulo stabilizers.
- `GateGroup.lean` (WS5): gates form a group that acts faithfully on addresses by bijections, and the braid gate forgets braiding (\(\sigma_i^2 \ne 1\) acts as the identity).

**Status tables and plans**
- **`SPEC.md`:** new rows C1–C3, T3a–T3d and B4–B7, and T3 is marked proved.
- **Registry:** new rows H-101, H-102 and H-103 in `HYPOTHESIS_REGISTRY.md`.
- **Phase D:** D2's only target was T3, so D2 is now closed and Phase D goal 3 is met. I updated `phase_d/README.md`, the D2 brief, `MASTER_PLAN.md` and the backlog to match.
- **WS6 axiom audit:** `audit/AxiomAudit.lean` now covers all 94 declarations listed as proved. Every name exists. 92 use only `propext`, `Classical.choice` and `Quot.sound`, and the two test vectors checked by `decide` use no axioms.

**Tests:** I added WS5's proposed tests P5.6–P5.8 to `tests/test_prop_braid_ops.py`. Following WS3's suggestion, I added a test in `tests/test_fnd_consensus.py` that checks the two Lean `round_to_cycles` values.

**Logs and records:** the WS3–WS6 logs moved to `QBX/docs/foundation/`, each with a new entry describing the integration, and the index there lists them. Each of `ws3_consensus/`, `ws4_toric/` and `ws5_braid_ops/` now has an `integration/MANIFEST.md` recording what was applied. I also updated the work-stream READMEs, `QBX_FILE_MAP.md` and `agents/memory/session_log.md`.

**Things that didn't match:**
- WS3's log and summary mention a `QBXConsensus` entry in `lakefile.toml`, but this tree doesn't have one, so there was nothing to remove.
- WS4 reported a `SPEC.md` change that isn't in this tree; I made it during integration.
- WS5's proposals were in `ws5_braid_ops/tests/` instead of `integration/`.

The Properties table lists nine of the main theorems from WS3–WS5, all marked proved.

# Summary of changes for run 8ebd7f9e-fd53-44af-9249-1ecceb42147e
I read `QBX/README.md` and `QBX/foundation/README.md`, plus the workstream and plan documents (`AGENT_WORKSTREAMS.md`, `MASTER_PLAN.md`, `phase_d/README.md`, `phase_d/INTEGRATION.md`) and everything in `QBX/foundation/ws6_certificates/`. Work stream 6 (Certificates & Formal Targets) has three merge checks, listed in its `PROPERTIES.md`. `SPEC.md` says the targets F1–F6c, T1, T2 and B1–B3 are already proved. I checked those claims against the current tree, and all three checks pass.

1. **The Lean library builds.** `lake build QBXFormal` finished successfully (8069 jobs) with no errors and no warnings. The four WS6 files (`GaugeFlatness`, `ToricCode`, `HypercubeGates`, `MultiEdgeFork`) are imported by `QBX/Formal.lean`.
2. **No `sorry`, `admit` or `axiom` declarations.** I ran the same search `health.sh` uses over `QBX/Formal` and `foundation/phase_d` and found none.
3. **Every name in `SPEC.md` exists and uses only standard axioms.** All 31 declarations listed as proved exist; the names in SPEC are relative to the `QBX.Formal` namespace. `#print axioms` shows only `propext`, `Classical.choice` and `Quot.sound` for each of them, and some use fewer than all three.

I also read each Lean statement against its row in SPEC, and they all match. One caveat on the toric-code results (T1/T2): SPEC says they hold for every \(m \ge 1\). That is true of the Lean model, which adds up edges mod 2. The Python `ToricCode` class only accepts \(m \ge 2\), and the two descriptions agree exactly on that range. At \(m = 1\) the claim applies only to the Lean model, not to the Python class.

I did not attempt T3, G1 or TB: the Phase D rules assign them to workstreams D2, D1 and D3. I also left `QBX/Formal/` and the content of `SPEC.md` unchanged.

**Files added in `QBX/foundation/ws6_certificates/` (committed):**
- `WS6_LOG.md`: the progress log you asked for, covering orientation, the results of each check, a per-declaration axiom table, the statement review and what was out of scope.
- `audit/AxiomAudit.lean`: a script you can re-run with `lake env lean QBX/foundation/ws6_certificates/audit/AxiomAudit.lean` from the repository root. It has no `module` header, because Lean does not allow `#print axioms` inside a module.
- `README.md`: I added pointers to the two files above.

# Summary of changes for run a4e3e04e-23a5-404e-b58b-de5fec6c3e4b
I read `QBX/README.md`, `QBX/foundation/README.md`, the workstream and Phase D rules, and the WS5 brief in `QBX/foundation/ws5_braid_ops/` (`README.md`, `PROPERTIES.md`). The progress log is at `QBX/foundation/ws5_braid_ops/LOG.md`. All my changes are inside the WS5 folder, as the folder-isolation rule requires.

**Starting point.** The WS5 tests passed (12 tests) and `QBX/Formal/HypercubeGates.lean` built. Comparing the README and PROPERTIES claims with what was actually proved turned up these gaps:
- Composing and inverting general gates (P5.2) had no Lean model; only braid gates were covered.
- "Gates are bijections" (P5.3) had no proof.
- The README says gate equality is "exact rather than extensional". That needs proof that two gates acting the same way on every address are the same gate. There was none.
- The Lean cyclic distance had never been tied to the Python distance formula.
- `BRAID_FULL_TWIST_NOTE` says the shadow "forgets all braiding", which was unproved. It also gave an out-of-date backlog rank and owner.

**New Lean file `lean/GateGroup.lean`.** It compiles with `lake env lean` with no errors or warnings, contains no `sorry`, and uses only the standard axioms. It proves:
- **Group structure:** gates with `compose`, `identity` and `inverse` form a group that acts on addresses (`Gate.act_compose`, `Gate.act_inverse`, plus `Group` and `MulAction` instances). This covers P5.2.
- **Bijections:** `Gate.act_bijective` covers P5.3.
- **Equality:** `Gate.ext_iff_act` shows two gates are equal exactly when they act the same on every address.
- **Distance:** `cycDist_natCast` shows the Lean cyclic distance equals the Python formula \(\min(d, m-d)\) with \(d = |x-y| \bmod m\), for \(x, y < m\).
- **Braid gates:** `braidToGate` turns each braid into a gate, respecting multiplication. `braidGate_sigma_inv` shows \(\sigma_i^{-1}\) and \(\sigma_i\) give the same gate. `braidGate_not_faithful` shows \(\sigma_i^2 \ne 1\) in \(B_n\) but its gate does nothing.

**Other changes in the folder:**
- `torus_braid.py`: I updated only the text of `BRAID_FULL_TWIST_NOTE`, to cite these results and the current owner (D3, backlog rank 4). Code behaviour is unchanged.
- `README.md` lists the new guarantees 5–8.
- `PROPERTIES.md` fills in the missing Lean counterparts and proposes three new properties, P5.6–P5.8.
- `integration/tests/test_ws5_gate_group.py` tests P5.6–P5.8 by random sampling, not proof.
- `integration/MANIFEST.md` says where each proposed change to a shared file should go: copy the Lean file to `QBX/Formal/` and add its import, add the tests, and add a row to the formal-layer table in the README.

**Checks.** The full foundation test suite passes (121 tests). The proposed tests pass alongside the WS5 tests (15 total).

**Still open:**
- `health.sh` does not check the new Lean file yet, because it only scans `phase_d/*/lean/`. Until the integration step copies it into `QBX/Formal/`, it has to be checked by hand; the commands are in the manifest.
- The full torus braid group \(B_n(T^2)\) is still out of scope; it belongs to D3.
- `orbit` and `GateSet.word` have no Lean counterpart.

The work is committed.

# Summary of changes for run 687e57d9-2aef-40c5-b8ed-62e95b87692c
The Lean proofs from the last session are now part of the project's Lean build. Last time the file was outside every library, so I could only check it by hand. I moved it, unchanged, to `QBX/Formal/ToricRank.lean` and imported it from `QBX/Formal.lean`. It is now in the `QBXFormal` library, which `lake build` builds by default and which `health.sh` checks.

**Verified:**
- A full `lake build` of every default target, including `QBXFormal`, succeeds.
- `ToricRank.lean` contains no `sorry`, `admit` or `axiom`.
- The eight main theorems depend only on the standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

**What the file proves** (for every torus size \(m \ge 1\), in the conventions of `ToricCode.lean`):
- **T3a / T3b:** the star X-supports span a space of dimension \(m^2-1\), and so do the plaquette Z-supports (`finrank_star_span`, `finrank_plaquette_span`). The only relation is that all of them sum to zero (`ker_starMap`, `ker_plaqMap`).
- **T3:** `toric_stabilizer_rank` says the stabilizer group has rank \(2m^2-2\). From it, `toric_logical_qubits` gives 2 logical qubits and `toric_degeneracy` gives \(2^{2m^2-\text{rank}} = 4\).
- **T3c:** `toric_logicals_independent` and `toric_logicals_linearIndependent` say `Z_A, Z_B, X_A, X_B` are independent modulo the stabilizers.
- **Extra:** a Pauli operator commutes with every star and plaquette exactly when it is a product of stabilizers and the four logicals (`toric_centralizer_eq`, `commutes_all_iff_mem_stab_sup_logical`). The set of such operators has dimension \(2m^2+2\) (`finrank_centralizer`).

**Documentation updated:**
- `QBX/foundation/ws6_certificates/SPEC.md`: T3 is now marked proved and removed from the open-targets table.
- `QBX/README.md`: new `ToricRank.lean` row in the table of Lean files.
- `ws4_toric/README.md` and `ws4_toric/PROPERTIES.md`: paths now point to the new file. The README keeps the table matching each Python function to its Lean theorem.
- `ws4_toric/lean/INTEGRATION.md`: removed, since its proposed changes are now applied.
- `ws4_toric/LOG.md`: a session-2 entry records all of this.

**Still to do:**
- No entry has been added to the hypothesis registry yet.
- Phase D workstream D2 was assigned only T3, which this file delivers, so it can be closed or re-scoped.

All changes are committed.

# Summary of changes for run 056c1d47-a13d-44ff-ab79-4115b184594f
I read the project and foundation READMEs (plus the master plan, the workstream list, the Phase D plan and the WS3 README/PROPERTIES), then worked on work stream 3. The progress log is `QBX/foundation/ws3_consensus/WS3_LOG.md`.

**Python baseline.** After installing `pytest`/`hypothesis`, the 53 WS3 tests and the full foundation suite (121 tests) pass. I also checked a few edge cases by hand: a self-loop event that isn't the identity is reported as a fork. I found no bugs in `flatness.py` or `event_graph.py` and didn't change any Python code.

**Gap analysis.** Lean proofs already covered WS3 guarantees 1, 2 and 5. Guarantee 6 (equivocation) belongs to D1 under the Phase D plan, so I left it alone. Guarantees 3 and 4 and property P3.4 had no Lean proof.

**New Lean file:** `QBX/foundation/ws3_consensus/lean/Consensus.lean` (namespace `QBX.Formal.Consensus`). It builds with `lake build QBXConsensus`, contains no `sorry`, and uses only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). It proves:
- **Guarantee 3 (fork localization).**
  - `perturb_mem_fundamentalCycle_edges`: if one edge of a consistent (flat) ledger is changed and the fundamental-cycle check fails at edge u—v, then the cycle for u—v, which is the loop `localize_fork` reports, contains the changed edge.
  - `mem_edges_of_perturb_holonomy_ne_one`: the same holds for any loop whose holonomy is non-trivial.
  - `exists_mem_diffEdges_of_holonomy_ne_one`: when several edges are changed, every such loop passes through at least one of them.
- **Property P3.4 (gauge invariance).**
  - `isFlat_regauge_iff`: re-gauging every node, \(g \mapsto \varphi(u)^{-1} g \varphi(v)\), doesn't change the verdict.
  - `fundamental_regauge_eq_one_iff`: it also doesn't change which edges fail the check, which is stronger.
  - `diffEdges_regauge`: it doesn't move the fork locations.
- **Guarantee 4 (`round_to_cycles`).**
  - `roundToCycles` copies the Python loop step for step.
  - `roundToCycles_bijOn`: it is a bijection from \([0, \prod m)\) onto digit tuples with \(d_i < m_i\). This needs no condition on the moduli.
  - `roundToCycles_add_prod`: it repeats with period \(\prod m\).
  - It has an explicit inverse, `cyclesToRound`.
  - Two input/output examples are checked by `decide`, including the README's `(37, (4,4)) ↦ (1,1)`. The Python function gives the same outputs.

I added a "Formal counterparts (Lean)" table to `ws3_consensus/README.md` that maps each guarantee to its Lean statement.

**One change outside the WS3 folder:** I added a 5-line `QBXConsensus` library entry to the root `lakefile.toml` so the new file builds. `health.sh` doesn't build this library yet, and its `sorry` scan doesn't cover `ws3_consensus/`. The log suggests how to fix that during integration: either extend `health.sh`, or move the file into `QBX/Formal/` and add rows to `SPEC.md`.

The four proved properties and their two supporting definitions are in the Properties table. All work is committed.

# Summary of changes for run d7637c36-5b7c-44ce-9d45-fe224c316056
Work stream 1 (geometry core) is now part of the main QBX project, and its log is in the project docs. You confirmed WS1 only for now: in this copy, `ws3_consensus/`, `ws4_toric/`, `ws5_braid_ops/` and `ws6_certificates/` have no logs or integration manifests, so I didn't touch them. `lake build QBXFormal` succeeds, the integrated file contains no `sorry`, and the main theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`). The full `./health.sh` passes all eight checks (671 tests). To run its Python checks I first had to install `pytest`, `hypothesis` and `cbor2` in this environment; the repository itself is unchanged by that.

**Lean integration** (following WS1's `integration/MANIFEST.md` and `phase_d/INTEGRATION.md`)
- I moved `MixedRadixGeometry.lean` unchanged from `foundation/ws1_geometry/lean/` to `QBX/Formal/MixedRadixGeometry.lean` and added its import to `QBX/Formal.lean`.
- I removed the temporary `QBXFoundationWS1` library from `lakefile.toml`.
- The proposed `health.sh` patch is no longer needed: the file now lives in `QBX/Formal/`, so the normal Lean build and the `sorry` scan already cover it.

**Status tables**
- `foundation/ws6_certificates/SPEC.md` has a new section, "Address-space geometry", with rows G0–G4, all proved: metric; shortest-path metric, connectivity, adjacency and greedy step; vertex-transitivity; balls and spheres; and the isometric, geodesically convex embedding of \(\{0,1\}^n\) in \(T^n_m\).
- **Numbering change:** these IDs differ from the manifest draft. I kept **G1** for the isometric embedding plus geodesic convexity, because the plan already used that ID for it. The old Phase D row and the research item for convexity are removed.
- `Formal/HYPOTHESIS_REGISTRY.md` has a new row, **H-100**. I used H-100 because H-076 – H-099 are reserved for Phase D.

**Documentation and logs**
- The log moved from `foundation/ws1_geometry/WS1_LOG.md` to `QBX/docs/foundation/WS1_LOG.md`, with a new entry recording the integration. A new index, `QBX/docs/foundation/README.md`, lists work-stream logs and has a row for WS1, so the other logs can be added there later.
- I updated these files to match the new state: `QBX/README.md`, `QBX_FILE_MAP.md`, `foundation/README.md`, `MASTER_PLAN.md`, the `ws1_geometry` README, PROPERTIES and MANIFEST, and `agents/memory/session_log.md`.
- The D1 brief and `phase_d/README.md` now record that D1's convexity deliverable is already proved, so D1 should cite it rather than re-prove it.

The Properties table entries now point to the new file location and stay marked proved. Everything is committed.

# Summary of changes for run 22a83494-0664-4233-8d33-62a9c379e47f
The WS1 formalization is complete. It now builds as its own Lake target (`lake build QBXFoundationWS1`) with no `sorry`. `#print axioms` on the main theorems shows only Lean's standard axioms (`propext`, `Classical.choice`, `Quot.sound`). All WS1 promises, P1.1–P1.5 and README guarantees 1–4, now have Lean proofs.

**Changes this session**
- **Lake library:** the WS1 file was previously only checked with `lake env lean`. I added a library `QBXFoundationWS1` to the root `lakefile.toml`, so `QBX/foundation/ws1_geometry/lean/MixedRadixGeometry.lean` now builds as a module. It is not a default target. I also rebuilt the existing default targets, and they still build.
- **P1.5 (balls and spheres), the one promise without a proof:** `walkBall c r` is the set of addresses reachable from `c` in at most `r` moves, which is what the depth-limited search in `routing.ball` collects. I proved `walkBall_eq` (the ball is \(\{v : d(c,v) \le r\}\)) and `walkSphere_eq` (the sphere is \(\{v : d(c,v) = r\}\)).

**Proved results** (namespace `QBX.Formal.Gates`; the graph `addrGraph n k M` joins two addresses that differ by one bit flip or one ±1 step on a single cycle, matching the Python `neighbors`)
- **Guarantees 1–2 (distance is the shortest-path metric), P1.1–P1.4:**
  - `addrGraph_dist`: graph distance equals `addrDist`.
  - `addrGraph_connected`: the graph is connected.
  - `addrGraph_adj_iff`: two addresses are adjacent exactly when their distance is 1.
  - `exists_isMove_addrDist`: from any address there is a move one step closer to the target.
  - The metric laws for `addrDist`.
  - `cycDist_eq_min`: the Lean cycle distance is the Python formula `min(d, m − d)`.
- **Guarantee 3 (no privileged origin):** `addrGraph_vertexTransitive`, for the whole product space. The hypercube alone is the case \(k = 0\).
- **Guarantee 4 (isometric embedding):** for \(m \ne 1\), distances between points of \(\{0,1\}^n\) inside \(T^n_m\) equal hypercube (Hamming) distances (`addrDist_embedBits`, `torus_dist_embedBits`, `embedBits_injective`). \(m = 1\) must be excluded because \(0 = 1\) there.
- **Guarantee 4 (geodesic convexity, previously open):** `embedBits_geodesicallyConvex` shows every shortest walk in \(T^n_m\) between points of \(\{0,1\}^n\) stays in \(\{0,1\}^n\). This holds for every \(m\), not only \(m \ge 3\).

**Python tests:** `tests/test_fnd_geometry.py` and `tests/test_prop_geometry.py` pass (12 tests).

**Docs and log:** `WS1_LOG.md`, `PROPERTIES.md`, `README.md` and `integration/MANIFEST.md` in `ws1_geometry/` are updated. The manifest notes that the temporary library should be removed once the file is moved into `QBX/Formal/`. The `lakefile.toml` entry is the only change outside the WS1 folder.

# Summary of changes for run 2389a8b4-19a7-43e7-916e-32654493aa6e
The multi-edge fork theorem (F6–F6c) is now proved in Lean. Before this it had only been checked numerically. The proofs are in the new file `QBX/Formal/MultiEdgeFork.lean`, which `QBX/Formal.lean` now imports. `lake build QBXFormal` succeeds, the file contains no `sorry`, and the main theorems use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`).

**What is proved** (namespace `QBX.Formal.Gauge.Connection`; a "fork" is the set of edges where two connections differ, `diffEdges`):
- **F6, `diffEdges_eq_levelCut`:** if two connections are both flat, the edges where they differ are exactly the edges whose endpoints get different labels under some vertex labelling \(\varphi : V \to K\). The converse also holds: any such set of edges can be produced by some flat connection (`exists_flat_diffEdges_eq_levelCut`).
- **F6a, `not_isFlat_of_isEdgeConnected`:** on a \(k\)-edge-connected graph, changing a flat connection on any non-empty set of fewer than \(k\) edges breaks flatness, so the fork is always detected.
- **F6b, `perturb_detected_of_isEdgeConnected_two`:** on a 2-edge-connected graph, every non-trivial single-edge fork is detected.
- **F6c, `exists_undetectable_fork_of_not_isEdgeReachable`:** the bound in F6a is tight. If two connected vertices can be separated by deleting fewer than \(k\) edges, some flat connection differs on a non-empty set of fewer than \(k\) edges, and no holonomy check can see that fork. This assumes the group \(K\) has more than one element. Together with F6a: on a connected graph, the smallest undetectable fork has exactly as many edges as the graph's edge connectivity. A related result, `exists_flat_diffEdges_eq_boundary`, shows that the edges leaving any vertex set can always form an undetectable fork.

**Documentation and plan changes:**
- Added row H-075 to `QBX/Formal/HYPOTHESIS_REGISTRY.md` and rows F6–F6c to `QBX/foundation/ws6_certificates/SPEC.md`, and mentioned the new file in `QBX/QBX_FILE_MAP.md`.
- Adjusted the Phase D plan, since one of its goals is now met:
  - D1 now covers equivocation and geodesic convexity, and is a supporting workstream.
  - D2 now covers T3 only.
  - The suggested order for dropping workstreams if you run fewer agents is D6, D5, D3, D1.
  - These changes are in `QBX/foundation/phase_d/README.md`, the D1, D2 and D4 briefs, `MASTER_PLAN.md`, `AGENT_WORKSTREAMS.md` and `PREFLIGHT_RESPONSE.md`.

The theorems and definitions are listed in the Properties table, with the theorems marked proved. Everything is committed.

You still need to run `cd QBX && ./seal.sh` yourself to freeze the queued v1.1.0 contracts, because it needs your key.

# Summary of changes for run dca5df4d-d5f2-4f15-9218-db4c5f5cdc12
I reviewed `QBX/foundation`, finished the parts that were missing, fixed the bugs I found, proved all of its planned theorems in Lean, and wrote one script that handles freezing, unfreezing and signing. `lake build QBXFormal` succeeds; the new Lean files contain no `sorry` and use only the standard axioms. All tests that don't need a database pass: 542 QBX tests (including 11 new ones for the script) and 74 foundation tests, with 1 skipped. Everything is committed.

**What was missing or broken in the folder** (full list in `QBX/foundation/REVIEW.md`)
- **Missing pieces:**
  - Three package entry files (`__init__.py` for `ws2_gauge`, `ws3_consensus` and `ws4_toric`) had ended up pasted into the bottom of the other READMEs, along with leftover markup. I recreated them and cleaned the READMEs.
  - `toric_code.py` stopped halfway through.
  - `ws5_braid_ops`, `ws6_certificates`, `ws7_benchmarks`, `ws8_spec`, `examples/` and `tests/` didn't exist.
  - All of these are now written.
- **Bugs fixed:**
  - `is_pure_gauge` only checked the part of the graph containing the starting node, so on a split-up graph it could disagree with `is_flat`.
  - `build_forked_events` could plant a fork that can never be detected (the reason is below). In one test setup this happened about 18% of the time.
  - `MatrixGroupGL` accepted non-prime moduli, where its matrix inversion gives wrong answers.
  - Self-loops were wrongly required to be their own inverse.
  - The WS3 README example was wrong: `round_to_cycles(37,(4,4))` is `(1,1)`, not `(2,1)`.
  - The quick-start instructions pointed to a folder that doesn't exist.
- **Contracts:** the `contracts/` folder was declared frozen, but nothing enforced it.

**Mathematical findings, all proved in Lean**
- **The plan's main claim is only true when the forked event lies on a loop.** "A fork is detected by geometry alone" holds exactly when the forked event lies on a cycle of the event graph. A fork on an edge that lies on no cycle (a "bridge") cannot be seen by any holonomy check (`perturb_detected_iff_not_isBridge`). So detection needs redundancy in the ledger; the new `bridges()` function lists the blind spots.
- **Target F2 was false as written.** Holonomy follows loops themselves, not just how many times each edge is crossed. A counterexample with permutations of 3 elements is in `holonomy_not_homological`. I corrected F2 and F4 in the planning docs.
- **Every other planned target is proved:**
  - F1, F3, F4 in `QBX/Formal/GaugeFlatness.lean`.
  - T1, T2 in `ToricCode.lean`, for every torus size.
  - B1, B2 in `HypercubeGates.lean`, which also proves that every gate preserves distances.
  - These are registered as H-071 – H-074, with a status table in `ws6_certificates/SPEC.md`.
- **Not proved in Lean:** the toric code's 4-dimensional ground space is only checked by computer for torus sizes 2–6.
- **Cross-check:** the 1000-trial comparison (`ws7_benchmarks/benchmarks/report.md`) passes on all three setups.

**One script for freezing and signing: `QBX/seal.sh`**
- `./seal.sh` shows what will change and asks you to confirm. Then you enter your key: a key file path, an encrypted key file (it asks for the passphrase), or a pasted key typed hidden.
  - It recognises which key you used from the trust list, so you don't need to type a key id.
  - It then re-hashes the frozen files, signs, checks the result, and writes the decision-log entry.
  - Nothing is saved unless every step succeeds.
  - A mistyped key path is an error; it never creates a new key.
- Other commands: `./seal.sh status`, `./seal.sh freeze PATH…`, `./seal.sh unfreeze PATH… --reason …`, `./seal.sh amend PATH… --amendment A-NNN`.
- The signature format is unchanged, so `verify_frozen.sh` still works. I tested a full seal end to end on a copy of the repository, using a throwaway key.
- I also removed an instruction in `phase_promotion.md` that would have overwritten the frozen-file record with plain progress text.

**What you need to do:** the three `foundation/contracts/*.py` files are queued to be frozen but are not signed yet, because that needs your key. Run `cd QBX && ./seal.sh`, review the plan, and enter your key. The current signed record (63 files) is unchanged and still verifies.

# Summary of changes for run 94ce5b8f-fde1-422d-9b5a-92d91e8bf5f1
I wrote a feasibility study of your list, `QBX/docs/feasibility_braid_crypto.md`, and proved its main claims in five new Lean files (registry entries H-066 – H-070). `lake build QBXFormal` succeeds, the new files contain no `sorry`, and the proofs use only the standard axioms.

**Short answer to each goal**
- **Encryption with no key at all: impossible.** `keyless_breaks` shows that with only one key, anyone who knows the scheme can decrypt everything. Shannon's bound (`card_msg_le_card_key`) shows that perfect secrecy needs at least as many keys as messages, so a keyless scheme is never perfectly secret (`keyless_not_perfectlySecret`).
  - What *is* possible is getting rid of stored, pre-shared keys: one-time key agreement, quantum key distribution, or secret sharing (§2 of the study). A secret braid can serve as the key, but it is still a key.
- **Two (or "double dual") networks disguised as one: possible if the two ends share a secret.** With a one-time pad over any finite group (bit-flip masks or permutation pads), every ciphertext comes from exactly one key, so two different traffic streams look statistically identical (`otp_traffic_indistinguishable`).
  - Without a shared secret this can't work, because an observer could separate the streams the same way the receiver does.
  - Message length and timing still leak unless the traffic is padded to a constant size and rate.
- **Zero-knowledge proofs:** the braid-conjugacy identification protocol is proved complete, specially sound and honest-verifier zero knowledge in \(B_n\) (`braid_sigma_protocol`, `ConjugacyZK.lean`). This proves how the protocol behaves, **not** that it is secure. Braid conjugacy is not a hard problem: it is decidable, and invariants like the project's own Burau characteristic polynomial help an attacker. My recommendation is to use braids as the thing being proved and a standard proof system for the security.
- **Routing and permutations:** every permutation of the strands is realised by some braid (`permHom_surjective`).
- **Hiding the most capable braid features:** every phase-type (abelian) invariant depends only on the writhe (`abelian_eq_zpow_writhe`). The braid \(\sigma_1^2\sigma_2^{-2}\) has the identity permutation and writhe 0, yet it is not the trivial braid; its Burau matrix at \(t=-1\) is \([[5,2],[2,1]]\) (`hidden_braid_layers`). So if you publish only the routing or phase layer, the finer information stays hidden. This hides by not publishing; it does not hide a braid word you do publish.
- **Separation by surgery:** if a braid's permutation moves a strand across the cut at site \(k\), no word for that braid avoids crossings at \(k\) (`not_split_of_perm_crosses`). The two halves of a cut braid commute (`split_commute`). The permutation test is necessary but not sufficient: \(\sigma_k^2\) keeps the two sides apart but still links them.
- **Separation by phase shift:**
  - No phase shift can separate braids of equal writhe (`abelian_eq_of_writhe_eq`).
  - For anyons: a double exchange of Ising \(\sigma\) and \(\psi\) is the global phase \(-1\), so a phase shift undoes it.
  - Ising \(\sigma\)–\(\sigma\) and Fibonacci \(\tau\)–\(\tau\) give different phases on different fusion channels, so no global phase shift undoes them (`AnyonPhase.lean`). That channel dependence is what makes them usable as gates.
- **Entanglement:** no-cloning is proved (`no_cloning`). Gate universality, no-signalling and teleportation are only discussed from the literature, not formalized. If "portal" means teleportation, it uses up a pre-shared entangled pair plus two classical bits per qubit.
- **Chern numbers:** for braids, the only integer-valued invariant of this kind is the writhe (proved). Chern numbers of physical systems are not formalized.

**Terms I need you to define (§9 of the study):** "layered ouroboros merkaba braid pattern", "end words", "double dual network", "portal", and which object's Chern number you mean. The study gives possible readings of each, but nothing about them can be decided until they are pinned down.

**Files:** `QBX/Formal/CryptoLimits.lean`, `ConjugacyZK.lean`, `BraidSeparability.lean`, `BraidLayers.lean`, `AnyonPhase.lean`, all imported from `QBX/Formal.lean`. I updated the hypothesis registry, `QBX/README.md`, `QBX/QBX_FILE_MAP.md` and the session log. No migration, Python module or frozen file was changed. I couldn't run the frozen-file signature check here because a Python package it needs (`cbor2`) is missing, but none of the files I edited is on the frozen list. The results are in the Properties table and marked proved. Your decision on the Phase 3 plan (Q-008) is still pending. Everything is committed.

# Summary of changes for run dee2be67-273a-46ae-bb23-e44bcf756bea
I finished Phase 3 item 4. The Fibonacci and Ising models in `qbx_ir.anyon.model` satisfy the pentagon equation and both hexagon equations, for every assignment of labels. This item only needed Lean, so it didn't depend on your pending decision on the Phase 3 plan (Q-008). It was also the last item on the hypothesis registry's "not yet formalized" list, and is now registered as proved under H-065.

**What is proved**
- `QBX/Formal/AnyonCoherence.lean` (new) defines the two equations, `IsPentagon` and `IsHexagon`.
  - It uses Python's conventions: `F a b c d e f = [F^{abc}_d]_{ef}`, with rows indexed by the left intermediate label, and `R a b c = R^{ab}_c`.
  - F- and R-symbols are set to zero wherever a fusion vertex isn't allowed. This makes the equations stronger: they hold for all labels, not just allowed ones.
  - The proofs work symbolically over any commutative ring that contains the needed numbers (`fibFK_pentagon`, `fibFK_hexagon`, `isingFK_pentagon`, `isingFK_hexagon`).
  - The Ising pentagon has \(3^9\) label combinations. Lean's kernel checks all of them directly, using \(\sqrt2 \cdot F\) over \(\mathbb{Z}[\sqrt2]\).
- `QBX/Formal/AnyonModels.lean` (new) writes the complex tables `fibF`, `fibR`, `isingF`, `isingR` exactly as Python defines them (`1/PHI`, `1/√PHI`, `1/√2`, `exp(-4πi/5)`, `-i`, …). It proves six theorems:
  - `fib_pentagon`, `fib_hexagon`, `fib_hexagon_inv`;
  - `ising_pentagon`, `ising_hexagon`, `ising_hexagon_inv`.

  The `_inv` versions are the second hexagon equation, which uses the reverse braiding `(R^{ba}_c)⁻¹`.
- `lake build QBXFormal` succeeds. There is no `sorry`, no `native_decide`, and only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`) are used.

**Python cross-check**
- `QBX/tests/qbx_ir/test_anyon_coherence.py` checks the same equations numerically on the Python models, with the same index conventions. It also checks that the Lean tables match the Python entries. It is recorded under runtime check R-001.
- The 531 tests that don't need a database pass. The live-database tests were not run, because no PostgreSQL is available here.

**Records**
- Updated: the hypothesis registry, `docs/phase_3_scope.md` (item 4 done), README, `QBX_FILE_MAP.md`, the decision and session logs, `project_state.json` and `ARISTOTLE_SUMMARY.md`.
- No migration, Python module or frozen file changed.
- The frozen-interface check, agent-output validation and hypothesis-expiry check pass. The validation script tries the project's `.venv` first, and that environment has no packages installed here, so I ran it with the system Python.
- The two results and the four definitions they use are in the Properties table, and the results are marked proved.

**Still open:** your decision on the Phase 3 plan (Q-008), item 2 (Jones certificates, migration 023) and item 5 (an amendment that needs re-signing with your key). Everything is committed.

# Summary of changes (2026-10-03, second session): Phase 3 item 4, pentagon and hexagon equations

Phase 3 item 4 is done. It only needed Lean, so it did not depend on your pending decision on the plan (Q-008). The F- and R-symbols of the Fibonacci and Ising models in `qbx_ir.anyon.model` are proved to satisfy the pentagon equation and both hexagon equations, for every assignment of labels (registry entry H-065). This was the last item in the registry's "not yet formalized" list.

- `QBX/Formal/AnyonCoherence.lean`: the equations `IsPentagon`, `IsHexagon` (F- and R-symbols extended by zero off admissible vertices, Python's index conventions); symbolic proofs over any commutative ring containing the needed algebraic numbers (`fibFK_pentagon`, `fibFK_hexagon`, `isingFK_pentagon`, `isingFK_hexagon`). The Ising pentagon (3⁹ label assignments) is checked by kernel evaluation of `√2 · F` over ℤ[√2].
- `QBX/Formal/AnyonModels.lean`: the complex tables `fibF`, `fibR`, `isingF`, `isingR` written exactly as in Python, and `fib_pentagon`, `fib_hexagon`, `fib_hexagon_inv`, `ising_pentagon`, `ising_hexagon`, `ising_hexagon_inv`. The second hexagon uses the reversed braiding `(R^{ba}_c)⁻¹`.
- `lake build QBXFormal` succeeds, no `sorry`, only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`; no `native_decide`).
- `QBX/tests/qbx_ir/test_anyon_coherence.py`: the same equations checked numerically on the Python models (added to R-001). The 531 tests that need no database pass; the live-database tests were not run.
- Records: registry (H-065, R-001, candidate list), `docs/phase_3_scope.md`, README, file map, decision and session logs, `project_state.json`. No migration, Python module or frozen file changed; the frozen-interface check, agent-output validation and hypothesis-expiry check pass.

# Summary of changes for run 72c0c761-e747-48dc-a4a2-5cd03212525d
I reviewed `qbx_composition/` and recommend not integrating it. I then built the Burau / Alexander certificates (Phase 3 item 3, migration 024), which also closes backlog item D2-005. The Lean build succeeds with no `sorry`, and the full test suite passes against a live PostgreSQL 17 (928 tests).

**1. `qbx_composition/` (report in `QBX/docs/qbx_composition_assessment.md`)**
- **None of the 13 Python files can be loaded.** Their indentation was stripped and `__future__` / `__init__` were turned into Markdown bold.
- **Several modules are still wrong after I fixed the syntax by hand:**
  - `ClawsonAxis` fails with a `TypeError` as soon as the class is defined.
  - The spanning-tree count uses floating point. On the E8 root graph it overflows, while the true count has about 415 digits.
  - `pin_naturality` checks components in the wrong direction and reports missing data as "converged".
  - The README calls functions with the wrong arguments.
  - The superposition code is floating point, which breaks the project's rule that certificates are exact.
- **One idea was worth keeping.** Using a braid matrix's eigenvalues as a conjugacy invariant is sound, so I took it over in exact form: the characteristic polynomial of the Burau matrix is proved to be a conjugacy invariant (`Word.burau_charpoly_conj`).

**2. Burau / Alexander certificates**
- **Lean proofs** (`BurauRep.lean`, `LaurentWindow.lean`, `BraidBurauCert.lean` under `QBX/Formal/`; registry entries H-063 and H-064):
  - The reduced Burau matrices form a group homomorphism \(B_n \to GL_{n-1}(K)\) for any commutative ring and unit \(t\), so equal braids have equal matrices.
  - Two certificates are equal exactly when the Burau matrices are equal. So equal braids get equal certificates, and different certificates prove the braids are different.
  - Alexander certificates are unique and unchanged by conjugation, so different Alexander certificates prove two braids are **not conjugate** (`not_isConj_of_alexCert_ne`).
  - Both kinds of certificate can be checked by evaluating at enough rational points.
  - On 17 test braids (1–5 strands), the Python certificates match the Lean values exactly (`burau_agrees_with_python`).
  - Example: σ₁σ₂⁻¹σ₁σ₂⁻¹ and σ₁σ₂⁻¹ have the same writhe and permutation type, so the invariants of migration 020 can't tell them apart. They are proved non-conjugate in \(B_3\) (`figureEight_not_conj`).
  - `lake build QBXFormal` succeeds, and the proofs use only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`).
- **SQL** (`QBX/migrations/024_braid_burau.sql`):
  - An append-only table `braid_burau`, whose values the database recomputes exactly with integer arithmetic whenever a row is written.
  - Functions for Burau equality, inequality and non-conjugacy.
  - Checks that certificates agree along rewrites and derivations and with the normal-form certificates of migration 021.
  - `run_phase3_batch_checks()`, which runs the existing Phase 2 checks and then the new ones.
  - A view `v_braid_exact_representations` with a representation-kind column (this is what closes D2-005).
  - Certificates are refused above 12 strands.
- **Python reference:** `QBX/src/qbx_ir/burau_ledger.py`.
- **Tests:** `tests/qbx_ir/test_burau_ledger.py` and `tests/live_db/test_braid_burau_db.py` (runtime check R-023). Separately, the SQL matched Python on 450 random words (up to 12 strands, length up to 30). The branch of the determinant routine that swaps rows never came up with a nonzero result in that random data, so it is less tested than the rest.

**3. Records**
- Updated: the hypothesis registry (H-063, H-064, R-023), `docs/phase_3_scope.md` (item 3 done), the Phase 2 backlog (D2-005 resolved), README, `QBX_FILE_MAP.md`, the decision and session logs, `project_state.json` and `ARISTOTLE_SUMMARY.md`.
- No frozen file was changed: the signed frozen-interface check, the agent-output validation and the hypothesis-expiry check all pass.
- Migration number 023 is still reserved for Phase 3 item 2 (Jones certificates). The Phase 3 plan still needs your decision (Q-008).

Everything is committed.

# Summary of changes (2026-10-03): `qbx_composition` review and Burau certificates

**`qbx_composition/` review (`QBX/docs/qbx_composition_assessment.md`).** Recommendation: do not integrate it. None of its 13 Python files parses: indentation is stripped and `__future__` / `__init__` were mangled into Markdown bold. After hand repair, several modules are still wrong:
- `ClawsonAxis` raises a `TypeError` at class creation.
- The floating-point Kirchhoff count overflows on the E8 root graph.
- `pin_naturality` checks the wrong component direction and reports missing data as converged.
- The README calls functions with the wrong arguments.

The one useful idea (eigenvalue spectra of braid matrices as a conjugacy invariant) was taken over in exact form: the characteristic polynomial of the Burau matrix is a conjugacy invariant (`Word.burau_charpoly_conj`).

**Phase 3 item 3, Burau / Alexander certificates (migration 024; closes D2-005).**
- Lean (`Formal/BurauRep.lean`, `Formal/LaurentWindow.lean`, `Formal/BraidBurauCert.lean`; H-063, H-064). The reduced Burau matrices form a homomorphism \(B_n \to GL_{n-1}(K)\) for every commutative ring and unit t. Canonical matrix certificates are equal iff the matrices are. Alexander certificates are unique and conjugation invariant, so different Alexander certificates prove two braids are not conjugate. Both kinds of certificate can be checked by evaluation at rational points. On 17 test vectors the Lean values equal the Python certificates exactly. σ₁σ₂⁻¹σ₁σ₂⁻¹ and σ₁σ₂⁻¹ are shown to be non-conjugate even though the invariants of migration 020 can't tell them apart. `lake build QBXFormal` succeeds with no `sorry` and only the standard axioms.
- SQL `migrations/024_braid_burau.sql`: append-only table `braid_burau` with exact Bareiss determinants, write-time recomputation, equality / inequality / non-conjugacy functions, transport and normal-form consistency checks, `run_phase3_batch_checks()`, and the representation-kind view `v_braid_exact_representations`. Reference: `src/qbx_ir/burau_ledger.py`.
- Tests: `tests/qbx_ir/test_burau_ledger.py` and `tests/live_db/test_braid_burau_db.py` (R-023); the full suite passes (928 tests, live PostgreSQL 17).
- Records updated: registry, Phase 3 scope, backlog, README, file map, decision and session logs, `project_state.json`. No frozen file changed. Migration number 023 stays reserved for item 2 (Jones).

# Summary of changes for run f6837050-389c-4455-9d80-65ee172daf11
Phase 2 was already accepted, and the next milestone was a Phase 3 plan, which didn't exist yet. I wrote a proposed plan and finished its first item, which only needed Lean. Nothing else was blocked on your decision. **The plan itself still needs your approval (question Q-008).**

**Lean result (`QBX/Formal/JonesMarkov.lean`, new, imported from `QBX/Formal.lean`).** It proves that the quantum-trace Jones polynomial computed by `jones_from_quantum_trace` is a Markov invariant. This was the first "not yet formalized" item in the hypothesis registry; it is now registered as proved under H-062. `lake build QBXFormal` succeeds, there is no `sorry`, and only the standard axioms (`propext`, `Classical.choice`, `Quot.sound`) are used.
- `Word.jonesQT` is the Python formula `q^(−2w) · Tr(μ^⊗n ρ(B)) / (q + q⁻¹)`, written for any field and any non-zero q. Python multiplies the letter matrices in the opposite order to the Lean model; `Word.quantumTrace_eq` shows this doesn't change the trace.
- The value stays the same under three moves:
  - replacing a braid with an equal one (`jonesQT_eq_of_eval_eq`);
  - conjugation, `a b a⁻¹ ↦ b` (`jonesQT_conj`);
  - stabilisation, `σ₁^{±1} · shift(B) ↦ B` (`jonesQT_stab`).
  So it is constant on Markov equivalence classes (`jonesQT_markov`), meaning it depends only on the closed braid.
- `jonesQT_unlink`: the trivial braid on n + 1 strands gives `(q + q⁻¹)ⁿ`, so the unknot gives 1.
- `jonesQT_agrees_with_python`: on 30 test braids with 1–3 strands and q ∈ {2, 3, −1/2}, the Lean value equals the Python value exactly. The exact Python values come from the Kauffman-bracket `jones_polynomial`, and `jones_from_quantum_trace` matched them to floating-point precision before I recorded them.
- As a consequence, the trefoil σ₁³ is neither Markov equivalent to the unknot nor to its mirror image σ₁⁻³ (`trefoil_not_markovEquiv_unknot`, `trefoil_not_markovEquiv_mirror`). The proof only uses Markov moves; Markov's theorem itself, which links them to isotopy of the closures, is not formalized.
- The stabilisation move adds the new strand on the left. With Python's choice `μ = diag(q⁻¹, q)`, that is the side where the partial trace is a multiple of the identity.

**Phase 3 proposal (`QBX/docs/phase_3_scope.md`, question Q-008):**
1. Markov invariance of the Jones polynomial (done).
2. Jones / Kauffman-bracket certificates, migration 023.
3. Burau / Alexander certificates, migration 024 (closes D2-005).
4. Fibonacci / Ising pentagon and hexagon equations in Lean.
5. The D3-001 / D3-002 amendment, which needs a re-signing with your key.
6. The acceptance review.

**Records updated:** the hypothesis registry (H-062, a note on R-002, candidate list), `README.md`, `QBX_FILE_MAP.md`, the decision log, the session log, `open_questions.md` (Q-008) and `project_state.json`. No migration, Python module or frozen file changed.

**Checks run:**
- `verify_frozen.py --require-signature`: 63 interfaces verified.
- `validate_agent_output.py` and `check_hypothesis_expiry.py` pass.
- The 513 Python tests that don't need a database pass. The live-database tests were not run, because no PostgreSQL is available here.

The Markov theorem, the test-vector check, the trefoil results and the two definitions they use are in the Properties table, and everything is committed.

# Summary of changes for run 089dc188-2b2b-4f28-a676-bb358ab5fd8f
Garside's uniqueness theorem for the left normal form (registry entry H-057, backlog item D2-001) is now proved in Lean for every number of strands. Two braid words that are equal in Bₙ get the same left normal form from the migration 021 algorithm, including its loop limits. So when `braid_normal_form_equal` answers FALSE, the two braids really are different, and the normal-form transport check can never fire on a correct database. Before this, the theorem was only proved for at most two strands, and the entry was due to expire on 2026-12-30.

**Lean (no `sorry`, only the standard axioms `propext`, `Classical.choice`, `Quot.sound`):**
- `QBX/Formal/WeakOrder.lean` (new): the lattice of simple braids. It shows:
  - a product of two simple braids is simple exactly when their inversion counts add up, with the matching identity in Bₙ;
  - any relation on strand positions that is transitive in both senses is the crossing set of some permutation;
  - joins, meets, complements (∂p), and the atoms σᵢ.
- `QBX/Formal/GarsideUniqueness.lean` (new): the theorem itself. The proof doesn't need the positive braid monoid. It has four steps:
  1. Splitting a pair of simple braids into a left-weighted pair is compatible with multiplying simple braids (`nf_germ`), and multiplying on the left keeps consecutive factors left-weighted (`leftWeighted_domino`).
  2. Multiplying normal forms on the left is an action of Bₙ (`nfAction`).
  3. Every normal form is what you get by applying its own braid to the empty normal form (`nfAction_nfValue`).
  4. The algorithm, with the limits it is given, always returns a normal form: no factor is 1 or Δ, and consecutive factors are left-weighted (`leftNormalForm_normal`).
- Main results: `leftNormalFormComplete` (true for every n) and `leftNormalForm_eq_iff_eval_eq` (equal normal forms exactly when the braids are equal).
- Both files are imported from `QBX/Formal.lean`, and `lake build QBXFormal` succeeds. In `BraidNormalForm.lean` I only changed comments.

**Records updated:**
- `Formal/HYPOTHESIS_REGISTRY.md`: H-057 moved to the proved table, so no provisional hypotheses remain. `check_hypothesis_expiry.py` passes.
- `README.md` (Lean table, migration 021 section, Phase 2 status), `QBX_FILE_MAP.md`, the decision log and the session log.
- `docs/phase_2_acceptance.md`: a dated addendum; the acceptance record itself is unchanged.
- `phase_2_backlog.md` (D2-001 closed) and `project_state.json`.
- No migration, Python module or frozen file changed.

**One thing left for you:** comments in three frozen files still call H-057 provisional: `migrations/021_braid_normal_forms.sql`, `src/qbx_ir/normal_form_ledger.py` and `src/qbx_ir/ledger_adapter.py`. Fixing them changes the frozen hashes, so it needs an amendment and a new signature with your key. I logged this as D3-002 in `phase_3_backlog.md`, so it can be done together with D3-001.

**Checks run:**
- `verify_frozen.py --require-signature`: 63 interfaces verified.
- `validate_agent_output.py`: passes.
- All 903 Python tests pass. I ran them in a separate environment because the project's own Python environment isn't available here.

The theorem, the normal-form equality result and the definition they use are in the Properties table, and everything is committed.

# Summary of changes for run 07c0144c-7fd3-4118-8d23-ee96af1947d1
I ran Phase 2 sprint 6, the acceptance review. **It found no disagreement between the database and its Python references, and I changed no migration.** Phase 2 is ready for your review but is **not accepted**: accepting it needs you (see below).

**What the review added.** Unlike Phase 1, every Phase 2 migration was built with its own random comparison from the start, so those per-function checks already existed. What no earlier sprint had compared was the layer around them: what the database actually records as problems, both when rows are written and when `run_phase2_batch_checks()` runs, and what strict mode refuses. The new file `QBX/tests/live_db/test_phase2_review_db.py` (registry entry R-022) builds random ledgers that use migrations 019–022 together. They include malformed braids, wrong rewrite records, broken derivations and tampered invariant, normal-form and representation certificates. It checks that:
- the problems recorded when rows are written, and the ones recorded by the batch run, are exactly the ones the four Python references predict for every row;
- in strict mode, an insert into any of the six Phase 2 tables is refused exactly when its reference reports a problem, and a refused insert leaves no logged problem;
- each Phase 2 batch check raises in strict mode exactly when the references predict a problem for its module;
- a ledger written only through the official write functions passes the strict batch run.

To make sure the new tests catch real faults, I applied four deliberately broken versions of the SQL inside a test transaction that was then rolled back. All four were caught. The first version of the strict batch test missed one of them; I fixed the test so it now calls each check separately.

One limitation: the consistency checks between certificates never fire on a correct database (that is what the Lean proofs guarantee), so random data cannot show they are present. The sprint 2–4 tests that install broken computations cover them instead; the acceptance document says this.

**Documents.**
- `QBX/docs/phase_2_acceptance.md` has the prerequisites, the review table, criteria P2-F1–F11 and P2-N1–N6, the steps left for you, and the record of checks run. A new test, `tests/test_phase2_acceptance_doc.py`, checks that every test the document cites exists.
- `QBX/agents/memory/deferred/phase_2_backlog.md` lists five deferred items, D2-001 to D2-005.
- I also updated the hypothesis registry, the scope document, the README, the file map, the decision and session logs, `project_state.json` (including a proposed Phase 2 freeze list) and the open questions (new Q-007).
- I added nothing to the Properties table, because this sprint produced tests and documents, not new Lean results.

**Checks run:**
- All 903 Python tests pass under hash seeds 0, 1 and 12345 (896 before, plus 7 new), including against a real PostgreSQL 16.
- `tests/test_triggers.sql` passes Tests 1–12 after migrations 001–022, and migrations 019–022 can be applied a second time without error.
- `lake build QBXFormal` succeeds; I changed no Lean file.
- `verify_frozen.py --require-signature` (52 interfaces), `validate_agent_output.py` and `check_hypothesis_expiry.py` pass.
- No frozen file was changed, and everything is committed.

**What's left needs you (question Q-007):**
1. Name an approver.
2. Approve the proposed Phase 2 freeze list: migrations 019–022, the four reference modules, `qbx_ir/quantum/exact.py`, the adapter and its PostgreSQL backend.
3. Hash and sign that list with your `sys-owner-2026` key, which I don't have.
4. Decide how to handle H-057, which is still provisional. Garside's uniqueness theorem is proved in Lean only for 1 and 2 strands, and the entry expires 2026-12-30. Only the database's "different" answer from normal-form comparison, and the related batch check, depend on it; every certificate the ledger presents as proved does not. My recommendation is to accept with H-057 deferred and prove it before it expires.

# Summary of changes for run fdfcd9be-00d0-4ab9-a850-a48ed70ed5ba
I finished Phase 2 sprint 5: the adapter that connects QBX-IR to the braid ledger. It writes a braid and its rewrite history into the ledger, reads them back, and checks that nothing changed. I added no migration and changed no frozen file. The Lean statements for this sprint are proved, and I added no provisional hypothesis.

**Python adapter (`QBX/src/qbx_ir/ledger_adapter.py`).** The adapter works with any storage backend that offers the same set of operations. Two backends exist:
- `InMemoryBraidLedger`, in the same file. It is the in-memory reference and behaves like the database's own writers.
- `PostgresBraidLedger`, in the new `QBX/src/qbx/db/braid_ledger.py`.

The main functions:
- `trace_problems` checks a rewrite trace before anything is written, so a bad trace leaves nothing half-written in the ledger.
- `write_trace` and `persist_normal_form` write the braid, one record per rewrite step, and the derivation from the braid to the end of the trace. The adapter sends only the input braid, the rule and the position. The database works out each result itself, and the adapter checks that the record it gets back is exactly the step it sent.
- `read_braid`, `read_transformation` and `read_trace` read the data back as QBX-IR objects.
- `verify_trace` compares what the ledger holds with the original braid and trace. It also asks the ledger to confirm, by its own check, that the start and end braids are equal.
- `certificate_problems_of_trace` adds the invariant, normal-form and representation certificates (migrations 020–022) to both ends and checks that they agree.
- `round_trip` does all of the above in one call.

If PostgreSQL refuses a write, the adapter raises an error and the database transaction stays usable.

**Lean (`QBX/Formal/BraidTrace.lean`, imported from `QBX/Formal.lean`).** It models the reduction loop of `normal_form_with_trace` step by step. `lake build QBXFormal` succeeds, the file has no `sorry`, and it uses only the standard axioms. What it proves:
- **The ledger always accepts the adapter's derivation** (`normalFormTrace_chainEnd`): for any iteration limit, the ledger's derivation check accepts the derivation the adapter writes for a normal-form trace, and that derivation ends at the reduced word. So the braid and its reduced word are the same braid.
- **Where the loop stops** (`reduceStep_eq_none_iff`): exactly at words with no cancellable pair of letters and no swap left to make.
- **The loop terminates** (`normalFormTrace_reduced`, `normalFormTrace_length_le`, `measure_le`): it finishes within length + length² steps. The Python limit of 100000 iterations is therefore never reached for words of up to 315 letters.
- **Agreement with Python** (`normalFormTrace_agrees_with_python`): on 14 test cases with 1–6 strands, Lean gives exactly the rules, positions and reduced words that Python gives.

**Tests.**
- All 896 Python tests pass, 24 of them new. As before, I ran them in a separate environment built from `requirements.txt`, because the project's own Python environment isn't available here.
- On a real PostgreSQL 16, the database backend and the in-memory reference were run side by side on random braids and random traces. They held the same rows, refused exactly the same writes, and reported the same problems, including for a derivation inserted without going through the writer.
- After the adapter writes, `run_phase2_batch_checks()` reports no problems.
- When I deliberately weakened the reference so it accepted invalid letters, the tests caught it.
- `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass.

**Records updated.** The hypothesis registry (H-060, H-061, R-021), `docs/phase_2_scope.md` (sprint 5 marked done), the README (new adapter section and Lean table row), the file map, the decision log, the session log and `project_state.json`. While updating `project_state.json` I also added migration 022 to its list of Phase 2 migrations, where it had been left out.

The new results are in the Properties table and everything is committed. The next step is sprint 6, the Phase 2 acceptance review.

# Summary of changes for run 77545d9c-2bc2-4fa2-9c1a-e0bb752143a2
I finished Phase 2 sprint 4 (migration 022). The database can now store each braid's exact matrix in the `U_q(sl₂)` quantum representation (`SL2RMatrix`) for any non-zero rational q. It compares these matrices exactly, with no tolerance. Everything Lean says about these certificates is proved; this sprint added no provisional hypothesis.

**Database (`QBX/migrations/022_braid_representations.sql`).** A new append-only table, `braid_representation`, holds one certificate per braid and value of q. A certificate is the matrix's whole-number numerators over a positive denominator, in lowest terms, plus the braid's hash. The database recomputes it from the braid word using whole numbers only. Braids with up to 6 strands are accepted, since the matrix has 4ⁿ entries.
- **Writing:** `certify_braid_representation(braid, q_num := 2, q_den := 1)` computes and stores a certificate. A row written any other way is checked when it is inserted, and strict mode refuses it.
- **Comparing:** `braid_representation_equal(a, b, q_num, q_den)` returns one of three answers:
  - TRUE: the two matrices are exactly equal. This is equality of representations, not equality of braids, because the representation may not tell all braids apart.
  - FALSE: the two braids are proved different.
  - NULL: the braids can't be compared, for example because a valid certificate is missing.
- **Inequality only:** `braid_representation_inequality_certified` returns true exactly in the FALSE case.
- **Batch check:** `check_braid_representations()` re-checks every certificate. It also checks that certificates agree along every accepted rewrite and derivation, and that braids proved equal by their normal forms (migration 021) never have different certificates. `run_phase2_batch_checks()` now runs it too. I changed no frozen file.

**Python.**
- `src/qbx_ir/quantum/exact.py` computes the same exact matrices.
- `src/qbx_ir/representation_ledger.py` is the reference implementation for the migration.
- `check_equality(…, EqualityKind.REPRESENTATION)` now compares exactly when given `ExactSL2Representation(q)`. Otherwise it still compares numerically, as before.

**Lean (`QBX/Formal/BraidRepCert.lean`).** It is imported from `QBX/Formal.lean`. `lake build QBXFormal` succeeds with no `sorry`, using only the standard axioms. Results:
- **Equal braids give equal matrices** (`repMat_eq_of_eval_eq`): the matrix built letter by letter depends only on the braid. This holds for every invertible solution of the Yang–Baxter equation.
- **Certificates match matrices** (`repCert_eq_iff`): two certificates with the same q are equal exactly when the two exact matrices are equal. This rests on two facts: the whole-number calculation is (p r)^length times the rational matrix, and a fraction in lowest terms is unique.
- **Equal braids give equal certificates** (`repCert_eq_of_eval_eq`), so the transport and consistency checks can never fire on correct data.
- **Different certificates mean different braids** (`eval_ne_of_repCert_ne`).
- **Agreement with Python** (`repCert_agrees_with_python`): the Lean model gives exactly the same numerators and denominators as Python on 8 test cases with 1–3 strands.
- **More information than invariants** (`representation_detects_more`): the braid σ₁²σ₂²σ₁⁻²σ₂⁻² has the same invariant certificate as the identity braid, but a different representation certificate, so it is proved not to be the identity.

**Tests and checks run:**
- All 872 Python tests pass, 23 more than before. They include a comparison against a real PostgreSQL 16 on random data with tampered certificates, where the database reported exactly the same problems as the Python reference, in the same order (recorded as R-020).
- A deliberately broken calculation that ignores inverse letters was caught by both the transport check and the consistency check.
- The exact matrices agree with the existing floating-point `representation_alt`.
- `tests/test_triggers.sql` passes Tests 1–12 after migrations 001–022; Test 12 is new.
- `verify_frozen.py --require-signature` (52 frozen interfaces, with the new signature), `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass.

I also updated:
- the hypothesis registry (H-058, H-059, R-020)
- `docs/phase_2_scope.md` (sprint 4 marked done)
- the README and the file map
- `scripts/run_all_migrations.sh`
- the decision log, the session log and `project_state.json`

Sprint 5 (connecting QBX-IR to the ledger) is next. The new results are in the Properties table, and everything is committed.

As before, the project's own Python environment points to an installation that isn't on this machine, so I ran the tests in a separate environment built from `requirements.txt`.

# Summary of changes for run 09ca65c7-a797-4880-8257-aa27dff8c466
I finished Phase 2 sprint 3: Garside normal-form certificates (migration 021). The database can now prove that two braids are **equal** by comparing their normal forms, and Lean proves this certificate correct. Garside's uniqueness theorem (equal braids always have the same normal form) is proved only for 1 and 2 strands. For 3 or more strands it is not proved and is registered as provisional entry H-057, which expires 2026-12-30.

**Database (`QBX/migrations/021_braid_normal_forms.sql`).** A new append-only table, `braid_normal_form`, holds one certificate per braid. It stores the power of Δ, the simple factors, the normal-form word and the braid's hash. The database recomputes all of these from the braid word with a SQL translation of `left_normal_form_from_short`.
- **Writing:** `certify_braid_normal_form(braid)` computes and stores a certificate. A certificate written any other way is checked when it is inserted; strict mode refuses it.
- **Proving equality:** `braid_nf_equality_certified(a, b)` returns true when two braids with the same strand count have the same valid normal form, which proves they are equal.
- **"Different":** `braid_normal_form_equal(a, b)` also returns `FALSE` when the normal forms differ. For 3 or more strands this means "different" only if H-057 holds, so it is documented that way. The proven way to show two braids differ is still the invariant certificates of migration 020.
- **Batch check:** `check_braid_normal_forms()` re-checks every certificate. It also checks that normal forms agree along every accepted rewrite and derivation (this relies on H-057). Finally, it checks that braids with the same normal form never have different invariant certificates (this uses only proved results). `run_phase2_batch_checks()` now also runs it. I changed no frozen file.

**Python reference:** `src/qbx_ir/normal_form_ledger.py`.

**Lean.** Both files are imported from `QBX/Formal.lean`, and `lake build QBXFormal` succeeds with no `sorry` and only the standard axioms.
- `QBX/Formal/SimpleBraid.lean`: one adjacent swap changes a permutation's inversion count by exactly ±1. Two shortest positive words for the same permutation are the same braid (`eval_eq_of_reduced`, the positive form of Matsumoto's theorem). It also covers how simple braids split, how they extend, and how conjugation by Δ acts on them.
- `QBX/Formal/BraidNormalForm.lean`: a step-by-step model of the Python normal-form algorithm. The two `while` loops get an explicit iteration limit; the soundness results hold for any limit.
  - **Soundness** (`nfValue_leftNormalForm`): the normal form is the same braid as the input word.
  - **Equal normal forms mean equal braids** (`eval_eq_of_leftNormalForm_eq`) and equal invariant certificates (`cert_eq_of_leftNormalForm_eq`).
  - **Uniqueness for at most two strands** (`leftNormalFormComplete_of_le_two`). For 3 or more strands it is stated as `LeftNormalFormComplete` but not proved.
  - **Agreement with Python:** the Lean model gives the same power, factors and normal-form word as Python on 10 examples with 1–5 strands (`leftNormalForm_agrees_with_python`). That the iteration limit always matches Python's loops is argued by counting moves but not proved.

**Tests and checks run:**
- All 849 Python tests pass, including 26 new ones, among them a comparison against a real PostgreSQL 16. On random data the database reported exactly the same problems as the Python reference, in the same order (recorded as R-019).
- Deliberately broken versions of the invariant computation and of the normal form were caught by the consistency and agreement checks.
- As a check that the value comparison catches real differences, I briefly broke one step of the SQL algorithm, and the comparison failed. Changing the order in which factors are rearranged did not change any result, as uniqueness predicts.
- `tests/test_triggers.sql` passes Tests 1–11 after migrations 001–021; Test 11 is new.
- `verify_frozen.py --require-signature` (52 frozen interfaces), `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass.

I also updated the hypothesis registry (H-054 to H-057, R-019), `docs/phase_2_scope.md` (sprint 3 done), the README, the file map, `scripts/run_all_migrations.sh`, the decision log, the session log and `project_state.json`; sprint 4 (exact representation certificates, migration 022) is next. The results are in the Properties table and everything is committed.

The project's `QBX/.venv` points to a Python installation that isn't on this machine, so I ran the tests in a separate environment built from `requirements.txt`.

# Summary of changes for run cd0046f8-9274-4892-bd6e-bc0ef0d5735d
I took your "Continue" as approval of the proposed Phase 2 plan (open question Q-006, option 1) and finished **Phase 2 sprint 2: braid invariant certificates (migration 020)**. Q-006 is marked resolved. Sprint 3 (Garside normal-form certificates, migration 021) is recorded as next.

**Database (`QBX/migrations/020_braid_invariants.sql`).** A new append-only table, `braid_invariant`, holds one certificate per braid. It records the permutation, the writhe, the closure components, the linking numbers of the closure, and the braid's hash. The database recomputes every field from the braid word.
- **Writing:** `certify_braid_invariants(braid)` computes and stores a certificate. A certificate written any other way is checked when it is inserted; problems are logged under module `braid_invariants`, and strict mode refuses the row.
- **Proving two braids different:** `braid_invariant_differences(a, b)` and `braid_inequality_certified(a, b)` report when two braids with the same strand count are different braids. This is the first ledger function that can prove two braids *different*. A `FALSE` result means "not certified", not "equal".
- **Batch check:** `check_braid_invariants()` re-checks every certificate, and checks that certificates agree along every accepted rewrite and derivation. `run_phase2_batch_checks()` now also runs it. I changed no frozen file.

**Python reference:** `src/qbx_ir/invariant_ledger.py`.

**Lean (`QBX/Formal/BraidInvariantCert.lean`).** It builds as part of `lake build QBXFormal`, with no `sorry` and only the standard axioms. What it proves:
- **The fields are braid invariants.** The database's crossing loop gives the same result for any two words of the same braid, whatever each crossing is weighted by. Hence the permutation, the writhe, the crossing totals per pair of strands and the linking totals all agree for equal braids (`cert_eq_of_eval_eq`, `linkTotal_eq_of_eval_eq`). So the agreement check can never fire on valid certificates.
- **Different certificates mean different braids** (`eval_ne_of_cert_ne`).
- **Stored linking numbers are exact** (`linkTotal_even`): the total being halved is always even, so the integer division never rounds.
- **Linking adds information** (`crossings_detect_more`): in B₃, σ₁²σ₂⁻² has the same permutation and writhe as the identity braid but is proved different from it.

These are registered as H-052 and H-053 in the hypothesis registry, and are in the Properties table.

**Tests and checks run:**
- All 822 Python tests pass (808 before, 14 new), including a comparison against a real PostgreSQL 16 on random data with tampered certificates. The database reported exactly the same problems as the Python reference, in the same order; this is recorded as R-018. As a check that this comparison catches real differences, I briefly broke the SQL crossing loop, and the comparison failed.
- `tests/test_triggers.sql` passes Tests 1–10 after migrations 001–020; Test 10 is new.
- `verify_frozen.py --require-signature` (52 frozen interfaces, signed by `sys-owner-2026`), `validate_agent_output.py` and `check_hypothesis_expiry.py` pass.

I also updated `docs/phase_2_scope.md`, the README, the file map, `scripts/run_all_migrations.sh`, and the decision log, session log, open questions and `project_state.json`. Everything is committed.

# Summary of changes for run 3a647ec9-ac0e-4cef-9c3d-fc5bdc34f425
I've formalized the Bible-braid conversion in Lean and proved its main properties. A kernel-checked theorem also shows the Lean version gives exactly the same braids as the Python converter on all 31 verses of Genesis 1. Both new files build with no `sorry`, and every theorem uses only Lean's standard axioms.

**The Lean model** (`QBX/Formal/BibleBraid.lean`) follows the Python rule one character at a time:
- Which characters count as marks: Hebrew points and cantillation, and combining accents U+0300–U+036F.
- Which characters are letters: Hebrew with its final (sofit) forms, Greek with final ς, and A–Z/a–z.
- How text splits into words, and how each letter becomes a generator: `(ordinal − 1) mod (n − 1)`, inverted for a final letter when the sofit rule is on.

It builds on the braid group already in `QBX/Formal/Braid.lean` and the writhe in `Invariants.lean`. One step is not modelled: the Unicode decomposition (NFKD) the Python code does first. The Lean model assumes the text is already decomposed. For the bundled Genesis text this makes no difference, because decomposition only reorders marks, and marks are dropped anyway.

**What is proved** (for any number of strands unless stated):
- **Verse = product of its words** (`convert_eval_eq_prod_words`), and **passage = product of its parts** (`convert_eval_append`). Conversion is a homomorphism from texts to the braid group (`convertHom`).
- **Marks never change the braid** (`convert_mark_invisible`): inserting a vowel point, accent or cantillation mark anywhere leaves the braid word unchanged.
- **Crossings = letters** (`convert_length`), and **writhe = letters − 2 × final letters** with the sofit rule on, or just letters with it off (`convert_writhe`).
- **Sofit test** (`sofit_changes_element_iff`): turning the sofit rule on or off changes the braid-group element exactly when the text contains a final letter. This is the general form of the check each run reports.
- **Decoding** (`decode_convert`): with at least 23 strands and the sofit rule on, the braid word gives back a Hebrew text's letters exactly, final forms included. This requires every letter in the text to be Hebrew, because Greek and Latin letters share generators with Hebrew ones.
- **Genesis 1:1** (`genesis_1_1_braid`, `genesis_1_1_braid_23`, `genesis_1_1_facts`): on the pointed Westminster Leningrad Codex text, the model gives the same words as the Python output on 8 and 23 strands. The verse has 7 words, 28 letters and 3 final letters, and its braid has writhe 22. Turning the sofit rule off changes its braid-group element.

**Python agreement on all of Genesis 1** (`QBX/Formal/BibleBraidGenesis1.lean`): `genesis_1_model_agrees_with_python` checks every verse on 8 strands (sofit rule on and off) and on 23 strands. The expected words come from a table generated from the Python output by the new `QBX/scripts/gen_lean_bible_table.py`. Because Lean recomputes all of these, this file takes about 7 minutes to build. It is part of the default `QBXFormal` build.

Both files are imported from `QBX/Formal.lean`, and `lake build QBXFormal` succeeds. I also added entries H-050 and H-051 to `QBX/Formal/HYPOTHESIS_REGISTRY.md` and a Lean paragraph to the README's "Bible braids" section. The frozen-hash signature check and the agent-output check still pass. The results are in the Properties table and everything is committed.

# Summary of changes for run cb699ea4-12d6-429a-ad64-80054c303e33
I checked the re-signed hashes, then started Phase 2 and finished its first sprint: storing QBX-IR braids and their rewrite history in the ledger (migration 019).

**The re-signed hashes are valid.** `verify_frozen.py --require-signature` passes. The signature is a real Ed25519 signature by `sys-owner-2026`, and the trust anchor now lists only that key; the old development key is gone. The 52 hashed files are exactly the frozen files listed in `project_state.json`. No private key is stored in the repository. Phase 1 is recorded as accepted. In `docs/phase_1_acceptance.md` I changed the prerequisites row that still said "proposed – needs human approval" and fixed two tables that a stray blank line had split.

**Phase 2 plan.** There was no written plan for Phase 2. In `docs/phase_2_scope.md` I proposed one, based on `docs/architecture.md`: connect the braid library to the ledger. Sprint 1 is done. The proposed next steps are:
- 2: invariant certificates (020)
- 3: Garside normal-form certificates (021)
- 4: exact representation certificates (022)
- 5: an adapter between the braid library and the ledger
- 6: an acceptance review

**Two design choices you may want to review** (reasons in the decision log). Migration 017 is frozen, so I didn't change it:
- New problems are logged to its existing `invariant_violation` table, so they still appear in `v_all_violations`.
- A new function, `run_phase2_batch_checks()`, runs the frozen `run_all_batch_checks()` and then the new checks.

**Sprint 1: the braid ledger (migration 019).**
- **Braids** are stored once per strand count and word. The database recomputes each braid's hash so it matches the Python `braid_hash`.
- **Rewrite records** store the input, rule, position, output, hashes and what the rule preserves. When a record is written, the database recomputes the output using the same rules as `apply_rule`.
- **Derivations** are chains of rewrite records, each used forwards or backwards. `braid_equality_certified(a, b)` is true when a recorded chain between `a` and `b` passes every check.
- All three tables are append-only: changes are logged, and refused in strict mode.
- The new functions that write rows (`register_braid`, `record_braid_rewrite`, `record_braid_derivation`) refuse bad input.
- The Python version of these checks is the new `src/qbx_ir/ledger.py`.

**Lean proofs (`QBX/Formal/BraidLedger.lean`, no `sorry`, standard axioms only):**
- `step_iff_exists_applyRule`: the database's rewrite check accepts a record exactly when it is one valid rewrite step (R01–R03).
- `chainEnd_eval_eq`: a derivation that passes the checks connects two braids that are equal as braids.
- `eval_eq_iff_exists_chain`: any two equal braids can be connected by such a derivation.
- `forward_chains_incomplete`: chains that only use records forwards can't prove every equality, which is why records can also be used backwards.

These six entries (two definitions, four results) are in the Properties table. They are also in the hypothesis registry as H-048 and H-049.

**Tests.** On random data (bad braids, wrong outputs, unknown rules, wrong hashes, broken chains), the database reported exactly the same problems as the Python version, in the same order (registry R-017). Every kind of problem came up. As a check that the comparison catches real differences, I briefly broke one of the R03 conditions in the SQL, and the comparison failed. I also added Test 9 to `tests/test_triggers.sql`.

**Checks run:**
- All 785 Python tests pass (767 before, plus 18 new), under hash seeds 0, 1 and 12345, including the tests against a real PostgreSQL 16.
- `tests/test_triggers.sql` passes Tests 1–9 after migrations 001–019.
- `lake build QBXFormal` succeeds.
- `validate_agent_output.py`, `check_hypothesis_expiry.py` and `verify_frozen.py --require-signature` pass.

I changed no frozen file. I updated the README, the file map, the decision and session logs, `project_state.json` and the open questions, and everything is committed.

**Needs your decision:** whether to go ahead with Phase 2 steps 2–6 as proposed. This is recorded as open question Q-006.

# Summary of changes for run 644d3757-7dcd-4551-bcdc-bfedd6f79554
I closed backlog item D1-001, the last open Phase 1 item I could do on my own. Phase 1 is still **not accepted**: that needs you, as described in `QBX/docs/phase_1_acceptance.md` §5.

**What I did.** Migration 007 (limits and colimits) was the only Phase 1 migration whose random comparison with its Python reference was narrow. The old test only covered two-node diagrams with no arrows, inside the divisor lattice of 12. I added two random comparisons to `QBX/tests/live_db/test_limits_db.py` (registry entry R-016):
- `test_random_cones_match_reference`: on 25 random data sets, the database's list of problems for each cone and cocone matches the reference's `cone_problems`.
- `test_random_universality_matches_reference`: on 20 more, `verify_limit_universality` and `verify_colimit_universality` give the same verdicts and reasons as `LimitChecker.verify_universality`, checked against the cones recorded over the same diagram.

The random data has:
- **Categories:** parallel morphisms and composition tables with some composites missing.
- **Diagrams:** arrows; nodes with no object or with an object from another category; arrows with no morphism, with the wrong type, or starting at a node of another diagram.
- **Cones:** some valid, plus cones with a missing leg, a leg of the wrong type, a leg from another category or another diagram, or an apex in another category.

Each test also checks that every possible problem type actually comes up. **The database and the reference agreed in every case.** I also tried six other random seeds and they agreed there too, though those seeds aren't saved as tests. Migration 007 is unchanged.

**Checks.** All 767 Python tests pass (765 before, plus the 2 new ones), under hash seeds 0, 1 and 12345, including the tests against a real PostgreSQL 16. `tests/test_triggers.sql` runs Tests 1–8 with every check passing. `lake build QBXFormal` succeeds; I changed no Lean file. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` pass. I changed no frozen file, and the work is committed.

**Documents updated:** the acceptance document (the migration 007 row, criterion P1-F10, the prerequisites and the verification record), the backlog (D1-001 marked resolved), the hypothesis registry (R-016), the README, the session log and `project_state.json`. I added nothing to the Properties table, because this work was database tests rather than Lean results.

**What's left needs you.**
1. Name an approver for the review.
2. Approve the proposed Phase 1 freeze list, then hash and sign it.
3. Deal with the signing key (D1-005). The current signature verifies, but it was made with the development key `dev-frozen-2026-10-01`. Either confirm only you hold that key, or re-sign with a new key using `--write-anchor`.
4. Record Phase 1 as accepted.

The other backlog items can wait: D1-002 is a documented choice about when 005/006 run their checks, D1-003 and D1-004 need real signatures or a model language, and D1-006 is a note. Phase 2 can start once Phase 1 is accepted.

# Summary of changes for run 8250a5f3-ba5d-43b2-84bc-706ffe6445ba
I did the next planned step, Phase 1 sprint 14: the acceptance review. I compared each Phase 1 migration (004–016 and 018) with its Python reference and drafted the acceptance checklist. **Phase 1 is ready for your review but is not accepted.** Accepting it needs a named human approver.

**The re-signed hashes:** `verify_frozen.py --require-signature` passes. However, the signature is byte-for-byte the one recorded for the development key on 2026-10-01, and the trust anchor still lists only that key (`dev-frozen-2026-10-01`). Ed25519 signatures are deterministic, so these files were signed with that same key. If only you hold that key, nothing more is needed. Otherwise, re-sign with a new key using `--write-anchor`. I recorded this in the decision log, under Q-002, and as backlog item D1-005.

**Checks:** all 765 Python tests pass (up from 743), under three hash seeds and including the tests against a real PostgreSQL 16. `tests/test_triggers.sql` runs without errors. `lake build QBXFormal` succeeds. I changed no Lean file. `validate_agent_output.py`, `check_hypothesis_expiry.py` and `verify_frozen.py` pass. I changed no frozen file, and everything is committed.

**What the review found.** Migrations 007–016 already had random tests against their references, and they still agree. Migrations 004, 005, 006 and 018 had no such tests, so I wrote them (registry entry R-015). Each new test found real disagreements, which I confirmed on PostgreSQL and fixed:
- **004 (natural transformations), rewritten:**
  - A component with the wrong type was accepted, even in strict mode.
  - So were components on objects of another category, and transformations between functors with different categories.
  - Squares where a functor didn't map the morphism, and identity squares, were skipped without a report.
  - The batch check logged every square twice and never reported missing components.
  - New functions: `check_natural_transformation`, plus writers that refuse wrongly typed input.
- **005 (adjunctions) and 006 (monads/comonads):** composites were looked up without checking that the two morphisms connect. With a wrongly typed component, a law could therefore be reported as failing, or wrongly pass, where the reference reports a missing composite. A new helper, `nt_compose_in`, checks this first.
- **018 (capability tokens):** `register_signed_capability` stored whatever token id, owner, scopes and expiry it was given. A token issued for `weyl:expand` with a 100-second lifetime could be registered with scope `*` and a much later expiry, and revoking its real id did nothing. `not_before` was also ignored. The function now reads the token's own claims and refuses arguments that differ, and `not_before` is enforced.

**Interface changes:** function signatures are unchanged. `register_nt_component` and `register_signed_capability` now refuse input they used to accept. `run_all_batch_checks` logs each naturality problem once instead of once per component, and I updated the one test that expected the old count.

**Acceptance documents**
- `docs/phase_1_acceptance.md`: the protocol's prerequisites, the review table for each migration, criteria P1-F1 to F11 and P1-N1 to N5, and the steps left for you. A new test, `tests/test_phase1_acceptance_doc.py`, checks that every test the document cites exists.
- `docs/phase_1_scope.md` (scope) and `agents/memory/deferred/phase_1_backlog.md` (six deferred items, D1-001 to D1-006).
- `docs/acceptance.md` was cut off in the middle of row F7. I completed that row and added a note that any later rows are lost.

**Steps left for you:** approve the review; approve the proposed Phase 1 freeze list; hash and sign it; then record Phase 1 as accepted. Deferred items include wider random tests for migration 007 (D1-001); the review found no disagreement there.

I also updated the README, the file map, the hypothesis registry, the decision and session logs, and `project_state.json`. I added nothing to the Properties table: this sprint produced database fixes and tests, not Lean results.

# Summary of changes for run c3ab489a-e1be-4d25-b62b-e3ba2161f978
I did the next planned step, Phase 1 sprint 13: empirical grounding (migration 016). Like 004–015 before it, it now has a database version, a matching Python version (`qbx.empirical`) and Lean proofs.

**Checks:** all 743 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 713. I ran them under three Python hash seeds, and they include the tests against a real PostgreSQL 16. `tests/test_triggers.sql` also runs cleanly, including a new Test 8. `lake build QBXFormal` succeeds. `QBX/Formal/Empirical.lean` has no `sorry`, and its theorems use only the standard axioms. `validate_agent_output.py`, `check_hypothesis_expiry.py` and `verify_frozen.py --require-signature` pass. I changed no frozen file, and everything is committed.

**Bugs in the original migration 016** (each confirmed by running it on PostgreSQL)
- Validating a bundle that doesn't exist returned true.
- An observation with no value passed the range check. Observations stored as a JSON object instead of a list made validation crash with a raw database error.
- A misspelled test ('rnage_check') was silently ignored, and bounds of min 10 > max 0 were accepted, so a bundle validated against them.
- `validated` could be set to true without any validation, and it stayed true after the observations were changed.
- Many bad values were accepted: blank names, negative precision, a solver config of `[1]`, a simulation with tolerance −1 that finished before it started, a mechanism spec of `"x"`, a gaussian sigma of −2, and sensors given as `5`.
- A mechanism's claims to be incentive compatible were never checked.
- Nothing was logged, and nothing was part of `run_all_batch_checks`.

**The rewrite**
- **Measurements:** uncertainty types come in three kinds: interval, uniform, and gaussian with a coverage factor. Contracts are checked for bounds, unit, precision, and known tests that are not repeated.
- **Validations:** a new append-only table, `measurement_validation`, records each validation. Its report lists every failing (test, observation) pair, and the checks recompute it. Each bundle must carry the result of its latest validation.
- **Exact arithmetic:** values are compared exactly, so 9.7 + 0.3 ≤ 10 passes. In ordinary floating point it would fail.
- **Models and agents:** dynamical models, simulation runs and agent models are now type-checked.
- **Mechanisms:** a mechanism is described as a finite table of types, outcomes, allocation, payment and valuation. If it claims `ic` or `ir`, the claim is checked, and every profitable misreport is reported with its gain.
- **Where problems go:** a new `empirical_violation` table, shown in `v_all_violations`. `check_empirical` runs as part of `run_all_batch_checks`, and all writers refuse bad input or false claims.

**Python version and tests:** tests on random inputs show the database reports exactly the same problems as `qbx.empirical`, in the same order. Further tests cover strict mode, the append-only log, an edited bundle being caught in the batch check, re-applying the migration, and upgrading a database that has the original 016.

**Lean (`QBX/Formal/Empirical.lean`, registry entries H-046 and H-047; test-checked entry R-014)**
- `rangeOk_iff`: the range check holds exactly when every value the measurement allows is within the bounds.
- `rangeOk_factor_antitone`: a larger coverage factor only makes the check stricter.
- `report_eq_nil_iff` and `mem_report_iff`: a validation passes exactly when every test passes on every observation, and the report lists exactly the failures.
- `icFailures_eq_nil_iff` and `irFailures_eq_nil_iff`: the database's lists of incentive-claim failures are empty exactly when the mechanism is incentive compatible or individually rational.
- `ic_payment_bounds`, `ic_weak_monotone` and `ic_single_parameter_monotone`: in an incentive-compatible mechanism, payment differences lie between valuation differences, so higher types never get worse outcomes.

**Decisions you may want to review** (reasons in `decision_log.md`)
- For a uniform uncertainty type, the recorded uncertainty is read as the half-width of the range. Reading it as a standard deviation would need a √3 factor, which can't be checked exactly.
- Only incentive properties that a mechanism claims are checked. Many legitimate mechanisms, such as first-price auctions, are not incentive compatible.
- `mapping_function` and `model_spec` are still stored as free text and not evaluated. The README lists this as not yet implemented.

**Interface changes:** `validate_measurement_bundle` keeps its signature but now also records a validation row. New writers: `register_uncertainty_type`, `register_measurement_contract`, `record_measurement_bundle`, `record_simulation_run` and `register_agent_model`.

I also updated `017_all_triggers.sql`, the README, the file map, two skill docs, the decision and session logs, and `project_state.json`. The next sprint recorded there is the Phase 1 acceptance review. The Properties table has four new definitions and six results, all marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run 66c7a148-41b3-4ae6-9635-08c44a24cb64
I did the next planned step, Phase 1 sprint 12: governance modalities (migration 015). It now has a database version, a matching Python version (`qbx.governance`) and Lean proofs.

**Checks:** all 713 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 676. I ran them under three Python hash seeds, and they include the tests against a real PostgreSQL 16. `tests/test_triggers.sql` also runs cleanly; its new Test 7 covers governance. `lake build QBXFormal` succeeds. `QBX/Formal/Modality.lean` has no `sorry`, and its theorems use only the standard axioms. `validate_agent_output.py`, `check_hypothesis_expiry.py` and `verify_frozen.py --require-signature` pass. I changed no frozen file, and everything is committed.

**Bugs in the original migration 015** (each confirmed by running it on PostgreSQL)
- `register_policy` with the unknown modality 'nope' created a policy with no modality. A body of `42` and a version of 'banana' were accepted.
- The four seeded modalities could be changed (□ made a 'possibility') or deleted, and any monad or comonad could back any modality.
- An assignment could carry a different modality from its policy, or the scope 'fly'. Identical assignments were accepted, because blank columns slip past the uniqueness rule.
- A policy check could be logged with no policy, its result was never computed, and checks could be rewritten afterwards.
- A workflow with steps `"x"` and a timeout of −3 was accepted. So was an approval from an unknown role that expired before it was given.
- Audit records could be edited or deleted without leaving a trace.
- Nothing was logged, and nothing was part of `run_all_batch_checks`.

**The rewrite** (`migrations/015_governance_modalities.sql`)
- **Modalities:** the modality table must equal the seed. □ and ◇ are evaluated over one set of rules, the alethic frame; ! and ? over a second, the deontic frame. Only □ may be backed by a comonad and only ◇ by a monad, and the backing must pass its laws (batch check).
- **Frames:** new tables for governance contexts (such as dev, staging, production) and which contexts each one can see. The alethic frame must be reflexive and transitive, and the deontic frame serial.
- **Policies:** each needs a non-blank name, a `MAJOR.MINOR.PATCH` version, a JSON-object body, a modality and an enforcement level.
- **Assignments:** each must use its policy's modality and the scope read, write or execute.
- **Policy checks:** a check now records a context and an outcome for each context. The contexts it can see are stored when it is written, and the result is recomputed: `pass` if the modality's condition holds, otherwise `warn` for a soft policy and `fail` for a hard or blocking one.
- **Approvals:** workflows have ordered steps with distinct roles. Approvals have a validity window, and each step must be approved in order. A new `approval_status(workflow, artifact, at)` reports whether an artifact is approved at a given time.
- **Logs:** the audit log and the check log are append-only. Every edit, delete or truncate is logged, and refused in strict mode. Audit records form a SHA-256 hash chain that the batch check re-verifies, and existing records are chained when an old database is upgraded.
- **Where problems go:** a new `governance_violation` table, shown in `v_all_violations`. `check_governance` is part of `run_all_batch_checks`, and all writers refuse bad input.

**Python version** (`qbx.governance`): tests against the live database compare the two on random inputs. They found one real mismatch, now fixed: PostgreSQL has no `\v` escape, so blank-text detection disagreed with Python.

**Lean (`QBX/Formal/Modality.lean`, registry entries H-043 to H-045; test-checked entry R-013)**
- The frame checks are exactly the modal axioms. `□p ⊆ p` for every p holds iff the frame is reflexive, `□p ⊆ □□p` iff it is transitive, and `!p ⊆ ?p` iff it is serial.
- On a valid alethic frame □ is a comonad and ◇ a monad (`boxComonad`, `diaMonad`).
- `◇ = ¬□¬` (`holds_dual`), and the computed result is `pass` exactly when the modality's condition holds (`result_eq_pass_iff`).
- The latest audit hash commits to the whole log (`chainHash_injective`). This assumes the hash has no collisions, which is stated as a hypothesis, not proved.

**Interface changes:** `log_policy_check` now takes a context and outcomes and computes the result; the old version took the result as given. `register_policy` gains a version argument. Nothing in the repository used the old forms.

**Decisions you may want to review** (reasons in `decision_log.md`)
- ! and ? are treated as deontic operators, not comonads or monads, because what is obligatory need not actually hold.
- A check keeps the contexts it was evaluated against, so later changes to the frames don't make old checks look wrong.
- Workflow timeouts count 24-hour days, so they don't shift with daylight-saving changes.
- Approval and audit signatures are stored but not verified, because signing is still a placeholder.

I also updated `017_all_triggers.sql`, the README, the file map, two skill docs, the decision and session logs, `project_state.json` (next sprint: empirical grounding, migration 016) and `scripts/seed_full_corpus.py`. The Properties table has four new definitions and six results, the results all marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run a1fdde89-6b1f-4d2b-8427-c09b791ec9e1
I did the next planned step, Phase 1 sprint 11: Hebrew primacy (migration 014). It now enforces rules R1–R7 from `agents/skills/hebrew_primacy_rules.md` in the database, with a matching Python version and Lean proofs.

**Checks:** all 676 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 611. I ran them under three Python hash seeds, and they include the tests against a real PostgreSQL 16. `lake build QBXFormal` succeeds. `QBX/Formal/Gematria.lean` has no `sorry`, and its theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` pass. I changed no frozen file: `HebrewMixer` and the gematria values are untouched. Everything is committed.

**Bugs in the original migration 014** (each confirmed by running it on PostgreSQL)
- `UPDATE hebrew_word SET total_gematria = 1` was accepted, because the trigger only recomputed the total when the text changed.
- `compute_gematria` was declared `IMMUTABLE` even though it reads the letter table. That table could be changed freely (setting א to 7, or adding a row 'X' with value −5), and totals already stored were never revisited.
- 'hello world 123' was accepted as a word, and '!!' as a root, both with total 0. The precomposed character U+FB2A counted 0, while its normalized form שׁ counts 300.
- Any vector was accepted as a word's embedding.
- Gematria functors were accepted with rules like `{"א": -3, "zz": "x"}` and with no categories, and there was no way to record a naturality obligation (R2).
- Torah sites had no site or presheaf, and a section 'nonsense 999' with text 'abc' was accepted (R5).
- Language adjunctions had no status (R6), and Hebrew ⊣ Hebrew was accepted.
- Nothing was logged, and nothing was part of `run_all_batch_checks`.

**The rewrite** (`migrations/014_hebrew_primacy.sql`)
- **Letter table:** must equal the seed (finals still 500–900). Every change to it is checked when it happens.
- **Words:** the total is recomputed on every write. A word must be normalized (NFC) text made of letters and Hebrew vowel and cantillation marks. A stored embedding must equal `gematria_vector(text)`.
- **Gematria functors:** need both categories and valid rules. Each one also needs naturality obligations, recorded in a new table; their claimed values are recomputed and must add up.
- **Torah sites:** now link to a site and presheaf from migration 012. The presheaf must pass the sheaf check and match the verse texts. A new `build_torah_presheaf` builds that presheaf. Verse references must name a Torah book and a chapter within that book's chapter count.
- **Language adjunctions:** marked `provisional` unless backed by a Lean proof record (a proof artifact of type `lean4`).
- **Where problems go:** a new `hebrew_violation` table, shown in `v_all_violations`. `check_hebrew` is part of `run_all_batch_checks`. Errors are raised only in strict mode.
- **Writers:** all of them refuse bad input.
- **Upgrading:** an existing database with the original tables can be upgraded; a test covers this.

**Python version** (`qbx.hebrew.text`, `.functor`, `.torah`): it runs the same checks and reports the same problems with the same details. Tests against the live database compare the two on random inputs, and every problem type occurs.

**Lean (`QBX/Formal/Gematria.lean`, registry entries H-040 to H-042)**
- `wordValue_append` and `gemHom_toAdd`: gematria is a functor for any letter values, so the naturality square always commutes.
- `additive_eq_wordValue`: such a functor is determined by its 27 letter values, so checking the rules is enough.
- `obligation_value_mismatch_of_square`: if an obligation's recorded values don't add up, at least one of them is wrong.
- `standard_injective` and `final_ne_base`: the 27 seeded values are all different, so each final form differs from its base form.
- `wordValue_not_injective`: different words can share a value (אב and ג are both 3).
- `textSheaf_locality_and_gluing`, `textSheaf_subsingleton` and `textSheaf_nonempty_iff`: the passage presheaf is a sheaf, with exactly one section over an open set when every verse in it has a text, and none otherwise.

**Decisions you may want to review** (reasons in `decision_log.md`)
- Final forms in the middle of a word are allowed, because there are attested spellings like that.
- Only chapter counts are checked, not the number of verses in each chapter.
- A Torah site without a presheaf is reported only by the batch check, so it can be built step by step even in strict mode.

I also updated `017_all_triggers.sql`, the README, the file map, the hypothesis registry (including new test-checked entry R-012), three skill docs, the decision and session logs and `project_state.json`. The next sprint recorded there is governance modalities (migration 015). The Properties table has three new definitions and seven results, all marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run 664c84da-efff-4401-8368-d7359e054574
I did the next planned step, Phase 1 sprint 10: the addressing protocol (migration 013, AddressV2). First I fixed a test from the previous sprint that failed on some runs.

**Checks:** all 611 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 487, under several Python hash seeds. That includes the tests against a real PostgreSQL 16. `lake build QBXFormal` succeeds, `QBX/Formal/Addressing.lean` has no `sorry`, and its theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` pass. I changed no frozen file, and everything is committed.

**Fixed test:** the sheaf comparison test (sprint 9) depended on Python's hash seed. Its random examples walked through a set, so whether every problem type occurred depended on the seed. They are now built in a fixed order, with a seed that produces every problem type.

**Bugs in the original migration 013** (I confirmed each one by running it on PostgreSQL)
- Calling `register_address` again for an existing address replaced its pointers, trust score and depth, and silently ignored the new bytes.
- No address hash was ever checked against its bytes. A hash `'h'` over a single zero byte was accepted.
- Trust values such as −7 were accepted.
- Cache entries with a negative time-to-live were accepted, and nothing ever read the cache.
- Gateways for unregistered addresses were accepted with any endpoint or protocol.
- DHT node ids of any length were accepted.
- Nothing was logged or part of `run_all_batch_checks`.

**The rewrite** (`migrations/013_addressing_protocol.sql`)
- **Hash check:** the database recomputes every hash itself. SHA3-256/512 are written in the database's own procedural SQL (PL/pgSQL), so no extension is needed.
- **Encoding check:** a strict decoder for the canonical CBOR encoding the project uses. It reports the first malformation and every non-canonical encoding.
- **Content checks:** the AddressV2 fields, types and ranges; the stored trust values must match the address's trust hint; pointers must be distinct.
- **Other tables:** cache entries, gateways, DHT nodes and discovery records are checked too.
- **Where problems go:** every check runs when a row is written and in batch. Problems go to a new `address_violation` table, which `v_all_violations` shows. Errors are raised only in strict mode.
- **Writers:** an address's hash, bytes, algorithm and owner can never change. Registering an address again only adds pointers. All writers refuse bad input.
- **New functions:** address resolution (the registry first, then the newest valid cache entry), cache purging, XOR distance and buckets, and the k closest DHT nodes.
- **Upgrading:** an existing database with the original tables can be upgraded; a test covers this.

**Python version** (`qbx.addressing`): it runs the same checks and reports the same problems with the same details. Checked in the database tests on random inputs:
- the database's SHA3 matches Python's;
- the decoder matches on 1500 inputs and the address checks on 1200 cases, with every problem type occurring;
- address resolution and closest-node routing match.

It also checks that the address built for a `PathSignature` hashes to that signature's `address_hash`.

**Decision you may want to review:** trust scores must now be between 0 and 1. `PathSignature.build` doesn't enforce this, so an address built with a score outside that range will be reported. The reasoning is in `decision_log.md`.

**Lean (`QBX/Formal/Addressing.lean`, registry entries H-037 to H-039)**
- `xorDist_triangle` and `xorDist_unidirectional`: XOR distance is a metric, and no two nodes are the same distance from a key.
- `bucket_ultrametric`: the routing buckets form an ultrametric.
- `kClosest_exists` and `kClosest_unique`: the k closest nodes always exist and are unique, so the result never depends on tie-breaking.
- `bytea_xor_order`: sorting the bytewise XORs the way the database sorts byte strings is the same as sorting by XOR distance. This is why the database's closest-node query is correct.

I also updated `017_all_triggers.sql`, the README, the file map, the hypothesis registry (including new test-checked entry R-011), the two skill docs, `decision_log.md`, `session_log.md` and `project_state.json`. The next sprint recorded there is Hebrew primacy (migration 014). The Properties table has the two definitions and six results; the results are marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run b7c06342-3c57-45d0-879a-a3b19f26f104
I did the next planned step, Phase 1 sprint 9: sheaf cohomology (migration 012). It covers finite sites, presheaves and the sheaf condition, with Čech H⁰ checked in the database.

**Checks:** all 487 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 449. That includes the tests against a real PostgreSQL 16. `lake build QBXFormal` succeeds, `QBX/Formal/Sheaf.lean` has no `sorry`, and its theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass. I didn't change any frozen file, and everything is committed.

**Bugs in the original migration 012** (I confirmed each one by running it on PostgreSQL)
- `check_sheaf_condition` only returned the stored `is_sheaf` flag. It was FALSE for every presheaf until someone set it by hand, and TRUE after.
- Presheaves had no restriction maps, so the sheaf condition couldn't be stated. `register_presheaf` accepted sections over keys that aren't open sets.
- `store_cohomology_group` and `store_cech_cochain` accepted negative degrees and a site other than the presheaf's.
- `sheaf_descent_data` accepted `verified = TRUE` with no check.
- Nothing checked that a cover actually covers anything. Nothing wrote to the obstruction table, and nothing was part of `run_all_batch_checks`.

**The rewrite** (`migrations/012_sheaf_cohomology.sql`)
- **New tables:** open sets with their points, named covers, and sections and restriction maps for each presheaf.
- **Site checks:** the open sets form a topology (∅, the base, closed under ∩ and ∪). Each cover's members are open sets inside the covered set, and their union is the covered set.
- **Presheaf checks**, run in stages:
  - typing;
  - restrictions are total and respect identities and composition;
  - exactly one section over ∅;
  - on every registered cover, locality and gluing, reported separately with counts;
  - recorded H⁰ sizes are compared with the number of compatible families.
- **`is_sheaf`:** only the checker can set it. Any change to the presheaf's data or its site resets it.
- **Descent data:** `verified` is computed when the row is written. A new `verify_descent` records one.
- **Writers:** new writers for sites, open sets, covers and restrictions; the existing ones now refuse badly typed input. None of them ever replaces a row.
- **Where problems go:** the obstruction table now has a `reason` column, and `v_all_violations` shows it. Both checks are part of `run_all_batch_checks`. Errors are raised only in strict mode.
- **Upgrading:** an existing database with the original tables can be upgraded; a test covers this. Old cover rows become a `default` cover of the base, and sections recorded under object ids are imported.

**Scope:** the database checks the sheaf condition on the registered covers plus the empty cover of ∅, so a pass means "a sheaf for the registered covers". Higher-degree cohomology ranks are stored with their type checked, not their value.

**Python version** (`qbx.categorical.sheaf`): it runs the same checks and reports the same problems with the same details. On 250 random examples the database and Python report exactly the same problems, and every kind of problem occurs. It also has `is_sheaf`, which checks every cover, and Čech cohomology over F₂ (`LinearPresheaf`).

**Lean (`QBX/Formal/Sheaf.lean`, registry entries H-034 to H-036)**
- `isSheaf_iff_locality_and_gluing`: locality and gluing over every cover are together exactly Mathlib's `IsSheaf`.
- `uniqueBot`: a sheaf has exactly one section over ∅.
- `constBool_gluing_not_locality` and `constEmpty_locality_not_gluing`: neither half implies the other, so the checker needs both.
- `card_compatible_eq`: for a sheaf, the number of compatible families on a cover equals the number of sections over the covered set.
- `presheafToTypes_locality_and_gluing`: the presheaf of all functions passes both halves.

**How the tests use these results**
- The presheaf of all functions passes on every cover, and its H⁰ size equals the number of sections.
- The two constant presheaves fail only locality and only gluing, respectively.
- With every cover registered, the checker's verdict matches `is_sheaf`.
- Every sheaf found has one section over ∅.
- The F₂ cohomology gives the expected results for the hollow and filled triangle and vanishes above degree 0 for the sheaf of all functions. It also satisfies d∘d = 0 and the Euler-characteristic identity.

I also updated `017_all_triggers.sql`, the README, the file map, `decision_log.md`, `session_log.md`, `project_state.json` (next sprint: addressing protocol, migration 013), `HYPOTHESIS_REGISTRY.md` (including new test-checked entry R-010) and the two skill docs. The Properties table has the two definitions and five results; the results are marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run f12b6e0e-91bd-43cb-b1a3-81dee26b6c6a
I did the next planned step, Phase 1 sprint 8: the topos kernel (migration 011), which handles subobject classifiers.

**Checks:** all 449 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 407. That includes the tests that run against a real PostgreSQL 16. `lake build QBXFormal` succeeds, `QBX/Formal/Topos.lean` has no `sorry`, and the new theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass. I didn't change any frozen file, and everything is committed.

**Bugs in the original migration 011** (each confirmed by running it on PostgreSQL)
- It accepted a classifier whose `true` doesn't end at `Ω`, and one with no `true` at all.
- `register_subobject` accepted a morphism that isn't a monomorphism, a morphism from another category, and an object that isn't the morphism's target.
- `attach_characteristic` accepted any morphism as `χ`. Its `ON CONFLICT … DO UPDATE` silently replaced one that was already attached.
- Nothing checked the pullback square, that `χ` is unique, or that `1` is terminal. There was no violation table, and nothing was part of `run_all_batch_checks`.

**The rewrite** (`migrations/011_topos_kernel.sql`)
- **Checked on every write:** that the classifier, subobjects, characteristic morphisms and truth values are well typed. A truth value can now name its element `1 → Ω` through a new `morphism_id` column.
- **Checked in batch** (`check_subobject_classifier`, now part of `run_all_batch_checks`):
  - `1` is terminal.
  - Each registered subobject is a monomorphism on the recorded data.
  - Each registered `χ` makes the square a pullback. Commuting, existence and uniqueness are reported separately.
  - Every monomorphism has exactly one `χ` that passes this check. If none does, it reports `unclassified_mono`; if several do, `characteristic_not_unique`.
- **Where problems go:** a new `topos_violation` table, which also feeds `v_all_violations`. Errors are raised only in strict mode.
- **Writers:** a new `register_subobject_classifier`, plus `register_subobject` and `attach_characteristic`. All three refuse badly typed input and never replace a row. `classify_mono` returns the unique `χ`.
- **Upgrading:** an existing database with the original tables can be upgraded; a test covers this.
- **Scope:** the checks run against the recorded morphisms and composites. A pass means the recorded data is consistent with a subobject classifier.

**Python version:** `qbx.categorical.topos` runs the same checks and reports the same problems with the same details. On 60 random examples the database and the Python code report exactly the same problems, and every kind of problem occurs.

**Lean (`QBX/Formal/Topos.lean`, registry entries H-031 to H-033)**
- `isPullback_iff_pullbackCheck`: the pullback check is exactly Mathlib's `IsPullback`.
- `hasClassifier_iff_exists_check`: the classifier check is exactly Mathlib's `Classifier`. `classifierCheck_of_classifier` and `Classifier.ofCheck` give the two directions.
- `classifier_existence_not_sufficient` (sets with a three-element `Ω`) and `classifier_uniqueness_not_sufficient` (the chain `false ≤ true`): the checker needs both halves of the check.
- `chi_id_eq`: the characteristic morphism of an identity is `true ∘ !`.
- `partialOrder_hasClassifier_iff`: a nonempty partial order has a classifier exactly when it has one element.

**How the tests use these results**
- Finite sets of sizes 0–2 with `Ω = 2` pass. The `χ` the checker finds is the indicator function, and `χ(id_X) = true ∘ !_X`.
- With a three-element `Ω`, the non-surjective injections are exactly the maps reported as having more than one `χ`: 2^|X∖U| each.
- Across every partial order with up to 3 elements in the database (4 in the Python code), the check passes only for the one-element order.

I also updated the README, the file map, `decision_log.md`, `session_log.md`, `project_state.json` (next sprint: sheaf cohomology, migration 012), `HYPOTHESIS_REGISTRY.md` (including new test-checked entry R-009), the two skill docs, and the count in the view-structure test. The Properties table has the two definitions and five results; the results are marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key.

# Summary of changes for run bd173d1d-357c-41f4-98a0-68e73044c7c0
I decided Q-005 and applied amendment A-004, then did the next planned step, Phase 1 sprint 7: fibrations (migration 010).

**Checks:** all 407 Python tests pass (`cd QBX && python3 -m pytest -q`), up from 377. That includes the tests that run against a real PostgreSQL 16. `lake build QBXFormal` succeeds, there is no `sorry`, and the new theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass. Everything is committed.

**Q-005 / A-004: I chose option 1, delegating to the 018 function**
- The frozen `enforce_capability_token()` in `migrations/003_capability_and_proof.sql` now calls `capability_token_is_active` from migration 018 instead of using `WHERE token = token`. That old line was an ambiguous column reference, so every production write failed.
- **Why not the smaller fix (renaming the variable):** the trigger would run, but it would still accept tokens with no expiry and ignore revocations. That contradicts decision Q-001 and would leave two different meanings of "valid token". If migration 018 is missing, the call fails and the write is refused.
- **One behaviour change:** tokens without an expiry are no longer accepted by this trigger, following Q-001.
- **Tests:** the test that recorded the old defect is replaced by three tests in `tests/live_db/test_capability_db.py`: a valid token is accepted; missing, unknown, expired, expiry-less and revoked tokens are refused; and the write is refused if 018 is missing. I ran all three against the original 003 and they fail there.
- **Hash and signature:** the hash of 003 is re-recorded and re-signed with the development key. Docs updated: the A-004 file, the amendments table, `open_questions.md`, `decision_log.md`, `session_log.md`, `project_state.json` and the README.

**Bugs in the original migration 010** (each confirmed by running it on PostgreSQL)
- It accepted a projection functor going from the base to the total category (the wrong way).
- `register_cartesian_lift` accepted a lift registered over a base morphism it doesn't lie over, and source/target objects that aren't the lift's.
- Its `ON CONFLICT … DO UPDATE` silently replaced an already registered lift with a different morphism.
- `verify_cartesian_property` only counted morphisms coming into the lift's source, so a lift that isn't cartesian passed.
- Nothing checked that lifts exist, opfibrations couldn't be told apart from fibrations, and no fibration check was part of `run_all_batch_checks`.

**The rewrite** (`migrations/010_fibrations.sql`)
- New `kind` column: `fibration` or `opfibration`.
- **Checked on every write:** that the projection functor goes the right way, that each lift is well formed, and that the lift lies over its base morphism.
- **Checked in batch** (`check_fibration`, now part of `run_all_batch_checks`): the cartesian property of each lift, with existence and uniqueness of the factorization reported separately, and the dual (cocartesian) property for opfibrations.
- **Missing lifts:** reported as `missing_lift` when no recorded morphism over a base morphism, at a given object, passes the check.
- **Lift registration:** `register_cartesian_lift` refuses badly formed lifts and never replaces one.
- **Upgrading:** an upgrade block converts an existing database that has the original tables; a test covers this.
- **Scope:** the checks run against the recorded morphisms and composites. A pass means the recorded data is consistent with a fibration; a factorization whose composite isn't recorded counts as missing.

**Python version:** `qbx.categorical.fibration` runs the same checks and reports the same problems with the same details. On 40 random examples the database and the Python code report exactly the same problems, and every kind of problem occurs.

**Lean (`QBX/Formal/Fibration.lean`, registry entries H-028 to H-030)**
- `isStronglyCartesian_iff_check` and `isStronglyCocartesian_iff_check`: the check is exactly Mathlib's strongly cartesian (and cocartesian) morphism.
- `isFibered_iff_cleavageCheck`: "every base morphism has a lift that passes the check" is exactly Mathlib's `Functor.IsFibered`.
- `cartesian_existence_not_sufficient` and `cartesian_uniqueness_not_sufficient`: the checker needs both halves of the check.
- `isStronglyCartesian_star_iff_isIso`: over a one-object base, cartesian means isomorphism. The tests use this as a check on the checker: for every 3-element monoid and for T₂, the database and the Python code find that the cartesian elements are exactly the units.

These results and their three definitions are in the Properties table; the five results are marked proved.

**Still waiting on you:** re-signing the frozen hashes with your own key. The signature now uses the development key, and that includes the new 003 hash. The next sprint is the topos kernel (migration 011).

# Summary of changes for run a8babe03-7a55-4ef3-a174-78fe8685e317
I did the next planned step, Phase 1 sprint 6: 2-categories (migration 009).

All 377 Python tests pass (`cd QBX && python3 -m pytest -q`), including the ones that run against a real PostgreSQL 16. That is 39 more than before. `lake build QBXFormal` succeeds, there is no `sorry`, and the new theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass. I did not change any frozen file, and everything is committed.

**Bugs in the original migration 009** (I confirmed each one by running it on PostgreSQL)
- It accepted a 2-cell between 1-morphisms that don't share endpoints (f : A → B and k : B → A).
- `compose_two_horizontal` never checked that the two cells can be composed. It also gave the result the wrong source and target. For example, two 2-cells f ⇒ g and g ⇒ f, both A → B, "composed horizontally" into a 2-cell f ⇒ f.
- `compose_two_vertical` didn't notice a missing upper cell. You only got an unrelated NOT NULL error.
- Cells from a different 2-category were accepted.
- Every call created a brand-new result cell. So composing the same pair twice failed, and the unit laws could never hold.
- There were no identity 2-cells.
- `check_interchange_law` was an empty loop. It checked nothing, and it wasn't part of `run_all_batch_checks`.

**The rewrite** (`migrations/009_two_categories.sql`)
- New `two_identity` table for identity 2-cells. A horizontal composite now runs from g ∘ f to g′ ∘ f′, both looked up in the composition table.
- **Checked on every write:** that cells and composites fit together, the unit laws, and identity preservation (1_g ⋆ 1_f = 1_(g∘f)).
- **Checked in batch** (new `check_two_category`, now part of `run_all_batch_checks`): vertical associativity, horizontal associativity and the interchange law. `check_interchange_law` now really checks interchange.
- Each law is checked wherever all the composites it mentions are recorded. A pass means the recorded data is consistent with a 2-category, not that every composite exists.
- Problems are logged to `two_category_coherence_violation`. Errors are raised only in strict mode.
- The compose functions accept an optional result cell, return a composite that's already recorded instead of making a duplicate, use the unit laws, and refuse input that doesn't fit together.

**Python version:** `qbx.categorical.two_category` does the same checks and reports the same problems with the same details. On 60 random examples the database and the Python code report exactly the same problems.

**Lean (`QBX/Formal/TwoCategory.lean`, registry entries H-025 to H-027)**
- `exists_bifunctor_iff`: identity preservation plus interchange are exactly what it takes for horizontal composition to be a functor. So these two checks are both correct and enough.
- `interchange_not_implied` and `identity_preservation_not_implied`: neither law implies the other, so the checker needs both.
- `eckmannHilton_two_cells`: on the 2-cells of an identity 1-morphism, the laws force vertical and horizontal composition to be the same commutative operation. The tests use this as a check on the checker:
  - The symmetric group S₃ gives exactly 648 interchange failures, in both the database and Python.
  - On all 6,561 pairs of operations tried on a 3-element set, the checker's verdict matches this theorem.

These three results and the `HCompLaws` definition are in the Properties table; the three results are marked proved.

I also updated the README, `decision_log.md`, `session_log.md`, `project_state.json`, `HYPOTHESIS_REGISTRY.md` (including new test-checked entry R-007) and the tier skill doc.

**Still waiting on you, unchanged from earlier sessions:**
- re-signing the frozen hashes with your own key;
- approving or rejecting amendment A-004 (question Q-005).

The next sprint is fibrations (migration 010).

# Summary of changes for run 10ebd06a-e1ae-4387-90cd-ef3af6837fec
I finished the next planned step, Phase 1 sprint 5: enriched categories (migration 008).

All 338 Python tests pass (`cd QBX && python3 -m pytest -q`), including the ones that run against a real PostgreSQL 16. `lake build QBXFormal` succeeds with no `sorry`, and the new theorems use only the standard axioms. `verify_frozen.py --require-signature`, `validate_agent_output.py` and `check_hypothesis_expiry.py` all pass. No frozen file was changed, and everything is committed.

**Bugs in migration 008 as found** (I ran it on PostgreSQL to confirm each one)
- The triangle check reported the wrong distance. For d(X,Z)=5 it returned `lhs` = 1, which is d(X,Y), instead of 5.
- A missing d(X,Z) was accepted silently, even though finite d(X,Y) and d(Y,Z) mean d(X,Z) must be finite.
- d(X,X)=0 was never checked (a value of 7 passed). Negative, NaN and non-numeric distances were also accepted.
- A hom could point at an object outside the base category.
- `enriched_composition` accepted homs that don't compose, and accepted any composed value. The writer could also mark the row `verified`.
- The enrichment kind was ignored. The metric check ran on any category, the other kinds had no checks at all, nothing was logged, and nothing ran in the batch checks.

**The rewrite**
- **Metric, ordered and quantale kinds.** Five value types are built in: `lawvere` (this is what metric uses), `ultrametric`, `boolean` (this is what ordered uses), `goedel` and `product`. Two laws are checked:
  - unit law: unit ≤ h(x,x) at every object;
  - composition law: h(x,y) ⊗ h(y,z) ≤ h(x,z).
  
  A missing hom counts as "no connection" (distance ∞, or truth value false), so the check covers every object in the base category, not only the recorded ones.
- **Probabilistic kind.** Each hom-value is a finite transition table, `{"kernel": {s: {t: p}}}`. The database checks that:
  - each row of probabilities sums to 1;
  - all tables leaving one object use the same set of states;
  - a table only moves to states that exist at its target;
  - a table from an object to itself is the identity;
  - the Chapman–Kolmogorov rule holds wherever all three tables of a chain are recorded: the x→z table equals the x→y table followed by the y→z table.
- **Exact arithmetic.** JSON numbers are read as exact decimals, so 0.1 + 0.7 = 0.8 exactly. An optional `tolerance` setting relaxes comparisons.
- **When checks run.**
  - Each hom is checked when it is written.
  - The `enriched_composition` trigger sets `verified` itself.
  - The laws are checked in batch by `check_enriched_category`, which is now part of `run_all_batch_checks`.
  - Problems are logged to a new `enriched_violation` table, which is also included in `v_all_violations`. Errors are raised only in strict mode.
  - `check_metric_triangle_inequality` is kept, now corrected.
- **Python version:** `qbx.categorical.enriched` does the same checks.
  - On 72 random examples covering all five value types (some with bad values), and 40 random probabilistic examples, the database and the Python code report exactly the same problems.
  - For metric categories, the Python check matches the textbook definition on every possible assignment over 1–2 objects and on 2000 random 3-object ones.

**Lean (`QBX/Formal/Enriched.lean`, registry entries H-022 to H-024)**
- `MonoidalPreorder`: an ordered commutative monoid set up as the base an enriched category takes its values in. Mathlib doesn't provide this, so I built it.
- `exists_enriched_iff`: the recorded values form an enriched category exactly when the unit and composition laws hold, so these two checks are both correct and enough.
- `lawvere_enriched_iff`: in the metric case, this means d(x,x)=0 plus the triangle inequality.
- `triangle_iff_finite`: only chains whose two legs are finite need checking. This justifies the database looking only at recorded pairs.
- `unit_law_not_sufficient` and `composition_law_not_sufficient`: neither law implies the other, so the checker needs both.

Three of these theorems are in the Properties table, marked proved, along with the `MonoidalPreorder` definition.

I also updated the README, `decision_log.md`, `session_log.md`, `project_state.json` and `HYPOTHESIS_REGISTRY.md` (including new runtime-check entry R-006). I left the original inventory `QBX_FILE_MAP.md` as it was, since it is a dated snapshot.

**Still waiting on you:** re-signing the frozen hashes with your own key, and approving or rejecting amendment A-004 (question Q-005). Both are unchanged from last session. The next sprint is 2-categories (migration 009).

# Summary of changes for run a62dc1ce-b6de-4dc3-80fc-484b9f0df362
I decided the three open questions, built what each decision needs, and then finished the next planned step, Phase 1 sprint 4: limits and colimits (migration 007).

All 292 Python tests pass, including the ones that run against a real PostgreSQL 16 (`cd QBX && python3 -m pytest -q`). `lake build QBXFormal` succeeds with no `sorry`, and the new theorems use only the standard axioms. `verify_frozen.py --require-signature` and `validate_agent_output.py` both pass. No frozen file was changed, and everything is committed.

**The three decisions** (in each case I took the option your design document recommended)
- **Q-001, capability tokens: signed tokens that can be revoked.** Each token is a signed blob listing who holds it, what it allows and when it expires, and it can be revoked before then.
  - The code is in `src/qbx/core/capability.py`. Signing goes through the existing `signing.py`, which keeps the project rule that only that file uses the cryptography library.
  - `VerifiedCapabilityGate` lets only verified tokens reach the frozen `WeylEngine`.
  - The new migration `018_capability_revocation.sql` adds the revocation list, an "is this token active?" check, and a working trigger, `enforce_signed_capability()`.
- **Q-002, frozen hashes: signed, and checked against a trusted public key.** The new `sign_frozen.py` signs the hash file, and `verify_frozen.py` now checks that signature. An agent that edits a frozen file and recomputes the hashes is now caught, because it cannot re-sign them.
- **Q-003, provisional hypotheses: 90 days, renewable once.** The new `check_hypothesis_expiry.py` enforces this. `HYPOTHESIS_REGISTRY.md` and skill R5 are updated.

Each decision is recorded in `open_questions.md`, `decision_log.md` and `project_state.json`.

**Two things that need you**
1. **Re-sign the frozen hashes with your own key.** The current signature uses a development key I made, which sits in the git-ignored `keys/` folder. Run `python3 agents/scripts/sign_frozen.py --key <your.pem> --key-id <id> --write-anchor`, then remove the development key from `agents/config/frozen_trust_anchor.json`. Until then the signature only shows that someone with access to `keys/` signed the hashes.
2. **Approve or reject amendment A-004 (question Q-005).** The frozen function `enforce_capability_token()` in migration 003 can never accept a write. `WHERE token = token` is ambiguous in PostgreSQL, so every production write fails with an error, even with a valid token. A test confirms this. The function isn't attached to any table yet, so nothing is broken today. A-004 proposes the fix; until you decide, `enforce_signed_capability()` from 018 can be used instead.

**Sprint 4: limits and colimits**
- **Migration 007, as found, had several bugs** (I ran it on PostgreSQL to confirm):
  - It rejected the limit of a single arrow A → B, because it couldn't handle identity morphisms.
  - It accepted a cone with no legs at all, and never checked that legs had the right source and target.
  - It stopped at the first problem, so later ones were never logged.
  - It let a limit point at a cone over a different diagram.
  - It had no colimit universality check.
- **The rewrite** checks every cone completely and logs all problems. It raises errors only in strict mode.
  - Universality is split into two checks: every other cone has a mediating morphism, and the legs are jointly monic (jointly epic for colimits).
  - Colimits get the same checks. Both now run in `run_all_batch_checks`.
  - **Limitation:** the database can only compare against cones that have been recorded. A pass means "universal among the recorded cones", not universal in general.
- **Python version:** `qbx.categorical.limits` does the same checks. It can also check universality against every possible cone when the category is small and all its compositions are recorded. On the divisors of 12, the database agrees with this Python version and with gcd for every recorded cone over every two-element diagram.
- **Lean (`QBX/Formal/Limits.lean`, registry entries H-019 to H-021):**
  - `nonempty_isLimit_iff`: a cone is a limit exactly when both checks pass; the colimit version is proved too.
  - `coneOfEdges` / `coneOfGenerators`: checking the triangle for each recorded arrow is enough to make a cone.
  - `existence_not_sufficient` and `jointlyMonic_not_sufficient`: neither check works on its own, so the checker needs both.

  Three of these are in the Properties table, marked proved.

The next sprint is enriched categories (migration 008).

## Suggested follow-up

The frozen `enforce_capability_token()` in `migrations/003_capability_and_proof.sql` refuses every production write, even with a valid token, because `WHERE token = token` is an ambiguous reference in PostgreSQL. It isn't attached to any table yet. If you approve amendment A-004 (`QBX/agents/memory/amendments/A-004_capability_trigger_ambiguous.md`), I can apply the fix, update the tests, and re-record the hash. You would then need to re-sign the hashes with your own key.

# Summary of changes for run 1f442cd7-0cac-4691-a10b-865fd4fad0f4
I applied the three approved fixes to the frozen migrations, recorded real hashes for the frozen files, and settled the שלום = 936 question. I then finished the next planned step, Phase 1 sprint 3: monad and comonad checking (migration 006).

All 220 Python tests pass (`cd QBX && python3 -m pytest -q`). The tests that run against a real PostgreSQL 16 ran this time; none were skipped. `lake build QBXFormal` succeeds with no `sorry`, the new theorems use only the standard axioms, and everything is committed.

**Where the 936 note was, and what I decided**
The note was in my earlier summaries and in `QBX/agents/memory/decision_log.md` (entry "Gematria final letters use 500–900"). The question is what the final letters ך ם ן ף ץ are worth:
- With the standard values (final mem = 40), שלום = 300+30+6+40 = **376**.
- With final letters at 500–900 (final mem = 600), שלום = **936**.

Your project already says which one it wants. Rule R7 in `QBX/agents/skills/hebrew_primacy_rules.md` says "Their gematria values are 500–900". `src/qbx/hebrew/gematria.py` and migration 014 both follow that rule.

Two tests still expected 376: the Python test, which an earlier session had already changed to 936, and Test 4 in `tests/test_triggers.sql`. I changed the SQL test to 936 to match R7. I also added `tests/live_db/test_gematria_db.py`, which checks that the database and the Python code give the same value for 8 words. I reworded one checklist line in `agents/roles/domain_hebrew.md` so it no longer contradicts R7. If you actually want 376, R7, `gematria.py` and the letter table in migration 014 would all need to change.

**Fixes to the frozen migrations (now applied)**
- **A-001:** `001_init.sql` now installs on PostgreSQL. The capability-token index no longer uses `now()`, and the test setup no longer needs to work around it.
- **A-002:** the functor checks in `002_enforced_functor.sql` now:
  - log problems in permissive mode and raise errors only in strict mode;
  - handle identity morphisms correctly, so constant functors are accepted;
  - check every recorded composition the newly mapped morphism is part of, so insertion order no longer matters.

  A new `check_functor_laws(functor_id)` re-checks a functor on demand, and `run_all_batch_checks` now calls it for every functor. Migration 004 now uses the same composition helper.
- **A-003:** `composition` now allows f∘f, allows only one result per pair, and rejects rows whose morphisms don't fit together.
- The tests for these changes are in `tests/live_db/test_amendments_db.py`, which replaces the old file that pinned the broken behaviour.

**Frozen-file hashes**
Real SHA-256 hashes are now in `frozen_interfaces.json`, taken after the fixes above, and `verify_frozen.sh` reports all 12 files OK. The amendment files, question Q-004, the decision and session logs, `project_state.json` and the README are all updated.

**Sprint 3: monads and comonads**
- **Migration 006, as found, could never run.** A variable shared its name with a column, so the check function always failed with an error, and `run_all_batch_checks` failed as soon as any monad existed. It also composed the associativity check in the wrong order, didn't handle identity morphisms, and skipped missing data without reporting it.
- **The rewrite** checks:
  - that the categories fit;
  - that η goes from the identity functor to T and μ from T∘T to T;
  - that each component has the right source and target;
  - all three laws for every object.

  Missing data is reported as a violation, and checks run automatically on insert or update; comonads get the dual checks. Live tests are in `tests/live_db/test_monad_db.py`.
- **Python version:** `qbx.categorical.Monad` and `Comonad` do the same checks, plus Kleisli composition, with tests in `tests/test_monad.py`.
- **Lean (`QBX/Formal/Monad.lean`, registry entries H-016 to H-018):**
  - `monadOfChecks` / `comonadOfChecks`: data that passes every check (naturality possibly checked only on generating morphisms) is a genuine Mathlib monad or comonad.
  - `exists_monad_iff_laws` / `exists_comonad_iff_laws`: natural transformations form a monad (comonad) exactly when the three laws hold.
  - `left_unit_independent`, `right_unit_independent` and `assoc_independent`: none of the three monad laws follows from the other two, so the checker has to check all three.

  Three of these theorems are in the Properties table, marked proved.

**Still open:** questions Q-001 to Q-003 (capability token format, how frozen hashes are distributed, and expiry of provisional hypotheses) come from your original design and need your decision. The next sprint is limits and colimits (migration 007).

# Summary of changes for run d278bebe-220b-4f97-8f0e-9e6ba18f958a
I finished the project's next planned step, Phase 1 sprint 2: the adjunction engine (migration 005). This time the database code was actually run: I set up a throwaway PostgreSQL 16 and applied all 17 migrations to it. That turned up serious bugs that parsing the SQL alone had missed.

All 159 Python tests pass (`cd QBX && python3 -m pytest -q`). That includes 21 new tests that run against the real database; they are skipped when no server is available. `lake build QBXFormal` succeeds with no `sorry`, and the new theorems use only the standard axioms. Everything is committed.

**Bugs found by running the SQL**
- **Migration 004 (natural transformations) never worked.** A name clash in the check function made every insert into `natural_transformation_component` fail. Separately, the composition helper I added last session looked composites up in the reverse order, so every correct square involving a non-identity morphism was reported as missing. Both are fixed, with regression tests.
- **The original migration 005 flagged genuine adjunctions.** On a real adjunction it reported all four triangle checks as violations: it composed the right triangle in the wrong order and didn't handle identity morphisms. It also silently skipped objects with missing data.
- **Frozen migration `001_init.sql` cannot be installed as written.** PostgreSQL rejects its partial index because the index condition uses `now()`. The tests work around this only at install time.
- **The frozen functor checks in `002_enforced_functor.sql` misbehave.**
  - They raise an error even in permissive mode.
  - They reject valid functors whose images involve identity morphisms, such as any constant functor.
  - Whether the composition check runs at all depends on the order the mappings are inserted.

**Adjunction engine**
- **Migration 005 (rewritten):** checks that the categories fit and that the unit and counit go between the right functors (identity, G∘F, F∘G, identity). It also checks that each component has the right source and target, and checks both triangles in the correct order. Missing data or an unrecorded composite is logged as a violation instead of being skipped.
  - A trigger runs the check when an adjunction is inserted or changed.
  - `run_all_batch_checks` (migration 017) now also re-checks natural transformations.
- **Python version:** `qbx.categorical.Adjunction`, plus the `IdentityFunctor` and `ComposedFunctor` helpers, does the same checks. It also converts maps F(X) → Y into maps X → G(Y) and back. It has 15 tests.

**Lean (`QBX/Formal/Adjunction.lean`, registry entries H-013 to H-015)**
- `exists_adjunction_iff_triangles`: natural η and ε form an adjunction exactly when both triangle identities hold at every object.
- `adjunctionOfChecks`: data that passes every check is a genuine adjunction, even when naturality was checked only on generating morphisms. `adjunctionOfChecks_homEquiv` and `adjunctionOfChecks_homEquiv_symm` show its conversion of maps is the one the Python code computes.
- `right_triangle_not_implies_left` and `left_triangle_not_implies_right`: neither triangle identity follows from the other, so the engine has to check both.

**Records:** I added the registry entries, decision-log entries, a session log entry, new question Q-004, and README sections. `project_state.json` now sets the next sprint to monads/comonads (migration 006). The four main theorems are in the Properties table, marked proved. I did not edit any frozen file. The fixes for 001 and 002, plus last session's `composition` table issues, are written up as proposals A-001 to A-003 in `QBX/agents/memory/amendments/`. Each needs your approval.

**Still open from earlier:** the frozen-file hashes are still placeholders, and the שלום value (936) still needs your confirmation.

## Suggested follow-up

Two frozen migrations have real bugs, and fixing them needs your approval. As written, `001_init.sql` cannot be installed on any PostgreSQL version because of its `now()` partial index (proposal A-001). The functor triggers in `002_enforced_functor.sql` raise errors even in permissive mode and reject valid functors (proposal A-002). If you approve, I can apply A-001 to A-003 and update the tests that currently pin the old behaviour.

# Summary of changes for run 0131e27d-1d90-45bc-952d-fc1031f08b78
I picked up the project's next planned step. Phase 1, sprint 1 in `QBX/agents/memory/project_state.json` was "implement natural transformation checker with naturality square enforcement", and that is now built. All 123 Python tests pass (`cd QBX && python3 -m pytest -q`). `lake build QBXFormal` succeeds, and no Lean file under `QBX/Formal/` contains `sorry`. The new theorems use only the standard axioms. Everything is committed. None of the SQL has been run against a live Postgres.

**Natural transformation checker (`QBX/src/qbx/categorical/`)**
- `NaturalTransformation` checks η: F ⇒ G between two Phase 0 `EnforcedFunctor`s and uses the same strict and permissive modes. The Phase 0 frozen interfaces are untouched.
- **Registering a component** (`set_component`) checks two things:
  - that η_X really goes from F(X) to G(X);
  - every naturality square that has just become checkable. This includes morphisms into X, morphisms out of X, and morphisms from X to itself.
- **Other checks:** `verify_all_laws` checks that every component is present and every square commutes. A composite missing from the table counts as a violation, not a pass.
- **Generator shortcut:** `verify_naturality(generators=...)` checks only the given morphisms. It does this only after `generates` confirms that they produce every morphism; otherwise it checks them all.
- **Also included:** the identity transformation, vertical composition and a signed canonical encoding.
- 20 tests are in `tests/test_natural_transformation.py`.

**Lean proofs (`QBX/Formal/Naturality.lean`, registry entries H-010 to H-012)**
- `naturality_of_generators`: if a set of morphisms generates the category, it is enough to check the squares on that set. `naturality_of_edges` gives the same result for free categories, with one square per edge.
- `checkedBy_of_mem`: checking every square at the new object, in both directions, eventually covers every square.
- `triggerCheckedBy_iff`: describes exactly what the original database trigger in migration 004 checked. It checked a square only when the morphism's target was registered before its source, and it never checked a morphism from an object to itself. As a result, a transformation that is not natural could be stored with no violation logged (`trigger_misses_forward`, `trigger_misses_endo`).

**Database migrations (files not frozen)**
- **Migration 004:**
  - the trigger now checks both directions and morphisms from an object to itself;
  - a new helper, `nt_compose`, treats identity morphisms correctly when composing;
  - a missing composite is now logged as a violation;
  - I added the `law` column, which the summary view in 017 reads but which didn't exist.
- **Install errors:** I checked every migration with the real PostgreSQL parser (`pglast`). It rejected migrations 004, 005, 006, 007, 009, 010 and 012:
  - they used `strict` as a variable name, which is a reserved word in PL/pgSQL. I renamed it to `is_strict`;
  - migration 007 also created a table called `limit`, a reserved SQL word. I quoted the name rather than renaming it.
- **New test:** `tests/test_migrations_parse.py` parses every migration and checks the summary view's column names. It is skipped if `pglast` isn't installed; I added `pglast` to the dev dependencies.

**Records:** I updated the registry, the decision log (two entries marked as needing human review), the session log, `project_state.json` and the README. The next sprint is recorded as the adjunction engine (migration 005). Four Lean theorems are in the Properties table, marked proved.

**Still open from earlier:** the frozen-file hashes are still placeholders, and the שלום test value (936) still needs your confirmation.

## Suggested follow-up

Two things in the frozen migration `001_init.sql` may be unintended, and I left both alone. First, the `composition` table has `CHECK (left_id <> right_id)`, so it can never record a morphism composed with itself (for example f∘f for an endomorphism f). Second, `composition` has no uniqueness constraint on `(left_id, right_id)`, so the same pair can be recorded with two different results. Changing either needs the frozen-interface amendment process. If you approve, I can draft the amendment.

# Summary of changes for run 28efc6bf-60cc-43a4-b7fe-6ca79f40a0fb
I repaired the damaged parts of the `QBX/` project and filled in the missing pieces of the braid system. All 88 Python tests pass (`cd QBX && python3 -m pytest -q`), `examples/demo.py` runs from start to finish, and the new Lean proofs build with `lake build QBXFormal` with no `sorry`. Each main theorem depends only on the axioms `propext`, `Classical.choice` and `Quot.sound`. Everything is committed.

**Braid library (`QBX/src/qbx_ir/`)** – rewritten, because the sources had lost their indentation and their `__name__`-style names were mangled.
- **Core:** `Braid` with tensor product, powers, mirror image, stabilisation, half and full twists.
- **Equality:** the five kinds of equality are kept separate. Word equality is decided exactly with the Garside normal form. Equality of closed braids (knots and links) is only partly decided, using invariants; a `certain` flag says whether the answer is conclusive.
- **Rewriting:** rules R01–R03 each record which Lean theorem justifies them and produce a provenance record. The old `normal_form` never terminated; the new one does.
- **Invariants:** correct linking numbers, plus the Kauffman bracket, Jones, Burau and Alexander polynomials.
- **Quantum and anyon layers:** a true U_q(sl2) R-matrix, a quantum-trace Jones polynomial that agrees with the Kauffman-bracket version, and Fibonacci/Ising anyon representations. The anyons are unitary and satisfy the braid relations (checked by tests).
- **Other:** the eight views L0–L7, SVG rendering, JSON/YAML import and export, and fingerprints. 58 new tests are in `tests/qbx_ir/`.

**Phase 0 kernel (`src/qbx/`)** – restored (indentation, Neo4j query parameters, the mixing operator) so that the existing 30 tests pass.
- **Changed test – please confirm:** the code and migration 014 give final letters the values 500–900, so I changed the test's expected value for שלום from 376 to 936 instead of changing the code. This is recorded in the decision log as awaiting human confirmation.

**Lean proofs (`QBX/Formal/`, library `QBXFormal`)**
- **Rewrite rules are sound and complete:** the braid group `B_n` is defined by generators and relations. Each rewrite step preserves the group element (`Step.eval_eq`). Two words are equal in `B_n` exactly when the rules connect them (`eval_eq_iff_eqvGen`).
- **Invariants:** permutation and writhe are unchanged by rewriting, and each generator has infinite order.
- **Quantum layer:** any invertible solution of the Yang–Baxter equation gives a representation of `B_n` for every `n`, and equal braids get equal operators. The twisted-swap R-matrix and the U_q(sl2) R-matrix both solve Yang–Baxter. The U_q(sl2) matrix also satisfies the Hecke relation, and it matches the Python `SL2RMatrix`.
- **Registry:** results are listed in `Formal/HYPOTHESIS_REGISTRY.md`.

**Agent system, database files and docs**
- **Scripts:** `boot_session.py` and `validate_agent_output.py` are rewritten. `hash_frozen.sh` and `verify_frozen.sh` had web-page markup pasted into them; they now call new Python helpers. All scripts work from any directory and use paths relative to `QBX/`.
- **Frozen-file hashes:** these are still placeholders. Recording real hashes needs human approval.
- **Config files:** the YAML in `agents/config/` and `docker-compose.yml` has its indentation restored.
- **Migrations:** 002 and 004 were each missing a `$$ LANGUAGE plpgsql;` line; I added them. The SQL has not been run against a live Postgres.
- **Agent docs:** stale paths are fixed (`qbx_phase0/…` → `QBX/…`, `formal/` → `Formal/`, Lean build command `lake build QBXFormal`). The project state, session log and decision log are updated.
- **Docs and packaging:** `README.md` is rewritten (layout, usage examples that run as written, Lean results, what is not done). `pyproject.toml` and `requirements.txt` are tidied, and `QBX_FILE_MAP.md` notes that its health findings describe the tree before these repairs.

**Not yet built:** the ZX-calculus layer (Phase 8), real post-quantum signatures (only stubs exist), exact rather than numerical representation equality, and full knot/link equivalence.

The Properties table lists the main Lean theorems (marked proved) and the definitions they are stated in.

# Summary of changes for run c3e939d0-86e6-48bf-9898-682907c111da
I wrote the file map and inventory to `QBX/QBX_FILE_MAP.md` and committed it. It covers all 155 files under `QBX/` (about 23.8k lines). Most of the source code there is currently damaged and won't run; details below.

**What the map covers**
- **Full directory tree** with line counts and one-line descriptions.
- **The design docs you named:**
  - `architecture.md`: the nine-layer stack of the record-keeping database (what the docs call the Categorical Ledger), the three check tiers (on every write, scheduled batch, monitoring), the serialization formats, and how data flows.
  - `phase0_acceptance.md`: each acceptance item A1–A12 is matched to its test, and all 12 tests exist. N4 says the Weyl engine uses exact rational rounding, but the code actually uses floating point with a 1e-6 tolerance.
  - `acceptance.md`: cut off partway through item F7.
- **Reference docs:**
  - `QBX.md` is the founding QBX-IR spec. Its key sections are the five kinds of equality, the rule that every rewrite must preserve what it declares, and a 10-phase build plan that ends with Lean.
  - `QBX-research.md` has eight sections, including the ingestion → rewriting → output pipeline.
  - `meru.md` is a JSON list of testable Meru primitives, plus 7 tests and an ESP32 C code sketch.
  - `logic.md` is background Q&A on a logic video. It contains no QBX-specific material and still has leftover HTML from search results.
  - The other reference files are summarised too. `glue-vectors.md` mostly repeats `setup.md`, and four of these docs are exact copies of files in `reference/primary/`.
- **The `agents/` folder:**
  - The 9-step session start-up sequence and the oversight chain (human → orchestrator → role agents → skills → checklists → hooks).
  - The ten "never" rules, the 9 roles, 14 skills, 9 protocols, 6 checklists and 4 config files.
  - The phase map: Phase 0 is frozen and Phase 1 is in progress.
  - The Lean gate rules for claiming a hypothesis.
  - The current memory state.
- **Migrations 001–017**, matched to the architecture layers.
- **Source code:** the Phase 0 core and the QBX-IR package, with the frozen interfaces marked.

**Problems found (mechanical checks only; nothing was run against a live database)**
- **Python source:** all 46 `.py` files in `src/qbx` and `src/qbx_ir`, plus the two agent Python scripts, fail to compile. Indentation has been stripped and names like `__future__` and `__init__` have turned into Markdown bold (`**future**`). So the Phase 0 tests can't run on this copy, even though the project memory records Phase 0 as accepted.
- **Rendered-math HTML in code:** `hash_frozen.sh` and `verify_frozen.sh` fail `bash -n`, and `neo4j_client.py` has broken query parameters.
- **SQL:** migrations 002 (a frozen file) and 004 are each missing a closing `$$ LANGUAGE plpgsql;`.
- **YAML:** indentation is flattened in `docker-compose.yml` and all four `agents/config/*.yaml` files, so they would load with the wrong structure.
- **Paths:** the agent files point to `qbx_phase0/...`, `formal/` and `HYPOTHESIS_REGISTRY.md`. Code is actually at `QBX/src/...` and `QBX/migrations/...`, and `formal/` and `HYPOTHESIS_REGISTRY.md` don't exist.
- **Memory files:** all the frozen-interface hashes are still placeholders. `project_state.json` lists no open questions, while `open_questions.md` has three open (Q-001 to Q-003).
- **Missing pieces:** `examples/demo.py`, which the README refers to, doesn't exist, and `qbx_ir` has no tests.

**Maths notes on `meru.md`** (I checked these by hand and with standard formulas; none is backed by a Lean proof):
- The Genesis 1:1 sequence encodes the final ם as `110` (regular Mem), but the alphabet table gives Mem-final as `212`. That choice affects the He/Mem count of [3,3].
- For the (3,10) torus knot the standard formulas give genus 9 and crossing number 20; the file says 1 and 30.
- Test 6 calls a matrix of about 10¹⁰ entries "small". Also, for a finite group H³(G, U(1)) is itself finite, so computing ranks over ℂ would always give 0.
- Several other claims do check out by direct count; these are listed in the file.

No Lean code was written or changed, so there are no build targets.

## Suggested follow-up

Most of the QBX source looks like it was damaged by a copy-paste through a Markdown/LaTeX renderer. The affected files are the `src/` Python files, two shell scripts, `neo4j_client.py`, migrations 002 and 004, and the YAML configs. I can restore indentation and the `__dunder__` names, remove the injected rendered-math HTML, add the missing `$$ LANGUAGE plpgsql;` terminators, and re-indent the YAML. I can also fix the encoding inconsistencies in `meru.md`, or write Lean proofs for the small finite facts there (mirror pairing, torus-knot genus and crossing number, the cocycle condition). Just say which you'd like.

# Summary of changes for run 890fd636-b991-4aaa-9d2d-c8a8a88e805f
I finished the three follow-up targets left from the last cycle and proved two further results about the Cayley–Dickson tower. I also improved several tactic files and wrote the Python operators. `lake build` passes with no warnings, no `sorry`, no added axioms and no `native_decide`. The main theorems depend only on the standard axioms.

**New Lean results (in `Refinery/`)**
- **Flexibility at every level** (`CDFlexible.lean`, `cdMul_flexible`): `(xy)x = x(yx)` holds at every level of the tower, over any commutative ring. The proof is by induction on the level. It also proves, at every level, that `(xy)‾ = ȳx̄`, `x̄̄ = x`, `t(xy) = t(yx)` and `t((xy)z) = t(x(yz))`.
- **Full power-associativity** (`CDPowers.lean`, `cdPow_mul_cdPow`): `xʲ·xᵏ = xʲ⁺ᵏ` for all `j, k` at every level. Last cycle only proved the cube case, so this fully refutes the `tactics/08` row claiming level 5 loses power-associativity.
- **Composition law** (`NormComposition.lean`, `cdNormSq_mul_iff_le_three`): over ℤ, `N(xy) = N(x)N(y)` holds for all elements exactly when the level is at most 3. The failure at level 4 carries up to every higher level.
- **Lost properties stay lost** (`CDLossPersistence.lean`): the tower is non-commutative from level 2 on, non-associative from level 3 on and non-alternative from level 4 on. Each proof takes one integer counterexample and embeds it via `x ↦ (x, 0)`.
- **Equal-temperament orbit** (`EqualTemperament.lean`, `et12_closure`): octave-folding the powers of the fifth `2^(7/12)` gives exactly 12 pitch classes, namely the 12 semitones. Folding the powers of the just fifth `3/2` gives infinitely many.
- `SpookyPrimes/Sedenion/Flexible.lean` now gets sedenion flexibility as the level-4 case of the general theorem. The statement is unchanged; its build drops from about 170 s to seconds.

**Tactic changes**
- `tactics/08_cd_lifting_v2.md` replaces the property-loss table. Level 4 loses alternativity, the composition law and freedom from zero divisors; level 5 loses nothing new. It also lists what survives every level and describes the two proof methods used (induction on the level, and embedding a counterexample upward).
- `tactics/04_adversarial_stress_testing_v2.md` keeps every v1 step. It adds: fix one precise reading before attacking, target the words that make a claim strong ("exactly", "uniquely", "closure"), and check counterexamples in Lean.
- `tactics/11_formal_certification.md` is new: a table of Lean proof patterns for backing a verdict. `TACTICS.md` indexes it and puts it after tactic 04 in the standard chain.
- Your rule is to supersede published tactics rather than edit them, so the v1 files 04 and 08 stay as they were, apart from a one-line pointer to v2.
- Seven documents were embedded inside other files between leftover `<BDS:create_file>` markers. I moved each, unchanged, to its intended path: `tactics/02`, `04` and `07`, `MASTER_PROJECT_OUTLINE.md`, `skills/harmonic_analysis.md`, `skills/cost_governance.md` and `templates/theorem_card.md`.
- `scripts/cd_ops.py`, `config/operators.yaml` and `skills/cayley_dickson_operators.md` had the same wrong level-5 entry; they now match the new table. `is_power_associative` now checks `xʲxᵏ = xʲ⁺ᵏ` rather than only cubes, and I added `is_flexible`.

**Operators** (`operators/`, each with code, `pipeline_binding.json` and `meta.json`)
- `octave_fold.v1` is emitted. Its declared consumer is `pitchclass_closure.v1`, which is itself annexed, so no live end consumer exists yet.
- `pitchclass_closure.v1` and `cyclic_phase_retrieval.v1` are annexed because nothing consumes them yet (your P7 rule).
- Each `meta.json` names the Lean theorem backing the operator. The Python self-tests pass, but they only sanity-check the code; the Lean theorems are the actual proofs.
- The files are named `operator_<slug>.py`, as tactic 05 specifies; a file named `operator.py` breaks Python's standard `operator` module.

**Records:** the data files and `PROGRESS_TRACKER.md` are updated, the full write-up is in `REFINERY_RUN_2026-09-29_CYCLE2.md`, and the new theorems are in the Properties table.

**Not done:**
- `scripts/pipeline.py` does not exist, so name validation, the folder index and the tactic-10 audit were not run.
- No consumer operators exist yet; that is now the main bottleneck.
- Every intake item has been triaged or attacked, so the intake needs new candidates.

# Summary of changes for run 1fc75ca5-65b2-4a84-a04f-9f9fb0fd4ad2
I read the project's own docs (`README.md`, `PROTOCOLS.md`, `TACTICS.md`, `PROMPTS.md`, `PROGRESS_TRACKER.md`, `data/`). They ask for a "theorem refinery": triage the intake, attack the queued targets, try to break each claim first, and log every verdict. The tracker's next step was to attack the queued targets, so that's what I did.

Each informal claim needed a precise reading before it could be tested. The verdicts apply to those readings. The proofs are in a new Lean library, `Refinery/`, which `lake build` now builds along with `SpookyPrimes/`. The build passes with no `sorry`, no added axioms and no `native_decide`.

**Results**
- **Pitch-class closure: holds, once restated.** Positive rational ratios are folded into `[1, 2)` by `octaveFold`.
  - Two ratios fold to the same value exactly when they differ by a power of 2.
  - Folding respects multiplication, and transposing a passage acts on its pitch-class set.
  - "Closure" fails for pure fifths: the pitch classes of 3ⁿ are all distinct, so that orbit never closes.
- **`ratio_extract` (canonical form): holds.** The folded value is the unique representative in `[1, 2)`.
- **Cyclostationary signature: false.** For periodic discrete signals:
  - For every period N ≥ 2, the fundamental cycle frequency can't tell the constant signal 1 from the zero signal.
  - Multiplying a signal by a constant of modulus 1 changes none of the cyclic autocorrelations, even using all frequencies.
  - Corrected statement, proved: if two signals match at every cycle frequency and lag, they are equal up to such a constant.
- **Octonion zero divisors: false.** The claim says sedenion zero divisors are exactly the pairs where the norm fails to multiply.
  - `a = e₁+e₁₀`, `b = e₀+e₅+e₁₄` is a counterexample: ab = a ≠ 0, but N(ab) = 2 while N(a)N(b) = 6.
  - The other direction holds, but it is trivial.
  - The real octonions have no zero divisors at all (eight-square identity), so the "octonion" in the name is wrong.
- **Commutativity loss: holds.** ℂ is commutative and ℍ is not, so the first doubling that loses it is ℂ→ℍ. I also checked the next rows of the table in `tactics/08_cd_lifting.md`: associativity holds at ℍ and fails at 𝕆; alternativity holds at 𝕆 and fails at 𝕊.
- **That table has a wrong row.** It says level 5 (𝕋) loses power-associativity. I proved that every Cayley–Dickson level, over any commutative ring, satisfies x·x = t(x)x − N(x), and hence (xx)x = x(xx). Only this cubic case of power-associativity is formalized, not all powers.

**Bookkeeping**
- I rejected the two remaining intake items: `zipf_slope` has no testable kill condition, and `fresnel_commute` is a textbook result.
- I added three follow-up candidates to `data/theorem_intake.json`. The main one is flexibility at every level, which is proved only for sedenions so far.
- I updated `data/target_queue.json`, `data/progress_state.json` and `data/rejection_log.csv`, and appended a session entry to `PROGRESS_TRACKER.md`.
- Your protocols say not to edit a published tactic file in place, so I left the table in `tactics/08_cd_lifting.md` unchanged. The correction is recorded in the run report.
- Details for each target are in `REFINERY_RUN_2026-09-29.md`, and the main theorems are in the Properties table.

**Not done:** no Python operator modules or pipeline bindings were written yet (protocol P7). Flexibility for every level is still open.

# Summary of changes for run 960eb478-a8ac-4ee9-bf70-9156ec9697a3
You chose to have me formalize the concrete claims in `reference/documents/spookyprimes.md`. I did that in a new Lean library, `SpookyPrimes/`, which builds with `lake build`. There is no `sorry` and no added axiom, and the only axioms used are the standard three. Finite checks are done by Lean's kernel (`decide +kernel`); `native_decide` is not used.

**Claims confirmed**
- **Dodecahedron, `λ₂ = 3 − √5 = 2φ⁻²`** (`Dodecahedron.lean`): the Laplacian eigenvalues are exactly {0, 3−√5, 2, 3, 5, 3+√5}. Eigenvalue 0 is simple and the graph is connected, so λ₂ = 3−√5 = 2/φ² ≈ 0.7639. The graph is built as the generalized Petersen graph GP(10,2) and proved 3-regular.
- **Koide ratio** (`Koide.lean`): with the PDG masses (0.51099895, 105.6583755, 1776.86 MeV), 0.66666 < K < 0.666661, matching the notes' 0.6666605. For any positive masses 1/3 ≤ K < 1, and K = 1/3 exactly when the masses are equal.
- **Zero-divisor pair**: (e₁+e₁₀)(e₅+e₁₄) = 0 in the sedenions. This also confirms my multiplication convention matches the notes, and I cross-checked it against `unsorted/sov`.

**Claims proved, but with a different explanation**
- **"ℍ⊕M₃(ℂ) is sedenion-isotropic, all singular values √3"** (`Sedenion/Isotropy.lean`): exactly true, Σ L_g L_gᵀ = 3I for the notes' generators τ³_q, λ₃, λ₈. The reason is not representation theory. All three generators sit in the octonion half span{e₀…e₇}, and I prove every element there satisfies ‖a·y‖ = ‖a‖‖y‖ for all sedenions y. So left multiplication by each is orthogonal, and such elements can never be zero divisors, which also explains the notes' "σ_min = 1 everywhere". The hypercharge generator Ŷ has components on e₈…e₁₅, and I prove L_Ŷ L_Ŷᵀ is not scalar; that is where the anisotropy the notes report for ℂ⊕M₃ and A_F comes from.
- **"[L,R] = 0 because the generators are weight vectors" and the "Moufang residual" probe** (`Sedenion/Flexible.lean`): this holds for every sedenion, because (ab)a = a(ba) always holds. The probe is identically zero.
- **Phase 8g, "lim_{p→∞} 𝓕_p = inf σ_min"** (`PowerMean.lean`): proved as the standard power-mean limit, (Σ wᵢ sᵢ^{−q})^{−1/q} → min sᵢ, for a finite weighted family (what a grid computation evaluates). The continuous Haar-integral version is not formalized. The limit holds for any positive numbers, so it gives the functional no geometric justification.

**Claim corrected**
- **Lie-algebra dimensions "4, 11, 13"** (`LieDimensions.lean`): I prove dim u(n) = n² and dim su(n) = n²−1, so the dimensions are **10, 12, 13**. The notes' first two values are wrong, though the three numbers are still distinct.

**Not formalized**
- The Dirac-space dimension chain, the Yukawa and Pati–Salam ranks, and the F_inf ordering depend on script conventions and generators (e.g. τ³_ℓ, λ₁) that the notes never define.
- From reading, not machine-checked: the notes report three different values of F_inf(A_F) (0.1059, 0.1013, 0.0149).

The claim-by-claim table and these caveats are in `SPOOKYPRIMES_FORMALIZATION.md`, and the main results are in the Properties table.

**Build change**: `lakefile.toml` now makes `SpookyPrimes` the default target. I kept the `unsorted` library entry but took it off the defaults, because its files use their original module names (`RequestProject.*`, `Sovereign.*`) and can't build under the `unsorted.+` glob in this layout.
