/-
UNCOMPILED CANDIDATE. General singleton-cut bound and a conditional high-gap
hard-Cheeger bound. This does NOT claim the general hard Cheeger inequality:
the additional hypothesis d/2 <= variationalGap is essential to this proof.
-/
import RequestProject.BoxKite

namespace BridgeLab.Cheeger
open Finset

variable {W : Type*} [Fintype W] [DecidableEq W]
    (G : SimpleGraph W) [DecidableRel G.Adj]

lemma edgeBoundary_singleton (v : W) : G.edgeBoundary {v} = G.degree v := by
  classical
  have hset :
      Finset.univ.filter (fun p : W × W => p.1 ∈ ({v} : Finset W) ∧
        p.2 ∉ ({v} : Finset W) ∧ G.Adj p.1 p.2) =
      ({v} : Finset W) ×ˢ G.neighborFinset v := by
    ext p
    rcases p with ⟨a,b⟩
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_singleton,
      Finset.mem_product, SimpleGraph.mem_neighborFinset]
    constructor
    · rintro ⟨rfl, _, hab⟩
      exact ⟨rfl, hab⟩
    · rintro ⟨rfl, hab⟩
      exact ⟨rfl, fun hb => G.loopless v (hb ▸ hab), hab⟩
  unfold SimpleGraph.edgeBoundary
  rw [hset, Finset.card_product]
  simp [SimpleGraph.degree]

/-- Every singleton is an admissible Cheeger cut when there are at least two vertices. -/
theorem cheegerConstant_le_degree (v : W) (hW : 2 ≤ Fintype.card W) :
    G.cheegerConstant ≤ (G.degree v : ℝ) := by
  classical
  have hb : BddBelow ((fun S : Finset W => (G.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W}) := by
    refine ⟨0, ?_⟩
    rintro r ⟨S, _, rfl⟩
    positivity
  unfold SimpleGraph.cheegerConstant
  apply csInf_le hb
  refine ⟨{v}, ⟨by simp, by simpa using hW⟩, ?_⟩
  simp [edgeBoundary_singleton]

/-- General high-gap regime only; not the full hard direction for all regular graphs. -/
theorem hard_cheeger_high_gap (v : W) (hW : 2 ≤ Fintype.card W) (d : ℕ)
    (hd : ∀ w, G.degree w = d) (hgap : (d : ℝ) / 2 ≤ G.variationalGap) :
    G.cheegerConstant ≤ Real.sqrt (2 * d * G.variationalGap) := by
  have hcut : G.cheegerConstant ≤ (d : ℝ) := by
    simpa [hd v] using cheegerConstant_le_degree G v hW
  have hd0 : (0 : ℝ) ≤ d := by positivity
  have hs : (d : ℝ)^2 ≤ 2 * d * G.variationalGap := by nlinarith
  have hr : 0 ≤ 2 * (d : ℝ) * G.variationalGap := le_trans (sq_nonneg _) hs
  have hsq := Real.sq_sqrt hr
  have hnonneg := Real.sqrt_nonneg (2 * (d : ℝ) * G.variationalGap)
  have hroot : (d : ℝ) ≤ Real.sqrt (2 * d * G.variationalGap) := by nlinarith
  exact hcut.trans hroot

/-- Local degree certificate uses kernel decision; it has not been executed here. -/
lemma box_degree_kernel : ∀ v : Fin 6 × Bool, boxKiteGraph.degree v = 4 := by
  decide +kernel

theorem box_hard_cheeger_bound :
    boxKiteGraph.cheegerConstant ≤ Real.sqrt (2 * 4 * boxKiteGraph.variationalGap) := by
  apply hard_cheeger_high_gap boxKiteGraph (0,false) (by decide) 4 box_degree_kernel
  rw [boxKiteGraph_spectralGap]
  norm_num

/-- This uses the structural gap theorem plus a cut, NOT the exact h=4/3 theorem. -/
theorem box_cheeger_le_four : boxKiteGraph.cheegerConstant ≤ 4 := by
  have h := box_hard_cheeger_bound
  norm_num [boxKiteGraph_spectralGap] at h
  exact h

end BridgeLab.Cheeger
