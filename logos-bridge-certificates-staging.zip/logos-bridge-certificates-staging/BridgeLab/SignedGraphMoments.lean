/-
UNCOMPILED CANDIDATE. Graph-degree sum -> actual associator pair moment ->
census histogram. No polynomial is fitted or independently substituted.
Ambient graph dimension is 2^(n+1), while pairMoment uses indices below 2^n.
The separate SimpleGraph/antipodal-quotient vertex and degree equivalences are
not encoded in this module; the degree function here is the supplied crossDegree.
-/
import Sovereign.Graph.CrossHalfVertexDegree
import Sovereign.Combinatorics.TowerDegreeMomentsUniform

namespace BridgeLab.GraphMoments
open Sovereign Finset

/-- Fully signed cross-half degree moment, indexed by admissible basis pairs. -/
def signedGraphMoment (n k : ℕ) : ℤ :=
  ∑ p ∈ admissiblePairs n, ∑ s : Bool × Bool,
    (crossDegree n s.1 s.2 p.1 p.2 : ℤ)^k

/-- Actual associator cardinal moment over the admissible index pairs, not a
separately declared polynomial or a fitted histogram. -/
def pairMoment (n k : ℕ) : ℤ :=
  ∑ p ∈ admissiblePairs n, ((nonassocMiddles n p.1 p.2).card : ℤ)^k

/-- The all-orders sign and degree factor, prior to census histogram disintegration. -/
theorem signedGraphMoment_eq_pairMoment (n k : ℕ) :
    signedGraphMoment n k = 4 * (2 : ℤ)^k * pairMoment n k := by
  unfold signedGraphMoment pairMoment
  calc
    (∑ p ∈ admissiblePairs n, ∑ s : Bool × Bool,
      (crossDegree n s.1 s.2 p.1 p.2 : ℤ)^k) =
        ∑ p ∈ admissiblePairs n,
          4 * (2 : ℤ)^k * ((nonassocMiddles n p.1 p.2).card : ℤ)^k := by
      apply Finset.sum_congr rfl
      intro p hp
      have hp' := (Finset.mem_filter.mp hp).1
      have hi : p.1 < 2^n := Finset.mem_range.mp (Finset.mem_product.mp hp').1
      have hj : p.2 < 2^n := Finset.mem_range.mp (Finset.mem_product.mp hp').2
      have ht : ∀ s : Bool × Bool,
          (crossDegree n s.1 s.2 p.1 p.2 : ℤ)^k =
          (2 : ℤ)^k * ((nonassocMiddles n p.1 p.2).card : ℤ)^k := by
        intro s
        rw [crossDegree_eq_two_mul_card n s.1 s.2 p.1 p.2 hi hj]
        push_cast
        rw [mul_pow]
      simp_rw [ht]
      simp only [Finset.sum_const, Finset.card_univ, Fintype.card_prod,
        Fintype.card_bool, nsmul_eq_mul]
      ring
    _ = 4 * (2 : ℤ)^k *
        ∑ p ∈ admissiblePairs n, ((nonassocMiddles n p.1 p.2).card : ℤ)^k := by
      rw [Finset.mul_sum]

/-- Histogram disintegration, using the proven quantization, bounds and census counts. -/
theorem pairMoment_eq_census (q k : ℕ) : pairMoment (q + 3) k = censusMoment k q := by
  classical
  symm
  calc
    censusMoment k q =
        ∑ t ∈ range (2^q), (8 * (t : ℤ) + 4)^k *
          (degreeCount (q+3) (8*t+4) : ℤ) := by
      simp only [censusMoment, degreeCount_eq_censusT]
    _ = ∑ t ∈ range (2^q), ∑ p ∈ admissiblePairs (q+3),
        if (nonassocMiddles (q+3) p.1 p.2).card = 8*t+4
        then (8 * (t : ℤ) + 4)^k else 0 := by
      apply Finset.sum_congr rfl
      intro t ht
      rw [degreeCount, Finset.card_filter, Nat.cast_sum, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro p hp
      split_ifs <;> simp_all
    _ = ∑ p ∈ admissiblePairs (q+3), ∑ t ∈ range (2^q),
        if (nonassocMiddles (q+3) p.1 p.2).card = 8*t+4
        then (8 * (t : ℤ) + 4)^k else 0 := by
      rw [Finset.sum_comm]
    _ = pairMoment (q+3) k := by
      unfold pairMoment
      apply Finset.sum_congr rfl
      intro p hp
      have hmem := Finset.mem_filter.mp hp
      have hi : p.1 < 2^(q+3) := Finset.mem_range.mp (Finset.mem_product.mp hmem.1).1
      have hj : p.2 < 2^(q+3) := Finset.mem_range.mp (Finset.mem_product.mp hmem.1).2
      obtain ⟨hi0,hj0,hij⟩ := hmem.2
      let d := (nonassocMiddles (q+3) p.1 p.2).card
      have heq : d = towerDegree (q+3) p.1 p.2 :=
        nonassocMiddles_card_eq_towerDegree (q+3) p.1 p.2 hi hj hi0 hj0 hij
      have hmod : d % 8 = 4 := by
        rw [heq]
        exact towerDegree_mod_eight (q+3) (by omega) p.1 p.2 hi hj hi0 hj0 hij
      have hb : d ≤ 2^(q+3)-4 := by
        rw [heq]
        exact (towerDegree_bounds (q+3) (by omega) p.1 p.2 hi hj hi0 hj0 hij).2
      have hpow : (2 : ℕ)^(q+3) = 8 * 2^q := by ring
      rw [hpow] at hb
      have hd : d = 8 * (d/8) + 4 := by omega
      have ht : d/8 < 2^q := by omega
      rw [Finset.sum_eq_single (d/8)]
      · have hcast : 8 * ((d/8 : ℕ) : ℤ) + 4 = (d : ℤ) := by
          exact_mod_cast hd.symm
        rw [if_pos hd, hcast]
      · intro t ht' hne
        have hbad : d ≠ 8*t+4 := by omega
        rw [if_neg hbad]
      · intro hnot
        exact False.elim (hnot (Finset.mem_range.mpr ht))

/-- Actual fully signed cross-half graph moments: ambient dimension 2^(q+4).
This is not the primitive graph in the same dimension as the census. -/
theorem signedGraphMoment_eq_census (q k : ℕ) :
    signedGraphMoment (q+3) k = 4 * (2 : ℤ)^k * censusMoment k q := by
  rw [signedGraphMoment_eq_pairMoment, pairMoment_eq_census]

end BridgeLab.GraphMoments
