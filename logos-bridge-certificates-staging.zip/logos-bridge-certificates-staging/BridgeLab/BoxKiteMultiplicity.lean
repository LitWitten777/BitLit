/-
UNCOMPILED CANDIDATE. Structural multiplicity refinement, not native_decide.
Derivation: octahedron adjacency acts by 4 on constants, -2 on the two-dimensional
pair-constant sum-zero subspace, and 0 on the three opposite-pair differences.
Symmetric/antisymmetric lifts to the double cover give eigenvalues 4-mu/4+mu.
The explicit rational eigenbasis and its inverse implement that decomposition.
-/
import RequestProject.ZeroDivisorGraph
import RequestProject.Expansion
import Mathlib

namespace BridgeLab.BoxKite
open Matrix Polynomial

section DoubleCover
variable {ι : Type*} [Fintype ι]

def coverOp (A : Matrix ι ι ℝ) (d : ℝ) (f : ι × Bool → ℝ) (v : ι × Bool) : ℝ :=
  d * f v - ∑ j, A v.1 j * f (j, !v.2)
def plusLift (x : ι → ℝ) (v : ι × Bool) : ℝ := x v.1
def minusLift (x : ι → ℝ) (v : ι × Bool) : ℝ := if v.2 then -x v.1 else x v.1

theorem plusLift_eigen (A : Matrix ι ι ℝ) (d μ : ℝ) (x : ι → ℝ)
    (hx : A *ᵥ x = μ • x) :
    coverOp A d (plusLift x) = (d - μ) • plusLift x := by
  funext v
  have h := congrFun hx v.1
  simp only [Matrix.mulVec, dotProduct, Pi.smul_apply, smul_eq_mul] at h
  simp only [coverOp, plusLift, Pi.smul_apply, smul_eq_mul]
  rw [h]
  ring

theorem minusLift_eigen (A : Matrix ι ι ℝ) (d μ : ℝ) (x : ι → ℝ)
    (hx : A *ᵥ x = μ • x) :
    coverOp A d (minusLift x) = (d + μ) • minusLift x := by
  funext v
  obtain ⟨i, b⟩ := v
  have h := congrFun hx i
  simp only [Matrix.mulVec, dotProduct, Pi.smul_apply, smul_eq_mul] at h
  cases b <;>
    simp [coverOp, minusLift, Pi.smul_apply, smul_eq_mul, mul_neg,
      Finset.sum_neg_distrib] <;> nlinarith [h]
end DoubleCover

abbrev V := Fin 6 × Bool

/-- Constants, two pair-constant sum-zero vectors, three opposite-pair differences. -/
def octBasis : Fin 6 → Fin 6 → ℚ :=
  ![![1,1,1,1,1,1], ![1,-1,0,1,-1,0], ![1,1,-2,1,1,-2],
    ![1,0,0,-1,0,0], ![0,1,0,0,-1,0], ![0,0,1,0,0,-1]]

def basisIndex : Fin 12 → Fin 6 := ![0,1,2,3,4,5,3,4,5,1,2,0]
def liftSign : Fin 12 → ℚ := ![1,-1,-1,1,1,1,-1,-1,-1,1,1,-1]
def eigenvalues : Fin 12 → ℚ := ![0,2,2,4,4,4,4,4,4,6,6,8]
def normSq : Fin 12 → ℚ := ![12,8,24,4,4,4,4,4,4,8,24,12]

def P : Matrix V (Fin 12) ℚ := fun v k =>
  octBasis (basisIndex k) v.1 * (if v.2 then liftSign k else 1)
def Q : Matrix (Fin 12) V ℚ := fun k v => P v k / normSq k

-- These are small rational linear identities, not determinant or spectrum enumeration.
-- Kernel evaluation avoids the native-evaluation trust extension. The mathematical
-- reason they hold is the orthogonal lift decomposition described above.
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
lemma PQ : P * Q = 1 := by decide +kernel
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
lemma QP : Q * P = 1 := by decide +kernel
set_option maxRecDepth 100000 in
set_option maxHeartbeats 0 in
lemma LP : boxKiteGraph.lapMatrix ℚ * P = P * Matrix.diagonal eigenvalues := by
  decide +kernel

lemma diagonalization : boxKiteGraph.lapMatrix ℚ =
    P * (Matrix.diagonal eigenvalues * Q) := by
  calc
    boxKiteGraph.lapMatrix ℚ = boxKiteGraph.lapMatrix ℚ * (P * Q) := by rw [PQ, mul_one]
    _ = (boxKiteGraph.lapMatrix ℚ * P) * Q := (mul_assoc _ _ _).symm
    _ = (P * Matrix.diagonal eigenvalues) * Q := by rw [LP]
    _ = P * (Matrix.diagonal eigenvalues * Q) := mul_assoc _ _ _

/-- Algebraic multiplicities, via a full eigenbasis rather than an annihilating polynomial. -/
theorem charpoly_rat : (boxKiteGraph.lapMatrix ℚ).charpoly =
    X * (X - 2)^2 * (X - 4)^6 * (X - 6)^2 * (X - 8) := by
  have h := Matrix.charpoly_mul_comm_of_le P (Matrix.diagonal eigenvalues * Q)
    (by decide : Fintype.card (Fin 12) ≤ Fintype.card V)
  have hc : Fintype.card V - Fintype.card (Fin 12) = 0 := by decide
  rw [hc, pow_zero, one_mul] at h
  rw [← Matrix.mul_assoc, ← diagonalization] at h
  rw [mul_assoc, QP, mul_one] at h
  rw [h, Matrix.charpoly_diagonal]
  norm_num [eigenvalues, Fin.prod_univ_succ] <;> ring

lemma lap_real_eq_map : boxKiteGraph.lapMatrix ℝ =
    (boxKiteGraph.lapMatrix ℚ).map (algebraMap ℚ ℝ) := by
  ext i j
  simp only [SimpleGraph.lapMatrix, SimpleGraph.degMatrix, SimpleGraph.adjMatrix,
    Matrix.map_apply, Matrix.sub_apply, Matrix.diagonal_apply, Matrix.of_apply]
  split_ifs <;> simp

theorem charpoly_real : (boxKiteGraph.lapMatrix ℝ).charpoly =
    X * (X - 2)^2 * (X - 4)^6 * (X - 6)^2 * (X - 8) := by
  rw [lap_real_eq_map, Matrix.charpoly_map, charpoly_rat]
  simp

def eigenList : List ℝ := [0,2,2,4,4,4,4,4,4,6,6,8]

lemma charpoly_real_prod : (boxKiteGraph.lapMatrix ℝ).charpoly =
    (((eigenList : List ℝ) : Multiset ℝ).map (fun a => X - C a)).prod := by
  rw [charpoly_real]
  norm_num [eigenList] <;> ring

/-- Multiset of real characteristic roots. This refines, rather than redefines,
Mathlib's SET-valued `spectrum` used by boxKiteGraph_lapMatrix_spectrum. -/
theorem boxKiteGraph_lapMatrix_eigenvalues_multiset :
    (boxKiteGraph.lapMatrix ℝ).charpoly.roots =
      (([0,2,2,4,4,4,4,4,4,6,6,8] : List ℝ) : Multiset ℝ) := by
  rw [charpoly_real_prod, Polynomial.roots_multiset_prod_X_sub_C]
  rfl

end BridgeLab.BoxKite
