/-
UNCOMPILED generated candidate. Integer/rational finite certificates, NOT executed by Lean.
Every generated leaf uses kernel decide (no native_decide); cost is unmeasured.
The Python producer checks all numerical identities before writing this source.
-/
import BridgeNext.AntipodalGraphs
import RequestProject.Expansion
import Sovereign.Graph.HermitianCertificate

set_option maxHeartbeats 0
set_option maxRecDepth 100000

noncomputable section

namespace BridgeCert.Dimension32Data
open Matrix Sovereign BridgeNext.AntipodalGraphs

def lower (a : Fin 28) : ℕ := a.val / 2 + 2
def upper (a : Fin 28) : ℕ := (lower a) ^^^ 1

def decode (a : Fin 28) : RepVertex 4 :=
  (⟨(lower a,upper a), by fin_cases a <;> decide +kernel⟩,decide (a.val % 2 = 0))

def chargeOne := {v : RepVertex 4 // v.1.1.1 ^^^ v.1.1.2 = 1}
def decodeSector (a : Fin 28) : chargeOne :=
  ⟨decode a, by fin_cases a <;> decide +kernel⟩

lemma decodeSector_bijective : Function.Bijective decodeSector := by decide +kernel

def sectorEquiv : Fin 28 ≃ chargeOne := Equiv.ofBijective decodeSector decodeSector_bijective

def graph : SimpleGraph (Fin 28) := (repGraph 4).comap decode
instance : DecidableRel graph.Adj := fun _ _ => inferInstance

def sectorGraph : SimpleGraph chargeOne := (repGraph 4).comap Subtype.val

def sectorIso : graph ≃g sectorGraph where
  toEquiv := sectorEquiv
  map_rel_iff' := by intro a b; rfl

def LZ : Matrix (Fin 28) (Fin 28) ℤ := ![![12, 0, 0, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1],
  ![0, 12, 0, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0],
  ![0, 0, 12, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0],
  ![0, 0, 0, 12, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1],
  ![0, -1, -1, 0, 12, 0, 0, 0, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1],
  ![-1, 0, 0, -1, 0, 12, 0, 0, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0],
  ![-1, 0, 0, -1, 0, 0, 12, 0, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0],
  ![0, -1, -1, 0, 0, 0, 0, 12, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1],
  ![-1, 0, 0, -1, -1, 0, 0, -1, 12, 0, 0, 0, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1],
  ![0, -1, -1, 0, 0, -1, -1, 0, 0, 12, 0, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0],
  ![0, -1, -1, 0, 0, -1, -1, 0, 0, 0, 12, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0],
  ![-1, 0, 0, -1, -1, 0, 0, -1, 0, 0, 0, 12, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1],
  ![0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 12, 0, 0, 0, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0],
  ![-1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 0, 12, 0, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1],
  ![-1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 0, 0, 12, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1],
  ![0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, 0, 0, 12, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0],
  ![-1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 12, 0, 0, 0, 0, -1, -1, 0, -1, 0, 0, -1],
  ![0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, 12, 0, 0, -1, 0, 0, -1, 0, -1, -1, 0],
  ![0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, 0, 12, 0, -1, 0, 0, -1, 0, -1, -1, 0],
  ![-1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 0, 0, 0, 12, 0, -1, -1, 0, -1, 0, 0, -1],
  ![0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 12, 0, 0, 0, -1, 0, 0, -1],
  ![-1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, 12, 0, 0, 0, -1, -1, 0],
  ![-1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, 0, 12, 0, 0, -1, -1, 0],
  ![0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, 0, 0, 0, 12, -1, 0, 0, -1],
  ![-1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 12, 0, 0, 0],
  ![0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, 12, 0, 0],
  ![0, -1, -1, 0, 0, -1, -1, 0, 0, -1, -1, 0, -1, 0, 0, -1, 0, -1, -1, 0, 0, -1, -1, 0, 0, 0, 12, 0],
  ![-1, 0, 0, -1, -1, 0, 0, -1, -1, 0, 0, -1, 0, -1, -1, 0, -1, 0, 0, -1, -1, 0, 0, -1, 0, 0, 0, 12]]
def PZ : Matrix (Fin 28) (Fin 28) ℤ := ![![1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 4, 5, 4, 1, 1, 1],
  ![1, -1, -1, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, -6, -1, -2, -13, -1, -1],
  ![1, -1, -1, -1, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, -6, -1, -2, -13, -1, -1],
  ![1, 1, 1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 4, 5, 4, 1, 1, 1],
  ![1, -1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, -6, -1, 4, 1, 1, 1],
  ![1, 1, -1, -1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, 4, 5, -2, -13, -1, -1],
  ![1, 1, -1, -1, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, 4, 5, -2, -13, -1, -1],
  ![1, -1, 1, 1, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 1, 1, 1, -6, -1, 4, 1, 1, 1],
  ![1, 0, 2, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2, 1, 1, -1, 2, 7, 8, -1, -1],
  ![1, 0, -2, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2, 1, 1, -1, 2, -5, -20, 1, 1],
  ![1, 0, -2, 1, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2, 1, 1, -1, 2, -5, -20, 1, 1],
  ![1, 0, 2, -1, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -2, 1, 1, -1, 2, 7, 8, -1, -1],
  ![1, 0, 0, -3, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -3, 1, -1, 2, 1, -6, 1, -3],
  ![1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, -3, 1, -1, 2, 1, -6, -1, 3],
  ![1, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, -3, 1, -1, 2, 1, -6, -1, 3],
  ![1, 0, 0, -3, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -3, 1, -1, 2, 1, -6, 1, -3],
  ![1, 1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, -4, -6, -1, -2, -13, 0, 4],
  ![1, -1, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -4, 4, 5, 4, 1, 0, -4],
  ![1, -1, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, -4, 4, 5, 4, 1, 0, -4],
  ![1, 1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, -4, -6, -1, -2, -13, 0, 4],
  ![1, -1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 10, -7, -2, -13, 0, 4],
  ![1, 1, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -13, 4, 1, 0, -4],
  ![1, 1, -1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, -13, 4, 1, 0, -4],
  ![1, -1, 1, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 10, -7, -2, -13, 0, 4],
  ![1, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, -12, 22, 0, -4],
  ![1, 0, -2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 50, 0, 4],
  ![1, 0, -2, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 50, 0, 4],
  ![1, 0, 2, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, -12, 22, 0, -4]]
def eigenZ : Fin 28 → ℤ := ![0, 6, 6, 8, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 12, 14, 14, 14, 14, 14, 14, 14, 14, 18, 18]
def normZ : Fin 28 → ℤ := ![28, 16, 48, 60, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 8, 24, 48, 80, 520, 624, 600, 8400, 16, 240]

def L : Matrix (Fin 28) (Fin 28) ℚ := LZ.map (Int.castRingHom ℚ)
def P : Matrix (Fin 28) (Fin 28) ℚ := PZ.map (Int.castRingHom ℚ)
def eigen : Fin 28 → ℚ := fun i => (eigenZ i : ℚ)
def Q : Matrix (Fin 28) (Fin 28) ℚ := fun i j => (PZ j i : ℚ) / (normZ i : ℚ)
def weight : Fin 28 → ℚ := fun i => if i = 0 then 0 else (eigen i - 6) / normZ i

def LR : Matrix (Fin 28) (Fin 28) ℝ := LZ.map (Int.castRingHom ℝ)
def PR : Matrix (Fin 28) (Fin 28) ℝ := PZ.map (Int.castRingHom ℝ)
def weightR : Fin 28 → ℝ := fun i => (weight i : ℝ)
def JR : Matrix (Fin 28) (Fin 28) ℝ := fun _ _ => 1

lemma lap_int : graph.lapMatrix ℤ = LZ := by decide +kernel
lemma regular : ∀ a, graph.degree a = 12 := by decide +kernel
lemma eigen_relation : LZ * PZ = PZ * Matrix.diagonal eigenZ := by decide +kernel
lemma orthogonal : PZᵀ * PZ = Matrix.diagonal normZ := by decide +kernel
lemma norms_positive : ∀ i, 0 < normZ i := by decide +kernel
lemma QP : Q * P = 1 := by decide +kernel
lemma PQ : P * Q = 1 := by decide +kernel
lemma LP : L * P = P * Matrix.diagonal eigen := by decide +kernel
lemma weight_nonneg : ∀ i, 0 ≤ weight i := by decide +kernel

/-- Entrywise leaf avoids an exponentially nested matrix-polynomial reduction. -/
lemma lower_gram_entry : ∀ i j,
    L i j - (if i = j then 6 else 0) + (3/14 : ℚ) =
      ∑ k, P i k * weight k * P j k := by decide +kernel

lemma witness_mean_Z : (∑ i, PZ i 1) = 0 := by decide +kernel
lemma witness_eigen_Z : ∀ i, (∑ j, LZ i j * PZ j 1) = 6 * PZ i 1 := by decide +kernel
lemma witness_nonzero_Z : PZ 0 1 ≠ 0 := by decide +kernel

def projectorCoeffs : List ℚ := [(1), (-253/504), (65/672), (-325/36288), (29/72576), (-1/145152)]
lemma filter_values : ∀ i, Sovereign.Graph.hornerS (eigen i) projectorCoeffs =
    if i = 0 then 1 else 0 := by decide +kernel
lemma projector_entry : ∀ i j,
    (∑ k, P i k * (if k = 0 then 1 else 0) * Q k j) = (1/28 : ℚ) := by decide +kernel

def cut : Finset (Fin 28) := {0, 3, 4, 7, 8, 11, 12, 15, 16, 19, 20, 23, 24, 27}
lemma cut_card : cut.card = 14 := by decide +kernel
lemma cut_boundary : graph.edgeBoundary cut = 56 := by decide +kernel

lemma reachable_from_zero (a : Fin 28) : graph.Reachable 0 a := by
  fin_cases a
  · exact SimpleGraph.Reachable.refl _
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans (((show graph.Adj (5 : Fin 28) (9 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (9 : Fin 28) (1 : Fin 28) from by decide +kernel).reachable))
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans (((show graph.Adj (5 : Fin 28) (9 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (9 : Fin 28) (2 : Fin 28) from by decide +kernel).reachable))
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (3 : Fin 28) from by decide +kernel).reachable)
  · exact ((show graph.Adj (0 : Fin 28) (8 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (8 : Fin 28) (4 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable
  · exact (show graph.Adj (0 : Fin 28) (6 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (8 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (8 : Fin 28) (7 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (8 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (9 : Fin 28) from by decide +kernel).reachable)
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (10 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (11 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (12 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (13 : Fin 28) from by decide +kernel).reachable
  · exact (show graph.Adj (0 : Fin 28) (14 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (15 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (16 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (13 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (13 : Fin 28) (17 : Fin 28) from by decide +kernel).reachable)
  · exact ((show graph.Adj (0 : Fin 28) (13 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (13 : Fin 28) (18 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (19 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (8 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (8 : Fin 28) (20 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (21 : Fin 28) from by decide +kernel).reachable
  · exact (show graph.Adj (0 : Fin 28) (22 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (8 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (8 : Fin 28) (23 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (24 : Fin 28) from by decide +kernel).reachable
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (25 : Fin 28) from by decide +kernel).reachable)
  · exact ((show graph.Adj (0 : Fin 28) (5 : Fin 28) from by decide +kernel).reachable).trans ((show graph.Adj (5 : Fin 28) (26 : Fin 28) from by decide +kernel).reachable)
  · exact (show graph.Adj (0 : Fin 28) (27 : Fin 28) from by decide +kernel).reachable

theorem connected : graph.Connected :=
  ⟨fun u v => (reachable_from_zero u).symm.trans (reachable_from_zero v)⟩

end BridgeCert.Dimension32Data
