/-
UNCOMPILED import-compatibility target. RequestProject is a documented review copy:
its spectralGap identifiers are renamed variationalGap, not silently equated to
Sovereign's sorted-eigenvalue gap. Uploaded originals are unchanged.
-/
import RequestProject.Expansion
import Sovereign.Algebra.LaplacianSpectralGap
import BridgeLab.CheegerWitness
import BridgeCert.Dimension32

namespace BridgeCert.GapApiSmoke

-- Both declarations must elaborate in one environment after the review-copy rename.
#check SimpleGraph.variationalGap
#check SimpleGraph.spectralGap
#check SimpleGraph.variationalGap_le_two_mul_cheegerConstant
#check SimpleGraph.spectralGap_pos_iff
#check BridgeLab.Cheeger.hard_cheeger_high_gap
#check BridgeCert.Dimension32.variational_gap_six

-- No general equality between the two gap definitions is asserted here.
end BridgeCert.GapApiSmoke
