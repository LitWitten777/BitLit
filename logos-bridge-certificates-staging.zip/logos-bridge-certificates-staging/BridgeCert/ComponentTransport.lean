/-
UNCOMPILED CANDIDATE. Component equivalence of an independent two-fold blow-up,
with its essential no-isolates hypothesis, and actual cross-half graph transport.
-/
import BridgeNext.AntipodalGraphs
import BridgeNext.CensusComponents
import Sovereign.Algebra.Sexagintaquattuorion

namespace BridgeCert.ComponentTransport
open SimpleGraph Sovereign Sovereign.Graph BridgeNext.AntipodalGraphs

section General
variable {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj]

def projection : blowUp G →g G where
  toFun := Prod.fst
  map_rel' h := h

def sectionMap : G →g blowUp G where
  toFun v := (v,false)
  map_rel' h := h

lemma same_fiber_reachable (hne : ∀ v, ∃ w, G.Adj v w) (v : V) (b c : Bool) :
    (blowUp G).Reachable (v,b) (v,c) := by
  obtain ⟨w,hw⟩ := hne v
  have h1 : (blowUp G).Adj (v,b) (w,false) := hw
  have h2 : (blowUp G).Adj (w,false) (v,c) := hw.symm
  exact h1.reachable.trans h2.reachable

lemma blowUp_reachable_iff (hne : ∀ v, ∃ w, G.Adj v w) (x y : V × Bool) :
    (blowUp G).Reachable x y ↔ G.Reachable x.1 y.1 := by
  constructor
  · exact fun h => h.map (projection G)
  · intro h
    exact (same_fiber_reachable G hne x.1 x.2 false).trans
      ((h.map (sectionMap G)).trans (same_fiber_reachable G hne y.1 false y.2))

/-- An isolated vertex would split into two components, so hne cannot be dropped. -/
def blowUpComponentEquiv (hne : ∀ v, ∃ w, G.Adj v w) :
    (blowUp G).ConnectedComponent ≃ G.ConnectedComponent where
  toFun := ConnectedComponent.map (projection G)
  invFun := ConnectedComponent.map (sectionMap G)
  left_inv C := C.ind (fun x => ConnectedComponent.sound
    (same_fiber_reachable G hne x.1 false x.2))
  right_inv C := C.ind (fun _ => rfl)

end General

lemma repGraph_degree_pos (n : ℕ) (hn : 3 ≤ n) (v : RepVertex n) :
    0 < (repGraph n).degree v := by
  let p := canonicalVertex n v
  have he : (antipodalIso n) p = (v,false) := by
    rcases v with ⟨v,r⟩
    cases r <;> rfl
  have hi := (antipodalIso n).degree_eq p
  have hc := crossDegree_eq_two_mul_towerDegree n p.1.1 p.1.2.1
    p.1.2.2.1 p.1.2.2.2 p.1.2.2.1.isLt p.1.2.2.2.isLt
    p.2.1 p.2.2.1 p.2.2.2
  have ht := (towerDegree_bounds n hn p.1.2.2.1 p.1.2.2.2
    p.1.2.2.1.isLt p.1.2.2.2.isLt p.2.1 p.2.2.1 p.2.2.2).1
  rw [he, blowUp_degree, fullGraph_degree, hc] at hi
  omega

lemma repGraph_has_neighbor (n : ℕ) (hn : 3 ≤ n) (v : RepVertex n) :
    ∃ w, (repGraph n).Adj v w := by
  rw [← (repGraph n).degree_pos_iff_exists_adj]
  exact repGraph_degree_pos n hn v

def antipodalComponentEquiv (n : ℕ) (hn : 3 ≤ n) :
    (fullGraph n).ConnectedComponent ≃ (repGraph n).ConnectedComponent :=
  (antipodalIso n).connectedComponentEquiv.trans
    (blowUpComponentEquiv (repGraph n) (repGraph_has_neighbor n hn))

/-- Reorder Fin-indexed signs/indices into the supplied Nat-indexed ZD labels. -/
def labelEquiv (n : ℕ) (hn : 3 ≤ n) : admVertex n ≃ ZDAsymptotics.ZDVert n where
  toFun p := ⟨(((p.1.2.2.1 : ℕ),(p.1.2.2.2 : ℕ)),p.1.1,p.1.2.1),
    (CrossHalfComponents.mem_crossZD_iff hn _).mpr
      ⟨p.1.2.2.1.isLt,p.1.2.2.2.isLt,p.2.1,p.2.2.1,p.2.2.2⟩⟩
  invFun p := by
    have h := (CrossHalfComponents.mem_crossZD_iff hn p.1).mp p.2
    exact ⟨(p.1.2.1,p.1.2.2,⟨p.1.1.1,h.1⟩,⟨p.1.1.2,h.2.1⟩),h.2.2⟩
  left_inv _ := rfl
  right_inv _ := rfl

/-- The new fullGraph is not merely equicardinal with the supplied ZD graph. -/
def signedZDIso (n : ℕ) (hn : 3 ≤ n) : fullGraph n ≃g ZDAsymptotics.zdGraph n where
  toEquiv := labelEquiv n hn
  map_rel_iff' := by
    intro p q
    constructor
    · intro h
      rcases h.2.2.2 with h | h
      · exact (crossAnnihilates_iff n p.1.1 p.1.2.1 q.1.1 q.1.2.1
          p.1.2.2.1 p.1.2.2.2 q.1.2.2.1 q.1.2.2.2
          p.1.2.2.1.isLt p.1.2.2.2.isLt q.1.2.2.1.isLt q.1.2.2.2.isLt).mpr h
      · have hb := (crossAnnihilates_iff n q.1.1 q.1.2.1 p.1.1 p.1.2.1
          q.1.2.2.1 q.1.2.2.2 p.1.2.2.1 p.1.2.2.2
          q.1.2.2.1.isLt q.1.2.2.2.isLt p.1.2.2.1.isLt p.1.2.2.2.isLt).mpr h
        rw [← crossAnnihilates_comm n p.1.1 p.1.2.1 q.1.1 q.1.2.1
          p.1.2.2.1 p.1.2.2.2 q.1.2.2.1 q.1.2.2.2
          p.1.2.2.1.isLt p.1.2.2.2.isLt q.1.2.2.1.isLt q.1.2.2.2.isLt
          p.2.1 q.2.1] at hb
        exact hb
    · intro h
      refine ⟨?_,⟨p.1.2.2.1.isLt,p.1.2.2.2.isLt⟩,
        ⟨q.1.2.2.1.isLt,q.1.2.2.2.isLt⟩,Or.inl ?_⟩
      · intro he
        have hpq : p = q := (labelEquiv n hn).injective (Subtype.ext he)
        subst q
        exact (fullGraph n).loopless p h
      · exact (crossAnnihilates_iff n p.1.1 p.1.2.1 q.1.1 q.1.2.1
          p.1.2.2.1 p.1.2.2.2 q.1.2.2.1 q.1.2.2.2
          p.1.2.2.1.isLt p.1.2.2.2.isLt q.1.2.2.1.isLt q.1.2.2.2.isLt).mp h

/-- Both sides now refer to the actual graph types used for moments/counts. -/
def representativeZDComponentEquiv (n : ℕ) (hn : 3 ≤ n) :
    (repGraph n).ConnectedComponent ≃ (ZDAsymptotics.zdGraph n).ConnectedComponent :=
  (antipodalComponentEquiv n hn).symm.trans (signedZDIso n hn).connectedComponentEquiv

theorem representative_components_card (n : ℕ) (hn : 3 ≤ n) :
    Nat.card (repGraph n).ConnectedComponent = 2^n - 1 := by
  rw [Nat.card_congr (representativeZDComponentEquiv n hn)]
  exact ZDAsymptotics.zdGraph_components_card hn

/-- The component count and the degree-Hankel matrix belong to the SAME repGraph. -/
theorem components_eq_eight_hankel_rank_sub_one (q : ℕ) :
    Nat.card (repGraph (q+3)).ConnectedComponent =
      8 * (BridgeNext.CensusComponents.representativeHankel q (2^q)).rank - 1 := by
  rw [representative_components_card (q+3) (by omega),
    BridgeNext.CensusComponents.representativeHankel_rank, min_self]
  have hp : (2 : ℕ)^(q+3) = 8 * 2^q := by ring
  rw [hp]

end BridgeCert.ComponentTransport
