/-
UNCOMPILED CANDIDATE. Explicit 28-vertex dimension32 charge17 graph:
rational diagonalization, characteristic polynomial, projector, real gap certificate.
No general Courant-Fischer equivalence or full hard-Cheeger theorem is asserted.
-/
import BridgeCert.Dimension32Data

noncomputable section

namespace BridgeCert.Dimension32
open Matrix Polynomial Sovereign.Graph BridgeCert.Dimension32Data

lemma lap_cast (R : Type*) [CommRing R] : graph.lapMatrix R = LZ.map (Int.castRingHom R) := by
  calc
    graph.lapMatrix R = (graph.lapMatrix ℤ).map (Int.castRingHom R) := by
      ext i j
      simp only [SimpleGraph.lapMatrix, SimpleGraph.degMatrix, SimpleGraph.adjMatrix,
        Matrix.map_apply, Matrix.sub_apply, Matrix.diagonal_apply, Matrix.of_apply]
      split_ifs <;> simp
    _ = LZ.map (Int.castRingHom R) := by rw [lap_int]

lemma diagonalization : L = P * Matrix.diagonal eigen * Q := by
  calc
    L = L * (P * Q) := by rw [PQ, mul_one]
    _ = (L * P) * Q := by rw [Matrix.mul_assoc]
    _ = P * Matrix.diagonal eigen * Q := by rw [LP]

/-- Full multiplicities, not just a set-valued spectrum. -/
theorem charpoly_rat : (graph.lapMatrix ℚ).charpoly =
    X * (X-6)^2 * (X-8) * (X-12)^14 * (X-14)^8 * (X-18)^2 := by
  rw [lap_cast ℚ]
  change L.charpoly = _
  have h := Matrix.charpoly_mul_comm P (Matrix.diagonal eigen * Q)
  have hleft : P * (Matrix.diagonal eigen * Q) = L := by
    rw [← Matrix.mul_assoc, ← diagonalization]
  rw [hleft, Matrix.mul_assoc, QP, Matrix.mul_one] at h
  rw [h, Matrix.charpoly_diagonal]
  norm_num [eigen, eigenZ, Fin.prod_univ_succ] <;> ring

lemma lap_real_map_rat : graph.lapMatrix ℝ =
    (graph.lapMatrix ℚ).map (algebraMap ℚ ℝ) := by
  ext i j
  simp only [SimpleGraph.lapMatrix, SimpleGraph.degMatrix, SimpleGraph.adjMatrix,
    Matrix.map_apply, Matrix.sub_apply, Matrix.diagonal_apply, Matrix.of_apply]
  split_ifs <;> simp

theorem charpoly_real : (graph.lapMatrix ℝ).charpoly =
    X * (X-6)^2 * (X-8) * (X-12)^14 * (X-14)^8 * (X-18)^2 := by
  rw [lap_real_map_rat, Matrix.charpoly_map, charpoly_rat]
  simp

/-- Algebraic intertwinement avoids computing a naively nested fifth matrix power. -/
lemma horner_intertwine {ι : Type*} [Fintype ι] [DecidableEq ι]
    (A B T : Matrix ι ι ℚ) (h : A*T = T*B) (cs : List ℚ) :
    hornerM A cs * T = T * hornerM B cs := by
  induction cs with
  | nil => simp [hornerM]
  | cons c cs ih =>
    have hc : Matrix.diagonal (fun _ : ι => c) * T = T * Matrix.diagonal (fun _ => c) := by
      ext i j
      simp [Matrix.diagonal_mul, Matrix.mul_diagonal, mul_comm]
    change (Matrix.diagonal (fun _ => c) + A * hornerM A cs) * T =
      T * (Matrix.diagonal (fun _ => c) + B * hornerM B cs)
    calc
      _ = Matrix.diagonal (fun _ => c) * T + A * (hornerM A cs * T) := by noncomm_ring
      _ = T * Matrix.diagonal (fun _ => c) + (A*T) * hornerM B cs := by
        rw [hc, ih]
        noncomm_ring
      _ = _ := by rw [h]; noncomm_ring

/-- The normalized degree5 polynomial is the actual zero-eigenspace projector. -/
theorem zero_projector : hornerM (graph.lapMatrix ℚ) projectorCoeffs =
    (1/28 : ℚ) • (fun _ _ : Fin 28 => (1 : ℚ)) := by
  rw [lap_cast ℚ]
  change hornerM L projectorCoeffs = _
  have ht := horner_intertwine L (Matrix.diagonal eigen) P LP projectorCoeffs
  rw [hornerM_diagonal] at ht
  have hd : (fun i => hornerS (eigen i) projectorCoeffs) =
      (fun i : Fin 28 => if i = 0 then (1 : ℚ) else 0) := funext filter_values
  rw [hd] at ht
  have hfull : hornerM L projectorCoeffs =
      P * Matrix.diagonal (fun i : Fin 28 => if i = 0 then (1 : ℚ) else 0) * Q := by
    calc
      _ = hornerM L projectorCoeffs * (P*Q) := by rw [PQ, mul_one]
      _ = (hornerM L projectorCoeffs * P) * Q := by noncomm_ring
      _ = _ := by rw [ht]
  rw [hfull]
  ext i j
  rw [Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.smul_apply, smul_eq_mul, mul_one]
  exact projector_entry i j

theorem projector_trace : (hornerM (graph.lapMatrix ℚ) projectorCoeffs).trace = 1 := by
  rw [zero_projector]
  norm_num [Matrix.trace, Matrix.diag, Fin.sum_univ_succ]

/-- An exact rational Gram certificate transferred entrywise to real matrices. -/
lemma gap_gram_real : graph.lapMatrix ℝ - (6 : ℝ) • (1 : Matrix (Fin 28) (Fin 28) ℝ) +
    (3/14 : ℝ) • JR = PR * Matrix.diagonal weightR * PRᵀ := by
  rw [lap_cast ℝ]
  ext i j
  rw [Matrix.mul_apply]
  simp only [Matrix.mul_diagonal, Matrix.transpose_apply]
  have h := congrArg (fun q : ℚ => (q : ℝ)) (lower_gram_entry i j)
  push_cast at h
  simpa [L, P, PR, weightR, JR, Matrix.map_apply, Matrix.add_apply, Matrix.sub_apply,
    Matrix.smul_apply, Matrix.one_apply, smul_eq_mul] using h

lemma gap_psd : (graph.lapMatrix ℝ - (6 : ℝ) • (1 : Matrix (Fin 28) (Fin 28) ℝ) +
    (3/14 : ℝ) • JR).PosSemidef := by
  rw [gap_gram_real]
  have hd : (Matrix.diagonal weightR).PosSemidef := by
    apply Matrix.posSemidef_diagonal_iff.mpr
    intro i
    exact_mod_cast weight_nonneg i
  have hs : PRᴴ = PRᵀ := by ext i j; simp
  simpa only [hs] using hd.mul_mul_conjTranspose_same PR

theorem energy_lower_bound (x : Fin 28 → ℝ) (hmean : ∑ i, x i = 0) :
    6 * (x ⬝ᵥ x) ≤ x ⬝ᵥ (graph.lapMatrix ℝ *ᵥ x) := by
  have hj : JR *ᵥ x = 0 := by
    ext i
    simpa [JR, Matrix.mulVec, dotProduct] using hmean
  have h := gap_psd.dotProduct_mulVec_nonneg x
  simp only [star_trivial, Matrix.add_mulVec, Matrix.sub_mulVec, Matrix.smul_mulVec,
    Matrix.one_mulVec, hj, smul_zero, add_zero, dotProduct_sub, dotProduct_smul,
    smul_eq_mul] at h
  linarith

lemma dot_pos {x : Fin 28 → ℝ} (hx : x ≠ 0) : 0 < x ⬝ᵥ x := by
  have hne : ∃ j, x j ≠ 0 := by
    by_contra h
    push_neg at h
    exact hx (funext h)
  obtain ⟨j,hj⟩ := hne
  unfold dotProduct
  calc
    0 < x j * x j := mul_self_pos.mpr hj
    _ ≤ ∑ i, x i * x i := Finset.single_le_sum
      (fun i _ => mul_self_nonneg (x i)) (Finset.mem_univ j)

def witness : Fin 28 → ℝ := fun i => (PZ i 1 : ℝ)

lemma witness_nonzero : witness ≠ 0 := by
  intro h
  have hz : ∀ i, PZ i 1 = 0 := by
    intro i
    have hi : (PZ i 1 : ℝ) = 0 := by simpa [witness] using congrFun h i
    exact_mod_cast hi
  exact witness_nonzero_Z (hz _)

lemma witness_mean : ∑ i, witness i = 0 := by
  change (∑ i, (PZ i 1 : ℝ)) = 0
  exact_mod_cast witness_mean_Z

lemma witness_eigen : graph.lapMatrix ℝ *ᵥ witness = (6 : ℝ) • witness := by
  rw [lap_cast ℝ]
  ext i
  have h := congrArg (fun z : ℤ => (z : ℝ)) (witness_eigen_Z i)
  push_cast at h
  simpa only [Matrix.mulVec, dotProduct, Matrix.map_apply, witness, Pi.smul_apply,
    smul_eq_mul] using h

lemma witness_rayleigh : graph.rayleigh witness = 6 := by
  unfold SimpleGraph.rayleigh
  rw [witness_eigen, dotProduct_smul, smul_eq_mul]
  exact mul_div_cancel_right₀ _ (ne_of_gt (dot_pos witness_nonzero))

/-- This is the variational definition used by the expansion branch, not a renamed
claim that the two gap APIs are already equivalent for arbitrary graphs. -/
theorem variational_gap_six : graph.variationalGap = 6 := by
  have hm : (6 : ℝ) ∈ graph.rayleigh '' {x | x ≠ 0 ∧ ∑ i, x i = 0} :=
    ⟨witness,⟨witness_nonzero,witness_mean⟩,witness_rayleigh⟩
  unfold SimpleGraph.variationalGap
  apply le_antisymm
  · exact csInf_le graph.variationalGap_bddBelow hm
  · apply le_csInf ⟨6,hm⟩
    rintro r ⟨x,⟨hx,hmean⟩,rfl⟩
    rw [SimpleGraph.rayleigh, le_div_iff₀ (dot_pos hx)]
    exact energy_lower_bound x hmean

theorem cheeger_upper_four : graph.cheegerConstant ≤ 4 := by
  have hb : BddBelow ((fun S : Finset (Fin 28) =>
      (graph.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2*S.card ≤ Fintype.card (Fin 28)}) := by
    refine ⟨0, ?_⟩
    rintro r ⟨S,hS,rfl⟩
    positivity
  have hm : ((graph.edgeBoundary cut : ℝ) / cut.card) ∈
      (fun S : Finset (Fin 28) => (graph.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2*S.card ≤ Fintype.card (Fin 28)} := by
    refine ⟨cut,⟨?_,?_⟩,rfl⟩
    · exact Finset.card_pos.mp (by rw [cut_card]; norm_num)
    · norm_num [cut_card]
  have h : graph.cheegerConstant ≤ (graph.edgeBoundary cut : ℝ) / cut.card := csInf_le hb hm
  norm_num [cut_boundary, cut_card] at h
  exact h

/-- The formal candidate bounds are 3≤h≤4. Exact h=4 is currently an exhaustive
Python result, not a new Lean theorem; no general hard-Cheeger proof is hidden here. -/
theorem cheeger_bounds : 3 ≤ graph.cheegerConstant ∧ graph.cheegerConstant ≤ 4 := by
  constructor
  · have h := graph.variationalGap_le_two_mul_cheegerConstant
    rw [variational_gap_six] at h
    linarith
  · exact cheeger_upper_four

end BridgeCert.Dimension32
