# Component transport and the dimension-32 expansion certificate

## Status

**7 November 2026.** This pass addresses antipodal component transport, makes the dimension-32 spectral witness explicit, and stages a review-copy repair of the gap-name collision. Uploaded originals and earlier staging projects are unchanged.

**Lean, Lake and Elan are still absent. No Lean compilation, kernel decision, or axiom query ran.** New Lean files are proof candidates, including the finite leaves written with `decide +kernel`. Their execution cost and elaboration remain unverified.

| Result | Evidence in this pass |
|---|---|
| Antipodal component transport with no isolates | Mathematical argument; new uncompiled general proof and cross-half specialization |
| Same-graph component/Hankel identity | New uncompiled candidate using the explicit signed-label graph isomorphism |
| Dimension-32 rational diagonalization and projector | Executed exact integer/rational checks; explicit matrices supplied |
| Dimension-32 gap 6 | Exact positive-semidefinite certificate plus an attaining zero-mean eigenvector; uncompiled variational-gap proof |
| Dimension-32 Cheeger constant 4, conductance 1/3 | Exhaustive exact Python cut enumeration; **not a Lean theorem** |
| Gap API coexistence | Mechanical review-copy rename and import smoke-test source; **not compiled** |

## 1. Component transport now uses the actual graph types

For the independent m-fold blow-up `G[m]` with m≥1, a nonisolated vertex's fiber lies in a single component: two lifts of v are connected through any neighbor w by `(v,b)—(w,0)—(v,c)`. Walks project to G and lift through a fixed fiber section. Consequently, if G has no isolated vertices,

\[
G[2].\mathrm{ConnectedComponent}\simeq G.\mathrm{ConnectedComponent}.
\]

Without that hypothesis the correct finite count is

\[
c(G[m])=c(G)+(m-1)\,\#\{\text{isolated vertices of }G\}.
\]

A one-vertex edgeless graph is the minimal counterexample to dropping the hypothesis. The verifier checked the count and the precise reachability exception on **all 1,100 labeled simple graphs with 0–5 vertices**, for m=2 and3; 815 of these graphs have no isolates, including the empty graph.

`BridgeCert/ComponentTransport.lean` implements the two-fold component equivalence and specializes it to the cross-half family. Positivity comes from the existing tower-degree lower bound, not from a fitted degree histogram. An explicit `signedZDIso` reorders Fin-indexed signs/indices into the supplied Nat-indexed ZD labels and identifies adjacency, including the reversed-product clause.

The resulting candidate `components_eq_eight_hankel_rank_sub_one` states

\[
\boxed{\operatorname{card}\pi_0(G_{\rm rep}(2^{q+4}))
=8\,\operatorname{rank}H^{\rm rep}_{2^q}(q)-1.}
\]

**Both sides now refer to the same representative graph.** This closes the source-level transport gap left in the previous report. It still depends on the previous uncompiled moment/rank candidates and the supplied uniform connectivity proof; compilation is required before calling the assembled theorem formally verified.

## 2. Explicit dimension-32 model and complete eigenbasis

The witness is the **28-vertex antipodal representative component of ambient XOR charge17**, base charge1, with degree12. It is not the fully signed56-vertex component and not the entire420-vertex cross-half graph.

The ordered vertices are

\[
v_{2(i-2)+b}=e_i+(-1)^{1-b}e_{16+(i\,\mathrm{xor}\,1)},
\quad i=2,\ldots,15,\quad b\in\{0,1\}.
\]

The JSON supplies these labels, adjacency lists, the integer Laplacian L, a complete integer eigenbasis P, its positive column norm squares ν, and the rational inverse `Q=diag(1/ν)Pᵀ`. The verifier checks exactly

\[
LP=P\operatorname{diag}(\lambda),\qquad
P^TP=\operatorname{diag}(\nu),\qquad QP=PQ=I.
\]

There are14 independent twin pairs. Their14-vertex6-regular quotient has adjacency eigenvalues `6¹,3²,2¹,(-1)⁸,(-3)²`. Symmetric lifts give the corresponding Laplacian eigenvalues, while14 antisymmetric twin-pair differences have eigenvalue12. Thus

\[
\chi_L(X)=X(X-6)^2(X-8)(X-12)^{14}(X-14)^8(X-18)^2.
\]

The new Lean data candidate does not merely assert that a table describes the source graph. It defines a decoder into `repGraph 4`, an equivalence onto its charge-one sector, the comapped graph on `Fin 28`, and a candidate equality between its actual integer Laplacian and the supplied matrix. Finite adjacency edges also give explicit spanning walks and a connectedness candidate.

## 3. Gap certificate without conflating the gap APIs

The first column of P is the constant vector. With

\[
w_0=0,\qquad w_j=(\lambda_j-6)/\nu_j\ge0\quad(j>0),
\]

the verifier checks the rational identity

\[
\boxed{L-6I+\frac3{14}J=P\operatorname{diag}(w)P^T.}
\]

It gives, over the reals, `xᵀLx≥6 xᵀx` for every zero-mean x. The supplied second eigenvector is nonzero, zero-mean, and attains quotient6. The variational gap therefore equals6. This argument proves the relevant minimization directly; it does not assume a general equivalence between the two supplied spectral-gap APIs.

`BridgeCert/Dimension32.lean` stages this Gram/positivity argument and the attained-infimum proof `variational_gap_six`, in addition to characteristic-polynomial and projector candidates.

## 4. Explicit zero-eigenspace projector

The normalized degree-five polynomial is

\[
p(t)=1-\frac{253}{504}t+\frac{65}{672}t^2
-\frac{325}{36288}t^3+\frac{29}{72576}t^4-\frac1{145152}t^5.
\]

It is `∏(1−t/λ)` for λ in `{6,8,12,14,18}`. The checked matrix identity is

\[
p(L)=J/28,\qquad\operatorname{tr}p(L)=1.
\]

The new candidate derives the matrix polynomial from the explicit intertwinement `LP=P diag λ`, scalar filter values, and Q. It avoids a naively nested computation of fifth matrix powers. It also gives explicit multiplicities, rather than replacing Mathlib's set-valued spectrum with a multiset.

## 5. New exact isoperimetric profile: h=4

Every cut is determined, for boundary and size, by its occupancies `u₁,…,u₁₄∈{0,1,2}` in the independent twin pairs. If B is the quotient adjacency matrix and `k=∑uᵢ`, its boundary is

\[
|\partial S|=12k-2\sum_{i<j}B_{ij}u_i u_j.
\]

The verifier exhausts **all `3^14=4,782,969` occupancy patterns** using single-coordinate Gray updates. A visited-state bitset checks uniqueness. Each state represents `2^(number of singleton occupancies)` labeled cuts; their counts match `binomial(28,k)` separately at every size, covering **268,435,456 subsets**. Partial twin cells are included—restricting to unions of complete twin pairs would not justify the lower bound.

The exact minimum boundary profile up to half size is:

| k | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13 | 14 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| min boundary | 12 | 22 | 30 | 36 | 42 | 46 | 48 | 48 | 52 | 54 | 56 | 56 | 56 | 56 |

Therefore

\[
\boxed{h=4,\qquad\phi=h/12=1/3.}
\]

An attaining cut has vertex IDs `{0,3,4,7,8,11,12,15,16,19,20,23,24,27}`, size14 and boundary56. Its labels and the full symmetric profile are in the JSON.

**Formal boundary:** the Lean candidates provide the explicit cut upper bound `h≤4` and the easy-Cheeger lower bound `h≥3` from gap6. They do **not** provide a Lean proof of the exhaustive lower bound `h≥4`. Nor does this one component settle the general hard Cheeger inequality.

## 6. Spectral-gap collision: a documented staging patch

In review copies only, RequestProject identifiers beginning with the token `spectralGap` are renamed `variationalGap`, including the affected theorem prefixes. The sorted-eigenvalue `SimpleGraph.spectralGap` in the supplied Sovereign module is left unchanged. References in the copied box-kite/Cheeger branch are updated consistently.

`BridgeCert/GapApiSmoke.lean` imports both APIs and the earlier conditional Cheeger candidate into one target. This repairs the identified declaration-name collision **at source level**; the target has not been elaborated. No theorem claiming general equality of the two definitions has been added. The provenance manifest records original and staged hashes and every copy adjustment.

Source review also found a parenthesization problem in the earlier uncompiled box-kite characteristic-polynomial proof. Its review copy now reassociates `P*(D*Q)` before rewriting with `L=P*D*Q`. This is a targeted source repair, not evidence that the earlier module now compiles.

## 7. Reproduction and remaining gates

The new archive includes the selected dependency closure, review-copy patches, a pinned Lean4 v4.28.0 / Mathlib project, target-specific trust queries, both Python reproducibility files and these results. The main verifier uses only Python's standard library and regenerates the numerical certificate and generated Lean data candidate.

An archive round-trip test passed: the verifier ran from the extracted bundle and regenerated byte-identical Lean data. This checks reproducibility, not Lean correctness.

Run exact checks with `python verify_certificates.py`. On a compatible external Lean machine, run `lake update`, `lake build BridgeCert`, and `lake env lean BridgeCert/TrustInventory.lean`. Build the data-certificate module separately if needed to measure the cost of its kernel-decision leaves. **Do not interpret local import checks, placeholder scans, or Python success as successful Lean elaboration.**

Remaining priorities:

1. Compile and repair the assembled project; obtain actual per-target axiom output.
2. Promote the compressed finite isoperimetric lower-bound check to an appropriate formal certificate, if exact h=4 is needed in Lean.
3. Establish the general variational/sorted-eigenvalue gap equivalence before treating the two APIs interchangeably.
4. Complete the general finite-sweep/coarea hard Cheeger proof. The previous high-gap-only lemma remains conditional.

No upstream submission or general division-algebra/Hankel/expansion index claim was made.
