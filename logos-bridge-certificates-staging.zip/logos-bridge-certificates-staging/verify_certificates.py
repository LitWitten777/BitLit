"""Exact dimension32 certificate and component-transport checks. Standard library only.
No Lean execution. Run beside compute_bridges.py or in the supplied workspace layout.
"""
from pathlib import Path
from fractions import Fraction as F
from collections import defaultdict,Counter,deque
from math import gcd,lcm,comb
from itertools import combinations
import importlib.util,json,time
HERE=Path(__file__).parent
helper=HERE/'compute_bridges.py'
if not helper.exists():helper=HERE.parent/'logos-bridge-development/compute_bridges.py'
s=importlib.util.spec_from_file_location('exact_helpers',helper);b=importlib.util.module_from_spec(s);s.loader.exec_module(b)

def nullspace(A):
 M=[list(map(F,r)) for r in A];n=len(M[0]);piv=[];r=0
 for j in range(n):
  k=next((k for k in range(r,len(M)) if M[k][j]),None)
  if k is None:continue
  M[r],M[k]=M[k],M[r];q=M[r][j];M[r]=[x/q for x in M[r]]
  for k in range(len(M)):
   if k!=r:
    q=M[k][j];M[k]=[x-q*y for x,y in zip(M[k],M[r])]
  piv.append(j);r+=1
  if r==len(M):break
 result=[]
 for j in range(n):
  if j in piv:continue
  v=[F(0)]*n;v[j]=1
  for k,c in enumerate(piv):v[c]=-M[k][j]
  result.append(v)
 return result

def primitive(v):
 den=lcm(*(x.denominator for x in v));w=[int(x*den) for x in v];g=gcd(*w)
 w=[x//g for x in w]
 if next(x for x in w if x)<0:w=[-x for x in w]
 return w

def orthogonal_basis(A):
 out=[]
 for v in nullspace(A):
  for w in out:
   t=sum(x*y for x,y in zip(v,w))/F(sum(x*x for x in w));v=[x-t*y for x,y in zip(v,w)]
  out.append(primitive(v))
 return out

def components(adj):
 rem=set(range(len(adj)));out=[]
 while rem:
  todo=[rem.pop()];cc=set(todo)
  while todo:
   i=todo.pop();ns=adj[i]&rem;rem-=ns;cc|=ns;todo.extend(ns)
  out.append(cc)
 return out

def check_transport():
 count=0;noisolates=0
 for n in range(6):
  pairs=list(combinations(range(n),2))
  for mask in range(1<<len(pairs)):
   a=[set() for _ in range(n)]
   for i,(x,y) in enumerate(pairs):
    if mask>>i&1:a[x].add(y);a[y].add(x)
   c=components(a);iso=sum(not s for s in a)
   for m in [2,3]:
    A=[{m*j+d for j in a[i] for d in range(m)} for i in range(n) for _ in range(m)]
    C=components(A);assert len(C)==len(c)+(m-1)*iso
    label={v:k for k,cc in enumerate(c) for v in cc};lift={v:k for k,cc in enumerate(C) for v in cc}
    for i in range(n*m):
     for j in range(n*m):
      expected=label[i//m]==label[j//m] and (i//m!=j//m or bool(a[i//m]) or i==j)
      assert (lift[i]==lift[j])==expected
   count+=1;noisolates+=iso==0
 assert count==1100
 return {'all_labeled_simple_graphs_on_0_to_5_vertices':count,'without_isolates':noisolates,'blowup_sizes':[2,3],'verified_formula':'c(G[m]) = c(G) + (m-1)*number_of_isolated_vertices(G)','reachability_equivalence_including_isolate_exception':True,'minimal_counterexample':{'base_vertices':1,'base_edges':0,'base_components':1,'twofold_blowup_components':2}}

def exact_cheeger(base,twin_pairs,adj):
 """Visit all 3^14 occupancies once; each represents 2^(number of 1s) labeled cuts."""
 n=len(base);N=2*n;total=3**n;u=[0]*n;direction=[1]*n;ns=[0]*n;k=boundary=ones=code=0
 best=[None]*(N+1);witness=[None]*(N+1);coverage=[0]*(N+1);seen=bytearray((total+7)//8);powers=[3**i for i in range(n)]
 neighbors=[[j for j in range(n) if base[i][j]] for i in range(n)]
 for step in range(total):
  byte,bit=divmod(code,8);assert not (seen[byte]>>bit&1);seen[byte]|=1<<bit
  coverage[k]+=1<<ones
  if best[k] is None or boundary<best[k]:best[k]=boundary;witness[k]=u[:]
  if step==total-1:break
  i=0
  while not 0<=u[i]+direction[i]<=2:direction[i]*=-1;i+=1
  delta=direction[i];boundary+=delta*(12-2*ns[i]);k+=delta;code+=delta*powers[i]
  u[i]+=delta;ones+=1 if u[i]==1 else -1
  for j in neighbors[i]:ns[j]+=delta
 assert sum(coverage)==2**N and coverage==[comb(N,k) for k in range(N+1)]
 assert all(best[k]==best[N-k] for k in range(N+1))
 h=min(F(best[k],k) for k in range(1,n+1));cutsize=next(k for k in range(1,n+1) if F(best[k],k)==h)
 cuts=[twin_pairs[i][:w] for i,w in enumerate(witness[cutsize])];cut=set(v for vs in cuts for v in vs)
 direct=sum(j not in cut for i in cut for j in adj[i]);assert len(cut)==cutsize and direct==best[cutsize]
 assert all(best[k]*h.denominator>=h.numerator*k for k in range(1,n+1))
 return {'exact_h':str(h),'exact_conductance':str(h/12),'twin_occupancy_states_visited':total,'labeled_vertex_subsets_covered':2**N,'coverage_by_size_matches_binomial_coefficients':True,'minimum_boundary_by_size':best,'optimal_cut_vertex_ids':sorted(cut),'optimal_cut_size':cutsize,'optimal_cut_boundary':direct,'proof_status':'exhaustive exact Python enumeration; NOT a Lean proof'}

def lean_vec(xs):return '!['+', '.join(map(str,xs))+']'
def lean_mat(A):return '!['+',\n  '.join(lean_vec(r) for r in A)+']'

def main():
 start=time.time();transport=check_transport();print('All 1100 finite-graph transport checks passed.',flush=True)
 vs=[(i,16+(i^1),sgn) for i in range(2,16) for sgn in [-1,1]]
 adj=[{j for j,y in enumerate(vs) if b.vanishes(5,x,y)} for x in vs]
 assert all(len(s)==12 for s in adj) and len(components(adj))==1
 assert all((j in adj[i])==(i in adj[j]) for i in range(28) for j in range(28))
 twins=defaultdict(list)
 for i in range(28):twins[tuple(sorted(adj[i]))].append(i)
 twins=list(twins.values());assert len(twins)==14 and all(len(t)==2 for t in twins)
 B=[[int(twins[j][0] in adj[twins[i][0]]) for j in range(14)] for i in range(14)]
 assert all(sum(row)==6 for row in B)
 for i in range(14):
  for j in range(14):
   for x in twins[i]:
    for y in twins[j]:assert int(y in adj[x])==B[i][j]
 eig=[];cols=[]
 for mu,mul in [(6,1),(3,2),(2,1)]:
  basis=orthogonal_basis([[B[i][j]-mu*int(i==j) for j in range(14)] for i in range(14)])
  assert len(basis)==mul
  for v in basis:
   w=[0]*28
   for i,pair in enumerate(twins):
    for j in pair:w[j]=v[i]
   cols.append(w);eig.append(12-2*mu)
 for pair in twins:
  v=[0]*28;v[pair[0]]=1;v[pair[1]]=-1;cols.append(v);eig.append(12)
 for mu,mul in [(-1,8),(-3,2)]:
  basis=orthogonal_basis([[B[i][j]-mu*int(i==j) for j in range(14)] for i in range(14)])
  assert len(basis)==mul
  for v in basis:
   w=[0]*28
   for i,pair in enumerate(twins):
    for j in pair:w[j]=v[i]
   cols.append(w);eig.append(12-2*mu)
 P=b.transpose(cols);norm=[sum(x*x for x in col) for col in cols]
 L=[[12*int(i==j)-int(j in adj[i]) for j in range(28)] for i in range(28)]
 I=[[int(i==j) for j in range(28)] for i in range(28)];D=[[eig[i]*int(i==j) for j in range(28)] for i in range(28)]
 assert b.matmul(b.transpose(P),P)==[[norm[i]*int(i==j) for j in range(28)] for i in range(28)]
 assert b.matmul(L,P)==b.matmul(P,D)
 Q=[[F(P[j][i],norm[i]) for j in range(28)] for i in range(28)]
 assert b.matmul(P,Q)==b.matmul(Q,P)==I
 assert cols[0]==[1]*28 and eig[0]==0 and all(x>=6 for x in eig[1:])
 weights=[F(0) if i==0 else F(eig[i]-6,norm[i]) for i in range(28)]
 C=[[F(L[i][j]-6*I[i][j])+F(3,14) for j in range(28)] for i in range(28)]
 assert all(weights[i]>=0 for i in range(28))
 assert b.matmul(b.matmul(P,[[weights[i]*int(i==j) for j in range(28)] for i in range(28)]),b.transpose(P))==C
 v6=cols[1];assert sum(v6)==0 and any(v6)
 assert b.matmul(L,[[x] for x in v6])==[[6*x] for x in v6]
 poly=b.charpoly(L);factors,rem=b.factor_integer_roots(poly,[0,6,8,12,14,18]);assert rem==[1]
 z=I
 for lam in [6,8,12,14,18]:z=b.matmul(z,[[lam*I[i][j]-L[i][j] for j in range(28)] for i in range(28)])
 assert z==[[5184]*28 for _ in range(28)]
 print('28-column exact eigenbasis, inverse, gap lower Gram and projector passed.',flush=True)
 cut=exact_cheeger(B,twins,adj);print('Exhaustive Cheeger result:',cut['exact_h'],'cut size',cut['optimal_cut_size'],'boundary',cut['optimal_cut_boundary'],flush=True)
 coeff=[F(1)]
 for lam in [6,8,12,14,18]:
  nxt=[F(0)]*(len(coeff)+1)
  for i,x in enumerate(coeff):nxt[i]+=x;nxt[i+1]-=x/F(lam)
  coeff=nxt
 data={'zero_projector_coefficients_ascending_rational_strings':list(map(str,coeff)),'evidence':'Exact standard-library Python verification; NO Lean compilation', 'ambient_dimension':32,'base_charge':1,'ambient_charge':17,'degree':12,'vertices_0_based':vs,'adjacency_lists':list(map(sorted,adj)),'twin_pairs':twins,'twin_base_adjacency':B,'laplacian':L,'eigenvalues_with_multiplicity':eig,'eigenbasis_P_integer':P,'column_norm_squares':norm,'inverse_Q_rational_strings':[[str(x) for x in r] for r in Q],'gap_lower_gram_weights_rational_strings':list(map(str,weights)),'gap_lower_gram_identity':'L - 6 I + (3/14) J = P diag(weights) P^T','zero_mean_gap_witness':v6,'charpoly_coefficients_descending':poly,'eigenvalue_multiplicities':factors,'zero_projector':'Product(lambda I-L), lambda in {6,8,12,14,18}, = 5184 J; normalized projector J/28','component_transport_checks':transport,'cheeger':cut,'elapsed_seconds':round(time.time()-start,3)}
 (HERE/'dimension32-certificate.json').write_text(json.dumps(data,indent=2)+'\n')
 stage=(HERE if (HERE/'lakefile.toml').exists() else HERE/'staging')/'BridgeCert'
 stage.mkdir(parents=True,exist_ok=True)
 content='''/-
UNCOMPILED generated candidate. Integer/rational finite certificates, NOT executed by Lean.
Every generated leaf uses kernel decide (no native_decide); cost is unmeasured.
The Python producer checks all numerical identities before writing this source.
-/
import BridgeNext.AntipodalGraphs

set_option maxHeartbeats 0
set_option maxRecDepth 100000

noncomputable section

namespace BridgeCert.Dimension32Data
open Matrix Sovereign BridgeNext.AntipodalGraphs

def lower (a : Fin 28) : ℕ := a.val / 2 + 2
def upper (a : Fin 28) : ℕ := (lower a) ^^^ 1

def decode (a : Fin 28) : RepVertex 4 :=
  (⟨(lower a,upper a), by fin_cases a <;> decide +kernel⟩,decide (a.val % 2 = 0))

def chargeOne := {v : RepVertex 4 // v.1.1.1 ^^^ v.1.1.2 = 1}
def decodeSector (a : Fin 28) : chargeOne :=
  ⟨decode a, by fin_cases a <;> decide +kernel⟩

lemma decodeSector_bijective : Function.Bijective decodeSector := by decide +kernel

def sectorEquiv : Fin 28 ≃ chargeOne := Equiv.ofBijective decodeSector decodeSector_bijective

def graph : SimpleGraph (Fin 28) := (repGraph 4).comap decode
instance : DecidableRel graph.Adj := fun _ _ => inferInstance

def sectorGraph : SimpleGraph chargeOne := (repGraph 4).comap Subtype.val

def sectorIso : graph ≃g sectorGraph where
  toEquiv := sectorEquiv
  map_rel_iff' := by intro a b; rfl

def LZ : Matrix (Fin 28) (Fin 28) ℤ := __L__
def PZ : Matrix (Fin 28) (Fin 28) ℤ := __P__
def eigenZ : Fin 28 → ℤ := __E__
def normZ : Fin 28 → ℤ := __N__

def L : Matrix (Fin 28) (Fin 28) ℚ := LZ.map (Int.castRingHom ℚ)
def P : Matrix (Fin 28) (Fin 28) ℚ := PZ.map (Int.castRingHom ℚ)
def eigen : Fin 28 → ℚ := fun i => (eigenZ i : ℚ)
def Q : Matrix (Fin 28) (Fin 28) ℚ := fun i j => (PZ j i : ℚ) / (normZ i : ℚ)
def weight : Fin 28 → ℚ := fun i => if i = 0 then 0 else (eigen i - 6) / normZ i

def LR : Matrix (Fin 28) (Fin 28) ℝ := LZ.map (Int.castRingHom ℝ)
def PR : Matrix (Fin 28) (Fin 28) ℝ := PZ.map (Int.castRingHom ℝ)
def weightR : Fin 28 → ℝ := fun i => (weight i : ℝ)
def JR : Matrix (Fin 28) (Fin 28) ℝ := fun _ _ => 1

lemma lap_int : graph.lapMatrix ℤ = LZ := by decide +kernel
lemma regular : ∀ a, graph.degree a = 12 := by decide +kernel
lemma eigen_relation : LZ * PZ = PZ * Matrix.diagonal eigenZ := by decide +kernel
lemma orthogonal : PZᵀ * PZ = Matrix.diagonal normZ := by decide +kernel
lemma norms_positive : ∀ i, 0 < normZ i := by decide +kernel
lemma QP : Q * P = 1 := by decide +kernel
lemma PQ : P * Q = 1 := by decide +kernel
lemma LP : L * P = P * Matrix.diagonal eigen := by decide +kernel
lemma weight_nonneg : ∀ i, 0 ≤ weight i := by decide +kernel

/-- Entrywise leaf avoids an exponentially nested matrix-polynomial reduction. -/
lemma lower_gram_entry : ∀ i j,
    L i j - (if i = j then 6 else 0) + (3/14 : ℚ) =
      ∑ k, P i k * weight k * P j k := by decide +kernel

lemma witness_mean_Z : (∑ i, PZ i 1) = 0 := by decide +kernel
lemma witness_eigen_Z : ∀ i, (∑ j, LZ i j * PZ j 1) = 6 * PZ i 1 := by decide +kernel
lemma witness_nonzero_Z : PZ __NZ__ 1 ≠ 0 := by decide +kernel

def projectorCoeffs : List ℚ := __COEFF__
lemma filter_values : ∀ i, Sovereign.Graph.hornerS (eigen i) projectorCoeffs =
    if i = 0 then 1 else 0 := by decide +kernel
lemma projector_entry : ∀ i j,
    (∑ k, P i k * (if k = 0 then 1 else 0) * Q k j) = (1/28 : ℚ) := by decide +kernel

def cut : Finset (Fin 28) := {__CUT__}
lemma cut_card : cut.card = __K__ := by decide +kernel
lemma cut_boundary : graph.edgeBoundary cut = __BOUNDARY__ := by decide +kernel

end BridgeCert.Dimension32Data
'''
 # edgeBoundary belongs to the review-copy expansion API, not Mathlib alone.
 content=content.replace('import BridgeNext.AntipodalGraphs\n','import BridgeNext.AntipodalGraphs\nimport RequestProject.Expansion\nimport Sovereign.Graph.HermitianCertificate\n')
 for key,val in {'__L__':lean_mat(L),'__P__':lean_mat(P),'__E__':lean_vec(eig),'__N__':lean_vec(norm),'__NZ__':str(next(i for i,x in enumerate(v6) if x)),'__CUT__':', '.join(map(str,cut['optimal_cut_vertex_ids'])),'__K__':str(cut['optimal_cut_size']),'__BOUNDARY__':str(cut['optimal_cut_boundary']),'__COEFF__':'['+', '.join('('+str(x)+')' for x in coeff)+']'}.items():content=content.replace(key,val)
 parent={0:None};todo=deque([0])
 while todo:
  i=todo.popleft()
  for j in sorted(adj[i]):
   if j not in parent:parent[j]=i;todo.append(j)
 lines=['lemma reachable_from_zero (a : Fin 28) : graph.Reachable 0 a := by','  fin_cases a','  · exact SimpleGraph.Reachable.refl _']
 for i in range(1,28):
  path=[i]
  while path[-1]!=0:path.append(parent[path[-1]])
  path.reverse()
  exprs=['(show graph.Adj ('+str(a)+' : Fin 28) ('+str(z)+' : Fin 28) from by decide +kernel).reachable' for a,z in zip(path,path[1:])]
  expr=exprs[-1]
  for x in reversed(exprs[:-1]):expr='('+x+').trans ('+expr+')'
  lines.append('  · exact '+expr)
 lines+=['','theorem connected : graph.Connected :=','  ⟨fun u v => (reachable_from_zero u).symm.trans (reachable_from_zero v)⟩','']
 content=content.replace('end BridgeCert.Dimension32Data','\n'.join(lines)+'\nend BridgeCert.Dimension32Data')
 (stage/'Dimension32Data.lean').write_text(content)
 print('All exact checks passed in',round(time.time()-start,2),'seconds; norms',norm,flush=True)
if __name__=='__main__':main()
