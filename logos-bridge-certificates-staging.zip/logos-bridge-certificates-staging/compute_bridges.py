"""Exact bounded checks for specified primitive Cayley-Dickson graph families.
Standard library only; no Lean compilation or floating-point eigenvalue claims.
Run: python user/workspace/co-scientist-outputs/logos-bridge-development/compute_bridges.py
"""
from collections import Counter, defaultdict
from fractions import Fraction as F
from functools import lru_cache
from pathlib import Path
import json
OUT = Path(__file__).parent

@lru_cache(None)
def basis_sign(n, i, j):
    if n == 0: return 1
    h=1<<(n-1); a=i>=h; b=j>=h; u=i%h; v=j%h
    if not a and not b: return basis_sign(n-1,u,v)
    if not a and b: return basis_sign(n-1,v,u)
    if a and not b: return (1 if v==0 else -1)*basis_sign(n-1,u,v)
    return -(1 if v==0 else -1)*basis_sign(n-1,v,u)

def vanishes(n, x, y):
    # x=(i,j,s) encodes e_i+s*e_j, i<j and first coefficient +1.
    i,j,s=x; k,l,t=y; z=defaultdict(int)
    for a,u in [(i,1),(j,s)]:
        for b,v in [(k,1),(l,t)]: z[a^b]+=u*v*basis_sign(n,a,b)
    return all(v==0 for v in z.values())

def graph(n, family):
    D=1<<n; verts=[(i,j,s) for i in range(1,D) for j in range(i+1,D)
                    for s in [-1,1] if family=='all_primitive' or i<D//2<j]
    # Necessary product-cancellation condition: XOR charges match.
    charges=defaultdict(list)
    for v in verts: charges[v[0]^v[1]].append(v)
    adj={v:set() for v in verts}
    for vs in charges.values():
        for a,x in enumerate(vs):
            for y in vs[a+1:]:
                xy=vanishes(n,x,y); yx=vanishes(n,y,x)
                assert xy==yx
                if xy: adj[x].add(y); adj[y].add(x)
    active=[v for v in verts if adj[v]]; pending=set(active); comps=[]
    while pending:
        todo=[pending.pop()]; comp=[]
        while todo:
            v=todo.pop(); comp.append(v)
            ns=adj[v]&pending; pending-=ns; todo.extend(ns)
        comps.append(sorted(comp))
    comps.sort(key=lambda c:(c[0][0]^c[0][1],c[0]))
    summaries=[]
    for c in comps:
        deg=Counter(len(adj[v]) for v in c)
        summaries.append({'charge':c[0][0]^c[0][1],'vertices':len(c),
            'edges':sum(len(adj[v]) for v in c)//2,
            'degree_histogram':dict(sorted(deg.items()))})
    return {'ambient_dimension':D,'family':family,'candidate_representatives':len(verts),
      'active_vertices':len(active),'edges':sum(len(adj[v]) for v in active)//2,
      'degree_histogram':dict(sorted(Counter(len(adj[v]) for v in active).items())),
      'component_count':len(comps),'components':summaries}, adj, comps

def matmul(A,B):
    return [[sum(x*y for x,y in zip(row,col)) for col in zip(*B)] for row in A]
def transpose(A): return list(map(list,zip(*A)))
def rank(A):
    B=[list(map(F,row)) for row in A]; r=0
    if not B: return 0
    for c in range(len(B[0])):
        p=next((i for i in range(r,len(B)) if B[i][c]),None)
        if p is None: continue
        B[r],B[p]=B[p],B[r]; q=B[r][c]; B[r]=[x/q for x in B[r]]
        for i in range(len(B)):
            if i!=r:
                q=B[i][c]; B[i]=[a-q*b for a,b in zip(B[i],B[r])]
        r+=1
    return r

def charpoly(A):
    # Fraction-free Faddeev-LeVerrier over integers; coefficients descending.
    n=len(A); B=[[int(i==j) for j in range(n)] for i in range(n)]; coeff=[1]
    for k in range(1,n+1):
        B=matmul(A,B); tr=sum(B[i][i] for i in range(n)); assert tr%k==0
        c=-tr//k; coeff.append(c)
        for i in range(n):B[i][i]+=c
    assert all(x==0 for row in B for x in row)
    return coeff

def factor_integer_roots(coeff, candidates):
    coeff=coeff[:]; factors={}
    for a in candidates:
        count=0
        while len(coeff)>1:
            out=[coeff[0]]
            for c in coeff[1:]:out.append(c+a*out[-1])
            if out[-1]:break
            coeff=out[:-1];count+=1
        if count:factors[a]=count
    return factors,coeff

def census(q):
    if q==0:return [42]
    c=census(q-1); out=[]
    for t in range(1<<q):
        if t%2: out.append(2*c[t//2]+(6*((1<<(q+2))-1) if t==(1<<q)-1 else 0))
        else:out.append(2*c[(1<<(q-1))-1-t//2])
    return out

def moments(weights, xs, k):return [sum(w*x**j for w,x in zip(weights,xs)) for j in range(k+1)]

def box_basis():
    # Rows ordered (a,false),(a,true), a=0,...,5, matching Fin6 x Bool.
    base=[[1]*6,[1,-1,0,1,-1,0],[1,1,-2,1,1,-2],
          [1,0,0,-1,0,0],[0,1,0,0,-1,0],[0,0,1,0,0,-1]]
    specs=[(0,1,0),(1,-1,2),(2,-1,2),
      (3,1,4),(4,1,4),(5,1,4),(3,-1,4),(4,-1,4),(5,-1,4),
      (1,1,6),(2,1,6),(0,-1,8)]
    P=[[base[k][a]*(1 if not b else e) for k,e,_ in specs] for a in range(6) for b in [False,True]]
    A=[[int(b!=d and a%3!=c%3) for c in range(6) for d in [False,True]] for a in range(6) for b in [False,True]]
    L=[[4*int(i==j)-A[i][j] for j in range(12)] for i in range(12)]
    gram=matmul(transpose(P),P); norms=[gram[i][i] for i in range(12)]
    assert all(gram[i][j]==(norms[i] if i==j else 0) for i in range(12) for j in range(12))
    assert all(d>0 for d in norms)
    eig=[lam for _,_,lam in specs]; LP=matmul(L,P)
    assert all(LP[i][j]==eig[j]*P[i][j] for i in range(12) for j in range(12))
    Q=[[F(P[j][i],norms[i]) for j in range(12)] for i in range(12)]
    assert matmul(Q,P)==matmul(P,Q)==[[int(i==j) for j in range(12)] for i in range(12)]
    Z=[[int(i==j) for j in range(12)] for i in range(12)]
    for lam in [2,4,6,8]:Z=matmul(Z,[[L[i][j]-lam*int(i==j) for j in range(12)] for i in range(12)])
    assert Z==[[32]*12 for _ in range(12)]
    spectral=[sum(lam**k for lam in eig) for k in range(11)]
    projector_coeff=[F(1),F(-25,24),F(35,96),F(-5,96),F(1,384)]
    assert sum(c*m for c,m in zip(projector_coeff,spectral))==1
    return {'spectral_moments_0_to_4':spectral[:5],
      'seven_box_kite_spectral_moments_0_to_4':[7*m for m in spectral[:5]],
      'spectral_moment_Hankel_ranks_1_to_6':[rank([[spectral[i+j] for j in range(m)] for i in range(m)]) for m in range(1,7)],
      'zero_projector_coefficients_ascending':[str(c) for c in projector_coeff],
      'zero_projector_identity':'(L-2I)(L-4I)(L-6I)(L-8I) = 32 J; P0 = J/12',
      'eigenvalues_with_multiplicity':eig,'orthogonal_basis_column_norm_squares':norms,
      'eigenbasis_P':P,'charpoly_factorization':'X*(X-2)^2*(X-4)^6*(X-6)^2*(X-8)',
      'verification':'exact LP=P diag(lambda), P^T P positive diagonal, QP=PQ=I over Q'}, P, Q

def main():
    allgraphs=[]; bridge=[]; witnesses=[]
    for n in [4,5,6]:
        for fam in (['cross_half','all_primitive'] if n < 6 else ['cross_half']):
            g,adj,comps=graph(n,fam)
            gm_all=[sum(len(adj[v])**k for v in adj if adj[v]) for k in range(7)]
            g['degree_moment_Hankel_ranks_1_to_4']=[rank([[gm_all[i+j] for j in range(m)] for i in range(m)]) for m in range(1,5)]
            a,b,c,d,e=gm_all[:5]
            g['degree_moment_H2']=a*(c*e-d*d)-b*(b*e-c*d)+c*(b*d-c*c)
            allgraphs.append(g)
            if fam=='cross_half':
                q=n-4; c=census(q); v=[8*t+4 for t in range(len(c))]
                cm=moments(c,v,6)
                gm=[sum(len(adj[x])**k for x in adj if adj[x]) for k in range(7)]
                # Antipodal quotient: half the signed vertices AND half the degree.
                assert all(gm[k]==2*cm[k] for k in range(7))
                bridge.append({'ambient_dimension':1<<n,'half_dimension':1<<(n-1),
                  'census_moments_0_to_6':cm,'representative_graph_moments_0_to_6':gm,
                  'antipodal_representative_scale':'2 (all moment orders)', 'fully_signed_scale':'4*2^k',
                  'degree_moment_Hankel_ranks_1_to_3':[rank([[gm[i+j] for j in range(m)] for i in range(m)]) for m in [1,2,3]]})
                if n > 5:
                    continue  # D=64 checks the shifted moment bridge, not a new spectrum claim.
                c0=comps[0]
                # Exact rational elimination: connected component Laplacian kernel dimension1.
                L=[[len(adj[x])*int(x==y)-int(y in adj[x]) for y in c0] for x in c0]
                rr=rank(L);assert rr==len(c0)-1
                poly=charpoly(L); factors,residual=factor_integer_roots(poly,[0,2,4,6,8,10,12,14,16,18,20,24])
                assert residual==[1]
                gap=min(a for a in factors if a>0)
                witnesses.append({'ambient_dimension':1<<n,'charge':g['components'][0]['charge'],
                  'component_vertices':len(c0),'rational_laplacian_rank':rr,
                  'exact_charpoly_coefficients_descending':poly,
                  'exact_eigenvalue_multiplicities':factors,'exact_gap':gap,
                  'verification':'integer Faddeev-LeVerrier with exact divisions, synthetic factorization, rational kernel rank'})
                if n==5:
                    assert factors=={0:1,6:2,8:1,12:14,14:8,18:2}
                    # Independent full all-pairs check validates the XOR-based pruning.
                    vv=list(adj)
                    for i,x in enumerate(vv):
                        for y in vv[i+1:]:assert vanishes(n,x,y)==(y in adj[x])
    spec,P,Q=box_basis()
    result={'verification':'Python exact finite checks; not Lean compilation',
       'graphs':allgraphs,'cross_half_moment_bridge_checks':bridge,
       'box_kite_structural_eigenbasis':spec,'positive_gap_witnesses':witnesses}
    (OUT/'bridge-results.json').write_text(json.dumps(result,indent=2)+'\n')
    for g in allgraphs:print(g['ambient_dimension'],g['family'],g['active_vertices'],'vertices',g['edges'],'edges',g['component_count'],'components',g['degree_histogram'])
    print('Exact component gaps:',[(w['ambient_dimension'],w['charge'],w['exact_gap']) for w in witnesses])
if __name__=='__main__': main()
