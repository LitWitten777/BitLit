module

public import RequestProject.Sedenion
meta import RequestProject.Sedenion
meta import Mathlib

@[expose] public section

/-!
# The graph of primitive sedenion zero divisors

A *primitive* sedenion is one of the form `e i ± e j` with `1 ≤ i < j ≤ 15`
(indexed by triples `(i, j, s)`, where `s = true` means `+` and `s = false` means `-`).

We show that such an element is a (two-sided) zero divisor inside this family exactly when
`1 ≤ i ≤ 7`, `9 ≤ j ≤ 15` and `j ≠ i + 8` (de Marrais' "assessors"), giving 84 zero divisors.
The *zero-divisor graph* `zdGraph` has these 84 elements as vertices, two of them being adjacent
when their product vanishes.

Each vertex has a *strut constant* `strut v = (i xor j) - 8 ∈ {1, …, 7}`, and we show that two
vertices lie in the same connected component iff they have the same strut constant.  Each
component (a *box-kite*) is isomorphic to the bipartite double cover of the octahedron.
-/

open Sedenion

/-- Indices `(i, j, s)` of the primitive element `e i + (±1) e j`. -/
abbrev PrimIdx : Type := Fin 16 × Fin 16 × Bool

/-- The sedenion `e i + e j` (if `s = true`) or `e i - e j` (if `s = false`). -/
def primElt (p : PrimIdx) : Sedenion :=
  Sedenion.ofFn (fun k => if k = p.1 then 1 else if k = p.2.1 then (if p.2.2 then 1 else -1) else 0)

/-- `(i, j, s)` indexes a primitive element: `1 ≤ i < j ≤ 15`. -/
def IsPrimitive (p : PrimIdx) : Prop := 0 < p.1.val ∧ p.1.val < p.2.1.val

instance : DecidablePred IsPrimitive := fun _ => inferInstanceAs (Decidable (_ ∧ _))

/-- De Marrais' assessor condition: `1 ≤ i ≤ 7`, `9 ≤ j ≤ 15`, `j ≠ i + 8`. -/
def IsAssessor (p : PrimIdx) : Prop :=
  1 ≤ p.1.val ∧ p.1.val ≤ 7 ∧ 9 ≤ p.2.1.val ∧ p.2.1.val ≠ p.1.val + 8

instance : DecidablePred IsAssessor := fun _ => inferInstanceAs (Decidable (_ ∧ _ ∧ _ ∧ _))

/-- **Classification of primitive zero divisors.**  A primitive sedenion `e i ± e j` is
annihilated by some primitive sedenion iff `(i, j)` is an assessor pair. -/
theorem exists_primitive_zero_product_iff (p : PrimIdx) (hp : IsPrimitive p) :
    (∃ q : PrimIdx, IsPrimitive q ∧ primElt p * primElt q = 0) ↔ IsAssessor p := by
  revert p
  native_decide

/-- The vertices of the zero-divisor graph: the 84 primitive zero divisors. -/
abbrev ZDVertex : Type := {p : PrimIdx // IsAssessor p}

theorem card_zdVertex : Fintype.card ZDVertex = 84 := by native_decide

lemma zd_mul_eq_zero_symm :
    ∀ u v : ZDVertex, primElt u.1 * primElt v.1 = 0 → primElt v.1 * primElt u.1 = 0 := by
  native_decide

/-- The zero-divisor graph of the primitive sedenion zero divisors: `u ~ v` iff `u * v = 0`
(which, as we show, is equivalent to `v * u = 0`). -/
def zdGraph : SimpleGraph ZDVertex where
  Adj u v := u ≠ v ∧ primElt u.1 * primElt v.1 = 0
  symm := fun u v h => ⟨h.1.symm, zd_mul_eq_zero_symm u v h.2⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

instance : DecidableRel zdGraph.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∧ _))

/-- Adjacent vertices really are zero divisors: the product vanishes in both orders. -/
theorem zdGraph_adj_iff (u v : ZDVertex) :
    zdGraph.Adj u v ↔ u ≠ v ∧ primElt u.1 * primElt v.1 = 0 := Iff.rfl

/-- The zero-divisor graph is 4-regular. -/
theorem zdGraph_degree (v : ZDVertex) : zdGraph.degree v = 4 := by
  revert v; native_decide

/-- The zero-divisor graph has 168 edges. -/
theorem zdGraph_card_edgeFinset : zdGraph.edgeFinset.card = 168 := by
  have h := zdGraph.sum_degrees_eq_twice_card_edges
  simp only [zdGraph_degree, Finset.sum_const, Finset.card_univ, card_zdVertex, smul_eq_mul] at h
  omega

/-- The strut constant `(i xor j) - 8` of a vertex (it lies in `{1, …, 7}`). -/
def strut (v : ZDVertex) : ℕ := (v.1.1.val ^^^ v.1.2.1.val) - 8

theorem strut_mem (v : ZDVertex) : 1 ≤ strut v ∧ strut v ≤ 7 := by
  revert v; native_decide

lemma strut_eq_of_adj : ∀ u v : ZDVertex, zdGraph.Adj u v → strut u = strut v := by
  native_decide

/-! ### The box-kite model graph -/

/-- The *box-kite graph*: the bipartite double cover of the octahedron `K_{2,2,2}`.
Octahedron vertices are `Fin 6`, with `a` and `a + 3` opposite (i.e. `a ~ c ↔ a % 3 ≠ c % 3`);
the `Bool` coordinate is the side of the double cover. -/
def boxKiteGraph : SimpleGraph (Fin 6 × Bool) where
  Adj x y := x.2 ≠ y.2 ∧ x.1.val % 3 ≠ y.1.val % 3
  symm := fun _ _ h => ⟨h.1.symm, h.2.symm⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

instance : DecidableRel boxKiteGraph.Adj := fun _ _ => inferInstanceAs (Decidable (_ ∧ _))

lemma boxKiteGraph_dist_le_three : ∀ x y : Fin 6 × Bool, x = y ∨ boxKiteGraph.Adj x y ∨
    (∃ z, boxKiteGraph.Adj x z ∧ boxKiteGraph.Adj z y) ∨
    (∃ z w, boxKiteGraph.Adj x z ∧ boxKiteGraph.Adj z w ∧ boxKiteGraph.Adj w y) := by
  decide

theorem boxKiteGraph_connected : boxKiteGraph.Connected := by
  rw [SimpleGraph.connected_iff]
  refine ⟨fun x y => ?_, inferInstance⟩
  rcases boxKiteGraph_dist_le_three x y with h | h | ⟨z, h1, h2⟩ | ⟨z, w, h1, h2, h3⟩
  · subst h; rfl
  · exact h.reachable
  · exact h1.reachable.trans h2.reachable
  · exact (h1.reachable.trans h2.reachable).trans h3.reachable

/-! ### The seven box-kites -/

/-- For each strut constant `k + 1` (`k : Fin 7`), the six assessors of the corresponding
box-kite, listed so that `a` and `a + 3` are opposite (the "struts" of the box-kite). -/
def boxKiteTable : Fin 7 → Fin 6 → PrimIdx
  | 0 => ![(2, 11, true), (4, 13, true), (6, 15, false), (3, 10, false), (5, 12, false),
          (7, 14, true)]
  | 1 => ![(1, 11, true), (4, 14, false), (5, 15, false), (3, 9, false), (6, 12, true),
          (7, 13, true)]
  | 2 => ![(1, 10, true), (4, 15, true), (5, 14, false), (2, 9, false), (7, 12, false),
          (6, 13, true)]
  | 3 => ![(1, 13, true), (2, 14, true), (3, 15, true), (5, 9, false), (6, 10, false),
          (7, 11, false)]
  | 4 => ![(1, 12, true), (2, 15, false), (3, 14, true), (4, 9, false), (7, 10, true),
          (6, 11, false)]
  | 5 => ![(1, 15, true), (2, 12, true), (3, 13, false), (7, 9, false), (4, 10, false),
          (5, 11, true)]
  | 6 => ![(1, 14, true), (2, 13, false), (3, 12, false), (6, 9, false), (5, 10, true),
          (4, 11, true)]

/-- The index of the vertex of box-kite `k` corresponding to the model vertex `x`
(the `Bool` coordinate of the model flips the sign). -/
def boxKiteIdx (k : Fin 7) (x : Fin 6 × Bool) : PrimIdx :=
  ((boxKiteTable k x.1).1, (boxKiteTable k x.1).2.1, xor (boxKiteTable k x.1).2.2 x.2)

lemma boxKiteIdx_isAssessor : ∀ k x, IsAssessor (boxKiteIdx k x) := by decide

/-- The vertex set of the `k`-th box-kite: the vertices of strut constant `k + 1`. -/
abbrev boxKiteSet (k : Fin 7) : Set ZDVertex := {v | strut v = k.val + 1}

/-- The embedding of the model into the zero-divisor graph as the `k`-th box-kite. -/
def boxKiteMap (k : Fin 7) (x : Fin 6 × Bool) : boxKiteSet k :=
  ⟨⟨boxKiteIdx k x, boxKiteIdx_isAssessor k x⟩, by revert k x; native_decide⟩

lemma boxKiteMap_bijective (k : Fin 7) : Function.Bijective (boxKiteMap k) := by
  constructor
  · intro x y h
    have h' : boxKiteIdx k x = boxKiteIdx k y := congrArg (fun v => v.1.1) h
    revert k x y
    native_decide
  · rintro ⟨v, hv⟩
    have key : ∀ k : Fin 7, ∀ v : ZDVertex, strut v = k.val + 1 →
        ∃ x, boxKiteIdx k x = v.1 := by native_decide
    obtain ⟨x, hx⟩ := key k v hv
    exact ⟨x, Subtype.ext (Subtype.ext hx)⟩

lemma boxKiteMap_adj_iff : ∀ (k : Fin 7) (x y : Fin 6 × Bool),
    zdGraph.Adj (boxKiteMap k x).1 (boxKiteMap k y).1 ↔ boxKiteGraph.Adj x y := by
  native_decide

/-- **Each box-kite component is the bipartite double cover of the octahedron.** -/
noncomputable def boxKiteIso (k : Fin 7) : boxKiteGraph ≃g zdGraph.induce (boxKiteSet k) where
  toEquiv := Equiv.ofBijective (boxKiteMap k) (boxKiteMap_bijective k)
  map_rel_iff' := by
    intro x y
    simp only [Equiv.ofBijective_apply]
    exact boxKiteMap_adj_iff k x y

/-- **Connected components of the zero-divisor graph.**  Two primitive zero divisors are
connected by a path iff they have the same strut constant. -/
theorem zdGraph_reachable_iff (u v : ZDVertex) :
    zdGraph.Reachable u v ↔ strut u = strut v := by
  constructor
  · rintro ⟨p⟩
    induction p with
    | nil => rfl
    | cons h _ ih => exact (strut_eq_of_adj _ _ h).trans ih
  · intro huv
    obtain ⟨h1, h7⟩ := strut_mem u
    set k : Fin 7 := ⟨strut u - 1, by omega⟩
    have hu : u ∈ boxKiteSet k := by simp [boxKiteSet, k]; omega
    have hv : v ∈ boxKiteSet k := by simp [boxKiteSet, k]; omega
    obtain ⟨x, hx⟩ := (boxKiteMap_bijective k).2 ⟨u, hu⟩
    obtain ⟨y, hy⟩ := (boxKiteMap_bijective k).2 ⟨v, hv⟩
    have hr : (zdGraph.induce (boxKiteSet k)).Reachable ⟨u, hu⟩ ⟨v, hv⟩ := by
      rw [← hx, ← hy]
      exact (boxKiteGraph_connected.preconnected x y).map (boxKiteIso k).toHom
    exact hr.map (SimpleGraph.Embedding.induce (boxKiteSet k)).toHom

/-- The zero-divisor graph is **not** connected. -/
theorem zdGraph_not_connected : ¬ zdGraph.Connected := by
  intro h
  have hr := h.preconnected (⟨(1, 10, true), by decide⟩ : ZDVertex) ⟨(1, 11, true), by decide⟩
  rw [zdGraph_reachable_iff] at hr
  revert hr
  decide

/-- The zero-divisor graph has exactly 7 connected components (the 7 box-kites). -/
theorem zdGraph_card_connectedComponent : Nat.card zdGraph.ConnectedComponent = 7 := by
  let f : zdGraph.ConnectedComponent → Fin 7 :=
    SimpleGraph.ConnectedComponent.lift (fun v => (⟨strut v - 1, by have := strut_mem v; omega⟩ : Fin 7))
      (fun v w p _ => by
        have := (zdGraph_reachable_iff v w).1 ⟨p⟩
        simp [this])
  have hf : Function.Bijective f := by
    constructor
    · intro c d hcd
      induction c using SimpleGraph.ConnectedComponent.ind with | h v => ?_
      induction d using SimpleGraph.ConnectedComponent.ind with | h w => ?_
      simp only [f, SimpleGraph.ConnectedComponent.lift_mk, Fin.mk.injEq] at hcd
      apply SimpleGraph.ConnectedComponent.sound
      rw [zdGraph_reachable_iff]
      have := strut_mem v; have := strut_mem w
      omega
    · intro k
      obtain ⟨v, hv⟩ := boxKiteMap k (0, false)
      refine ⟨zdGraph.connectedComponentMk v, ?_⟩
      simp only [f, SimpleGraph.ConnectedComponent.lift_mk]
      ext
      simp only [boxKiteSet, Set.mem_setOf_eq] at hv
      simp [hv]
  rw [Nat.card_eq_of_bijective f hf, Nat.card_eq_fintype_card, Fintype.card_fin]
