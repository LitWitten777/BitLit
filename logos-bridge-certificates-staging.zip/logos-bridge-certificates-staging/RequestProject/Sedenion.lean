module

public import Mathlib

@[expose] public section

/-!
# The sedenions via the Cayley–Dickson construction

We build the Cayley–Dickson tower `ℤ, ℂ_ℤ, ℍ_ℤ, 𝕆_ℤ, 𝕊_ℤ` over the integers, using the doubling
formula
`(a, b) * (c, d) = (a c - d̄ b, d a + b c̄)`,  `conj (a, b) = (conj a, -b)`.
The sedenions are the fourth doubling of `ℤ` (dimension `2^4 = 16`).  Everything is computable,
so that finite statements about sedenion products can be checked by evaluation.
-/

/-- One Cayley–Dickson doubling step: pairs `(re, im)` of elements of `A`. -/
@[ext]
structure CayleyDickson (A : Type) where
  re : A
  im : A
deriving DecidableEq, Repr

/-- The algebraic operations needed to run the Cayley–Dickson construction. -/
class CDOps (A : Type) where
  zero : A
  add : A → A → A
  neg : A → A
  mul : A → A → A
  conj : A → A

instance : CDOps ℤ := ⟨0, (· + ·), (- ·), (· * ·), id⟩

/-- The Cayley–Dickson doubling formula. -/
instance {A : Type} [CDOps A] : CDOps (CayleyDickson A) where
  zero := ⟨CDOps.zero, CDOps.zero⟩
  add x y := ⟨CDOps.add x.re y.re, CDOps.add x.im y.im⟩
  neg x := ⟨CDOps.neg x.re, CDOps.neg x.im⟩
  mul x y := ⟨CDOps.add (CDOps.mul x.re y.re) (CDOps.neg (CDOps.mul (CDOps.conj y.im) x.im)),
              CDOps.add (CDOps.mul y.im x.re) (CDOps.mul x.im (CDOps.conj y.re))⟩
  conj x := ⟨CDOps.conj x.re, CDOps.neg x.im⟩

/-- The `n`-th Cayley–Dickson algebra over `ℤ` (of dimension `2^n`). -/
def CDAlg : ℕ → Type
  | 0 => ℤ
  | n + 1 => CayleyDickson (CDAlg n)

instance CDAlg.instOps : (n : ℕ) → CDOps (CDAlg n)
  | 0 => inferInstanceAs (CDOps ℤ)
  | n + 1 => @instCDOpsCayleyDickson _ (CDAlg.instOps n)

instance CDAlg.instDecEq : (n : ℕ) → DecidableEq (CDAlg n)
  | 0 => inferInstanceAs (DecidableEq ℤ)
  | n + 1 => @instDecidableEqCayleyDickson _ (CDAlg.instDecEq n)

/-- Build an element of `CDAlg n` from its `2^n` integer coordinates. -/
def CDAlg.ofFn : (n : ℕ) → (Fin (2 ^ n) → ℤ) → CDAlg n
  | 0, f => (f 0 : ℤ)
  | n + 1, f =>
    (⟨CDAlg.ofFn n (fun i => f ⟨i.val, by have := i.isLt; rw [pow_succ]; omega⟩),
      CDAlg.ofFn n (fun i => f ⟨i.val + 2 ^ n, by have := i.isLt; rw [pow_succ]; omega⟩)⟩ :
      CayleyDickson (CDAlg n))

/-- The (integral) sedenions: the fourth Cayley–Dickson doubling of `ℤ`. -/
abbrev Sedenion : Type := CDAlg 4

namespace Sedenion

instance : Mul Sedenion := ⟨CDOps.mul⟩
instance : Add Sedenion := ⟨CDOps.add⟩
instance : Neg Sedenion := ⟨CDOps.neg⟩
instance : Zero Sedenion := ⟨CDOps.zero⟩
instance : DecidableEq Sedenion := CDAlg.instDecEq 4

/-- The sedenion with the given 16 integer coordinates. -/
def ofFn (f : Fin 16 → ℤ) : Sedenion := CDAlg.ofFn 4 f

/-- The standard basis unit `e i`, `i : Fin 16` (with `e 0 = 1`). -/
def e (i : Fin 16) : Sedenion := ofFn (fun k => if k = i then 1 else 0)

end Sedenion
