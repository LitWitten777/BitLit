module

public import Mathlib

@[expose] public section

/-!
# Edge expansion, conductance and spectral gap of finite graphs

For a finite simple graph `G` on a vertex type `W` we define

* `edgeBoundary G S` : the number of edges leaving `S` (`|∂S|`);
* `cheegerConstant G` : the Cheeger constant (edge expansion)
  `h(G) = min { |∂S| / |S| : S ≠ ∅, |S| ≤ |W| / 2 }`;
* `volume G S` : the sum of the degrees of the vertices of `S`;
* `conductance G` : the (Cheeger) conductance
  `φ(G) = min { |∂S| / vol S : 0 < vol S ≤ vol W / 2 }`;
* `variationalGap G` : the spectral gap (algebraic connectivity, Fiedler value) of the Laplacian
  `λ₂(G) = inf { xᵀ L x / xᵀ x : x ≠ 0, ∑ x = 0 }`.

We prove that these quantities are invariants of graph isomorphism, and we prove the "easy"
Cheeger inequality `λ₂(G) ≤ 2 h(G)` for every finite graph.
-/

open Finset Matrix
open scoped Pointwise

namespace SimpleGraph

variable {W : Type*} [Fintype W] [DecidableEq W] (G : SimpleGraph W) [DecidableRel G.Adj]

/-- The edge boundary `|∂S|`: the number of edges with exactly one endpoint in `S`. -/
def edgeBoundary (S : Finset W) : ℕ :=
  (Finset.univ.filter (fun p : W × W => p.1 ∈ S ∧ p.2 ∉ S ∧ G.Adj p.1 p.2)).card

/-- The Cheeger constant (edge expansion) `h(G) = min_{S ≠ ∅, |S| ≤ |W|/2} |∂S| / |S|`. -/
noncomputable def cheegerConstant : ℝ :=
  sInf ((fun S : Finset W => (G.edgeBoundary S : ℝ) / S.card) ''
    {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W})

/-- The volume of a vertex set: the sum of the degrees of its vertices. -/
def volume (S : Finset W) : ℕ := ∑ v ∈ S, G.degree v

/-- The conductance `φ(G) = min_{0 < vol S ≤ vol W / 2} |∂S| / vol S`. -/
noncomputable def conductance : ℝ :=
  sInf ((fun S : Finset W => (G.edgeBoundary S : ℝ) / G.volume S) ''
    {S | 0 < G.volume S ∧ 2 * G.volume S ≤ G.volume Finset.univ})

/-- The Rayleigh quotient `xᵀ L x / xᵀ x` of the graph Laplacian. -/
noncomputable def rayleigh (x : W → ℝ) : ℝ :=
  (x ⬝ᵥ (G.lapMatrix ℝ *ᵥ x)) / (x ⬝ᵥ x)

/-- The spectral gap (algebraic connectivity) of `G`: the infimum of the Rayleigh quotient of the
Laplacian over nonzero vectors orthogonal to the constant vector.  By the Courant–Fischer theorem
this is the second smallest Laplacian eigenvalue `λ₂`. -/
noncomputable def variationalGap : ℝ :=
  sInf (G.rayleigh '' {x | x ≠ 0 ∧ ∑ i, x i = 0})

/-- The Laplacian quadratic form as a sum over (ordered) adjacent pairs. -/
lemma dotProduct_lapMatrix_mulVec (x : W → ℝ) :
    x ⬝ᵥ (G.lapMatrix ℝ *ᵥ x) = (∑ i, ∑ j, if G.Adj i j then (x i - x j) ^ 2 else 0) / 2 := by
  rw [← SimpleGraph.lapMatrix_toLinearMap₂', Matrix.toLinearMap₂'_apply']

lemma rayleigh_nonneg (x : W → ℝ) : 0 ≤ G.rayleigh x := by
  unfold rayleigh
  apply div_nonneg
  · rw [dotProduct_lapMatrix_mulVec]
    apply div_nonneg _ (by norm_num)
    apply Finset.sum_nonneg; intro i _; apply Finset.sum_nonneg; intro j _
    split_ifs <;> positivity
  · exact Finset.sum_nonneg (fun i _ => mul_self_nonneg (x i))

section Iso

variable {W' : Type*} [Fintype W'] [DecidableEq W'] {H : SimpleGraph W'} [DecidableRel H.Adj]

lemma Iso.edgeBoundary_map (e : G ≃g H) (S : Finset W) :
    H.edgeBoundary (S.map e.toEquiv.toEmbedding) = G.edgeBoundary S := by
  unfold edgeBoundary
  rw [Finset.card_filter, Finset.card_filter]
  symm
  refine Fintype.sum_equiv (e.toEquiv.prodCongr e.toEquiv) _ _ (fun p => ?_)
  have h : ∀ x, e.toEquiv.symm (e x) = x := fun x => e.toEquiv.symm_apply_apply x
  simp [Finset.mem_map_equiv, e.map_adj_iff, h]

omit [DecidableEq W] [DecidableEq W'] in
lemma Iso.volume_map (e : G ≃g H) (S : Finset W) :
    H.volume (S.map e.toEquiv.toEmbedding) = G.volume S := by
  unfold volume
  rw [Finset.sum_map]
  refine Finset.sum_congr rfl (fun v _ => ?_)
  exact e.degree_eq v

lemma Iso.rayleigh_comp (e : G ≃g H) (x : W' → ℝ) :
    G.rayleigh (x ∘ e) = H.rayleigh x := by
  unfold rayleigh
  rw [dotProduct_lapMatrix_mulVec, dotProduct_lapMatrix_mulVec]
  congr 1
  · congr 1
    exact Fintype.sum_equiv e.toEquiv _ _ (fun i => Fintype.sum_equiv e.toEquiv _ _
      (fun j => by simp [e.map_adj_iff]))
  · simp only [dotProduct]
    exact Fintype.sum_equiv e.toEquiv _ _ (fun i => rfl)

lemma Iso.cheeger_set_subset (e : G ≃g H) :
    (fun S : Finset W => (G.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W} ⊆
    (fun S : Finset W' => (H.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W'} := by
  rintro r ⟨S, ⟨hne, hcard⟩, rfl⟩
  refine ⟨S.map e.toEquiv.toEmbedding, ⟨hne.map, ?_⟩, ?_⟩
  · rw [Finset.card_map, ← Fintype.card_congr e.toEquiv]; exact hcard
  · simp only [Iso.edgeBoundary_map, Finset.card_map]

lemma Iso.cheegerConstant_eq (e : G ≃g H) : G.cheegerConstant = H.cheegerConstant := by
  unfold cheegerConstant
  rw [Set.Subset.antisymm (Iso.cheeger_set_subset G e) (Iso.cheeger_set_subset H e.symm)]

lemma Iso.conductance_set_subset (e : G ≃g H) :
    (fun S : Finset W => (G.edgeBoundary S : ℝ) / G.volume S) ''
      {S | 0 < G.volume S ∧ 2 * G.volume S ≤ G.volume Finset.univ} ⊆
    (fun S : Finset W' => (H.edgeBoundary S : ℝ) / H.volume S) ''
      {S | 0 < H.volume S ∧ 2 * H.volume S ≤ H.volume Finset.univ} := by
  rintro r ⟨S, ⟨hpos, hvol⟩, rfl⟩
  have hu : H.volume Finset.univ = G.volume Finset.univ := by
    rw [← Iso.volume_map G e Finset.univ, Finset.map_univ_equiv]
  refine ⟨S.map e.toEquiv.toEmbedding, ⟨?_, ?_⟩, ?_⟩
  · rw [Iso.volume_map]; exact hpos
  · rw [Iso.volume_map, hu]; exact hvol
  · simp only [Iso.edgeBoundary_map, Iso.volume_map]

lemma Iso.conductance_eq (e : G ≃g H) : G.conductance = H.conductance := by
  unfold conductance
  rw [Set.Subset.antisymm (Iso.conductance_set_subset G e) (Iso.conductance_set_subset H e.symm)]

lemma Iso.spectral_set_subset (e : G ≃g H) :
    G.rayleigh '' {x | x ≠ 0 ∧ ∑ i, x i = 0} ⊆ H.rayleigh '' {x | x ≠ 0 ∧ ∑ i, x i = 0} := by
  rintro r ⟨x, ⟨hx, hsum⟩, rfl⟩
  refine ⟨x ∘ e.symm, ⟨?_, ?_⟩, ?_⟩
  · intro h
    apply hx
    funext v
    have := congrFun h (e v)
    simpa using this
  · rw [← hsum]
    exact Fintype.sum_equiv e.symm.toEquiv _ _ (fun i => rfl)
  · exact Iso.rayleigh_comp H e.symm x

lemma Iso.variationalGap_eq (e : G ≃g H) : G.variationalGap = H.variationalGap := by
  unfold variationalGap
  rw [Set.Subset.antisymm (Iso.spectral_set_subset G e) (Iso.spectral_set_subset H e.symm)]

end Iso

lemma edgeBoundary_eq_sum (S : Finset W) :
    (G.edgeBoundary S : ℝ) = ∑ i, ∑ j, if (i ∈ S ∧ j ∉ S ∧ G.Adj i j) then (1 : ℝ) else 0 := by
  unfold edgeBoundary
  rw [Finset.card_filter, Nat.cast_sum, ← Finset.univ_product_univ, Finset.sum_product]
  simp

lemma variationalGap_bddBelow :
    BddBelow (G.rayleigh '' {x | x ≠ 0 ∧ ∑ i, x i = 0}) :=
  ⟨0, by rintro r ⟨x, _, rfl⟩; exact G.rayleigh_nonneg x⟩

/-- The Rayleigh quotient of the centred indicator vector of `S`. -/
lemma rayleigh_indicator_le (S : Finset W) (hne : S.Nonempty)
    (hcard : 2 * S.card ≤ Fintype.card W) :
    ∃ x : W → ℝ, x ≠ 0 ∧ ∑ i, x i = 0 ∧
      G.rayleigh x ≤ 2 * ((G.edgeBoundary S : ℝ) / S.card) := by
  set n : ℝ := (Fintype.card W : ℝ) with hn_def
  set s : ℝ := (S.card : ℝ) with hs_def
  set ind : W → ℝ := fun i => if i ∈ S then 1 else 0 with hind
  have hs1 : (1 : ℝ) ≤ s := by
    rw [hs_def]; exact_mod_cast Finset.card_pos.mpr hne
  have hsn : 2 * s ≤ n := by rw [hs_def, hn_def]; exact_mod_cast hcard
  have hn : 0 < n := by linarith
  have hsum_ind : ∑ i, ind i = s := by
    simp [hind, Finset.sum_ite_mem, hs_def]
  have hind_sq : ∀ i, ind i * ind i = ind i := by
    intro i; by_cases h : i ∈ S <;> simp [hind, h]
  refine ⟨fun i => ind i - s / n, ?_, ?_, ?_⟩
  · intro h
    obtain ⟨v, hv⟩ := hne
    have := congrFun h v
    simp only [hind, hv, if_true, Pi.zero_apply] at this
    have : s = n := by field_simp at this; linarith
    linarith
  · rw [Finset.sum_sub_distrib, hsum_ind]
    simp only [Finset.sum_const, Finset.card_univ, nsmul_eq_mul, ← hn_def]
    field_simp
    ring
  · have hE : (G.edgeBoundary S : ℝ) ≥ 0 := by positivity
    have hnum : (fun i => ind i - s / n) ⬝ᵥ (G.lapMatrix ℝ *ᵥ (fun i => ind i - s / n)) =
        G.edgeBoundary S := by
      rw [dotProduct_lapMatrix_mulVec, edgeBoundary_eq_sum]
      have hpt : ∀ i j, (if G.Adj i j then ((ind i - s / n) - (ind j - s / n)) ^ 2 else 0) =
          (if (i ∈ S ∧ j ∉ S ∧ G.Adj i j) then (1 : ℝ) else 0) +
          (if (j ∈ S ∧ i ∉ S ∧ G.Adj j i) then (1 : ℝ) else 0) := by
        intro i j
        by_cases hi : i ∈ S <;> by_cases hj : j ∈ S <;> by_cases ha : G.Adj i j <;>
          simp [hind, hi, hj, ha, G.adj_comm j i]
        all_goals (right; ring)
      simp only [hpt, Finset.sum_add_distrib]
      rw [Finset.sum_comm (f := fun i j => if (j ∈ S ∧ i ∉ S ∧ G.Adj j i) then (1 : ℝ) else 0)]
      ring
    have hden : (fun i => ind i - s / n) ⬝ᵥ (fun i => ind i - s / n) = s * (n - s) / n := by
      simp only [dotProduct]
      have hpt : ∀ i, (ind i - s / n) * (ind i - s / n) = ind i * (1 - 2 * (s / n)) + (s / n) ^ 2 := by
        intro i; have := hind_sq i; nlinarith [this]
      simp only [hpt, Finset.sum_add_distrib, ← Finset.sum_mul, hsum_ind, Finset.sum_const,
        Finset.card_univ, nsmul_eq_mul, ← hn_def]
      field_simp
      ring
    have hD : 0 < s * (n - s) / n := by
      apply div_pos _ hn; apply mul_pos <;> linarith
    unfold rayleigh
    rw [hnum, hden, div_le_iff₀ hD]
    have : 2 * ((G.edgeBoundary S : ℝ) / s) * (s * (n - s) / n) =
        (G.edgeBoundary S : ℝ) * (2 * (n - s) / n) := by
      field_simp
    rw [this]
    apply le_mul_of_one_le_right hE
    rw [le_div_iff₀ hn]; linarith

/-- For a `d`-regular graph the conductance is the Cheeger constant divided by `d`. -/
theorem conductance_eq_of_regular (d : ℕ) (hd : 0 < d) (hreg : ∀ v, G.degree v = d) :
    G.conductance = G.cheegerConstant / d := by
  have hvol : ∀ S, G.volume S = d * S.card := by
    intro S; simp [volume, hreg, mul_comm]
  unfold conductance cheegerConstant
  have hset : ((fun S : Finset W => (G.edgeBoundary S : ℝ) / G.volume S) ''
      {S | 0 < G.volume S ∧ 2 * G.volume S ≤ G.volume Finset.univ}) =
      (1 / (d : ℝ)) • ((fun S : Finset W => (G.edgeBoundary S : ℝ) / S.card) ''
        {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W}) := by
    rw [← Set.image_smul, Set.image_image]
    have hA : {S : Finset W | 0 < G.volume S ∧ 2 * G.volume S ≤ G.volume Finset.univ} =
        {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W} := by
      ext S
      simp only [Set.mem_setOf_eq, hvol, Finset.card_univ, ← Finset.card_pos]
      constructor
      · rintro ⟨h1, h2⟩
        refine ⟨Nat.pos_of_mul_pos_left h1, ?_⟩
        have : d * (2 * S.card) ≤ d * Fintype.card W := by linarith
        exact Nat.le_of_mul_le_mul_left this hd
      · rintro ⟨h1, h2⟩
        exact ⟨Nat.mul_pos hd h1, by nlinarith⟩
    rw [hA]
    refine Set.image_congr (fun S _ => ?_)
    simp only [hvol, Nat.cast_mul, smul_eq_mul]
    rw [div_mul_eq_div_div, one_div_mul_eq_div, div_div, div_div, mul_comm]
  rw [hset, Real.sInf_smul_of_nonneg (by positivity), smul_eq_mul]
  ring

/-- The easy half of the discrete Cheeger inequality: `λ₂(G) ≤ 2 h(G)`. -/
theorem variationalGap_le_two_mul_cheegerConstant : G.variationalGap ≤ 2 * G.cheegerConstant := by
  by_cases hne : ((fun S : Finset W => (G.edgeBoundary S : ℝ) / S.card) ''
      {S | S.Nonempty ∧ 2 * S.card ≤ Fintype.card W}).Nonempty
  · unfold cheegerConstant
    rw [← div_le_iff₀' (by norm_num : (0:ℝ) < 2)]
    apply le_csInf hne
    rintro r ⟨S, ⟨hS, hcard⟩, rfl⟩
    obtain ⟨x, hx, hsum, hle⟩ := G.rayleigh_indicator_le S hS hcard
    rw [div_le_iff₀' (by norm_num : (0:ℝ) < 2)]
    exact le_trans (csInf_le G.variationalGap_bddBelow ⟨x, ⟨hx, hsum⟩, rfl⟩) hle
  · have hempty : {x : W → ℝ | x ≠ 0 ∧ ∑ i, x i = 0} = ∅ := by
      ext x
      simp only [Set.mem_setOf_eq, Set.mem_empty_iff_false, iff_false, not_and]
      intro hx hsum
      obtain ⟨v, hv⟩ : ∃ v, x v ≠ 0 := by
        by_contra h; push_neg at h; exact hx (funext h)
      have hcard : Fintype.card W ≤ 1 := by
        by_contra h
        exact hne ⟨_, ⟨{v}, ⟨Finset.singleton_nonempty v, by simp; omega⟩, rfl⟩⟩
      have huniv : (Finset.univ : Finset W) = {v} := by
        ext w
        simp only [Finset.mem_univ, Finset.mem_singleton, true_iff]
        exact Fintype.card_le_one_iff.mp hcard w v
      rw [huniv, Finset.sum_singleton] at hsum
      exact hv hsum
    have h0 : G.cheegerConstant = 0 := by
      unfold cheegerConstant
      rw [Set.not_nonempty_iff_eq_empty.mp hne, Real.sInf_empty]
    unfold variationalGap
    rw [hempty, Set.image_empty, Real.sInf_empty, h0, mul_zero]

end SimpleGraph
