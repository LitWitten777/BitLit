module

public import RequestProject.Expansion
public import RequestProject.ZeroDivisorGraph
meta import RequestProject.Expansion
meta import RequestProject.ZeroDivisorGraph
meta import Mathlib

@[expose] public section

/-!
# Expansion and spectrum of the box-kite graph

The box-kite graph (the bipartite double cover of the octahedron, see `boxKiteGraph`) is the
graph of every connected component of the sedenion zero-divisor graph.  Here we compute:

* its Cheeger constant `h = 4/3`,
* its conductance `φ = 1/3`,
* its spectral gap `λ₂ = 2`,
* its full Laplacian spectrum `{0, 2, 4, 6, 8}`.
-/

open SimpleGraph Finset Matrix

namespace BoxKite

/-- An optimal Cheeger cut of the box-kite graph (6 vertices, 8 boundary edges). -/
def optimalCut : Finset (Fin 6 × Bool) :=
  {(1, false), (2, false), (4, false), (5, false), (0, true), (3, true)}

lemma optimalCut_card : optimalCut.card = 6 := by decide

lemma optimalCut_edgeBoundary : boxKiteGraph.edgeBoundary optimalCut = 8 := by native_decide

lemma edgeBoundary_bound : ∀ S : Finset (Fin 6 × Bool), S.Nonempty → 2 * S.card ≤ 12 →
    4 * S.card ≤ 3 * boxKiteGraph.edgeBoundary S := by
  native_decide

lemma card_vertex : Fintype.card (Fin 6 × Bool) = 12 := by decide

lemma degree_eq (x : Fin 6 × Bool) : boxKiteGraph.degree x = 4 := by
  revert x; native_decide

end BoxKite

open BoxKite

/-- **Cheeger constant of the box-kite:** `h = 4/3`. -/
theorem boxKiteGraph_cheegerConstant : boxKiteGraph.cheegerConstant = 4 / 3 := by
  apply IsLeast.csInf_eq
  constructor
  · refine ⟨optimalCut, ⟨by decide, by rw [optimalCut_card, card_vertex]⟩, ?_⟩
    simp only [optimalCut_card, optimalCut_edgeBoundary]
    norm_num
  · rintro r ⟨S, ⟨hne, hc⟩, rfl⟩
    rw [card_vertex] at hc
    have h := edgeBoundary_bound S hne hc
    have hpos : (0 : ℝ) < S.card := by exact_mod_cast hne.card_pos
    rw [le_div_iff₀ hpos]
    have h' : (4 : ℝ) * S.card ≤ 3 * boxKiteGraph.edgeBoundary S := by exact_mod_cast h
    linarith

/-- **Conductance of the box-kite:** `φ = 1/3`. -/
theorem boxKiteGraph_conductance : boxKiteGraph.conductance = 1 / 3 := by
  rw [boxKiteGraph.conductance_eq_of_regular 4 (by norm_num) degree_eq,
    boxKiteGraph_cheegerConstant]
  norm_num

namespace BoxKite

/-- The explicit sum-of-squares decomposition of `xᵀ L x - 2 xᵀ x` for the box-kite Laplacian. -/
lemma quadForm_sub_two (x : Fin 6 × Bool → ℝ) :
    x ⬝ᵥ (boxKiteGraph.lapMatrix ℝ *ᵥ x) - 2 * (x ⬝ᵥ x) =
      (1 / 2) * (∑ a, x (a, false) - ∑ a, x (a, true)) ^ 2
      + (1 / 2) * ((x (0, false) - x (1, false) + x (3, false) - x (4, false))
          + (x (0, true) - x (1, true) + x (3, true) - x (4, true))) ^ 2
      + (1 / 6) * ((x (0, false) + x (1, false) - 2 * x (2, false) + x (3, false)
            + x (4, false) - 2 * x (5, false))
          + (x (0, true) + x (1, true) - 2 * x (2, true) + x (3, true)
            + x (4, true) - 2 * x (5, true))) ^ 2
      + (1 / 2) * (((x (0, false) - x (3, false)) + (x (0, true) - x (3, true))) ^ 2
          + ((x (1, false) - x (4, false)) + (x (1, true) - x (4, true))) ^ 2
          + ((x (2, false) - x (5, false)) + (x (2, true) - x (5, true))) ^ 2
          + ((x (0, false) - x (3, false)) - (x (0, true) - x (3, true))) ^ 2
          + ((x (1, false) - x (4, false)) - (x (1, true) - x (4, true))) ^ 2
          + ((x (2, false) - x (5, false)) - (x (2, true) - x (5, true))) ^ 2)
      - (1 / 6) * (∑ i, x i) ^ 2 := by
  rw [dotProduct_lapMatrix_mulVec]
  simp only [dotProduct, Fintype.sum_prod_type, Fin.sum_univ_six, Fintype.sum_bool]
  simp (config := { decide := true }) only [if_true, if_false]
  ring

lemma two_le_rayleigh (x : Fin 6 × Bool → ℝ) (hx : x ≠ 0) (hsum : ∑ i, x i = 0) :
    2 ≤ boxKiteGraph.rayleigh x := by
  have hpos : 0 < x ⬝ᵥ x := by
    obtain ⟨v, hv⟩ : ∃ v, x v ≠ 0 := by
      by_contra h; push_neg at h; exact hx (funext h)
    simp only [dotProduct]
    exact lt_of_lt_of_le (mul_self_pos.mpr hv)
      (Finset.single_le_sum (f := fun i => x i * x i) (fun i _ => mul_self_nonneg (x i))
        (Finset.mem_univ v))
  unfold rayleigh
  rw [le_div_iff₀ hpos]
  have h := quadForm_sub_two x
  rw [hsum] at h
  simp only [ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow, mul_zero, sub_zero] at h
  have h0 : 0 ≤ x ⬝ᵥ (boxKiteGraph.lapMatrix ℝ *ᵥ x) - 2 * (x ⬝ᵥ x) := by
    rw [h]; positivity
  linarith

/-- A Fiedler vector of the box-kite graph (a `λ = 2` eigenvector orthogonal to constants). -/
def fiedler (x : Fin 6 × Bool) : ℝ :=
  (if x.1.val % 3 = 0 then 1 else if x.1.val % 3 = 1 then -1 else 0) * (if x.2 then -1 else 1)

lemma fiedler_ne_zero : fiedler ≠ 0 := by
  intro h
  have := congrFun h (0, false)
  simp [fiedler] at this

lemma fiedler_sum : ∑ i, fiedler i = 0 := by
  simp (config := { decide := true }) only [fiedler, Fintype.sum_prod_type, Fin.sum_univ_six,
    Fintype.sum_bool, if_true, if_false]
  norm_num

lemma rayleigh_fiedler : boxKiteGraph.rayleigh fiedler = 2 := by
  unfold rayleigh
  rw [dotProduct_lapMatrix_mulVec]
  simp only [dotProduct, Fintype.sum_prod_type, Fin.sum_univ_six, Fintype.sum_bool]
  simp (config := { decide := true }) only [fiedler, if_true, if_false]
  norm_num

end BoxKite

/-- **Spectral gap of the box-kite:** `λ₂ = 2`. -/
theorem boxKiteGraph_spectralGap : boxKiteGraph.variationalGap = 2 := by
  apply IsLeast.csInf_eq
  constructor
  · exact ⟨fiedler, ⟨fiedler_ne_zero, fiedler_sum⟩, rayleigh_fiedler⟩
  · rintro r ⟨x, ⟨hx, hsum⟩, rfl⟩
    exact two_le_rayleigh x hx hsum

/-! ### The Laplacian spectrum of the box-kite -/

namespace BoxKite

open Polynomial

lemma lapMatrix_real_eq :
    boxKiteGraph.lapMatrix ℝ = (boxKiteGraph.lapMatrix ℤ).map (Int.castRingHom ℝ) := by
  ext i j
  simp only [SimpleGraph.lapMatrix, SimpleGraph.degMatrix, SimpleGraph.adjMatrix, Matrix.map_apply,
    Matrix.sub_apply, Matrix.diagonal_apply, Matrix.of_apply]
  split_ifs <;> simp

/-- The Laplacian satisfies `L (L - 2) (L - 4) (L - 6) (L - 8) = 0` (over `ℤ`). -/
lemma annihilating_int :
    boxKiteGraph.lapMatrix ℤ * (boxKiteGraph.lapMatrix ℤ - 2) * (boxKiteGraph.lapMatrix ℤ - 4) *
      (boxKiteGraph.lapMatrix ℤ - 6) * (boxKiteGraph.lapMatrix ℤ - 8) = 0 := by
  native_decide

lemma annihilating_real :
    boxKiteGraph.lapMatrix ℝ * (boxKiteGraph.lapMatrix ℝ - 2) * (boxKiteGraph.lapMatrix ℝ - 4) *
      (boxKiteGraph.lapMatrix ℝ - 6) * (boxKiteGraph.lapMatrix ℝ - 8) = 0 := by
  have h := congrArg (Int.castRingHom ℝ).mapMatrix annihilating_int
  simp only [map_mul, map_sub, map_ofNat, map_zero, RingHom.mapMatrix_apply] at h
  rw [lapMatrix_real_eq]
  exact h

lemma mem_spectrum_of_mulVec_eq {n : Type*} [Fintype n] [DecidableEq n] (M : Matrix n n ℝ)
    (μ : ℝ) (v : n → ℝ) (hv : v ≠ 0) (h : M *ᵥ v = μ • v) : μ ∈ spectrum ℝ M := by
  rw [spectrum.mem_iff, Matrix.isUnit_iff_isUnit_det, isUnit_iff_ne_zero, not_not]
  by_contra hdet
  apply hv
  apply Matrix.eq_zero_of_mulVec_eq_zero hdet
  rw [Matrix.sub_mulVec, h, Matrix.algebraMap_eq_diagonal]
  ext i
  simp [Matrix.mulVec_diagonal]

lemma mem_spectrum_of_int_eigvec (μ : ℤ) (v : Fin 6 × Bool → ℤ) (hv : v ≠ 0)
    (h : boxKiteGraph.lapMatrix ℤ *ᵥ v = μ • v) :
    (μ : ℝ) ∈ spectrum ℝ (boxKiteGraph.lapMatrix ℝ) := by
  refine mem_spectrum_of_mulVec_eq _ _ (fun i => (v i : ℝ)) ?_ ?_
  · intro h0
    apply hv
    funext i
    have := congrFun h0 i
    simp only [Pi.zero_apply] at this ⊢
    exact_mod_cast this
  · funext i
    have := RingHom.map_mulVec (Int.castRingHom ℝ) (boxKiteGraph.lapMatrix ℤ) v i
    rw [h] at this
    simp only [Pi.smul_apply, smul_eq_mul, Int.coe_castRingHom] at this ⊢
    rw [lapMatrix_real_eq]
    simp only [Int.coe_castRingHom]
    rw [Function.comp_def] at this
    rw [← this]
    push_cast
    ring

/-- Integer eigenvectors of the box-kite Laplacian for the eigenvalues `0, 2, 4, 6, 8`. -/
def eigvec : ℤ → Fin 6 × Bool → ℤ
  | 0 => fun _ => 1
  | 2 => fun x => (if x.1.val % 3 = 0 then 1 else if x.1.val % 3 = 1 then -1 else 0) *
      (if x.2 then -1 else 1)
  | 4 => fun x => if x.1.val = 0 then 1 else if x.1.val = 3 then -1 else 0
  | 6 => fun x => if x.1.val % 3 = 0 then 1 else if x.1.val % 3 = 1 then -1 else 0
  | _ => fun x => if x.2 then -1 else 1

lemma eigvec_spec : ∀ μ ∈ ({0, 2, 4, 6, 8} : Finset ℤ),
    eigvec μ ≠ 0 ∧ boxKiteGraph.lapMatrix ℤ *ᵥ eigvec μ = μ • eigvec μ := by
  native_decide

end BoxKite

open BoxKite Polynomial in
/-- **Laplacian spectrum of the box-kite:** the eigenvalues of the Laplacian are exactly
`0, 2, 4, 6, 8` (with multiplicities `1, 2, 6, 2, 1`, not recorded here). -/
theorem boxKiteGraph_lapMatrix_spectrum :
    spectrum ℝ (boxKiteGraph.lapMatrix ℝ) = {0, 2, 4, 6, 8} := by
  apply Set.Subset.antisymm
  · intro μ hμ
    have h1 := spectrum.subset_polynomial_aeval (boxKiteGraph.lapMatrix ℝ)
      (X * (X - 2) * (X - 4) * (X - 6) * (X - 8)) ⟨μ, hμ, rfl⟩
    simp only [map_mul, map_sub, Polynomial.aeval_X, map_ofNat] at h1
    rw [annihilating_real, spectrum.zero_eq] at h1
    simp only [eval_mul, eval_sub, eval_X, eval_ofNat, Set.mem_singleton_iff, mul_eq_zero,
      sub_eq_zero] at h1
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff]
    tauto
  · intro μ hμ
    simp only [Set.mem_insert_iff, Set.mem_singleton_iff] at hμ
    rcases hμ with rfl | rfl | rfl | rfl | rfl
    · have h := eigvec_spec 0 (by decide)
      exact_mod_cast mem_spectrum_of_int_eigvec 0 _ h.1 h.2
    · have h := eigvec_spec 2 (by decide)
      exact_mod_cast mem_spectrum_of_int_eigvec 2 _ h.1 h.2
    · have h := eigvec_spec 4 (by decide)
      exact_mod_cast mem_spectrum_of_int_eigvec 4 _ h.1 h.2
    · have h := eigvec_spec 6 (by decide)
      exact_mod_cast mem_spectrum_of_int_eigvec 6 _ h.1 h.2
    · have h := eigvec_spec 8 (by decide)
      exact_mod_cast mem_spectrum_of_int_eigvec 8 _ h.1 h.2
