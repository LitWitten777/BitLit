import Sovereign.Algebra.TowerBasis
import Sovereign.Algebra.TowerZeroDivisors

namespace Sovereign

/-! ## 0. Boolean helpers -/

theorem bool_xor_eq_false_iff (x y : Bool) : (xor x y = false) ↔ x = y := by decide +revert

theorem bool_xor_eq_true_iff (x y : Bool) : (xor x y = true) ↔ x ≠ y := by decide +revert

/-! ## 1. Reduction lemmas for the sign function at a doubling step -/

theorem epsNeg_succ_low_low (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    epsNeg (n + 1) a b = epsNeg n a b := by
  simp [epsNeg, ha, hb]

theorem epsNeg_succ_low_high (n a b : Nat) (ha : a < 2 ^ n) :
    epsNeg (n + 1) a (2 ^ n + b) = epsNeg n b a := by
  have h : ¬ (2 ^ n + b < 2 ^ n) := by omega
  simp [epsNeg, ha, h]

theorem epsNeg_succ_high_low (n a b : Nat) (hb : b < 2 ^ n) :
    epsNeg (n + 1) (2 ^ n + a) b = xor (conjNeg b) (epsNeg n a b) := by
  have h : ¬ (2 ^ n + a < 2 ^ n) := by omega
  simp [epsNeg, h, hb]

theorem epsNeg_succ_high_high (n a b : Nat) :
    epsNeg (n + 1) (2 ^ n + a) (2 ^ n + b) = !(xor (conjNeg b) (epsNeg n b a)) := by
  have h : ¬ (2 ^ n + a < 2 ^ n) := by omega
  have h' : ¬ (2 ^ n + b < 2 ^ n) := by omega
  simp [epsNeg, h, h']

/-! ## 2. The two structural laws of the sign function -/

/-- **Commutation law (total form).** `e_a e_b = -e_b e_a` exactly for distinct non-real
basis vectors, and `e_a e_b = e_b e_a` in every other case. -/
theorem epsNeg_xor_swap (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    xor (epsNeg n a b) (epsNeg n b a) = decide (a ≠ 0 ∧ b ≠ 0 ∧ a ≠ b) := by
  by_cases ha0 : a = 0
  · subst ha0; simp [epsNeg_zero_left, epsNeg_zero_right]
  by_cases hb0 : b = 0
  · subst hb0; simp [epsNeg_zero_left, epsNeg_zero_right]
  by_cases hab : a = b
  · subst hab; simp
  · rw [epsNeg_anticomm n a b ha hb hab ha0 hb0]
    cases epsNeg n b a <;> simp [ha0, hb0, hab]

/-- **Cyclic law (total form).** For a "quaternionic triple" `a, b, a ^^^ b` of distinct
non-real indices the two products `e_a e_b` and `e_b e_{a ^^^ b}` carry the same sign. -/
theorem epsNeg_cyclic : ∀ (n a b : Nat), a < 2 ^ n → b < 2 ^ n →
    xor (epsNeg n a b) (epsNeg n b (a ^^^ b)) = decide ((a = 0 ∨ a = b) ∧ b ≠ 0) := by
  intro n
  induction n with
  | zero =>
    intro a b ha hb
    have ha0 : a = 0 := by simpa using ha
    have hb0 : b = 0 := by simpa using hb
    subst ha0; subst hb0; simp [epsNeg]
  | succ n ih =>
    intro a b ha hb
    have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    have hHpos : 0 < 2 ^ n := by positivity
    by_cases hA : a < 2 ^ n <;> by_cases hB : b < 2 ^ n
    · -- low, low
      have hx : a ^^^ b < 2 ^ n := Nat.xor_lt_two_pow hA hB
      rw [epsNeg_succ_low_low n a b hA hB, epsNeg_succ_low_low n b (a ^^^ b) hB hx]
      exact ih a b hA hB
    · -- low, high
      obtain ⟨b', hb', rfl⟩ : ∃ p, p < 2 ^ n ∧ b = 2 ^ n + p := ⟨b - 2 ^ n, by omega, by omega⟩
      have hx : a ^^^ b' < 2 ^ n := Nat.xor_lt_two_pow hA hb'
      rw [xor_low_high hA hb', epsNeg_succ_low_high n a b' hA,
        epsNeg_succ_high_high n b' (a ^^^ b')]
      have hrhs : ((a = 0 ∨ a = 2 ^ n + b') ∧ 2 ^ n + b' ≠ 0) ↔ a = 0 := by
        constructor
        · rintro ⟨h | h, -⟩
          · exact h
          · omega
        · intro h; exact ⟨Or.inl h, by omega⟩
      rw [decide_eq_decide.mpr hrhs]
      by_cases ha0 : a = 0
      · subst ha0
        simp [epsNeg_zero_right, epsNeg_self n b' hb', Nat.zero_xor]
      · by_cases hab : a = b'
        · subst hab
          simp [Nat.xor_self, epsNeg_self n a hA, epsNeg_zero_left, conjNeg, ha0]
        · have hxne : a ^^^ b' ≠ 0 := by
            simpa [Nat.xor_eq_zero_iff] using hab
          have hcn : conjNeg (a ^^^ b') = true := by simp [conjNeg, hxne]
          rw [hcn, decide_eq_false ha0]
          have key : epsNeg n b' a = epsNeg n (a ^^^ b') b' := by
            by_cases hb0 : b' = 0
            · subst hb0; simp [epsNeg_zero_left, epsNeg_zero_right, Nat.xor_zero]
            · have h1 := ih b' a hb' hA
              have h1' : epsNeg n b' a = epsNeg n a (b' ^^^ a) := by
                have hba : b' ≠ a := fun h => hab h.symm
                have : decide ((b' = 0 ∨ b' = a) ∧ a ≠ 0) = false := by
                  simp [hb0, hba]
                rw [this] at h1
                exact (bool_xor_eq_false_iff _ _).mp h1
              have h2 := ih a (a ^^^ b') hA hx
              have h2' : epsNeg n a (a ^^^ b') = epsNeg n (a ^^^ b') b' := by
                have hself : a ^^^ (a ^^^ b') = b' := Nat.xor_xor_cancel_left a b'
                rw [hself] at h2
                have : decide ((a = 0 ∨ a = a ^^^ b') ∧ a ^^^ b' ≠ 0) = false := by
                  have : a ≠ a ^^^ b' := by
                    intro h
                    apply hb0
                    have := congrArg (fun z => a ^^^ z) h
                    simpa [Nat.xor_xor_cancel_left] using this.symm
                  simp [ha0, this]
                rw [this] at h2
                exact (bool_xor_eq_false_iff _ _).mp h2
              rw [h1', Nat.xor_comm b' a, h2']
          rw [key]
          cases epsNeg n (a ^^^ b') b' <;> simp
    · -- high, low
      obtain ⟨a', ha', rfl⟩ : ∃ p, p < 2 ^ n ∧ a = 2 ^ n + p := ⟨a - 2 ^ n, by omega, by omega⟩
      have hx : a' ^^^ b < 2 ^ n := Nat.xor_lt_two_pow ha' hB
      rw [xor_high_low ha' hB, epsNeg_succ_high_low n a' b hB,
        epsNeg_succ_low_high n b (a' ^^^ b) hB]
      have hrhs : decide ((2 ^ n + a' = 0 ∨ 2 ^ n + a' = b) ∧ b ≠ 0) = false := by
        have hno : ¬ ((2 ^ n + a' = 0 ∨ 2 ^ n + a' = b) ∧ b ≠ 0) := by omega
        exact decide_eq_false hno
      rw [hrhs]
      by_cases hb0 : b = 0
      · subst hb0
        simp [epsNeg_zero_right, conjNeg, Nat.xor_zero]
      · have hcn : conjNeg b = true := by simp [conjNeg, hb0]
        rw [hcn]
        by_cases ha0 : a' = 0
        · subst ha0
          simp [epsNeg_zero_left, Nat.zero_xor, epsNeg_self n b hB, conjNeg, hb0]
        · by_cases hab : a' = b
          · subst hab
            simp [Nat.xor_self, epsNeg_self n a' ha', epsNeg_zero_left, conjNeg, ha0]
          · have hxne : a' ^^^ b ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hab
            have h1 := ih a' b ha' hB
            have h1' : epsNeg n a' b = epsNeg n b (a' ^^^ b) := by
              have : decide ((a' = 0 ∨ a' = b) ∧ b ≠ 0) = false := by simp [ha0, hab]
              rw [this] at h1
              exact (bool_xor_eq_false_iff _ _).mp h1
            have h2 := epsNeg_xor_swap n b (a' ^^^ b) hB hx
            have hne2 : b ≠ a' ^^^ b := by
              intro h
              apply ha0
              have := congrArg (fun z => z ^^^ b) h
              simpa [Nat.xor_xor_cancel_right] using this.symm
            rw [decide_eq_true (by exact ⟨hb0, hxne, hne2⟩)] at h2
            rw [h1']
            have := (bool_xor_eq_true_iff _ _).mp h2
            cases hv : epsNeg n b (a' ^^^ b) <;>
              cases hw : epsNeg n (a' ^^^ b) b <;> simp_all
    · -- high, high
      obtain ⟨a', ha', rfl⟩ : ∃ p, p < 2 ^ n ∧ a = 2 ^ n + p := ⟨a - 2 ^ n, by omega, by omega⟩
      obtain ⟨b', hb', rfl⟩ : ∃ p, p < 2 ^ n ∧ b = 2 ^ n + p := ⟨b - 2 ^ n, by omega, by omega⟩
      have hx : a' ^^^ b' < 2 ^ n := Nat.xor_lt_two_pow ha' hb'
      rw [xor_high_high ha' hb', epsNeg_succ_high_high n a' b',
        epsNeg_succ_high_low n b' (a' ^^^ b') hx]
      have hrhs : ((2 ^ n + a' = 0 ∨ 2 ^ n + a' = 2 ^ n + b') ∧ 2 ^ n + b' ≠ 0) ↔ a' = b' := by
        constructor
        · rintro ⟨h | h, -⟩
          · omega
          · omega
        · intro h; exact ⟨Or.inr (by omega), by omega⟩
      rw [decide_eq_decide.mpr hrhs]
      by_cases hab : a' = b'
      · subst hab
        simp [Nat.xor_self, epsNeg_self n a' ha', epsNeg_zero_right, conjNeg]
      · have hxne : a' ^^^ b' ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hab
        have hcn : conjNeg (a' ^^^ b') = true := by simp [conjNeg, hxne]
        rw [hcn, decide_eq_false hab]
        by_cases hb0 : b' = 0
        · subst hb0
          simp [epsNeg_zero_left, conjNeg, Nat.xor_zero]
        · have hcnb : conjNeg b' = true := by simp [conjNeg, hb0]
          rw [hcnb]
          by_cases ha0 : a' = 0
          · subst ha0
            simp [epsNeg_zero_right, Nat.zero_xor, epsNeg_self n b' hb', conjNeg, hb0]
          · have h1 := ih a' b' ha' hb'
            have h1' : epsNeg n a' b' = epsNeg n b' (a' ^^^ b') := by
              have : decide ((a' = 0 ∨ a' = b') ∧ b' ≠ 0) = false := by simp [ha0, hab]
              rw [this] at h1
              exact (bool_xor_eq_false_iff _ _).mp h1
            have h2 := epsNeg_xor_swap n a' b' ha' hb'
            rw [decide_eq_true (by exact ⟨ha0, hb0, hab⟩)] at h2
            rw [← h1']
            have := (bool_xor_eq_true_iff _ _).mp h2
            cases hv : epsNeg n a' b' <;> cases hw : epsNeg n b' a' <;> simp_all

/-! ## 3. The associator sign -/

/-- The sign of the associator of three basis vectors: `assocNeg n a b c = true` exactly
when `(e_a e_b) e_c = -(e_a (e_b e_c))`. -/
def assocNeg (n a b c : Nat) : Bool :=
  xor (xor (epsNeg n a b) (epsNeg n (a ^^^ b) c)) (xor (epsNeg n b c) (epsNeg n a (b ^^^ c)))

theorem basis_assoc (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) (hc : c < 2 ^ n) :
    (basis n a * basis n b) * basis n c
      = signed (assocNeg n a b c) (basis n a * (basis n b * basis n c)) := by
  have hab : a ^^^ b < 2 ^ n := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ n := Nat.xor_lt_two_pow hb hc
  rw [basis_mul n a b ha hb, signed_mul, basis_mul n (a ^^^ b) c hab hc, signed_signed,
    basis_mul n b c hb hc, mul_signed, basis_mul n a (b ^^^ c) ha hbc, signed_signed,
    signed_signed, Nat.xor_assoc]
  congr 1
  simp only [assocNeg]
  cases epsNeg n a b <;> cases epsNeg n (a ^^^ b) c <;> cases epsNeg n b c <;>
    cases epsNeg n a (b ^^^ c) <;> simp

theorem basis_ne_zero (n a : Nat) (ha : a < 2 ^ n) : basis n a ≠ 0 := by
  intro h
  have hco := coeff_basis n a a ha ha
  rw [h, coeff_zero] at hco
  simp at hco

theorem signed_ne_zero (n : Nat) (s : Bool) (x : Tower n) (hx : x ≠ 0) : signed s x ≠ 0 := by
  cases s <;> simpa [signed] using hx

/-- The tower has no 2-torsion, so a non-zero element is never equal to its negative. -/
theorem tower_eq_zero_of_neg_eq (n : Nat) (x : Tower n) (h : -x = x) : x = 0 := by
  refine (coeff_eq_zero_iff n x).2 (fun a _ => ?_)
  have hco := congrArg (fun z => coeff n z a) h
  simp only [coeff_neg] at hco
  omega

/-- The triple `(e_a, e_b, e_c)` associates iff its associator sign vanishes. -/
theorem basis_assoc_eq_iff (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) (hc : c < 2 ^ n) :
    (basis n a * basis n b) * basis n c = basis n a * (basis n b * basis n c)
      ↔ assocNeg n a b c = false := by
  have hbc : b ^^^ c < 2 ^ n := Nat.xor_lt_two_pow hb hc
  have habc : a ^^^ (b ^^^ c) < 2 ^ n := Nat.xor_lt_two_pow ha hbc
  have hy : basis n a * (basis n b * basis n c) ≠ 0 := by
    rw [basis_mul n b c hb hc, mul_signed, basis_mul n a (b ^^^ c) ha hbc, signed_signed]
    exact signed_ne_zero n _ _ (basis_ne_zero n _ habc)
  rw [basis_assoc n a b c ha hb hc]
  cases hs : assocNeg n a b c
  · simp
  · have hne : ¬ (signed true (basis n a * (basis n b * basis n c))
        = basis n a * (basis n b * basis n c)) := by
      intro h
      exact hy (tower_eq_zero_of_neg_eq n _ (by simpa [signed] using h))
    exact iff_of_false hne (by simp)

/-! ## 4. The annihilation condition and its associator form -/

/-- The combinatorial annihilation condition extracted from `crossVec_mul_eq_zero_iff`:
the pair of cross-half vectors with index data `(i,j)` and `(k,m)` admits a choice of signs
making the product vanish exactly when `crossSign n i j k m = true`. -/
def crossSign (n i j k m : Nat) : Bool :=
  xor (epsNeg n i k) (xor (epsNeg n m i) (xor (epsNeg n m j) (xor (epsNeg n j k)
    (xor (conjNeg k) (conjNeg m)))))

theorem nat_xor_eq_iff (a b c : Nat) : a ^^^ b = c ↔ a = b ^^^ c := by
  constructor
  · rintro rfl
    rw [Nat.xor_comm b, Nat.xor_xor_cancel_right]
  · rintro rfl
    rw [Nat.xor_comm b c, Nat.xor_xor_cancel_right]

/-- The Boolean bookkeeping behind `crossSign_eq_assocNeg`. -/
theorem bridge_bool (x1 x2 x3 x4 y1 y2 y3 z k m : Bool)
    (hd : xor (xor x2 y3) (xor (xor x3 z) (xor (xor z y1)
      (xor (xor x4 y2) (xor k m)))) = false) :
    xor x1 (xor x2 (xor x3 (xor x4 (xor k m)))) = xor (xor x1 y1) (xor y2 y3) := by
  revert hd
  decide +revert

/-- The degeneracy bookkeeping behind `crossSign_eq_assocNeg`. -/
theorem crossSign_decide_identity (i j k m : Nat) (hm : m = k ^^^ (i ^^^ j)) :
    xor (decide ((m = 0 ∨ m = i) ∧ i ≠ 0))
      (xor (decide ((m = 0 ∨ m = j) ∧ j ≠ 0))
        (xor (decide (j ≠ 0 ∧ m ^^^ j ≠ 0 ∧ j ≠ m ^^^ j))
          (xor (decide (j ≠ 0 ∧ k ≠ 0 ∧ j ≠ k)) (xor (conjNeg k) (conjNeg m))))) = false := by
  have hmxj : (m ^^^ j = 0) ↔ m = j := Nat.xor_eq_zero_iff
  have hjmxj : (j = m ^^^ j) ↔ m = 0 := by
    constructor
    · intro h
      have := (nat_xor_eq_iff m j j).mp h.symm
      simpa [Nat.xor_self] using this
    · intro h; subst h; simp
  have hm0 : (m = 0) ↔ (k = i ^^^ j) := by
    rw [hm, Nat.xor_eq_zero_iff]
  have hmi : (m = i) ↔ (k = j) := by
    rw [hm, nat_xor_eq_iff, Nat.xor_comm i j, Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
  by_cases hj0 : j = 0
  · subst hj0
    have hmk : m = k ^^^ i := by rw [hm, Nat.xor_zero]
    have hm0' : (m = 0) ↔ (k = i) := by rw [hmk, Nat.xor_eq_zero_iff]
    have hmi' : (m = i) ↔ (k = 0) := by
      rw [hmk, nat_xor_eq_iff, Nat.xor_self]
    by_cases hi0 : i = 0
    · subst hi0
      have : m = k := by rw [hmk, Nat.xor_zero]
      subst this
      simp
    · by_cases hk0 : k = 0
      · have hmi'' : m = i := hmi'.mpr hk0
        simp [hmi'', hi0, hk0, conjNeg]
      · by_cases hki : k = i
        · have : m = 0 := hm0'.mpr hki
          simp [this, hi0, hk0, conjNeg]
        · have h1 : m ≠ 0 := fun h => hki (hm0'.mp h)
          have h2 : m ≠ i := fun h => hk0 (hmi'.mp h)
          simp [h1, h2, hi0, hk0, conjNeg]
  · -- `j ≠ 0`
    have hd23 : xor (decide ((m = 0 ∨ m = j) ∧ j ≠ 0))
        (decide (j ≠ 0 ∧ m ^^^ j ≠ 0 ∧ j ≠ m ^^^ j)) = true := by
      by_cases h1 : m = 0
      · simp [h1, hj0]
      · by_cases h2 : m = j
        · simp [h2, hj0]
        · have h3 : m ^^^ j ≠ 0 := fun h => h2 (hmxj.mp h)
          have h4 : j ≠ m ^^^ j := fun h => h1 (hjmxj.mp h)
          simp [h1, h2, hj0, h3, h4]
    have hd4k : xor (decide (j ≠ 0 ∧ k ≠ 0 ∧ j ≠ k)) (conjNeg k) = decide (m = i) := by
      by_cases hk0 : k = 0
      · have : m ≠ i := by
          intro h
          exact hj0 (by simpa [hk0] using (hmi.mp h).symm)
        simp [hk0, conjNeg, this]
      · by_cases hjk : j = k
        · simp [hjk, hk0, conjNeg, hmi.mpr hjk.symm]
        · have : m ≠ i := fun h => hjk (hmi.mp h).symm
          simp [hjk, hk0, conjNeg, hj0, this]
    have hfinal : xor (decide ((m = 0 ∨ m = i) ∧ i ≠ 0)) (xor (decide (m = i)) (conjNeg m))
        = true := by
      by_cases hi0 : i = 0
      · subst hi0
        by_cases h1 : m = 0
        · simp [h1, conjNeg]
        · simp [h1, conjNeg]
      · by_cases h1 : m = 0
        · subst h1
          have h2 : ¬ (0 = i) := fun h => hi0 h.symm
          simp [hi0, h2, conjNeg]
        · by_cases h2 : m = i
          · simp [h2, hi0, conjNeg]
          · simp [h1, h2, hi0, conjNeg]
    revert hd23 hd4k hfinal
    generalize decide ((m = 0 ∨ m = i) ∧ i ≠ 0) = D1
    generalize decide ((m = 0 ∨ m = j) ∧ j ≠ 0) = D2
    generalize decide (j ≠ 0 ∧ m ^^^ j ≠ 0 ∧ j ≠ m ^^^ j) = D3
    generalize decide (j ≠ 0 ∧ k ≠ 0 ∧ j ≠ k) = D4
    generalize decide (m = i) = E
    generalize conjNeg k = K
    generalize conjNeg m = M
    decide +revert

/-- **Zero divisors are non-associativity.**  With `m = k ^^^ i ^^^ j` (forced by charge
conservation) the annihilation condition for `(i,j)` against `(k,m)` is exactly the
statement that `e_i, e_k, e_j` fail to associate. -/
theorem crossSign_eq_assocNeg (n i j k : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n)
    (hk : k < 2 ^ n) :
    crossSign n i j k (k ^^^ (i ^^^ j)) = assocNeg n i k j := by
  have hij : i ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hi hj
  set m := k ^^^ (i ^^^ j) with hm
  have hm' : m < 2 ^ n := Nat.xor_lt_two_pow hk hij
  have hmxj : m ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hm' hj
  have hmxi : m ^^^ i < 2 ^ n := Nat.xor_lt_two_pow hm' hi
  have hik : i ^^^ k = m ^^^ j := by
    rw [hm, Nat.xor_assoc, Nat.xor_xor_cancel_right, Nat.xor_comm]
  have hkj : k ^^^ j = m ^^^ i := by
    rw [hm, Nat.xor_assoc, Nat.xor_comm i j, Nat.xor_xor_cancel_right]
  rw [crossSign, assocNeg, hik, hkj]
  refine bridge_bool _ _ _ _ _ _ _ (epsNeg n j (m ^^^ j)) _ _ ?_
  rw [epsNeg_cyclic n m i hm' hi, epsNeg_cyclic n m j hm' hj,
    epsNeg_xor_swap n j (m ^^^ j) hj hmxj, epsNeg_xor_swap n j k hj hk]
  exact crossSign_decide_identity i j k m hm

/-- The associator of `(e_a, e_b, e_a)` always vanishes: a corollary of the identification
of associators with annihilation conditions. -/
theorem assocNeg_self (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    assocNeg n a b a = false := by
  have h := crossSign_eq_assocNeg n a a b ha ha hb
  rw [Nat.xor_self, Nat.xor_zero] at h
  rw [← h, crossSign]
  cases epsNeg n a b <;> cases epsNeg n b a <;> cases conjNeg b <;> simp

/-- **Flexibility.** Every algebra of the tower is flexible on basis vectors. -/
theorem basis_flexible (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    (basis n a * basis n b) * basis n a = basis n a * (basis n b * basis n a) :=
  (basis_assoc_eq_iff n a b a ha hb ha).mpr (assocNeg_self n a b ha hb)

/-! ## 5. Existence of a non-associative partner -/

/-- The auxiliary low index used as a witness: an index in `{1,2}` different from `x`. -/
def altIndex (x : Nat) : Nat := if x = 1 then 2 else 1

theorem altIndex_ne_zero (x : Nat) : altIndex x ≠ 0 := by
  unfold altIndex; split <;> simp

theorem altIndex_ne (x : Nat) : altIndex x ≠ x := by
  unfold altIndex; split <;> omega

theorem altIndex_lt (x q : Nat) (hq : 2 ≤ q) : altIndex x < 2 ^ q := by
  have : (4 : Nat) ≤ 2 ^ q := by
    calc (4 : Nat) = 2 ^ 2 := by norm_num
    _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
  unfold altIndex; split <;> omega

/-! ### The nine cases of the witness construction

With `H = 2 ^ q` the last doubling step splits the index range into a low half `< H` and a
high half `H + ·`.  In most cases the new imaginary unit `e_H` itself is a witness; in the
degenerate configurations a low (or high) index in `{1,2}` is used instead. -/

theorem assocNeg_ll (q i j : Nat) (hi : i < 2 ^ q) (hj : j < 2 ^ q) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) : assocNeg (q + 1) i (2 ^ q + 0) j = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hx1 : i ^^^ (2 ^ q + 0) = 2 ^ q + i := by rw [xor_low_high hi h0, Nat.xor_zero]
  have hx2 : (2 ^ q + 0) ^^^ j = 2 ^ q + j := by rw [xor_high_low h0 hj, Nat.zero_xor]
  have hsw := epsNeg_xor_swap q i j hi hj
  rw [decide_eq_true (show i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j from ⟨hi0, hj0, hij⟩)] at hsw
  rw [assocNeg, hx1, hx2, epsNeg_succ_low_high q i 0 hi,
    epsNeg_succ_high_low q i j hj, epsNeg_succ_high_low q 0 j hj,
    epsNeg_succ_low_high q i j hi]
  simp only [epsNeg_zero_left]
  cases hu : epsNeg q i j <;> cases hv : epsNeg q j i <;> cases hw : conjNeg j <;> simp_all

theorem assocNeg_lh_gen (q i j' : Nat) (hi : i < 2 ^ q) (hj' : j' < 2 ^ q) (hi0 : i ≠ 0)
    (hj'0 : j' ≠ 0) (hij : i ≠ j') :
    assocNeg (q + 1) i (2 ^ q + 0) (2 ^ q + j') = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hx1 : i ^^^ (2 ^ q + 0) = 2 ^ q + i := by rw [xor_low_high hi h0, Nat.xor_zero]
  have hx2 : (2 ^ q + 0) ^^^ (2 ^ q + j') = j' := by rw [xor_high_high h0 hj', Nat.zero_xor]
  have hcn : conjNeg j' = true := by simp [conjNeg, hj'0]
  have hsw := epsNeg_xor_swap q i j' hi hj'
  rw [decide_eq_true (show i ≠ 0 ∧ j' ≠ 0 ∧ i ≠ j' from ⟨hi0, hj'0, hij⟩)] at hsw
  rw [assocNeg, hx1, hx2, epsNeg_succ_low_high q i 0 hi,
    epsNeg_succ_high_high q i j', epsNeg_succ_high_high q 0 j',
    epsNeg_succ_low_low q i j' hi hj', hcn]
  simp only [epsNeg_zero_left, epsNeg_zero_right]
  cases hu : epsNeg q i j' <;> cases hv : epsNeg q j' i <;> simp_all

theorem assocNeg_lh_deg_zero (q i k : Nat) (hi : i < 2 ^ q) (hk : k < 2 ^ q) (hi0 : i ≠ 0)
    (hk0 : k ≠ 0) (hik : i ≠ k) : assocNeg (q + 1) i k (2 ^ q + 0) = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hxik : i ^^^ k < 2 ^ q := Nat.xor_lt_two_pow hi hk
  have hx2 : k ^^^ (2 ^ q + 0) = 2 ^ q + k := by rw [xor_low_high hk h0, Nat.xor_zero]
  have hsw := epsNeg_xor_swap q i k hi hk
  rw [decide_eq_true (show i ≠ 0 ∧ k ≠ 0 ∧ i ≠ k from ⟨hi0, hk0, hik⟩)] at hsw
  rw [assocNeg, hx2, epsNeg_succ_low_low q i k hi hk,
    epsNeg_succ_low_high q (i ^^^ k) 0 hxik, epsNeg_succ_low_high q k 0 hk,
    epsNeg_succ_low_high q i k hi]
  simp only [epsNeg_zero_left]
  cases hu : epsNeg q i k <;> cases hv : epsNeg q k i <;> simp_all

theorem assocNeg_lh_deg_eq (q i k : Nat) (hi : i < 2 ^ q) (hk : k < 2 ^ q) (hi0 : i ≠ 0)
    (hk0 : k ≠ 0) (hik : i ≠ k) : assocNeg (q + 1) i k (2 ^ q + i) = true := by
  have hxik : i ^^^ k < 2 ^ q := Nat.xor_lt_two_pow hi hk
  have hxki : k ^^^ i < 2 ^ q := Nat.xor_lt_two_pow hk hi
  have hx2 : k ^^^ (2 ^ q + i) = 2 ^ q + (k ^^^ i) := xor_low_high hk hi
  have hne1 : i ^^^ k ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hik
  have hne2 : i ≠ i ^^^ k := by
    intro h
    apply hk0
    have h2 : i ^^^ (i ^^^ k) = i ^^^ i := by rw [← h]
    rw [Nat.xor_xor_cancel_left, Nat.xor_self] at h2
    exact h2
  have hsw := epsNeg_xor_swap q i (i ^^^ k) hi hxik
  rw [decide_eq_true (show i ≠ 0 ∧ i ^^^ k ≠ 0 ∧ i ≠ i ^^^ k from ⟨hi0, hne1, hne2⟩)] at hsw
  rw [assocNeg, hx2, epsNeg_succ_low_low q i k hi hk,
    epsNeg_succ_low_high q (i ^^^ k) i hxik, epsNeg_succ_low_high q k i hk,
    epsNeg_succ_low_high q i (k ^^^ i) hi, Nat.xor_comm k i]
  cases hu : epsNeg q i k <;> cases hv : epsNeg q i (i ^^^ k) <;>
    cases hw : epsNeg q (i ^^^ k) i <;> simp_all

theorem assocNeg_hl_gen (q i' j : Nat) (hi' : i' < 2 ^ q) (hj : j < 2 ^ q) (hi'0 : i' ≠ 0)
    (hj0 : j ≠ 0) (hij : i' ≠ j) :
    assocNeg (q + 1) (2 ^ q + i') (2 ^ q + 0) j = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hx1 : (2 ^ q + i') ^^^ (2 ^ q + 0) = i' := by
    rw [xor_high_high hi' h0, Nat.xor_zero]
  have hx2 : (2 ^ q + 0) ^^^ j = 2 ^ q + j := by rw [xor_high_low h0 hj, Nat.zero_xor]
  have hcn : conjNeg j = true := by simp [conjNeg, hj0]
  have hsw := epsNeg_xor_swap q i' j hi' hj
  rw [decide_eq_true (show i' ≠ 0 ∧ j ≠ 0 ∧ i' ≠ j from ⟨hi'0, hj0, hij⟩)] at hsw
  rw [assocNeg, hx1, hx2, epsNeg_succ_high_high q i' 0, epsNeg_succ_low_low q i' j hi' hj,
    epsNeg_succ_high_low q 0 j hj, epsNeg_succ_high_high q i' j, hcn]
  simp only [epsNeg_zero_left, conjNeg]
  cases hu : epsNeg q i' j <;> cases hv : epsNeg q j i' <;> simp_all

theorem assocNeg_hl_zero (q j k : Nat) (hj : j < 2 ^ q) (hk : k < 2 ^ q) (hj0 : j ≠ 0)
    (hk0 : k ≠ 0) (hkj : k ≠ j) : assocNeg (q + 1) (2 ^ q + 0) k j = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hxkj : k ^^^ j < 2 ^ q := Nat.xor_lt_two_pow hk hj
  have hx1 : (2 ^ q + 0) ^^^ k = 2 ^ q + k := by rw [xor_high_low h0 hk, Nat.zero_xor]
  have hcnk : conjNeg k = true := by simp [conjNeg, hk0]
  have hcnj : conjNeg j = true := by simp [conjNeg, hj0]
  have hcnkj : conjNeg (k ^^^ j) = true := by
    have : k ^^^ j ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hkj
    simp [conjNeg, this]
  rw [assocNeg, hx1, epsNeg_succ_high_low q 0 k hk, epsNeg_succ_high_low q k j hj,
    epsNeg_succ_low_low q k j hk hj, epsNeg_succ_high_low q 0 (k ^^^ j) hxkj,
    hcnk, hcnj, hcnkj]
  simp only [epsNeg_zero_left]
  cases hu : epsNeg q k j <;> simp

theorem assocNeg_hl_eq (q j k' : Nat) (hj : j < 2 ^ q) (hk' : k' < 2 ^ q) (hj0 : j ≠ 0)
    (hk'0 : k' ≠ 0) (hk'j : k' ≠ j) :
    assocNeg (q + 1) (2 ^ q + j) (2 ^ q + k') j = true := by
  have hxjk : j ^^^ k' < 2 ^ q := Nat.xor_lt_two_pow hj hk'
  have hxkj : k' ^^^ j < 2 ^ q := Nat.xor_lt_two_pow hk' hj
  have hx1 : (2 ^ q + j) ^^^ (2 ^ q + k') = j ^^^ k' := xor_high_high hj hk'
  have hx2 : (2 ^ q + k') ^^^ j = 2 ^ q + (k' ^^^ j) := xor_high_low hk' hj
  have hcnk : conjNeg k' = true := by simp [conjNeg, hk'0]
  have hcnj : conjNeg j = true := by simp [conjNeg, hj0]
  have hcnkj : conjNeg (k' ^^^ j) = true := by
    have : k' ^^^ j ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hk'j
    simp [conjNeg, this]
  rw [assocNeg, hx1, hx2, epsNeg_succ_high_high q j k',
    epsNeg_succ_low_low q (j ^^^ k') j hxjk hj, epsNeg_succ_high_low q k' j hj,
    epsNeg_succ_high_high q j (k' ^^^ j), hcnk, hcnj, hcnkj, Nat.xor_comm j k']
  cases hu : epsNeg q k' j <;> cases hv : epsNeg q (k' ^^^ j) j <;> simp

theorem assocNeg_hh_gen (q i' j' : Nat) (hi' : i' < 2 ^ q) (hj' : j' < 2 ^ q) (hi'0 : i' ≠ 0)
    (hj'0 : j' ≠ 0) (hij : i' ≠ j') :
    assocNeg (q + 1) (2 ^ q + i') (2 ^ q + 0) (2 ^ q + j') = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hx1 : (2 ^ q + i') ^^^ (2 ^ q + 0) = i' := by
    rw [xor_high_high hi' h0, Nat.xor_zero]
  have hx2 : (2 ^ q + 0) ^^^ (2 ^ q + j') = j' := by rw [xor_high_high h0 hj', Nat.zero_xor]
  have hcn : conjNeg j' = true := by simp [conjNeg, hj'0]
  have hsw := epsNeg_xor_swap q i' j' hi' hj'
  rw [decide_eq_true (show i' ≠ 0 ∧ j' ≠ 0 ∧ i' ≠ j' from ⟨hi'0, hj'0, hij⟩)] at hsw
  rw [assocNeg, hx1, hx2, epsNeg_succ_high_high q i' 0, epsNeg_succ_low_high q i' j' hi',
    epsNeg_succ_high_high q 0 j', epsNeg_succ_high_low q i' j' hj', hcn]
  simp only [epsNeg_zero_left, epsNeg_zero_right, conjNeg]
  cases hu : epsNeg q i' j' <;> cases hv : epsNeg q j' i' <;> simp_all

theorem assocNeg_hh_i0 (q j' k : Nat) (hj' : j' < 2 ^ q) (hk : k < 2 ^ q) (hj'0 : j' ≠ 0)
    (hk0 : k ≠ 0) (hkj : k ≠ j') :
    assocNeg (q + 1) (2 ^ q + 0) k (2 ^ q + j') = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hxkj : k ^^^ j' < 2 ^ q := Nat.xor_lt_two_pow hk hj'
  have hx1 : (2 ^ q + 0) ^^^ k = 2 ^ q + k := by rw [xor_high_low h0 hk, Nat.zero_xor]
  have hx2 : k ^^^ (2 ^ q + j') = 2 ^ q + (k ^^^ j') := xor_low_high hk hj'
  have hcnk : conjNeg k = true := by simp [conjNeg, hk0]
  have hcnj : conjNeg j' = true := by simp [conjNeg, hj'0]
  have hcnkj : conjNeg (k ^^^ j') = true := by
    have : k ^^^ j' ≠ 0 := by simpa [Nat.xor_eq_zero_iff] using hkj
    simp [conjNeg, this]
  rw [assocNeg, hx1, hx2, epsNeg_succ_high_low q 0 k hk, epsNeg_succ_high_high q k j',
    epsNeg_succ_low_high q k j' hk, epsNeg_succ_high_high q 0 (k ^^^ j'),
    hcnk, hcnj, hcnkj]
  simp only [epsNeg_zero_left, epsNeg_zero_right]
  cases hu : epsNeg q j' k <;> simp

theorem assocNeg_hh_j0 (q i' k : Nat) (hi' : i' < 2 ^ q) (hk : k < 2 ^ q) (hi'0 : i' ≠ 0)
    (hk0 : k ≠ 0) (hki : k ≠ i') :
    assocNeg (q + 1) (2 ^ q + i') k (2 ^ q + 0) = true := by
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  have hxik : i' ^^^ k < 2 ^ q := Nat.xor_lt_two_pow hi' hk
  have hx1 : (2 ^ q + i') ^^^ k = 2 ^ q + (i' ^^^ k) := xor_high_low hi' hk
  have hx2 : k ^^^ (2 ^ q + 0) = 2 ^ q + k := by rw [xor_low_high hk h0, Nat.xor_zero]
  have hcnk : conjNeg k = true := by simp [conjNeg, hk0]
  have hsw := epsNeg_xor_swap q i' k hi' hk
  rw [decide_eq_true (show i' ≠ 0 ∧ k ≠ 0 ∧ i' ≠ k from ⟨hi'0, hk0, fun h => hki h.symm⟩)] at hsw
  rw [assocNeg, hx1, hx2, epsNeg_succ_high_low q i' k hk, epsNeg_succ_high_high q (i' ^^^ k) 0,
    epsNeg_succ_low_high q k 0 hk, epsNeg_succ_high_high q i' k, hcnk]
  simp only [epsNeg_zero_left, conjNeg]
  cases hu : epsNeg q i' k <;> cases hv : epsNeg q k i' <;> simp_all

/-- **Existence of a non-associative triple.** In every algebra of the tower of dimension
`2ⁿ ≥ 8` (octonions and beyond) any two distinct non-real basis vectors fail to associate
with some third basis vector. -/
theorem exists_assocNeg_witness (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    ∃ k, k < 2 ^ n ∧ assocNeg n i k j = true := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 1 := ⟨n - 1, by omega⟩
  have hq : 2 ≤ q := by omega
  have hpow : 2 ^ (q + 1) = 2 ^ q + 2 ^ q := by rw [pow_succ]; ring
  have h0 : (0 : Nat) < 2 ^ q := by positivity
  by_cases hA : i < 2 ^ q <;> by_cases hB : j < 2 ^ q
  · exact ⟨2 ^ q + 0, by omega, assocNeg_ll q i j hA hB hi0 hj0 hij⟩
  · obtain ⟨j', hj', rfl⟩ : ∃ p, p < 2 ^ q ∧ j = 2 ^ q + p := ⟨j - 2 ^ q, by omega, by omega⟩
    by_cases hj'0 : j' = 0
    · subst hj'0
      exact ⟨altIndex i, by have := altIndex_lt i q hq; omega,
        assocNeg_lh_deg_zero q i (altIndex i) hA (altIndex_lt i q hq) hi0
          (altIndex_ne_zero i) (fun h => altIndex_ne i h.symm)⟩
    · by_cases hj'i : j' = i
      · subst hj'i
        exact ⟨altIndex j', by have := altIndex_lt j' q hq; omega,
          assocNeg_lh_deg_eq q j' (altIndex j') hA (altIndex_lt j' q hq) hi0
            (altIndex_ne_zero j') (fun h => altIndex_ne j' h.symm)⟩
      · exact ⟨2 ^ q + 0, by omega,
          assocNeg_lh_gen q i j' hA hj' hi0 hj'0 (fun h => hj'i h.symm)⟩
  · obtain ⟨i', hi', rfl⟩ : ∃ p, p < 2 ^ q ∧ i = 2 ^ q + p := ⟨i - 2 ^ q, by omega, by omega⟩
    by_cases hi'0 : i' = 0
    · subst hi'0
      exact ⟨altIndex j, by have := altIndex_lt j q hq; omega,
        assocNeg_hl_zero q j (altIndex j) hB (altIndex_lt j q hq) hj0
          (altIndex_ne_zero j) (altIndex_ne j)⟩
    · by_cases hi'j : i' = j
      · subst hi'j
        exact ⟨2 ^ q + altIndex i', by have := altIndex_lt i' q hq; omega,
          assocNeg_hl_eq q i' (altIndex i') hB (altIndex_lt i' q hq) hj0
            (altIndex_ne_zero i') (altIndex_ne i')⟩
      · exact ⟨2 ^ q + 0, by omega, assocNeg_hl_gen q i' j hi' hB hi'0 hj0 hi'j⟩
  · obtain ⟨i', hi', rfl⟩ : ∃ p, p < 2 ^ q ∧ i = 2 ^ q + p := ⟨i - 2 ^ q, by omega, by omega⟩
    obtain ⟨j', hj', rfl⟩ : ∃ p, p < 2 ^ q ∧ j = 2 ^ q + p := ⟨j - 2 ^ q, by omega, by omega⟩
    have hij' : i' ≠ j' := by omega
    by_cases hi'0 : i' = 0
    · subst hi'0
      have hj'0' : j' ≠ 0 := fun h => hij' (by omega)
      exact ⟨altIndex j', by have := altIndex_lt j' q hq; omega,
        assocNeg_hh_i0 q j' (altIndex j') hj' (altIndex_lt j' q hq) hj'0'
          (altIndex_ne_zero j') (altIndex_ne j')⟩
    · by_cases hj'0' : j' = 0
      · subst hj'0'
        exact ⟨altIndex i', by have := altIndex_lt i' q hq; omega,
          assocNeg_hh_j0 q i' (altIndex i') hi' (altIndex_lt i' q hq) hi'0
            (altIndex_ne_zero i') (altIndex_ne i')⟩
      · exact ⟨2 ^ q + 0, by omega, assocNeg_hh_gen q i' j' hi' hj' hi'0 hj'0' hij'⟩

/-! ## 6. The general index criterion -/

theorem sign_exists_iff (s t e1 e2 e3 e4 : Bool) :
    (∃ u r : Bool, xor s (xor u e1) ≠ xor t (xor r e4) ∧
        xor s (xor r e2) ≠ xor t (xor u e3))
      ↔ xor e1 (xor e4 (xor e2 e3)) = false := by
  decide +revert

/-- For a fixed pair of index data, a choice of signs making the two cross-half vectors
annihilate exists exactly when `crossSign` holds. -/
theorem exists_signs_iff_crossSign (n : Nat) (s t : Bool) (i j k m : Nat) (hi : i < 2 ^ n)
    (hk : k < 2 ^ n) :
    (∃ u r : Bool,
        xor s (xor u (epsNeg (n + 1) i k)) ≠ xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m)))
        ∧ xor s (xor r (epsNeg (n + 1) i (2 ^ n + m)))
            ≠ xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k)))
      ↔ crossSign n i j k m = true := by
  rw [sign_exists_iff, epsNeg_succ_low_low n i k hi hk, epsNeg_succ_high_high n j m,
    epsNeg_succ_low_high n i m hi, epsNeg_succ_high_low n j k hk, crossSign]
  cases epsNeg n i k <;> cases epsNeg n m j <;> cases epsNeg n m i <;> cases epsNeg n j k <;>
    cases conjNeg k <;> cases conjNeg m <;> simp

theorem hasCrossPartner_iff (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n) :
    hasCrossPartner n s t i j = true ↔
      ∃ k m, k < 2 ^ n ∧ m < 2 ^ n ∧ k ^^^ m = i ^^^ j ∧ crossSign n i j k m = true := by
  simp only [hasCrossPartner, List.any_eq_true, List.mem_range, List.mem_cons,
    List.not_mem_nil, or_false, Bool.and_eq_true, decide_eq_true_iff]
  constructor
  · rintro ⟨k, hk, m, hm, u, -, r, -, ⟨hcharge, h1⟩, h2⟩
    exact ⟨k, m, hk, hm, hcharge.symm,
      (exists_signs_iff_crossSign n s t i j k m hi hk).1 ⟨u, r, h1, h2⟩⟩
  · rintro ⟨k, m, hk, hm, hcharge, hsign⟩
    obtain ⟨u, r, h1, h2⟩ := (exists_signs_iff_crossSign n s t i j k m hi hk).2 hsign
    exact ⟨k, hk, m, hm, u, by cases u <;> simp, r, by cases r <;> simp,
      ⟨hcharge.symm, h1⟩, h2⟩

theorem assocNeg_zero_left (n k j : Nat) : assocNeg n 0 k j = false := by
  simp only [assocNeg, Nat.zero_xor, epsNeg_zero_left]
  cases epsNeg n k j <;> simp

theorem assocNeg_zero_right (n i k : Nat) : assocNeg n i k 0 = false := by
  simp only [assocNeg, Nat.xor_zero, epsNeg_zero_right]
  cases epsNeg n i k <;> simp

/-- **The index criterion in every dimension.**  For every `n ≥ 3`, i.e. in every
Cayley–Dickson algebra of dimension `2ⁿ⁺¹ ≥ 16`, a cross-half vector `±e_i ± e_{H+j}`
annihilates another cross-half vector exactly when `i ≠ 0`, `j ≠ 0` and `i ≠ j`. -/
theorem index_criterion_general (n : Nat) (hn : 3 ≤ n) (s t : Bool) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    hasCrossPartner n s t i j = decide (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  by_cases hcrit : i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j
  · obtain ⟨hi0, hj0, hij⟩ := hcrit
    obtain ⟨k, hk, hassoc⟩ := exists_assocNeg_witness n hn i j hi hj hi0 hj0 hij
    have hm : k ^^^ (i ^^^ j) < 2 ^ n :=
      Nat.xor_lt_two_pow hk (Nat.xor_lt_two_pow hi hj)
    have hcharge : k ^^^ (k ^^^ (i ^^^ j)) = i ^^^ j := Nat.xor_xor_cancel_left k (i ^^^ j)
    rw [decide_eq_true (show i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j from ⟨hi0, hj0, hij⟩)]
    refine (hasCrossPartner_iff n s t i j hi).2 ⟨k, k ^^^ (i ^^^ j), hk, hm, hcharge, ?_⟩
    rw [crossSign_eq_assocNeg n i j k hi hj hk]
    exact hassoc
  · rw [decide_eq_false hcrit]
    by_contra hcon
    have htrue : hasCrossPartner n s t i j = true := by
      cases h : hasCrossPartner n s t i j
      · exact absurd h hcon
      · rfl
    obtain ⟨k, m, hk, hm, hcharge, hsign⟩ := (hasCrossPartner_iff n s t i j hi).1 htrue
    have hmk : m = k ^^^ (i ^^^ j) := by
      rw [← hcharge, Nat.xor_xor_cancel_left]
    subst hmk
    rw [crossSign_eq_assocNeg n i j k hi hj hk] at hsign
    have hfalse : assocNeg n i k j = false := by
      by_cases hi0 : i = 0
      · subst hi0; exact assocNeg_zero_left n k j
      · by_cases hj0 : j = 0
        · subst hj0; exact assocNeg_zero_right n i k
        · have hij : i = j := by
            by_contra h
            exact hcrit ⟨hi0, hj0, h⟩
          subst hij
          exact assocNeg_self n i k hi hk
    rw [hfalse] at hsign
    exact Bool.false_ne_true hsign

/-- Algebraic form of the general index criterion. -/
theorem crossVec_zero_divisor_iff (n : Nat) (hn : 3 ≤ n) (s t : Bool) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    (∃ u r k m, k < 2 ^ n ∧ m < 2 ^ n ∧ crossVec n u k r m ≠ 0 ∧
        crossVec n s i t j * crossVec n u k r m = 0)
      ↔ (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  rw [exists_crossVec_annihilator_iff n s t i j hi hj,
    index_criterion_general n hn s t i j hi hj, decide_eq_true_iff]

/-- **Characterisation of non-associative pairs.**  In every algebra of the tower of
dimension `2ⁿ ≥ 8`, two basis vectors fail to associate with a third one exactly when they
are distinct and non-real. -/
theorem exists_nonassoc_iff (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) :
    (∃ k, k < 2 ^ n ∧ (basis n i * basis n k) * basis n j
        ≠ basis n i * (basis n k * basis n j))
      ↔ (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  constructor
  · rintro ⟨k, hk, hne⟩
    by_contra hcrit
    apply hne
    refine (basis_assoc_eq_iff n i k j hi hk hj).mpr ?_
    by_cases hi0 : i = 0
    · subst hi0; exact assocNeg_zero_left n k j
    · by_cases hj0 : j = 0
      · subst hj0; exact assocNeg_zero_right n i k
      · have hij : i = j := by
          by_contra h
          exact hcrit ⟨hi0, hj0, h⟩
        subst hij
        exact assocNeg_self n i k hi hk
  · rintro ⟨hi0, hj0, hij⟩
    obtain ⟨k, hk, hassoc⟩ := exists_assocNeg_witness n hn i j hi hj hi0 hj0 hij
    refine ⟨k, hk, fun h => ?_⟩
    rw [(basis_assoc_eq_iff n i k j hi hk hj).mp h] at hassoc
    exact Bool.false_ne_true hassoc

/-- **Cross-half zero divisors are exactly the non-associative pairs.**  For `n ≥ 3` the
cross-half vector `±e_i ± e_{H+j}` of the `2ⁿ⁺¹`-dimensional algebra annihilates a non-zero
cross-half vector if and only if `e_i` and `e_j` fail to associate with some `e_k`. -/
theorem crossVec_annihilator_iff_nonassoc (n : Nat) (hn : 3 ≤ n) (s t : Bool) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    (∃ u r k m, k < 2 ^ n ∧ m < 2 ^ n ∧ crossVec n u k r m ≠ 0 ∧
        crossVec n s i t j * crossVec n u k r m = 0)
      ↔ ∃ k, k < 2 ^ n ∧ (basis n i * basis n k) * basis n j
          ≠ basis n i * (basis n k * basis n j) := by
  rw [crossVec_zero_divisor_iff n hn s t i j hi hj, exists_nonassoc_iff n hn i j hi hj]

/-- **Zero divisors exist in every dimension `2ⁿ⁺¹ ≥ 16`.**  The cross-half vector
`e₁ + e_{H+2}` annihilates a non-zero cross-half vector. -/
theorem exists_zero_divisor (n : Nat) (hn : 3 ≤ n) :
    ∃ v w : Tower (n + 1), v ≠ 0 ∧ w ≠ 0 ∧ v * w = 0 := by
  have h8 : (8 : Nat) ≤ 2 ^ n := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  have h1 : 1 < 2 ^ n := by omega
  have h2 : 2 < 2 ^ n := by omega
  obtain ⟨u, r, k, m, hk, hm, hwne, hzero⟩ :=
    (crossVec_zero_divisor_iff n hn false false 1 2 h1 h2).2 ⟨by norm_num, by norm_num, by norm_num⟩
  exact ⟨crossVec n false 1 false 2, crossVec n u k r m,
    crossVec_ne_zero n false false 1 2 h1 h2, hwne, hzero⟩

/-- Every algebra of the tower of dimension `2ⁿ ≥ 8` is non-associative. -/
theorem exists_nonassoc_triple (n : Nat) (hn : 3 ≤ n) :
    ∃ x y z : Tower n, (x * y) * z ≠ x * (y * z) := by
  have h8 : (8 : Nat) ≤ 2 ^ n := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  obtain ⟨k, hk, hne⟩ :=
    (exists_nonassoc_iff n hn 1 2 (by omega) (by omega)).2 ⟨by norm_num, by norm_num, by norm_num⟩
  exact ⟨basis n 1, basis n k, basis n 2, hne⟩

/-! ## 7. The finite checks as instances of the general theorem

The dimension-by-dimension index criteria of `TowerZeroDivisors` were closed by compiler
evaluation; they are instances of `index_criterion_general`, and the versions below are
therefore checked by the kernel alone. -/

end Sovereign
