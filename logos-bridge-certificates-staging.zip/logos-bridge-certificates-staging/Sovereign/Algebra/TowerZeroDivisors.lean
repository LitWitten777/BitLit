import Sovereign.Algebra.TowerBasis
import Sovereign.Algebra.UniversalDecoupling

namespace Sovereign

/-! ## 1. Coordinates -/

/-- The `a`-th coordinate of a tower element with respect to the basis. -/
def coeff : (n : Nat) → Tower n → Nat → Int
  | 0, x, _ => x
  | n + 1, x, a => if a < 2 ^ n then coeff n x.re a else coeff n x.im (a - 2 ^ n)

@[simp] theorem coeff_zero (n : Nat) (a : Nat) : coeff n 0 a = 0 := by
  induction n generalizing a with
  | zero => rfl
  | succ n ih => by_cases h : a < 2 ^ n <;> simp [coeff, h, ih]

theorem coeff_add (n : Nat) (x y : Tower n) (a : Nat) :
    coeff n (x + y) a = coeff n x a + coeff n y a := by
  induction n generalizing a with
  | zero => rfl
  | succ n ih => by_cases h : a < 2 ^ n <;> simp [coeff, h, ih]

theorem coeff_neg (n : Nat) (x : Tower n) (a : Nat) : coeff n (-x) a = -coeff n x a := by
  induction n generalizing a with
  | zero => rfl
  | succ n ih => by_cases h : a < 2 ^ n <;> simp [coeff, h, ih]

theorem coeff_signed (n : Nat) (s : Bool) (x : Tower n) (a : Nat) :
    coeff n (signed s x) a = if s then -coeff n x a else coeff n x a := by
  cases s <;> simp [signed, coeff_neg]

/-- A tower element is zero iff all of its coordinates vanish. -/
theorem coeff_eq_zero_iff : ∀ (n : Nat) (x : Tower n),
    x = 0 ↔ ∀ a, a < 2 ^ n → coeff n x a = 0 := by
  intro n
  induction n with
  | zero =>
    intro x
    constructor
    · rintro rfl a _; rfl
    · intro h
      exact h 0 (by norm_num)
  | succ n ih =>
    intro x
    constructor
    · rintro rfl a _; simp
    · intro h
      have hre : x.re = 0 := by
        refine (ih x.re).2 (fun a ha => ?_)
        have := h a (by
          have : (2 : Nat) ^ n ≤ 2 ^ (n + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
          omega)
        simpa [coeff, ha] using this
      have him : x.im = 0 := by
        refine (ih x.im).2 (fun a ha => ?_)
        have hlt : 2 ^ n + a < 2 ^ (n + 1) := by
          have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
          omega
        have := h (2 ^ n + a) hlt
        have hnot : ¬ (2 ^ n + a < 2 ^ n) := by omega
        simpa [coeff, hnot] using this
      exact CD.ext (by simpa using hre) (by simpa using him)

/-- Coordinates of a basis vector. -/
theorem coeff_basis : ∀ (n a b : Nat), a < 2 ^ n → b < 2 ^ n →
    coeff n (basis n a) b = if a = b then 1 else 0 := by
  intro n
  induction n with
  | zero =>
    intro a b ha hb
    have ha0 : a = 0 := by simpa using ha
    have hb0 : b = 0 := by simpa using hb
    subst ha0; subst hb0
    rfl
  | succ n ih =>
    intro a b ha hb
    by_cases hA : a < 2 ^ n <;> by_cases hB : b < 2 ^ n
    · have e1 : basis (n + 1) a = (⟨basis n a, 0⟩ : CD (Tower n)) := by simp [basis, hA]
      rw [e1]
      simpa [coeff, hB] using ih a b hA hB
    · have e1 : basis (n + 1) a = (⟨basis n a, 0⟩ : CD (Tower n)) := by simp [basis, hA]
      have hne : a ≠ b := by omega
      rw [e1]
      simp [coeff, hB, hne]
    · have e1 : basis (n + 1) a = (⟨0, basis n (a - 2 ^ n)⟩ : CD (Tower n)) := by simp [basis, hA]
      have hne : a ≠ b := by omega
      rw [e1]
      simp [coeff, hB, hne]
    · have hp : a - 2 ^ n < 2 ^ n := by
        have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
        omega
      have hq : b - 2 ^ n < 2 ^ n := by
        have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
        omega
      have e1 : basis (n + 1) a = (⟨0, basis n (a - 2 ^ n)⟩ : CD (Tower n)) := by simp [basis, hA]
      have hiff : (a - 2 ^ n = b - 2 ^ n) ↔ (a = b) := by omega
      rw [e1]
      simp only [coeff, hB, if_false]
      rw [ih (a - 2 ^ n) (b - 2 ^ n) hp hq]
      simp [hiff]

theorem coeff_signed_basis (n : Nat) (s : Bool) (a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    coeff n (signed s (basis n a)) b = if a = b then (if s then -1 else 1) else 0 := by
  rw [coeff_signed, coeff_basis n a b ha hb]
  cases s <;> by_cases h : a = b <;> simp [h]

/-! ## 2. Cross-half vectors -/

/-- The cross-half vector `signed s e_i + signed t e_{2ⁿ+j}` of `Tower (n+1)`. -/
def crossVec (n : Nat) (s : Bool) (i : Nat) (t : Bool) (j : Nat) : Tower (n + 1) :=
  signed s (basis (n + 1) i) + signed t (basis (n + 1) (2 ^ n + j))

/-- The four-term expansion of a product of cross-half vectors. -/
theorem crossVec_mul_expand (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hm : m < 2 ^ n) :
    crossVec n s i t j * crossVec n u k r m
      = (signed (xor s (xor u (epsNeg (n + 1) i k))) (basis (n + 1) (i ^^^ k))
          + signed (xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m))))
              (basis (n + 1) (j ^^^ m)))
        + (signed (xor s (xor r (epsNeg (n + 1) i (2 ^ n + m))))
              (basis (n + 1) (2 ^ n + (i ^^^ m)))
          + signed (xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k)))
              (basis (n + 1) (2 ^ n + (j ^^^ k)))) := by
  have hlt : ∀ x : Nat, x < 2 ^ n → x < 2 ^ (n + 1) := by
    intro x hx
    have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    omega
  have hlt' : ∀ x : Nat, x < 2 ^ n → 2 ^ n + x < 2 ^ (n + 1) := by
    intro x hx
    have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    omega
  have h1 := signedBasis_mul (n + 1) s u i k (hlt i hi) (hlt k hk)
  have h2 := signedBasis_mul (n + 1) s r i (2 ^ n + m) (hlt i hi) (hlt' m hm)
  have h3 := signedBasis_mul (n + 1) t u (2 ^ n + j) k (hlt' j hj) (hlt k hk)
  have h4 := signedBasis_mul (n + 1) t r (2 ^ n + j) (2 ^ n + m) (hlt' j hj) (hlt' m hm)
  rw [xor_low_high hi hm] at h2
  rw [xor_high_low hj hk] at h3
  rw [xor_high_high hj hm] at h4
  rw [crossVec, crossVec, tower_add_mul, tower_mul_add, tower_mul_add, h1, h2, h3, h4]
  abel

/-! ## 3. The general annihilation criterion -/

theorem signed_add_signed_of_ne {n : Nat} {s t : Bool} (h : s ≠ t) (x : Tower n) :
    signed s x + signed t x = 0 := by
  cases s <;> cases t <;> simp_all [signed]

/-- **General cross-half annihilation criterion.** In the Cayley–Dickson algebra of
dimension `2ⁿ⁺¹`, two cross-half vectors annihilate exactly when their XOR charges agree
and the two decoupled sign cancellations both hold. -/
theorem crossVec_mul_eq_zero_iff (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hm : m < 2 ^ n) :
    crossVec n s i t j * crossVec n u k r m = 0 ↔
      (i ^^^ j = k ^^^ m ∧
        xor s (xor u (epsNeg (n + 1) i k))
          ≠ xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m))) ∧
        xor s (xor r (epsNeg (n + 1) i (2 ^ n + m)))
          ≠ xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k))) := by
  have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
  have hik : i ^^^ k < 2 ^ n := Nat.xor_lt_two_pow hi hk
  have hjm : j ^^^ m < 2 ^ n := Nat.xor_lt_two_pow hj hm
  have him : i ^^^ m < 2 ^ n := Nat.xor_lt_two_pow hi hm
  have hjk : j ^^^ k < 2 ^ n := Nat.xor_lt_two_pow hj hk
  rw [crossVec_mul_expand n s t u r i j k m hi hj hk hm]
  set s1 := xor s (xor u (epsNeg (n + 1) i k)) with hs1
  set s4 := xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m))) with hs4
  set s2 := xor s (xor r (epsNeg (n + 1) i (2 ^ n + m))) with hs2
  set s3 := xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k)) with hs3
  clear_value s1 s4 s2 s3
  clear hs1 hs4 hs2 hs3
  constructor
  · intro h
    have hco := (coeff_eq_zero_iff (n + 1) _).1 h
    -- coordinate at the low index `i ^^^ k`
    have hlow := hco (i ^^^ k) (by omega)
    have hhigh := hco (2 ^ n + (i ^^^ m)) (by omega)
    rw [coeff_add, coeff_add, coeff_add,
      coeff_signed_basis (n + 1) s1 (i ^^^ k) (i ^^^ k) (by omega) (by omega),
      coeff_signed_basis (n + 1) s4 (j ^^^ m) (i ^^^ k) (by omega) (by omega),
      coeff_signed_basis (n + 1) s2 (2 ^ n + (i ^^^ m)) (i ^^^ k) (by omega) (by omega),
      coeff_signed_basis (n + 1) s3 (2 ^ n + (j ^^^ k)) (i ^^^ k) (by omega) (by omega)] at hlow
    rw [coeff_add, coeff_add, coeff_add,
      coeff_signed_basis (n + 1) s1 (i ^^^ k) (2 ^ n + (i ^^^ m)) (by omega) (by omega),
      coeff_signed_basis (n + 1) s4 (j ^^^ m) (2 ^ n + (i ^^^ m)) (by omega) (by omega),
      coeff_signed_basis (n + 1) s2 (2 ^ n + (i ^^^ m)) (2 ^ n + (i ^^^ m)) (by omega)
        (by omega),
      coeff_signed_basis (n + 1) s3 (2 ^ n + (j ^^^ k)) (2 ^ n + (i ^^^ m)) (by omega)
        (by omega)] at hhigh
    have hne1 : ¬ (2 ^ n + (i ^^^ m) = i ^^^ k) := by omega
    have hne2 : ¬ (2 ^ n + (j ^^^ k) = i ^^^ k) := by omega
    have hne3 : ¬ (i ^^^ k = 2 ^ n + (i ^^^ m)) := by omega
    have hne4 : ¬ (j ^^^ m = 2 ^ n + (i ^^^ m)) := by omega
    rw [if_neg hne1, if_neg hne2] at hlow
    rw [if_neg hne3, if_neg hne4] at hhigh
    simp only [add_zero, zero_add] at hlow hhigh
    have hidx1 : j ^^^ m = i ^^^ k := by
      by_contra hcon
      rw [if_neg hcon] at hlow
      cases s1 <;> simp at hlow
    have hidx2 : 2 ^ n + (j ^^^ k) = 2 ^ n + (i ^^^ m) := by
      by_contra hcon
      rw [if_neg hcon] at hhigh
      cases s2 <;> simp at hhigh
    rw [if_pos hidx1] at hlow
    rw [if_pos hidx2] at hhigh
    refine ⟨(xor_eq_swap i j k m).mp hidx1.symm, ?_, ?_⟩
    · cases s1 <;> cases s4 <;> simp_all
    · cases s2 <;> cases s3 <;> simp_all
  · rintro ⟨hchi, h14, h23⟩
    have hidx1 : i ^^^ k = j ^^^ m := (xor_eq_swap i j k m).mpr hchi
    have hidx2 : i ^^^ m = j ^^^ k := universal_decoupling_k1_eq_k2 i j k m hchi
    rw [hidx1, hidx2, signed_add_signed_of_ne h14, signed_add_signed_of_ne h23, add_zero]

/-- **Charge conservation in every dimension of the tower.** If two cross-half vectors
annihilate, their XOR charges coincide. -/
theorem crossVec_charge_conservation (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hm : m < 2 ^ n)
    (h : crossVec n s i t j * crossVec n u k r m = 0) :
    i ^^^ j = k ^^^ m :=
  ((crossVec_mul_eq_zero_iff n s t u r i j k m hi hj hk hm).1 h).1

/-! ## 4. Cross-half vectors are non-zero, and the decidable zero-divisor test -/

theorem crossVec_ne_zero (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    crossVec n s i t j ≠ 0 := by
  have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
  intro h
  have hco := (coeff_eq_zero_iff (n + 1) _).1 h i (by omega)
  rw [crossVec, coeff_add,
    coeff_signed_basis (n + 1) s i i (by omega) (by omega),
    coeff_signed_basis (n + 1) t (2 ^ n + j) i (by omega) (by omega)] at hco
  have hne : ¬ (2 ^ n + j = i) := by omega
  rw [if_neg hne, if_pos rfl, add_zero] at hco
  cases s <;> simp at hco

/-- Decidable test for "the cross-half vector `signed s e_i + signed t e_{H+j}` annihilates
some cross-half vector", extracted from the general criterion. -/
def hasCrossPartner (n : Nat) (s t : Bool) (i j : Nat) : Bool :=
  (List.range (2 ^ n)).any fun k => (List.range (2 ^ n)).any fun m =>
    [false, true].any fun u => [false, true].any fun r =>
      decide (i ^^^ j = k ^^^ m) &&
      decide (xor s (xor u (epsNeg (n + 1) i k))
        ≠ xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m)))) &&
      decide (xor s (xor r (epsNeg (n + 1) i (2 ^ n + m)))
        ≠ xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k)))

/-- The decidable test really decides the existence of a (necessarily non-zero) cross-half
annihilator. -/
theorem exists_crossVec_annihilator_iff (n : Nat) (s t : Bool) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    (∃ u r k m, k < 2 ^ n ∧ m < 2 ^ n ∧ crossVec n u k r m ≠ 0 ∧
        crossVec n s i t j * crossVec n u k r m = 0)
      ↔ hasCrossPartner n s t i j = true := by
  simp only [hasCrossPartner, List.any_eq_true, List.mem_range, List.mem_cons,
    List.not_mem_nil, or_false, Bool.and_eq_true, decide_eq_true_iff]
  constructor
  · rintro ⟨u, r, k, m, hk, hm, _, hzero⟩
    obtain ⟨h1, h2, h3⟩ := (crossVec_mul_eq_zero_iff n s t u r i j k m hi hj hk hm).1 hzero
    exact ⟨k, hk, m, hm, u, by cases u <;> simp, r, by cases r <;> simp, ⟨h1, h2⟩, h3⟩
  · rintro ⟨k, hk, m, hm, u, _, r, _, ⟨h1, h2⟩, h3⟩
    exact ⟨u, r, k, m, hk, hm, crossVec_ne_zero n u r k m hk hm,
      (crossVec_mul_eq_zero_iff n s t u r i j k m hi hj hk hm).2 ⟨h1, h2, h3⟩⟩

/-! ## 5. The index criterion in dimensions 16, 32 and 64 -/

/-- **Index criterion, `D = 16`.** Derived from the general criterion rather than from an
exhaustive product computation in the sedenion algebra. -/
theorem index_criterion_16 :
    ∀ s t : Bool, ∀ i ∈ List.range 8, ∀ j ∈ List.range 8,
      hasCrossPartner 3 s t i j = decide (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  decide +kernel

/-- **Index criterion, `D = 32`.** -/
theorem index_criterion_32 :
    ∀ s t : Bool, ∀ i ∈ List.range 16, ∀ j ∈ List.range 16,
      hasCrossPartner 4 s t i j = decide (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  decide +kernel

/-- **Index criterion, `D = 64`.** The same criterion in the chingon algebra, where a
direct evaluation of all cross-half products was out of reach. -/
theorem index_criterion_64 :
    ∀ s t : Bool, ∀ i ∈ List.range 32, ∀ j ∈ List.range 32,
      hasCrossPartner 5 s t i j = decide (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  native_decide

/-- **Index criterion, `D = 128`.** -/
theorem index_criterion_128 :
    ∀ s t : Bool, ∀ i ∈ List.range 64, ∀ j ∈ List.range 64,
      hasCrossPartner 6 s t i j = decide (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  native_decide

/-- Zero-divisor index-pair counts in dimensions 16, 32 and 64: `42 = 7·6`, `210 = 15·14`
and `930 = 31·30`, i.e. `(D-2)(D-4)/4` in each case. -/
theorem zd_index_pair_counts :
    ((List.range 8).flatMap fun i => (List.range 8).filter fun j =>
        hasCrossPartner 3 false false i j).length = 42 ∧
    ((List.range 16).flatMap fun i => (List.range 16).filter fun j =>
        hasCrossPartner 4 false false i j).length = 210 ∧
    ((List.range 32).flatMap fun i => (List.range 32).filter fun j =>
        hasCrossPartner 5 false false i j).length = 930 := by
  native_decide

/-- The annihilation degree of a cross-half zero divisor in dimension 16 is `8`: each of the
168 sedenion cross-octet zero divisors annihilates exactly 8 others. -/
theorem annihilation_degree_16 :
    ∀ s t : Bool, ∀ i ∈ List.range 8, ∀ j ∈ List.range 8, (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) →
      ((List.range 8).flatMap fun k => (List.range 8).flatMap fun m =>
        ([false, true].flatMap fun u => [false, true].filter fun r =>
          decide (i ^^^ j = k ^^^ m) &&
          decide (xor s (xor u (epsNeg 4 i k))
            ≠ xor t (xor r (epsNeg 4 (8 + j) (8 + m)))) &&
          decide (xor s (xor r (epsNeg 4 i (8 + m)))
            ≠ xor t (xor u (epsNeg 4 (8 + j) k))))).length = 8 := by
  decide +kernel

end Sovereign
