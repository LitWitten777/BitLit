import Sovereign.Algebra.LeechSedenionFano
/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Machine-checked cross-octet stratification of the integer sedenions

The theorems in `Sovereign.Algebra.LeechSedenionFano` and `MonographTheorems` (removed by the 2026 curation)
record the *numerical* content of the monograph (`42 * 4 = 168`, …).  They are true,
but they say nothing about the sedenion algebra itself.

This module states and proves the corresponding *structural* facts about the actual
Cayley–Dickson algebra `CDSedenion = CD (CD (CD (CD ℤ)))`:

* the 256 cross-octet vectors `± e i ± e (8 + j)` are pairwise distinct and non-zero;
* such a vector annihilates another cross-octet vector **iff** `i ≠ 0`, `j ≠ 0`, `i ≠ j`
  (`crossOctet_annihilator_iff_index`);
* exactly 168 of them are zero divisors and exactly 88 are not
  (`crossOctetZD_length`, `crossOctetNonZD_length`);
* the annihilation relation is symmetric, is 8-regular on the 168 zero divisors, and
  therefore has 672 undirected edges;
* annihilation conserves the XOR charge `i ^^^ j`, and the 168 zero divisors split into
  the 7 charge sectors `χ ∈ {1, …, 7}` of 24 vectors each.

That the 88 remaining vectors are not zero divisors *in the whole algebra* (a statement
about infinitely many potential partners, hence not a finite check) is proved separately
in `Sovereign.Algebra.SedenionNonZeroDivisors`.

The finite verifications below are discharged by kernel-external evaluation
(`native_decide`) because they involve tens of thousands of exact integer sedenion
products.
-/


set_option maxRecDepth 100000

namespace Sovereign

/-! ## Labelled cross-octet vectors -/

/-- A label `(i, j, s, t)` for the cross-octet vector `s • eᵢ + t • e₈₊ⱼ`. -/
abbrev CrossLabel := Nat × Nat × Int × Int

/-- All 256 labels `(i, j, s, t)` with `i, j < 8` and `s, t ∈ {1, -1}`, in the same
order as `crossOctet`. -/
def crossLabels : List CrossLabel :=
  (List.range 8).flatMap fun i =>
    (List.range 8).flatMap fun j =>
      [(1 : Int), -1].flatMap fun s =>
        [(1 : Int), -1].map fun t => (i, j, s, t)

/-- The cross-octet vector attached to a label. -/
def labelVec (p : CrossLabel) : CDSedenion := crossOctetVec p.1 p.2.1 p.2.2.1 p.2.2.2

theorem crossLabels_length : crossLabels.length = 256 := by decide +kernel

theorem crossOctet_eq_map_labelVec : crossOctet = crossLabels.map labelVec := by decide +kernel

/-- Membership in `crossLabels` is exactly the expected range condition. -/
theorem mem_crossLabels_iff (i j : Nat) (s t : Int) :
    (i, j, s, t) ∈ crossLabels ↔
      i < 8 ∧ j < 8 ∧ (s = 1 ∨ s = -1) ∧ (t = 1 ∨ t = -1) := by
  simp only [crossLabels, List.mem_flatMap, List.mem_map, List.mem_range, List.mem_cons,
    List.not_mem_nil, or_false, Prod.mk.injEq]
  constructor
  · rintro ⟨i', hi', j', hj', s', hs', t', ht', rfl, rfl, rfl, rfl⟩
    exact ⟨hi', hj', hs', ht'⟩
  · rintro ⟨hi, hj, hs, ht⟩
    exact ⟨i, hi, j, hj, s, hs, t, ht, rfl, rfl, rfl, rfl⟩

/-- The 256 cross-octet vectors are pairwise distinct. -/
theorem crossOctet_nodup : crossOctet.Nodup := by decide +kernel

theorem crossOctet_length : crossOctet.length = 256 := by decide +kernel

/-- Every cross-octet vector is non-zero. -/
theorem crossOctet_ne_zero : ∀ v ∈ crossOctet, v ≠ 0 := by decide +kernel

/-! ## The annihilation relation -/

/-- `annihilates v w` is `true` when `v * w = 0`. -/
def annihilates (v w : CDSedenion) : Bool := v * w == 0

/-- The cross-octet vectors that annihilate some non-zero cross-octet vector. -/
def crossOctetZD : List CDSedenion :=
  crossOctet.filter fun v => crossOctet.any fun w => w != 0 && annihilates v w

/-- The cross-octet vectors that annihilate no non-zero cross-octet vector. -/
def crossOctetNonZD : List CDSedenion :=
  crossOctet.filter fun v => !(crossOctet.any fun w => w != 0 && annihilates v w)

/-- **Index criterion.** A cross-octet vector `s • eᵢ + t • e₈₊ⱼ` annihilates some
non-zero cross-octet vector iff `i ≠ 0`, `j ≠ 0` and `i ≠ j`; the signs are irrelevant. -/
theorem crossOctet_annihilator_iff_index :
    ∀ p ∈ crossLabels,
      (∃ w ∈ crossOctet, w ≠ 0 ∧ labelVec p * w = 0) ↔ isZeroDivisorIndex p.1 p.2.1 = true := by
  native_decide

/-- The index criterion, spelled out for explicit indices and signs. -/
theorem crossOctetVec_annihilator_iff (i j : Nat) (s t : Int)
    (hi : i < 8) (hj : j < 8) (hs : s = 1 ∨ s = -1) (ht : t = 1 ∨ t = -1) :
    (∃ w ∈ crossOctet, w ≠ 0 ∧ crossOctetVec i j s t * w = 0)
      ↔ (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) := by
  have hmem : (i, j, s, t) ∈ crossLabels := (mem_crossLabels_iff i j s t).2 ⟨hi, hj, hs, ht⟩
  have := crossOctet_annihilator_iff_index (i, j, s, t) hmem
  simpa [labelVec, crossOctetVec, isZeroDivisorIndex] using this

/-- Exactly 168 of the 256 cross-octet vectors are zero divisors. -/
theorem crossOctetZD_length : crossOctetZD.length = 168 := by native_decide

/-- Exactly 88 of the 256 cross-octet vectors are not zero divisors (within the
cross-octet family; see `Sovereign.Algebra.SedenionNonZeroDivisors` for the full algebra). -/
theorem crossOctetNonZD_length : crossOctetNonZD.length = 88 := by native_decide

/-- The stratification `256 = 168 + 88` for the *actual* sedenion vectors. -/
theorem crossOctet_stratification :
    crossOctetZD.length + crossOctetNonZD.length = crossOctet.length := by
  rw [crossOctetZD_length, crossOctetNonZD_length, crossOctet_length]

-- The two theorems that compared these lengths with the numerals `(D-2)(D-4)` and
-- `6D - 8` at `D = 16` were removed: `Sovereign.Algebra.CrossHalfUniversal` proves the
-- counts for every `D = 2^n` (`zdVerts_card_universal`, `nonZD_card_universal`) and
-- bridges them to the concrete sedenion lists (`zdVerts_eq_crossOctetZD_card`).

/-! ## Regularity and edge count of the annihilation graph -/

/-- Number of cross-octet zero divisors annihilated by `v`. -/
def annihilationDegree (v : CDSedenion) : Nat :=
  (crossOctetZD.filter (annihilates v)).length

/-- The annihilation graph is 8-regular. -/
theorem annihilation_regular : ∀ v ∈ crossOctetZD, annihilationDegree v = 8 := by
  native_decide

/-- Annihilation is symmetric on cross-octet vectors: `v * w = 0 ↔ w * v = 0`. -/
theorem annihilation_symm :
    ∀ v ∈ crossOctet, ∀ w ∈ crossOctet, v * w = 0 ↔ w * v = 0 := by
  native_decide

/-- No cross-octet vector annihilates itself, so the annihilation graph is loopless. -/
theorem annihilation_irrefl : ∀ v ∈ crossOctet, v * v ≠ 0 := by decide +kernel

/-- The 1344 directed annihilating pairs, i.e. 672 undirected edges. -/
theorem annihilation_directed_pairs :
    (crossOctetZD.map annihilationDegree).sum = 1344 := by native_decide

/-- The annihilation graph has 672 undirected edges. -/
theorem annihilation_edges :
    (crossOctetZD.map annihilationDegree).sum / 2 = 672 := by
  rw [annihilation_directed_pairs]

/-! ## XOR charge conservation and the seven sectors -/

/-- **Charge conservation.** If two cross-octet vectors annihilate each other then their
XOR charges `i ^^^ j` agree. -/
theorem xorCharge_conserved :
    ∀ p ∈ crossLabels, ∀ q ∈ crossLabels,
      labelVec p * labelVec q = 0 → xorCharge p.1 p.2.1 = xorCharge q.1 q.2.1 := by
  native_decide

/-- The zero-divisor labels of XOR charge `c`. -/
def chargeSector (c : Nat) : List CrossLabel :=
  crossLabels.filter fun p => isZeroDivisorIndex p.1 p.2.1 && (xorCharge p.1 p.2.1 == c)

/-- Every zero divisor carries a non-zero charge, and each of the seven non-zero charges
carries exactly 24 of the 168 zero divisors. -/
theorem chargeSector_length : ∀ c ∈ [1, 2, 3, 4, 5, 6, 7], (chargeSector c).length = 24 := by
  decide +kernel

/-- Charge `0` contains no zero divisor, and charges `≥ 8` do not occur. -/
theorem chargeSector_zero_empty : chargeSector 0 = [] := by decide +kernel

theorem chargeSector_large_empty : ∀ c ∈ List.range 8, chargeSector (8 + c) = [] := by
  decide +kernel

/-- The seven sectors exhaust the 168 zero divisors: `7 * 24 = 168`. -/
theorem chargeSectors_partition :
    ((List.range 7).map fun c => (chargeSector (c + 1)).length).sum = 168 := by
  decide +kernel

end Sovereign
