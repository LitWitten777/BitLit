import Mathlib
import Sovereign.Algebra.Trigintaduonion

namespace Sovereign
namespace CrossHalf

/-! ## 1. The cross-half index model -/

/-- All index pairs `(i, j)` of cross-half vectors `s • eᵢ + t • e_{H+j}` in the
Cayley–Dickson algebra of dimension `D = 2H`. -/
def crossIdx (H : Nat) : Finset (Nat × Nat) := Finset.range H ×ˢ Finset.range H

/-- The index pairs satisfying the zero-divisor criterion `i ≠ 0`, `j ≠ 0`, `i ≠ j`. -/
def zdIdx (H : Nat) : Finset (Nat × Nat) :=
  (crossIdx H).filter fun p => p.1 ≠ 0 ∧ p.2 ≠ 0 ∧ p.1 ≠ p.2

/-- The XOR charge `χ = i ^^^ j` of an index pair. -/
def charge (p : Nat × Nat) : Nat := p.1 ^^^ p.2

/-- The zero-divisor index pairs of XOR charge `c`. -/
def sector (H c : Nat) : Finset (Nat × Nat) := (zdIdx H).filter fun p => charge p = c

/-- A signed cross-half zero divisor: an index pair together with the two signs
`s, t ∈ {1, -1}` (encoded as booleans). -/
def zdVerts (H : Nat) : Finset ((Nat × Nat) × Bool × Bool) := zdIdx H ×ˢ Finset.univ

/-- The signed cross-half zero divisors of XOR charge `c`. -/
def sectorVerts (H c : Nat) : Finset ((Nat × Nat) × Bool × Bool) := sector H c ×ˢ Finset.univ

/-! ## 2. Elementary XOR lemmas -/

theorem xor_cancel_left (a b : Nat) : a ^^^ (a ^^^ b) = b := by
  rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]

theorem two_le_two_pow_of_lt {c k : Nat} (hc0 : c ≠ 0) (hcH : c < 2 ^ k) : 2 ≤ 2 ^ k := by
  rcases Nat.eq_zero_or_pos k with rfl | hk
  · simp at hcH; omega
  · calc 2 = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk

/-! ## 3. Membership characterisations -/

theorem mem_zdIdx_iff (H : Nat) (p : Nat × Nat) :
    p ∈ zdIdx H ↔ (p.1 < H ∧ p.2 < H ∧ p.1 ≠ 0 ∧ p.2 ≠ 0 ∧ p.1 ≠ p.2) := by
  simp only [zdIdx, crossIdx, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
  tauto

theorem mem_sector_iff (H c : Nat) (p : Nat × Nat) :
    p ∈ sector H c ↔ (p.1 < H ∧ p.2 < H ∧ p.1 ≠ 0 ∧ p.2 ≠ 0 ∧ p.1 ≠ p.2 ∧ p.1 ^^^ p.2 = c) := by
  simp only [sector, Finset.mem_filter, mem_zdIdx_iff, charge]
  tauto

/-! ## 4. The universal zero-divisor count `(D-2)(D-4)` -/

theorem zdIdx_eq_offDiag (H : Nat) : zdIdx H = (Finset.Ico 1 H).offDiag := by
  ext p
  simp only [mem_zdIdx_iff, Finset.mem_offDiag, Finset.mem_Ico]
  omega

/-- There are exactly `(H-1)(H-2)` cross-half zero-divisor index pairs in dimension `D = 2H`. -/
theorem zdIdx_card (H : Nat) : (zdIdx H).card = (H - 1) * (H - 2) := by
  rw [zdIdx_eq_offDiag, Finset.offDiag_card, Nat.card_Ico]
  rcases Nat.lt_or_ge H 2 with h | h
  · interval_cases H <;> rfl
  · obtain ⟨m, rfl⟩ : ∃ m, H = m + 2 := ⟨H - 2, by omega⟩
    simp only [Nat.add_sub_cancel, show m + 2 - 1 = m + 1 from by omega]
    have hexp : (m + 1) * (m + 1) = (m + 1) * m + (m + 1) := by ring
    omega

theorem zdVerts_card (H : Nat) : (zdVerts H).card = 4 * ((H - 1) * (H - 2)) := by
  rw [zdVerts, Finset.card_product, zdIdx_card]
  simp [Finset.card_univ]
  ring

/-- **Universal zero-divisor count.** In the Cayley–Dickson algebra of dimension
`D = 2ᵏ⁺¹` there are exactly `(D - 2)(D - 4)` signed cross-half zero divisors. -/
theorem zdVerts_card_universal (k : Nat) (hk : 1 ≤ k) :
    (zdVerts (2 ^ k)).card = (2 ^ (k + 1) - 2) * (2 ^ (k + 1) - 4) := by
  have h2 : (2 : Nat) ≤ 2 ^ k := by
    calc (2 : Nat) = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk
  obtain ⟨m, hm⟩ : ∃ m, 2 ^ k = m + 2 := ⟨2 ^ k - 2, by omega⟩
  have hpow : 2 ^ (k + 1) = 2 * (m + 2) := by rw [pow_succ, hm]; ring
  rw [zdVerts_card, hm, hpow]
  have e1 : 2 * (m + 2) - 2 = 2 * (m + 1) := by omega
  have e2 : 2 * (m + 2) - 4 = 2 * m := by omega
  have e3 : m + 2 - 1 = m + 1 := by omega
  have e4 : m + 2 - 2 = m := by omega
  rw [e1, e2, e3, e4]
  ring

/-- **Universal non-zero-divisor count.** The remaining cross-half vectors — those with
`i = 0`, `j = 0` or `i = j` — number exactly `6D - 8`. -/
theorem nonZD_card_universal (k : Nat) (hk : 1 ≤ k) :
    4 * (2 ^ k * 2 ^ k) - (zdVerts (2 ^ k)).card = 6 * 2 ^ (k + 1) - 8 := by
  have h2 : (2 : Nat) ≤ 2 ^ k := by
    calc (2 : Nat) = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk
  obtain ⟨m, hm⟩ : ∃ m, 2 ^ k = m + 2 := ⟨2 ^ k - 2, by omega⟩
  have hpow : 2 ^ (k + 1) = 2 * (m + 2) := by rw [pow_succ, hm]; ring
  rw [zdVerts_card, hm, hpow]
  have e3 : m + 2 - 1 = m + 1 := by omega
  have e4 : m + 2 - 2 = m := by omega
  rw [e3, e4]
  have : 4 * ((m + 2) * (m + 2)) = 4 * ((m + 1) * m) + (6 * (2 * (m + 2)) - 8) := by ring_nf; omega
  omega

/-- The total number of cross-half vectors is `D² = 4H²`, and it splits as
`(D-2)(D-4) + (6D-8)`. -/
theorem crossHalf_stratification_universal (k : Nat) (hk : 1 ≤ k) :
    (zdVerts (2 ^ k)).card + (6 * 2 ^ (k + 1) - 8) = 2 ^ (k + 1) * 2 ^ (k + 1) := by
  have h2 : (2 : Nat) ≤ 2 ^ k := by
    calc (2 : Nat) = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk
  obtain ⟨m, hm⟩ : ∃ m, 2 ^ k = m + 2 := ⟨2 ^ k - 2, by omega⟩
  have hpow : 2 ^ (k + 1) = 2 * (m + 2) := by rw [pow_succ, hm]; ring
  rw [zdVerts_card, hm, hpow]
  have e3 : m + 2 - 1 = m + 1 := by omega
  have e4 : m + 2 - 2 = m := by omega
  rw [e3, e4]
  have : 4 * ((m + 1) * m) + (6 * (2 * (m + 2)) - 8) = 2 * (m + 2) * (2 * (m + 2)) := by
    ring_nf; omega
  omega

/-! ## 5. XOR charge sectors -/

theorem charge_ne_zero {H : Nat} {p : Nat × Nat} (hp : p ∈ zdIdx H) : charge p ≠ 0 := by
  rw [mem_zdIdx_iff] at hp
  intro h
  exact hp.2.2.2.2 (Nat.eq_of_xor_eq_zero h)

theorem charge_lt {k : Nat} {p : Nat × Nat} (hp : p ∈ zdIdx (2 ^ k)) : charge p < 2 ^ k := by
  rw [mem_zdIdx_iff] at hp
  exact Nat.xor_lt_two_pow hp.1 hp.2.1

/-- Every sector of non-zero charge `c < H = 2ᵏ` is the graph of `i ↦ i ^^^ c`. -/
theorem sector_eq_image (k c : Nat) (hc0 : c ≠ 0) (hcH : c < 2 ^ k) :
    sector (2 ^ k) c = ((Finset.Ico 1 (2 ^ k)).erase c).image (fun i => (i, i ^^^ c)) := by
  ext p
  rw [mem_sector_iff]
  simp only [Finset.mem_image, Finset.mem_erase, Finset.mem_Ico]
  constructor
  · rintro ⟨h1, h2, h3, h4, h5, h6⟩
    have hp2 : p.1 ^^^ c = p.2 := by rw [← h6, xor_cancel_left]
    refine ⟨p.1, ⟨?_, by omega, h1⟩, ?_⟩
    · rintro rfl
      exact h4 (by rw [← hp2, Nat.xor_self])
    · exact Prod.ext rfl hp2
  · rintro ⟨i, ⟨hic, hi1, hi2⟩, rfl⟩
    refine ⟨hi2, Nat.xor_lt_two_pow hi2 hcH, by omega, ?_, ?_, xor_cancel_left i c⟩
    · intro h
      exact hic (Nat.eq_of_xor_eq_zero h)
    · intro h
      simp only at h
      have hx := xor_cancel_left i c
      rw [← h, Nat.xor_self] at hx
      exact hc0 hx.symm

/-- **Universal sector size.** For every non-zero charge `χ < H = 2ᵏ` there are exactly
`H - 2` zero-divisor index pairs of charge `χ`. -/
theorem sector_card (k c : Nat) (hc0 : c ≠ 0) (hcH : c < 2 ^ k) :
    (sector (2 ^ k) c).card = 2 ^ k - 2 := by
  have h2 : 2 ≤ 2 ^ k := two_le_two_pow_of_lt hc0 hcH
  rw [sector_eq_image k c hc0 hcH,
    Finset.card_image_of_injective _ (fun a b h => congrArg Prod.fst h),
    Finset.card_erase_of_mem (by simp only [Finset.mem_Ico]; omega), Nat.card_Ico]
  omega

/-- Signed form of the sector size: `2(D-4)` signed zero divisors per non-zero charge. -/
theorem sector_verts_card_universal (k c : Nat) (hc0 : c ≠ 0) (hcH : c < 2 ^ k) :
    (sectorVerts (2 ^ k) c).card = 2 * (2 ^ (k + 1) - 4) := by
  have h2 : 2 ≤ 2 ^ k := two_le_two_pow_of_lt hc0 hcH
  rw [sectorVerts, Finset.card_product, sector_card k c hc0 hcH]
  simp only [Finset.card_univ, Fintype.card_prod, Fintype.card_bool]
  have hpow : 2 ^ (k + 1) = 2 * 2 ^ k := by rw [pow_succ]; ring
  rw [hpow]
  omega

/-- The zero divisors are the disjoint union of their charge sectors. -/
theorem zdIdx_card_eq_sum (k : Nat) :
    (zdIdx (2 ^ k)).card = ∑ c ∈ Finset.Ico 1 (2 ^ k), (sector (2 ^ k) c).card := by
  refine Finset.card_eq_sum_card_fiberwise ?_
  intro p hp
  have h0 := charge_ne_zero hp
  have h1 := charge_lt hp
  exact Finset.mem_Ico.mpr ⟨by omega, h1⟩

/-- **Universal component count × component size = total.** There are `D/2 - 1` non-zero
XOR charges, each carrying `H - 2` index pairs, and together they exhaust the
`(H-1)(H-2)` cross-half zero-divisor index pairs. -/
theorem charge_count_mul_sector_card (k : Nat) (hk : 1 ≤ k) :
    (Finset.Ico 1 (2 ^ k)).card * (2 ^ k - 2) = (zdIdx (2 ^ k)).card := by
  have h2 : (2 : Nat) ≤ 2 ^ k := by
    calc (2 : Nat) = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk
  have hsum : ∑ c ∈ Finset.Ico 1 (2 ^ k), (sector (2 ^ k) c).card
      = ∑ _c ∈ Finset.Ico 1 (2 ^ k), (2 ^ k - 2) := by
    refine Finset.sum_congr rfl ?_
    intro c hc
    rw [Finset.mem_Ico] at hc
    exact sector_card k c (by omega) hc.2
  rw [zdIdx_card_eq_sum k, hsum, Finset.sum_const, smul_eq_mul]

/-! ## 6. The eightfold-triangular law -/

/-- Triangular numbers. -/
def tri (r : Nat) : Nat := r * (r + 1) / 2

/-- **Universal eightfold-triangular law.** `(D-2)(D-4) = 8 · T_{(D-4)/2}` for every
Cayley–Dickson dimension `D = 2ᵏ⁺¹`, `k ≥ 1`. -/
theorem zd_triangular_universal (k : Nat) (hk : 1 ≤ k) :
    (zdVerts (2 ^ k)).card = 8 * tri (2 ^ k - 2) := by
  have h2 : (2 : Nat) ≤ 2 ^ k := by
    calc (2 : Nat) = 2 ^ 1 := rfl
      _ ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hk
  obtain ⟨m, hm⟩ : ∃ m, 2 ^ k = m + 2 := ⟨2 ^ k - 2, by omega⟩
  rw [zdVerts_card, hm, tri]
  have e3 : m + 2 - 1 = m + 1 := by omega
  have e4 : m + 2 - 2 = m := by omega
  rw [e3, e4]
  obtain ⟨q, hq⟩ : ∃ q, m * (m + 1) = 2 * q := (Nat.even_mul_succ_self m).elim
    fun a ha => ⟨a, by omega⟩
  rw [hq, Nat.mul_div_cancel_left q (by norm_num)]
  have : (m + 1) * m = 2 * q := by rw [Nat.mul_comm]; exact hq
  omega

/-! ## 7. The transposition involution -/

/-- The transposition `τ : (i, j) ↦ (j, i)`. -/
def transpose (p : Nat × Nat) : Nat × Nat := (p.2, p.1)

theorem transpose_involutive (p : Nat × Nat) : transpose (transpose p) = p := rfl

theorem transpose_charge (p : Nat × Nat) : charge (transpose p) = charge p :=
  Nat.xor_comm p.2 p.1

theorem transpose_mem_sector {H c : Nat} {p : Nat × Nat} (hp : p ∈ sector H c) :
    transpose p ∈ sector H c := by
  rw [mem_sector_iff] at hp ⊢
  exact ⟨hp.2.1, hp.1, hp.2.2.2.1, hp.2.2.1, fun h => hp.2.2.2.2.1 h.symm,
    by rw [Nat.xor_comm]; exact hp.2.2.2.2.2⟩

theorem transpose_ne_self {H c : Nat} {p : Nat × Nat} (hp : p ∈ sector H c) :
    transpose p ≠ p := by
  rw [mem_sector_iff] at hp
  intro h
  exact hp.2.2.2.2.1 (congrArg Prod.fst h).symm

/-- Every charge sector has even cardinality — as it must, since `τ` is a fixed-point-free
involution of it (`transpose_mem_sector`, `transpose_involutive`, `transpose_ne_self`). -/
theorem sector_card_even (k c : Nat) (hc0 : c ≠ 0) (hcH : c < 2 ^ k) :
    Even (sector (2 ^ k) c).card := by
  have h2 := two_le_two_pow_of_lt hc0 hcH
  rw [sector_card k c hc0 hcH]
  obtain ⟨m, hm⟩ : (2 : Nat) ∣ 2 ^ k := dvd_pow_self 2 (by rintro rfl; simp at h2)
  exact ⟨m - 1, by omega⟩

/-! ## 8. Instances: the classical dimensions, derived from the universal theorems -/

/-- `D = 16` (sedenions): `168 = (16-2)(16-4)` signed cross-half zero divisors. -/
theorem zd_card_16 : (zdVerts 8).card = 168 := by
  have := zdVerts_card_universal 3 (by norm_num)
  norm_num at this ⊢
  exact this

/-- `D = 32` (trigintaduonions): `840 = (32-2)(32-4)`. -/
theorem zd_card_32 : (zdVerts 16).card = 840 := by
  have := zdVerts_card_universal 4 (by norm_num)
  norm_num at this ⊢
  exact this

/-- `D = 64` (chingons): `3720 = (64-2)(64-4)`. -/
theorem zd_card_64 : (zdVerts 32).card = 3720 := by
  have := zdVerts_card_universal 5 (by norm_num)
  norm_num at this ⊢
  exact this

/-- `D = 128`: `15624 = (128-2)(128-4)`. -/
theorem zd_card_128 : (zdVerts 64).card = 15624 := by
  have := zdVerts_card_universal 6 (by norm_num)
  norm_num at this ⊢
  exact this

/-- `D = 256`: `64008 = (256-2)(256-4)`. -/
theorem zd_card_256 : (zdVerts 128).card = 64008 := by
  have := zdVerts_card_universal 7 (by norm_num)
  norm_num at this ⊢
  exact this

/-- The seven Fano sectors of the sedenions have `24 = 2(16-4)` signed zero divisors each. -/
theorem sector_card_16 (c : Nat) (hc0 : c ≠ 0) (hcH : c < 8) :
    (sectorVerts 8 c).card = 24 := by
  have := sector_verts_card_universal 3 c hc0 (by norm_num; omega)
  norm_num at this ⊢
  exact this

/-- The fifteen `PG(3,2)` sectors of the trigintaduonions have `56 = 2(32-4)` each. -/
theorem sector_card_32 (c : Nat) (hc0 : c ≠ 0) (hcH : c < 16) :
    (sectorVerts 16 c).card = 56 := by
  have := sector_verts_card_universal 4 c hc0 (by norm_num; omega)
  norm_num at this ⊢
  exact this

/-- The sixty-three `PG(5,2)` sectors of the `D = 128` algebra have `248 = 2(128-4)` each. -/
theorem sector_card_128 (c : Nat) (hc0 : c ≠ 0) (hcH : c < 64) :
    (sectorVerts 64 c).card = 248 := by
  have := sector_verts_card_universal 6 c hc0 (by norm_num; omega)
  norm_num at this ⊢
  exact this

/-! ## 9. Agreement with the kernel-verified algebra computations -/

/-- The universal count reproduces the sedenion computation in the actual algebra:
`crossOctetZD` (the 168 cross-octet zero divisors of `CDSedenion`, obtained by exact
evaluation of sedenion products) has exactly `(zdVerts 8).card` elements. -/
theorem zdVerts_eq_crossOctetZD_card : (zdVerts 8).card = crossOctetZD.length := by
  rw [zd_card_16, crossOctetZD_length]

/-- The universal count reproduces the trigintaduonion computation: `zd32` (the cross-half
zero divisors of `CD CDSedenion`, obtained by exact evaluation) has `(zdVerts 16).card`
elements. -/
theorem zdVerts_eq_zd32_card : (zdVerts 16).card = zd32.length := by
  rw [zd_card_32, zd32_card]

/-- Sectorwise agreement in dimension 32: the universal sector size `2(32-4) = 56` equals the
size of every non-zero charge sector computed inside the algebra. -/
theorem sectorVerts_eq_sector32_card (c : Nat) (hc : c ∈ List.range 15) :
    (sectorVerts 16 (c + 1)).card = (sector32 (c + 1)).length := by
  have hc' : c < 15 := List.mem_range.mp hc
  rw [sector_card_32 (c + 1) (by omega) (by omega), sector32_card.2 c hc]

/-! ## 10. The charge index set is the point set of `PG(n-2, 𝔽₂)` -/

/-- The binary expansion of a charge as a vector of `𝔽₂^k`. -/
def chargeBits (k c : Nat) : Fin k → ZMod 2 := fun i => if c.testBit i.1 then 1 else 0

theorem chargeBits_zero (k : Nat) : chargeBits k 0 = 0 := by
  funext i; simp [chargeBits]

/-- The charge map turns XOR into addition in `𝔽₂^k`: charges form an elementary abelian
2-group, exactly the vector space underlying `PG(k-1, 𝔽₂)`. -/
theorem chargeBits_xor (k c d : Nat) :
    chargeBits k (c ^^^ d) = chargeBits k c + chargeBits k d := by
  funext i
  simp only [chargeBits, Nat.testBit_xor, Pi.add_apply]
  rcases Bool.eq_false_or_eq_true (c.testBit i.1) with h1 | h1 <;>
    rcases Bool.eq_false_or_eq_true (d.testBit i.1) with h2 | h2 <;>
      simp [h1, h2]
  decide

theorem chargeBits_injOn (k : Nat) {c d : Nat} (hc : c < 2 ^ k) (hd : d < 2 ^ k)
    (h : chargeBits k c = chargeBits k d) : c = d := by
  apply Nat.eq_of_testBit_eq
  intro i
  by_cases hi : i < k
  · have hbit := congrFun h ⟨i, hi⟩
    simp only [chargeBits] at hbit
    rcases Bool.eq_false_or_eq_true (c.testBit i) with h1 | h1 <;>
      rcases Bool.eq_false_or_eq_true (d.testBit i) with h2 | h2 <;>
        simp [h1, h2] at hbit ⊢
  · have hc' : c.testBit i = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le hc (Nat.pow_le_pow_right (by norm_num) (by omega)))
    have hd' : d.testBit i = false := Nat.testBit_lt_two_pow
      (lt_of_lt_of_le hd (Nat.pow_le_pow_right (by norm_num) (by omega)))
    rw [hc', hd']

theorem chargeBits_ne_zero (k c : Nat) (hc0 : c ≠ 0) (hcH : c < 2 ^ k) :
    chargeBits k c ≠ 0 := by
  intro h
  refine hc0 (chargeBits_injOn k hcH (by positivity) ?_)
  rw [h, chargeBits_zero]

/-- **Universal projective indexing of the components.** The non-zero XOR charges of the
cross-half zero divisors of the dimension-`2ᵏ⁺¹` Cayley–Dickson algebra correspond
bijectively, via binary expansion, to the non-zero vectors of `𝔽₂^k` — the points of
`PG(k-1, 𝔽₂)`. -/
theorem chargeBits_image (k : Nat) :
    (Finset.Ico 1 (2 ^ k)).image (chargeBits k)
      = Finset.univ.filter (fun v : Fin k → ZMod 2 => v ≠ 0) := by
  have hsub : (Finset.Ico 1 (2 ^ k)).image (chargeBits k)
      ⊆ Finset.univ.filter (fun v : Fin k → ZMod 2 => v ≠ 0) := by
    intro v hv
    simp only [Finset.mem_image, Finset.mem_Ico] at hv
    obtain ⟨c, ⟨hc1, hc2⟩, rfl⟩ := hv
    simp only [Finset.mem_filter, Finset.mem_univ, true_and]
    exact chargeBits_ne_zero k c (by omega) hc2
  refine Finset.eq_of_subset_of_card_le hsub ?_
  have hcard1 : ((Finset.Ico 1 (2 ^ k)).image (chargeBits k)).card = 2 ^ k - 1 := by
    rw [Finset.card_image_of_injOn ?_, Nat.card_Ico]
    intro a ha b hb hab
    simp only [Finset.coe_Ico, Set.mem_Ico] at ha hb
    exact chargeBits_injOn k ha.2 hb.2 hab
  have hcard2 : (Finset.univ.filter (fun v : Fin k → ZMod 2 => v ≠ 0)).card = 2 ^ k - 1 := by
    rw [Finset.filter_ne', Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ]
    simp
  omega

/-- The number of charge sectors equals the number of points of `PG(k-1, 𝔽₂)`,
i.e. `D/2 - 1`. -/
theorem sector_count_eq_projective_points (k : Nat) :
    (Finset.Ico 1 (2 ^ k)).card
      = (Finset.univ.filter (fun v : Fin k → ZMod 2 => v ≠ 0)).card := by
  rw [Finset.filter_ne', Finset.card_erase_of_mem (Finset.mem_univ _), Finset.card_univ,
    Nat.card_Ico]
  simp

end CrossHalf
end Sovereign
