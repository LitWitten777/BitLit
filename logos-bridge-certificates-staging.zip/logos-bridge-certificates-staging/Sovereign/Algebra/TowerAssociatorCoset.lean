import Sovereign.Algebra.TowerAlternative

namespace Sovereign

/-- Helper lemma: XOR cancellation for booleans `a ⊕ false ⊕ b ⊕ false ⊕ false = false → a = b`. -/
theorem xor_cancel_five (a b : Bool) (h : xor a (xor false (xor b (xor false false))) = false) :
    a = b := by
  revert h
  cases a <;> cases b <;> decide

/-- **Left-shift invariance of the associator sign.**
Translating the middle index `k` by `i` preserves the associator sign `assocNeg n i k j`:
`assocNeg n i (k ^^^ i) j = assocNeg n i k j`. -/
theorem assocNeg_shift_left (n i k j : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n) :
    assocNeg n i (k ^^^ i) j = assocNeg n i k j := by
  have hki : k ^^^ i < 2 ^ n := Nat.xor_lt_two_pow hk hi
  have hkj : k ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hk hj
  have hp := assocNeg_pentagon n i i k j
  have h1 : assocNeg n (i ^^^ i) k j = false := by
    rw [Nat.xor_self]
    exact assocNeg_zero_left n k j
  have h2 : assocNeg n i i (k ^^^ j) = false := assocNeg_left_alt n i (k ^^^ j) hi hkj
  have h3 : assocNeg n i i k = false := assocNeg_left_alt n i k hi hk
  rw [h1, h2, h3] at hp
  rw [Nat.xor_comm k i]
  exact (xor_cancel_five (assocNeg n i k j) (assocNeg n i (i ^^^ k) j) hp).symm

/-- **Right-shift invariance of the associator sign.**
Translating the middle index `k` by `j` preserves the associator sign `assocNeg n i k j`:
`assocNeg n i (k ^^^ j) j = assocNeg n i k j`. -/
theorem assocNeg_shift_right (n i k j : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n) :
    assocNeg n i (k ^^^ j) j = assocNeg n i k j := by
  have hik : i ^^^ k < 2 ^ n := Nat.xor_lt_two_pow hi hk
  have hp := assocNeg_pentagon n i k j j
  have h1 : assocNeg n k j j = false := assocNeg_right_alt n k j hk hj
  have h2 : assocNeg n (i ^^^ k) j j = false := assocNeg_right_alt n (i ^^^ k) j hik hj
  have h3 : assocNeg n i k (j ^^^ j) = false := by
    rw [Nat.xor_self]
    exact assocNeg_zero_right n i k
  rw [h1, h2, h3] at hp
  have hp_simp : xor (assocNeg n i (k ^^^ j) j) (assocNeg n i k j) = false := by
    revert hp
    cases assocNeg n i (k ^^^ j) j <;> cases assocNeg n i k j <;> decide
  revert hp_simp
  cases assocNeg n i (k ^^^ j) j <;> cases assocNeg n i k j <;> decide

/-- **XOR-shift invariance of the associator sign.**
Translating the middle index `k` by `i ⊕ j` preserves the associator sign:
`assocNeg n i (k ^^^ (i ^^^ j)) j = assocNeg n i k j`. -/
theorem assocNeg_shift_xor (n i k j : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n) :
    assocNeg n i (k ^^^ (i ^^^ j)) j = assocNeg n i k j := by
  have hki : k ^^^ i < 2 ^ n := Nat.xor_lt_two_pow hk hi
  rw [← Nat.xor_assoc]
  rw [assocNeg_shift_right n i (k ^^^ i) j hi hki hj]
  exact assocNeg_shift_left n i k j hi hk hj

/-- **Universal Coset Translation Invariance Theorem.**
The associator sign `assocNeg n i (k ^^^ s) j` is identical to `assocNeg n i k j`
for any index `s` in the 2-dimensional subspace `span(i, j) = {0, i, j, i ⊕ j}`. -/
theorem assocNeg_shift_span (n i k j s : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n)
    (hs : inSpan2 i j s) : assocNeg n i (k ^^^ s) j = assocNeg n i k j := by
  rcases hs with h0 | hs1 | hs2 | hs3
  · rw [h0, Nat.xor_zero]
  · rw [hs1]; exact assocNeg_shift_left n i k j hi hk hj
  · rw [hs2]; exact assocNeg_shift_right n i k j hi hk hj
  · rw [hs3]; exact assocNeg_shift_xor n i k j hi hk hj

/-- **Associating middles are closed under translation by `span(i, j)`.** -/
theorem assoc_middle_shift_span (n i k j s : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n)
    (hs : inSpan2 i j s) :
    assocNeg n i (k ^^^ s) j = false ↔ assocNeg n i k j = false := by
  rw [assocNeg_shift_span n i k j s hi hk hj hs]

/-- **Non-associating middles are closed under translation by `span(i, j)`.** -/
theorem nonassoc_middle_shift_span (n i k j s : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hj : j < 2 ^ n)
    (hs : inSpan2 i j s) :
    assocNeg n i (k ^^^ s) j = true ↔ assocNeg n i k j = true := by
  rw [assocNeg_shift_span n i k j s hi hk hj hs]

end Sovereign
