/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Universal Index Geometry Decoupling Theorem in Lean 4

Formal verification of HYP-022:
In any Cayley-Dickson algebra of dimension D = 2ⁿ (n ≥ 4),
for cross-half zero-divisor vectors:
  v₁ = s₁ e_i + s₂ e_{H+j}  with charge χ(v₁) = i ^^^ j
  v₂ = t₁ e_k + t₂ e_{H+m}  with charge χ(v₂) = k ^^^ m

The 4 product terms have basis indices:
  k₀ = i ^^^ k
  k₁ = i ^^^ m
  k₂ = j ^^^ k
  k₃ = j ^^^ m

1. Both low and high components cancel IF AND ONLY IF χ(v₁) = χ(v₂).
2. When χ(v₁) = χ(v₂) = χ ≠ 0, identically k₀ = k₃ and k₁ = k₂.
3. Furthermore, k₀ ≠ k₁ whenever χ ≠ 0, completely forbidding cross-pair collisions.
4. Hence, cancellation decomposes into two independent 2-term sign cancellations:
   s₀ + s₃ = 0  and  s₁ + s₂ = 0.
-/

namespace Sovereign

/-- Swapping outer and inner indices in a 4-term XOR equality. -/
theorem xor_eq_swap (i j k m : Nat) : (i ^^^ k = j ^^^ m) ↔ (i ^^^ j = k ^^^ m) := by
  constructor
  · intro h
    have h1 : (i ^^^ k) ^^^ (k ^^^ j) = (j ^^^ m) ^^^ (k ^^^ j) := by rw [h]
    rw [← Nat.xor_assoc, Nat.xor_assoc i k k, Nat.xor_self, Nat.xor_zero] at h1
    have h2 : (j ^^^ m) ^^^ (k ^^^ j) = (m ^^^ j) ^^^ (j ^^^ k) := by
      rw [Nat.xor_comm j m, Nat.xor_comm k j]
    rw [h2] at h1
    rw [← Nat.xor_assoc, Nat.xor_assoc m j j, Nat.xor_self, Nat.xor_zero, Nat.xor_comm m k] at h1
    exact h1
  · intro h
    have h1 : (i ^^^ j) ^^^ (j ^^^ k) = (k ^^^ m) ^^^ (j ^^^ k) := by rw [h]
    rw [← Nat.xor_assoc, Nat.xor_assoc i j j, Nat.xor_self, Nat.xor_zero] at h1
    have h2 : (k ^^^ m) ^^^ (j ^^^ k) = (m ^^^ k) ^^^ (k ^^^ j) := by
      rw [Nat.xor_comm k m, Nat.xor_comm j k]
    rw [h2] at h1
    rw [← Nat.xor_assoc, Nat.xor_assoc m k k, Nat.xor_self, Nat.xor_zero, Nat.xor_comm m j] at h1
    exact h1

/-- High-half index exchange. -/
theorem xor_high_term_swap (i j k m : Nat) : (m ^^^ i = j ^^^ k) ↔ (i ^^^ j = k ^^^ m) := by
  have h1 : m ^^^ i = i ^^^ m := Nat.xor_comm m i
  rw [h1]
  have h3 := xor_eq_swap i j m k
  rw [Nat.xor_comm m k] at h3
  exact h3

/-- **Universal Index Geometry Decoupling Theorem (Part 1: Charge Conservation)**:
    Low and high cross-half products cancel if and only if XOR charges are equal. -/
theorem universal_xor_charge_cancellation_iff (i j k m : Nat) :
    (i ^^^ k = j ^^^ m ∧ m ^^^ i = j ^^^ k) ↔ (i ^^^ j = k ^^^ m) := by
  constructor
  · rintro ⟨hlow, _hhigh⟩
    exact (xor_eq_swap i j k m).mp hlow
  · intro h
    constructor
    · exact (xor_eq_swap i j k m).mpr h
    · exact (xor_high_term_swap i j k m).mpr h

/-- **Universal Index Geometry Decoupling Theorem (Part 2: Low-Term Decoupling)**:
    When XOR charges match, the outer basis index k₀ = i ^^^ k equals k₃ = j ^^^ m. -/
theorem universal_decoupling_k0_eq_k3 (i j k m : Nat) (hchi : i ^^^ j = k ^^^ m) :
    i ^^^ k = j ^^^ m :=
  (xor_eq_swap i j k m).mpr hchi

/-- **Universal Index Geometry Decoupling Theorem (Part 3: High-Term Decoupling)**:
    When XOR charges match, the inner basis index k₁ = i ^^^ m equals k₂ = j ^^^ k. -/
theorem universal_decoupling_k1_eq_k2 (i j k m : Nat) (hchi : i ^^^ j = k ^^^ m) :
    i ^^^ m = j ^^^ k := by
  have h := (xor_high_term_swap i j k m).mpr hchi
  rw [Nat.xor_comm m i] at h
  exact h

/-- Cancellation of XOR on the left: i ^^^ k = i ^^^ m ↔ k = m. -/
theorem xor_left_inj (i k m : Nat) : (i ^^^ k = i ^^^ m) ↔ (k = m) := by
  constructor
  · intro h
    have h1 : i ^^^ (i ^^^ k) = i ^^^ (i ^^^ m) := by rw [h]
    rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor] at h1
    rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor] at h1
    exact h1
  · intro h
    rw [h]

/-- **Universal Index Geometry Decoupling Theorem (Part 4: Disjointness of Pairs)**:
    Whenever the conserved charge χ = k ^^^ m is non-zero, k₀ ≠ k₁, preventing cross-pair interference. -/
theorem universal_decoupling_k0_ne_k1 (i k m : Nat) (h_nonzero : k ^^^ m ≠ 0) :
    i ^^^ k ≠ i ^^^ m := by
  intro heq
  have hkm : k = m := (xor_left_inj i k m).mp heq
  subst hkm
  rw [Nat.xor_self] at h_nonzero
  exact h_nonzero rfl

end Sovereign
