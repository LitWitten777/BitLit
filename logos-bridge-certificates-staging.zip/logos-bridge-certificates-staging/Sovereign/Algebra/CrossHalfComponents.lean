import Sovereign.Algebra.CrossHalfCriterion
import Sovereign.Algebra.CrossHalfUniversal
import Sovereign.Algebra.TowerAssociator

namespace Sovereign
namespace CrossHalfComponents

open CrossHalfCriterion CrossHalf

/-! ## 1. Labels, vectors and the annihilation graph -/

/-- A label `((i, j), (s, t))` of the cross-half vector `signed s eᵢ + signed t e_{H+j}`. -/
abbrev Label := (Nat × Nat) × Bool × Bool

/-- The cross-half vector of `Tower (n+1)` attached to a label. -/
def vec (n : Nat) (x : Label) : Tower (n + 1) := crossVec n x.2.1 x.1.1 x.2.2 x.1.2

/-- Both indices of the label are below `H = 2ⁿ`. -/
def InRange (n : Nat) (x : Label) : Prop := x.1.1 < 2 ^ n ∧ x.1.2 < 2 ^ n

/-- `x` is a cross-half zero divisor: it annihilates (from the left) some non-zero
cross-half vector. -/
def IsCrossZD (n : Nat) (x : Label) : Prop :=
  InRange n x ∧ ∃ y, InRange n y ∧ vec n y ≠ 0 ∧ vec n x * vec n y = 0

open Classical in
/-- The finite set of cross-half zero divisors of `Tower (n+1)`. -/
noncomputable def crossZD (n : Nat) : Finset Label :=
  (crossIdx (2 ^ n) ×ˢ (Finset.univ : Finset (Bool × Bool))).filter (IsCrossZD n)

/-- The annihilation graph: two distinct in-range cross-half vectors are adjacent when
their product (in one order or the other) vanishes. -/
def annihGraph (n : Nat) : SimpleGraph Label where
  Adj x y := x ≠ y ∧ InRange n x ∧ InRange n y ∧ (vec n x * vec n y = 0 ∨ vec n y * vec n x = 0)
  symm := fun _ _ ⟨h1, h2, h3, h4⟩ => ⟨Ne.symm h1, h3, h2, h4.symm⟩
  loopless := ⟨fun _ h => h.1 rfl⟩

open Classical in
/-- The zero divisors of XOR charge `c`. -/
noncomputable def crossSector (n c : Nat) : Finset Label :=
  (crossZD n).filter fun x => charge x.1 = c

/-! ## 2. The edge law -/

/-- The sign parity carried by an edge `i → k` (for the partner index `m = k ^^^ i ^^^ j`). -/
def edgePar (n i j k : Nat) : Bool :=
  xor (epsNeg n i k) (xor (conjNeg (k ^^^ (i ^^^ j))) (epsNeg n (k ^^^ (i ^^^ j)) j))

theorem sign_edge_iff (s t u r A B C D : Bool) :
    (xor s (xor u A) ≠ xor t (xor r (!B)) ∧ xor s (xor r C) ≠ xor t (xor u D))
      ↔ (xor (xor s t) (xor u r) = xor A B ∧ xor A B = !(xor C D)) := by
  revert s t u r A B C D; decide

/-- **Edge law.** `(± eᵢ ± e_{H+j}) · (± e_k ± e_{H+m}) = 0` exactly when `m = k ^^^ i ^^^ j`,
the index condition `crossOK` holds, and the four signs have the parity `edgePar`. -/
theorem vec_mul_eq_zero_iff (n : Nat) (x y : Label) (hx : InRange n x) (hy : InRange n y) :
    vec n x * vec n y = 0 ↔
      (y.1.2 = y.1.1 ^^^ (x.1.1 ^^^ x.1.2) ∧
        xor (xor x.2.1 x.2.2) (xor y.2.1 y.2.2) = edgePar n x.1.1 x.1.2 y.1.1 ∧
        crossOK n x.1.1 x.1.2 y.1.1) := by
  obtain ⟨⟨i, j⟩, s, t⟩ := x
  obtain ⟨⟨k, m⟩, u, r⟩ := y
  obtain ⟨hi, hj⟩ := hx
  obtain ⟨hk, hm⟩ := hy
  simp only [vec]
  rw [crossVec_mul_eq_zero_iff n s t u r i j k m hi hj hk hm]
  constructor
  · rintro ⟨h1, h2, h3⟩
    have hm' : m = k ^^^ (i ^^^ j) := by rw [h1, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
    subst hm'
    rw [eps_ll hi hk, eps_hh] at h2
    rw [eps_lh _ hi, eps_hl _ hk] at h3
    exact ⟨rfl, ((sign_edge_iff s t u r _ _ _ _).1 ⟨h2, h3⟩)⟩
  · rintro ⟨hm', h2⟩
    subst hm'
    refine ⟨by rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor], ?_⟩
    rw [eps_ll hi hk, eps_hh, eps_lh _ hi, eps_hl _ hk]
    exact (sign_edge_iff s t u r _ _ _ _).2 h2

theorem vec_ne_zero (n : Nat) (x : Label) (hx : InRange n x) : vec n x ≠ 0 :=
  crossVec_ne_zero n _ _ _ _ hx.1 hx.2

/-! ## 3. Which cross-half vectors are zero divisors, and how many there are -/

/-- In dimension `D = 2ⁿ⁺¹ ≥ 16` the cross-half zero divisors are exactly the labels with
`i ≠ 0`, `j ≠ 0`, `i ≠ j`. -/
theorem isCrossZD_iff {n : Nat} (hn : 3 ≤ n) (x : Label) :
    IsCrossZD n x ↔ x ∈ zdVerts (2 ^ n) := by
  obtain ⟨⟨i, j⟩, s, t⟩ := x
  simp only [zdVerts, Finset.mem_product, Finset.mem_univ, and_true, mem_zdIdx_iff]
  constructor
  · rintro ⟨hx, y, hy, hy0, hxy⟩
    obtain ⟨⟨k, m⟩, u, r⟩ := y
    have := (Sovereign.crossVec_zero_divisor_iff n hn s t i j hx.1 hx.2).1
      ⟨u, r, k, m, hy.1, hy.2, hy0, hxy⟩
    exact ⟨hx.1, hx.2, this⟩
  · rintro ⟨hi, hj, hv⟩
    obtain ⟨u, r, k, m, hk, hm, h0, hz⟩ := (Sovereign.crossVec_zero_divisor_iff n hn s t i j hi hj).2 hv
    exact ⟨⟨hi, hj⟩, ((k, m), u, r), ⟨hk, hm⟩, h0, hz⟩

theorem crossZD_eq {n : Nat} (hn : 3 ≤ n) : crossZD n = zdVerts (2 ^ n) := by
  ext x
  simp only [crossZD, Finset.mem_filter, isCrossZD_iff hn]
  constructor
  · exact fun h => h.2
  · intro h
    refine ⟨?_, h⟩
    simp only [zdVerts, Finset.mem_product] at h
    simp only [Finset.mem_product]
    exact ⟨Finset.mem_of_subset (Finset.filter_subset _ _) h.1, h.2⟩

theorem mem_crossZD_iff {n : Nat} (hn : 3 ≤ n) (x : Label) :
    x ∈ crossZD n ↔ (x.1.1 < 2 ^ n ∧ x.1.2 < 2 ^ n ∧ x.1.1 ≠ 0 ∧ x.1.2 ≠ 0 ∧ x.1.1 ≠ x.1.2) := by
  rw [crossZD_eq hn]
  simp [zdVerts, mem_zdIdx_iff]

/-- **Universal count.** The Cayley–Dickson algebra of dimension `D = 2ⁿ⁺¹ ≥ 16` has exactly
`(D - 2)(D - 4)` cross-half zero divisors `± eᵢ ± e_{D/2+j}`. -/
theorem crossZD_card {n : Nat} (hn : 3 ≤ n) :
    (crossZD n).card = (2 ^ (n + 1) - 2) * (2 ^ (n + 1) - 4) := by
  rw [crossZD_eq hn, zdVerts_card_universal n (by omega)]

theorem crossSector_eq {n : Nat} (hn : 3 ≤ n) (c : Nat) : crossSector n c = sectorVerts (2 ^ n) c := by
  ext x
  simp [crossSector, crossZD_eq hn, zdVerts, sectorVerts, sector]

/-- **Universal sector size.** Every non-zero XOR charge `c < D/2` carries exactly
`2(D - 4)` cross-half zero divisors. -/
theorem crossSector_card {n : Nat} (hn : 3 ≤ n) (c : Nat) (hc0 : c ≠ 0) (hc : c < 2 ^ n) :
    (crossSector n c).card = 2 * (2 ^ (n + 1) - 4) := by
  rw [crossSector_eq hn, sector_verts_card_universal n c hc0 hc]

theorem charge_mem_Ico {n : Nat} (hn : 3 ≤ n) {x : Label} (hx : x ∈ crossZD n) :
    charge x.1 ∈ Finset.Ico 1 (2 ^ n) := by
  rw [mem_crossZD_iff hn] at hx
  have h0 : charge x.1 ≠ 0 := fun h => hx.2.2.2.2 (Nat.eq_of_xor_eq_zero h)
  have h1 : charge x.1 < 2 ^ n := Nat.xor_lt_two_pow hx.1 hx.2.1
  exact Finset.mem_Ico.mpr ⟨by omega, h1⟩

/-- The zero divisors are the union of the sectors of the non-zero charges `1 ≤ c < D/2`. -/
theorem crossZD_eq_biUnion {n : Nat} (hn : 3 ≤ n) :
    crossZD n = (Finset.Ico 1 (2 ^ n)).biUnion (crossSector n) := by
  ext x
  simp only [Finset.mem_biUnion, crossSector, Finset.mem_filter]
  constructor
  · intro hx
    exact ⟨charge x.1, charge_mem_Ico hn hx, hx, rfl⟩
  · rintro ⟨c, _, hx, _⟩
    exact hx

/-- Distinct charges give disjoint sectors. -/
theorem crossSector_disjoint (n : Nat) {c d : Nat} (h : c ≠ d) :
    Disjoint (crossSector n c) (crossSector n d) := by
  rw [Finset.disjoint_left]
  intro x hx hx'
  simp only [crossSector, Finset.mem_filter] at hx hx'
  exact h (hx.2.symm.trans hx'.2)

/-! ## 4. Annihilation preserves the charge and stays among the zero divisors -/

/-- A right annihilating partner of a cross-half zero divisor is itself a zero divisor. -/
theorem crossOK_partner_valid {n i j k : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n)
    (hk : k < 2 ^ n) (h : crossOK n i j k) :
    k ≠ 0 ∧ k ^^^ (i ^^^ j) ≠ 0 ∧ k ≠ k ^^^ (i ^^^ j) := by
  obtain ⟨hi0, hj0, hij⟩ := crossOK_valid hi hj hk h
  have hc0 : i ^^^ j ≠ 0 := fun h' => hij (Nat.eq_of_xor_eq_zero h')
  have hc : i ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hi hj
  unfold crossOK at h
  refine ⟨?_, ?_, ?_⟩
  · rintro rfl
    rw [Nat.zero_xor, epsNeg_zero_right, epsNeg_zero_right, conjNeg_zero, conjNeg_of_ne hc0] at h
    have e : epsNeg n (i ^^^ j) j = !epsNeg n (i ^^^ j) i := by
      have := eps_left_xor hc hi hc0
      have h2 : (i ^^^ j) ^^^ i = j := by
        rw [Nat.xor_comm i j, Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
      rwa [h2] at this
    rw [e] at h
    revert h; cases epsNeg n (i ^^^ j) i <;> decide
  · intro hm
    have hk' : k = i ^^^ j := by
      have := congrArg (· ^^^ (i ^^^ j)) hm
      simpa [Nat.xor_assoc] using this
    rw [hm, hk', epsNeg_zero_left, epsNeg_zero_left, conjNeg_zero, conjNeg_of_ne hc0] at h
    have e : epsNeg n i (i ^^^ j) = !epsNeg n j (i ^^^ j) := by
      have := eps_right_xor hj hc hc0
      rwa [xor_xor_cancel_left' j i] at this
    rw [e] at h
    revert h; cases epsNeg n j (i ^^^ j) <;> decide
  · intro hkm
    have : i ^^^ j = 0 := by
      have := congrArg (k ^^^ ·) hkm
      simpa [← Nat.xor_assoc] using this.symm
    exact hc0 this

/-- One step of the annihilation graph (from any in-range vector) lands among the zero divisors
and preserves the XOR charge. -/
theorem adj_mem {n : Nat} (hn : 3 ≤ n) {x y : Label}
    (hadj : (annihGraph n).Adj x y) : y ∈ crossZD n ∧ charge y.1 = charge x.1 := by
  obtain ⟨_, hxr, hyr, hz⟩ := hadj
  rcases hz with hz | hz
  · obtain ⟨hm, _, hok⟩ := (vec_mul_eq_zero_iff n x y hxr hyr).1 hz
    obtain ⟨hk0, hm0, hkm⟩ := crossOK_partner_valid hxr.1 hxr.2 hyr.1 hok
    rw [← hm] at hm0 hkm
    refine ⟨(mem_crossZD_iff hn y).2 ⟨hyr.1, hyr.2, hk0, hm0, hkm⟩, ?_⟩
    simp only [charge]
    rw [hm, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
  · have hyz : IsCrossZD n y := ⟨hyr, x, hxr, vec_ne_zero n x hxr, hz⟩
    refine ⟨by rw [crossZD_eq hn]; exact (isCrossZD_iff hn y).1 hyz, ?_⟩
    obtain ⟨hm, _, _⟩ := (vec_mul_eq_zero_iff n y x hyr hxr).1 hz
    simp only [charge]
    rw [hm, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]

/-- Everything reachable from a zero divisor is a zero divisor of the same charge. -/
theorem reachable_mem {n : Nat} (hn : 3 ≤ n) {x y : Label} (hx : x ∈ crossZD n)
    (h : (annihGraph n).Reachable x y) : y ∈ crossZD n ∧ charge y.1 = charge x.1 := by
  obtain ⟨w⟩ := h
  induction w with
  | nil => exact ⟨hx, rfl⟩
  | cons hadj _ ih =>
    obtain ⟨hy, hc⟩ := adj_mem hn hadj
    obtain ⟨hz, hc'⟩ := ih hy
    exact ⟨hz, hc'.trans hc⟩

end CrossHalfComponents
end Sovereign
