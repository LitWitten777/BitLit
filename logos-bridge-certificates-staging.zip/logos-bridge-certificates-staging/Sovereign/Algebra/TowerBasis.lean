import Sovereign.Algebra.CayleyDickson
import Mathlib

namespace Sovereign

/-! ## 1. The tower and its algebraic instances -/

/-- The Cayley–Dickson tower over `ℤ`: `Tower n` has dimension `2ⁿ`. -/
def Tower : Nat → Type
  | 0 => Int
  | n + 1 => CD (Tower n)

instance towerAddCommGroup : (n : Nat) → AddCommGroup (Tower n)
  | 0 => inferInstanceAs (AddCommGroup Int)
  | n + 1 =>
    letI IH : AddCommGroup (Tower n) := towerAddCommGroup n
    { add := fun x y => (⟨x.re + y.re, x.im + y.im⟩ : CD (Tower n))
      zero := (⟨0, 0⟩ : CD (Tower n))
      neg := fun x => (⟨-x.re, -x.im⟩ : CD (Tower n))
      sub := fun x y => (⟨x.re - y.re, x.im - y.im⟩ : CD (Tower n))
      nsmul := fun k x => (⟨k • x.re, k • x.im⟩ : CD (Tower n))
      zsmul := fun k x => (⟨k • x.re, k • x.im⟩ : CD (Tower n))
      nsmul_zero := by intro a; exact CD.ext (zero_nsmul _) (zero_nsmul _)
      nsmul_succ := by intro k a; exact CD.ext (succ_nsmul ..) (succ_nsmul ..)
      zsmul_zero' := by intro a; exact CD.ext (zero_zsmul _) (zero_zsmul _)
      zsmul_succ' := by
        intro k a
        exact CD.ext (by simpa using (SubNegMonoid.zsmul_succ' k a.re))
          (by simpa using (SubNegMonoid.zsmul_succ' k a.im))
      zsmul_neg' := by
        intro k a
        exact CD.ext (by simpa using (SubNegMonoid.zsmul_neg' k a.re))
          (by simpa using (SubNegMonoid.zsmul_neg' k a.im))
      add_assoc := by intro a b c; exact CD.ext (add_assoc ..) (add_assoc ..)
      zero_add := by intro a; exact CD.ext (zero_add _) (zero_add _)
      add_zero := by intro a; exact CD.ext (add_zero _) (add_zero _)
      neg_add_cancel := by intro a; exact CD.ext (neg_add_cancel _) (neg_add_cancel _)
      sub_eq_add_neg := by intro a b; exact CD.ext (sub_eq_add_neg ..) (sub_eq_add_neg ..)
      add_comm := by intro a b; exact CD.ext (add_comm ..) (add_comm ..) }

instance towerConj : (n : Nat) → Conjugate (Tower n)
  | 0 => inferInstanceAs (Conjugate Int)
  | n + 1 => letI := towerConj n; inferInstanceAs (Conjugate (CD (Tower n)))

instance towerMul : (n : Nat) → Mul (Tower n)
  | 0 => inferInstanceAs (Mul Int)
  | n + 1 => letI := towerMul n; inferInstanceAs (Mul (CD (Tower n)))

instance towerDecEq : (n : Nat) → DecidableEq (Tower n)
  | 0 => inferInstanceAs (DecidableEq Int)
  | n + 1 => letI := towerDecEq n; inferInstanceAs (DecidableEq (CD (Tower n)))

/-! ## 2. Componentwise description of the operations -/

@[simp] theorem tower_add_re (n : Nat) (x y : Tower (n + 1)) : (x + y).re = x.re + y.re := rfl
@[simp] theorem tower_add_im (n : Nat) (x y : Tower (n + 1)) : (x + y).im = x.im + y.im := rfl
@[simp] theorem tower_neg_re (n : Nat) (x : Tower (n + 1)) : (-x).re = -x.re := rfl
@[simp] theorem tower_neg_im (n : Nat) (x : Tower (n + 1)) : (-x).im = -x.im := rfl
@[simp] theorem tower_zero_re (n : Nat) : (0 : Tower (n + 1)).re = 0 := rfl
@[simp] theorem tower_zero_im (n : Nat) : (0 : Tower (n + 1)).im = 0 := rfl
@[simp] theorem tower_conj_re (n : Nat) (x : Tower (n + 1)) : (conj x).re = conj x.re := rfl
@[simp] theorem tower_conj_im (n : Nat) (x : Tower (n + 1)) : (conj x).im = -x.im := rfl
@[simp] theorem tower_mul_re (n : Nat) (x y : Tower (n + 1)) :
    (x * y).re = x.re * y.re - conj y.im * x.im := rfl
@[simp] theorem tower_mul_im (n : Nat) (x y : Tower (n + 1)) :
    (x * y).im = y.im * x.re + x.im * conj y.re := rfl

theorem tower_eq_iff (n : Nat) (x y : Tower (n + 1)) : x = y ↔ x.re = y.re ∧ x.im = y.im :=
  ⟨fun h => by rw [h]; exact ⟨rfl, rfl⟩, fun h => CD.ext h.1 h.2⟩

/-! ## 3. Distributivity and additivity of conjugation -/

/-- The three structural laws of the tower, proved simultaneously by induction on the level. -/
theorem tower_laws (n : Nat) :
    (∀ x y z : Tower n, x * (y + z) = x * y + x * z) ∧
    (∀ x y z : Tower n, (x + y) * z = x * z + y * z) ∧
    (∀ x y : Tower n, conj (x + y) = conj x + conj y) := by
  induction n with
  | zero =>
    exact ⟨fun x y z => mul_add (R := Int) x y z, fun x y z => add_mul (R := Int) x y z,
      fun _ _ => rfl⟩
  | succ n ih =>
    obtain ⟨ihl, ihr, ihc⟩ := ih
    refine ⟨fun x y z => ?_, fun x y z => ?_, fun x y => ?_⟩
    · refine CD.ext ?_ ?_ <;> simp [ihl, ihr, ihc] <;> abel
    · refine CD.ext ?_ ?_ <;> simp [ihl, ihr] <;> abel
    · refine CD.ext ?_ ?_
      · simpa using ihc x.re y.re
      · simp
        exact add_comm _ _

theorem tower_mul_add (n : Nat) (x y z : Tower n) : x * (y + z) = x * y + x * z :=
  (tower_laws n).1 x y z

theorem tower_add_mul (n : Nat) (x y z : Tower n) : (x + y) * z = x * z + y * z :=
  (tower_laws n).2.1 x y z

theorem tower_conj_add (n : Nat) (x y : Tower n) : conj (x + y) = conj x + conj y :=
  (tower_laws n).2.2 x y

@[simp] theorem tower_mul_zero (n : Nat) (x : Tower n) : x * 0 = 0 := by
  have h := tower_mul_add n x 0 0
  rw [add_zero] at h
  exact left_eq_add.mp h

@[simp] theorem tower_zero_mul (n : Nat) (x : Tower n) : 0 * x = 0 := by
  have h := tower_add_mul n 0 0 x
  rw [add_zero] at h
  exact left_eq_add.mp h

theorem tower_neg_mul (n : Nat) (x y : Tower n) : (-x) * y = -(x * y) := by
  have h := tower_add_mul n (-x) x y
  rw [neg_add_cancel, tower_zero_mul] at h
  exact eq_neg_of_add_eq_zero_left h.symm

theorem tower_mul_neg (n : Nat) (x y : Tower n) : x * (-y) = -(x * y) := by
  have h := tower_mul_add n x (-y) y
  rw [neg_add_cancel, tower_mul_zero] at h
  exact eq_neg_of_add_eq_zero_left h.symm

@[simp] theorem tower_conj_zero (n : Nat) : conj (0 : Tower n) = 0 := by
  have h := tower_conj_add n 0 0
  rw [add_zero] at h
  exact (by simpa using h.symm)

theorem tower_conj_neg (n : Nat) (x : Tower n) : conj (-x) = -conj x := by
  have h := tower_conj_add n (-x) x
  rw [neg_add_cancel, tower_conj_zero] at h
  exact eq_neg_of_add_eq_zero_left h.symm

/-! ## 4. Signed elements -/

/-- `signed s x` is `-x` when the boolean sign flag `s` is `true`, and `x` otherwise. -/
def signed {G : Type} [Neg G] (s : Bool) (x : G) : G := if s then -x else x

@[simp] theorem signed_false {G : Type} [Neg G] (x : G) : signed false x = x := rfl
@[simp] theorem signed_true {G : Type} [Neg G] (x : G) : signed true x = -x := rfl

theorem signed_signed (n : Nat) (s t : Bool) (x : Tower n) :
    signed s (signed t x) = signed (xor s t) x := by
  cases s <;> cases t <;> simp [signed, neg_neg]

theorem signed_neg (n : Nat) (s : Bool) (x : Tower n) :
    -(signed s x) = signed (!s) x := by
  cases s <;> simp [signed, neg_neg]

theorem mul_signed (n : Nat) (s : Bool) (x y : Tower n) :
    x * signed s y = signed s (x * y) := by
  cases s <;> simp [signed, tower_mul_neg]

theorem signed_mul (n : Nat) (s : Bool) (x y : Tower n) :
    signed s x * y = signed s (x * y) := by
  cases s <;> simp [signed, tower_neg_mul]

@[simp] theorem signed_re (n : Nat) (s : Bool) (x : Tower (n + 1)) :
    (signed s x).re = signed s x.re := by
  cases s <;> rfl

@[simp] theorem signed_im (n : Nat) (s : Bool) (x : Tower (n + 1)) :
    (signed s x).im = signed s x.im := by
  cases s <;> rfl

@[simp] theorem signed_zero (n : Nat) (s : Bool) : signed s (0 : Tower n) = 0 := by
  cases s <;> simp [signed]

/-! ## 5. The basis and the twisted-XOR product law -/

/-- The `a`-th basis vector of `Tower n` (meaningful for `a < 2ⁿ`). -/
def basis : (n : Nat) → Nat → Tower n
  | 0, _ => (1 : Int)
  | n + 1, a =>
    if a < 2 ^ n then (⟨basis n a, 0⟩ : CD (Tower n))
    else (⟨0, basis n (a - 2 ^ n)⟩ : CD (Tower n))

/-- Conjugation negates every basis vector except `e₀`. -/
def conjNeg (a : Nat) : Bool := decide (a ≠ 0)

/-- The recursive Cayley–Dickson structure sign: `epsNeg n a b = true` exactly when
`eₐ · e_b = -e_{a ^^^ b}` in `Tower n`. -/
def epsNeg : (n : Nat) → Nat → Nat → Bool
  | 0, _, _ => false
  | n + 1, a, b =>
    if a < 2 ^ n then
      if b < 2 ^ n then epsNeg n a b
      else epsNeg n (b - 2 ^ n) a
    else
      if b < 2 ^ n then xor (conjNeg b) (epsNeg n (a - 2 ^ n) b)
      else !(xor (conjNeg (b - 2 ^ n)) (epsNeg n (b - 2 ^ n) (a - 2 ^ n)))

/-! ### Index arithmetic -/

theorem two_pow_add_eq_xor {n p : Nat} (h : p < 2 ^ n) : 2 ^ n + p = 2 ^ n ^^^ p := by
  have h1 := Nat.two_pow_add_eq_or_of_lt h 1
  simp at h1
  rw [h1]
  apply Nat.eq_of_testBit_eq
  intro i
  simp only [Nat.testBit_or, Nat.testBit_xor, Nat.testBit_two_pow]
  by_cases hi : n = i
  · subst hi
    have hp : p.testBit n = false := Nat.testBit_lt_two_pow h
    simp [hp]
  · simp [hi]

theorem xor_low_high {n a p : Nat} (ha : a < 2 ^ n) (hp : p < 2 ^ n) :
    a ^^^ (2 ^ n + p) = 2 ^ n + (a ^^^ p) := by
  rw [two_pow_add_eq_xor hp, two_pow_add_eq_xor (Nat.xor_lt_two_pow ha hp),
    ← Nat.xor_assoc, Nat.xor_comm a (2 ^ n), Nat.xor_assoc]

theorem xor_high_low {n j b : Nat} (hj : j < 2 ^ n) (hb : b < 2 ^ n) :
    (2 ^ n + j) ^^^ b = 2 ^ n + (j ^^^ b) := by
  rw [two_pow_add_eq_xor hj, two_pow_add_eq_xor (Nat.xor_lt_two_pow hj hb), Nat.xor_assoc]

theorem xor_high_high {n j m : Nat} (hj : j < 2 ^ n) (hm : m < 2 ^ n) :
    (2 ^ n + j) ^^^ (2 ^ n + m) = j ^^^ m := by
  rw [two_pow_add_eq_xor hj, two_pow_add_eq_xor hm, Nat.xor_assoc, ← Nat.xor_assoc j (2 ^ n) m,
    Nat.xor_comm j (2 ^ n), Nat.xor_assoc, ← Nat.xor_assoc (2 ^ n) (2 ^ n), Nat.xor_self,
    Nat.zero_xor]

/-- Conjugation acts on the basis by the sign `conjNeg`. -/
theorem basis_conj : ∀ (n a : Nat), a < 2 ^ n → conj (basis n a) = signed (conjNeg a) (basis n a) := by
  intro n
  induction n with
  | zero =>
    intro a ha
    have : a = 0 := by simpa using ha
    subst this
    rfl
  | succ n ih =>
    intro a ha
    by_cases h : a < 2 ^ n
    · have hb : basis (n + 1) a = (⟨basis n a, 0⟩ : CD (Tower n)) := by
        simp [basis, h]
      rw [hb]
      refine CD.ext ?_ ?_
      · simpa [signed_re] using ih a h
      · cases hcn : conjNeg a <;> simp [signed]
    · have hp : a - 2 ^ n < 2 ^ n := by
        have : a < 2 ^ (n + 1) := ha
        rw [pow_succ] at this
        omega
      have hb : basis (n + 1) a = (⟨0, basis n (a - 2 ^ n)⟩ : CD (Tower n)) := by
        simp [basis, h]
      have ha0 : conjNeg a = true := by
        have : 0 < 2 ^ n := by positivity
        simp [conjNeg]
        omega
      rw [hb, ha0]
      refine CD.ext ?_ ?_ <;> simp [signed]
/-- **Twisted-XOR basis product law.** In every Cayley–Dickson algebra of the tower the
product of two basis vectors is `± e_{a ^^^ b}`, with the explicit recursive sign `epsNeg`. -/
theorem basis_mul : ∀ (n a b : Nat), a < 2 ^ n → b < 2 ^ n →
    basis n a * basis n b = signed (epsNeg n a b) (basis n (a ^^^ b)) := by
  intro n
  induction n with
  | zero =>
    intro a b ha hb
    have ha0 : a = 0 := by simpa using ha
    have hb0 : b = 0 := by simpa using hb
    subst ha0; subst hb0
    rfl
  | succ n ih =>
    intro a b ha hb
    have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    have hHpos : 0 < 2 ^ n := by positivity
    by_cases hA : a < 2 ^ n <;> by_cases hB : b < 2 ^ n
    · -- low · low
      have hxor : a ^^^ b < 2 ^ n := Nat.xor_lt_two_pow hA hB
      have e1 : basis (n + 1) a = (⟨basis n a, 0⟩ : CD (Tower n)) := by simp [basis, hA]
      have e2 : basis (n + 1) b = (⟨basis n b, 0⟩ : CD (Tower n)) := by simp [basis, hB]
      have e3 : basis (n + 1) (a ^^^ b) = (⟨basis n (a ^^^ b), 0⟩ : CD (Tower n)) := by
        simp [basis, hxor]
      have hsign : epsNeg (n + 1) a b = epsNeg n a b := by simp [epsNeg, hA, hB]
      rw [e1, e2, e3, hsign]
      refine CD.ext ?_ ?_
      · simpa using ih a b hA hB
      · simp
    · -- low · high
      obtain ⟨p, hp, rfl⟩ : ∃ p, p < 2 ^ n ∧ b = 2 ^ n + p := ⟨b - 2 ^ n, by omega, by omega⟩
      have hxor : a ^^^ (2 ^ n + p) = 2 ^ n + (a ^^^ p) := xor_low_high hA hp
      have hxlt : ¬ (2 ^ n + (a ^^^ p) < 2 ^ n) := by omega
      have e1 : basis (n + 1) a = (⟨basis n a, 0⟩ : CD (Tower n)) := by simp [basis, hA]
      have e2 : basis (n + 1) (2 ^ n + p) = (⟨0, basis n p⟩ : CD (Tower n)) := by
        simp [basis, hB]
      have e3 : basis (n + 1) (a ^^^ (2 ^ n + p)) = (⟨0, basis n (a ^^^ p)⟩ : CD (Tower n)) := by
        rw [hxor]; simp [basis, hxlt]
      have hsign : epsNeg (n + 1) a (2 ^ n + p) = epsNeg n p a := by simp [epsNeg, hA, hB]
      rw [e1, e2, e3, hsign]
      refine CD.ext ?_ ?_
      · simp
      · have hih := ih p a hp hA
        rw [Nat.xor_comm p a] at hih
        simpa using hih
    · -- high · low
      obtain ⟨j, hj, rfl⟩ : ∃ j, j < 2 ^ n ∧ a = 2 ^ n + j := ⟨a - 2 ^ n, by omega, by omega⟩
      have hxor : (2 ^ n + j) ^^^ b = 2 ^ n + (j ^^^ b) := xor_high_low hj hB
      have hxlt : ¬ (2 ^ n + (j ^^^ b) < 2 ^ n) := by omega
      have e1 : basis (n + 1) (2 ^ n + j) = (⟨0, basis n j⟩ : CD (Tower n)) := by
        simp [basis, hA]
      have e2 : basis (n + 1) b = (⟨basis n b, 0⟩ : CD (Tower n)) := by simp [basis, hB]
      have e3 : basis (n + 1) ((2 ^ n + j) ^^^ b) = (⟨0, basis n (j ^^^ b)⟩ : CD (Tower n)) := by
        rw [hxor]; simp [basis, hxlt]
      have hsign : epsNeg (n + 1) (2 ^ n + j) b = xor (conjNeg b) (epsNeg n j b) := by
        simp [epsNeg, hA, hB]
      rw [e1, e2, e3, hsign]
      refine CD.ext ?_ ?_
      · simp
      · have hcb := basis_conj n b hB
        have hprod := ih j b hj hB
        simp only [tower_mul_im, tower_mul_zero, zero_add, signed_im]
        rw [hcb, mul_signed, hprod, signed_signed]
    · -- high · high
      obtain ⟨j, hj, rfl⟩ : ∃ j, j < 2 ^ n ∧ a = 2 ^ n + j := ⟨a - 2 ^ n, by omega, by omega⟩
      obtain ⟨m, hm, rfl⟩ : ∃ m, m < 2 ^ n ∧ b = 2 ^ n + m := ⟨b - 2 ^ n, by omega, by omega⟩
      have hxor : (2 ^ n + j) ^^^ (2 ^ n + m) = j ^^^ m := xor_high_high hj hm
      have hxlt : j ^^^ m < 2 ^ n := Nat.xor_lt_two_pow hj hm
      have e1 : basis (n + 1) (2 ^ n + j) = (⟨0, basis n j⟩ : CD (Tower n)) := by
        simp [basis, hA]
      have e2 : basis (n + 1) (2 ^ n + m) = (⟨0, basis n m⟩ : CD (Tower n)) := by
        simp [basis, hB]
      have e3 : basis (n + 1) ((2 ^ n + j) ^^^ (2 ^ n + m))
          = (⟨basis n (j ^^^ m), 0⟩ : CD (Tower n)) := by
        rw [hxor]; simp [basis, hxlt]
      have hsign : epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m)
          = !(xor (conjNeg m) (epsNeg n m j)) := by
        simp [epsNeg, hA, hB]
      rw [e1, e2, e3, hsign]
      refine CD.ext ?_ ?_
      · have hcb := basis_conj n m hm
        have hprod := ih m j hm hj
        simp only [tower_mul_re, tower_mul_zero, zero_sub, signed_re]
        rw [hcb, signed_mul, hprod, signed_signed, signed_neg, Nat.xor_comm m j]
      · simp
/-! ## 6. The standard relations of a Cayley–Dickson basis -/

/-- `e₀` never contributes a sign. -/
theorem epsNeg_zero_right : ∀ (n a : Nat), epsNeg n a 0 = false := by
  intro n
  induction n with
  | zero => intro a; rfl
  | succ n ih =>
    intro a
    have hHpos : 0 < 2 ^ n := by positivity
    by_cases hA : a < 2 ^ n <;> simp [epsNeg, hA, hHpos, ih, conjNeg]

theorem epsNeg_zero_left : ∀ (n b : Nat), epsNeg n 0 b = false := by
  intro n
  induction n with
  | zero => intro b; rfl
  | succ n ih =>
    intro b
    have hHpos : 0 < 2 ^ n := by positivity
    by_cases hB : b < 2 ^ n <;> simp [epsNeg, hHpos, hB, ih, epsNeg_zero_right]

/-- Every non-real basis vector squares to `-e₀`; `e₀` squares to itself. -/
theorem epsNeg_self : ∀ (n a : Nat), a < 2 ^ n → epsNeg n a a = conjNeg a := by
  intro n
  induction n with
  | zero =>
    intro a ha
    have : a = 0 := by simpa using ha
    subst this
    rfl
  | succ n ih =>
    intro a ha
    have hHpos : 0 < 2 ^ n := by positivity
    by_cases hA : a < 2 ^ n
    · simp [epsNeg, hA, ih a hA]
    · have hj : a - 2 ^ n < 2 ^ n := by
        have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
        omega
      have ha0 : conjNeg a = true := by simp [conjNeg]; omega
      simp [epsNeg, hA, ih (a - 2 ^ n) hj, ha0]

/-- Distinct non-real basis vectors anticommute. -/
theorem epsNeg_anticomm : ∀ (n a b : Nat), a < 2 ^ n → b < 2 ^ n → a ≠ b → a ≠ 0 → b ≠ 0 →
    epsNeg n a b = !(epsNeg n b a) := by
  intro n
  induction n with
  | zero =>
    intro a b ha hb _ ha0 _
    exact absurd (by simpa using ha) ha0
  | succ n ih =>
    intro a b ha hb hab ha0 hb0
    have hHpos : 0 < 2 ^ n := by positivity
    have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    by_cases hA : a < 2 ^ n <;> by_cases hB : b < 2 ^ n
    · simp only [epsNeg, if_pos hA, if_pos hB]
      exact ih a b hA hB hab ha0 hb0
    · have hm : b - 2 ^ n < 2 ^ n := by omega
      have hca : conjNeg a = true := by simp [conjNeg]; omega
      simp [epsNeg, hA, hB, hca]
    · have hj : a - 2 ^ n < 2 ^ n := by omega
      have hcb : conjNeg b = true := by simp [conjNeg]; omega
      simp [epsNeg, hA, hB, hcb]
    · have hj : a - 2 ^ n < 2 ^ n := by omega
      have hm : b - 2 ^ n < 2 ^ n := by omega
      have hjm : a - 2 ^ n ≠ b - 2 ^ n := by omega
      simp only [epsNeg, if_neg hA, if_neg hB]
      by_cases hj0 : a - 2 ^ n = 0
      · have hm0 : b - 2 ^ n ≠ 0 := by omega
        simp [hj0, epsNeg_zero_left, epsNeg_zero_right, conjNeg, hm0]
      · by_cases hm0 : b - 2 ^ n = 0
        · simp [hm0, epsNeg_zero_left, epsNeg_zero_right, conjNeg, hj0]
        · have hIH := ih (b - 2 ^ n) (a - 2 ^ n) hm hj (Ne.symm hjm) hm0 hj0
          have hcj : conjNeg (a - 2 ^ n) = true := by simp [conjNeg, hj0]
          have hcm : conjNeg (b - 2 ^ n) = true := by simp [conjNeg, hm0]
          rw [hcj, hcm, hIH]
          cases epsNeg n (a - 2 ^ n) (b - 2 ^ n) <;> simp

/-- `e₀` is a two-sided unit on basis vectors. -/
theorem basis_mul_zero_right (n a : Nat) (ha : a < 2 ^ n) :
    basis n a * basis n 0 = basis n a := by
  rw [basis_mul n a 0 ha (by positivity), epsNeg_zero_right, Nat.xor_zero]
  rfl

theorem basis_zero_mul (n a : Nat) (ha : a < 2 ^ n) :
    basis n 0 * basis n a = basis n a := by
  rw [basis_mul n 0 a (by positivity) ha, epsNeg_zero_left, Nat.zero_xor]
  rfl

/-- Every non-real basis vector squares to `-e₀`. -/
theorem basis_sq (n a : Nat) (ha : a < 2 ^ n) (ha0 : a ≠ 0) :
    basis n a * basis n a = -basis n 0 := by
  rw [basis_mul n a a ha ha, epsNeg_self n a ha, Nat.xor_self]
  simp [conjNeg, ha0, signed]

/-- Distinct non-real basis vectors anticommute. -/
theorem basis_anticomm (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) (hab : a ≠ b)
    (ha0 : a ≠ 0) (hb0 : b ≠ 0) :
    basis n a * basis n b = -(basis n b * basis n a) := by
  rw [basis_mul n a b ha hb, basis_mul n b a hb ha, epsNeg_anticomm n a b ha hb hab ha0 hb0,
    Nat.xor_comm b a, signed_neg]

/-- The product law for sign-decorated basis vectors: signed basis vectors are closed
under multiplication. -/
theorem signedBasis_mul (n : Nat) (s t : Bool) (a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    signed s (basis n a) * signed t (basis n b)
      = signed (xor s (xor t (epsNeg n a b))) (basis n (a ^^^ b)) := by
  rw [signed_mul, mul_signed, basis_mul n a b ha hb, signed_signed, signed_signed,
    Bool.xor_assoc]

end Sovereign
