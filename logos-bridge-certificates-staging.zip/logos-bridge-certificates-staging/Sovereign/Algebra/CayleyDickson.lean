namespace Sovereign

/-- One step of Cayley-Dickson doubling: pairs of elements of `A`. -/
structure CD (A : Type) where
  re : A  -- real part
  im : A  -- imaginary part
deriving DecidableEq, Repr, Inhabited

/-- Two Cayley–Dickson pairs are equal when their real and imaginary parts are. -/
theorem CD.ext {A : Type} {x y : CD A} (re : x.re = y.re) (im : x.im = y.im) : x = y := by
  cases x; cases y; simp_all

/-- Conjugation class for *-algebras in the Cayley-Dickson tower. -/
class Conjugate (A : Type) where
  conj : A → A

export Conjugate (conj)

/-- Base case: conjugation on ℤ is the identity. -/
instance : Conjugate Int := ⟨id⟩

/-- Recursive case: conjugation on CD A flips sign of imaginary part. -/
instance {A : Type} [Conjugate A] [Neg A] : Conjugate (CD A) :=
  ⟨fun x => ⟨conj x.re, -x.im⟩⟩

/-- Componentwise addition. -/
instance {A : Type} [Add A] : Add (CD A) :=
  ⟨fun x y => ⟨x.re + y.re, x.im + y.im⟩⟩

/-- Componentwise subtraction. -/
instance {A : Type} [Sub A] : Sub (CD A) :=
  ⟨fun x y => ⟨x.re - y.re, x.im - y.im⟩⟩

/-- Componentwise negation. -/
instance {A : Type} [Neg A] : Neg (CD A) :=
  ⟨fun x => ⟨-x.re, -x.im⟩⟩

/-- Zero element. -/
instance {A : Type} [Zero A] : Zero (CD A) :=
  ⟨⟨Zero.zero, Zero.zero⟩⟩

/-- One element. -/
instance {A : Type} [Zero A] [One A] : One (CD A) :=
  ⟨⟨One.one, Zero.zero⟩⟩

/-- Cayley-Dickson canonical product formula:
    (a, b)(c, d) = (ac - d*b, da + bc*) -/
instance {A : Type} [Mul A] [Add A] [Sub A] [Conjugate A] : Mul (CD A) :=
  ⟨fun x y => ⟨x.re * y.re - conj y.im * x.im, y.im * x.re + x.im * conj y.re⟩⟩

/-- Integer scalar multiplication on CD ℤ. -/
def smulCD : Int → CD Int → CD Int
  | n, ⟨r, i⟩ => ⟨n * r, n * i⟩

/-- Complex integers (Gaussian integers): ℤ[i] -/
abbrev CDComplex := CD Int

/-- Quaternion integers (Lipschitz quaternions) -/
abbrev CDQuaternion := CD CDComplex

/-- Octonion integers -/
abbrev CDOctonion := CD CDQuaternion

/-- Sedenion integers (16-dimensional, contains zero divisors) -/
abbrev CDSedenion := CD CDOctonion

/-- Real part of a product. -/
theorem mul_re {A : Type} [Mul A] [Add A] [Sub A] [Conjugate A]
    (x y : CD A) : (x * y).re = x.re * y.re - conj y.im * x.im := rfl

/-- Imaginary part of a product. -/
theorem mul_im {A : Type} [Mul A] [Add A] [Sub A] [Conjugate A]
    (x y : CD A) : (x * y).im = y.im * x.re + x.im * conj y.re := rfl

end Sovereign
