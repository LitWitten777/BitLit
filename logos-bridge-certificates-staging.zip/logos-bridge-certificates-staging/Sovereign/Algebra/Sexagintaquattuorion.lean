import Sovereign.Algebra.CrossHalfZeroDivisorTheorem
import Sovereign.Algebra.Trigintaduonion

namespace Sovereign

/-! ## 1. The concrete 64-dimensional algebra -/

/-! The trigintaduonion operations are named once here, so that the code generator does not
re-specialise the whole generic Cayley–Dickson product chain for level `6`.  Each instance is
definitionally the generic one. -/

/-- Trigintaduonion product. -/
def trigMul (x y : CDTrig) : CDTrig := x * y
/-- Trigintaduonion sum. -/
def trigAdd (x y : CDTrig) : CDTrig := x + y
/-- Trigintaduonion difference. -/
def trigSub (x y : CDTrig) : CDTrig := x - y
/-- Trigintaduonion negation. -/
def trigNeg (x : CDTrig) : CDTrig := -x
/-- Trigintaduonion conjugation. -/
def trigConj (x : CDTrig) : CDTrig := conj x

instance (priority := high) s64TrigMul : Mul CDTrig := ⟨trigMul⟩
instance (priority := high) s64TrigAdd : Add CDTrig := ⟨trigAdd⟩
instance (priority := high) s64TrigSub : Sub CDTrig := ⟨trigSub⟩
instance (priority := high) s64TrigNeg : Neg CDTrig := ⟨trigNeg⟩
instance (priority := high) s64TrigConjugate : Conjugate CDTrig := ⟨trigConj⟩
instance (priority := high) s64TrigDecidableEq : DecidableEq CDTrig := inferInstanceAs (DecidableEq (CD CDSedenion))

/-- The sexagintaquattuorions `𝕊₆₄`: one Cayley–Dickson doubling of the trigintaduonions. -/
abbrev CDSexagintaquattuorion := CD CDTrig

/-- Basis vectors `e₀, …, e₆₃` of the sexagintaquattuorions. -/
def e64 (i : Nat) : CDSexagintaquattuorion :=
  if i < 32 then ⟨e32 i, 0⟩ else ⟨0, e32 (i - 32)⟩

/-- Level `6` of the abstract tower is the concrete 64-dimensional algebra. -/
theorem tower_six_eq_sexagintaquattuorion : Tower 6 = CDSexagintaquattuorion := rfl

/-- The abstract basis of `Tower 6` is the concrete basis `e64`. -/
theorem basis_six_eq_e64 :
    ∀ a ∈ List.range 64, (basis 6 a : CDSexagintaquattuorion) = e64 a := by
  decide +kernel

/-- The abstract product of `Tower 6` agrees with the concrete Cayley–Dickson product of
`𝕊₆₄` on all `64 × 64` pairs of basis vectors. -/
theorem basis_six_mul_eq_e64_mul :
    ∀ a ∈ List.range 64, ∀ b ∈ List.range 64,
      ((basis 6 a * basis 6 b : Tower 6) : CDSexagintaquattuorion) = e64 a * e64 b := by
  intro a ha b hb
  rw [← basis_six_eq_e64 a ha, ← basis_six_eq_e64 b hb]

/-- A concrete zero-divisor pair of `𝕊₆₄`: `(e₁ + e₄₂)(e₂ + e₄₁) = 0`. -/
theorem e64_zeroDivisor_example :
    (e64 1 + e64 42) * (e64 2 + e64 41) = 0 ∧ e64 1 + e64 42 ≠ 0 ∧ e64 2 + e64 41 ≠ 0 := by
  decide +kernel

namespace ZDAsymptotics

open CrossHalfCriterion CrossHalf CrossHalfComponents

/-! ## 2. The cross-half family and its zero divisors -/

/-- All `D² = 4 · (D/2)²` sign-decorated cross-half labels of `Tower (N+1)`. -/
def crossLabels (N : Nat) : Finset Label :=
  crossIdx (2 ^ N) ×ˢ (Finset.univ : Finset (Bool × Bool))

theorem crossLabels_card (N : Nat) : (crossLabels N).card = (2 ^ (N + 1)) ^ 2 := by
  simp [crossLabels, crossIdx, Finset.card_product]
  ring

theorem crossZD_subset_crossLabels (N : Nat) : crossZD N ⊆ crossLabels N := by
  classical
  exact Finset.filter_subset _ _

/-- The vertices of the zero-divisor graph. -/
abbrev ZDVert (N : Nat) := {x : Label // x ∈ crossZD N}

/-- The annihilation graph restricted to the cross-half zero divisors. -/
def zdGraph (N : Nat) : SimpleGraph (ZDVert N) where
  Adj x y := (annihGraph N).Adj x.1 y.1
  symm := fun _ _ h => h.symm
  loopless := ⟨fun _ h => h.1 rfl⟩

/-- A walk of the full annihilation graph starting at a zero divisor stays among the zero
divisors, hence is a walk of `zdGraph`. -/
theorem zdGraph_reachable_of_walk {N : Nat} (hN : 3 ≤ N) {u v : Label}
    (w : (annihGraph N).Walk u v) :
    ∀ (hu : u ∈ crossZD N) (hv : v ∈ crossZD N), (zdGraph N).Reachable ⟨u, hu⟩ ⟨v, hv⟩ := by
  induction w with
  | nil => intro _ _; rfl
  | cons h _ ih =>
    intro hu hv
    have hadj : (zdGraph N).Adj ⟨_, hu⟩ ⟨_, (adj_mem hN h).1⟩ := h
    exact hadj.reachable.trans (ih _ hv)

/-- **Components = charge sectors.** Two cross-half zero divisors are joined by a path of
annihilations iff they carry the same XOR charge. -/
theorem zdGraph_reachable_iff {N : Nat} (hN : 3 ≤ N) (x y : ZDVert N) :
    (zdGraph N).Reachable x y ↔ charge x.1.1 = charge y.1.1 := by
  constructor
  · rintro ⟨w⟩
    have hw : (annihGraph N).Reachable x.1 y.1 :=
      ⟨w.map (⟨Subtype.val, fun h => h⟩ : zdGraph N →g annihGraph N)⟩
    exact (reachable_mem hN x.2 hw).2.symm
  · intro h
    obtain ⟨w⟩ := (reachable_iff hN x.2).2 ⟨y.2, h.symm⟩
    exact zdGraph_reachable_of_walk hN w x.2 y.2

/-! ## 3. The components -/

/-- The XOR charge of a component. -/
def componentCharge {N : Nat} (hN : 3 ≤ N) : (zdGraph N).ConnectedComponent → Nat :=
  SimpleGraph.ConnectedComponent.lift (fun x => charge x.1.1) fun _ _ w _ =>
    (zdGraph_reachable_iff hN _ _).1 ⟨w⟩

theorem componentCharge_injective {N : Nat} (hN : 3 ≤ N) :
    Function.Injective (componentCharge hN) := by
  intro C D h
  induction C using SimpleGraph.ConnectedComponent.ind with
  | _ p =>
  induction D using SimpleGraph.ConnectedComponent.ind with
  | _ q =>
    exact SimpleGraph.ConnectedComponent.sound ((zdGraph_reachable_iff hN p q).2 h)

theorem range_componentCharge {N : Nat} (hN : 3 ≤ N) :
    Set.range (componentCharge hN) = (Finset.Ico 1 (2 ^ N) : Set Nat) := by
  ext c
  constructor
  · rintro ⟨C, rfl⟩
    induction C using SimpleGraph.ConnectedComponent.ind with
    | _ p => exact charge_mem_Ico hN p.2
  · intro hc
    rw [Finset.coe_Ico, Set.mem_Ico] at hc
    have h16 : 2 ^ 4 ≤ 2 ^ (N + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
    have hpos : 0 < (crossSector N c).card := by
      rw [crossSector_card hN c (by omega) hc.2]
      omega
    obtain ⟨x, hx⟩ := Finset.card_pos.1 hpos
    rw [crossSector, Finset.mem_filter] at hx
    exact ⟨(zdGraph N).connectedComponentMk ⟨x, hx.1⟩, hx.2⟩

/-- **Component count.** In dimension `D = 2ᴺ⁺¹ ≥ 16` the annihilation graph of the
cross-half zero divisors has exactly `D/2 - 1 = 2ᴺ - 1` connected components. -/
theorem zdGraph_components_card {N : Nat} (hN : 3 ≤ N) :
    Nat.card (zdGraph N).ConnectedComponent = 2 ^ N - 1 := by
  rw [Nat.card_congr ((Equiv.ofInjective _ (componentCharge_injective hN)).trans
    (Equiv.setCongr (range_componentCharge hN))), Nat.card_coe_set_eq, Set.ncard_coe_finset,
    Nat.card_Ico]

/-- **Projective count.** The components are counted by `|PG(N-1, 𝔽₂)|`. -/
theorem zdGraph_components_card_eq_PG {N : Nat} (hN : 3 ≤ N) :
    Nat.card (zdGraph N).ConnectedComponent =
      Nat.card (Projectivization (ZMod 2) (Fin N → ZMod 2)) := by
  rw [zdGraph_components_card hN, card_projective]

/-- **Component size.** Every component has exactly `2(D - 4)` vertices. -/
theorem zdGraph_component_card {N : Nat} (hN : 3 ≤ N) (C : (zdGraph N).ConnectedComponent) :
    Nat.card C.supp = 2 * (2 ^ (N + 1) - 4) := by
  induction C using SimpleGraph.ConnectedComponent.ind with
  | _ x =>
  have hc := charge_mem_Ico hN x.2
  rw [Finset.mem_Ico] at hc
  have e : ((zdGraph N).connectedComponentMk x).supp ≃
      {y : Label // y ∈ crossSector N (charge x.1.1)} :=
    { toFun := fun v => ⟨v.1.1, by
        have hv := v.2
        rw [SimpleGraph.ConnectedComponent.mem_supp_iff,
          SimpleGraph.ConnectedComponent.eq] at hv
        rw [crossSector, Finset.mem_filter]
        exact ⟨v.1.2, ((zdGraph_reachable_iff hN _ _).1 hv)⟩⟩
      invFun := fun y => ⟨⟨y.1, (Finset.mem_filter.1 y.2).1⟩, by
        rw [SimpleGraph.ConnectedComponent.mem_supp_iff, SimpleGraph.ConnectedComponent.eq]
        exact (zdGraph_reachable_iff hN _ _).2 (Finset.mem_filter.1 y.2).2⟩
      left_inv := fun v => rfl
      right_inv := fun y => rfl }
  rw [Nat.card_congr e, Nat.card_eq_fintype_card, Fintype.card_coe,
    crossSector_card hN _ (by omega) hc.2]

/-! ## 4. Asymptotics -/

/-- The fraction of cross-half basis vectors `± eᵢ ± e_{D/2+j}` of `Tower (N+1)` that are
zero divisors. -/
noncomputable def zdFraction (N : Nat) : ℝ :=
  ((crossZD N).card : ℝ) / ((crossLabels N).card : ℝ)

theorem zdFraction_eq {N : Nat} (hN : 3 ≤ N) :
    zdFraction N = ((2 : ℝ) ^ (N + 1) - 2) * ((2 : ℝ) ^ (N + 1) - 4) / ((2 : ℝ) ^ (N + 1)) ^ 2 := by
  have h16 : 2 ^ 4 ≤ 2 ^ (N + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  rw [zdFraction, crossZD_card hN, crossLabels_card, Nat.cast_mul,
    Nat.cast_sub (by omega), Nat.cast_sub (by omega)]
  push_cast
  ring

/-- Explicit bounds `1 - 6/D < fraction < 1`, `D = 2ᴺ⁺¹`. -/
theorem zdFraction_bounds {N : Nat} (hN : 3 ≤ N) :
    1 - 6 / (2 : ℝ) ^ (N + 1) < zdFraction N ∧ zdFraction N < 1 := by
  rw [zdFraction_eq hN]
  have h16 : (2 : ℝ) ^ 4 ≤ 2 ^ (N + 1) := pow_le_pow_right₀ (by norm_num) (by omega)
  set D : ℝ := 2 ^ (N + 1)
  have hD : (16 : ℝ) ≤ D := by norm_num at h16; linarith
  have hD0 : 0 < D := by linarith
  constructor
  · rw [lt_div_iff₀ (by positivity)]
    have key : (1 - 6 / D) * D ^ 2 = D ^ 2 - 6 * D := by field_simp
    rw [key]
    nlinarith
  · rw [div_lt_one (by positivity)]
    nlinarith

/-- **Asymptotic density.** The fraction of cross-half basis vectors that are zero divisors
tends to `1` along the Cayley–Dickson tower. -/
theorem zdFraction_tendsto_one :
    Filter.Tendsto zdFraction Filter.atTop (nhds 1) := by
  have hx : Filter.Tendsto (fun N : Nat => (1 / 2 : ℝ) ^ (N + 1)) Filter.atTop (nhds 0) :=
    (tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)).comp
      (Filter.tendsto_add_atTop_nat 1)
  have hlim : Filter.Tendsto
      (fun N : Nat => (1 - 2 * (1 / 2 : ℝ) ^ (N + 1)) * (1 - 4 * (1 / 2 : ℝ) ^ (N + 1)))
      Filter.atTop (nhds 1) := by
    have := (tendsto_const_nhds (x := (1 : ℝ)).sub (hx.const_mul 2)).mul
      (tendsto_const_nhds (x := (1 : ℝ)).sub (hx.const_mul 4))
    simpa using this
  refine hlim.congr' ?_
  filter_upwards [Filter.eventually_ge_atTop 3] with N hN
  rw [zdFraction_eq hN, one_div_pow]
  field_simp

/-- The component count `2ᴺ - 1` is asymptotic to `2ᴺ = D/2`. -/
theorem componentRatio_tendsto_one :
    Filter.Tendsto (fun N : Nat => ((2 ^ N - 1 : Nat) : ℝ) / (2 : ℝ) ^ N) Filter.atTop
      (nhds 1) := by
  have hx : Filter.Tendsto (fun N : Nat => (1 / 2 : ℝ) ^ N) Filter.atTop (nhds 0) :=
    tendsto_pow_atTop_nhds_zero_of_lt_one (by norm_num) (by norm_num)
  have hlim : Filter.Tendsto (fun N : Nat => 1 - (1 / 2 : ℝ) ^ N) Filter.atTop (nhds 1) := by
    simpa using (tendsto_const_nhds (x := (1 : ℝ))).sub hx
  refine hlim.congr' (Filter.Eventually.of_forall fun N => ?_)
  show _ = ((2 ^ N - 1 : Nat) : ℝ) / (2 : ℝ) ^ N
  rw [Nat.cast_sub Nat.one_le_two_pow, one_div_pow]
  push_cast
  field_simp

/-- **Asymptotic theorem for the Cayley–Dickson tower.**  Along the tower `D = 2ⁿ`
(`n ≥ 4`, written `n = N + 1`), the cross-half zero divisors number `(D - 2)(D - 4)`, they
form `2ⁿ⁻¹ - 1 = |PG(n-2, 𝔽₂)|` components of `2(D - 4)` vertices each; their fraction among
all `D²` cross-half basis vectors tends to `1`, and the component count is asymptotic to
`2ⁿ⁻¹`. -/
theorem tower_zeroDivisor_asymptotics :
    (∀ N, 3 ≤ N →
      (crossZD N).card = (2 ^ (N + 1) - 2) * (2 ^ (N + 1) - 4) ∧
      Nat.card (zdGraph N).ConnectedComponent = 2 ^ N - 1 ∧
      Nat.card (zdGraph N).ConnectedComponent =
        Nat.card (Projectivization (ZMod 2) (Fin N → ZMod 2)) ∧
      ∀ C : (zdGraph N).ConnectedComponent, Nat.card C.supp = 2 * (2 ^ (N + 1) - 4)) ∧
    Filter.Tendsto zdFraction Filter.atTop (nhds 1) ∧
    Filter.Tendsto
      (fun N => (Nat.card (zdGraph N).ConnectedComponent : ℝ) / (2 : ℝ) ^ N)
      Filter.atTop (nhds 1) := by
  refine ⟨fun N hN => ⟨crossZD_card hN, zdGraph_components_card hN,
    zdGraph_components_card_eq_PG hN, zdGraph_component_card hN⟩, zdFraction_tendsto_one, ?_⟩
  refine componentRatio_tendsto_one.congr' ?_
  filter_upwards [Filter.eventually_ge_atTop 3] with N hN
  rw [zdGraph_components_card hN]

end ZDAsymptotics

/-! ## 5. The 64-dimensional case -/

namespace S64

open CrossHalfComponents ZDAsymptotics

/-- **3720 cross-half zero divisors in `𝕊₆₄`.**  Level `N = 5` of the tower is
`Tower 6 = CDSexagintaquattuorion`. -/
theorem crossZD_card : (crossZD 5).card = 3720 ∧ (64 - 2) * (64 - 4) = 3720 := by
  rw [CrossHalfComponents.crossZD_card (by norm_num)]
  norm_num

/-- **31 components.** -/
theorem components_card : Nat.card (zdGraph 5).ConnectedComponent = 31 := by
  rw [zdGraph_components_card (by norm_num)]
  norm_num

/-- The 31 components are counted by the points of `PG(4, 𝔽₂) = ℙ(𝔽₂⁵)`. -/
theorem components_card_eq_PG :
    Nat.card (zdGraph 5).ConnectedComponent =
      Nat.card (Projectivization (ZMod 2) (Fin 5 → ZMod 2)) :=
  zdGraph_components_card_eq_PG (by norm_num)

/-- The same count in the formulation of `CrossHalfZeroDivisorTheorem` (components of the full
annihilation graph that contain a zero divisor). -/
theorem components_card' : (CrossHalfComponents.components 5).card = 31 := by
  rw [component_count (by norm_num)]
  norm_num

/-- **Each component has 120 vertices**, and `31 · 120 = 3720`. -/
theorem component_card (C : (zdGraph 5).ConnectedComponent) :
    Nat.card C.supp = 120 ∧ 31 * 120 = 3720 := by
  rw [zdGraph_component_card (by norm_num)]
  norm_num

end S64

end Sovereign
