import Sovereign.Algebra.TowerAssociator

namespace Sovereign

/-! ## 1. Conjugation is an involutive anti-automorphism -/

/-- The two conjugation laws of the tower, proved simultaneously by induction on the
level: conjugation is an involution and an anti-automorphism. -/
theorem tower_conj_laws (n : Nat) :
    (∀ x : Tower n, conj (conj x) = x) ∧
    (∀ x y : Tower n, conj (x * y) = conj y * conj x) := by
  induction n with
  | zero => exact ⟨fun _ => rfl, fun x y => Int.mul_comm x y⟩
  | succ n ih =>
    obtain ⟨ihinv, ihanti⟩ := ih
    refine ⟨fun x => ?_, fun x y => ?_⟩
    · exact CD.ext (by simpa using ihinv x.re) (by simp)
    · have hsub : ∀ u v : Tower n, conj (u - v) = conj u - conj v := by
        intro u v
        rw [sub_eq_add_neg, tower_conj_add, tower_conj_neg, sub_eq_add_neg]
      refine CD.ext ?_ ?_
      · simp only [tower_conj_re, tower_conj_im, tower_mul_re]
        rw [hsub, ihanti, ihanti, ihinv, tower_conj_neg, tower_neg_mul, tower_mul_neg,
          neg_neg]
      · simp only [tower_conj_re, tower_conj_im, tower_mul_im, ihinv]
        rw [tower_neg_mul, tower_neg_mul]
        abel

/-- Conjugation is an involution on every algebra of the tower. -/
theorem tower_conj_conj (n : Nat) (x : Tower n) : conj (conj x) = x :=
  (tower_conj_laws n).1 x

/-- **Conjugation is an anti-automorphism** of every algebra of the Cayley–Dickson
tower: `conj (x * y) = conj y * conj x`, in every dimension `2ⁿ`. -/
theorem tower_conj_mul (n : Nat) (x y : Tower n) : conj (x * y) = conj y * conj x :=
  (tower_conj_laws n).2 x y

theorem tower_conj_injective (n : Nat) {x y : Tower n} (h : conj x = conj y) : x = y := by
  have := congrArg (fun z : Tower n => conj z) h
  simpa [tower_conj_conj] using this

/-! ## 2. The associator and reversal -/

/-- The associator `[x, y, z] = (x y) z - x (y z)`. -/
def assoc3 {n : Nat} (x y z : Tower n) : Tower n := (x * y) * z - x * (y * z)

/-- **Reversal law for the associator.** Conjugating an associator reverses the triple
and flips the sign: `conj [x, y, z] = -[conj z, conj y, conj x]`. -/
theorem assoc3_conj (n : Nat) (x y z : Tower n) :
    conj (assoc3 x y z) = -assoc3 (conj z) (conj y) (conj x) := by
  have hsub : ∀ u v : Tower n, conj (u - v) = conj u - conj v := by
    intro u v
    have : u - v = u + -v := by abel
    rw [this, tower_conj_add, tower_conj_neg]
    abel
  simp only [assoc3, hsub, tower_conj_mul]
  abel

/-- A triple associates exactly when the reversed triple of conjugates associates. -/
theorem tower_assoc_iff_reverse (n : Nat) (x y z : Tower n) :
    (x * y) * z = x * (y * z) ↔
      (conj z * conj y) * conj x = conj z * (conj y * conj x) := by
  constructor
  · intro h
    have h0 : assoc3 x y z = 0 := by rw [assoc3, h, sub_self]
    have hc := assoc3_conj n x y z
    rw [h0, tower_conj_zero] at hc
    exact sub_eq_zero.mp (neg_eq_zero.mp hc.symm)
  · intro h
    have h0 : assoc3 (conj z) (conj y) (conj x) = 0 := by rw [assoc3, h, sub_self]
    have hc := assoc3_conj n x y z
    rw [h0, neg_zero] at hc
    have : assoc3 x y z = 0 := tower_conj_injective n (by rw [hc, tower_conj_zero])
    exact sub_eq_zero.mp this

/-- **Reversal invariance of the associator sign**, in every dimension. -/
theorem assocNeg_reverse (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n)
    (hc : c < 2 ^ n) : assocNeg n a b c = assocNeg n c b a := by
  have hconj : ∀ m : Nat, m < 2 ^ n →
      conj (basis n m) = signed (conjNeg m) (basis n m) := fun m hm => basis_conj n m hm
  have key : assocNeg n a b c = false ↔ assocNeg n c b a = false := by
    rw [← basis_assoc_eq_iff n a b c ha hb hc, ← basis_assoc_eq_iff n c b a hc hb ha]
    rw [tower_assoc_iff_reverse n (basis n a) (basis n b) (basis n c)]
    rw [hconj a ha, hconj b hb, hconj c hc]
    cases conjNeg a <;> cases conjNeg b <;> cases conjNeg c <;>
      simp [signed, tower_neg_mul, tower_mul_neg, neg_eq_iff_eq_neg]
  cases h1 : assocNeg n a b c <;> cases h2 : assocNeg n c b a <;> simp_all

/-- The algebraic form of reversal invariance on basis vectors. -/
theorem basis_assoc_reverse (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n)
    (hc : c < 2 ^ n) :
    ((basis n a * basis n b) * basis n c = basis n a * (basis n b * basis n c))
      ↔ ((basis n c * basis n b) * basis n a = basis n c * (basis n b * basis n a)) := by
  rw [basis_assoc_eq_iff n a b c ha hb hc, basis_assoc_eq_iff n c b a hc hb ha,
    assocNeg_reverse n a b c ha hb hc]

/-! ## 3. Normalization -/

theorem assocNeg_zero_mid (n a c : Nat) : assocNeg n a 0 c = false := by
  simp only [assocNeg, epsNeg_zero_right, epsNeg_zero_left, Nat.xor_zero, Nat.zero_xor]
  cases epsNeg n a c <;> simp

/-! ## 4. The Mac Lane pentagon: the associator sign is a 3-cocycle -/

/-- The Boolean skeleton of the pentagon identity: the ten sign values that occur in the
five associator signs cancel in pairs. -/
theorem pentagon_bool (e1 e2 e3 e4 e5 e6 e7 e8 e9 e10 : Bool) :
    xor (xor (xor e2 e5) (xor e3 e7))
      (xor (xor (xor e4 e8) (xor e3 e9))
        (xor (xor (xor e6 e8) (xor e5 e10))
          (xor (xor (xor e1 e9) (xor e7 e10))
            (xor (xor e1 e4) (xor e2 e6))))) = false := by
  decide +revert

/-- **Pentagon identity (Mac Lane 3-cocycle condition).** For every level `n` and all
indices, the coboundary of the associator sign vanishes:
`ω(b,c,d) ⊕ ω(a⊕b,c,d) ⊕ ω(a,b⊕c,d) ⊕ ω(a,b,c⊕d) ⊕ ω(a,b,c) = 0`. -/
theorem assocNeg_pentagon (n a b c d : Nat) :
    xor (assocNeg n b c d)
      (xor (assocNeg n (a ^^^ b) c d)
        (xor (assocNeg n a (b ^^^ c) d)
          (xor (assocNeg n a b (c ^^^ d)) (assocNeg n a b c)))) = false := by
  simp only [assocNeg, Nat.xor_assoc]
  exact pentagon_bool (epsNeg n a b) (epsNeg n b c) (epsNeg n c d) (epsNeg n (a ^^^ b) c)
    (epsNeg n (b ^^^ c) d) (epsNeg n a (b ^^^ c)) (epsNeg n b (c ^^^ d))
    (epsNeg n (a ^^^ (b ^^^ c)) d) (epsNeg n (a ^^^ b) (c ^^^ d))
    (epsNeg n a (b ^^^ (c ^^^ d)))

/-! ## 5. The `±1`-valued phase -/

/-- The associator phase `(-1)^assocNeg`: `+1` when the triple associates, `-1` otherwise. -/
def assocPhase (n a b c : Nat) : Int := if assocNeg n a b c then -1 else 1

theorem assocPhase_eq_one_iff (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n)
    (hc : c < 2 ^ n) :
    assocPhase n a b c = 1 ↔
      (basis n a * basis n b) * basis n c = basis n a * (basis n b * basis n c) := by
  rw [basis_assoc_eq_iff n a b c ha hb hc, assocPhase]
  cases assocNeg n a b c <;> simp

theorem assocPhase_mul_self (n a b c : Nat) : assocPhase n a b c * assocPhase n a b c = 1 := by
  simp only [assocPhase]
  cases assocNeg n a b c <;> norm_num

/-- **Multiplicative pentagon identity** for the `±1` associator phase: the five phases of
a Mac Lane pentagon multiply to `+1`, in every dimension and for every quadruple. -/
theorem assocPhase_pentagon (n a b c d : Nat) :
    assocPhase n b c d * assocPhase n (a ^^^ b) c d * assocPhase n a (b ^^^ c) d *
      assocPhase n a b (c ^^^ d) * assocPhase n a b c = 1 := by
  have h := assocNeg_pentagon n a b c d
  simp only [assocPhase]
  revert h
  cases assocNeg n b c d <;> cases assocNeg n (a ^^^ b) c d <;>
    cases assocNeg n a (b ^^^ c) d <;> cases assocNeg n a b (c ^^^ d) <;>
      cases assocNeg n a b c <;> simp

/-- Reversal invariance of the phase. -/
theorem assocPhase_reverse (n a b c : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n)
    (hc : c < 2 ^ n) : assocPhase n a b c = assocPhase n c b a := by
  simp [assocPhase, assocNeg_reverse n a b c ha hb hc]

/-! ## 6. Sedenion (level 4) instances -/

/-- The sedenion triple `(e₁, e₂, e₄)` does not associate. -/
theorem sedenion_assocNeg_e1_e2_e4 : assocNeg 4 1 2 4 = true := by decide

/-- The quaternionic triple `(e₁, e₂, e₃)` associates. -/
theorem sedenion_assocNeg_e1_e2_e3 : assocNeg 4 1 2 3 = false := by decide

/-- The associator of `(e₁, e₂, e₄)` is twice a basis vector: `[e₁, e₂, e₄] = 2 e₇`,
so the triple is genuinely non-associative. -/
theorem sedenion_associator_e1_e2_e4 :
    assoc3 (basis 4 1) (basis 4 2) (basis 4 4)
      = basis 4 7 + basis 4 7 := by decide

/-- The phase of the non-associating sedenion triple is `-1`. -/
theorem sedenion_assocPhase_e1_e2_e4 : assocPhase 4 1 2 4 = -1 := by decide

/-- The phase of the associating quaternionic triple is `+1`. -/
theorem sedenion_assocPhase_e1_e2_e3 : assocPhase 4 1 2 3 = 1 := by decide

/-- The pentagon identity on the canonical sedenion quadruple `(e₁, e₂, e₄, e₈)`,
an instance of the general theorem. -/
theorem sedenion_pentagon_e1_e2_e4_e8 :
    assocPhase 4 2 4 8 * assocPhase 4 (1 ^^^ 2) 4 8 * assocPhase 4 1 (2 ^^^ 4) 8 *
      assocPhase 4 1 2 (4 ^^^ 8) * assocPhase 4 1 2 4 = 1 :=
  assocPhase_pentagon 4 1 2 4 8

end Sovereign
