/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Every charge sector of the cross-half zero-divisor graph is connected

For `D = 2ᴺ⁺¹ ≥ 16` we prove that the annihilation graph restricted to one XOR-charge sector
is connected.  The argument is uniform in the dimension:

* `allReach_fwd`, `allReach_bwd` : an edge `i → k` of the index condition `crossOK` lets all
  four sign decorations of one endpoint reach all four of the other, once they are reached;
* `allReach_triangle` : a triangle of index edges with odd total sign parity `edgePar`
  makes all sign decorations of one vertex reachable from a single one;
* `sector_allReach_low`, `sector_allReach_pole`, `sector_allReach_high` : explicit odd
  triangles and explicit spanning edges for the three kinds of charge `c < D/4`, `c = D/4`,
  `c > D/4`;
* `reachable_iff` : **two zero divisors are connected iff they have the same charge.**
-/

import Sovereign.Algebra.CrossHalfComponents

namespace Sovereign
namespace CrossHalfComponents

open CrossHalfCriterion CrossHalf

/-! ## 1. Sector labels and the edge lemma -/

/-- The label of `signed s eᵢ + signed t e_{H + (i ^^^ c)}`, a vector of charge `c`. -/
def lab (c i : Nat) (s t : Bool) : Label := ((i, i ^^^ c), (s, t))

theorem crossOK_irrefl {n i j : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    ¬ crossOK n i j i := by
  intro h
  unfold crossOK at h
  have e : i ^^^ (i ^^^ j) = j := by rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
  rw [e, epsNeg_self n i hi, epsNeg_self n j hj] at h
  revert h
  cases conjNeg i <;> cases conjNeg j <;> cases epsNeg n j i <;> decide

theorem sector_adj {N c i k : Nat} (hi : i < 2 ^ N) (hk : k < 2 ^ N) (hc : c < 2 ^ N)
    (hok : crossOK N i (i ^^^ c) k) (s t u r : Bool)
    (hp : xor (xor s t) (xor u r) = edgePar N i (i ^^^ c) k) :
    (annihGraph N).Adj (lab c i s t) (lab c k u r) := by
  have hic : i ^^^ c < 2 ^ N := Nat.xor_lt_two_pow hi hc
  have hne : i ≠ k := by
    rintro rfl
    exact crossOK_irrefl hi hic hok
  refine ⟨fun h => hne (congrArg (fun x : Label => x.1.1) h), ⟨hi, hic⟩,
    ⟨hk, Nat.xor_lt_two_pow hk hc⟩, Or.inl ?_⟩
  refine (vec_mul_eq_zero_iff N _ _ ⟨hi, hic⟩ ⟨hk, Nat.xor_lt_two_pow hk hc⟩).2 ⟨?_, hp, hok⟩
  simp only [lab]
  rw [← Nat.xor_assoc i i c, Nat.xor_self, Nat.zero_xor]

/-- All four sign-decorations of index `k` in sector `c` are reachable from `R`. -/
def AllReach (N c : Nat) (R : Label) (k : Nat) : Prop :=
  ∀ u r, (annihGraph N).Reachable R (lab c k u r)

theorem allReach_fwd {N c i k : Nat} {R : Label} (hi : i < 2 ^ N) (hk : k < 2 ^ N)
    (hc : c < 2 ^ N) (hok : crossOK N i (i ^^^ c) k) (h : AllReach N c R i) :
    AllReach N c R k := by
  intro u r
  have hadj := sector_adj hi hk hc hok false (xor (edgePar N i (i ^^^ c) k) (xor u r)) u r
    (by cases edgePar N i (i ^^^ c) k <;> cases u <;> cases r <;> rfl)
  exact (h _ _).trans hadj.reachable

theorem allReach_bwd {N c i k : Nat} {R : Label} (hi : i < 2 ^ N) (hk : k < 2 ^ N)
    (hc : c < 2 ^ N) (hok : crossOK N i (i ^^^ c) k) (h : AllReach N c R k) :
    AllReach N c R i := by
  intro s t
  have hadj := sector_adj hi hk hc hok s t false (xor (edgePar N i (i ^^^ c) k) (xor s t))
    (by cases edgePar N i (i ^^^ c) k <;> cases s <;> cases t <;> rfl)
  exact (h _ _).trans hadj.reachable.symm

/-- **Odd triangle.** An odd-parity triangle `a → b`, `a → d`, `d → b` makes every
sign-decoration of `b` reachable from any decoration of `a`. -/
theorem allReach_triangle {N c a b d : Nat} (ha : a < 2 ^ N) (hb : b < 2 ^ N) (hd : d < 2 ^ N)
    (hc : c < 2 ^ N) (hab : crossOK N a (a ^^^ c) b) (had : crossOK N a (a ^^^ c) d)
    (hdb : crossOK N d (d ^^^ c) b)
    (hpar : xor (edgePar N a (a ^^^ c) b)
      (xor (edgePar N a (a ^^^ c) d) (edgePar N d (d ^^^ c) b)) = true)
    (s0 t0 : Bool) : AllReach N c (lab c a s0 t0) b := by
  intro u r
  by_cases hq : xor (xor s0 t0) (xor u r) = edgePar N a (a ^^^ c) b
  · exact (sector_adj ha hb hc hab s0 t0 u r hq).reachable
  · set pd := xor (xor s0 t0) (edgePar N a (a ^^^ c) d) with hpd
    have h1 := sector_adj ha hd hc had s0 t0 false pd (by
      rw [hpd]; cases s0 <;> cases t0 <;> cases edgePar N a (a ^^^ c) d <;> rfl)
    have h2 := sector_adj hd hb hc hdb false pd u r (by
      rw [hpd]
      revert hq hpar
      cases s0 <;> cases t0 <;> cases u <;> cases r <;>
        cases edgePar N a (a ^^^ c) b <;> cases edgePar N a (a ^^^ c) d <;>
          cases edgePar N d (d ^^^ c) b <;> decide)
    exact h1.reachable.trans h2.reachable

/-! ## 2. Further explicit edges and their parities -/

theorem crossOK_low_h0 {n i j : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) : crossOK (n + 1) i j (2 ^ n + 0) := by
  have hc : i ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hi hj
  unfold crossOK
  rw [xor_high_low (Nat.two_pow_pos n) hc, Nat.zero_xor, eps_lh _ hi, eps_hl _ hj,
    eps_hl _ hi, eps_lh _ hj, conjNeg_high, conjNeg_high]
  have hc0 : i ^^^ j ≠ 0 := fun h => hij (Nat.eq_of_xor_eq_zero h)
  have e : epsNeg n (i ^^^ j) j = !epsNeg n (i ^^^ j) i := by
    have := eps_left_xor hc hi hc0
    have h2 : (i ^^^ j) ^^^ i = j := by
      rw [Nat.xor_comm i j, Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
    rwa [h2] at this
  rw [e, epsNeg_zero_left, epsNeg_zero_left, conjNeg_of_ne hi0, conjNeg_of_ne hj0]
  cases epsNeg n (i ^^^ j) i <;> decide

theorem crossOK_low_hi {n i j : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) : crossOK (n + 1) i j (2 ^ n + i) := by
  unfold crossOK
  rw [xor_high_low hi (Nat.xor_lt_two_pow hi hj), ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor,
    eps_lh _ hi, eps_hl _ hj, eps_hl _ hi, eps_lh _ hj, conjNeg_high, conjNeg_high]
  rw [epsNeg_self n i hi, epsNeg_self n j hj, conjNeg_of_ne hi0, conjNeg_of_ne hj0,
    epsNeg_anticomm n j i hj hi (Ne.symm hij) hj0 hi0]
  cases epsNeg n i j <;> decide

theorem edgePar_ll {n i k : Nat} (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hi0 : i ≠ 0) : edgePar (n + 1) i (2 ^ n + i) k = true := by
  unfold edgePar
  rw [xor_low_high hi hi, Nat.xor_self, xor_low_high hk (Nat.two_pow_pos n), Nat.xor_zero,
    eps_ll hi hk, eps_hh, conjNeg_high]
  rw [conjNeg_of_ne hi0]
  cases epsNeg n i k <;> decide

theorem parA {n i j : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) :
    xor (edgePar (n + 1) i j (2 ^ n + 0))
      (xor (edgePar (n + 1) i j (2 ^ n + i))
        (edgePar (n + 1) (2 ^ n + i) (2 ^ n + j) (2 ^ n + 0))) = true := by
  have hc : i ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hi hj
  unfold edgePar
  rw [xor_high_low (Nat.two_pow_pos n) hc, Nat.zero_xor,
    xor_high_low hi hc, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor,
    xor_high_high hi hj, xor_high_low (Nat.two_pow_pos n) hc, Nat.zero_xor]
  rw [eps_lh _ hi, eps_hl _ hj, eps_lh _ hi, eps_hl _ hj, eps_hh, eps_hh]
  simp only [conjNeg_high]
  have e1 : epsNeg n (i ^^^ j) j = !epsNeg n i j := eps_right_xor hi hj hj0
  have e2 : epsNeg n j (i ^^^ j) = !epsNeg n j i := by
    rw [Nat.xor_comm]; exact eps_left_xor hj hi hj0
  rw [e1, e2, epsNeg_zero_left, epsNeg_self n i hi, epsNeg_self n j hj, conjNeg_zero,
    conjNeg_of_ne hi0, conjNeg_of_ne hj0, epsNeg_anticomm n j i hj hi (Ne.symm hij) hj0 hi0]
  cases epsNeg n i j <;> decide

theorem parB {n c e : Nat} (hc : c < 2 ^ n) (he : e < 2 ^ n) (hc0 : c ≠ 0)
    (he0 : e ≠ 0) (hec : e ≠ c) :
    xor (edgePar (n + 1) c (2 ^ n + 0) (e ^^^ c))
      (xor (edgePar (n + 1) c (2 ^ n + 0) e)
        (edgePar (n + 1) e (2 ^ n + (e ^^^ c)) (e ^^^ c))) = true := by
  have hx : e ^^^ c < 2 ^ n := Nat.xor_lt_two_pow he hc
  unfold edgePar
  have h1 : (e ^^^ c) ^^^ c = e := by rw [Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
  have h2 : e ^^^ (e ^^^ c) = c := by rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
  rw [xor_low_high hc (Nat.two_pow_pos n), Nat.xor_zero, xor_low_high hx hc,
    xor_low_high he hc, xor_low_high he hx, h2, xor_low_high hx hc, h1]
  rw [eps_ll hc hx, eps_ll hc he, eps_ll he hx, eps_hh, eps_hh, eps_hh]
  simp only [conjNeg_high]
  have hx0 : e ^^^ c ≠ 0 := fun h => hec (Nat.eq_of_xor_eq_zero h)
  have e1 : epsNeg n c (e ^^^ c) = !epsNeg n c e := by
    rw [Nat.xor_comm]; exact eps_left_xor hc he hc0
  have e2 : epsNeg n e (e ^^^ c) = !epsNeg n e c := eps_left_xor he hc he0
  have e3 : epsNeg n (e ^^^ c) e = !epsNeg n c e := by
    rw [Nat.xor_comm]; exact eps_right_xor hc he he0
  rw [e1, e2, e3, epsNeg_zero_left, epsNeg_zero_left, conjNeg_zero, conjNeg_of_ne hx0,
    epsNeg_anticomm n e c he hc hec he0 hc0]
  cases epsNeg n c e <;> decide

/-! ## 3. Every sector is connected -/

theorem lt_succ_pow {n x : Nat} (hx : x < 2 ^ n) : x < 2 ^ (n + 1) := by
  have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
  omega

theorem high_lt_succ_pow {n x : Nat} (hx : x < 2 ^ n) : 2 ^ n + x < 2 ^ (n + 1) := by
  have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
  omega

theorem xor_ne_zero_of_ne {a b : Nat} (h : a ≠ b) : a ^^^ b ≠ 0 :=
  fun h' => h (Nat.eq_of_xor_eq_zero h')

theorem ne_xor_self {a c : Nat} (hc : c ≠ 0) : a ≠ a ^^^ c := by
  intro h
  apply hc
  have := congrArg (a ^^^ ·) h
  simpa [← Nat.xor_assoc] using this.symm

/-- Low charge `0 < c < D/4`. -/
theorem sector_allReach_low {n c : Nat} (hn : 2 ≤ n) (hc0 : c ≠ 0) (hc : c < 2 ^ n) :
    ∃ R, ∀ i, i < 2 ^ (n + 1) → i ≠ 0 → i ≠ c → AllReach (n + 1) c R i := by
  have hcN := lt_succ_pow hc
  set a := otherIdx c with ha_def
  have ha : a < 2 ^ n := otherIdx_lt hn c
  have ha0 : a ≠ 0 := otherIdx_ne_zero c
  have hac : a ≠ c := otherIdx_ne c
  have hja : a ^^^ c < 2 ^ n := Nat.xor_lt_two_pow ha hc
  have hja0 : a ^^^ c ≠ 0 := xor_ne_zero_of_ne hac
  have haja : a ≠ a ^^^ c := ne_xor_self hc0
  have hb := high_lt_succ_pow (Nat.two_pow_pos n)
  have hd := high_lt_succ_pow ha
  have eb : (2 ^ n + 0) ^^^ c = 2 ^ n + c := by
    rw [xor_high_low (Nat.two_pow_pos n) hc, Nat.zero_xor]
  have ed : (2 ^ n + a) ^^^ c = 2 ^ n + (a ^^^ c) := xor_high_low ha hc
  have hab : crossOK (n + 1) a (a ^^^ c) (2 ^ n + 0) := crossOK_low_h0 ha hja ha0 hja0 haja
  have had : crossOK (n + 1) a (a ^^^ c) (2 ^ n + a) := crossOK_low_hi ha hja ha0 hja0 haja
  have hdb : crossOK (n + 1) (2 ^ n + a) ((2 ^ n + a) ^^^ c) (2 ^ n + 0) := by
    rw [ed]; exact crossOK_hh ha hja ha0 hja0 haja
  have hpar := parA ha hja ha0 hja0 haja
  rw [← ed] at hpar
  have hB := allReach_triangle (lt_succ_pow ha) hb hd hcN hab had hdb hpar false false
  refine ⟨lab c a false false, ?_⟩
  have hlow : ∀ k, k < 2 ^ n → k ≠ 0 → k ≠ c → AllReach (n + 1) c (lab c a false false) k := by
    intro k hk hk0 hkc
    refine allReach_fwd hb (lt_succ_pow hk) hcN ?_ hB
    rw [eb]; exact crossOK_h0 hc hk hc0 hk0 hkc
  intro i hi hi0 hic
  rcases split_idx hi with hil | ⟨i', hi', rfl⟩
  · exact hlow i hil hi0 hic
  · by_cases h0 : i' = 0
    · subst h0; exact hB
    · by_cases h1 : i' = c
      · subst h1
        refine allReach_bwd (high_lt_succ_pow hc) (lt_succ_pow ha) hcN ?_ (hlow a ha ha0 hac)
        rw [xor_high_low hc hc, Nat.xor_self]
        exact crossOK_0h hc ha hc0 ha0 hac
      · refine allReach_bwd (high_lt_succ_pow hi') hb hcN ?_ hB
        rw [xor_high_low hi' hc]
        exact crossOK_hh hi' (Nat.xor_lt_two_pow hi' hc) h0 (xor_ne_zero_of_ne h1)
          (ne_xor_self hc0)

/-- The doubling-pole charge `c = D/4`. -/
theorem sector_allReach_pole {n : Nat} (hn : 2 ≤ n) :
    ∃ R, ∀ i, i < 2 ^ (n + 1) → i ≠ 0 → i ≠ 2 ^ n + 0 → AllReach (n + 1) (2 ^ n + 0) R i := by
  have h4 : 4 ≤ 2 ^ n := by
    calc 4 = 2 ^ 2 := by norm_num
      _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  have hcN := high_lt_succ_pow (Nat.two_pow_pos n)
  have e : ∀ a, a < 2 ^ n → a ^^^ (2 ^ n + 0) = 2 ^ n + a := by
    intro a ha; rw [xor_low_high ha (Nat.two_pow_pos n), Nat.xor_zero]
  have hok : ∀ a k, a < 2 ^ n → k < 2 ^ n → a ≠ 0 → k ≠ 0 → k ≠ a →
      crossOK (n + 1) a (a ^^^ (2 ^ n + 0)) k := by
    intro a k ha hk ha0 hk0 hka
    rw [e a ha]; exact crossOK_ll ha hk ha0 hk0 hka
  have hpar : ∀ a k, a < 2 ^ n → k < 2 ^ n → a ≠ 0 →
      edgePar (n + 1) a (a ^^^ (2 ^ n + 0)) k = true := by
    intro a k ha hk ha0
    rw [e a ha]; exact edgePar_ll ha hk ha0
  have h1 : (1 : Nat) < 2 ^ n := by omega
  have h2 : (2 : Nat) < 2 ^ n := by omega
  have h3 : (3 : Nat) < 2 ^ n := by omega
  have hT := allReach_triangle (lt_succ_pow h1) (lt_succ_pow h3) (lt_succ_pow h2) hcN
    (hok 1 3 h1 h3 (by omega) (by omega) (by omega))
    (hok 1 2 h1 h2 (by omega) (by omega) (by omega))
    (hok 2 3 h2 h3 (by omega) (by omega) (by omega))
    (by rw [hpar 1 3 h1 h3 (by omega), hpar 1 2 h1 h2 (by omega), hpar 2 3 h2 h3 (by omega)]; rfl)
    false false
  refine ⟨lab (2 ^ n + 0) 1 false false, ?_⟩
  have hlow : ∀ k, k < 2 ^ n → k ≠ 0 →
      AllReach (n + 1) (2 ^ n + 0) (lab (2 ^ n + 0) 1 false false) k := by
    intro k hk hk0
    by_cases hk3 : k = 3
    · subst hk3; exact hT
    · exact allReach_fwd (lt_succ_pow h3) (lt_succ_pow hk) hcN
        (hok 3 k h3 hk (by omega) hk0 hk3) hT
  intro i hi hi0 hic
  rcases split_idx hi with hil | ⟨i', hi', rfl⟩
  · exact hlow i hil hi0
  · have hi'0 : i' ≠ 0 := by rintro rfl; exact hic rfl
    have ho := otherIdx_lt hn i'
    refine allReach_bwd (high_lt_succ_pow hi') (lt_succ_pow ho) hcN ?_
      (hlow _ ho (otherIdx_ne_zero i'))
    rw [xor_high_high hi' (Nat.two_pow_pos n), Nat.xor_zero]
    exact crossOK_jl hi' ho hi'0 (otherIdx_ne_zero i') (otherIdx_ne i')

/-- High charge `c = D/4 + c'` with `c' ≠ 0`. -/
theorem sector_allReach_high {n c : Nat} (hn : 2 ≤ n) (hc0 : c ≠ 0) (hc : c < 2 ^ n) :
    ∃ R, ∀ i, i < 2 ^ (n + 1) → i ≠ 0 → i ≠ 2 ^ n + c →
      AllReach (n + 1) (2 ^ n + c) R i := by
  have hcN := high_lt_succ_pow hc
  set e := otherIdx c with he_def
  have he : e < 2 ^ n := otherIdx_lt hn c
  have he0 : e ≠ 0 := otherIdx_ne_zero c
  have hec : e ≠ c := otherIdx_ne c
  have hb : e ^^^ c < 2 ^ n := Nat.xor_lt_two_pow he hc
  have hb0 : e ^^^ c ≠ 0 := xor_ne_zero_of_ne hec
  have hbc : e ^^^ c ≠ c := by
    intro h; apply he0
    have := congrArg (· ^^^ c) h
    simpa [Nat.xor_assoc] using this
  have ea : c ^^^ (2 ^ n + c) = 2 ^ n + 0 := by rw [xor_low_high hc hc, Nat.xor_self]
  have ed : e ^^^ (2 ^ n + c) = 2 ^ n + (e ^^^ c) := xor_low_high he hc
  have hl0 : ∀ k, k < 2 ^ n → k ≠ 0 → k ≠ c → crossOK (n + 1) c (c ^^^ (2 ^ n + c)) k := by
    intro k hk hk0 hkc
    rw [ea]; exact crossOK_l0 hc hk hc0 hk0 hkc
  have hdb : crossOK (n + 1) e (e ^^^ (2 ^ n + c)) (e ^^^ c) := by
    rw [ed]; exact crossOK_lh he hb he0 hb0 (ne_xor_self hc0)
  have hpar := parB hc he hc0 he0 hec
  rw [← ea, ← ed] at hpar
  have hT := allReach_triangle (lt_succ_pow hc) (lt_succ_pow hb) (lt_succ_pow he) hcN
    (hl0 _ hb hb0 hbc) (hl0 _ he he0 hec) hdb hpar false false
  refine ⟨lab (2 ^ n + c) c false false, ?_⟩
  have hC : AllReach (n + 1) (2 ^ n + c) (lab (2 ^ n + c) c false false) c :=
    allReach_bwd (lt_succ_pow hc) (lt_succ_pow hb) hcN (hl0 _ hb hb0 hbc) hT
  have hlow : ∀ k, k < 2 ^ n → k ≠ 0 →
      AllReach (n + 1) (2 ^ n + c) (lab (2 ^ n + c) c false false) k := by
    intro k hk hk0
    by_cases hkc : k = c
    · subst hkc; exact hC
    · exact allReach_fwd (lt_succ_pow hc) (lt_succ_pow hk) hcN (hl0 k hk hk0 hkc) hC
  intro i hi hi0 hic
  rcases split_idx hi with hil | ⟨i', hi', rfl⟩
  · exact hlow i hil hi0
  · have hi'c : i' ≠ c := by rintro rfl; exact hic rfl
    by_cases h0 : i' = 0
    · subst h0
      have ho := otherIdx_lt hn c
      refine allReach_bwd (high_lt_succ_pow (Nat.two_pow_pos n)) (lt_succ_pow ho) hcN ?_
        (hlow _ ho (otherIdx_ne_zero c))
      rw [xor_high_high (Nat.two_pow_pos n) hc, Nat.zero_xor]
      exact crossOK_0l hc ho hc0 (otherIdx_ne_zero c) (otherIdx_ne c)
    · refine allReach_bwd (high_lt_succ_pow hi') (lt_succ_pow hi') hcN ?_ (hlow i' hi' h0)
      rw [xor_high_high hi' hc]
      exact crossOK_hl hi' (Nat.xor_lt_two_pow hi' hc) h0 (xor_ne_zero_of_ne hi'c)
        (ne_xor_self hc0)

theorem sector_allReach {n c : Nat} (hn : 2 ≤ n) (hc0 : c ≠ 0) (hc : c < 2 ^ (n + 1)) :
    ∃ R, ∀ i, i < 2 ^ (n + 1) → i ≠ 0 → i ≠ c → AllReach (n + 1) c R i := by
  rcases split_idx hc with hcl | ⟨c', hc', rfl⟩
  · exact sector_allReach_low hn hc0 hcl
  · by_cases h0 : c' = 0
    · subst h0; exact sector_allReach_pole hn
    · exact sector_allReach_high hn h0 hc'

theorem lab_of_mem {N : Nat} (hN : 3 ≤ N) {x : Label} (hx : x ∈ crossZD N) :
    x = lab (charge x.1) x.1.1 x.2.1 x.2.2 ∧ x.1.1 < 2 ^ N ∧ x.1.1 ≠ 0 ∧ x.1.1 ≠ charge x.1 := by
  rw [mem_crossZD_iff hN] at hx
  obtain ⟨⟨i, j⟩, s, t⟩ := x
  simp only [lab, charge] at hx ⊢
  refine ⟨?_, hx.1, hx.2.2.1, ?_⟩
  · rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
  · intro h
    apply hx.2.2.2.1
    have := congrArg (i ^^^ ·) h
    simpa [← Nat.xor_assoc] using this.symm

/-- **The components are exactly the charge sectors.** Two cross-half zero divisors of the
Cayley–Dickson algebra of dimension `2ᴺ⁺¹ ≥ 16` lie in the same connected component of the
annihilation graph if and only if they have the same XOR charge `i ^^^ j`. Moreover the
component of a zero divisor contains only zero divisors. -/
theorem reachable_iff {N : Nat} (hN : 3 ≤ N) {x y : Label} (hx : x ∈ crossZD N) :
    (annihGraph N).Reachable x y ↔ (y ∈ crossZD N ∧ charge y.1 = charge x.1) := by
  refine ⟨reachable_mem hN hx, ?_⟩
  rintro ⟨hy, hxy⟩
  obtain ⟨n, rfl⟩ : ∃ n, N = n + 1 := ⟨N - 1, by omega⟩
  have hc := charge_mem_Ico hN hx
  rw [Finset.mem_Ico] at hc
  obtain ⟨R, hR⟩ := sector_allReach (n := n) (by omega) (by omega) hc.2
  obtain ⟨ex, hx1, hx2, hx3⟩ := lab_of_mem hN hx
  obtain ⟨ey, hy1, hy2, hy3⟩ := lab_of_mem hN hy
  rw [hxy] at ey hy3
  have h1 := hR _ hx1 hx2 hx3 x.2.1 x.2.2
  have h2 := hR _ hy1 hy2 hy3 y.2.1 y.2.2
  rw [← ex] at h1
  rw [← ey] at h2
  exact h1.symm.trans h2

end CrossHalfComponents
end Sovereign
