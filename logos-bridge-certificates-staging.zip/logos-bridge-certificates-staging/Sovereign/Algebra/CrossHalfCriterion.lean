import Sovereign.Algebra.TowerZeroDivisors

namespace Sovereign
namespace CrossHalfCriterion

/-! ## 1. The structure sign one level up -/

theorem eps_ll {n a b : Nat} (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    epsNeg (n + 1) a b = epsNeg n a b := by
  simp [epsNeg, ha, hb]

theorem eps_lh {n a : Nat} (b : Nat) (ha : a < 2 ^ n) :
    epsNeg (n + 1) a (2 ^ n + b) = epsNeg n b a := by
  simp [epsNeg, ha]

theorem eps_hl {n b : Nat} (a : Nat) (hb : b < 2 ^ n) :
    epsNeg (n + 1) (2 ^ n + a) b = xor (conjNeg b) (epsNeg n a b) := by
  simp [epsNeg, hb]

theorem eps_hh {n : Nat} (a b : Nat) :
    epsNeg (n + 1) (2 ^ n + a) (2 ^ n + b) = !(xor (conjNeg b) (epsNeg n b a)) := by
  simp [epsNeg]

@[simp] theorem conjNeg_zero : conjNeg 0 = false := rfl

theorem conjNeg_of_ne {a : Nat} (h : a ≠ 0) : conjNeg a = true := by simp [conjNeg, h]

theorem conjNeg_high (n a : Nat) : conjNeg (2 ^ n + a) = true :=
  conjNeg_of_ne (by have : 0 < 2 ^ n := (by positivity); omega)

theorem split_idx {n a : Nat} (ha : a < 2 ^ (n + 1)) :
    a < 2 ^ n ∨ ∃ a', a' < 2 ^ n ∧ a = 2 ^ n + a' := by
  by_cases h : a < 2 ^ n
  · exact Or.inl h
  · refine Or.inr ⟨a - 2 ^ n, ?_, by omega⟩
    have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
    omega

/-! ## 2. The left and right quaternionic sign laws -/

/-- `eₚ (eₚ e_q) = -e_q` and `(eₚ e_q) e_q = -eₚ` at the level of signs. -/
theorem epsNeg_xor_laws : ∀ n : Nat,
    (∀ p q, p < 2 ^ n → q < 2 ^ n → p ≠ 0 → epsNeg n p (p ^^^ q) = !epsNeg n p q) ∧
    (∀ p q, p < 2 ^ n → q < 2 ^ n → q ≠ 0 → epsNeg n (p ^^^ q) q = !epsNeg n p q) := by
  intro n
  induction n with
  | zero =>
    refine ⟨fun p q hp _ h0 => absurd (by simpa using hp) h0,
      fun p q _ hq h0 => absurd (by simpa using hq) h0⟩
  | succ n ih =>
    obtain ⟨IL, IR⟩ := ih
    have anti := epsNeg_anticomm n
    have self := epsNeg_self n
    have z1 := epsNeg_zero_left n
    have z2 := epsNeg_zero_right n
    constructor
    · intro p q hp hq hp0
      rcases split_idx hp with hpl | ⟨p', hp', rfl⟩ <;>
        rcases split_idx hq with hql | ⟨q', hq', rfl⟩
      · rw [eps_ll hpl (Nat.xor_lt_two_pow hpl hql), eps_ll hpl hql]
        exact IL p q hpl hql hp0
      · rw [xor_low_high hpl hq', eps_lh _ hpl, eps_lh _ hpl, Nat.xor_comm]
        exact IR q' p hq' hpl hp0
      · rw [xor_high_low hp' hql, eps_hh, eps_hl _ hql]
        by_cases h0 : p' = 0
        · subst h0; simp [z1, z2]
        · have hR := IR q p' hql hp' h0
          rw [Nat.xor_comm] at hR
          rw [hR]
          by_cases hq0 : q = 0
          · subst hq0; simp [z1, z2, conjNeg_of_ne h0]
          · by_cases hqp : q = p'
            · subst hqp; simp [self q hql, conjNeg_of_ne h0]
            · have hx : p' ^^^ q ≠ 0 := fun h => hqp (Nat.eq_of_xor_eq_zero h).symm
              rw [conjNeg_of_ne hx, conjNeg_of_ne hq0, anti p' q hp' hql (Ne.symm hqp) h0 hq0]
      · rw [xor_high_high hp' hq', eps_hl _ (Nat.xor_lt_two_pow hp' hq'), eps_hh]
        by_cases h0 : p' = 0
        · subst h0; simp [z1, z2]
        · rw [IL p' q' hp' hq' h0]
          by_cases hq0 : q' = 0
          · subst hq0; simp [z1, z2, conjNeg_of_ne h0]
          · by_cases hqp : q' = p'
            · subst hqp; simp [self q' hq', conjNeg_of_ne hq0]
            · have hx : p' ^^^ q' ≠ 0 := fun h => hqp (Nat.eq_of_xor_eq_zero h).symm
              rw [conjNeg_of_ne hx, conjNeg_of_ne hq0, anti q' p' hq' hp' hqp hq0 h0]
              cases epsNeg n p' q' <;> rfl
    · intro p q hp hq hq0
      rcases split_idx hp with hpl | ⟨p', hp', rfl⟩ <;>
        rcases split_idx hq with hql | ⟨q', hq', rfl⟩
      · rw [eps_ll (Nat.xor_lt_two_pow hpl hql) hql, eps_ll hpl hql]
        exact IR p q hpl hql hq0
      · rw [xor_low_high hpl hq', eps_hh, eps_lh _ hpl]
        by_cases h0 : q' = 0
        · subst h0; simp [z1]
        · rw [Nat.xor_comm, IL q' p hq' hpl h0, conjNeg_of_ne h0]
          cases epsNeg n q' p <;> rfl
      · rw [xor_high_low hp' hql, eps_hl _ hql, eps_hl _ hql, IR p' q hp' hql hq0]
        cases conjNeg q <;> cases epsNeg n p' q <;> rfl
      · rw [xor_high_high hp' hq', eps_lh _ (Nat.xor_lt_two_pow hp' hq'), eps_hh]
        by_cases h0 : q' = 0
        · subst h0; simp [z1]
        · rw [Nat.xor_comm, IL q' p' hq' hp' h0, conjNeg_of_ne h0]
          cases epsNeg n q' p' <;> rfl

theorem eps_left_xor {n p q : Nat} (hp : p < 2 ^ n) (hq : q < 2 ^ n) (hp0 : p ≠ 0) :
    epsNeg n p (p ^^^ q) = !epsNeg n p q := (epsNeg_xor_laws n).1 p q hp hq hp0

theorem eps_right_xor {n p q : Nat} (hp : p < 2 ^ n) (hq : q < 2 ^ n) (hq0 : q ≠ 0) :
    epsNeg n (p ^^^ q) q = !epsNeg n p q := (epsNeg_xor_laws n).2 p q hp hq hq0

/-! ## 3. Reduction of the annihilation problem to an index condition -/

/-- The sign-free index condition: the cross-half vector `± eᵢ ± e_{H+j}` of `Tower (n+1)`
is annihilated by a cross-half vector `± e_k ± e_{H+m}` (for suitable signs) exactly when
`m = k ^^^ i ^^^ j` and this condition holds. -/
def crossOK (n i j k : Nat) : Prop :=
  xor (epsNeg n i k) (xor (conjNeg (k ^^^ (i ^^^ j))) (epsNeg n (k ^^^ (i ^^^ j)) j)) =
    !(xor (epsNeg n (k ^^^ (i ^^^ j)) i) (xor (conjNeg k) (epsNeg n j k)))

instance (n i j k : Nat) : Decidable (crossOK n i j k) := by
  unfold crossOK; infer_instance

theorem sign_choice_iff (s t A B C D : Bool) :
    (∃ u r : Bool, xor s (xor u A) ≠ xor t (xor r (!B)) ∧ xor s (xor r C) ≠ xor t (xor u D))
      ↔ xor A B = !(xor C D) := by
  revert s t A B C D; decide

theorem hasCrossPartner_iff (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) :
    hasCrossPartner n s t i j = true ↔ ∃ k, k < 2 ^ n ∧ crossOK n i j k := by
  simp only [hasCrossPartner, List.any_eq_true, List.mem_range, List.mem_cons,
    List.not_mem_nil, or_false, Bool.and_eq_true, decide_eq_true_iff]
  constructor
  · rintro ⟨k, hk, m, hm, u, _, r, _, ⟨h1, h2⟩, h3⟩
    have hm' : m = k ^^^ (i ^^^ j) := by rw [h1, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
    subst hm'
    refine ⟨k, hk, ?_⟩
    rw [eps_ll hi hk, eps_hh] at h2
    rw [eps_lh _ hi, eps_hl _ hk] at h3
    exact (sign_choice_iff s t _ _ _ _).1 ⟨u, r, h2, h3⟩
  · rintro ⟨k, hk, hok⟩
    obtain ⟨u, r, h2, h3⟩ := (sign_choice_iff s t _ _ _ _).2 hok
    refine ⟨k, hk, k ^^^ (i ^^^ j), Nat.xor_lt_two_pow hk (Nat.xor_lt_two_pow hi hj),
      u, by cases u <;> simp, r, by cases r <;> simp,
      ⟨by rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor], ?_⟩, ?_⟩
    · rw [eps_ll hi hk, eps_hh]; exact h2
    · rw [eps_lh _ hi, eps_hl _ hk]; exact h3

/-! ## 4. Necessity -/

theorem crossOK_valid {n i j k : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n)
    (h : crossOK n i j k) : i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j := by
  have self := epsNeg_self n
  have z1 := epsNeg_zero_left n
  have z2 := epsNeg_zero_right n
  unfold crossOK at h
  have hi0 : i ≠ 0 := by
    rintro rfl
    rw [Nat.zero_xor, z1, z2] at h
    by_cases hj0 : j = 0
    · subst hj0
      rw [Nat.xor_zero, z2, z1] at h
      cases conjNeg k <;> simp at h
    · rw [eps_right_xor hk hj hj0] at h
      by_cases hk0 : k = 0
      · subst hk0
        simp [z1, z2, conjNeg_of_ne hj0] at h
      · by_cases hkj : k = j
        · subst hkj
          simp [self k hk, conjNeg_of_ne hk0] at h
        · have hx : k ^^^ j ≠ 0 := fun h' => hkj (Nat.eq_of_xor_eq_zero h')
          rw [conjNeg_of_ne hx, conjNeg_of_ne hk0, epsNeg_anticomm n j k hj hk (Ne.symm hkj) hj0 hk0] at h
          cases epsNeg n k j <;> simp at h
  have hj0 : j ≠ 0 := by
    rintro rfl
    rw [Nat.xor_zero, z1, z2, eps_right_xor hk hi hi0] at h
    by_cases hk0 : k = 0
    · subst hk0
      simp [z1, z2, conjNeg_of_ne hi0] at h
    · by_cases hki : k = i
      · subst hki
        simp [self k hk, conjNeg_of_ne hk0] at h
      · have hx : k ^^^ i ≠ 0 := fun h' => hki (Nat.eq_of_xor_eq_zero h')
        rw [conjNeg_of_ne hx, conjNeg_of_ne hk0, epsNeg_anticomm n i k hi hk (Ne.symm hki) hi0 hk0] at h
        cases epsNeg n k i <;> simp at h
  refine ⟨hi0, hj0, ?_⟩
  rintro rfl
  rw [Nat.xor_self, Nat.xor_zero] at h
  revert h
  cases epsNeg n i k <;> cases epsNeg n k i <;> cases conjNeg k <;> decide

/-! ## 5. Sufficiency -/

theorem crossOK_lift {n i j k : Nat} (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) :
    crossOK (n + 1) i j k ↔ crossOK n i j k := by
  have hm : k ^^^ (i ^^^ j) < 2 ^ n := Nat.xor_lt_two_pow hk (Nat.xor_lt_two_pow hi hj)
  unfold crossOK
  rw [eps_ll hi hk, eps_ll hm hj, eps_ll hm hi, eps_ll hj hk]

/-- An index different from `0` and from `a`, of size at most `2`. -/
def otherIdx (a : Nat) : Nat := if a = 1 then 2 else 1

theorem otherIdx_ne_zero (a : Nat) : otherIdx a ≠ 0 := by
  unfold otherIdx; split <;> omega

theorem otherIdx_ne (a : Nat) : otherIdx a ≠ a := by
  unfold otherIdx; split <;> omega

theorem otherIdx_lt {n : Nat} (hn : 2 ≤ n) (a : Nat) : otherIdx a < 2 ^ n := by
  have : 2 ^ 2 ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  unfold otherIdx; split <;> omega

theorem crossOK_hh {n i' j' : Nat} (hi : i' < 2 ^ n) (hj : j' < 2 ^ n) (hi0 : i' ≠ 0)
    (hj0 : j' ≠ 0) (hij : i' ≠ j') :
    crossOK (n + 1) (2 ^ n + i') (2 ^ n + j') (2 ^ n + 0) := by
  unfold crossOK
  rw [xor_high_high hi hj, xor_high_low (Nat.two_pow_pos n) (Nat.xor_lt_two_pow hi hj),
    Nat.zero_xor, eps_hh, eps_hh, eps_hh, eps_hh, conjNeg_high, conjNeg_high]
  have e1 : epsNeg n j' (i' ^^^ j') = !epsNeg n j' i' := by
    rw [Nat.xor_comm]; exact eps_left_xor hj hi hj0
  rw [e1, eps_left_xor hi hj hi0, epsNeg_zero_left, epsNeg_zero_left, conjNeg_zero,
    conjNeg_of_ne hi0, conjNeg_of_ne hj0, epsNeg_anticomm n j' i' hj hi (Ne.symm hij) hj0 hi0]
  cases epsNeg n i' j' <;> decide

theorem xor_xor_cancel_left' (a b : Nat) : a ^^^ (b ^^^ a) = b := by
  rw [Nat.xor_comm b a, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]

theorem crossOK_h0 {n j' k : Nat} (hj : j' < 2 ^ n) (hk : k < 2 ^ n) (hj0 : j' ≠ 0)
    (hk0 : k ≠ 0) (hkj : k ≠ j') :
    crossOK (n + 1) (2 ^ n + 0) (2 ^ n + j') k := by
  have hm : k ^^^ j' < 2 ^ n := Nat.xor_lt_two_pow hk hj
  unfold crossOK
  rw [xor_high_high (Nat.two_pow_pos n) hj, Nat.zero_xor, eps_hl _ hk, eps_lh _ hm,
    eps_lh _ hm, eps_hl _ hk]
  have e : epsNeg n j' (k ^^^ j') = !epsNeg n j' k := by
    rw [Nat.xor_comm]; exact eps_left_xor hj hk hj0
  have hx : k ^^^ j' ≠ 0 := fun h => hkj (Nat.eq_of_xor_eq_zero h)
  rw [e, epsNeg_zero_left, epsNeg_zero_left, conjNeg_of_ne hk0, conjNeg_of_ne hx]
  cases epsNeg n j' k <;> decide

theorem crossOK_0h {n i' k : Nat} (hi : i' < 2 ^ n) (hk : k < 2 ^ n) (hi0 : i' ≠ 0)
    (hk0 : k ≠ 0) (hki : k ≠ i') :
    crossOK (n + 1) (2 ^ n + i') (2 ^ n + 0) k := by
  have hm : k ^^^ i' < 2 ^ n := Nat.xor_lt_two_pow hk hi
  unfold crossOK
  rw [xor_high_high hi (Nat.two_pow_pos n), Nat.xor_zero, eps_hl _ hk, eps_lh _ hm,
    eps_lh _ hm, eps_hl _ hk]
  have e : epsNeg n i' (k ^^^ i') = !epsNeg n i' k := by
    rw [Nat.xor_comm]; exact eps_left_xor hi hk hi0
  have hx : k ^^^ i' ≠ 0 := fun h => hki (Nat.eq_of_xor_eq_zero h)
  rw [e, epsNeg_zero_left, epsNeg_zero_left, conjNeg_of_ne hk0, conjNeg_of_ne hx]
  cases epsNeg n i' k <;> decide

theorem crossOK_lh {n i j' : Nat} (hi : i < 2 ^ n) (hj : j' < 2 ^ n) (hi0 : i ≠ 0)
    (hj0 : j' ≠ 0) (hij : i ≠ j') :
    crossOK (n + 1) i (2 ^ n + j') j' := by
  unfold crossOK
  rw [xor_low_high hi hj, xor_low_high hj (Nat.xor_lt_two_pow hi hj),
    xor_xor_cancel_left' j' i, eps_ll hi hj, eps_hh, eps_hl _ hi, eps_hl _ hj, conjNeg_high]
  rw [epsNeg_self n i hi, epsNeg_self n j' hj, conjNeg_of_ne hi0, conjNeg_of_ne hj0,
    epsNeg_anticomm n j' i hj hi (Ne.symm hij) hj0 hi0]
  cases epsNeg n i j' <;> decide

theorem crossOK_l0 {n i k : Nat} (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hi0 : i ≠ 0)
    (hk0 : k ≠ 0) (hki : k ≠ i) :
    crossOK (n + 1) i (2 ^ n + 0) k := by
  have hm : k ^^^ i < 2 ^ n := Nat.xor_lt_two_pow hk hi
  unfold crossOK
  rw [xor_low_high hi (Nat.two_pow_pos n), Nat.xor_zero, xor_low_high hk hi,
    eps_ll hi hk, eps_hh, eps_hl _ hi, eps_hl _ hk, conjNeg_high]
  rw [eps_right_xor hk hi hi0, epsNeg_zero_left, epsNeg_zero_left, conjNeg_zero,
    conjNeg_of_ne hi0, conjNeg_of_ne hk0, epsNeg_anticomm n k i hk hi hki hk0 hi0]
  cases epsNeg n i k <;> decide

theorem crossOK_ll {n i k : Nat} (hi : i < 2 ^ n) (hk : k < 2 ^ n) (hi0 : i ≠ 0)
    (hk0 : k ≠ 0) (hki : k ≠ i) :
    crossOK (n + 1) i (2 ^ n + i) k := by
  unfold crossOK
  rw [xor_low_high hi hi, Nat.xor_self, xor_low_high hk (Nat.two_pow_pos n), Nat.xor_zero,
    eps_ll hi hk, eps_hh, eps_hl _ hi, eps_hl _ hk, conjNeg_high]
  rw [conjNeg_of_ne hi0, conjNeg_of_ne hk0, epsNeg_anticomm n k i hk hi hki hk0 hi0]
  cases epsNeg n i k <;> decide

theorem crossOK_hl {n i' j : Nat} (hi : i' < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i' ≠ 0)
    (hj0 : j ≠ 0) (hij : i' ≠ j) :
    crossOK (n + 1) (2 ^ n + i') j i' := by
  unfold crossOK
  rw [xor_high_low hi hj, xor_low_high hi (Nat.xor_lt_two_pow hi hj), ← Nat.xor_assoc,
    Nat.xor_self, Nat.zero_xor, eps_hl _ hi, eps_hl _ hj, eps_hh, eps_ll hj hi, conjNeg_high]
  rw [epsNeg_self n i' hi, epsNeg_self n j hj, conjNeg_of_ne hi0, conjNeg_of_ne hj0,
    epsNeg_anticomm n j i' hj hi (Ne.symm hij) hj0 hi0]
  cases epsNeg n i' j <;> decide

theorem crossOK_0l {n j k : Nat} (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hj0 : j ≠ 0)
    (hk0 : k ≠ 0) (hkj : k ≠ j) :
    crossOK (n + 1) (2 ^ n + 0) j k := by
  unfold crossOK
  rw [xor_high_low (Nat.two_pow_pos n) hj, Nat.zero_xor, xor_low_high hk hj,
    eps_hl _ hk, eps_hl _ hj, eps_hh, eps_ll hj hk, conjNeg_high]
  rw [eps_right_xor hk hj hj0, epsNeg_zero_left, epsNeg_zero_left, conjNeg_zero,
    conjNeg_of_ne hj0, conjNeg_of_ne hk0, epsNeg_anticomm n k j hk hj hkj hk0 hj0]
  cases epsNeg n j k <;> decide

theorem crossOK_jl {n j k : Nat} (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hj0 : j ≠ 0)
    (hk0 : k ≠ 0) (hkj : k ≠ j) :
    crossOK (n + 1) (2 ^ n + j) j k := by
  unfold crossOK
  rw [xor_high_low hj hj, Nat.xor_self, xor_low_high hk (Nat.two_pow_pos n), Nat.xor_zero,
    eps_hl _ hk, eps_hl _ hj, eps_hh, eps_ll hj hk, conjNeg_high]
  rw [conjNeg_of_ne hj0, conjNeg_of_ne hk0, epsNeg_anticomm n k j hk hj hkj hk0 hj0]
  cases epsNeg n j k <;> decide

/-- The sedenion base case, checked by evaluation. -/
theorem crossOK_base : ∀ i < 8, ∀ j < 8, (i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j) →
    ∃ k < 8, crossOK 3 i j k := by
  decide

theorem exists_crossOK : ∀ n, 3 ≤ n → ∀ i j, i < 2 ^ n → j < 2 ^ n → i ≠ 0 → j ≠ 0 → i ≠ j →
    ∃ k, k < 2 ^ n ∧ crossOK n i j k := by
  intro n hn
  induction n, hn using Nat.le_induction with
  | base =>
    intro i j hi hj hi0 hj0 hij
    obtain ⟨k, hk, hok⟩ := crossOK_base i (by simpa using hi) j (by simpa using hj) ⟨hi0, hj0, hij⟩
    exact ⟨k, by simpa using hk, hok⟩
  | succ n hn ih =>
    intro i j hi hj hi0 hj0 hij
    have h2 : 2 ≤ n := by omega
    have hup : ∀ x, x < 2 ^ n → x < 2 ^ (n + 1) := fun x hx => by
      have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
      omega
    have hup0 : 2 ^ n + 0 < 2 ^ (n + 1) := by
      have : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
      have := Nat.two_pow_pos n
      omega
    have ho := otherIdx_lt h2
    rcases split_idx hi with hil | ⟨i', hi', rfl⟩ <;>
      rcases split_idx hj with hjl | ⟨j', hj', rfl⟩
    · obtain ⟨k, hk, hok⟩ := ih i j hil hjl hi0 hj0 hij
      exact ⟨k, hup k hk, (crossOK_lift hil hjl hk).2 hok⟩
    · by_cases h0 : j' = 0
      · subst h0
        exact ⟨otherIdx i, hup _ (ho i),
          crossOK_l0 hil (ho i) hi0 (otherIdx_ne_zero i) (otherIdx_ne i)⟩
      · by_cases hji : j' = i
        · subst hji
          exact ⟨otherIdx j', hup _ (ho j'),
            crossOK_ll hil (ho j') hi0 (otherIdx_ne_zero j') (otherIdx_ne j')⟩
        · exact ⟨j', hup _ hj', crossOK_lh hil hj' hi0 h0 (Ne.symm hji)⟩
    · by_cases h0 : i' = 0
      · subst h0
        exact ⟨otherIdx j, hup _ (ho j),
          crossOK_0l hjl (ho j) hj0 (otherIdx_ne_zero j) (otherIdx_ne j)⟩
      · by_cases hij' : i' = j
        · subst hij'
          exact ⟨otherIdx i', hup _ (ho i'),
            crossOK_jl hjl (ho i') hj0 (otherIdx_ne_zero i') (otherIdx_ne i')⟩
        · exact ⟨i', hup _ hi', crossOK_hl hi' hjl h0 hj0 hij'⟩
    · by_cases h0 : i' = 0
      · subst h0
        have hj0' : j' ≠ 0 := by rintro rfl; exact hij rfl
        exact ⟨otherIdx j', hup _ (ho j'),
          crossOK_h0 hj' (ho j') hj0' (otherIdx_ne_zero j') (otherIdx_ne j')⟩
      · by_cases hj0' : j' = 0
        · subst hj0'
          exact ⟨otherIdx i', hup _ (ho i'),
            crossOK_0h hi' (ho i') h0 (otherIdx_ne_zero i') (otherIdx_ne i')⟩
        · have hne : i' ≠ j' := by rintro rfl; exact hij rfl
          exact ⟨2 ^ n + 0, hup0, crossOK_hh hi' hj' h0 hj0' hne⟩

end CrossHalfCriterion
end Sovereign

namespace Sovereign
namespace CrossHalfCriterion

/-! ## 6. The universal zero-divisor criterion in the algebra

The resulting criterion (in `Tower (n+1)`, `n ≥ 3`, the cross-half vector `± eᵢ ± e_{D/2+j}`
annihilates a non-zero cross-half vector iff `i ≠ 0`, `j ≠ 0`, `i ≠ j`) is stated once, as
`Sovereign.crossVec_zero_divisor_iff` in `TowerAssociator.lean`; the cross-half partner
construction above (`hasCrossPartner_iff`, `crossOK_valid`, `exists_crossOK`) gives a second,
independent route to it. -/

end CrossHalfCriterion
end Sovereign
