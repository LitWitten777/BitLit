/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# The 32-dimensional level: trigintaduonion cross-half stratification

The same analysis one level up the Cayley–Dickson tower, for
`CDTrig = CD CDSedenion` (dimension 32).  The cross-half vectors are
`s • eᵢ + t • e₁₆₊ⱼ` with `i, j < 16`, `s, t ∈ {1, -1}`; there are `32 * 32 = 1024` of them.

Proved below by exact evaluation:

* `zd32_iff_index` — such a vector annihilates a cross-half partner iff `i ≠ 0`, `j ≠ 0`
  and `i ≠ j`, exactly as in dimension 16;
* `zd32_card`, `nonZd32_card` — there are `840 = (32-2)(32-4)` zero divisors and
  `184 = 6·32-8` non-zero-divisors, matching the monograph's universal formulas;
* `xorCharge32_conserved`, `sector32_card` — annihilation conserves the XOR charge
  `χ = i ^^^ j`, and the 15 non-zero charges each carry `56 = 2(32-4)` zero divisors,
  matching `|PG(3, 2)| = 15`;
* `sector32_regular_part` — the eight sectors `χ ≤ 8` (the Fano hyperplane `χ ≤ 7` together
  with the doubling pole `χ = 8`) are 24-regular with 672 edges each;
* `sector32_biregular_part` — the seven sectors `χ ≥ 9` (the affine complement) have
  degrees in `{8, 24}` and 288 edges each;
* `edges32_total` — `8 * 672 + 7 * 288 = 7392` undirected edges in total.

Caveat: unlike in dimension 16, the 184 non-zero-divisors are here only shown to
annihilate no *cross-half* vector; the corresponding statement for the whole 32-dimensional
algebra is not formalised.
-/

import Sovereign.Graph.AnnihilationGraphDefs

namespace Sovereign

/-- The trigintaduonions: one more Cayley–Dickson doubling of the sedenions. -/
abbrev CDTrig := CD CDSedenion

/-- Basis vectors `e₀, …, e₃₁` of the trigintaduonions. -/
def e32 (i : Nat) : CDTrig := if i < 16 then ⟨e i, 0⟩ else ⟨0, e (i - 16)⟩

/-- Integer scaling of a trigintaduonion. -/
def smulTrig (n : Int) (x : CDTrig) : CDTrig := ⟨smulSed n x.re, smulSed n x.im⟩

/-- The cross-half vector `s • eᵢ + t • e₁₆₊ⱼ`. -/
def crossHalfVec32 (i j : Nat) (s t : Int) : CDTrig :=
  smulTrig s (e32 i) + smulTrig t (e32 (16 + j))

/-- Labels `(i, j, s, t)` of cross-half vectors, `i, j < 16`. -/
abbrev Label32 := Nat × Nat × Int × Int

/-- All 1024 cross-half labels. -/
def labels32 : List Label32 :=
  (List.range 16).flatMap fun i =>
    (List.range 16).flatMap fun j =>
      [(1 : Int), -1].flatMap fun s =>
        [(1 : Int), -1].map fun t => (i, j, s, t)

/-- The vector attached to a label. -/
def vec32 (p : Label32) : CDTrig := crossHalfVec32 p.1 p.2.1 p.2.2.1 p.2.2.2

/-- Adjacency: `p` annihilates `q`. -/
def adj32 (p q : Label32) : Bool := vec32 p * vec32 q == 0

/-- The labels satisfying the index criterion. -/
def zd32 : List Label32 :=
  labels32.filter fun p => decide (p.1 ≠ 0 ∧ p.2.1 ≠ 0 ∧ p.1 ≠ p.2.1)

/-- The zero divisors of XOR charge `c`. -/
def sector32 (c : Nat) : List Label32 := zd32.filter fun p => p.1 ^^^ p.2.1 == c

/-- There are `32 * 32 = 1024` cross-half vectors. -/
theorem labels32_card : labels32.length = 1024 := by decide +kernel

/-- **Index criterion in dimension 32.** -/
theorem zd32_iff_index :
    ∀ p ∈ labels32,
      (labels32.any fun q => adj32 p q) = decide (p.1 ≠ 0 ∧ p.2.1 ≠ 0 ∧ p.1 ≠ p.2.1) := by
  native_decide

/-- `840 = (32 - 2)(32 - 4)` zero divisors. -/
theorem zd32_card : zd32.length = 840 := by
  decide +kernel

/-- `184 = 6 · 32 - 8` non-zero-divisors (within the cross-half family). -/
theorem nonZd32_card :
    (labels32.filter fun p => !(labels32.any fun q => adj32 p q)).length = 184 := by
  native_decide

/-- Annihilation conserves the XOR charge. -/
theorem xorCharge32_conserved :
    ∀ p ∈ zd32, ∀ q ∈ zd32, adj32 p q = true → p.1 ^^^ p.2.1 = q.1 ^^^ q.2.1 := by
  native_decide

/-- The 15 non-zero charges (`|PG(3, 2)| = 15`) carry 56 zero divisors each; charge 0 is
empty. -/
theorem sector32_card :
    (sector32 0).length = 0 ∧ ∀ c ∈ List.range 15, (sector32 (c + 1)).length = 56 := by
  decide +kernel

/-- The eight sectors `χ = 1, …, 8` are 24-regular with 672 edges. -/
theorem sector32_regular_part :
    ∀ c ∈ List.range 8,
      (∀ p ∈ sector32 (c + 1), (sector32 (c + 1)).countP (adj32 p) = 24) ∧
      ((sector32 (c + 1)).map fun p => (sector32 (c + 1)).countP (adj32 p)).sum / 2 = 672 := by
  native_decide

/-- The seven sectors `χ = 9, …, 15` have degrees `8` or `24` (both occur) and 288 edges. -/
theorem sector32_biregular_part :
    ∀ c ∈ List.range 7,
      (∀ p ∈ sector32 (c + 9),
        (sector32 (c + 9)).countP (adj32 p) = 8 ∨ (sector32 (c + 9)).countP (adj32 p) = 24) ∧
      (∃ p ∈ sector32 (c + 9), (sector32 (c + 9)).countP (adj32 p) = 8) ∧
      (∃ p ∈ sector32 (c + 9), (sector32 (c + 9)).countP (adj32 p) = 24) ∧
      ((sector32 (c + 9)).map fun p => (sector32 (c + 9)).countP (adj32 p)).sum / 2 = 288 := by
  native_decide

/-- The 32-dimensional annihilation graph has 7392 undirected edges. -/
theorem edges32_total :
    ((zd32.map fun p => zd32.countP (adj32 p)).sum) / 2 = 7392 ∧ 8 * 672 + 7 * 288 = 7392 := by
  native_decide

end Sovereign
