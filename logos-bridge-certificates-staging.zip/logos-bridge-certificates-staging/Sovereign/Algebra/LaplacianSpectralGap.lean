/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# The Laplacian spectral gap `λ₂` of a finite simple graph

For a finite simple graph `G` on `n` vertices, the Laplacian `L = D - A` is real symmetric and
positive semidefinite, so its eigenvalues can be listed in increasing order
`0 = λ₁ ≤ λ₂ ≤ ⋯ ≤ λₙ`.  The second one, `λ₂`, is the *spectral gap* (algebraic connectivity,
Fiedler value).

* `SimpleGraph.lapEigenvalue G i` : the `i`-th Laplacian eigenvalue, in increasing order;
* `SimpleGraph.spectralGap G` : `λ₂` (defined as `0` when `n < 2`);
* `SimpleGraph.card_zero_lapEigenvalue` : the multiplicity of the eigenvalue `0` is the number
  of connected components;
* `SimpleGraph.spectralGap_pos_iff` : for `n ≥ 2`, `λ₂ > 0` iff `G` is connected;
* `SimpleGraph.spectralGap_eq_zero_of_two_le_components` : if `G` has at least two connected
  components, then `λ₂ = 0`.
-/

import Mathlib

namespace SimpleGraph

variable {V : Type*} [Fintype V] [DecidableEq V] (G : SimpleGraph V) [DecidableRel G.Adj]

theorem isHermitian_lapMatrix_real : (G.lapMatrix ℝ).IsHermitian :=
  (G.posSemidef_lapMatrix ℝ).isHermitian

/-- The Laplacian eigenvalues of `G`, listed in **increasing** order:
`lapEigenvalue G 0 ≤ lapEigenvalue G 1 ≤ ⋯`. -/
noncomputable def lapEigenvalue (i : Fin (Fintype.card V)) : ℝ :=
  (G.isHermitian_lapMatrix_real).eigenvalues₀ i.rev

/-- The **spectral gap** (algebraic connectivity) `λ₂` of `G`: the second smallest Laplacian
eigenvalue (by convention `0` if `G` has fewer than two vertices). -/
noncomputable def spectralGap : ℝ :=
  if h : 2 ≤ Fintype.card V then G.lapEigenvalue ⟨1, h⟩ else 0

theorem lapEigenvalue_monotone : Monotone G.lapEigenvalue := fun _ _ hij =>
  (G.isHermitian_lapMatrix_real).eigenvalues₀_antitone (Fin.rev_le_rev.2 hij)

theorem lapEigenvalue_nonneg (i : Fin (Fintype.card V)) : 0 ≤ G.lapEigenvalue i := by
  have h := (G.posSemidef_lapMatrix ℝ).eigenvalues_nonneg
    ((Fintype.equivOfCardEq (Fintype.card_fin _)) i.rev)
  simpa [Matrix.IsHermitian.eigenvalues, lapEigenvalue] using h

/-- The number of zero Laplacian eigenvalues (with multiplicity) equals the number of
connected components. -/
theorem card_zero_lapEigenvalue :
    Fintype.card {i // G.lapEigenvalue i = 0} = Nat.card G.ConnectedComponent := by
  have hH := G.isHermitian_lapMatrix_real
  -- rank = number of nonzero eigenvalues
  have hrank := hH.rank_eq_card_non_zero_eigs
  -- rank + nullity = n
  have hrn : (G.lapMatrix ℝ).rank +
      Module.finrank ℝ (LinearMap.ker (Matrix.toLin' (G.lapMatrix ℝ))) = Fintype.card V := by
    have := LinearMap.finrank_range_add_finrank_ker (Matrix.toLin' (G.lapMatrix ℝ))
    rw [Module.finrank_fintype_fun_eq_card] at this
    rw [Matrix.rank]
    exact this
  rw [← G.card_connectedComponent_eq_finrank_ker_toLin'_lapMatrix] at hrn
  -- count the nonzero eigenvalues via `lapEigenvalue`
  let e : Fin (Fintype.card V) ≃ V :=
    Fin.revPerm.trans (Fintype.equivOfCardEq (Fintype.card_fin _))
  have hev : ∀ i, hH.eigenvalues (e i) = G.lapEigenvalue i := by
    intro i
    simp [e, Matrix.IsHermitian.eigenvalues, lapEigenvalue]
  have hnz : Fintype.card {v // hH.eigenvalues v ≠ 0} =
      Fintype.card {i // G.lapEigenvalue i ≠ 0} := by
    refine Fintype.card_congr (e.symm.subtypeEquiv ?_)
    intro v
    rw [← hev, Equiv.apply_symm_apply]
  have hsum := Finset.card_filter_add_card_filter_not (s := Finset.univ)
    (fun i : Fin (Fintype.card V) => G.lapEigenvalue i = 0)
  simp only [Finset.card_univ, Fintype.card_fin] at hsum
  have h1 : Fintype.card {i // G.lapEigenvalue i = 0} =
      (Finset.univ.filter (fun i : Fin (Fintype.card V) => G.lapEigenvalue i = 0)).card := by
    rw [Fintype.card_subtype]
  have h2 : Fintype.card {i // G.lapEigenvalue i ≠ 0} =
      (Finset.univ.filter (fun i : Fin (Fintype.card V) => ¬ G.lapEigenvalue i = 0)).card := by
    rw [Fintype.card_subtype]
  have h3 : (G.lapMatrix ℝ).rank = Fintype.card {i // G.lapEigenvalue i ≠ 0} := by
    rw [hrank, ← hnz]
  have e1 : (Finset.univ.filter (fun i : Fin (Fintype.card V) => G.lapEigenvalue i = 0)).card +
      (Finset.univ.filter (fun i : Fin (Fintype.card V) => ¬ G.lapEigenvalue i = 0)).card =
      Fintype.card V := by convert hsum
  rw [h1]
  rw [h3, h2] at hrn
  have key := Nat.add_left_cancel ((add_comm _ _).trans (e1.trans hrn.symm))
  rw [key]
  exact Nat.card_eq_fintype_card.symm

/-- If `λ₂ > 0` then at most one Laplacian eigenvalue vanishes. -/
theorem card_zero_lapEigenvalue_le_one (h : 2 ≤ Fintype.card V)
    (hpos : 0 < G.lapEigenvalue ⟨1, h⟩) : Fintype.card {i // G.lapEigenvalue i = 0} ≤ 1 := by
  rw [Fintype.card_le_one_iff]
  rintro ⟨i, hi⟩ ⟨j, hj⟩
  have key : ∀ k : Fin (Fintype.card V), G.lapEigenvalue k = 0 → k = ⟨0, by omega⟩ := by
    intro k hk
    by_contra hne
    have : (⟨1, h⟩ : Fin (Fintype.card V)) ≤ k := by
      rw [Fin.le_def]
      have : k.val ≠ 0 := fun h0 => hne (Fin.ext h0)
      simp only
      omega
    have := G.lapEigenvalue_monotone this
    linarith
  exact Subtype.ext ((key i hi).trans (key j hj).symm)

/-- If `λ₂ = 0` then at least two Laplacian eigenvalues vanish. -/
theorem two_le_card_zero_lapEigenvalue (h : 2 ≤ Fintype.card V)
    (h0 : G.lapEigenvalue ⟨1, h⟩ = 0) : 2 ≤ Fintype.card {i // G.lapEigenvalue i = 0} := by
  have hz : G.lapEigenvalue ⟨0, by omega⟩ = 0 := by
    have := G.lapEigenvalue_monotone (show (⟨0, by omega⟩ : Fin (Fintype.card V)) ≤ ⟨1, h⟩ by
      rw [Fin.le_def]; simp)
    have := G.lapEigenvalue_nonneg ⟨0, by omega⟩
    linarith
  have : 1 < Fintype.card {i // G.lapEigenvalue i = 0} :=
    Fintype.one_lt_card_iff.2 ⟨⟨_, hz⟩, ⟨_, h0⟩, fun he => by
      have := congrArg (fun x => x.1.val) he
      simp at this⟩
  omega

theorem spectralGap_eq (h : 2 ≤ Fintype.card V) : G.spectralGap = G.lapEigenvalue ⟨1, h⟩ :=
  dif_pos h

theorem spectralGap_nonneg : 0 ≤ G.spectralGap := by
  unfold spectralGap
  split_ifs
  · exact G.lapEigenvalue_nonneg _
  · exact le_rfl

/-- The smallest Laplacian eigenvalue is `0` (when `G` has a vertex). -/
theorem lapEigenvalue_zero_eq_zero (h : 0 < Fintype.card V) : G.lapEigenvalue ⟨0, h⟩ = 0 := by
  have : Nonempty V := Fintype.card_pos_iff.1 h
  have hpos : 0 < Fintype.card {i // G.lapEigenvalue i = 0} := by
    rw [G.card_zero_lapEigenvalue]
    exact Nat.card_pos
  obtain ⟨⟨i, hi⟩⟩ := Fintype.card_pos_iff.1 hpos
  have := G.lapEigenvalue_monotone (show (⟨0, h⟩ : Fin (Fintype.card V)) ≤ i from
    Fin.le_def.2 (Nat.zero_le _))
  have := G.lapEigenvalue_nonneg ⟨0, h⟩
  linarith

/-- **Spectral gap criterion.**  For a graph with at least two vertices, `λ₂ > 0` iff the graph is
connected. -/
theorem spectralGap_pos_iff (h : 2 ≤ Fintype.card V) : 0 < G.spectralGap ↔ G.Connected := by
  have : Nonempty V := Fintype.card_pos_iff.1 (by omega)
  rw [G.spectralGap_eq h]
  constructor
  · intro hpos
    have h1 := G.card_zero_lapEigenvalue_le_one h hpos
    rw [G.card_zero_lapEigenvalue] at h1
    have : Subsingleton G.ConnectedComponent :=
      (Finite.card_le_one_iff_subsingleton).1 h1
    refine ⟨fun u v => ?_⟩
    exact SimpleGraph.ConnectedComponent.exact (Subsingleton.elim _ _)
  · intro hc
    have : Subsingleton G.ConnectedComponent := ⟨fun c d => by
      induction c using SimpleGraph.ConnectedComponent.ind with
      | _ u =>
      induction d using SimpleGraph.ConnectedComponent.ind with
      | _ v => exact SimpleGraph.ConnectedComponent.sound (hc.preconnected u v)⟩
    have hcard : Nat.card G.ConnectedComponent ≤ 1 := Finite.card_le_one_iff_subsingleton.2 this
    rcases (G.lapEigenvalue_nonneg ⟨1, h⟩).lt_or_eq with hlt | heq
    · exact hlt
    · have := G.two_le_card_zero_lapEigenvalue h heq.symm
      rw [G.card_zero_lapEigenvalue] at this
      omega

/-- A graph with at least two connected components has spectral gap `λ₂ = 0`. -/
theorem spectralGap_eq_zero_of_one_lt_card_components
    (h : 1 < Nat.card G.ConnectedComponent) : G.spectralGap = 0 := by
  unfold spectralGap
  split_ifs with hV
  · rcases (G.lapEigenvalue_nonneg ⟨1, hV⟩).lt_or_eq with hlt | heq
    · have := G.card_zero_lapEigenvalue_le_one hV hlt
      rw [G.card_zero_lapEigenvalue] at this
      omega
    · exact heq.symm
  · rfl

/-- A graph with at least two connected components is not connected, so its spectral gap
vanishes: `¬ 0 < λ₂`. -/
theorem not_spectralGap_pos_of_one_lt_card_components
    (h : 1 < Nat.card G.ConnectedComponent) : ¬ 0 < G.spectralGap := by
  rw [G.spectralGap_eq_zero_of_one_lt_card_components h]
  exact lt_irrefl 0

end SimpleGraph
