/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# The universal Cayley–Dickson cross-half zero-divisor theorem

For the Cayley–Dickson algebra of dimension `D = 2ⁿ ≥ 16` (`Tower n`, built over `ℤ` by
iterated doubling; its cross-half vectors are `crossVec (n-1)`):

* `universal_cd_zero_divisor_theorem` : there are exactly `(D - 2)(D - 4)` cross-half zero
  divisors `± eᵢ ± e_{D/2+j}`; they form exactly `|PG(n-2, 𝔽₂)| = 2ⁿ⁻¹ - 1` connected components
  of the annihilation graph, each with exactly `2(D - 4)` elements;
* `card_preimage` : the charge map to `PG(n-2, 𝔽₂)` is a fibration with all fibres of size
  `2(D - 4)`: any set `S` of points has preimage of size `|S| · 2(D - 4)`;
* `trigintaduonion_zero_divisor_theorem` : for `D = 32` the 840 zero divisors form 15
  components of 56 indexed by `PG(3, 2)`; over each of the 15 hyperplanes `PG(2, 2) ⊂ PG(3, 2)`
  lie exactly `392 = 7 · 56` of them (and `448 = 8 · 56` off it), and each zero divisor lies over
  exactly 7 of the 15 hyperplanes.
-/

import Sovereign.Algebra.CrossHalfConnectivity

open scoped LinearAlgebra.Projectivization

namespace Sovereign
namespace CrossHalfComponents

open CrossHalfCriterion CrossHalf

/-! ## 1. Components -/

open Classical in
/-- The zero divisors lying in the connected component of `x`. -/
noncomputable def componentOf (N : Nat) (x : Label) : Finset Label :=
  (crossZD N).filter (fun y => (annihGraph N).Reachable x y)

open Classical in
/-- The set of connected components of the annihilation graph that contain a zero divisor. -/
noncomputable def components (N : Nat) : Finset (annihGraph N).ConnectedComponent :=
  (crossZD N).image (annihGraph N).connectedComponentMk

theorem charge_lab (c i : Nat) (s t : Bool) : charge (lab c i s t).1 = c := by
  simp only [lab, charge]
  rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]

theorem lab_mem {N c : Nat} (hN : 3 ≤ N) (hc0 : c ≠ 0) (hc : c < 2 ^ N) (s t : Bool) :
    lab c (otherIdx c) s t ∈ crossZD N := by
  have ho := otherIdx_lt (n := N) (by omega) c
  rw [mem_crossZD_iff hN]
  exact ⟨ho, Nat.xor_lt_two_pow ho hc, otherIdx_ne_zero c,
    xor_ne_zero_of_ne (otherIdx_ne c), ne_xor_self hc0⟩

/-- The zero divisors in the component of a zero divisor `x` form exactly its charge sector. -/
theorem component_eq_sector {N : Nat} (hN : 3 ≤ N) {x : Label} (hx : x ∈ crossZD N) :
    componentOf N x = crossSector N (charge x.1) := by
  ext y
  simp only [componentOf, Finset.mem_filter, crossSector]
  constructor
  · rintro ⟨_, h⟩; exact (reachable_iff hN hx).1 h
  · rintro ⟨hy, h⟩; exact ⟨hy, (reachable_iff hN hx).2 ⟨hy, h⟩⟩

/-- **Component size.** Every component has `2(D - 4)` elements. -/
theorem component_card {N : Nat} (hN : 3 ≤ N) {x : Label} (hx : x ∈ crossZD N) :
    (componentOf N x).card = 2 * (2 ^ (N + 1) - 4) := by
  have hc := charge_mem_Ico hN hx
  rw [Finset.mem_Ico] at hc
  rw [component_eq_sector hN hx, crossSector_card hN _ (by omega) hc.2]

/-- **Component count.** The cross-half zero divisors fall into exactly `D/2 - 1`
connected components of the annihilation graph. -/
theorem component_count {N : Nat} (hN : 3 ≤ N) : (components N).card = 2 ^ N - 1 := by
  classical
  rw [← Nat.card_Ico 1 (2 ^ N), components]
  symm
  refine Finset.card_bij
    (fun c _ => (annihGraph N).connectedComponentMk (lab c (otherIdx c) false false)) ?_ ?_ ?_
  · intro c hc
    rw [Finset.mem_Ico] at hc
    exact Finset.mem_image_of_mem _ (lab_mem hN (by omega) hc.2 false false)
  · intro c hc d hd h
    rw [Finset.mem_Ico] at hc hd
    have h' := (SimpleGraph.ConnectedComponent.eq).1 h
    have := ((reachable_iff hN (lab_mem hN (by omega) hc.2 false false)).1 h').2
    rw [charge_lab, charge_lab] at this
    exact this.symm
  · intro C hC
    obtain ⟨x, hx, rfl⟩ := Finset.mem_image.1 hC
    have hc := charge_mem_Ico hN hx
    refine ⟨charge x.1, hc, ?_⟩
    rw [Finset.mem_Ico] at hc
    refine (SimpleGraph.ConnectedComponent.eq).2 ?_
    refine (reachable_iff hN (lab_mem hN (by omega) hc.2 false false)).2 ⟨hx, ?_⟩
    rw [charge_lab]

/-- The number of points of the projective space `PG(N-1, 𝔽₂) = ℙ(𝔽₂ᴺ)`. -/
theorem card_projective (N : Nat) : Nat.card (ℙ (ZMod 2) (Fin N → ZMod 2)) = 2 ^ N - 1 := by
  rw [Projectivization.card'']
  simp

/-- The components are counted by the points of `PG(N-1, 𝔽₂) = ℙ(𝔽₂ᴺ)`. -/
theorem component_count_eq_projective {N : Nat} (hN : 3 ≤ N) :
    (components N).card = Nat.card (ℙ (ZMod 2) (Fin N → ZMod 2)) := by
  rw [component_count hN, card_projective]

/-! ## 2. The fibration over the projective space -/

/-- **Fibration.** For every set `S` of non-zero charges (points of `PG(N-1, 𝔽₂)`), exactly
`|S| · 2(D - 4)` zero divisors have their charge in `S`. -/
theorem card_preimage {N : Nat} (hN : 3 ≤ N) (S : Finset Nat) (hS : S ⊆ Finset.Ico 1 (2 ^ N)) :
    ((crossZD N).filter (fun x => charge x.1 ∈ S)).card = S.card * (2 * (2 ^ (N + 1) - 4)) := by
  have h : (crossZD N).filter (fun x => charge x.1 ∈ S) = S.biUnion (crossSector N) := by
    ext x
    simp only [Finset.mem_filter, Finset.mem_biUnion, crossSector]
    constructor
    · rintro ⟨hx, hS'⟩; exact ⟨_, hS', hx, rfl⟩
    · rintro ⟨c, hc, hx, rfl⟩; exact ⟨hx, hc⟩
  rw [h, Finset.card_biUnion (fun c _ d _ hcd => crossSector_disjoint N hcd)]
  rw [Finset.sum_congr rfl (g := fun _ => 2 * (2 ^ (N + 1) - 4)), Finset.sum_const, smul_eq_mul]
  intro c hc
  have := Finset.mem_Ico.1 (hS hc)
  exact crossSector_card hN c (by omega) this.2

/-! ## 3. The universal theorem, in the dimension `D = 2ⁿ` -/

/-- **Universal Cayley–Dickson zero-divisor theorem.** Let `D = 2ⁿ ≥ 16` and consider the
cross-half vectors `± eᵢ ± e_{D/2+j}` (`i, j < D/2`) of the Cayley–Dickson algebra of
dimension `D` (`crossVec`, level `n - 1`), with the annihilation graph joining two of them when
their product (in either order) vanishes. Then

1. exactly `(D - 2)(D - 4)` of them are zero divisors;
2. these fall into exactly `|PG(n-2, 𝔽₂)|` connected components;
3. `|PG(n-2, 𝔽₂)| = 2ⁿ⁻¹ - 1`;
4. every component has exactly `2(D - 4)` elements. -/
theorem universal_cd_zero_divisor_theorem (n : Nat) (hn : 4 ≤ n) :
    (crossZD (n - 1)).card = (2 ^ n - 2) * (2 ^ n - 4) ∧
    (components (n - 1)).card = Nat.card (ℙ (ZMod 2) (Fin (n - 1) → ZMod 2)) ∧
    Nat.card (ℙ (ZMod 2) (Fin (n - 1) → ZMod 2)) = 2 ^ (n - 1) - 1 ∧
    (∀ x ∈ crossZD (n - 1), (componentOf (n - 1) x).card = 2 * (2 ^ n - 4)) := by
  obtain ⟨N, rfl⟩ : ∃ N, n = N + 1 := ⟨n - 1, by omega⟩
  have hN : 3 ≤ N := by omega
  simp only [Nat.add_sub_cancel]
  exact ⟨crossZD_card hN, component_count_eq_projective hN, card_projective N,
    fun x hx => component_card hN hx⟩

/-- The components times their size recovers the total: `(D/2 - 1) · 2(D - 4) = (D-2)(D-4)`. -/
theorem components_mul_size (n : Nat) (hn : 4 ≤ n) :
    (2 ^ (n - 1) - 1) * (2 * (2 ^ n - 4)) = (2 ^ n - 2) * (2 ^ n - 4) := by
  obtain ⟨N, rfl⟩ : ∃ N, n = N + 1 := ⟨n - 1, by omega⟩
  simp only [Nat.add_sub_cancel]
  have h1 : 1 ≤ 2 ^ N := Nat.one_le_two_pow
  have h2 : 2 ^ (N + 1) = 2 * 2 ^ N := by rw [pow_succ]; ring
  rw [h2]
  obtain ⟨m, hm⟩ : ∃ m, 2 ^ N = m + 1 := ⟨2 ^ N - 1, by omega⟩
  rw [hm]
  rcases m with _ | m
  · simp
  · have e1 : 2 * (m + 1 + 1) - 2 = 2 * (m + 1) := by omega
    rw [e1, Nat.add_sub_cancel]
    ring

/-! ## 4. The trigintaduonions `T₃₂` and the hyperplanes of `PG(3, 2)` -/

/-- The `𝔽₂`-bilinear pairing of two charges (dot product of their binary expansions);
`a ≠ 0` defines the hyperplane `{c | hdot a c = 0}` of `PG(N-1, 𝔽₂)`. -/
def hdot (N a c : Nat) : ZMod 2 := ∑ i : Fin N, chargeBits N a i * chargeBits N c i

/-- The hyperplane of `PG(N-1, 𝔽₂)` cut out by the non-zero functional `a`. -/
def hyperplane (N a : Nat) : Finset Nat := (Finset.Ico 1 (2 ^ N)).filter (fun c => hdot N a c = 0)

theorem hyperplane_subset (N a : Nat) : hyperplane N a ⊆ Finset.Ico 1 (2 ^ N) :=
  Finset.filter_subset _ _

set_option maxRecDepth 10000 in
/-- Each of the 15 hyperplanes of `PG(3, 2)` is a Fano plane `PG(2, 2)` with 7 points. -/
theorem hyperplane_card_32 : ∀ a ∈ Finset.Ico 1 16, (hyperplane 4 a).card = 7 := by
  decide

set_option maxRecDepth 10000 in
/-- Distinct non-zero functionals give distinct hyperplanes, so `PG(3, 2)` has exactly 15. -/
theorem hyperplane_injective_32 :
    ∀ a ∈ Finset.Ico 1 16, ∀ b ∈ Finset.Ico 1 16, hyperplane 4 a = hyperplane 4 b → a = b := by
  decide

set_option maxRecDepth 10000 in
/-- Every point of `PG(3, 2)` lies on exactly 7 of the 15 hyperplanes. -/
theorem point_on_hyperplanes_32 :
    ∀ c ∈ Finset.Ico 1 16, ((Finset.Ico 1 16).filter (fun a => c ∈ hyperplane 4 a)).card = 7 := by
  decide

set_option maxRecDepth 8000 in
/-- **Trigintaduonion zero-divisor theorem (`D = 32`).**

1. `T₃₂` has exactly `840 = (32-2)(32-4)` cross-half zero divisors;
2. they form exactly `15 = |PG(3, 2)|` connected components of the annihilation graph,
   each with `56 = 2(32-4)` elements;
3. (**hyperplane fibration**) for each of the 15 hyperplanes `H ≅ PG(2, 2)` of `PG(3, 2)`,
   exactly `392 = 7 · 56` zero divisors have their charge on `H` and `448 = 8 · 56` off `H`;
4. every zero divisor lies over exactly 7 of the 15 hyperplanes. -/
theorem trigintaduonion_zero_divisor_theorem :
    (crossZD 4).card = 840 ∧
    (components 4).card = 15 ∧
    Nat.card (ℙ (ZMod 2) (Fin 4 → ZMod 2)) = 15 ∧
    (∀ x ∈ crossZD 4, (componentOf 4 x).card = 56) ∧
    (∀ a ∈ Finset.Ico 1 16,
      ((crossZD 4).filter (fun x => charge x.1 ∈ hyperplane 4 a)).card = 392 ∧
      ((crossZD 4).filter (fun x => charge x.1 ∉ hyperplane 4 a)).card = 448) ∧
    (∀ x ∈ crossZD 4,
      ((Finset.Ico 1 16).filter (fun a => charge x.1 ∈ hyperplane 4 a)).card = 7) := by
  have hN : 3 ≤ 4 := by norm_num
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · exact (crossZD_card hN).trans (by norm_num)
  · exact (component_count hN).trans (by norm_num)
  · exact (card_projective 4).trans (by norm_num)
  · intro x hx; exact (component_card hN hx).trans (by norm_num)
  · intro a ha
    have h1 := card_preimage hN (hyperplane 4 a) (hyperplane_subset 4 a)
    rw [hyperplane_card_32 a ha] at h1
    have hsplit := Finset.card_filter_add_card_filter_not
      (s := crossZD 4) (fun x => charge x.1 ∈ hyperplane 4 a)
    rw [crossZD_card hN] at hsplit
    norm_num at h1 hsplit
    omega
  · intro x hx
    exact point_on_hyperplanes_32 _ (charge_mem_Ico hN hx)

end CrossHalfComponents
end Sovereign
