/-
Copyright (c) 2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Annihilating-polynomial certificates for integer matrices

This module supplies the generic machinery for proving facts about concrete integer
matrices through **annihilating polynomials**.

* `hornerM B [c₀, c₁, …, c_d] = c₀ I + B (c₁ I + B (⋯)) = ∑ cₖ Bᵏ` is matrix Horner evaluation.
* `mulVec_eq_zero_of_hornerM` — if `∑ cₖ Bᵏ = 0` with `c₀ ≠ 0`, then `B` has trivial kernel.
* `hornerM_mulVec_of_eigen` — on an eigenvector `B y = μ y`, `(∑ cₖ Bᵏ) y = (∑ cₖ μᵏ) y`.
  So every eigenvalue of `B` is a root of an annihilating polynomial.
* `hornerM_map` — Horner evaluation commutes with ring homomorphisms, so a certificate
  checked over `ℤ` transfers to `ℝ`.
* `arrOf`, `ofArr`, `hornerArr`, `certCheck` — an array-based implementation of the same
  evaluation, proved equal to the plain one (`matMemo_eq`, `ofArr_hornerArr`,
  `certCheck_spec`).  Every intermediate matrix is stored as an array, so `native_decide`
  checks of certificates run in polynomial time.
-/

import Mathlib

namespace Sovereign.Graph

open Matrix

/-! ## 1. Horner evaluation of a polynomial at a matrix -/

section Horner

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {R : Type*} [CommRing R]

/-- Horner evaluation `hornerM B [c₀, …, c_d] = ∑ cₖ Bᵏ`. -/
def hornerM (B : Matrix ι ι R) : List R → Matrix ι ι R
  | [] => 0
  | c :: cs => Matrix.diagonal (fun _ => c) + B * hornerM B cs

/-- Scalar Horner evaluation `hornerS μ [c₀, …, c_d] = ∑ cₖ μᵏ`. -/
def hornerS (μ : R) : List R → R
  | [] => 0
  | c :: cs => c + μ * hornerS μ cs

theorem hornerM_commute (B : Matrix ι ι R) (cs : List R) : B * hornerM B cs = hornerM B cs * B := by
  induction cs with
  | nil => simp [hornerM]
  | cons c cs ih =>
    simp only [hornerM, Matrix.mul_add, Matrix.add_mul, ← Matrix.mul_assoc, ih]
    congr 1
    ext i j
    simp [Matrix.mul_apply, Matrix.diagonal, mul_comm]

/-- **Trivial kernel from an annihilating polynomial with non-zero constant term.** -/
theorem mulVec_eq_zero_of_hornerM [IsDomain R] (B : Matrix ι ι R) (c : R) (cs : List R)
    (hc : c ≠ 0) (h : hornerM B (c :: cs) = 0) (v : ι → R) (hv : B *ᵥ v = 0) : v = 0 := by
  have key : hornerM B (c :: cs) *ᵥ v = c • v := by
    rw [hornerM, Matrix.add_mulVec, hornerM_commute, ← Matrix.mulVec_mulVec, hv,
      Matrix.mulVec_zero, add_zero]
    ext i
    simp [Matrix.mulVec, dotProduct, Matrix.diagonal, Finset.sum_ite_eq]
  rw [h, Matrix.zero_mulVec] at key
  ext i
  have := congrFun key i
  simp only [Pi.zero_apply, Pi.smul_apply, smul_eq_mul] at this
  exact (mul_eq_zero.mp this.symm).resolve_left hc

/-- On an eigenvector, a matrix polynomial acts by the scalar polynomial. -/
theorem hornerM_mulVec_of_eigen (B : Matrix ι ι R) (μ : R) (y : ι → R) (hy : B *ᵥ y = μ • y)
    (cs : List R) : hornerM B cs *ᵥ y = hornerS μ cs • y := by
  induction cs with
  | nil => simp [hornerM, hornerS]
  | cons c cs ih =>
    rw [hornerM, Matrix.add_mulVec, ← Matrix.mulVec_mulVec, ih, Matrix.mulVec_smul, hy,
      hornerS, smul_smul, add_smul, mul_comm (hornerS μ cs) μ]
    congr 1
    ext i
    simp [Matrix.mulVec, dotProduct, Matrix.diagonal, Finset.sum_ite_eq]

/-- **Eigenvalues are roots of annihilating polynomials.** -/
theorem hornerS_eq_zero_of_eigen [IsDomain R] (B : Matrix ι ι R) (cs : List R)
    (h : hornerM B cs = 0) (μ : R) (y : ι → R) (hy0 : y ≠ 0) (hy : B *ᵥ y = μ • y) :
    hornerS μ cs = 0 := by
  have key := hornerM_mulVec_of_eigen B μ y hy cs
  rw [h, Matrix.zero_mulVec] at key
  obtain ⟨i, hi⟩ : ∃ i, y i ≠ 0 := by
    by_contra hne
    push_neg at hne
    exact hy0 (funext hne)
  have := congrFun key i
  simp only [Pi.zero_apply, Pi.smul_apply, smul_eq_mul] at this
  exact (mul_eq_zero.mp this.symm).resolve_right hi

/-- Horner evaluation commutes with ring homomorphisms. -/
theorem hornerM_map {S : Type*} [CommRing S] (f : R →+* S) (B : Matrix ι ι R) (cs : List R) :
    (hornerM B cs).map f = hornerM (B.map f) (cs.map f) := by
  induction cs with
  | nil => simp [hornerM]
  | cons c cs ih =>
    simp only [hornerM, List.map_cons]
    rw [← ih, Matrix.map_add f f.map_add, Matrix.map_mul, Matrix.diagonal_map f.map_zero]

end Horner

/-! ## 2. Memoised versions for fast evaluation -/

section Memo

variable {N : Nat} {p : Fin N → Prop} [DecidablePred p]

/-- The padded array of entries of a matrix indexed by a subtype of `Fin N`. -/
def arrOf (M : Matrix {a // p a} {a // p a} ℤ) : Array (Array ℤ) :=
  Array.ofFn fun i : Fin N => Array.ofFn fun j : Fin N =>
    if h : p i ∧ p j then M ⟨i, h.1⟩ ⟨j, h.2⟩ else 0

/-- Read a matrix off a padded array.  (Kept out of line, so that the array is computed once
and shared by all lookups.) -/
@[noinline] def ofArr (arr : Array (Array ℤ)) : Matrix {a // p a} {a // p a} ℤ :=
  fun a b => (arr.getD a.1.1 #[]).getD b.1.1 0

/-- Store the entries of a matrix in an array. -/
def matMemo (M : Matrix {a // p a} {a // p a} ℤ) : Matrix {a // p a} {a // p a} ℤ :=
  ofArr (arrOf M)

theorem matMemo_eq (M : Matrix {a // p a} {a // p a} ℤ) : matMemo M = M := by
  ext a b
  simp [matMemo, ofArr, arrOf, a.2, b.2]

/-- One Horner step `c I + B H`, on padded arrays.  The result is an array, not a function,
so each intermediate matrix is computed exactly once. -/
@[noinline] def hornerStepArr (B : Matrix {a // p a} {a // p a} ℤ) (c : ℤ)
    (H : Array (Array ℤ)) : Array (Array ℤ) :=
  arrOf (Matrix.diagonal (fun _ => c) + B * ofArr H)

/-- Horner evaluation on padded arrays. -/
def hornerArr (B : Matrix {a // p a} {a // p a} ℤ) : List ℤ → Array (Array ℤ)
  | [] => arrOf (p := p) 0
  | c :: cs => hornerStepArr B c (hornerArr B cs)

theorem ofArr_hornerArr (B : Matrix {a // p a} {a // p a} ℤ) (cs : List ℤ) :
    (ofArr (hornerArr B cs) : Matrix {a // p a} {a // p a} ℤ) = hornerM B cs := by
  induction cs with
  | nil => exact matMemo_eq 0
  | cons c cs ih =>
    simp only [hornerArr, hornerStepArr]
    rw [show (ofArr (arrOf (Matrix.diagonal (fun _ => c) + B * ofArr (hornerArr B cs))) :
        Matrix {a // p a} {a // p a} ℤ) = _ from matMemo_eq _, ih, hornerM]

/-- Whether every entry of a padded-array matrix vanishes. -/
def allZeroArr (H : Array (Array ℤ)) : Bool :=
  decide (∀ a b : {a // p a}, (ofArr H : Matrix {a // p a} {a // p a} ℤ) a b = 0)

/-- The Boolean certificate check: the list is non-empty, its constant term is non-zero, and
it annihilates `B`. -/
def certCheck (B : Matrix {a // p a} {a // p a} ℤ) : List ℤ → Bool
  | [] => false
  | c :: cs => decide (c ≠ 0) && allZeroArr (p := p) (hornerArr (p := p) (ofArr (arrOf B)) (c :: cs))

theorem certCheck_spec (B : Matrix {a // p a} {a // p a} ℤ) (cs : List ℤ)
    (h : certCheck B cs = true) :
    ∃ c cs', cs = c :: cs' ∧ c ≠ 0 ∧ hornerM B cs = 0 := by
  cases cs with
  | nil => simp [certCheck] at h
  | cons c cs' =>
    simp only [certCheck, allZeroArr, Bool.and_eq_true, decide_eq_true_eq] at h
    refine ⟨c, cs', rfl, h.1, ?_⟩
    have h2 := h.2
    have hB : (ofArr (arrOf B) : Matrix {a // p a} {a // p a} ℤ) = B := matMemo_eq B
    rw [ofArr_hornerArr, hB] at h2
    ext a b
    exact h2 a b

/-- The Boolean trace check: `trace (∑ cₖ Bᵏ) = t`. -/
def traceCheck (B : Matrix {a // p a} {a // p a} ℤ) (cs : List ℤ) (t : ℤ) : Bool :=
  decide (Matrix.trace (ofArr (hornerArr (p := p) (ofArr (arrOf B)) cs) :
    Matrix {a // p a} {a // p a} ℤ) = t)

theorem traceCheck_spec (B : Matrix {a // p a} {a // p a} ℤ) (cs : List ℤ) (t : ℤ)
    (h : traceCheck B cs t = true) : Matrix.trace (hornerM B cs) = t := by
  simp only [traceCheck, decide_eq_true_eq] at h
  have hB : (ofArr (arrOf B) : Matrix {a // p a} {a // p a} ℤ) = B := matMemo_eq B
  rwa [ofArr_hornerArr, hB] at h

end Memo

end Sovereign.Graph
