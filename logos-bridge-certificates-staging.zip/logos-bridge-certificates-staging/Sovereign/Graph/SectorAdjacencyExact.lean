/-
Copyright (c) 2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Exact row sums and symmetry of the charge-sector adjacency matrices (Track 1, `T1`)

`Sovereign/Graph/SectorAdjacencyMatrix.lean` builds, for every level `n` and every charge `χ`,
the `{0,1}` adjacency matrix `sectorAdj n χ` of the annihilation graph restricted to the
admissible cross-half vectors of charge `i ⊕ j = χ`, and bounds its row sums from above by
the vertex degree.  This module upgrades both statements to exact ones, in every dimension:

* `crossAnnihilates_comm` — the annihilation relation is symmetric on vertices whose first
  index is non-zero: `x y = 0 ↔ y x = 0`.  The proof is algebraic: such vectors are purely
  imaginary (`conj x = -x`) and conjugation is an anti-automorphism of every algebra of the
  tower (`tower_conj_mul`);
* `crossAnnihilates_partner_adm` — every annihilating partner of an admissible vertex is
  itself admissible (its middle index is a non-associating middle, and the four middles
  `0, i, j, i ⊕ j` always associate);
* `crossAdj_isSymm`, `sectorAdj_isSymm` — the adjacency matrices are symmetric;
* `crossAdj_rowSum`, `sectorAdj_rowSum` — **every row sum equals the vertex degree
  `2 · towerDegree n i j`** exactly: no neighbour is lost by restricting to admissible
  vertices or to a charge sector;
* `sectorAdj_eigenvalue_abs_le` — every real eigenvalue of every charge sector satisfies
  `|λ| ≤ Dₐ - 8` (`Dₐ = 2ⁿ⁺¹`, `n ≥ 3`).
-/

import Mathlib
import Sovereign.Graph.SectorAdjacencyMatrix
import Sovereign.Algebra.TowerAlternative

namespace Sovereign.Graph

open Finset Matrix Sovereign

/-! ## 1. Symmetry of the annihilation relation -/

/-- A cross-half vector with non-zero first index is purely imaginary. -/
theorem crossVec_conj (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n)
    (hi0 : i ≠ 0) : conj (crossVec n s i t j) = -crossVec n s i t j := by
  have hpow : 2 ^ (n + 1) = 2 ^ n + 2 ^ n := by rw [pow_succ]; ring
  have hi' : i < 2 ^ (n + 1) := by omega
  have hj' : 2 ^ n + j < 2 ^ (n + 1) := by omega
  have hci : conjNeg i = true := by simp [conjNeg, hi0]
  have hcj : conjNeg (2 ^ n + j) = true := by
    have : 0 < 2 ^ n := by positivity
    simp [conjNeg]
  have hsc : ∀ (b : Bool) (x : Tower (n + 1)), conj (signed b x) = signed b (conj x) := by
    intro b x; cases b <;> simp [signed, tower_conj_neg]
  have hns : ∀ (b : Bool) (x : Tower (n + 1)), signed b (-x) = -signed b x := by
    intro b x; cases b <;> simp [signed]
  rw [crossVec, tower_conj_add, hsc, hsc, basis_conj _ _ hi', basis_conj _ _ hj', hci, hcj,
    signed_true, signed_true, hns, hns, neg_add]

/-- In an algebra of the tower, two purely imaginary elements annihilate in one order iff
they annihilate in the other. -/
theorem tower_mul_eq_zero_comm_of_imag (n : Nat) (x y : Tower n) (hx : conj x = -x)
    (hy : conj y = -y) (h : x * y = 0) : y * x = 0 := by
  have hc := tower_conj_mul n x y
  rw [h, tower_conj_zero, hx, hy, tower_neg_mul, tower_mul_neg, neg_neg] at hc
  exact hc.symm

/-- **The annihilation relation is symmetric** on cross-half vectors with non-zero first
index, in every dimension. -/
theorem crossAnnihilates_comm (n : Nat) (s t u r : Bool) (i j k m : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hm : m < 2 ^ n) (hi0 : i ≠ 0) (hk0 : k ≠ 0) :
    crossAnnihilates n s t i j u r k m = crossAnnihilates n u r k m s t i j := by
  apply Bool.eq_iff_iff.mpr
  rw [crossAnnihilates_iff n s t u r i j k m hi hj hk hm,
    crossAnnihilates_iff n u r s t k m i j hk hm hi hj]
  have hx := crossVec_conj n s t i j hi hj hi0
  have hy := crossVec_conj n u r k m hk hm hk0
  exact ⟨tower_mul_eq_zero_comm_of_imag _ _ _ hx hy,
    tower_mul_eq_zero_comm_of_imag _ _ _ hy hx⟩

/-! ## 2. Partners of admissible vertices are admissible -/

/-- An annihilating pair of cross-half vectors satisfies the combinatorial sign condition
`crossSign`. -/
theorem crossSign_of_crossAnnihilates (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hk : k < 2 ^ n) (h : crossAnnihilates n s t i j u r k m = true) :
    crossSign n i j k m = true := by
  have hcount := crossAnnihilates_pair_count n s t i j k m hi hk
  have hmem : (u, r) ∈ Finset.univ.filter (fun p : Bool × Bool =>
      crossAnnihilates n s t i j p.1 p.2 k m = true) := by simp [h]
  have hpos := Finset.card_pos.mpr ⟨_, hmem⟩
  rw [hcount, if_pos (crossAnnihilates_charge_eq n s t u r i j k m h)] at hpos
  by_contra hc
  rw [if_neg hc] at hpos
  exact absurd hpos (lt_irrefl 0)

/-- The middle index of an annihilating partner fails to associate with the outer pair. -/
theorem assocNeg_of_crossAnnihilates (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n)
    (h : crossAnnihilates n s t i j u r k m = true) :
    assocNeg n i k j = true := by
  have hs := crossSign_of_crossAnnihilates n s t u r i j k m hi hk h
  have hm : m = k ^^^ (i ^^^ j) :=
    (cross_charge_iff i j k m).mp (crossAnnihilates_charge_eq n s t u r i j k m h)
  rw [hm, crossSign_eq_assocNeg n i j k hi hj hk] at hs
  exact hs

/-- **Every annihilating partner of an admissible vertex is admissible**: its index pair
`(k, m)` has `k ≠ 0`, `m ≠ 0` and `k ≠ m`. -/
theorem crossAnnihilates_partner_adm (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hij : i ≠ j)
    (h : crossAnnihilates n s t i j u r k m = true) :
    k ≠ 0 ∧ m ≠ 0 ∧ k ≠ m := by
  have ha := assocNeg_of_crossAnnihilates n s t u r i j k m hi hj hk h
  have hc := crossAnnihilates_charge_eq n s t u r i j k m h
  have hm : m = k ^^^ (i ^^^ j) := (cross_charge_iff i j k m).mp hc
  refine ⟨fun hk0 => ?_, fun hm0 => ?_, fun hkm => ?_⟩
  · rw [assoc_middles_four n i j k hi hj (Or.inl hk0)] at ha
    exact Bool.false_ne_true ha
  · have hkx : k = i ^^^ j := by
      rw [hm0] at hm
      have := congrArg (fun x => x ^^^ (i ^^^ j)) hm
      simpa [Nat.xor_assoc] using this.symm
    rw [assoc_middles_four n i j k hi hj (Or.inr (Or.inr (Or.inr hkx)))] at ha
    exact Bool.false_ne_true ha
  · rw [hkm, Nat.xor_self] at hc
    exact hij (Nat.xor_eq_zero_iff.mp hc)

/-! ## 3. Symmetry of the adjacency matrices -/

/-- **The adjacency matrix of the annihilation graph is symmetric**, in every dimension. -/
theorem crossAdj_isSymm (n : Nat) : (crossAdj n).IsSymm := by
  refine Matrix.IsSymm.ext fun p q => ?_
  simp only [crossAdj]
  rw [crossAnnihilates_comm n q.1.1 q.1.2.1 p.1.1 p.1.2.1 _ _ _ _ q.1.2.2.1.isLt
    q.1.2.2.2.isLt p.1.2.2.1.isLt p.1.2.2.2.isLt q.2.1 p.2.1]

/-- **The charge-sector adjacency matrix is symmetric**, in every dimension and for every
charge. -/
theorem sectorAdj_isSymm (n χ : Nat) : (sectorAdj n χ).IsSymm := by
  refine Matrix.IsSymm.ext fun p q => ?_
  simp only [sectorAdj]
  rw [crossAnnihilates_comm n q.1.1.1 q.1.1.2.1 p.1.1.1 p.1.1.2.1 _ _ _ _ q.1.1.2.2.1.isLt
    q.1.1.2.2.2.isLt p.1.1.2.2.1.isLt p.1.1.2.2.2.isLt q.1.2.1 p.1.2.1]

/-! ## 4. Exact row sums -/

/-- The indicator row of a vertex, as a function on all cross-half vectors. -/
noncomputable def crossRow (n : Nat) (s t : Bool) (i j : Nat) (q : crossVertex n) : ℝ :=
  if crossAnnihilates n s t i j q.1 q.2.1 q.2.2.1 q.2.2.2 = true then 1 else 0

/-- Summing a function over an injective image that contains its support. -/
theorem sum_comp_eq_sum_univ_of_support {V W : Type*} [Fintype V] [Fintype W] [DecidableEq W]
    (e : V → W) (he : Function.Injective e) (f : W → ℝ)
    (hsupp : ∀ w, f w ≠ 0 → ∃ v, e v = w) :
    ∑ v, f (e v) = ∑ w, f w := by
  rw [← Finset.sum_image (fun a _ b _ h => he h)]
  refine Finset.sum_subset (Finset.subset_univ _) fun w _ hw => ?_
  by_contra hne
  obtain ⟨v, rfl⟩ := hsupp w hne
  exact hw (Finset.mem_image_of_mem e (Finset.mem_univ v))

/-- **Exact row sums of the annihilation-graph adjacency matrix**: the row of an admissible
vertex `(s, t, i, j)` sums to its full vertex degree `crossDegree n s t i j`. -/
theorem crossAdj_rowSum_eq_crossDegree (n : Nat) (p : admVertex n) :
    ∑ q, crossAdj n p q = (crossDegree n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 : ℝ) := by
  classical
  rw [← sum_indicator_eq_crossDegree]
  refine sum_comp_eq_sum_univ_of_support (fun v : admVertex n => v.1) Subtype.val_injective
    (crossRow n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2) fun w hw => ?_
  have hann : crossAnnihilates n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 w.1 w.2.1 w.2.2.1 w.2.2.2
      = true := by
    by_contra h; exact hw (by simp [crossRow, h])
  exact ⟨⟨w, crossAnnihilates_partner_adm n _ _ _ _ _ _ _ _ p.1.2.2.1.isLt p.1.2.2.2.isLt
    w.2.2.1.isLt p.2.2.2 hann⟩, rfl⟩

/-- **Exact row sums of the annihilation-graph adjacency matrix, degree-law form**:
the row of an admissible vertex with index pair `(i, j)` sums to `2 · towerDegree n i j`. -/
theorem crossAdj_rowSum (n : Nat) (p : admVertex n) :
    ∑ q, crossAdj n p q = 2 * (towerDegree n p.1.2.2.1 p.1.2.2.2 : ℝ) := by
  rw [crossAdj_rowSum_eq_crossDegree, crossDegree_eq_two_mul_towerDegree n _ _ _ _
    p.1.2.2.1.isLt p.1.2.2.2.isLt p.2.1 p.2.2.1 p.2.2.2]
  push_cast; ring

/-- **Exact row sums of the charge-sector adjacency matrix**: restricting the annihilation
graph to a charge sector loses no neighbours, so each row sums to the full vertex degree. -/
theorem sectorAdj_rowSum_eq_crossDegree (n χ : Nat) (p : SectorVertex n χ) :
    ∑ q, sectorAdj n χ p q
      = (crossDegree n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2 : ℝ) := by
  classical
  rw [← sum_indicator_eq_crossDegree]
  refine sum_comp_eq_sum_univ_of_support (fun v : SectorVertex n χ => v.1.1)
    (fun a b h => Subtype.val_injective (Subtype.val_injective h))
    (crossRow n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2) fun w hw => ?_
  have hann : crossAnnihilates n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2
      w.1 w.2.1 w.2.2.1 w.2.2.2 = true := by
    by_contra h; exact hw (by simp [crossRow, h])
  have hadm : AdmVertex n w := crossAnnihilates_partner_adm n _ _ _ _ _ _ _ _
    p.1.1.2.2.1.isLt p.1.1.2.2.2.isLt w.2.2.1.isLt p.1.2.2.2 hann
  have hsec : InSector n χ ⟨w, hadm⟩ := by
    have hc := crossAnnihilates_charge_eq n _ _ _ _ _ _ _ _ hann
    have hp : (p.1.1.2.2.1 : Nat) ^^^ (p.1.1.2.2.2 : Nat) = χ := p.2
    show (w.2.2.1 : Nat) ^^^ (w.2.2.2 : Nat) = χ
    rw [← hc, hp]
  exact ⟨⟨⟨w, hadm⟩, hsec⟩, rfl⟩

/-- **Milestone T1: exact row sums of the charge-sector adjacency matrix.**  For every level
`n`, every charge `χ` and every vertex `(s, t, i, j)` of the sector,
`∑_q (sectorAdj n χ) p q = 2 · towerDegree n i j`. -/
theorem sectorAdj_rowSum (n χ : Nat) (p : SectorVertex n χ) :
    ∑ q, sectorAdj n χ p q = 2 * (towerDegree n p.1.1.2.2.1 p.1.1.2.2.2 : ℝ) := by
  rw [sectorAdj_rowSum_eq_crossDegree, crossDegree_eq_two_mul_towerDegree n _ _ _ _
    p.1.1.2.2.1.isLt p.1.1.2.2.2.isLt p.1.2.1 p.1.2.2.1 p.1.2.2.2]
  push_cast; ring

/-! ## 5. The spectral radius of a charge sector -/

/-- **Every real eigenvalue of a charge-sector adjacency matrix satisfies `|λ| ≤ Dₐ - 8`**,
where `Dₐ = 2ⁿ⁺¹`, in every dimension `n ≥ 3` and for every charge.  The constant is derived
from the exact row sums `sectorAdj_rowSum` and the degree bounds `crossDegree_bounds`. -/
theorem sectorAdj_eigenvalue_abs_le (n χ : Nat) (hn : 3 ≤ n) (lam : ℝ)
    (x : SectorVertex n χ → ℝ) (hx : x ≠ 0) (heig : (sectorAdj n χ).mulVec x = lam • x) :
    |lam| ≤ 2 ^ (n + 1) - 8 := by
  have hge : (8 : Nat) ≤ 2 ^ (n + 1) := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ (n + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  refine eigenvalue_abs_le_rowSum_of_nonneg (sectorAdj n χ) _ (sectorAdj_nonneg n χ)
    (fun p => ?_) lam x hx heig
  obtain ⟨hi0, hj0, hij⟩ := p.1.2
  have hdeg := (crossDegree_bounds n hn p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2
    p.1.1.2.2.1.isLt p.1.1.2.2.2.isLt hi0 hj0 hij).2
  have hcast : ((crossDegree n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2 : ℕ) : ℝ)
      ≤ ((2 ^ (n + 1) - 8 : ℕ) : ℝ) := Nat.cast_le.mpr hdeg
  rw [Nat.cast_sub hge] at hcast
  push_cast at hcast
  rw [sectorAdj_rowSum_eq_crossDegree]
  exact hcast

end Sovereign.Graph
