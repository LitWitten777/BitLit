import Sovereign.Algebra.TowerZeroDivisors
import Sovereign.Combinatorics.TowerDegreeHandshake
import Mathlib.Data.Real.Basic
import Mathlib.Data.Fintype.BigOperators

namespace Sovereign

open Finset

/-! ## 1. The annihilation test -/

/-- The decidable annihilation test for two cross-half vectors of the algebra of dimension
`2ⁿ⁺¹`, read off `crossVec_mul_eq_zero_iff`. -/
def crossAnnihilates (n : Nat) (s t : Bool) (i j : Nat) (u r : Bool) (k m : Nat) : Bool :=
  decide (i ^^^ j = k ^^^ m) &&
  decide (xor s (xor u (epsNeg (n + 1) i k))
    ≠ xor t (xor r (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m)))) &&
  decide (xor s (xor r (epsNeg (n + 1) i (2 ^ n + m)))
    ≠ xor t (xor u (epsNeg (n + 1) (2 ^ n + j) k)))

/-- The test really decides annihilation in the Cayley–Dickson algebra. -/
theorem crossAnnihilates_iff (n : Nat) (s t u r : Bool) (i j k m : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hm : m < 2 ^ n) :
    crossAnnihilates n s t i j u r k m = true
      ↔ crossVec n s i t j * crossVec n u k r m = 0 := by
  rw [crossVec_mul_eq_zero_iff n s t u r i j k m hi hj hk hm, crossAnnihilates]
  simp only [Bool.and_eq_true, decide_eq_true_iff, and_assoc]

/-! ## 1a. Sign-flip involution and harmonic cancellation -/

/-- The sign-flip involution `(u, r) ↦ (!u, !r)` preserves `crossAnnihilates`.
This reflects the fundamental symmetry that negating both halves of a cross-half
vector preserves orthogonality and zero-divisor relations. -/
theorem crossAnnihilates_involution (n : Nat) (s t u r : Bool) (i j k m : Nat) :
    crossAnnihilates n s t i j (!u) (!r) k m = crossAnnihilates n s t i j u r k m := by
  dsimp [crossAnnihilates]
  congr 2
  · cases s <;> cases t <;> cases u <;> cases r <;>
      cases epsNeg (n + 1) i k <;>
      cases epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m) <;> decide
  · cases s <;> cases t <;> cases u <;> cases r <;>
      cases epsNeg (n + 1) i (2 ^ n + m) <;>
      cases epsNeg (n + 1) (2 ^ n + j) k <;> decide

/-- Summing the first-half sign `(-1)^u` over the 4-element sign fiber vanishes on the
annihilation graph, proving exact nullity of the U-harmonic subspace: `A U = 0`. -/
theorem sum_signed_u_crossAnnihilates (n : Nat) (s t : Bool) (i j k m : Nat) :
    (∑ p : Bool × Bool,
      (if p.1 then (-1 : ℝ) else 1) *
      (if crossAnnihilates n s t i j p.1 p.2 k m = true then 1 else 0)) = 0 := by
  have h00 : crossAnnihilates n s t i j true true k m =
             crossAnnihilates n s t i j false false k m :=
    crossAnnihilates_involution n s t false false i j k m
  have h01 : crossAnnihilates n s t i j true false k m =
             crossAnnihilates n s t i j false true k m :=
    crossAnnihilates_involution n s t false true i j k m
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_bool, Bool.false_eq_true, ite_false, ite_true]
  rw [h00, h01]
  ring

/-- Summing the second-half sign `(-1)^r` over the 4-element sign fiber vanishes on the
annihilation graph, proving exact nullity of the V-harmonic subspace: `A V = 0`. -/
theorem sum_signed_r_crossAnnihilates (n : Nat) (s t : Bool) (i j k m : Nat) :
    (∑ p : Bool × Bool,
      (if p.2 then (-1 : ℝ) else 1) *
      (if crossAnnihilates n s t i j p.1 p.2 k m = true then 1 else 0)) = 0 := by
  have h00 : crossAnnihilates n s t i j true true k m =
             crossAnnihilates n s t i j false false k m :=
    crossAnnihilates_involution n s t false false i j k m
  have h01 : crossAnnihilates n s t i j true false k m =
             crossAnnihilates n s t i j false true k m :=
    crossAnnihilates_involution n s t false true i j k m
  rw [Fintype.sum_prod_type]
  simp only [Fintype.sum_bool, Bool.false_eq_true, ite_false, ite_true]
  rw [h00, h01]
  ring

/-- **Lemma 1: Cayley–Dickson high-half sign inversion.** For pure imaginary octonions
`j, m ∈ {1..7}` with `j ≠ m`, the level-4 Cayley–Dickson doubling sign satisfies
`epsNeg 4 (8+j) (8+m) = !epsNeg 3 j m`. -/
theorem sedenion_eps_high_parity :
    ∀ j ∈ List.range 8, ∀ m ∈ List.range 8,
    j ≠ 0 → m ≠ 0 → j ≠ m →
    epsNeg 4 (8 + j) (8 + m) = !epsNeg 3 j m := by
  decide

/-- **Lemma 2: Condition c1 parity relation.** On every edge of the sedenion
annihilation graph, condition `c1` enforces that the sign parity of the four
vertex decorations matches the level-3 cross-basis sign parity:
  `s ^ t ^ u ^ r = epsNeg 3 i k ^ epsNeg 3 j m`. -/
theorem sedenion_edge_c1_parity :
    ∀ s t : Bool, ∀ i ∈ List.range 8, ∀ j ∈ List.range 8,
    ∀ u r : Bool, ∀ k ∈ List.range 8, ∀ m ∈ List.range 8,
    crossAnnihilates 3 s t i j u r k m = true →
    xor (xor s t) (xor u r) = xor (epsNeg 3 i k) (epsNeg 3 j m) := by
  decide

/-- **Lemma 3: Cohomological obstruction on the Klein four-group (non-collinear Fano triples).**
For any four distinct imaginary basis elements `i, j, k, m ∈ {1..7}` with `i ^ j = k ^ m`,
the 4-cycle parity equals `true` (evaluates to -1) precisely because `{e_i, e_j, e_k, e_m}`
span no quaternionic subalgebra `ℍ ⊂ 𝕆` (i.e. the triple `(i, j, k)` is non-collinear
in the Fano plane, representing the non-trivial generator of `H³(V, ℤ₂)`). -/
theorem octonion_klein4_cocycle_obstruction :
    ∀ i ∈ List.range 8, ∀ j ∈ List.range 8,
    ∀ k ∈ List.range 8, ∀ m ∈ List.range 8,
    i ≠ 0 → j ≠ 0 → k ≠ 0 → m ≠ 0 →
    i ≠ j → k ≠ m → (i ^^^ j = k ^^^ m) → (k ≠ i ∧ k ≠ j ∧ k ≠ (i ^^^ j)) →
    xor (xor (epsNeg 3 i j) (epsNeg 3 i k)) (xor (epsNeg 3 k m) (epsNeg 3 j m)) = true := by
  decide

/-- **The edge-by-edge sign relation (Theorem 2).** On every edge of the sedenion
annihilation graph, the c1 parity relation and the octonionic cohomological obstruction
both hold simultaneously. -/
theorem sedenion_edge_bipartite_coloring :
    ∀ s t : Bool, ∀ i ∈ List.range 8, ∀ j ∈ List.range 8,
    ∀ u r : Bool, ∀ k ∈ List.range 8, ∀ m ∈ List.range 8,
    crossAnnihilates 3 s t i j u r k m = true →
    (xor (xor s t) (xor u r) = xor (epsNeg 3 i k) (epsNeg 3 j m)) ∧
    (xor (xor (epsNeg 3 i j) (epsNeg 3 i k)) (xor (epsNeg 3 k m) (epsNeg 3 j m)) = true) := by
  decide

/-- **The bipartite ground state product identity.** Combining the parity relation and
the cohomological obstruction shows that the sign bit of `W[p, χ] · W[q, χ]` is identically `true`
(i.e. -1) on every edge of the annihilation graph, proving `A W = -8 W`. -/
theorem sedenion_edge_w_prod_sign :
    ∀ s t : Bool, ∀ i ∈ List.range 8, ∀ j ∈ List.range 8,
    ∀ u r : Bool, ∀ k ∈ List.range 8, ∀ m ∈ List.range 8,
    crossAnnihilates 3 s t i j u r k m = true →
    (xor (xor (xor s t) (epsNeg 3 i j))
         (xor (xor u r) (epsNeg 3 k m)) = true) := by
  decide

/-! ## 2. The degree of a vertex -/

/-- Charge conservation solves for the partner's second index. -/
theorem cross_charge_iff (i j k m : Nat) : i ^^^ j = k ^^^ m ↔ m = k ^^^ (i ^^^ j) := by
  constructor
  · intro h
    rw [h, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
  · intro h
    rw [h, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]

/-- `crossDegree n s t i j` is the number of cross-half vectors annihilated by
`signed s e_i + signed t e_{2ⁿ+j}` in the algebra of dimension `2ⁿ⁺¹`: the degree of that
vertex of the annihilation graph. -/
def crossDegree (n : Nat) (s t : Bool) (i j : Nat) : Nat :=
  ∑ k ∈ range (2 ^ n), ∑ m ∈ range (2 ^ n),
    (Finset.univ.filter (fun p : Bool × Bool =>
      crossAnnihilates n s t i j p.1 p.2 k m = true)).card

/-- **The sign count.**  For a fixed partner index pair, the four sign decorations of the
partner give either two annihilators or none. -/
theorem sign_pair_count (s t e1 e2 e3 e4 : Bool) :
    (Finset.univ.filter (fun p : Bool × Bool =>
        (decide (xor s (xor p.1 e1) ≠ xor t (xor p.2 e4)) &&
          decide (xor s (xor p.2 e2) ≠ xor t (xor p.1 e3))) = true)).card
      = if xor e1 (xor e4 (xor e2 e3)) = false then 2 else 0 := by
  decide +revert

/-- The four level-`n+1` signs of a doubling step, combined, are the complement of
`crossSign`. -/
theorem epsNeg_succ_combination (n i j k m : Nat) (hi : i < 2 ^ n) (hk : k < 2 ^ n) :
    xor (epsNeg (n + 1) i k)
        (xor (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m))
          (xor (epsNeg (n + 1) i (2 ^ n + m)) (epsNeg (n + 1) (2 ^ n + j) k)))
      = !(crossSign n i j k m) := by
  rw [epsNeg_succ_low_low n i k hi hk, epsNeg_succ_high_high n j m,
    epsNeg_succ_low_high n i m hi, epsNeg_succ_high_low n j k hk, crossSign]
  cases epsNeg n i k <;> cases epsNeg n m j <;> cases epsNeg n m i <;> cases epsNeg n j k <;>
    cases conjNeg k <;> cases conjNeg m <;> simp

/-- The number of annihilating sign decorations of one partner index pair. -/
theorem crossAnnihilates_pair_count (n : Nat) (s t : Bool) (i j k m : Nat) (hi : i < 2 ^ n)
    (hk : k < 2 ^ n) :
    (Finset.univ.filter (fun p : Bool × Bool =>
        crossAnnihilates n s t i j p.1 p.2 k m = true)).card
      = if i ^^^ j = k ^^^ m then (if crossSign n i j k m = true then 2 else 0) else 0 := by
  by_cases hc : i ^^^ j = k ^^^ m
  · rw [if_pos hc]
    have hfil : ∀ p : Bool × Bool, crossAnnihilates n s t i j p.1 p.2 k m
        = (decide (xor s (xor p.1 (epsNeg (n + 1) i k))
              ≠ xor t (xor p.2 (epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m)))) &&
            decide (xor s (xor p.2 (epsNeg (n + 1) i (2 ^ n + m)))
              ≠ xor t (xor p.1 (epsNeg (n + 1) (2 ^ n + j) k)))) := by
      intro p
      rw [crossAnnihilates, decide_eq_true hc, Bool.true_and]
    rw [Finset.filter_congr (fun p _ => by rw [hfil p]), sign_pair_count,
      epsNeg_succ_combination n i j k m hi hk]
    cases hs : crossSign n i j k m <;> simp
  · rw [if_neg hc, Finset.card_eq_zero, Finset.filter_eq_empty_iff]
    intro p _
    rw [crossAnnihilates, decide_eq_false hc]
    simp

/-- **The vertex-degree law.**  The degree of the vertex `signed s e_i + signed t e_{2ⁿ+j}`
of the annihilation graph is twice the number of middles that fail to associate with the
outer pair `(e_i, ·, e_j)` — in particular it does not depend on the signs. -/
theorem crossDegree_eq_two_mul_card (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) :
    crossDegree n s t i j = 2 * (nonassocMiddles n i j).card := by
  have hij : i ^^^ j < 2 ^ n := Nat.xor_lt_two_pow hi hj
  have hinner : ∀ k ∈ range (2 ^ n),
      (∑ m ∈ range (2 ^ n), (Finset.univ.filter (fun p : Bool × Bool =>
          crossAnnihilates n s t i j p.1 p.2 k m = true)).card)
        = if assocNeg n i k j = true then 2 else 0 := by
    intro k hk
    have hk' := Finset.mem_range.mp hk
    have hmem : k ^^^ (i ^^^ j) ∈ range (2 ^ n) :=
      Finset.mem_range.mpr (Nat.xor_lt_two_pow hk' hij)
    have hpt : ∀ m ∈ range (2 ^ n),
        (Finset.univ.filter (fun p : Bool × Bool =>
            crossAnnihilates n s t i j p.1 p.2 k m = true)).card
          = if m = k ^^^ (i ^^^ j) then (if crossSign n i j k m = true then 2 else 0) else 0 := by
      intro m _
      rw [crossAnnihilates_pair_count n s t i j k m hi hk']
      by_cases hm : m = k ^^^ (i ^^^ j)
      · rw [if_pos hm, if_pos ((cross_charge_iff i j k m).mpr hm)]
      · rw [if_neg hm, if_neg (fun hc => hm ((cross_charge_iff i j k m).mp hc))]
    rw [Finset.sum_congr rfl hpt, Finset.sum_ite_eq' (range (2 ^ n)) (k ^^^ (i ^^^ j))
      (fun m => if crossSign n i j k m = true then 2 else 0), if_pos hmem,
      crossSign_eq_assocNeg n i j k hi hj hk']
  rw [crossDegree, Finset.sum_congr rfl hinner, nonassocMiddles, Finset.card_filter,
    Finset.mul_sum]
  exact Finset.sum_congr rfl (fun k _ => by by_cases h : assocNeg n i k j = true <;> simp [h])

/-- **The vertex-degree law, in terms of the degree recursion.**  For an admissible index
pair the degree of each of its four vertices is `2 · towerDegree n i j`. -/
theorem crossDegree_eq_two_mul_towerDegree (n : Nat) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    crossDegree n s t i j = 2 * towerDegree n i j := by
  rw [crossDegree_eq_two_mul_card n s t i j hi hj,
    nonassocMiddles_card_eq_towerDegree n i j hi hj hi0 hj0 hij]

/-! ## 3. The edge count -/

/-- The sum of the degrees of all vertices of the annihilation graph of dimension `2ⁿ⁺¹`,
i.e. twice its number of edges. -/
def crossTotalDegree (n : Nat) : Nat :=
  ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), ∑ p : Bool × Bool, crossDegree n p.1 p.2 i j

/-- **The handshake of the annihilation graph.**  The sum of the vertex degrees is eight
times the total number of non-associating middles: four vertices per ordered index pair,
each of degree twice the number of middles. -/
theorem crossTotalDegree_eq_handshake (n : Nat) :
    crossTotalDegree n = 8 * totalNonassocMiddles n := by
  rw [crossTotalDegree, totalNonassocMiddles_eq_sum, Finset.mul_sum]
  refine Finset.sum_congr rfl (fun i hi => ?_)
  rw [Finset.mul_sum]
  refine Finset.sum_congr rfl (fun j hj => ?_)
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  rw [Finset.sum_congr rfl (fun p _ =>
    crossDegree_eq_two_mul_card n p.1 p.2 i j hi' hj'), Finset.sum_const,
    Finset.card_univ]
  simp only [Fintype.card_prod, Fintype.card_bool, smul_eq_mul]
  ring

/-- **The edge count in every dimension.**  With `D = 2ⁿ` the sum of the vertex degrees of
the annihilation graph of the algebra of dimension `2ⁿ⁺¹` is `4 D³ - 112 D + 192`; halving
it, the graph has `Dₐ³/4 - 28 Dₐ + 96` edges for `Dₐ = 2ⁿ⁺¹`. -/
theorem crossTotalDegree_formula (n : Nat) (hn : 1 ≤ n) :
    crossTotalDegree n + 112 * 2 ^ n = 4 * (2 ^ n) ^ 3 + 192 := by
  have h := totalNonassocMiddles_formula n hn
  rw [crossTotalDegree_eq_handshake]
  omega

end Sovereign
