/-
Copyright (c) 2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Characteristic polynomials of real symmetric matrices from polynomial certificates

For a real symmetric (Hermitian) matrix `A` with eigenvalues `λᵢ` (Mathlib's
`IsHermitian.eigenvalues`), this module relates certificate data to the spectrum:

* `trace_hornerM_of_isHermitian` — `trace (∑ cₖ Aᵏ) = ∑ᵢ ∑ₖ cₖ λᵢᵏ`;
* `hornerS_eigenvalue_eq_zero` — every eigenvalue is a root of every annihilating polynomial;
* `charpoly_eq_prod_of_mem` — if all eigenvalues lie in a finite set `S`, then
  `charpoly A = ∏_{v ∈ S} (X - v)^{#{i : λᵢ = v}}`.

The multiplicities `#{i : λᵢ = v}` can then be read off traces of Lagrange-type polynomials,
which are computable from integer data.
-/

import Sovereign.Graph.MatrixCertificate

namespace Sovereign.Graph

open Matrix Polynomial

section Generic

variable {ι : Type*} [Fintype ι] [DecidableEq ι] {R : Type*} [CommRing R]

theorem hornerM_diagonal (d : ι → R) (cs : List R) :
    hornerM (Matrix.diagonal d) cs = Matrix.diagonal (fun i => hornerS (d i) cs) := by
  induction cs with
  | nil => simp [hornerM, hornerS]
  | cons c cs ih =>
    rw [hornerM, ih, Matrix.diagonal_mul_diagonal, Matrix.diagonal_add]
    rfl

theorem hornerM_algHom (φ : Matrix ι ι R →ₐ[R] Matrix ι ι R) (B : Matrix ι ι R) (cs : List R) :
    φ (hornerM B cs) = hornerM (φ B) cs := by
  induction cs with
  | nil => simp [hornerM]
  | cons c cs ih =>
    have hd : (Matrix.diagonal (fun _ => c) : Matrix ι ι R) = algebraMap R _ c := by
      rw [Matrix.algebraMap_eq_diagonal]; rfl
    rw [hornerM, hornerM, map_add, map_mul, ih, hd, AlgHom.commutes]

theorem hornerM_submatrix {κ : Type*} [Fintype κ] [DecidableEq κ] (e : κ ≃ ι)
    (B : Matrix ι ι R) (cs : List R) :
    hornerM (B.submatrix e e) cs = (hornerM B cs).submatrix e e := by
  induction cs with
  | nil => simp [hornerM]
  | cons c cs ih =>
    have h1 : (B.submatrix e e) * (hornerM B cs).submatrix e e
        = (B * hornerM B cs).submatrix e e := Matrix.submatrix_mul_equiv _ _ _ _ _
    rw [hornerM, hornerM, ih, h1]
    ext i j
    simp [Matrix.diagonal_apply, e.apply_eq_iff_eq]

omit [DecidableEq ι] in
theorem trace_submatrix_equiv {κ : Type*} [Fintype κ] (e : κ ≃ ι) (B : Matrix ι ι R) :
    (B.submatrix e e).trace = B.trace := by
  simp only [Matrix.trace, Matrix.diag, Matrix.submatrix_apply]
  exact Equiv.sum_comp e (fun i => B i i)

omit [DecidableEq ι] in
theorem trace_map_ringHom {S : Type*} [CommRing S] (f : R →+* S) (B : Matrix ι ι R) :
    (B.map f).trace = f B.trace := by
  simp [Matrix.trace, map_sum]

end Generic

section Hermitian

variable {ι : Type*} [Fintype ι] [DecidableEq ι]

/-- **Trace of a matrix polynomial of a symmetric matrix**: `tr (∑ cₖ Aᵏ) = ∑ᵢ ∑ₖ cₖ λᵢᵏ`. -/
theorem trace_hornerM_of_isHermitian (A : Matrix ι ι ℝ) (hA : A.IsHermitian) (cs : List ℝ) :
    (hornerM A cs).trace = ∑ i, hornerS (hA.eigenvalues i) cs := by
  set U := hA.eigenvectorUnitary
  set φ : Matrix ι ι ℝ →ₐ[ℝ] Matrix ι ι ℝ :=
    (Unitary.conjStarAlgAut ℝ (Matrix ι ι ℝ) U).toAlgEquiv.toAlgHom
  have hspec : A = φ (Matrix.diagonal (RCLike.ofReal ∘ hA.eigenvalues)) := hA.spectral_theorem
  have key : hornerM A cs = φ (hornerM (Matrix.diagonal (RCLike.ofReal ∘ hA.eigenvalues)) cs) := by
    conv_lhs => rw [hspec]
    exact (hornerM_algHom _ _ _).symm
  rw [key, hornerM_diagonal]
  simp only [φ, AlgEquiv.toAlgHom_eq_coe, AlgHom.coe_coe, StarAlgEquiv.coe_toAlgEquiv,
    Unitary.conjStarAlgAut_apply]
  rw [Matrix.trace_mul_cycle, Unitary.coe_star_mul_self, Matrix.one_mul, Matrix.trace_diagonal]
  simp

/-- Every eigenvalue of a symmetric matrix is a root of every annihilating polynomial. -/
theorem hornerS_eigenvalue_eq_zero (A : Matrix ι ι ℝ) (hA : A.IsHermitian) (cs : List ℝ)
    (h : hornerM A cs = 0) (i : ι) : hornerS (hA.eigenvalues i) cs = 0 := by
  refine hornerS_eq_zero_of_eigen A cs h _ (⇑(hA.eigenvectorBasis i)) ?_
    (hA.mulVec_eigenvectorBasis i)
  intro h0
  have hn := hA.eigenvectorBasis.orthonormal.1 i
  have : hA.eigenvectorBasis i = 0 := by
    ext j
    exact congrFun h0 j
  rw [this, norm_zero] at hn
  exact zero_ne_one hn

/-- **The characteristic polynomial from the eigenvalue multiplicities.** -/
theorem charpoly_eq_prod_of_mem (A : Matrix ι ι ℝ) (hA : A.IsHermitian) (S : Finset ℝ)
    (hS : ∀ i, hA.eigenvalues i ∈ S) :
    A.charpoly = ∏ v ∈ S, (X - C v) ^ (Finset.univ.filter (fun i => hA.eigenvalues i = v)).card := by
  rw [hA.charpoly_eq]
  simp only [RCLike.ofReal_real_eq_id, id]
  rw [← Finset.prod_fiberwise_of_maps_to (g := hA.eigenvalues) (t := S)
    (fun i _ => hS i)]
  refine Finset.prod_congr rfl fun v _ => ?_
  rw [Finset.prod_congr rfl (fun i hi => by rw [(Finset.mem_filter.mp hi).2]),
    Finset.prod_const]

end Hermitian

end Sovereign.Graph
