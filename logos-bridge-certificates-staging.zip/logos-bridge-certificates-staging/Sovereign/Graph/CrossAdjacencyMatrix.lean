import Mathlib
import Sovereign.Graph.AdjacencyEigenvalueBound

namespace Sovereign.Graph

open Finset Matrix Sovereign

/-! ## 1. The vertices -/

/-- A sign-decorated cross-half vector `s eᵢ + t e_{2ⁿ+j}` of the algebra of dimension
`2ⁿ⁺¹`. -/
abbrev crossVertex (n : Nat) : Type := Bool × Bool × Fin (2 ^ n) × Fin (2 ^ n)

/-- Admissibility of the index pair of a vertex. -/
def AdmVertex (n : Nat) (p : crossVertex n) : Prop :=
  (p.2.2.1 : Nat) ≠ 0 ∧ (p.2.2.2 : Nat) ≠ 0 ∧ (p.2.2.1 : Nat) ≠ (p.2.2.2 : Nat)

instance (n : Nat) : DecidablePred (AdmVertex n) := fun p => by
  unfold AdmVertex; infer_instance

/-- The vertices of the annihilation graph: cross-half vectors with an admissible index
pair. -/
abbrev admVertex (n : Nat) : Type := {p : crossVertex n // AdmVertex n p}

/-! ## 2. Summing over vertices -/

/-- A double `Fin` sum as a double `range` sum. -/
theorem sum_fin_two_eq_range {M : Type*} [AddCommMonoid M] (N : Nat) (F : Nat → Nat → M) :
    ∑ k : Fin N, ∑ m : Fin N, F k m = ∑ k ∈ range N, ∑ m ∈ range N, F k m := by
  rw [← Fin.sum_univ_eq_sum_range (fun k => ∑ m ∈ range N, F k m) N]
  exact Finset.sum_congr rfl fun x _ => Fin.sum_univ_eq_sum_range (fun y => F x y) N

/-- Summing a function of a cross-half vertex: indices first, then signs. -/
theorem sum_crossVertex {M : Type*} [AddCommMonoid M] (n : Nat)
    (G : Bool → Bool → Nat → Nat → M) :
    ∑ q : crossVertex n, G q.1 q.2.1 q.2.2.1 q.2.2.2
      = ∑ k ∈ range (2 ^ n), ∑ m ∈ range (2 ^ n), ∑ p : Bool × Bool, G p.1 p.2 k m := by
  let e : crossVertex n ≃ (Fin (2 ^ n) × Fin (2 ^ n)) × (Bool × Bool) :=
    { toFun := fun p => ((p.2.2.1, p.2.2.2), (p.1, p.2.1))
      invFun := fun q => (q.2.1, q.2.2, q.1.1, q.1.2)
      left_inv := fun _ => rfl
      right_inv := fun _ => rfl }
  rw [← Equiv.sum_comp e.symm (fun q : crossVertex n => G q.1 q.2.1 q.2.2.1 q.2.2.2)]
  rw [Fintype.sum_prod_type, Fintype.sum_prod_type]
  rw [← sum_fin_two_eq_range (2 ^ n) (fun a b => ∑ p : Bool × Bool, G p.1 p.2 a b)]
  rfl

/-- The vertex degree, as a sum of annihilation indicators over all cross-half vertices. -/
theorem sum_indicator_eq_crossDegree (n : Nat) (s t : Bool) (i j : Nat) :
    ∑ q : crossVertex n,
        (if crossAnnihilates n s t i j q.1 q.2.1 q.2.2.1 q.2.2.2 = true then (1 : ℝ) else 0)
      = (crossDegree n s t i j : ℝ) := by
  rw [sum_crossVertex n (fun u r k m =>
    (if crossAnnihilates n s t i j u r k m = true then (1 : ℝ) else 0)), crossDegree]
  push_cast
  refine Finset.sum_congr rfl fun k _ => Finset.sum_congr rfl fun m _ => ?_
  rw [Finset.card_filter]
  push_cast
  rfl

/-! ## 3. The adjacency matrix -/

/-- The `{0,1}` adjacency matrix of the annihilation graph of dimension `2ⁿ⁺¹`. -/
def crossAdj (n : Nat) : Matrix (admVertex n) (admVertex n) ℝ := fun p q =>
  if crossAnnihilates n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 q.1.1 q.1.2.1 q.1.2.2.1 q.1.2.2.2
      = true then 1 else 0

/-- Every entry of the adjacency matrix is `0` or `1`. -/
theorem crossAdj_entry (n : Nat) (p q : admVertex n) :
    crossAdj n p q = 0 ∨ crossAdj n p q = 1 := by
  unfold crossAdj
  split
  · exact Or.inr rfl
  · exact Or.inl rfl

/-- The adjacency matrix is non-negative. -/
theorem crossAdj_nonneg (n : Nat) (p q : admVertex n) : 0 ≤ crossAdj n p q := by
  rcases crossAdj_entry n p q with h | h
  · rw [h]
  · rw [h]; norm_num

/-- **The row sums of the adjacency matrix are bounded by the proved vertex degrees.** -/
theorem crossAdj_rowSum_le (n : Nat) (p : admVertex n) :
    ∑ q, crossAdj n p q ≤ (crossDegree n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 : ℝ) := by
  classical
  set f : crossVertex n → ℝ := fun q =>
    if crossAnnihilates n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 q.1 q.2.1 q.2.2.1 q.2.2.2 = true
      then 1 else 0 with hf
  have hsub : ∑ q ∈ univ.filter (AdmVertex n), f q = ∑ q : admVertex n, f q.1 :=
    Finset.sum_subtype _ (fun x => by simp) f
  have hle : ∑ q ∈ univ.filter (AdmVertex n), f q ≤ ∑ q : crossVertex n, f q := by
    refine Finset.sum_le_sum_of_subset_of_nonneg (Finset.filter_subset _ _) ?_
    intro q _ _
    rw [hf]
    dsimp only
    split
    · norm_num
    · norm_num
  rw [← sum_indicator_eq_crossDegree n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2]
  calc ∑ q, crossAdj n p q = ∑ q : admVertex n, f q.1 := rfl
    _ = ∑ q ∈ univ.filter (AdmVertex n), f q := hsub.symm
    _ ≤ ∑ q : crossVertex n, f q := hle

/-! ## 4. The spectral bound, unconditionally -/

/-- **Every real eigenvalue of the annihilation-graph adjacency matrix of dimension
`Dₐ = 2ⁿ⁺¹` satisfies `|λ| ≤ Dₐ - 8`**, in every dimension.

Nothing is tabulated: the bound comes from the vertex-degree law
`crossDegree_eq_two_mul_towerDegree`, the degree bounds `towerDegree_bounds`, and the row-sum
eigenvalue bound `eigenvalue_abs_le_rowSum_of_nonneg`. -/
theorem crossAdj_eigenvalue_abs_le (n : Nat) (hn : 3 ≤ n) (lam : ℝ) (x : admVertex n → ℝ)
    (hx : x ≠ 0) (heig : (crossAdj n).mulVec x = lam • x) :
    |lam| ≤ 2 ^ (n + 1) - 8 := by
  have hge : (8 : Nat) ≤ 2 ^ (n + 1) := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ (n + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  refine eigenvalue_abs_le_rowSum_of_nonneg (crossAdj n) _ (crossAdj_nonneg n)
    (fun p => ?_) lam x hx heig
  obtain ⟨hi0, hj0, hij⟩ := p.2
  have hdeg := (crossDegree_bounds n hn p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 p.1.2.2.1.isLt
    p.1.2.2.2.isLt hi0 hj0 hij).2
  have hcast : ((crossDegree n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 : ℕ) : ℝ)
      ≤ ((2 ^ (n + 1) - 8 : ℕ) : ℝ) := Nat.cast_le.mpr hdeg
  rw [Nat.cast_sub hge] at hcast
  push_cast at hcast
  exact le_trans (crossAdj_rowSum_le n p) hcast

end Sovereign.Graph
