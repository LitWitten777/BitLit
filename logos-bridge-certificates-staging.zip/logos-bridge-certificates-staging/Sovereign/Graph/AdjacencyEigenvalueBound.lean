import Mathlib
import Sovereign.Graph.CrossHalfVertexDegree

namespace Sovereign.Graph

open Finset Matrix Sovereign

/-! ## 1. The degrees of the annihilation graph -/

/-- The degree of every vertex of the annihilation graph of dimension `Dₐ = 2ⁿ⁺¹` lies
between `8` and `Dₐ - 8`. -/
theorem crossDegree_bounds (n : Nat) (hn : 3 ≤ n) (s t : Bool) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    8 ≤ crossDegree n s t i j ∧ crossDegree n s t i j ≤ 2 ^ (n + 1) - 8 := by
  obtain ⟨hlow, hhigh⟩ := towerDegree_bounds n hn i j hi hj hi0 hj0 hij
  have hpow : (2 : Nat) ^ (n + 1) = 2 * 2 ^ n := by rw [pow_succ]; ring
  have hge : (8 : Nat) ≤ 2 ^ n := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  rw [crossDegree_eq_two_mul_towerDegree n s t i j hi hj hi0 hj0 hij]
  omega

/-! ## 2. The row-sum bound on eigenvalues -/

/-- **Row-sum bound.**  If `A · x = λ · x` for some non-zero `x`, and every row of `A` has
absolute sum at most `d`, then `|λ| ≤ d`. -/
theorem eigenvalue_abs_le_row_absSum {V : Type*} [Fintype V] [DecidableEq V]
    (A : Matrix V V ℝ) (d : ℝ) (hrow : ∀ i, ∑ j, |A i j| ≤ d)
    (lam : ℝ) (x : V → ℝ) (hx : x ≠ 0) (heig : A.mulVec x = lam • x) :
    |lam| ≤ d := by
  have hne : ∃ j, x j ≠ 0 := by
    by_contra h
    push_neg at h
    exact hx (funext h)
  obtain ⟨j0, hj0⟩ := hne
  obtain ⟨i, -, hi⟩ := Finset.exists_max_image (univ : Finset V) (fun j => |x j|)
    ⟨j0, mem_univ j0⟩
  have hpos : 0 < |x i| := lt_of_lt_of_le (abs_pos.mpr hj0) (hi j0 (mem_univ j0))
  have key : |lam| * |x i| ≤ d * |x i| := by
    have h1 : lam * x i = ∑ j, A i j * x j := by
      have hrow' := congrFun heig i
      simp [Matrix.mulVec, dotProduct] at hrow'
      linarith [hrow']
    calc |lam| * |x i| = |lam * x i| := (abs_mul _ _).symm
      _ = |∑ j, A i j * x j| := by rw [h1]
      _ ≤ ∑ j, |A i j * x j| := Finset.abs_sum_le_sum_abs _ _
      _ ≤ ∑ j, |A i j| * |x i| := by
          refine Finset.sum_le_sum fun j _ => ?_
          rw [abs_mul]
          exact mul_le_mul_of_nonneg_left (hi j (mem_univ j)) (abs_nonneg _)
      _ = (∑ j, |A i j|) * |x i| := by rw [Finset.sum_mul]
      _ ≤ d * |x i| := mul_le_mul_of_nonneg_right (hrow i) (le_of_lt hpos)
  exact le_of_mul_le_mul_right (by linarith) hpos

/-- The row-sum bound for a non-negative matrix, stated with the row sums themselves. -/
theorem eigenvalue_abs_le_rowSum_of_nonneg {V : Type*} [Fintype V] [DecidableEq V]
    (A : Matrix V V ℝ) (d : ℝ) (hnonneg : ∀ i j, 0 ≤ A i j) (hrow : ∀ i, ∑ j, A i j ≤ d)
    (lam : ℝ) (x : V → ℝ) (hx : x ≠ 0) (heig : A.mulVec x = lam • x) :
    |lam| ≤ d := by
  refine eigenvalue_abs_le_row_absSum A d (fun i => ?_) lam x hx heig
  calc ∑ j, |A i j| = ∑ j, A i j :=
        Finset.sum_congr rfl fun j _ => abs_of_nonneg (hnonneg i j)
    _ ≤ d := hrow i

/-! ## 3. The spectral bound of the annihilation graph -/

/-- **The spectral radius bound of the annihilation graph.**  Let `A` be a non-negative
matrix indexed by vertices `s eᵢ + t e_{2ⁿ+j}` of the annihilation graph of dimension
`Dₐ = 2ⁿ⁺¹`, whose row sums are the vertex degrees `crossDegree n s t i j` of that graph.
Then every real eigenvalue of `A` satisfies `|λ| ≤ Dₐ - 8`.

The constant is not tabulated: it comes from `crossDegree_bounds`, hence from the proved
vertex-degree law and the degree recursion. -/
theorem crossGraph_eigenvalue_abs_le {V : Type*} [Fintype V] [DecidableEq V]
    (n : Nat) (hn : 3 ≤ n) (sg tg : V → Bool) (ix jx : V → Nat)
    (hi : ∀ p, ix p < 2 ^ n) (hj : ∀ p, jx p < 2 ^ n)
    (hi0 : ∀ p, ix p ≠ 0) (hj0 : ∀ p, jx p ≠ 0) (hij : ∀ p, ix p ≠ jx p)
    (A : Matrix V V ℝ) (hnonneg : ∀ p q, 0 ≤ A p q)
    (hrow : ∀ p, ∑ q, A p q = (crossDegree n (sg p) (tg p) (ix p) (jx p) : ℝ))
    (lam : ℝ) (x : V → ℝ) (hx : x ≠ 0) (heig : A.mulVec x = lam • x) :
    |lam| ≤ 2 ^ (n + 1) - 8 := by
  have hge : (8 : Nat) ≤ 2 ^ (n + 1) := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ (n + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  refine eigenvalue_abs_le_rowSum_of_nonneg A _ hnonneg (fun p => ?_) lam x hx heig
  have hbound := (crossDegree_bounds n hn (sg p) (tg p) (ix p) (jx p) (hi p) (hj p) (hi0 p)
    (hj0 p) (hij p)).2
  have hcast : ((crossDegree n (sg p) (tg p) (ix p) (jx p) : ℕ) : ℝ) ≤ ((2 ^ (n + 1) - 8 : ℕ) : ℝ) :=
    Nat.cast_le.mpr hbound
  rw [hrow p]
  rw [Nat.cast_sub hge] at hcast
  push_cast at hcast ⊢
  linarith

end Sovereign.Graph
