import Mathlib
import Sovereign.Graph.CrossAdjacencyMatrix

namespace Sovereign.Graph

open Finset Matrix Sovereign

/-! ## 1. Sector Vertices -/

/-- An admissible cross-half vertex belongs to charge sector $\chi$ if $i \oplus j = \chi$. -/
def InSector (n χ : Nat) (p : admVertex n) : Prop :=
  (p.1.2.2.1 : Nat) ^^^ (p.1.2.2.2 : Nat) = χ

instance (n χ : Nat) : DecidablePred (InSector n χ) := fun p => by
  unfold InSector; infer_instance

/-- The vertices of the charge sector $\chi$ graph. -/
abbrev SectorVertex (n χ : Nat) : Type := {p : admVertex n // InSector n χ p}

/-! ## 2. Charge Conservation in Annihilation -/

/-- Cross-annihilation strictly requires identical XOR charges $i \oplus j = k \oplus m$. -/
theorem crossAnnihilates_charge_eq (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (h : crossAnnihilates n s t i j u r k m = true) :
    i ^^^ j = k ^^^ m := by
  dsimp [crossAnnihilates] at h
  simp only [Bool.and_eq_true, decide_eq_true_iff] at h
  exact h.1.1

/-- Annihilation between distinct charge sectors is impossible. -/
theorem crossAnnihilates_diff_sector_false (n : Nat) (s t u r : Bool) (i j k m : Nat)
    (h_diff : i ^^^ j ≠ k ^^^ m) :
    crossAnnihilates n s t i j u r k m = false := by
  cases h : crossAnnihilates n s t i j u r k m
  · rfl
  · exfalso
    have h_eq := crossAnnihilates_charge_eq n s t u r i j k m h
    exact h_diff h_eq

/-! ## 3. The Sector Adjacency Matrix -/

/-- The `{0,1}` adjacency matrix of the charge sector $\chi$ subgraph. -/
def sectorAdj (n χ : Nat) : Matrix (SectorVertex n χ) (SectorVertex n χ) ℝ := fun p q =>
  if crossAnnihilates n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2
                      q.1.1.1 q.1.1.2.1 q.1.1.2.2.1 q.1.1.2.2.2 = true
  then 1 else 0

/-- Every entry in the sector adjacency matrix is binary (0 or 1). -/
theorem sectorAdj_entry (n χ : Nat) (p q : SectorVertex n χ) :
    sectorAdj n χ p q = 0 ∨ sectorAdj n χ p q = 1 := by
  unfold sectorAdj
  split <;> [right; left] <;> rfl

/-- Every entry of `sectorAdj n χ` is non-negative. -/
theorem sectorAdj_nonneg (n χ : Nat) (p q : SectorVertex n χ) :
    0 ≤ sectorAdj n χ p q := by
  rcases sectorAdj_entry n χ p q with h0 | h1 <;> linarith

set_option maxHeartbeats 400000 in
/-- Row sum of the sector adjacency matrix is bounded by the vertex degree `crossDegree`. -/
theorem sectorAdj_rowSum_le (n χ : Nat) (p : SectorVertex n χ) :
    ∑ q : SectorVertex n χ, sectorAdj n χ p q
      ≤ crossDegree n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2 := by
  classical
  set f : crossVertex n → ℝ := fun q =>
    if crossAnnihilates n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2
                         q.1 q.2.1 q.2.2.1 q.2.2.2 = true then 1 else 0 with hf
  have hf_nn : ∀ q : crossVertex n, 0 ≤ f q := fun q => by
    simp only [hf]; split <;> norm_num
  rw [← sum_indicator_eq_crossDegree n p.1.1.1 p.1.1.2.1 p.1.1.2.2.1 p.1.1.2.2.2]
  have hlhs : ∑ q : SectorVertex n χ, sectorAdj n χ p q = ∑ q : SectorVertex n χ, f q.1.1 := rfl
  rw [hlhs]
  -- ·.1.1 : SectorVertex n χ → crossVertex n is injective (double subtype coercion)
  have hinj : Function.Injective (fun v : SectorVertex n χ => v.1.1) :=
    fun a b h => Subtype.val_inj.mp (Subtype.val_inj.mp h)
  -- rewrite as sum over image, which sits inside univ : Finset (crossVertex n)
  calc ∑ q : SectorVertex n χ, f q.1.1
      = ∑ q ∈ (Finset.univ : Finset (SectorVertex n χ)).image (fun v => v.1.1), f q :=
        (Finset.sum_image fun a _ b _ h => hinj h).symm
    _ ≤ ∑ q : crossVertex n, f q :=
        Finset.sum_le_sum_of_subset_of_nonneg (Finset.subset_univ _) fun q _ _ => hf_nn q

end Sovereign.Graph

