/-
Copyright (c) 2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# The equitable twin quotient of a charge sector and its zero modes (Track 1, `T2`)

Fix a level `n` (algebra dimension `Dₐ = 2ⁿ⁺¹`) and a charge `χ`.  The vertices of the charge
sector are the sign-decorated cross-half vectors `(s, t, i, j)` with `i ⊕ j = χ`
(`SectorVertex n χ`), and `sectorAdj n χ` is their `{0,1}` adjacency matrix.

## The twin classes

The annihilation condition for a vertex `(s, t, i, j)` depends on its signs only through
`s ⊕ t`, and swapping the index pair `(i, j) ↦ (j, i)` while flipping `s ⊕ t` does not change
it either (`crossAnnihilates_twin_swap`).  Consequently the sector splits into classes of
exactly four vertices with identical neighbourhoods (**true twins**), one class for each
ordered index pair `(a, b)` of the sector:

  `T(a, b) = {(s, t, a, b) : s ⊕ t = 0} ∪ {(s, t, b, a) : s ⊕ t = 1}`.

Note that the class of a vertex is *not* its set of four sign decorations: the decorations
`(s, t, i, j)` with `s ⊕ t = 0` and with `s ⊕ t = 1` generally have different neighbourhoods
(`sign_decorations_not_twins`).

## Results

* `twinClass`, `twinQuotient` — the class map and the `{0,1}` quotient matrix `B` indexed by
  the ordered index pairs of the sector (`SectorPair n χ`);
* `sectorAdj_eq_twinQuotient` — `A_{vw} = B_{[v][w]}`: the partition is equitable, with every
  class of size `4` (`card_twinClass_fiber`);
* `sectorAdj_eq_mul` — the factorisation `A = P B Pᵀ` with `Pᵀ P = 4 I`;
* `sectorAdj_charpoly` — **the characteristic polynomial identity**
  `det(X I - A) = X^{3 b} det(X I - 4 B)` with `b = #SectorPair n χ`;
* `sectorAdj_rank_le`, `sectorAdj_nullity_ge` — `rank A ≤ b` and `dim ker A ≥ 3 b`;
* `card_sectorPair` — for a non-trivial charge `0 < χ < 2ⁿ`, `b = 2ⁿ - 2 = (Dₐ - 4)/2`,
  which is `baseOrder Dₐ`.  So in every dimension the sector has `4 b` vertices and at least
  `3 b` zero modes, and its non-zero spectrum is that of the `b × b` matrix `4 B`.
-/

import Mathlib
import Sovereign.Graph.SectorAdjacencyExact
import Sovereign.Graph.BaseGraphQuotient

namespace Sovereign.Graph

open Finset Matrix Sovereign Polynomial

/-! ## 1. Two sign identities for the annihilation test -/

/-- The annihilation test depends on the signs `s, t` of the first vertex only through
`s ⊕ t`. -/
theorem crossAnnihilates_sign_xor (n : Nat) (s t s' t' u r : Bool) (i j k m : Nat)
    (h : xor s t = xor s' t') :
    crossAnnihilates n s t i j u r k m = crossAnnihilates n s' t' i j u r k m := by
  unfold crossAnnihilates
  generalize decide (i ^^^ j = k ^^^ m) = c
  generalize epsNeg (n + 1) i k = e1
  generalize epsNeg (n + 1) (2 ^ n + j) (2 ^ n + m) = e2
  generalize epsNeg (n + 1) i (2 ^ n + m) = e3
  generalize epsNeg (n + 1) (2 ^ n + j) k = e4
  revert h
  decide +revert

/-- The Boolean core of the twin swap. -/
theorem twin_swap_bool (s t s' t' u r c X Y Z W : Bool) (h : xor s t ≠ xor s' t') :
    (c && decide (xor s (xor u X) ≠ xor t (xor r (!(xor true Z)))) &&
        decide (xor s (xor r Y) ≠ xor t (xor u (xor true W))))
      = (c && decide (xor s' (xor u W) ≠ xor t' (xor r (!(xor true Y)))) &&
        decide (xor s' (xor r Z) ≠ xor t' (xor u (xor true X)))) := by
  revert h
  decide +revert

/-- **The twin swap.**  Against every partner with non-zero indices, the vertex
`(s, t, i, j)` has the same annihilation behaviour as `(s', t', j, i)` whenever
`s ⊕ t ≠ s' ⊕ t'`. -/
theorem crossAnnihilates_twin_swap (n : Nat) (s t s' t' u r : Bool) (i j k m : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hk : k < 2 ^ n) (hk0 : k ≠ 0) (hm0 : m ≠ 0)
    (h : xor s t ≠ xor s' t') :
    crossAnnihilates n s t i j u r k m = crossAnnihilates n s' t' j i u r k m := by
  unfold crossAnnihilates
  rw [Nat.xor_comm j i, epsNeg_succ_low_low n i k hi hk, epsNeg_succ_high_high n j m,
    epsNeg_succ_low_high n i m hi, epsNeg_succ_high_low n j k hk,
    epsNeg_succ_low_low n j k hj hk, epsNeg_succ_high_high n i m,
    epsNeg_succ_low_high n j m hj, epsNeg_succ_high_low n i k hk]
  have hck : conjNeg k = true := by simp [conjNeg, hk0]
  have hcm : conjNeg m = true := by simp [conjNeg, hm0]
  rw [hck, hcm]
  exact twin_swap_bool s t s' t' u r _ _ _ _ _ h

/-! ## 2. Index pairs of a sector -/

/-- An ordered index pair `(a, b)` of the charge sector `χ`. -/
def IsSectorPair (n χ : Nat) (q : Fin (2 ^ n) × Fin (2 ^ n)) : Prop :=
  (q.1 : Nat) ≠ 0 ∧ (q.2 : Nat) ≠ 0 ∧ (q.1 : Nat) ≠ q.2 ∧ (q.1 : Nat) ^^^ (q.2 : Nat) = χ

instance (n χ : Nat) : DecidablePred (IsSectorPair n χ) := fun q => by
  unfold IsSectorPair; infer_instance

/-- The ordered index pairs of the charge sector `χ`: the twin classes. -/
abbrev SectorPair (n χ : Nat) : Type := {q : Fin (2 ^ n) × Fin (2 ^ n) // IsSectorPair n χ q}

/-- Reversing an index pair. -/
def SectorPair.swap {n χ : Nat} (c : SectorPair n χ) : SectorPair n χ :=
  ⟨(c.1.2, c.1.1), c.2.2.1, c.2.1, fun h => c.2.2.2.1 h.symm,
    by rw [Nat.xor_comm]; exact c.2.2.2.2⟩

@[simp] theorem SectorPair.swap_swap {n χ : Nat} (c : SectorPair n χ) : c.swap.swap = c := rfl

/-- The vertex `(s, t, a, b)` over the index pair `(a, b)`. -/
def pairVertex {n χ : Nat} (c : SectorPair n χ) (s t : Bool) : SectorVertex n χ :=
  ⟨⟨(s, t, c.1.1, c.1.2), c.2.1, c.2.2.1, c.2.2.2.1⟩, c.2.2.2.2⟩

/-- The index pair of a vertex. -/
def vertexPair {n χ : Nat} (v : SectorVertex n χ) : SectorPair n χ :=
  ⟨(v.1.1.2.2.1, v.1.1.2.2.2), v.1.2.1, v.1.2.2.1, v.1.2.2.2, v.2⟩

/-! ## 3. The twin classes -/

/-- The twin class of a vertex `(s, t, i, j)`: the pair `(i, j)` if `s ⊕ t = 0`, and `(j, i)`
otherwise. -/
def twinClass {n χ : Nat} (v : SectorVertex n χ) : SectorPair n χ :=
  if xor v.1.1.1 v.1.1.2.1 = true then (vertexPair v).swap else vertexPair v

/-- The `k`-th member of a twin class, `k = (s, t)`. -/
def twinMember {n χ : Nat} (c : SectorPair n χ) (s t : Bool) : SectorVertex n χ :=
  if xor s t = true then pairVertex c.swap s t else pairVertex c s t

/-- The representative `(0, 0, a, b)` of the class of `(a, b)`. -/
def twinRep {n χ : Nat} (c : SectorPair n χ) : SectorVertex n χ := pairVertex c false false

theorem twinMember_signs {n χ : Nat} (c : SectorPair n χ) (s t : Bool) :
    (twinMember c s t).1.1.1 = s ∧ (twinMember c s t).1.1.2.1 = t := by
  unfold twinMember; split <;> exact ⟨rfl, rfl⟩

theorem twinClass_twinMember {n χ : Nat} (c : SectorPair n χ) (s t : Bool) :
    twinClass (twinMember c s t) = c := by
  unfold twinClass twinMember
  by_cases h : xor s t = true
  · simp only [h, if_true]
    dsimp only [pairVertex]
    simp only [h, if_true]
    rfl
  · simp only [h, if_false, Bool.false_eq_true]
    dsimp only [pairVertex]
    simp only [h, if_false, Bool.false_eq_true]
    rfl

theorem twinMember_twinClass {n χ : Nat} (v : SectorVertex n χ) :
    twinMember (twinClass v) v.1.1.1 v.1.1.2.1 = v := by
  unfold twinClass twinMember
  by_cases h : xor v.1.1.1 v.1.1.2.1 = true
  · simp only [h, if_true, SectorPair.swap_swap]
    rfl
  · simp only [h, if_false, Bool.false_eq_true]
    rfl

theorem twinClass_twinRep {n χ : Nat} (c : SectorPair n χ) : twinClass (twinRep c) = c :=
  twinClass_twinMember c false false

/-- A sector vertex is determined by its twin class and its two signs. -/
def twinEquiv (n χ : Nat) : SectorVertex n χ ≃ SectorPair n χ × (Bool × Bool) where
  toFun v := (twinClass v, (v.1.1.1, v.1.1.2.1))
  invFun p := twinMember p.1 p.2.1 p.2.2
  left_inv v := twinMember_twinClass v
  right_inv p := by
    obtain ⟨c, s, t⟩ := p
    obtain ⟨h1, h2⟩ := twinMember_signs c s t
    simp only [twinClass_twinMember, h1, h2]

/-- **Every twin class has exactly four vertices.** -/
theorem card_twinClass_fiber (n χ : Nat) (c : SectorPair n χ) :
    (Finset.univ.filter (fun v : SectorVertex n χ => twinClass v = c)).card = 4 := by
  classical
  rw [← Finset.card_map (twinEquiv n χ).toEmbedding]
  have : (Finset.univ.filter (fun v : SectorVertex n χ => twinClass v = c)).map
      (twinEquiv n χ).toEmbedding = ({c} : Finset (SectorPair n χ)) ×ˢ Finset.univ := by
    ext ⟨d, st⟩
    simp only [Finset.mem_map_equiv, Finset.mem_filter, Finset.mem_univ, true_and,
      Finset.mem_product, Finset.mem_singleton, and_true]
    constructor
    · intro h
      exact (twinClass_twinMember d st.1 st.2).symm.trans h
    · rintro rfl
      exact twinClass_twinMember d st.1 st.2
  rw [this, Finset.card_product]
  simp

/-- **The sector has four times as many vertices as index pairs.** -/
theorem card_sectorVertex (n χ : Nat) :
    Fintype.card (SectorVertex n χ) = 4 * Fintype.card (SectorPair n χ) := by
  rw [Fintype.card_congr (twinEquiv n χ), Fintype.card_prod, Fintype.card_prod,
    Fintype.card_bool]
  ring

/-! ## 4. Twins have identical rows -/

/-- Every vertex has the same row of the adjacency matrix as the representative of its twin
class. -/
theorem sectorAdj_twinRep_left (n χ : Nat) (v w : SectorVertex n χ) :
    sectorAdj n χ v w = sectorAdj n χ (twinRep (twinClass v)) w := by
  unfold sectorAdj
  congr 2
  unfold twinClass twinRep pairVertex
  by_cases h : xor v.1.1.1 v.1.1.2.1 = true
  · simp only [h, if_true]
    exact crossAnnihilates_twin_swap n _ _ false false _ _ _ _ _ _ v.1.1.2.2.1.isLt
      v.1.1.2.2.2.isLt w.1.1.2.2.1.isLt w.1.2.1 w.1.2.2.1 (by rw [h]; decide)
  · simp only [h, if_false, Bool.false_eq_true]
    exact crossAnnihilates_sign_xor n _ _ false false _ _ _ _ _ _ (by simpa using h)

/-- The quotient matrix `B` of the twin partition: `B_{cd}` is the adjacency between the
representatives of the classes `c` and `d`. -/
noncomputable def twinQuotient (n χ : Nat) : Matrix (SectorPair n χ) (SectorPair n χ) ℝ :=
  fun c d => sectorAdj n χ (twinRep c) (twinRep d)

/-- **The twin partition is equitable**: the adjacency between two vertices depends only on
their twin classes, `A_{vw} = B_{[v][w]}`. -/
theorem sectorAdj_eq_twinQuotient (n χ : Nat) (v w : SectorVertex n χ) :
    sectorAdj n χ v w = twinQuotient n χ (twinClass v) (twinClass w) := by
  have hs := sectorAdj_isSymm n χ
  rw [sectorAdj_twinRep_left, ← hs.apply, sectorAdj_twinRep_left, ← hs.apply]
  rfl

/-- The quotient matrix is symmetric. -/
theorem twinQuotient_isSymm (n χ : Nat) : (twinQuotient n χ).IsSymm :=
  Matrix.IsSymm.ext fun c d => (sectorAdj_isSymm n χ).apply (twinRep c) (twinRep d)

/-- Every entry of the quotient matrix is `0` or `1`. -/
theorem twinQuotient_entry (n χ : Nat) (c d : SectorPair n χ) :
    twinQuotient n χ c d = 0 ∨ twinQuotient n χ c d = 1 :=
  sectorAdj_entry n χ (twinRep c) (twinRep d)

/-! ## 5. The factorisation `A = P B Pᵀ` -/

/-- The incidence matrix of the twin partition. -/
noncomputable def twinIncidence (n χ : Nat) : Matrix (SectorVertex n χ) (SectorPair n χ) ℝ :=
  fun v c => if twinClass v = c then 1 else 0

/-- `Pᵀ P = 4 I`: the classes are disjoint and have four vertices each. -/
theorem twinIncidence_transpose_mul (n χ : Nat) :
    (twinIncidence n χ)ᵀ * twinIncidence n χ = (4 : ℝ) • (1 : Matrix _ _ ℝ) := by
  classical
  ext c d
  simp only [Matrix.mul_apply, Matrix.transpose_apply, twinIncidence, Matrix.smul_apply,
    Matrix.one_apply, smul_eq_mul, mul_ite, mul_one, mul_zero]
  by_cases hcd : c = d
  · subst hcd
    have hx : ∀ v : SectorVertex n χ, (if twinClass v = c then
        (if twinClass v = c then (1 : ℝ) else 0) else 0) = if twinClass v = c then 1 else 0 :=
      fun v => by split_ifs <;> rfl
    simp only [if_true, hx]
    rw [Finset.sum_boole, card_twinClass_fiber]
    norm_num
  · simp only [if_neg hcd]
    refine Finset.sum_eq_zero fun v _ => ?_
    split_ifs with h1 h2
    · exact absurd (h2.symm.trans h1) hcd
    · rfl
    · rfl

/-- **The factorisation `A = P B Pᵀ`** of the sector adjacency matrix through its twin
quotient. -/
theorem sectorAdj_eq_mul (n χ : Nat) :
    sectorAdj n χ = twinIncidence n χ * twinQuotient n χ * (twinIncidence n χ)ᵀ := by
  classical
  ext v w
  simp only [Matrix.mul_apply, Matrix.transpose_apply, twinIncidence, ite_mul, one_mul,
    zero_mul, mul_ite, mul_one, mul_zero]
  simp only [Finset.sum_ite_eq, Finset.mem_univ, if_true]
  exact sectorAdj_eq_twinQuotient n χ v w

/-! ## 6. The characteristic polynomial and the zero modes -/

/-- **The characteristic polynomial of a charge sector** factors through its twin quotient:
`det(X I - A) = X^{3b} · det(X I - 4 B)`, where `b` is the number of index pairs of the
sector.  Hence the non-zero spectrum of the sector is exactly that of the `b × b` matrix
`4 B`, and `0` has algebraic multiplicity at least `3 b`. -/
theorem sectorAdj_charpoly (n χ : Nat) :
    (sectorAdj n χ).charpoly
      = X ^ (3 * Fintype.card (SectorPair n χ)) * ((4 : ℝ) • twinQuotient n χ).charpoly := by
  have h := charpoly_mul_comm' (twinIncidence n χ) (twinQuotient n χ * (twinIncidence n χ)ᵀ)
  have hBA : twinQuotient n χ * (twinIncidence n χ)ᵀ * twinIncidence n χ
      = (4 : ℝ) • twinQuotient n χ := by
    rw [Matrix.mul_assoc, twinIncidence_transpose_mul, Matrix.mul_smul, Matrix.mul_one]
  rw [← Matrix.mul_assoc, ← sectorAdj_eq_mul, hBA, card_sectorVertex,
    show 4 * Fintype.card (SectorPair n χ)
      = Fintype.card (SectorPair n χ) + 3 * Fintype.card (SectorPair n χ) by ring,
    pow_add, mul_assoc] at h
  exact (isRegular_X_pow _).left.eq_iff.mp h

/-- The rank of the sector adjacency matrix is at most the number of twin classes. -/
theorem sectorAdj_rank_le (n χ : Nat) :
    (sectorAdj n χ).rank ≤ Fintype.card (SectorPair n χ) := by
  rw [sectorAdj_eq_mul, Matrix.mul_assoc]
  exact (Matrix.rank_mul_le_left _ _).trans (Matrix.rank_le_card_width _)

/-- **Zero modes.**  The kernel of the sector adjacency matrix has dimension at least three
times the number of twin classes. -/
theorem sectorAdj_nullity_ge (n χ : Nat) :
    3 * Fintype.card (SectorPair n χ)
      ≤ Module.finrank ℝ (LinearMap.ker (sectorAdj n χ).mulVecLin) := by
  have hrn := LinearMap.finrank_range_add_finrank_ker (sectorAdj n χ).mulVecLin
  have hr := sectorAdj_rank_le n χ
  rw [Matrix.rank] at hr
  rw [Module.finrank_fintype_fun_eq_card, card_sectorVertex] at hrn
  omega

/-! ## 7. The number of twin classes -/

/-- The admissible first indices `a ∉ {0, χ}` of the charge sector `χ`. -/
abbrev AdmIndex (n χ : Nat) : Type := {a : Fin (2 ^ n) // (a : Nat) ≠ 0 ∧ (a : Nat) ≠ χ}

/-- For a non-trivial charge, an index pair of the sector is determined by its first index:
the second index is forced to be `a ⊕ χ`. -/
def sectorPairEquiv (n χ : Nat) (hχ0 : χ ≠ 0) (hχ : χ < 2 ^ n) :
    SectorPair n χ ≃ AdmIndex n χ :=
  { toFun := fun c => ⟨c.1.1, c.2.1, fun h => by
      have := congrArg (fun x => χ ^^^ x) c.2.2.2.2
      simp only [h, ← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor] at this
      exact c.2.2.1 this⟩
    invFun := fun a => ⟨(a.1, ⟨(a.1 : Nat) ^^^ χ, Nat.xor_lt_two_pow a.1.isLt hχ⟩),
      a.2.1, fun h => a.2.2 (Nat.xor_eq_zero_iff.mp h),
      fun h => hχ0 (by simpa using congrArg (fun x => (a.1 : Nat) ^^^ x) h.symm),
      by simp⟩
    left_inv := fun c => by
      apply Subtype.ext
      refine Prod.ext rfl (Fin.ext ?_)
      show (c.1.1 : Nat) ^^^ χ = c.1.2
      have hc : (c.1.1 : Nat) ^^^ (c.1.2 : Nat) = χ := c.2.2.2.2
      calc (c.1.1 : Nat) ^^^ χ = (c.1.1 : Nat) ^^^ ((c.1.1 : Nat) ^^^ (c.1.2 : Nat)) := by
            rw [hc]
        _ = c.1.2 := by rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
    right_inv := fun a => rfl }

@[simp] theorem sectorPairEquiv_apply_val (n χ : Nat) (hχ0 : χ ≠ 0) (hχ : χ < 2 ^ n)
    (c : SectorPair n χ) : ((sectorPairEquiv n χ hχ0 hχ c : AdmIndex n χ) : Fin (2 ^ n)) = c.1.1 :=
  rfl

/-- For a non-trivial charge `0 < χ < 2ⁿ` the sector has `2ⁿ - 2` index pairs: the first
index is any `a ∉ {0, χ}` and the second is forced to be `a ⊕ χ`. -/
theorem card_sectorPair (n χ : Nat) (hχ0 : χ ≠ 0) (hχ : χ < 2 ^ n) :
    Fintype.card (SectorPair n χ) = 2 ^ n - 2 := by
  classical
  let e := sectorPairEquiv n χ hχ0 hχ
  rw [Fintype.card_congr e, Fintype.card_subtype]
  have hset : (Finset.univ.filter fun a : Fin (2 ^ n) => (a : Nat) ≠ 0 ∧ (a : Nat) ≠ χ)
      = Finset.univ \ {⟨0, by positivity⟩, ⟨χ, hχ⟩} := by
    ext a
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Finset.mem_sdiff,
      Finset.mem_insert, Finset.mem_singleton, not_or, Fin.ext_iff]
  rw [hset, Finset.card_sdiff, Finset.card_univ, Fintype.card_fin, Finset.inter_univ, Finset.card_pair]
  · simp
    exact hχ0

/-- The number of twin classes of a non-trivial sector is `baseOrder Dₐ = (Dₐ - 4)/2`, where
`Dₐ = 2ⁿ⁺¹` is the dimension of the algebra. -/
theorem card_sectorPair_eq_baseOrder (n χ : Nat) (hχ0 : χ ≠ 0) (hχ : χ < 2 ^ n) :
    Fintype.card (SectorPair n χ) = baseOrder (2 ^ (n + 1)) := by
  rw [card_sectorPair n χ hχ0 hχ, baseOrder, pow_succ]
  omega

/-- **Milestone T2: the twin-quotient identity in every dimension.**  For every level `n` and
every non-trivial charge `0 < χ < 2ⁿ`, with `Dₐ = 2ⁿ⁺¹`,
`det(X I - A_χ) = X^{3 · baseOrder Dₐ} · det(X I - 4 B_χ)`, and `dim ker A_χ ≥ 3 · baseOrder Dₐ`. -/
theorem sectorAdj_twin_quotient_spectrum (n χ : Nat) (hχ0 : χ ≠ 0) (hχ : χ < 2 ^ n) :
    (sectorAdj n χ).charpoly
        = X ^ (3 * baseOrder (2 ^ (n + 1))) * ((4 : ℝ) • twinQuotient n χ).charpoly ∧
      3 * baseOrder (2 ^ (n + 1))
        ≤ Module.finrank ℝ (LinearMap.ker (sectorAdj n χ).mulVecLin) := by
  rw [← card_sectorPair_eq_baseOrder n χ hχ0 hχ]
  exact ⟨sectorAdj_charpoly n χ, sectorAdj_nullity_ge n χ⟩

/-! ## 8. The sign decorations of an index pair are not twins -/

/-- The four sign decorations of one index pair do **not** in general share their
neighbourhoods: in the sedenions (`n = 3`), `e₂ + e₁₁` and `e₂ - e₁₁` (charge `1`) have
different neighbours, e.g. the partner `e₄ + e₁₃`.  (Contrast the twin classes above.) -/
theorem sign_decorations_not_twins :
    crossAnnihilates 3 false false 2 3 false false 4 5
      ≠ crossAnnihilates 3 false true 2 3 false false 4 5 := by
  decide

end Sovereign.Graph
