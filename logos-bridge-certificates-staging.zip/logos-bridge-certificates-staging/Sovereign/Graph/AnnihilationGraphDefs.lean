/-
Copyright (c) 2024-2026 Sovereign Engine Project. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.

# Definitions for the sector-structure analysis of the annihilation graph

The theorems built on these definitions are in `Sovereign.Graph.AnnihilationGraph`.

The tables `sectorVertices` and `sectorClasses` are *constants* (no arguments), so that
the exact evaluation of the theorems in `Sovereign.Graph.AnnihilationGraph` computes them
once instead of once per quantified variable.
-/

import Sovereign.Algebra.SedenionStratification

namespace Sovereign

/-- Adjacency of two labelled cross-octet vectors. -/
def labelAdj (p q : CrossLabel) : Bool := annihilates (labelVec p) (labelVec q)

/-- The 168 labels of cross-octet zero divisors. -/
def zdLabels : List CrossLabel := crossLabels.filter fun p => isZeroDivisorIndex p.1 p.2.1

/-- The annihilators of `p` among the zero divisors. -/
def nbhd (p : CrossLabel) : List CrossLabel := zdLabels.filter (labelAdj p)

/-- The classes of vertices of the sector `c` having the same neighbourhood ("twins"). -/
def twinClasses (c : Nat) : List (List CrossLabel) :=
  ((chargeSector c).map fun p => (chargeSector c).filter fun q => nbhd q == nbhd p).eraseDups

/-- Indices of the twin classes adjacent to the class number `a`. -/
def classNbrs (cls : List (List CrossLabel)) (a : Nat) : List Nat :=
  (List.range cls.length).filter fun b =>
    (cls[b]!).any fun q => (cls[a]!).any fun p => labelAdj p q

/-- Greedy walk through the quotient graph, used to order the twin classes cyclically. -/
def walkAux (cls : List (List CrossLabel)) : Nat → Nat → List Nat → List Nat
  | 0, _, acc => acc.reverse
  | fuel + 1, cur, acc =>
    match (classNbrs cls cur).find? fun x => !(acc.contains x) with
    | some nxt => walkAux cls fuel nxt (nxt :: acc)
    | none => acc.reverse

/-- The twin classes of the sector `c`, ordered along the quotient 6-cycle. -/
def cycleClasses (c : Nat) : List (List CrossLabel) :=
  let cls := twinClasses c
  (walkAux cls 5 0 [0]).map fun a => cls[a]!

/-- The seven non-zero XOR charges. -/
def charges : List Nat := [1, 2, 3, 4, 5, 6, 7]

/-- `sectorVertices[k]` is the list of the 24 zero divisors of charge `k + 1`. -/
def sectorVertices : List (List CrossLabel) := charges.map chargeSector

/-- `sectorClasses[k]` is the list of the 6 twin classes of the sector of charge `k + 1`,
in cyclic order along the quotient hexagon. -/
def sectorClasses : List (List (List CrossLabel)) := charges.map cycleClasses

/-- Position of a vertex on the quotient hexagon of its sector. -/
def posIn (cls : List (List CrossLabel)) (p : CrossLabel) : Nat :=
  cls.findIdx fun cl => cl.contains p

end Sovereign
