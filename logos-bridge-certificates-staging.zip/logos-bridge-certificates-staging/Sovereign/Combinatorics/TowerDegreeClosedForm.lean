import Sovereign.Combinatorics.TowerDegreeFormula

namespace Sovereign

open Finset

/-! ## 1. Reading the degree recursion one doubling step at a time

The following unfoldings of `towerDegree` are the four doubling laws in the form needed
below; `towerDegree_comm` records that the degree does not depend on the order of the outer
pair. -/

theorem towerDegree_low_low (m i j : Nat) (hi : i < 2 ^ m) (hj : j < 2 ^ m) :
    towerDegree (m + 1) i j = 2 * towerDegree m i j + 4 := by
  rw [towerDegree]
  simp only [if_pos hi, if_pos hj]

theorem towerDegree_low_high_deg (m i c : Nat) (hi : i < 2 ^ m) (h : c = 0 ∨ c = i) :
    towerDegree (m + 1) i (2 ^ m + c) = 2 ^ (m + 1) - 4 := by
  rw [towerDegree]
  simp only [if_pos hi, if_neg (show ¬ 2 ^ m + c < 2 ^ m by omega), Nat.add_sub_cancel_left,
    if_pos h]

theorem towerDegree_low_high (m i c : Nat) (hi : i < 2 ^ m) (hc0 : c ≠ 0) (hci : c ≠ i) :
    towerDegree (m + 1) i (2 ^ m + c) = 2 ^ (m + 1) - (2 * towerDegree m i c + 4) := by
  rw [towerDegree]
  simp only [if_pos hi, if_neg (show ¬ 2 ^ m + c < 2 ^ m by omega), Nat.add_sub_cancel_left,
    if_neg (show ¬ (c = 0 ∨ c = i) by tauto)]

theorem towerDegree_high_low_deg (m a j : Nat) (hj : j < 2 ^ m) (h : a = 0 ∨ a = j) :
    towerDegree (m + 1) (2 ^ m + a) j = 2 ^ (m + 1) - 4 := by
  rw [towerDegree]
  simp only [if_neg (show ¬ 2 ^ m + a < 2 ^ m by omega), if_pos hj, Nat.add_sub_cancel_left,
    if_pos h]

theorem towerDegree_high_low (m a j : Nat) (hj : j < 2 ^ m) (ha0 : a ≠ 0) (haj : a ≠ j) :
    towerDegree (m + 1) (2 ^ m + a) j = 2 ^ (m + 1) - (2 * towerDegree m j a + 4) := by
  rw [towerDegree]
  simp only [if_neg (show ¬ 2 ^ m + a < 2 ^ m by omega), if_pos hj, Nat.add_sub_cancel_left,
    if_neg (show ¬ (a = 0 ∨ a = j) by tauto)]

theorem towerDegree_high_high_deg (m a c : Nat) (h : a = 0 ∨ c = 0) :
    towerDegree (m + 1) (2 ^ m + a) (2 ^ m + c) = 2 ^ (m + 1) - 4 := by
  rw [towerDegree]
  simp only [if_neg (show ¬ 2 ^ m + a < 2 ^ m by omega),
    if_neg (show ¬ 2 ^ m + c < 2 ^ m by omega), Nat.add_sub_cancel_left, if_pos h]

theorem towerDegree_high_high (m a c : Nat) (ha0 : a ≠ 0) (hc0 : c ≠ 0) :
    towerDegree (m + 1) (2 ^ m + a) (2 ^ m + c) = 2 * towerDegree m a c + 4 := by
  rw [towerDegree]
  simp only [if_neg (show ¬ 2 ^ m + a < 2 ^ m by omega),
    if_neg (show ¬ 2 ^ m + c < 2 ^ m by omega), Nat.add_sub_cancel_left,
    if_neg (show ¬ (a = 0 ∨ c = 0) by tauto)]

/-- The degree of an admissible pair is symmetric in the two outer indices. -/
theorem towerDegree_comm (n i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) : towerDegree n i j = towerDegree n j i := by
  rw [← nonassocMiddles_card_eq_towerDegree n i j hi hj hi0 hj0 hij,
    ← nonassocMiddles_card_eq_towerDegree n j i hj hi hj0 hi0 (Ne.symm hij),
    nonassocMiddles_card_reverse n i j hi hj]

theorem towerDegree_dim8 (i j : Nat) (hi : i < 8) (hj : j < 8) (hi0 : i ≠ 0) (hj0 : j ≠ 0)
    (hij : i ≠ j) : towerDegree 3 i j = 4 := by
  rw [← nonassocMiddles_card_eq_towerDegree 3 i j (by norm_num; omega) (by norm_num; omega)
    hi0 hj0 hij]
  exact Sovereign.annihilation_graph_regular_dim16 i j hi hj hi0 hj0 hij

/-! ## 2. The closed form -/

/-- The level at which the degree descent degenerates.  Going down from level `n`, the
descent stops at the first level `ℓ` at which the truncated pair
`(i mod 2^ℓ, j mod 2^ℓ)` has one of the three extremal shapes: one of the two indices is
the new unit `2^(ℓ-1)`, or the two indices are diagonal (they differ exactly by
`2^(ℓ-1)`).  If no such level exists the descent runs all the way down to the octonionic
base level `3`. -/
def stopLevel : Nat → Nat → Nat → Nat
  | 0, _, _ => 3
  | m + 1, i, j =>
    if m < 3 then 3
    else if i = 2 ^ m ∨ j = 2 ^ m ∨ i ^^^ j = 2 ^ m then m + 1
    else stopLevel m (i % 2 ^ m) (j % 2 ^ m)

theorem stopLevel_base (n i j : Nat) (hn : n ≤ 3) : stopLevel n i j = 3 := by
  match n with
  | 0 => rfl
  | m + 1 =>
      rw [stopLevel]
      simp only [if_pos (show m < 3 by omega)]

theorem stopLevel_ge (n i j : Nat) : 3 ≤ stopLevel n i j := by
  induction n generalizing i j with
  | zero => simp [stopLevel]
  | succ m ih =>
      rw [stopLevel]
      split
      · omega
      · split
        · omega
        · exact ih _ _

theorem stopLevel_le (n i j : Nat) (hn : 3 ≤ n) : stopLevel n i j ≤ n := by
  induction n generalizing i j with
  | zero => omega
  | succ m ih =>
      rw [stopLevel]
      split
      · omega
      · split
        · omega
        · rcases Nat.lt_or_ge m 3 with hm | hm
          · omega
          · exact le_trans (ih _ _ hm) (Nat.le_succ m)

/-- The number of set bits of `d` in the window `[l, n)`. -/
def hiPop (d l n : Nat) : Nat := ((Finset.Ico l n).filter (fun t => d.testBit t)).card

/-- The alternating dyadic sum carried by the set bits of `d` in the window `[L, n)`. -/
def altSum (d L n : Nat) : ℤ :=
  (-1) ^ hiPop d L n * 2 ^ (n - 1)
    + 8 * ∑ l ∈ (Finset.Ico L n).filter (fun t => d.testBit t),
        (-1) ^ hiPop d (l + 1) n * 2 ^ (n - 1 - l)

/-- **The closed form of the degree.**  Above the stop level the degree is a single
alternating dyadic sum over the set bits of `d = i ⊕ j`: each set bit at position `l`
contributes `± 8 · 2^(n-1-l)`, the sign being the parity of the number of set bits strictly
above `l`, and the leading term `± 2^(n-1)` carries the parity of the whole window. -/
def degreeClosed (n i j : Nat) : ℤ :=
  2 ^ (n - 1) - 4 + altSum (i ^^^ j) (stopLevel n i j) n

/-! ### Elementary properties of the window statistics -/

theorem hiPop_self (d l : Nat) : hiPop d l l = 0 := by
  simp [hiPop]

theorem hiPop_succ (d l m : Nat) (hl : l ≤ m) :
    hiPop d l (m + 1) = hiPop d l m + (if d.testBit m then 1 else 0) := by
  classical
  unfold hiPop
  rw [Nat.Ico_succ_right_eq_insert_Ico hl, Finset.filter_insert]
  by_cases hb : d.testBit m
  · rw [if_pos hb, Finset.card_insert_of_notMem (by simp), if_pos hb]
  · rw [if_neg hb, if_neg hb, Nat.add_zero]

theorem altSum_of_empty (d L : Nat) : altSum d L L = 2 ^ (L - 1) := by
  simp [altSum, hiPop_self]

/-- **The doubling law for the alternating sum.**  Extending the window by one bit either
doubles the sum (bit clear) or reflects it (bit set). -/
theorem altSum_succ (d L m : Nat) (hL : L ≤ m) (hm : 1 ≤ m) :
    altSum d L (m + 1) =
      if d.testBit m then 8 - 2 * altSum d L m else 2 * altSum d L m := by
  classical
  have hins := Nat.Ico_succ_right_eq_insert_Ico (a := L) (b := m) hL
  have hpowsucc : (m + 1) - 1 = m := by omega
  -- the leading exponent
  have hlead : hiPop d L (m + 1) = hiPop d L m + (if d.testBit m then 1 else 0) :=
    hiPop_succ d L m hL
  -- the tail terms
  have hterm : ∀ l ∈ (Finset.Ico L m).filter (fun t => d.testBit t),
      ((-1 : ℤ)) ^ hiPop d (l + 1) (m + 1) * 2 ^ (m - l)
        = (if d.testBit m then (-1 : ℤ) else 1) *
            (2 * ((-1 : ℤ) ^ hiPop d (l + 1) m * 2 ^ (m - 1 - l))) := by
    intro l hl
    rw [Finset.mem_filter, Finset.mem_Ico] at hl
    obtain ⟨hl, -⟩ := hl
    have hl1 : l + 1 ≤ m := by omega
    rw [hiPop_succ d (l + 1) m hl1]
    have hexp : m - l = (m - 1 - l) + 1 := by omega
    by_cases hb : d.testBit m
    · rw [if_pos hb, if_pos hb, hexp, pow_succ, pow_succ]
      ring
    · rw [if_neg hb, if_neg hb, hexp, pow_succ, pow_add, pow_zero]
      ring
  rw [altSum, altSum, hins, Finset.filter_insert]
  by_cases hb : d.testBit m
  · rw [if_pos hb, Finset.sum_insert (by simp), hlead, if_pos hb, if_pos hb, hpowsucc]
    rw [Finset.sum_congr rfl hterm, ← Finset.mul_sum, ← Finset.mul_sum]
    have hz : hiPop d (m + 1) (m + 1) = 0 := hiPop_self d (m + 1)
    rw [hz]
    simp only [pow_zero, Nat.sub_self, one_mul, if_pos hb]
    have h2 : (2 : ℤ) ^ m = 2 * 2 ^ (m - 1) := by
      rw [← pow_succ']
      congr 1
      omega
    rw [h2, pow_succ]
    ring
  · rw [if_neg hb, hlead, if_neg hb, if_neg hb, hpowsucc, Nat.add_zero]
    rw [Finset.sum_congr rfl hterm, ← Finset.mul_sum, ← Finset.mul_sum]
    have h2 : (2 : ℤ) ^ m = 2 * 2 ^ (m - 1) := by
      rw [← pow_succ']
      congr 1
      omega
    rw [h2]
    simp only [if_neg hb]
    ring

/-- The alternating sum only depends on the bits inside its window. -/
theorem altSum_congr (d d' L n : Nat)
    (h : ∀ t, L ≤ t → t < n → d.testBit t = d'.testBit t) :
    altSum d L n = altSum d' L n := by
  classical
  have hpop : ∀ l, L ≤ l → hiPop d l n = hiPop d' l n := by
    intro l hl
    unfold hiPop
    apply congrArg
    apply Finset.filter_congr
    intro t ht
    rw [Finset.mem_Ico] at ht
    rw [h t (by omega) ht.2]
  have hfilter : (Finset.Ico L n).filter (fun t => d.testBit t)
      = (Finset.Ico L n).filter (fun t => d'.testBit t) := by
    apply Finset.filter_congr
    intro t ht
    rw [Finset.mem_Ico] at ht
    rw [h t ht.1 ht.2]
  unfold altSum
  rw [hpop L le_rfl, hfilter]
  refine congrArg _ (congrArg _ (Finset.sum_congr rfl ?_))
  intro l hl
  rw [← hfilter, Finset.mem_filter, Finset.mem_Ico] at hl
  rw [hpop (l + 1) (by omega)]

/-! ### Bit bookkeeping for one doubling step -/

theorem testBit_high_eq (m r : Nat) (hr : r < 2 ^ m) : (2 ^ m + r).testBit m = true := by
  rw [Nat.testBit_two_pow_add_eq, Nat.testBit_lt_two_pow hr]
  rfl

theorem mod_two_pow_high (m r : Nat) (hr : r < 2 ^ m) : (2 ^ m + r) % 2 ^ m = r := by
  rw [Nat.add_mod_left, Nat.mod_eq_of_lt hr]

/-! ### The degenerate branches -/

theorem towerDegree_unit_low (m j : Nat) (hj : j < 2 ^ m) :
    towerDegree (m + 1) (2 ^ m) j = 2 ^ (m + 1) - 4 := by
  simpa using towerDegree_high_low_deg m 0 j hj (Or.inl rfl)

theorem towerDegree_low_unit (m i : Nat) (hi : i < 2 ^ m) :
    towerDegree (m + 1) i (2 ^ m) = 2 ^ (m + 1) - 4 := by
  simpa using towerDegree_low_high_deg m i 0 hi (Or.inl rfl)

theorem towerDegree_unit_high (m c : Nat) :
    towerDegree (m + 1) (2 ^ m) (2 ^ m + c) = 2 ^ (m + 1) - 4 := by
  simpa using towerDegree_high_high_deg m 0 c (Or.inl rfl)

theorem towerDegree_high_unit (m a : Nat) :
    towerDegree (m + 1) (2 ^ m + a) (2 ^ m) = 2 ^ (m + 1) - 4 := by
  simpa using towerDegree_high_high_deg m a 0 (Or.inr rfl)

/-- Every degenerate shape is extremal for the recursion. -/
theorem towerDegree_degenerate (m i j : Nat) (hi : i < 2 ^ (m + 1)) (hj : j < 2 ^ (m + 1))
    (hdeg : i = 2 ^ m ∨ j = 2 ^ m ∨ i ^^^ j = 2 ^ m) :
    towerDegree (m + 1) i j = 2 ^ (m + 1) - 4 := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  by_cases hi2 : i = 2 ^ m
  · subst hi2
    rcases lt_or_ge j (2 ^ m) with hja | hja
    · exact towerDegree_unit_low m j hja
    · obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
      exact towerDegree_unit_high m c
  · by_cases hj2 : j = 2 ^ m
    · subst hj2
      rcases lt_or_ge i (2 ^ m) with hia | hia
      · exact towerDegree_low_unit m i hia
      · obtain ⟨a, rfl⟩ : ∃ a, i = 2 ^ m + a := ⟨i - 2 ^ m, by omega⟩
        exact towerDegree_high_unit m a
    · have hx : i ^^^ j = 2 ^ m := by tauto
      rcases lt_or_ge i (2 ^ m) with hia | hia
      · rcases lt_or_ge j (2 ^ m) with hja | hja
        · have := Nat.xor_lt_two_pow hia hja
          omega
        · obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
          have hc : c < 2 ^ m := by omega
          rw [xor_low_high hia hc] at hx
          have hic : i ^^^ c = 0 := by omega
          have hci : c = i := (Nat.xor_eq_zero_iff.mp hic).symm
          subst hci
          exact towerDegree_low_high_deg m c c hia (Or.inr rfl)
      · obtain ⟨a, rfl⟩ : ∃ a, i = 2 ^ m + a := ⟨i - 2 ^ m, by omega⟩
        have ha : a < 2 ^ m := by omega
        rcases lt_or_ge j (2 ^ m) with hja | hja
        · rw [xor_high_low ha hja] at hx
          have haj : a ^^^ j = 0 := by omega
          have : a = j := Nat.xor_eq_zero_iff.mp haj
          subst this
          exact towerDegree_high_low_deg m a a hja (Or.inr rfl)
        · obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
          have hc : c < 2 ^ m := by omega
          rw [xor_high_high ha hc] at hx
          have := Nat.xor_lt_two_pow ha hc
          omega

theorem degreeClosed_degenerate (m i j : Nat) (hm : 3 ≤ m)
    (hdeg : i = 2 ^ m ∨ j = 2 ^ m ∨ i ^^^ j = 2 ^ m) :
    degreeClosed (m + 1) i j = 2 ^ (m + 1) - 4 := by
  rw [degreeClosed, stopLevel, if_neg (show ¬ m < 3 by omega), if_pos hdeg,
    altSum_of_empty _ (m + 1)]
  simp only [Nat.add_sub_cancel]
  ring

/-! ### The inductive step for the closed form -/

theorem cast_sub_helper (A B C : Nat) (h : A + (2 * B + 4) = C) :
    (A : ℤ) = (C : ℤ) - 4 - 2 * B := by
  have h' := congrArg (fun t : Nat => (t : ℤ)) h
  push_cast at h'
  linarith

/-- The degree recursion and the closed form agree. -/
theorem towerDegree_eq_degreeClosed (n : Nat) (hn : 3 ≤ n) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (towerDegree n i j : ℤ) = degreeClosed n i j := by
  induction n, hn using Nat.le_induction generalizing i j with
  | base =>
      rw [towerDegree_dim8 i j (by norm_num at hi; omega) (by norm_num at hj; omega)
          hi0 hj0 hij,
        degreeClosed, stopLevel_base 3 i j le_rfl, altSum_of_empty _ 3]
      norm_num
  | succ m hm ih =>
      have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
      have hge : (8 : Nat) ≤ 2 ^ m := by
        calc (8 : Nat) = 2 ^ 3 := by norm_num
          _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
      have hz2 : (2 : ℤ) ^ m = 2 * 2 ^ (m - 1) := by
        rw [← pow_succ']
        congr 1
        omega
      by_cases hdeg : i = 2 ^ m ∨ j = 2 ^ m ∨ i ^^^ j = 2 ^ m
      · rw [towerDegree_degenerate m i j hi hj hdeg, degreeClosed_degenerate m i j hm hdeg,
          Nat.cast_sub (by omega)]
        push_cast
        ring
      · -- non-degenerate: the descent continues one more level
        have hnd : i ≠ 2 ^ m ∧ j ≠ 2 ^ m ∧ i ^^^ j ≠ 2 ^ m := by tauto
        have hstop : stopLevel (m + 1) i j = stopLevel m (i % 2 ^ m) (j % 2 ^ m) := by
          rw [stopLevel, if_neg (show ¬ m < 3 by omega), if_neg hdeg]
        have hLm : stopLevel m (i % 2 ^ m) (j % 2 ^ m) ≤ m := stopLevel_le m _ _ hm
        have hL3 : 3 ≤ stopLevel m (i % 2 ^ m) (j % 2 ^ m) := stopLevel_ge m _ _
        set L := stopLevel m (i % 2 ^ m) (j % 2 ^ m) with hLdef
        set S : ℤ := altSum (i ^^^ j) L m with hSdef
        have hbits : ∀ t, L ≤ t → t < m →
            ((i % 2 ^ m) ^^^ (j % 2 ^ m)).testBit t = (i ^^^ j).testBit t := by
          intro t _ ht
          simp [Nat.testBit_xor, Nat.testBit_mod_two_pow, ht]
        have hclosed_prev : degreeClosed m (i % 2 ^ m) (j % 2 ^ m) = 2 ^ (m - 1) - 4 + S := by
          rw [degreeClosed, ← hLdef, hSdef]
          exact congrArg _ (altSum_congr _ _ _ _ hbits)
        have hclosed_succ : degreeClosed (m + 1) i j
            = 2 ^ m - 4 + (if (i ^^^ j).testBit m then 8 - 2 * S else 2 * S) := by
          rw [degreeClosed, hstop, altSum_succ _ L m hLm (by omega), hSdef,
            Nat.add_sub_cancel]
        rw [hclosed_succ]
        rcases lt_or_ge i (2 ^ m) with hia | hia
        · rcases lt_or_ge j (2 ^ m) with hja | hja
          · -- both indices inherited
            have hbit : (i ^^^ j).testBit m = false :=
              Nat.testBit_lt_two_pow (Nat.xor_lt_two_pow hia hja)
            have hprev : degreeClosed m i j = 2 ^ (m - 1) - 4 + S := by
              rw [Nat.mod_eq_of_lt hia, Nat.mod_eq_of_lt hja] at hclosed_prev
              exact hclosed_prev
            rw [hbit, if_neg (by simp), towerDegree_low_low m i j hia hja]
            have hih := ih i j hia hja hi0 hj0 hij
            rw [hprev] at hih
            push_cast
            rw [hih]
            linarith
          · -- `j` from the new half
            obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
            have hc : c < 2 ^ m := by omega
            have hxor : i ^^^ (2 ^ m + c) = 2 ^ m + (i ^^^ c) := xor_low_high hia hc
            have hic : i ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hia hc
            have hbit : (i ^^^ (2 ^ m + c)).testBit m = true := by
              rw [hxor]; exact testBit_high_eq m _ hic
            have hc0 : c ≠ 0 := by
              intro h; exact hnd.2.1 (by omega)
            have hci : c ≠ i := by
              intro h
              subst h
              exact hnd.2.2 (by rw [hxor, Nat.xor_self, Nat.add_zero])
            have hprev : degreeClosed m i c = 2 ^ (m - 1) - 4 + S := by
              rw [Nat.mod_eq_of_lt hia, mod_two_pow_high m c hc] at hclosed_prev
              exact hclosed_prev
            have hih := ih i c hia hc hi0 hc0 (Ne.symm hci)
            rw [hprev] at hih
            have hbound : towerDegree m i c ≤ 2 ^ m - 4 := by
              rw [← nonassocMiddles_card_eq_towerDegree m i c hia hc hi0 hc0 (Ne.symm hci)]
              exact (nonassocMiddles_card_bounds m i c hm hia hc hi0 hc0 (Ne.symm hci)).2
            rw [hbit, if_pos rfl, towerDegree_low_high m i c hia hc0 hci]
            have hcast := cast_sub_helper (2 ^ (m + 1) - (2 * towerDegree m i c + 4))
              (towerDegree m i c) (2 ^ (m + 1)) (by omega)
            rw [hcast]
            push_cast at hih ⊢
            rw [hih]
            linarith
        · -- `i` from the new half
          obtain ⟨a, rfl⟩ : ∃ a, i = 2 ^ m + a := ⟨i - 2 ^ m, by omega⟩
          have ha : a < 2 ^ m := by omega
          rcases lt_or_ge j (2 ^ m) with hja | hja
          · have hxor : (2 ^ m + a) ^^^ j = 2 ^ m + (a ^^^ j) := xor_high_low ha hja
            have haj : a ^^^ j < 2 ^ m := Nat.xor_lt_two_pow ha hja
            have hbit : ((2 ^ m + a) ^^^ j).testBit m = true := by
              rw [hxor]; exact testBit_high_eq m _ haj
            have ha0 : a ≠ 0 := by
              intro h; exact hnd.1 (by omega)
            have haj0 : a ≠ j := by
              intro h
              subst h
              exact hnd.2.2 (by rw [hxor, Nat.xor_self, Nat.add_zero])
            have hprev : degreeClosed m a j = 2 ^ (m - 1) - 4 + S := by
              rw [mod_two_pow_high m a ha, Nat.mod_eq_of_lt hja] at hclosed_prev
              exact hclosed_prev
            have hih := ih a j ha hja ha0 hj0 haj0
            rw [hprev] at hih
            have hsymm : towerDegree m j a = towerDegree m a j :=
              towerDegree_comm m j a hja ha hj0 ha0 (Ne.symm haj0)
            have hbound : towerDegree m j a ≤ 2 ^ m - 4 := by
              rw [← nonassocMiddles_card_eq_towerDegree m j a hja ha hj0 ha0 (Ne.symm haj0)]
              exact (nonassocMiddles_card_bounds m j a hm hja ha hj0 ha0 (Ne.symm haj0)).2
            rw [hbit, if_pos rfl, towerDegree_high_low m a j hja ha0 haj0]
            have hcast := cast_sub_helper (2 ^ (m + 1) - (2 * towerDegree m j a + 4))
              (towerDegree m j a) (2 ^ (m + 1)) (by omega)
            rw [hcast, hsymm]
            push_cast at hih ⊢
            rw [hih]
            linarith
          · obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
            have hc : c < 2 ^ m := by omega
            have hxor : (2 ^ m + a) ^^^ (2 ^ m + c) = a ^^^ c := xor_high_high ha hc
            have hac : a ≠ c := by omega
            have ha0 : a ≠ 0 := by
              intro h; exact hnd.1 (by omega)
            have hc0 : c ≠ 0 := by
              intro h; exact hnd.2.1 (by omega)
            have hbit : ((2 ^ m + a) ^^^ (2 ^ m + c)).testBit m = false := by
              rw [hxor]
              exact Nat.testBit_lt_two_pow (Nat.xor_lt_two_pow ha hc)
            have hprev : degreeClosed m a c = 2 ^ (m - 1) - 4 + S := by
              rw [mod_two_pow_high m a ha, mod_two_pow_high m c hc] at hclosed_prev
              exact hclosed_prev
            have hih := ih a c ha hc ha0 hc0 hac
            rw [hprev] at hih
            rw [hbit, if_neg (by simp), towerDegree_high_high m a c ha0 hc0]
            push_cast
            rw [hih]
            linarith

/-- **Closed formula for the degree of an arbitrary pair.**  For every `n ≥ 3` and all
distinct non-real indices `i, j < 2ⁿ`, the number of middles that fail to associate with the
outer pair `(e_i, ·, e_j)` is given by the non-recursive expression `degreeClosed n i j`. -/
theorem nonassocMiddles_card_eq_degreeClosed (n : Nat) (hn : 3 ≤ n) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    ((nonassocMiddles n i j).card : ℤ) = degreeClosed n i j := by
  rw [nonassocMiddles_card_eq_towerDegree n i j hi hj hi0 hj0 hij]
  exact towerDegree_eq_degreeClosed n hn i j hi hj hi0 hj0 hij

/-! ## 3. The regular charge sectors, in every dimension

A charge sector is *regular* when every pair carrying that charge attains the maximal
degree.  Dimensions 16 and 32 suggested the criterion "`chi < 8` or `chi` is a power of
two"; the maximality criterion of `TowerDegreeFormula` proves it in every dimension. -/

/-- A charge sector is *regular* when all its admissible pairs attain the maximal degree
`2ⁿ - 4`. -/
def IsRegularSector (n chi : Nat) : Prop :=
  ∀ p ∈ chargeSectorPairs n chi, (nonassocMiddles n p.1 p.2).card = 2 ^ n - 4

theorem mod_two_pow_ne_zero_of_testBit (y b k : Nat) (hb : b < k) (h : y.testBit b = true) :
    y % 2 ^ k ≠ 0 := by
  intro h0
  have hmod := Nat.testBit_mod_two_pow y k b
  rw [h0, Nat.zero_testBit, h] at hmod
  simp [hb] at hmod

theorem exists_testBit_of_mod_two_pow_ne_zero (y k : Nat) (h : y % 2 ^ k ≠ 0) :
    ∃ b, b < k ∧ y.testBit b = true := by
  by_contra hc
  push_neg at hc
  apply h
  apply Nat.eq_of_testBit_eq
  intro t
  rw [Nat.testBit_mod_two_pow, Nat.zero_testBit]
  by_cases ht : t < k
  · have hbt := hc t ht
    simp only [Bool.not_eq_true] at hbt
    simp [ht, hbt]
  · simp [ht]

/-- **Classification of the regular charge sectors, in every dimension.**  For a non-zero
charge `chi < 2ⁿ`, the sector of charge `chi` is regular — every admissible pair with
`i ⊕ j = chi` attains the maximal degree `2ⁿ - 4` — if and only if `chi < 8` or `chi` is a
power of two. -/
theorem chargeSector_regular_iff (n chi : Nat) (h1 : 1 ≤ chi) (h2 : chi < 2 ^ n) :
    IsRegularSector n chi ↔ (chi < 8 ∨ ∃ k, chi = 2 ^ k) := by
  have hkle : 2 ^ chi.log2 ≤ chi := Nat.log2_self_le (by omega)
  have hklt : chi < 2 ^ (chi.log2 + 1) := Nat.lt_log2_self
  set k := chi.log2 with hkdef
  constructor
  · intro hreg
    by_contra hcon
    push_neg at hcon
    obtain ⟨hge8, hnp⟩ := hcon
    have hk3 : 3 ≤ k := by
      by_contra hc
      push_neg at hc
      have : chi < 2 ^ 3 :=
        lt_of_lt_of_le hklt (Nat.pow_le_pow_right (by norm_num) (by omega))
      omega
    have hpos : 0 < 2 ^ k := Nat.two_pow_pos k
    have hlow : chi % 2 ^ k ≠ 0 := by
      intro h0
      obtain ⟨q, hq⟩ : 2 ^ k ∣ chi := Nat.dvd_of_mod_eq_zero h0
      have hq1 : 1 ≤ q := by
        rcases Nat.eq_zero_or_pos q with h | h
        · subst h; omega
        · exact h
      have hq2 : q < 2 := by
        by_contra hc
        push_neg at hc
        have : 2 ^ (k + 1) ≤ 2 ^ k * q := by
          calc 2 ^ (k + 1) = 2 ^ k * 2 := by ring
            _ ≤ 2 ^ k * q := Nat.mul_le_mul_left _ hc
        omega
      have hq1' : q = 1 := by omega
      subst hq1'
      exact hnp k (by simp [hq])
    obtain ⟨b, hbk, hb⟩ := exists_testBit_of_mod_two_pow_ne_zero chi k hlow
    have hb'k : (if b = 0 then 1 else 0) < k := by split <;> omega
    have hbb' : (if b = 0 then 1 else 0) ≠ b := by split <;> omega
    set b' := if b = 0 then 1 else 0 with hb'def
    have hipow : (2 ^ b').testBit b' = true := by simp
    have hib : (2 ^ b').testBit b = false := by simp [hbb']
    have hjb : (2 ^ b' ^^^ chi).testBit b = true := by
      rw [Nat.testBit_xor, hib, hb]
      rfl
    have hilt : 2 ^ b' < 2 ^ n := by
      have : (2 : Nat) ^ b' < 2 ^ k := Nat.pow_lt_pow_right (by norm_num) hb'k
      omega
    have hjlt : 2 ^ b' ^^^ chi < 2 ^ n := Nat.xor_lt_two_pow hilt h2
    have hi0 : (2 : Nat) ^ b' ≠ 0 := by positivity
    have hj0 : 2 ^ b' ^^^ chi ≠ 0 := by
      intro h
      rw [h, Nat.zero_testBit] at hjb
      exact Bool.noConfusion hjb
    have hxor : 2 ^ b' ^^^ (2 ^ b' ^^^ chi) = chi := by
      rw [← Nat.xor_assoc, Nat.xor_self, Nat.zero_xor]
    have hij : (2 : Nat) ^ b' ≠ 2 ^ b' ^^^ chi := by
      intro h
      rw [← h, Nat.xor_self] at hxor
      omega
    have hmem : ((2 : Nat) ^ b', 2 ^ b' ^^^ chi) ∈ chargeSectorPairs n chi := by
      simp only [chargeSectorPairs, admissiblePairs, Finset.mem_filter, Finset.mem_product,
        Finset.mem_range]
      exact ⟨⟨⟨hilt, hjlt⟩, hi0, hj0, hij⟩, hxor⟩
    have hmax := hreg _ hmem
    rw [nonassocMiddles_card_max_iff n (2 ^ b') (2 ^ b' ^^^ chi) k hilt hjlt hi0 hj0 hij
      (by rw [hxor]; exact hkle) (by rw [hxor]; exact hklt)] at hmax
    rcases hmax with h | h | h | h
    · omega
    · exact mod_two_pow_ne_zero_of_testBit _ b' k hb'k hipow h
    · exact mod_two_pow_ne_zero_of_testBit _ b k hbk hjb h
    · rw [hxor] at h
      exact hnp k h
  · intro hcrit p hp
    rw [chargeSectorPairs, Finset.mem_filter] at hp
    obtain ⟨hpa, hpc⟩ := hp
    simp only [admissiblePairs, Finset.mem_filter, Finset.mem_product, Finset.mem_range] at hpa
    obtain ⟨⟨hi, hj⟩, hi0, hj0, hij⟩ := hpa
    rw [nonassocMiddles_card_max_iff n p.1 p.2 k hi hj hi0 hj0 hij
      (by rw [hpc]; exact hkle) (by rw [hpc]; exact hklt)]
    rcases hcrit with hlt | ⟨t, ht⟩
    · left
      by_contra hc
      push_neg at hc
      have : (2 : Nat) ^ 3 ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) hc
      omega
    · refine Or.inr (Or.inr (Or.inr ?_))
      rw [hpc, ht]
      congr 1
      have hkt : k ≤ t := by
        rw [ht] at hkle
        exact (Nat.pow_le_pow_iff_right (by norm_num)).mp hkle
      have htk : t < k + 1 := by
        rw [ht] at hklt
        exact (Nat.pow_lt_pow_iff_right (by norm_num)).mp hklt
      omega

/-! ## 4. Consequences: the degree census in dimension 64

Evaluating the degree of a single pair is a bounded computation, so global statistics of the
annihilation graph become finite checks. -/

theorem nonassocMiddles_card_eq_towerDegree_of_mem (n : Nat) (p : Nat × Nat)
    (hp : p ∈ admissiblePairs n) :
    (nonassocMiddles n p.1 p.2).card = towerDegree n p.1 p.2 := by
  simp only [admissiblePairs, Finset.mem_filter, Finset.mem_product, Finset.mem_range] at hp
  exact nonassocMiddles_card_eq_towerDegree n p.1 p.2 hp.1.1 hp.1.2 hp.2.1 hp.2.2.1 hp.2.2.2

theorem mem_chargeSectorPairs_card (n chi : Nat) (p : Nat × Nat)
    (hp : p ∈ chargeSectorPairs n chi) :
    (nonassocMiddles n p.1 p.2).card = towerDegree n p.1 p.2 := by
  rw [chargeSectorPairs, Finset.mem_filter] at hp
  exact nonassocMiddles_card_eq_towerDegree_of_mem n p hp.1

theorem admissiblePairs_degree_filter (n v : Nat) :
    (admissiblePairs n).filter (fun p => (nonassocMiddles n p.1 p.2).card = v)
      = (admissiblePairs n).filter (fun p => towerDegree n p.1 p.2 = v) := by
  apply Finset.filter_congr
  intro p hp
  rw [nonassocMiddles_card_eq_towerDegree_of_mem n p hp]

set_option maxRecDepth 1000000 in
/-- **The exact degree census in dimension 64.**  Among the `930` admissible index pairs of
the 32-dimensional base algebra, exactly `252` pairs have `4` non-associating middles
(degree `8` in the cross-half annihilation graph), `168` have `12` (degree `24`), `168`
have `20` (degree `40`) and `342` have `28` (degree `56`).  This is the complete degree
distribution of the 64-dimensional annihilation graph; the two extreme multiplicities agree
with `minDegreePairs_card_dim32` and `maxDegreePairs_card_dim32`. -/
theorem dim64_degree_counts :
    (admissiblePairs 5).card = 930 ∧
    ((admissiblePairs 5).filter (fun p => (nonassocMiddles 5 p.1 p.2).card = 4)).card = 252 ∧
    ((admissiblePairs 5).filter (fun p => (nonassocMiddles 5 p.1 p.2).card = 12)).card = 168 ∧
    ((admissiblePairs 5).filter (fun p => (nonassocMiddles 5 p.1 p.2).card = 20)).card = 168 ∧
    ((admissiblePairs 5).filter (fun p => (nonassocMiddles 5 p.1 p.2).card = 28)).card = 342 := by
  rw [admissiblePairs_degree_filter 5 4, admissiblePairs_degree_filter 5 12,
    admissiblePairs_degree_filter 5 20, admissiblePairs_degree_filter 5 28]
  refine ⟨by decide, by decide, by decide, by decide, by decide⟩

set_option maxRecDepth 1000000 in
/-- **The regular charge sectors in dimension 64.**  A charge sector of the 64-dimensional
annihilation graph is regular (all its pairs have the maximal degree `56`) exactly for the
charges `1, …, 8` and `16`. -/
theorem dim64_regular_sectors :
    (Finset.Icc 1 31).filter
        (fun chi => ∀ p ∈ chargeSectorPairs 5 chi, (nonassocMiddles 5 p.1 p.2).card = 28)
      = {1, 2, 3, 4, 5, 6, 7, 8, 16} := by
  have key : (Finset.Icc 1 31).filter
        (fun chi => ∀ p ∈ chargeSectorPairs 5 chi, (nonassocMiddles 5 p.1 p.2).card = 28)
      = (Finset.Icc 1 31).filter
        (fun chi => ∀ p ∈ chargeSectorPairs 5 chi, towerDegree 5 p.1 p.2 = 28) := by
    apply Finset.filter_congr
    intro chi _
    constructor
    · intro h p hp
      rw [← mem_chargeSectorPairs_card 5 chi p hp]
      exact h p hp
    · intro h p hp
      rw [mem_chargeSectorPairs_card 5 chi p hp]
      exact h p hp
  rw [key]
  decide

/-- **The regularity criterion in dimension 64**, in the form of the project's predicate
`is_regular_sector_criterion`: a special case of `chargeSector_regular_iff`. -/
theorem dim64_regular_sector_iff (chi : Nat) (h1 : 1 ≤ chi) (h2 : chi ≤ 31) :
    (∀ p ∈ chargeSectorPairs 5 chi, (nonassocMiddles 5 p.1 p.2).card = 28)
      ↔ is_regular_sector_criterion chi := by
  have h := chargeSector_regular_iff 5 chi h1 (by norm_num; omega)
  simpa [IsRegularSector, is_regular_sector_criterion] using h

set_option maxRecDepth 1000000 in
/-- **An exact degree far beyond enumeration range.**  In the Cayley–Dickson algebra of
dimension `2²¹` the pair of basis indices `(12345, 54321)` has exactly `1044860`
non-associating middles, so the corresponding cross-half zero divisor has `2089720`
annihilation partners inside its charge sector.  Reading this off the associator table
would take `2²⁰` sign computations; the recursion needs `20` steps. -/
theorem nonassocMiddles_card_dim2pow21_example :
    (nonassocMiddles 20 12345 54321).card = 1044860 := by
  rw [nonassocMiddles_card_eq_towerDegree 20 12345 54321
    (by norm_num) (by norm_num) (by norm_num) (by norm_num) (by norm_num)]
  decide

end Sovereign
