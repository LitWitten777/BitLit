import Sovereign.Combinatorics.TowerDegreeHandshake
import Sovereign.Combinatorics.HomomorphismDecomposition

namespace Sovereign

open Finset

/-! ## 1. The doubling law of a weighted census sum -/

/-- A sum over the indices of level `q + 1` is a sum over pairs of children: the case `k = 2`
of the block decomposition `Sovereign.HomDecomp.sum_range_blocks` (see
`Sovereign/Combinatorics/HomomorphismDecomposition.lean`). -/
theorem sum_range_two_mul_int (n : Nat) (f : Nat → ℤ) :
    ∑ e ∈ range (2 * n), f e = ∑ s ∈ range n, (f (2 * s) + f (2 * s + 1)) :=
  HomDecomp.sum_range_pairs n f

/-- **The doubling law for weighted census sums.**  Summing any weight `f` against the
census of level `q + 1` reduces to a sum against the census of level `q`. -/
theorem censusT_succ_weighted (q : Nat) (f : Nat → ℤ) :
    ∑ e ∈ range (2 ^ (q + 1)), f e * (censusT (q + 1) e : ℤ)
      = 2 * ∑ s ∈ range (2 ^ q),
          (f (2 * (2 ^ q - 1 - s)) + f (2 * s + 1)) * (censusT q s : ℤ)
        + f (2 ^ (q + 1) - 1) * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hpow : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
  rw [hpow, sum_range_two_mul_int (2 ^ q) (fun e => f e * (censusT (q + 1) e : ℤ))]
  have hterm : ∀ s ∈ range (2 ^ q),
      f (2 * s) * (censusT (q + 1) (2 * s) : ℤ) + f (2 * s + 1) * (censusT (q + 1) (2 * s + 1) : ℤ)
        = 2 * (f (2 * s) * (censusT q (2 ^ q - 1 - s) : ℤ) + f (2 * s + 1) * (censusT q s : ℤ))
          + (if s = 2 ^ q - 1 then f (2 * s + 1) * (6 * ((2 : ℤ) ^ (q + 3) - 1)) else 0) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have h1 : censusT (q + 1) (2 * s) = 2 * censusT q (2 ^ q - 1 - s) := by
      rw [censusT, show (2 * s) % 2 = 0 from by omega, show (2 * s) / 2 = s from by omega,
        if_neg (by omega : ¬ (0 : Nat) = 1), if_pos hs']
    have h2 : censusT (q + 1) (2 * s + 1)
        = 2 * censusT q s + (if s = 2 ^ q - 1 then 6 * (2 ^ (q + 3) - 1) else 0) := by
      rw [censusT, show (2 * s + 1) % 2 = 1 from by omega,
        show (2 * s + 1) / 2 = s from by omega, if_pos rfl]
      by_cases hmax : s = 2 ^ q - 1
      · rw [if_pos hmax, if_pos (by omega : 2 * s + 1 = 2 ^ (q + 1) - 1)]
      · rw [if_neg hmax, if_neg (by omega : ¬ 2 * s + 1 = 2 ^ (q + 1) - 1)]
    rw [h1, h2]
    by_cases hmax : s = 2 ^ q - 1
    · rw [if_pos hmax, if_pos hmax]
      have hge : (1 : Nat) ≤ 2 ^ (q + 3) := Nat.one_le_two_pow
      push_cast [hge]
      ring
    · rw [if_neg hmax, if_neg hmax]
      push_cast
      ring
  have hrefl : ∑ i ∈ range (2 ^ q), f (2 * i) * (censusT q (2 ^ q - 1 - i) : ℤ)
      = ∑ s ∈ range (2 ^ q), f (2 * (2 ^ q - 1 - s)) * (censusT q s : ℤ) := by
    rw [← Finset.sum_range_reflect (fun i => f (2 * i) * (censusT q (2 ^ q - 1 - i) : ℤ)) (2 ^ q)]
    refine Finset.sum_congr rfl (fun s hs => ?_)
    have hs' := Finset.mem_range.mp hs
    rw [show 2 ^ q - 1 - (2 ^ q - 1 - s) = s from by omega]
  rw [Finset.sum_congr rfl hterm, Finset.sum_add_distrib, ← Finset.mul_sum,
    Finset.sum_ite_eq' (range (2 ^ q)) (2 ^ q - 1)
      (fun x => f (2 * x + 1) * (6 * ((2 : ℤ) ^ (q + 3) - 1))),
    if_pos (Finset.mem_range.mpr (by have : 0 < 2 ^ q := Nat.two_pow_pos q; omega)),
    Finset.sum_add_distrib, hrefl, show 2 * (2 ^ q - 1) + 1 = 2 * 2 ^ q - 1 from by
      have : 0 < 2 ^ q := Nat.two_pow_pos q; omega]
  rw [Finset.sum_congr rfl (fun s _ => add_mul (f (2 * (2 ^ q - 1 - s))) (f (2 * s + 1))
    ((censusT q s : ℤ))), Finset.sum_add_distrib]

/-! ## 2. The moments -/

/-- The number of ordered admissible pairs of the dimension `2^(q+3)`, as an integer. -/
def censusMoment0 (q : Nat) : ℤ := ∑ t ∈ range (2 ^ q), (censusT q t : ℤ)

/-- The first moment of the degree census: the total degree. -/
def censusMoment1 (q : Nat) : ℤ := ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) * (censusT q t : ℤ)

/-- The second moment of the degree census. -/
def censusMoment2 (q : Nat) : ℤ :=
  ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) ^ 2 * (censusT q t : ℤ)

theorem censusMoment0_formula (q : Nat) :
    censusMoment0 q = ((2 : ℤ) ^ (q + 3) - 1) * ((2 : ℤ) ^ (q + 3) - 2) := by
  have h := censusT_sum q
  have h8 : (8 : Nat) ≤ 2 ^ (q + 3) := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ (q + 3) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hcast : (((2 ^ (q + 3) - 1) * (2 ^ (q + 3) - 2) : Nat) : ℤ)
      = ((2 : ℤ) ^ (q + 3) - 1) * ((2 : ℤ) ^ (q + 3) - 2) := by
    push_cast [Nat.cast_sub (show 1 ≤ 2 ^ (q + 3) from by omega),
      Nat.cast_sub (show 2 ≤ 2 ^ (q + 3) from by omega)]
    ring
  rw [censusMoment0, ← hcast, ← h, Nat.cast_sum]

/-- The cast of the reflected index, for `s` below `2 ^ q`. -/
theorem cast_two_pow_sub_sub (q s : Nat) (hs : s < 2 ^ q) :
    ((2 ^ q - 1 - s : Nat) : ℤ) = (2 : ℤ) ^ q - 1 - (s : ℤ) := by
  have h1 : (1 : Nat) ≤ 2 ^ q := Nat.one_le_two_pow
  push_cast [Nat.cast_sub (show s ≤ 2 ^ q - 1 from by omega), Nat.cast_sub h1]
  ring

theorem censusMoment1_succ (q : Nat) :
    censusMoment1 (q + 1)
      = 2 * (2 * (2 : ℤ) ^ (q + 3)) * censusMoment0 q
        + (2 * (2 : ℤ) ^ (q + 3) - 4) * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hw := censusT_succ_weighted q (fun e => 8 * (e : ℤ) + 4)
  have hsum : ∀ s ∈ range (2 ^ q),
      ((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) + (8 * ((2 * s + 1 : Nat) : ℤ) + 4))
        * (censusT q s : ℤ)
        = (2 * (2 : ℤ) ^ (q + 3)) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    push_cast [hc]
    have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
    rw [hp]
    ring
  have hlast : (8 * ((2 ^ (q + 1) - 1 : Nat) : ℤ) + 4) = 2 * (2 : ℤ) ^ (q + 3) - 4 := by
    have h1 : (1 : Nat) ≤ 2 ^ (q + 1) := Nat.one_le_two_pow
    push_cast [Nat.cast_sub h1]
    have hp : (2 : ℤ) ^ (q + 3) = 4 * 2 ^ (q + 1) := by ring
    rw [hp]
    ring
  have hM1 : censusMoment1 (q + 1)
      = ∑ e ∈ range (2 ^ (q + 1)), (8 * (e : ℤ) + 4) * (censusT (q + 1) e : ℤ) := rfl
  rw [hM1, hw, Finset.sum_congr rfl hsum, ← Finset.mul_sum, hlast, censusMoment0]
  ring

theorem censusMoment1_formula (q : Nat) :
    2 * censusMoment1 q = ((2 : ℤ) ^ (q + 3)) ^ 3 - 28 * (2 : ℤ) ^ (q + 3) + 48 := by
  induction q with
  | zero => decide
  | succ q ih =>
    have h0 := censusMoment0_formula q
    have hstep := censusMoment1_succ q
    have hp : (2 : ℤ) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    rw [hp, hstep, h0]
    ring

theorem censusMoment2_succ (q : Nat) :
    censusMoment2 (q + 1)
      = 2 * ((4 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 16 * (2 : ℤ) ^ (q + 3) + 32) * censusMoment0 q
          + (32 - 8 * (2 : ℤ) ^ (q + 3)) * censusMoment1 q + 8 * censusMoment2 q)
        + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 2 * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hw := censusT_succ_weighted q (fun e => (8 * (e : ℤ) + 4) ^ 2)
  have hsum : ∀ s ∈ range (2 ^ q),
      (((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) ^ 2) + ((8 * ((2 * s + 1 : Nat) : ℤ) + 4) ^ 2))
        * (censusT q s : ℤ)
        = ((4 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 16 * (2 : ℤ) ^ (q + 3) + 32)
            + (32 - 8 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4)
            + 8 * (8 * (s : ℤ) + 4) ^ 2) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    push_cast [hc]
    have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
    rw [hp]
    ring
  have hlast : ((8 * ((2 ^ (q + 1) - 1 : Nat) : ℤ) + 4) ^ 2) = (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 2 := by
    have h1 : (1 : Nat) ≤ 2 ^ (q + 1) := Nat.one_le_two_pow
    push_cast [Nat.cast_sub h1]
    have hp : (2 : ℤ) ^ (q + 3) = 4 * 2 ^ (q + 1) := by ring
    rw [hp]
    ring
  have hM2 : censusMoment2 (q + 1)
      = ∑ e ∈ range (2 ^ (q + 1)), ((8 * (e : ℤ) + 4) ^ 2) * (censusT (q + 1) e : ℤ) := rfl
  have hsplit : ∑ s ∈ range (2 ^ q),
      ((4 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 16 * (2 : ℤ) ^ (q + 3) + 32)
          + (32 - 8 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4)
          + 8 * (8 * (s : ℤ) + 4) ^ 2) * (censusT q s : ℤ)
      = (4 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 16 * (2 : ℤ) ^ (q + 3) + 32) * censusMoment0 q
        + (32 - 8 * (2 : ℤ) ^ (q + 3)) * censusMoment1 q + 8 * censusMoment2 q := by
    rw [censusMoment0, censusMoment1, censusMoment2, Finset.mul_sum, Finset.mul_sum,
      Finset.mul_sum, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib]
    exact Finset.sum_congr rfl (fun s _ => by ring)
  rw [hM2, hw, Finset.sum_congr rfl hsum, hlast, hsplit]

/-- **The second moment of the degree census.**  In every dimension `D = 2^(q+3)` of the
tower the degrees of the annihilation graph satisfy
`30 ∑ v² · (multiplicity of v) = 11 D⁴ - 700 D² + 2880 D - 3136`. -/
theorem censusMoment2_formula (q : Nat) :
    30 * censusMoment2 q
      = 11 * ((2 : ℤ) ^ (q + 3)) ^ 4 - 700 * ((2 : ℤ) ^ (q + 3)) ^ 2
        + 2880 * (2 : ℤ) ^ (q + 3) - 3136 := by
  induction q with
  | zero => decide
  | succ q ih =>
    have h0 := censusMoment0_formula q
    have h1 := censusMoment1_formula q
    have hstep := censusMoment2_succ q
    have hp : (2 : ℤ) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    rw [hp, hstep, h0]
    linear_combination 16 * ih + 30 * (32 - 8 * (2 : ℤ) ^ (q + 3)) * h1

/-- The second moment in terms of the degree census of dimension `2ⁿ`. -/
theorem degreeCount_second_moment (n : Nat) (hn : 3 ≤ n) :
    30 * ∑ t ∈ range (2 ^ (n - 3)), (8 * (t : ℤ) + 4) ^ 2 * (degreeCount n (8 * t + 4) : ℤ)
      = 11 * ((2 : ℤ) ^ n) ^ 4 - 700 * ((2 : ℤ) ^ n) ^ 2 + 2880 * (2 : ℤ) ^ n - 3136 := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  rw [show q + 3 - 3 = q from by omega,
    Finset.sum_congr rfl (fun t _ => by rw [degreeCount_eq_censusT q t])]
  exact censusMoment2_formula q

end Sovereign
