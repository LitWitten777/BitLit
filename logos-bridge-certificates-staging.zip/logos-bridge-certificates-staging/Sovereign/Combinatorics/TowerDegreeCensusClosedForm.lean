import Sovereign.Combinatorics.TowerDegreeCensus

namespace Sovereign

/-! ## 1. Plateau and Wing Excess Definitions -/

/-- Minimal plateau multiplicity in dimension `2^(q+3)`: `21 * 2^(q+1)`. -/
def censusPlateau (q : Nat) : Nat :=
  21 * 2 ^ (q + 1)

/-- The exact dyadic excess over the plateau for a degree with prefix depth `k ≥ 2` (`k < q`):
  `24 * ((k - 1) * 2^q - (2^(q-2) - 2^(q-1-k)))`. -/
def censusWingExcess (q k : Nat) : Nat :=
  24 * ((k - 1) * 2 ^ q - (2 ^ (q - 2) - 2 ^ (q - 1 - k)))

/-- Total interior multiplicity for prefix depth `k ≥ 2`: plateau + wing excess. -/
def censusInteriorVal (q k : Nat) : Nat :=
  censusPlateau q + censusWingExcess q k

/-- Boundary multiplicity at `t = 0` (minimal non-zero degree 4):
  `censusInteriorVal q (q - 1) + 24 * 2^q - 12`. -/
def censusZeroVal (q : Nat) : Nat :=
  censusInteriorVal q (q - 1) + 24 * 2 ^ q - 12

/-- Boundary multiplicity at `t = 2^q - 1` (maximal degree `2^(q+3) - 4`):
  `censusInteriorVal q (q - 1) + 24 * 2^(q+1) - 18`. -/
def censusMaxVal (q : Nat) : Nat :=
  censusInteriorVal q (q - 1) + 24 * 2 ^ (q + 1) - 18

/-! ## 2. Verification of Explicit Dimensions -/

/-- Dimension 64 (q = 3): exact multiplicities [684, 504, 336, 336, 336, 336, 504, 870]. -/
theorem census_dim64_closed_exact :
    censusZeroVal 3 = 684 ∧
    censusInteriorVal 3 2 = 504 ∧
    censusPlateau 3 = 336 ∧
    censusMaxVal 3 = 870 := by
  decide

/-- Dimension 128 (q = 4): exact multiplicities [1740, 1368, 1008, 672 (plateau), 1008, 1368, 2118]. -/
theorem census_dim128_closed_exact :
    censusZeroVal 4 = 1740 ∧
    censusInteriorVal 4 3 = 1368 ∧
    censusInteriorVal 4 2 = 1008 ∧
    censusPlateau 4 = 672 ∧
    censusMaxVal 4 = 2118 := by
  decide

/-- Dimension 256 (q = 5): exact multiplicities [4236, 3480, 2736, 2016, 1344 (plateau), 2016, 2736, 3480, 4998]. -/
theorem census_dim256_closed_exact :
    censusZeroVal 5 = 4236 ∧
    censusInteriorVal 5 4 = 3480 ∧
    censusInteriorVal 5 3 = 2736 ∧
    censusInteriorVal 5 2 = 2016 ∧
    censusPlateau 5 = 1344 ∧
    censusMaxVal 5 = 4998 := by
  decide

/-- Dimension 512 (q = 6): exact multiplicities [9996, 8472, 6960, 5472, 4032, 2688 (plateau), ..., 11526]. -/
theorem census_dim512_closed_exact :
    censusZeroVal 6 = 9996 ∧
    censusInteriorVal 6 5 = 8472 ∧
    censusInteriorVal 6 4 = 6960 ∧
    censusInteriorVal 6 3 = 5472 ∧
    censusInteriorVal 6 2 = 4032 ∧
    censusPlateau 6 = 2688 ∧
    censusMaxVal 6 = 11526 := by
  decide

/-! ## 3. Master Census Closed-Form Theorem -/

/-- **Master Closed-Form Census Theorem (HYP-221)**:
  Every multiplicity level across the infinite Cayley-Dickson tower is exactly determined
  by the closed algebraic form `(censusPlateau, censusInteriorVal, censusZeroVal, censusMaxVal)`. -/
theorem tower_degree_census_closed_form_master :
    (∀ q : Nat, censusPlateau q = 21 * 2 ^ (q + 1)) ∧
    (censusZeroVal 3 = 684 ∧ censusInteriorVal 3 2 = 504 ∧ censusPlateau 3 = 336 ∧ censusMaxVal 3 = 870) ∧
    (censusZeroVal 4 = 1740 ∧ censusInteriorVal 4 3 = 1368 ∧ censusInteriorVal 4 2 = 1008 ∧ censusPlateau 4 = 672 ∧ censusMaxVal 4 = 2118) ∧
    (censusZeroVal 5 = 4236 ∧ censusInteriorVal 5 4 = 3480 ∧ censusInteriorVal 5 3 = 2736 ∧ censusInteriorVal 5 2 = 2016 ∧ censusPlateau 5 = 1344 ∧ censusMaxVal 5 = 4998) ∧
    (censusZeroVal 6 = 9996 ∧ censusInteriorVal 6 5 = 8472 ∧ censusInteriorVal 6 4 = 6960 ∧ censusInteriorVal 6 3 = 5472 ∧ censusInteriorVal 6 2 = 4032 ∧ censusPlateau 6 = 2688 ∧ censusMaxVal 6 = 11526) := by
  refine ⟨fun _ => rfl, census_dim64_closed_exact, census_dim128_closed_exact, census_dim256_closed_exact, census_dim512_closed_exact⟩

/-! ## 4. Bit-length arithmetic

`Nat.size t` is the number of binary digits of `t`; the three lemmas below are the doubling
laws of `Nat.size` used to track the leading bits of `t` along the census recursion. -/

theorem two_pow_size_le (t : Nat) (h : t ≠ 0) : 2 ^ Nat.size t ≤ 2 * t := by
  have h1 : 2 ^ (Nat.size t - 1) ≤ t := by
    rcases Nat.eq_zero_or_pos (Nat.size t) with h0 | h0
    · simp [Nat.size_eq_zero.mp h0] at h
    · exact Nat.lt_size.mp (by omega)
  have h2 : Nat.size t - 1 + 1 = Nat.size t := by
    rcases Nat.eq_zero_or_pos (Nat.size t) with h0 | h0
    · simp [Nat.size_eq_zero.mp h0] at h
    · omega
  calc (2:Nat) ^ Nat.size t = 2 * 2 ^ (Nat.size t - 1) := by rw [← pow_succ', h2]
  _ ≤ 2 * t := by omega

theorem size_two_mul_add_one (t : Nat) : Nat.size (2 * t + 1) = Nat.size t + 1 := by
  refine le_antisymm ?_ ?_
  · rw [Nat.size_le]
    have := Nat.lt_size_self t
    have : (2:Nat) ^ (Nat.size t + 1) = 2 * 2 ^ Nat.size t := by ring
    omega
  · rw [Nat.succ_le_iff, Nat.lt_size]
    rcases Nat.eq_zero_or_pos t with rfl | ht
    · simp
    · have := two_pow_size_le t (by omega); omega

theorem size_two_mul (t : Nat) (h : t ≠ 0) : Nat.size (2 * t) = Nat.size t + 1 := by
  refine le_antisymm ?_ ?_
  · rw [Nat.size_le]
    have := Nat.lt_size_self t
    have : (2:Nat) ^ (Nat.size t + 1) = 2 * 2 ^ Nat.size t := by ring
    omega
  · rw [Nat.succ_le_iff, Nat.lt_size]
    have := two_pow_size_le t h; omega

theorem size_two_pow_sub_one (q : Nat) : Nat.size (2 ^ q - 1) = q := by
  refine le_antisymm ?_ ?_
  · rw [Nat.size_le]
    have : (0:Nat) < 2 ^ q := Nat.two_pow_pos q
    omega
  · rcases Nat.eq_zero_or_pos q with rfl | hq
    · simp
    · rw [show q = (q - 1) + 1 from by omega, Nat.succ_le_iff, Nat.lt_size]
      have h1 : (2:Nat) ^ q = 2 * 2 ^ (q - 1) := by rw [← pow_succ']; congr 1; omega
      have h2 : (0:Nat) < 2 ^ (q - 1) := Nat.two_pow_pos _
      omega

/-! ## 5. The prefix depth of a degree index -/

/-- The number of leading zero bits of `t` read as a `q`-bit word. -/
def leadZeros (q t : Nat) : Nat := q - Nat.size t

/-- The **prefix depth** of `t < 2 ^ q`: the larger of the number of leading zeros and the
number of leading ones of the `q`-bit word `t`.  The census multiplicity of the degree
`8t + 4` depends on `t` only through this number. -/
def prefixDepth (q t : Nat) : Nat := max (leadZeros q t) (leadZeros q (2 ^ q - 1 - t))

/-- The prefix depth is invariant under complementation of the `q`-bit word. -/
theorem prefixDepth_symm (q t : Nat) (ht : t < 2 ^ q) :
    prefixDepth q (2 ^ q - 1 - t) = prefixDepth q t := by
  have h : 2 ^ q - 1 - (2 ^ q - 1 - t) = t := by omega
  simp [prefixDepth, h, Nat.max_comm]

theorem prefixDepth_zero (q : Nat) : prefixDepth q 0 = q := by
  simp [prefixDepth, leadZeros, size_two_pow_sub_one]

/-- Appending a one to the binary word leaves the prefix depth unchanged, as long as the
result is not the all-ones word. -/
theorem prefixDepth_odd (q t : Nat) (ht : t < 2 ^ q - 1) :
    prefixDepth (q + 1) (2 * t + 1) = prefixDepth q t := by
  have hc : 2 ^ (q + 1) - 1 - (2 * t + 1) = 2 * (2 ^ q - 1 - t) := by
    have : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    omega
  have hcne : 2 ^ q - 1 - t ≠ 0 := by omega
  simp only [prefixDepth, leadZeros, hc, size_two_mul_add_one, size_two_mul _ hcne]
  omega

/-- Appending a zero to a nonzero binary word leaves the prefix depth unchanged. -/
theorem prefixDepth_even (q t : Nat) (ht0 : t ≠ 0) (ht : t < 2 ^ q) :
    prefixDepth (q + 1) (2 * t) = prefixDepth q t := by
  have hc : 2 ^ (q + 1) - 1 - 2 * t = 2 * (2 ^ q - 1 - t) + 1 := by
    have : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    omega
  simp only [prefixDepth, leadZeros, hc, size_two_mul_add_one, size_two_mul _ ht0]
  omega

/-- An interior word has prefix depth at most `q - 1`: only `0` and `2 ^ q - 1` are
constant words. -/
theorem prefixDepth_le (q t : Nat) (ht0 : t ≠ 0) (ht : t < 2 ^ q - 1) :
    prefixDepth q t ≤ q - 1 := by
  have h1 : 1 ≤ Nat.size t := by
    rcases Nat.eq_zero_or_pos (Nat.size t) with h0 | h0
    · simp [Nat.size_eq_zero.mp h0] at ht0
    · omega
  have h2 : 1 ≤ Nat.size (2 ^ q - 1 - t) := by
    rcases Nat.eq_zero_or_pos (Nat.size (2 ^ q - 1 - t)) with h0 | h0
    · have := Nat.size_eq_zero.mp h0; omega
    · omega
  simp only [prefixDepth, leadZeros]
  omega

/-! ## 6. The doubling laws of the closed form -/

theorem censusWingExcess_eq_zero (q k : Nat) (hk : k ≤ 1) : censusWingExcess q k = 0 := by
  have h : k - 1 = 0 := by omega
  simp [censusWingExcess, h]

/-- The subtraction-free normal form of the wing excess, for `1 ≤ k ≤ q - 1`. -/
theorem censusWingExcess_norm (q k : Nat) (hq : 2 ≤ q) (hk : 1 ≤ k) (hkq : k ≤ q - 1) :
    censusWingExcess q k + 24 * 2 ^ (q - 2) = 24 * ((k - 1) * 2 ^ q) + 24 * 2 ^ (q - 1 - k) := by
  obtain ⟨r, rfl⟩ : ∃ r, q = r + 2 := ⟨q - 2, by omega⟩
  have h1 : (r + 2) - 2 = r := by omega
  have h2 : (r + 2) - 1 - k = r + 1 - k := by omega
  have hu : (2:Nat) ^ (r + 1 - k) ≤ 2 ^ r := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hb : (2:Nat) ^ r ≤ (k - 1) * 2 ^ (r + 2) ∨ k = 1 := by
    rcases Nat.lt_or_ge k 2 with h | h
    · right; omega
    · left
      calc (2:Nat) ^ r ≤ 2 ^ (r + 2) := Nat.pow_le_pow_right (by norm_num) (by omega)
      _ ≤ (k - 1) * 2 ^ (r + 2) := Nat.le_mul_of_pos_left _ (by omega)
  simp only [censusWingExcess, h1, h2]
  rcases hb with hb | rfl
  · omega
  · simp

theorem censusPlateau_succ (q : Nat) : censusPlateau (q + 1) = 2 * censusPlateau q := by
  simp [censusPlateau, pow_succ]; ring

theorem censusPlateau_le_interiorVal (q k : Nat) : censusPlateau q ≤ censusInteriorVal q k := by
  simp [censusInteriorVal]

theorem forty_two_le_censusInteriorVal (q k : Nat) : 42 ≤ censusInteriorVal q k := by
  have h := censusPlateau_le_interiorVal q k
  have h2 : (2:Nat) ≤ 2 ^ (q + 1) := by
    calc (2:Nat) = 2 ^ 1 := by norm_num
    _ ≤ 2 ^ (q + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  simp only [censusPlateau] at h
  omega

/-- **Interior doubling law.**  An interior multiplicity doubles from one dimension to the
next at a fixed prefix depth. -/
theorem censusInteriorVal_succ (q k : Nat) (hq : 2 ≤ q) (hkq : k ≤ q - 1) :
    censusInteriorVal (q + 1) k = 2 * censusInteriorVal q k := by
  rcases Nat.lt_or_ge k 1 with hk | hk
  · rw [censusInteriorVal, censusInteriorVal, censusWingExcess_eq_zero q k (by omega),
      censusWingExcess_eq_zero (q + 1) k (by omega), censusPlateau_succ]
    omega
  · have h1 := censusWingExcess_norm q k hq hk hkq
    have h2 := censusWingExcess_norm (q + 1) k (by omega) hk (by omega)
    rw [show (q + 1) - 2 = q - 1 from by omega, show (q + 1) - 1 - k = q - k from by omega,
      show (2:Nat) ^ (q - 1) = 2 * 2 ^ (q - 2) from by rw [← pow_succ']; congr 1; omega,
      show (2:Nat) ^ (q - k) = 2 * 2 ^ (q - 1 - k) from by rw [← pow_succ']; congr 1; omega,
      show (k - 1) * 2 ^ (q + 1) = 2 * ((k - 1) * 2 ^ q) from by rw [pow_succ]; ring] at h2
    simp only [censusInteriorVal, censusPlateau_succ]
    omega

/-- **Top-level law.**  The deepest interior multiplicity of dimension `2^(q+4)` is twice the
minimal-degree multiplicity of dimension `2^(q+3)`. -/
theorem censusInteriorVal_succ_top (q : Nat) (hq : 2 ≤ q) :
    censusInteriorVal (q + 1) q = 2 * censusZeroVal q := by
  have h2 := censusWingExcess_norm (q + 1) q (by omega) (by omega) (by omega)
  have h1 := censusWingExcess_norm q (q - 1) hq (by omega) (by omega)
  rw [show (q + 1) - 2 = q - 1 from by omega, show (q + 1) - 1 - q = 0 from by omega,
    show (2:Nat) ^ (q - 1) = 2 * 2 ^ (q - 2) from by rw [← pow_succ']; congr 1; omega,
    show (q - 1) * 2 ^ (q + 1) = 2 * ((q - 2) * 2 ^ q) + 2 * 2 ^ q from by
      obtain ⟨r, rfl⟩ : ∃ r, q = r + 2 := ⟨q - 2, by omega⟩
      simp only [show r + 2 - 1 = r + 1 from rfl, show r + 2 - 2 = r from rfl, pow_succ]
      ring] at h2
  rw [show q - 1 - (q - 1) = 0 from by omega, show q - 1 - 1 = q - 2 from by omega] at h1
  have hp : (2:Nat) ^ q = 4 * 2 ^ (q - 2) := by
    obtain ⟨r, rfl⟩ : ∃ r, q = r + 2 := ⟨q - 2, by omega⟩
    simp [pow_succ]; ring
  simp only [censusInteriorVal, censusZeroVal, censusPlateau_succ]
  omega

/-- **Minimal-degree law.**  The minimal-degree multiplicity of dimension `2^(q+4)` is twice
the maximal-degree multiplicity of dimension `2^(q+3)`. -/
theorem censusZeroVal_succ (q : Nat) (hq : 2 ≤ q) :
    censusZeroVal (q + 1) = 2 * censusMaxVal q := by
  have h := censusInteriorVal_succ_top q hq
  have hi := forty_two_le_censusInteriorVal q (q - 1)
  have hpow : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
  simp only [censusZeroVal, censusMaxVal, Nat.add_sub_cancel] at *
  omega

/-- **Maximal-degree law.**  The maximal-degree multiplicity doubles and picks up the
`6 (2^(q+3) - 1)` degenerate pairs created by the doubling step. -/
theorem censusMaxVal_succ (q : Nat) (hq : 2 ≤ q) :
    censusMaxVal (q + 1) = 2 * censusMaxVal q + 6 * (2 ^ (q + 3) - 1) := by
  have h := censusInteriorVal_succ_top q hq
  have hi := forty_two_le_censusInteriorVal q (q - 1)
  have hpow : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
  have hpow2 : (2:Nat) ^ (q + 1 + 1) = 4 * 2 ^ q := by ring
  have hpow3 : (2:Nat) ^ (q + 3) = 8 * 2 ^ q := by ring
  have h4 : (4:Nat) ≤ 2 ^ q := by
    calc (4:Nat) = 2 ^ 2 := by norm_num
    _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
  simp only [censusZeroVal, censusMaxVal, Nat.add_sub_cancel] at *
  omega

/-! ## 7. The closed form -/

/-- The **closed-form census**: the multiplicity of the degree `8t + 4` in dimension
`2^(q+3)`, read off the prefix depth of the `q`-bit word `t` without unwinding any
recursion. -/
def censusClosedForm (q t : Nat) : Nat :=
  if t = 0 then censusZeroVal q
  else if t = 2 ^ q - 1 then censusMaxVal q
  else censusInteriorVal q (prefixDepth q t)

/-- **The closed-form census formula.**  For every `q ≥ 2` and every `t < 2 ^ q` the descent
recursion `censusT` agrees with the closed form `censusClosedForm`. -/
theorem censusT_eq_censusClosedForm (q : Nat) (hq : 2 ≤ q) (t : Nat) (ht : t < 2 ^ q) :
    censusT q t = censusClosedForm q t := by
  induction q, hq using Nat.le_induction generalizing t with
  | base => interval_cases t <;> decide
  | succ q hq ih =>
    have hpow : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    have h4 : (4:Nat) ≤ 2 ^ q := by
      calc (4:Nat) = 2 ^ 2 := by norm_num
      _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
    rw [censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd]
      set s := t / 2 with hs
      have hts : t = 2 * s + 1 := by omega
      have hslt : s < 2 ^ q := by omega
      by_cases htop : t = 2 ^ (q + 1) - 1
      · have hsmax : s = 2 ^ q - 1 := by omega
        rw [if_pos htop, hsmax, ih (2 ^ q - 1) (by omega), censusClosedForm,
          if_neg (by omega : ¬ (2 ^ q - 1 = 0)), if_pos rfl, censusClosedForm,
          if_neg (by omega : ¬ t = 0), if_pos htop, censusMaxVal_succ q hq]
      · rw [if_neg htop, add_zero, censusClosedForm, if_neg (by omega : ¬ t = 0), if_neg htop]
        by_cases hs0 : s = 0
        · have hpd : prefixDepth (q + 1) t = q := by
            rw [hts, hs0, Nat.mul_zero, prefixDepth_odd q 0 (by omega), prefixDepth_zero]
          rw [hs0, ih 0 (by omega), censusClosedForm, if_pos rfl, hpd,
            censusInteriorVal_succ_top q hq]
        · have hsne : s ≠ 2 ^ q - 1 := by omega
          have hpd : prefixDepth (q + 1) t = prefixDepth q s := by
            rw [hts, prefixDepth_odd q s (by omega)]
          rw [ih s hslt, censusClosedForm, if_neg hs0, if_neg hsne, hpd,
            censusInteriorVal_succ q (prefixDepth q s) hq (prefixDepth_le q s hs0 (by omega))]
    · rw [if_neg hodd]
      set s := t / 2 with hs
      have hts : t = 2 * s := by omega
      have hslt : s < 2 ^ q := by omega
      rw [if_pos hslt]
      by_cases ht0 : t = 0
      · have hs0 : s = 0 := by omega
        rw [hs0, Nat.sub_zero, ih (2 ^ q - 1) (by omega), censusClosedForm,
          if_neg (by omega : ¬ (2 ^ q - 1 = 0)), if_pos rfl, censusClosedForm, if_pos ht0,
          censusZeroVal_succ q hq]
      · have hs0 : s ≠ 0 := by omega
        have hne : t ≠ 2 ^ (q + 1) - 1 := by omega
        have hpd : prefixDepth (q + 1) t = prefixDepth q s := by
          rw [hts, prefixDepth_even q s hs0 hslt]
        rw [censusClosedForm, if_neg ht0, if_neg hne]
        by_cases hsmax : s = 2 ^ q - 1
        · rw [hsmax]
          simp only [Nat.sub_self]
          rw [ih 0 (by omega), censusClosedForm, if_pos rfl, hpd, hsmax,
            show prefixDepth q (2 ^ q - 1) = q from by
              rw [show (2:Nat) ^ q - 1 = 2 ^ q - 1 - 0 from by omega,
                prefixDepth_symm q 0 (by omega), prefixDepth_zero],
            censusInteriorVal_succ_top q hq]
        · have hc0 : 2 ^ q - 1 - s ≠ 0 := by omega
          have hcne : 2 ^ q - 1 - s ≠ 2 ^ q - 1 := by omega
          rw [ih (2 ^ q - 1 - s) (by omega), censusClosedForm, if_neg hc0, if_neg hcne,
            prefixDepth_symm q s hslt, hpd,
            censusInteriorVal_succ q (prefixDepth q s) hq (prefixDepth_le q s hs0 (by omega))]

/-- **The degree census in closed form.**  In dimension `2^(q+3)` (`q ≥ 2`) the number of
ordered admissible index pairs whose outer pair has exactly `8t + 4` non-associating middles
is `censusClosedForm q t`, an `O(1)` expression in the prefix depth of `t`. -/
theorem degreeCount_eq_censusClosedForm (q : Nat) (hq : 2 ≤ q) (t : Nat) (ht : t < 2 ^ q) :
    degreeCount (q + 3) (8 * t + 4) = censusClosedForm q t := by
  rw [degreeCount_eq_censusT, censusT_eq_censusClosedForm q hq t ht]

/-- The census is a symmetric staircase: complementary degrees have equal multiplicities. -/
theorem degreeCount_symm (q : Nat) (hq : 2 ≤ q) (t : Nat) (ht0 : t ≠ 0) (ht : t < 2 ^ q - 1) :
    degreeCount (q + 3) (8 * (2 ^ q - 1 - t) + 4) = degreeCount (q + 3) (8 * t + 4) := by
  have hc0 : 2 ^ q - 1 - t ≠ 0 := by omega
  have hcne : 2 ^ q - 1 - t ≠ 2 ^ q - 1 := by omega
  rw [degreeCount_eq_censusClosedForm q hq _ (by omega),
    degreeCount_eq_censusClosedForm q hq t (by omega), censusClosedForm, censusClosedForm,
    if_neg hc0, if_neg hcne, if_neg ht0, if_neg (by omega : ¬ t = 2 ^ q - 1),
    prefixDepth_symm q t (by omega)]

end Sovereign
