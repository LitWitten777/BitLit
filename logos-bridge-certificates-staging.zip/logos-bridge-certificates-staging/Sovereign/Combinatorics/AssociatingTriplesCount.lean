import Sovereign.Algebra.TowerAlternative
import Sovereign.Combinatorics.TowerDegreeSpectrum

namespace Sovereign

open Finset

/-! ## 1. The commutation defect -/

/-- The commutation defect of two indices: `true` exactly when `e_b` and `e_c`
anticommute. -/
def commNeg (b c : Nat) : Bool := decide (b ≠ 0 ∧ c ≠ 0 ∧ b ≠ c)

theorem conjNeg_xor_triple (b c : Nat) :
    xor (conjNeg b) (xor (conjNeg c) (conjNeg (b ^^^ c))) = commNeg b c := by
  have hx : (b ^^^ c = 0) ↔ b = c := Nat.xor_eq_zero_iff
  by_cases hb : b = 0
  · subst hb; simp [conjNeg, commNeg]
  · by_cases hc : c = 0
    · subst hc; simp [conjNeg, commNeg, hb]
    · by_cases hbc : b = c
      · subst hbc; simp [conjNeg, commNeg]
      · have : b ^^^ c ≠ 0 := fun h => hbc (hx.mp h)
        simp [conjNeg, commNeg, hb, hc, hbc, this]

theorem epsNeg_swap_eq_commNeg (n a b : Nat) (ha : a < 2 ^ n) (hb : b < 2 ^ n) :
    xor (epsNeg n a b) (epsNeg n b a) = commNeg a b :=
  epsNeg_xor_swap n a b ha hb

/-! ## 2. The four low sector signs -/

/-- Sector `(0,0,1)`: the associator sign of `(e_a, e_b, e_{d+c})`. -/
def sec001 (n a b c : Nat) : Bool :=
  xor (xor (epsNeg n a b) (epsNeg n c (a ^^^ b))) (xor (epsNeg n c b) (epsNeg n (b ^^^ c) a))

/-- Sector `(0,1,0)`: the associator sign of `(e_a, e_{d+b}, e_c)`. -/
def sec010 (n a b c : Nat) : Bool :=
  xor (xor (epsNeg n b a) (epsNeg n (a ^^^ b) c)) (xor (epsNeg n b c) (epsNeg n (b ^^^ c) a))

/-- Sector `(0,1,1)`: the associator sign of `(e_a, e_{d+b}, e_{d+c})`. -/
def sec011 (n a b c : Nat) : Bool :=
  xor (xor (epsNeg n b a) (epsNeg n c (a ^^^ b))) (xor (epsNeg n c b) (epsNeg n a (b ^^^ c)))

theorem assocNeg_succ_llh (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) a b (2 ^ m + c) = sec001 m a b c := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx : b ^^^ (2 ^ m + c) = 2 ^ m + (b ^^^ c) := xor_low_high hb hc
  simp only [assocNeg, sec001, hx, epsNeg_succ_low_low m a b ha hb,
    epsNeg_succ_low_high m (a ^^^ b) c hab, epsNeg_succ_low_high m b c hb,
    epsNeg_succ_low_high m a (b ^^^ c) ha]

theorem assocNeg_succ_lhl (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) a (2 ^ m + b) c = sec010 m a b c := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : a ^^^ (2 ^ m + b) = 2 ^ m + (a ^^^ b) := xor_low_high ha hb
  have hx2 : (2 ^ m + b) ^^^ c = 2 ^ m + (b ^^^ c) := xor_high_low hb hc
  simp only [assocNeg, sec010, hx1, hx2, epsNeg_succ_low_high m a b ha,
    epsNeg_succ_high_low m (a ^^^ b) c hc, epsNeg_succ_high_low m b c hc,
    epsNeg_succ_low_high m a (b ^^^ c) ha]
  cases conjNeg c <;> cases epsNeg m b a <;> cases epsNeg m (a ^^^ b) c <;>
    cases epsNeg m b c <;> cases epsNeg m (b ^^^ c) a <;> rfl

theorem assocNeg_succ_lhh (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) a (2 ^ m + b) (2 ^ m + c) = sec011 m a b c := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : a ^^^ (2 ^ m + b) = 2 ^ m + (a ^^^ b) := xor_low_high ha hb
  have hx2 : (2 ^ m + b) ^^^ (2 ^ m + c) = b ^^^ c := xor_high_high hb hc
  simp only [assocNeg, sec011, hx1, hx2, epsNeg_succ_low_high m a b ha,
    epsNeg_succ_high_high m (a ^^^ b) c, epsNeg_succ_high_high m b c,
    epsNeg_succ_low_low m a (b ^^^ c) ha hbc]
  cases conjNeg c <;> cases epsNeg m b a <;> cases epsNeg m c (a ^^^ b) <;>
    cases epsNeg m c b <;> cases epsNeg m a (b ^^^ c) <;> rfl

/-! ## 3. The high sectors differ by the commutation defect -/

theorem assocNeg_succ_hll (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m + a) b c = xor (assocNeg m a b c) (commNeg b c) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : (2 ^ m + a) ^^^ b = 2 ^ m + (a ^^^ b) := xor_high_low ha hb
  have hd := conjNeg_xor_triple b c
  simp only [assocNeg, hx1, epsNeg_succ_high_low m a b hb,
    epsNeg_succ_high_low m (a ^^^ b) c hc, epsNeg_succ_low_low m b c hb hc,
    epsNeg_succ_high_low m a (b ^^^ c) hbc]
  rw [← hd]
  cases conjNeg b <;> cases conjNeg c <;> cases conjNeg (b ^^^ c) <;>
    cases epsNeg m a b <;> cases epsNeg m (a ^^^ b) c <;> cases epsNeg m b c <;>
    cases epsNeg m a (b ^^^ c) <;> rfl

theorem assocNeg_succ_hlh (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m + a) b (2 ^ m + c) = xor (sec001 m a b c) (commNeg b c) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : (2 ^ m + a) ^^^ b = 2 ^ m + (a ^^^ b) := xor_high_low ha hb
  have hx2 : b ^^^ (2 ^ m + c) = 2 ^ m + (b ^^^ c) := xor_low_high hb hc
  have hd := conjNeg_xor_triple b c
  simp only [assocNeg, sec001, hx1, hx2, epsNeg_succ_high_low m a b hb,
    epsNeg_succ_high_high m (a ^^^ b) c, epsNeg_succ_low_high m b c hb,
    epsNeg_succ_high_high m a (b ^^^ c)]
  rw [← hd]
  cases conjNeg b <;> cases conjNeg c <;> cases conjNeg (b ^^^ c) <;>
    cases epsNeg m a b <;> cases epsNeg m c (a ^^^ b) <;> cases epsNeg m c b <;>
    cases epsNeg m (b ^^^ c) a <;> rfl

theorem assocNeg_succ_hhl (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c = xor (sec010 m a b c) (commNeg b c) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : (2 ^ m + a) ^^^ (2 ^ m + b) = a ^^^ b := xor_high_high ha hb
  have hx2 : (2 ^ m + b) ^^^ c = 2 ^ m + (b ^^^ c) := xor_high_low hb hc
  have hd := conjNeg_xor_triple b c
  simp only [assocNeg, sec010, hx1, hx2, epsNeg_succ_high_high m a b,
    epsNeg_succ_low_low m (a ^^^ b) c hab hc, epsNeg_succ_high_low m b c hc,
    epsNeg_succ_high_high m a (b ^^^ c)]
  rw [← hd]
  cases conjNeg b <;> cases conjNeg c <;> cases conjNeg (b ^^^ c) <;>
    cases epsNeg m b a <;> cases epsNeg m (a ^^^ b) c <;> cases epsNeg m b c <;>
    cases epsNeg m (b ^^^ c) a <;> rfl

theorem assocNeg_succ_hhh (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hc : c < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) (2 ^ m + c)
      = xor (sec011 m a b c) (commNeg b c) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have hx1 : (2 ^ m + a) ^^^ (2 ^ m + b) = a ^^^ b := xor_high_high ha hb
  have hx2 : (2 ^ m + b) ^^^ (2 ^ m + c) = b ^^^ c := xor_high_high hb hc
  have hd := conjNeg_xor_triple b c
  simp only [assocNeg, sec011, hx1, hx2, epsNeg_succ_high_high m a b,
    epsNeg_succ_low_high m (a ^^^ b) c hab, epsNeg_succ_high_high m b c,
    epsNeg_succ_high_low m a (b ^^^ c) hbc]
  rw [← hd]
  cases conjNeg b <;> cases conjNeg c <;> cases conjNeg (b ^^^ c) <;>
    cases epsNeg m b a <;> cases epsNeg m c (a ^^^ b) <;> cases epsNeg m c b <;>
    cases epsNeg m a (b ^^^ c) <;> rfl

/-! ## 4. The four low sectors on the degenerate locus `commNeg b c = false` -/

/-- Middle index `0`. -/
theorem sec001_mid_zero (m a c : Nat) : sec001 m a 0 c = false := by
  simp only [sec001, Nat.xor_zero, Nat.zero_xor, epsNeg_zero_right]
  cases epsNeg m c a <;> rfl

theorem sec010_mid_zero (m a c : Nat) (ha : a < 2 ^ m) (hc : c < 2 ^ m) :
    sec010 m a 0 c = commNeg a c := by
  have h := epsNeg_swap_eq_commNeg m a c ha hc
  simp only [sec010, Nat.xor_zero, Nat.zero_xor, epsNeg_zero_left]
  rw [← h]
  cases epsNeg m a c <;> cases epsNeg m c a <;> rfl

theorem sec011_mid_zero (m a c : Nat) (ha : a < 2 ^ m) (hc : c < 2 ^ m) :
    sec011 m a 0 c = commNeg a c := by
  have h := epsNeg_swap_eq_commNeg m a c ha hc
  simp only [sec011, Nat.xor_zero, Nat.zero_xor, epsNeg_zero_left, epsNeg_zero_right]
  rw [← h]
  cases epsNeg m a c <;> cases epsNeg m c a <;> rfl

/-- Last index `0`. -/
theorem sec001_last_zero (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec001 m a b 0 = commNeg a b := by
  have h := epsNeg_swap_eq_commNeg m a b ha hb
  simp only [sec001, Nat.xor_zero, epsNeg_zero_left]
  rw [← h]
  cases epsNeg m a b <;> cases epsNeg m b a <;> rfl

theorem sec010_last_zero (m a b : Nat) : sec010 m a b 0 = false := by
  simp only [sec010, Nat.xor_zero, epsNeg_zero_right]
  cases epsNeg m b a <;> rfl

theorem sec011_last_zero (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec011 m a b 0 = commNeg a b := by
  have h := epsNeg_swap_eq_commNeg m a b ha hb
  simp only [sec011, Nat.xor_zero, epsNeg_zero_left]
  rw [← h]
  cases epsNeg m a b <;> cases epsNeg m b a <;> rfl

/-- Repeated index `c = b`. -/
theorem sec001_repeat (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) (hb0 : b ≠ 0) :
    sec001 m a b b = decide (a ≠ 0 ∧ a ≠ b) := by
  have hcyc := epsNeg_cyclic m a b ha hb
  have hself := epsNeg_self m b hb
  have hcb : conjNeg b = true := by simp [conjNeg, hb0]
  simp only [sec001, Nat.xor_self, epsNeg_zero_left, hself, hcb]
  rw [show xor (xor (epsNeg m a b) (epsNeg m b (a ^^^ b))) (xor true false)
      = xor (xor (epsNeg m a b) (epsNeg m b (a ^^^ b))) true from rfl, hcyc]
  by_cases h1 : a = 0
  · simp [h1, hb0]
  · by_cases h2 : a = b
    · simp [h2, hb0]
    · simp [h1, h2, hb0]

theorem sec010_repeat (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec010 m a b b = commNeg a b := by
  have hshift := epsNeg_right_shift m a b ha hb
  have hswap := epsNeg_swap_eq_commNeg m a b ha hb
  have hself := epsNeg_self m b hb
  simp only [sec010, Nat.xor_self, epsNeg_zero_left, hself]
  rw [← hswap]
  revert hshift
  cases epsNeg m a b <;> cases epsNeg m b a <;> cases epsNeg m (a ^^^ b) b <;>
    cases conjNeg b <;> simp

theorem sec011_repeat (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec011 m a b b = false := by
  have hshift := epsNeg_left_shift m b a hb ha
  have hself := epsNeg_self m b hb
  have hxc : a ^^^ b = b ^^^ a := Nat.xor_comm a b
  simp only [sec011, Nat.xor_self, epsNeg_zero_right, hself, hxc]
  revert hshift
  cases epsNeg m b a <;> cases epsNeg m b (b ^^^ a) <;> cases conjNeg b <;> simp

/-! ## 5. The pointwise eight-sector count -/

/-- Indicator of an associating triple. -/
def indA (s : Bool) : Nat := if s = false then 1 else 0

/-- The index that controls the degenerate locus: on `b = 0 ∨ c = 0 ∨ b = c` the four low
sectors are determined by `a` and `wIdx b c`. -/
def wIdx (b c : Nat) : Nat := if b = 0 then c else b

/-- The predicate counting the extra associating triples on the degenerate locus. -/
def qFlag (a b c : Nat) : Bool :=
  decide ((b = 0 ∨ c = 0 ∨ b = c) ∧ (a = 0 ∨ wIdx b c = 0 ∨ a = wIdx b c))

/-- **Pointwise sector count.** For fixed low indices `a, b, c < 2ᵐ` the eight sectors of
the doubling step contain exactly `4` associating triples off the degenerate locus, and
`8` on it.  In particular the count never refers to the level-`m` signs. -/
theorem sector_assoc_count (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m)
    (hc : c < 2 ^ m) :
    indA (assocNeg (m + 1) a b c) + indA (assocNeg (m + 1) a b (2 ^ m + c))
      + indA (assocNeg (m + 1) a (2 ^ m + b) c)
      + indA (assocNeg (m + 1) a (2 ^ m + b) (2 ^ m + c))
      + indA (assocNeg (m + 1) (2 ^ m + a) b c)
      + indA (assocNeg (m + 1) (2 ^ m + a) b (2 ^ m + c))
      + indA (assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c)
      + indA (assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) (2 ^ m + c))
      = 4 + 4 * indA (!(qFlag a b c)) := by
  rw [Sovereign.assocNeg_succ_low m a b c ha hb hc, assocNeg_succ_llh m a b c ha hb hc,
    assocNeg_succ_lhl m a b c ha hb hc, assocNeg_succ_lhh m a b c ha hb hc,
    assocNeg_succ_hll m a b c ha hb hc, assocNeg_succ_hlh m a b c ha hb hc,
    assocNeg_succ_hhl m a b c ha hb hc, assocNeg_succ_hhh m a b c ha hb hc]
  by_cases hcomm : commNeg b c = true
  · -- off the degenerate locus: the high sectors flip every low sector
    have hq : qFlag a b c = false := by
      have h : b ≠ 0 ∧ c ≠ 0 ∧ b ≠ c := by simpa [commNeg] using hcomm
      simp [qFlag, h.1, h.2.1, h.2.2]
    rw [hcomm, hq]
    cases assocNeg m a b c <;> cases sec001 m a b c <;> cases sec010 m a b c <;>
      cases sec011 m a b c <;> rfl
  · -- the degenerate locus `b = 0 ∨ c = 0 ∨ b = c`
    have hcf : commNeg b c = false := by simpa using hcomm
    have hdeg : b = 0 ∨ c = 0 ∨ b = c := by
      by_contra h
      push_neg at h
      exact hcomm (by simp [commNeg, h.1, h.2.1, h.2.2])
    rw [hcf]
    have hxf : ∀ s : Bool, xor s false = s := fun s => by cases s <;> rfl
    simp only [hxf]
    rcases hdeg with hb0 | hc0 | hbc
    · -- middle index zero
      subst hb0
      have e0 : assocNeg m a 0 c = false := assocNeg_zero_mid m a c
      have e1 : sec001 m a 0 c = false := sec001_mid_zero m a c
      have e2 : sec010 m a 0 c = commNeg a c := sec010_mid_zero m a c ha hc
      have e3 : sec011 m a 0 c = commNeg a c := sec011_mid_zero m a c ha hc
      have hq : qFlag a 0 c = !(commNeg a c) := by
        by_cases h1 : a = 0
        · simp [qFlag, wIdx, commNeg, h1]
        · by_cases h2 : c = 0
          · simp [qFlag, wIdx, commNeg, h2]
          · by_cases h3 : a = c
            · simp [qFlag, wIdx, commNeg, h3]
            · simp [qFlag, wIdx, commNeg, h1, h2, h3]
      rw [e0, e1, e2, e3, hq]
      cases commNeg a c <;> rfl
    · -- last index zero
      subst hc0
      have e0 : assocNeg m a b 0 = false := assocNeg_zero_right m a b
      have e1 : sec001 m a b 0 = commNeg a b := sec001_last_zero m a b ha hb
      have e2 : sec010 m a b 0 = false := sec010_last_zero m a b
      have e3 : sec011 m a b 0 = commNeg a b := sec011_last_zero m a b ha hb
      have hq : qFlag a b 0 = !(commNeg a b) := by
        by_cases h1 : a = 0
        · simp [qFlag, wIdx, commNeg, h1]
        · by_cases h2 : b = 0
          · simp [qFlag, wIdx, commNeg, h2]
          · by_cases h3 : a = b
            · simp [qFlag, wIdx, commNeg, h3]
            · simp [qFlag, wIdx, commNeg, h1, h2, h3]
      rw [e0, e1, e2, e3, hq]
      cases commNeg a b <;> rfl
    · -- repeated index
      subst hbc
      by_cases hb0 : b = 0
      · subst hb0
        have e0 : assocNeg m a 0 0 = false := assocNeg_zero_mid m a 0
        have e1 : sec001 m a 0 0 = false := sec001_mid_zero m a 0
        have e2 : sec010 m a 0 0 = commNeg a 0 := sec010_mid_zero m a 0 ha hb
        have e3 : sec011 m a 0 0 = commNeg a 0 := sec011_mid_zero m a 0 ha hb
        have hc0 : commNeg a 0 = false := by simp [commNeg]
        have hq : qFlag a 0 0 = true := by simp [qFlag, wIdx]
        rw [e0, e1, e2, e3, hc0, hq]
        rfl
      · have e0 : assocNeg m a b b = false := assocNeg_right_alt m a b ha hb
        have e1 : sec001 m a b b = decide (a ≠ 0 ∧ a ≠ b) := sec001_repeat m a b ha hb hb0
        have e2 : sec010 m a b b = commNeg a b := sec010_repeat m a b ha hb
        have e3 : sec011 m a b b = false := sec011_repeat m a b ha hb
        have hcomm' : commNeg a b = decide (a ≠ 0 ∧ a ≠ b) := by
          by_cases h1 : a = 0
          · simp [commNeg, h1]
          · by_cases h3 : a = b
            · simp [commNeg, h3, hb0]
            · simp [commNeg, h1, h3, hb0]
        have hq : qFlag a b b = !(decide (a ≠ 0 ∧ a ≠ b)) := by
          by_cases h1 : a = 0
          · simp [qFlag, wIdx, h1, hb0]
          · by_cases h3 : a = b
            · simp [qFlag, wIdx, h3, hb0]
            · simp [qFlag, wIdx, h1, h3, hb0]
        rw [e0, e1, e2, e3, hcomm', hq]
        cases hd : decide (a ≠ 0 ∧ a ≠ b) <;> rfl

/-! ## 6. Summing the pointwise count -/

/-- A triple sum over a doubled range splits into the eight sectors of the doubling step. -/
theorem sum_triple_range_double (d : Nat) (f : Nat → Nat → Nat → Nat) :
    ∑ a ∈ range (d + d), ∑ b ∈ range (d + d), ∑ c ∈ range (d + d), f a b c
      = ∑ a ∈ range d, ∑ b ∈ range d, ∑ c ∈ range d,
        (f a b c + f a b (d + c) + f a (d + b) c + f a (d + b) (d + c)
          + f (d + a) b c + f (d + a) b (d + c) + f (d + a) (d + b) c
          + f (d + a) (d + b) (d + c)) := by
  simp only [Finset.sum_range_add, Finset.sum_add_distrib]
  ring

/-- The associating-triple count as an iterated sum of indicators. -/
theorem card_filter_triple_eq_sum (N : Nat) (f : Nat → Nat → Nat → Bool) :
    (((Finset.range N) ×ˢ (Finset.range N) ×ˢ (Finset.range N)).filter
        (fun t => f t.1 t.2.1 t.2.2 = false)).card
      = ∑ a ∈ range N, ∑ b ∈ range N, ∑ c ∈ range N, indA (f a b c) := by
  rw [Finset.card_filter, Finset.sum_product]
  refine Finset.sum_congr rfl (fun a _ => ?_)
  rw [Finset.sum_product]
  simp [indA]

theorem associatingTriples_eq_sum (n : Nat) :
    associatingTriples n
      = ∑ a ∈ range (2 ^ n), ∑ b ∈ range (2 ^ n), ∑ c ∈ range (2 ^ n),
          indA (assocNeg n a b c) :=
  card_filter_triple_eq_sum (2 ^ n) (assocNeg n)

/-! ### The degenerate-locus count -/

theorem sum_range_ite_single (d k v : Nat) (hk : k < d) :
    ∑ c ∈ range d, (if c = k then v else 0) = v := by
  rw [Finset.sum_ite_eq' (range d) k (fun _ => v)]
  simp [hk]

theorem sum_range_ite_pair (d k l : Nat) (hk : k < d) (hl : l < d) (hkl : k ≠ l) :
    ∑ c ∈ range d, (if c = k ∨ c = l then (1 : Nat) else 0) = 2 := by
  have h : ∀ c, (if c = k ∨ c = l then (1 : Nat) else 0)
      = (if c = k then 1 else 0) + (if c = l then 1 else 0) := by
    intro c
    by_cases h1 : c = k <;> by_cases h2 : c = l <;> simp_all
  rw [Finset.sum_congr rfl (fun c _ => h c), Finset.sum_add_distrib,
    sum_range_ite_single d k 1 hk, sum_range_ite_single d l 1 hl]

/-- The degenerate-locus indicator, summed over the last index. -/
theorem qsum_last (d a b : Nat) (ha : a < d) (hb : b < d) :
    ∑ c ∈ range d, indA (!(qFlag a b c))
      = if b = 0 then (if a = 0 then d else 2) else (if a = 0 ∨ a = b then 2 else 0) := by
  have hd : 0 < d := Nat.lt_of_le_of_lt (Nat.zero_le a) ha
  by_cases hb0 : b = 0
  · subst hb0
    by_cases ha0 : a = 0
    · subst ha0
      have h : ∀ c, indA (!(qFlag 0 0 c)) = 1 := by
        intro c; simp [indA, qFlag, wIdx]
      rw [Finset.sum_congr rfl (fun c _ => h c)]
      simp
    · have h : ∀ c, indA (!(qFlag a 0 c)) = if c = 0 ∨ c = a then 1 else 0 := by
        intro c
        by_cases h1 : c = 0
        · simp [indA, qFlag, wIdx, h1]
        · by_cases h2 : c = a
          · simp [indA, qFlag, wIdx, h2, ha0]
          · have h3 : ¬ (a = c) := fun h => h2 h.symm
            simp [indA, qFlag, wIdx, h1, h2, h3, ha0]
      rw [Finset.sum_congr rfl (fun c _ => h c),
        sum_range_ite_pair d 0 a hd ha (Ne.symm ha0)]
      simp [ha0]
  · by_cases hab : a = 0 ∨ a = b
    · have h : ∀ c, indA (!(qFlag a b c)) = if c = 0 ∨ c = b then 1 else 0 := by
        intro c
        rcases hab with h0 | h0
        · subst h0
          by_cases h1 : c = 0
          · simp [indA, qFlag, wIdx, h1]
          · by_cases h2 : c = b
            · simp [indA, qFlag, wIdx, h2, hb0]
            · simp [indA, qFlag, wIdx, h1, h2, hb0, Ne.symm h2]
        · subst h0
          by_cases h1 : c = 0
          · simp [indA, qFlag, wIdx, h1, hb0]
          · by_cases h2 : c = a
            · simp [indA, qFlag, wIdx, h2, hb0]
            · simp [indA, qFlag, wIdx, h1, h2, hb0, Ne.symm h2]
      rw [Finset.sum_congr rfl (fun c _ => h c),
        sum_range_ite_pair d 0 b hd hb (Ne.symm hb0)]
      simp [hb0, hab]
    · push_neg at hab
      have h : ∀ c, indA (!(qFlag a b c)) = 0 := by
        intro c
        have hne : ¬ (a = 0 ∨ wIdx b c = 0 ∨ a = wIdx b c) := by
          simp [wIdx, hb0, hab.1, hab.2]
        simp [indA, qFlag, hne]
      rw [Finset.sum_congr rfl (fun c _ => h c)]
      simp [hb0, hab.1, hab.2]

/-- The degenerate-locus indicator, summed over the last two indices. -/
theorem qsum_mid_last (d a : Nat) (ha : a < d) :
    ∑ b ∈ range d, ∑ c ∈ range d, indA (!(qFlag a b c))
      = if a = 0 then 3 * d - 2 else 4 := by
  have hd : 0 < d := Nat.lt_of_le_of_lt (Nat.zero_le a) ha
  rw [Finset.sum_congr rfl (fun b hb => qsum_last d a b ha (Finset.mem_range.mp hb))]
  by_cases ha0 : a = 0
  · subst ha0
    have h : ∀ b, (if b = 0 then (if (0 : Nat) = 0 then d else 2)
        else (if (0 : Nat) = 0 ∨ 0 = b then 2 else 0)) = if b = 0 then d else 2 := by
      intro b
      by_cases hb : b = 0 <;> simp [hb]
    rw [Finset.sum_congr rfl (fun b _ => h b),
      ← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hd)]
    have herase : ∀ b ∈ (range d).erase 0, (if b = 0 then d else 2) = 2 := by
      intro b hb
      simp [Finset.ne_of_mem_erase hb]
    rw [Finset.sum_congr rfl herase, Finset.sum_const, smul_eq_mul,
      Finset.card_erase_of_mem (Finset.mem_range.mpr hd), Finset.card_range]
    simp only [if_true]
    omega
  · have h : ∀ b, (if b = 0 then (if a = 0 then d else 2)
        else (if a = 0 ∨ a = b then 2 else 0))
        = (if b = 0 then 2 else 0) + (if b = a then 2 else 0) := by
      intro b
      by_cases hb : b = 0
      · simp [hb, ha0, Ne.symm ha0]
      · by_cases hba : b = a
        · simp [hba, ha0]
        · simp [hb, hba, ha0, Ne.symm hba]
    rw [Finset.sum_congr rfl (fun b _ => h b), Finset.sum_add_distrib,
      sum_range_ite_single d 0 2 hd, sum_range_ite_single d a 2 ha]
    simp [ha0]

/-- The total number of degenerate-locus triples in `[0,d)³` is `7d - 6`. -/
theorem qsum_total (d : Nat) (hd : 0 < d) :
    (∑ a ∈ range d, ∑ b ∈ range d, ∑ c ∈ range d, indA (!(qFlag a b c))) + 6 = 7 * d := by
  rw [Finset.sum_congr rfl (fun a ha => qsum_mid_last d a (Finset.mem_range.mp ha)),
    ← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hd)]
  have herase : ∀ a ∈ (range d).erase 0, (if a = 0 then 3 * d - 2 else 4) = 4 := by
    intro a ha
    simp [Finset.ne_of_mem_erase ha]
  rw [Finset.sum_congr rfl herase, Finset.sum_const, smul_eq_mul,
    Finset.card_erase_of_mem (Finset.mem_range.mpr hd), Finset.card_range]
  simp only [if_true]
  omega

/-! ## 7. The counting law -/

/-- **Doubling formula.** In dimension `D = 2ᵐ⁺¹` the number of associating basis triples is
`4 (2ᵐ)³ + 28 · 2ᵐ - 24 = D³/2 + 14 D - 24`. -/
theorem associatingTriples_succ (m : Nat) :
    associatingTriples (m + 1) + 24 = 4 * (2 ^ m) ^ 3 + 28 * 2 ^ m := by
  have hd : 0 < 2 ^ m := Nat.two_pow_pos m
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by rw [pow_succ]; ring
  rw [associatingTriples_eq_sum, hpow, sum_triple_range_double,
    Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (fun b hb =>
      Finset.sum_congr rfl (fun c hc =>
        sector_assoc_count m a b c (Finset.mem_range.mp ha) (Finset.mem_range.mp hb)
          (Finset.mem_range.mp hc))))]
  simp only [Finset.sum_add_distrib, Finset.sum_const, Finset.card_range, smul_eq_mul,
    ← Finset.mul_sum]
  have hq := qsum_total (2 ^ m) hd
  ring_nf
  ring_nf at hq
  omega

/-- **The associating-triple counting law of the Cayley–Dickson tower.**  For every
dimension `D = 2ⁿ ≥ 2` of the tower the number of ordered triples of basis vectors that
associate is exactly `D³/2 + 14 D - 24`. -/
theorem associatingTriples_formula (n : Nat) (hn : 1 ≤ n) :
    associatingTriples n + 24 = 2 ^ (3 * n - 1) + 14 * 2 ^ n := by
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  have h := associatingTriples_succ m
  have h1 : 2 ^ (3 * (m + 1) - 1) = 4 * (2 ^ m) ^ 3 := by
    have : 3 * (m + 1) - 1 = 3 * m + 2 := by omega
    rw [this, pow_add, ← pow_mul, Nat.mul_comm m 3, pow_mul]
    ring
  have h2 : 14 * 2 ^ (m + 1) = 28 * 2 ^ m := by rw [pow_succ]; ring
  rw [h1, h2]
  exact h

/-- The same law in the "halved cube" form: `2 A(D) + 48 = D³ + 28 D`. -/
theorem associatingTriples_formula_dim (n : Nat) (hn : 1 ≤ n) :
    2 * associatingTriples n + 48 = (2 ^ n) ^ 3 + 28 * 2 ^ n := by
  have h := associatingTriples_formula n hn
  have h1 : 2 * 2 ^ (3 * n - 1) = (2 ^ n) ^ 3 := by
    obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
    have he : 3 * (m + 1) - 1 = 3 * m + 2 := by omega
    have hr : ((2 : Nat) ^ (m + 1)) ^ 3 = 2 ^ (3 * m + 3) := by
      rw [← pow_mul]
      congr 1
      omega
    rw [he, hr, ← pow_succ']
  omega

/-! ## 8. The count of associating triples of basis vectors -/

/-- The number of ordered triples of basis vectors of `Tower n` that associate, stated
directly in terms of the algebra product. -/
def associatingBasisTriples (n : Nat) : Nat :=
  (((Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n))).filter
    (fun t => (basis n t.1 * basis n t.2.1) * basis n t.2.2
      = basis n t.1 * (basis n t.2.1 * basis n t.2.2))).card

theorem associatingBasisTriples_eq (n : Nat) :
    associatingBasisTriples n = associatingTriples n := by
  rw [associatingBasisTriples, associatingTriples]
  refine congrArg Finset.card (Finset.filter_congr (fun t ht => ?_))
  obtain ⟨a, b, c⟩ := t
  simp only [Finset.mem_product, Finset.mem_range] at ht
  exact basis_assoc_eq_iff n a b c ht.1 ht.2.1 ht.2.2

/-- **The counting law, in algebraic form.**  In the Cayley–Dickson algebra of dimension
`D = 2ⁿ ≥ 2` exactly `D³/2 + 14 D - 24` of the `D³` ordered triples of basis vectors
satisfy `(e_a e_b) e_c = e_a (e_b e_c)`. -/
theorem associatingBasisTriples_formula (n : Nat) (hn : 1 ≤ n) :
    associatingBasisTriples n + 24 = 2 ^ (3 * n - 1) + 14 * 2 ^ n := by
  rw [associatingBasisTriples_eq]
  exact associatingTriples_formula n hn

/-! ## 9. The complementary count -/

/-- The number of ordered basis triples of the `2ⁿ`-dimensional algebra that fail to
associate. -/
def nonAssociatingTriples (n : Nat) : Nat :=
  (((Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n))).filter
    (fun t => assocNeg n t.1 t.2.1 t.2.2 = true)).card

theorem associating_add_nonassociating (n : Nat) :
    associatingTriples n + nonAssociatingTriples n = (2 ^ n) ^ 3 := by
  classical
  set S := (Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n)) ×ˢ (Finset.range (2 ^ n)) with hS
  have hcard : S.card = (2 ^ n) ^ 3 := by
    rw [hS]
    simp [Finset.card_product, Finset.card_range]
    ring
  have hfil : (S.filter (fun t => ¬ (assocNeg n t.1 t.2.1 t.2.2 = false)))
      = S.filter (fun t => assocNeg n t.1 t.2.1 t.2.2 = true) :=
    Finset.filter_congr (fun t _ => by cases assocNeg n t.1 t.2.1 t.2.2 <;> simp)
  have key := Finset.card_filter_add_card_filter_not
    (s := S) (p := fun t : Nat × Nat × Nat => assocNeg n t.1 t.2.1 t.2.2 = false)
  rw [associatingTriples, nonAssociatingTriples, ← hS, ← hfil, key, hcard]

/-- **The complementary counting law.**  The number of ordered basis triples that fail to
associate in dimension `D = 2ⁿ ≥ 2` is exactly `D³/2 - 14 D + 24`. -/
theorem nonAssociatingTriples_formula (n : Nat) (hn : 1 ≤ n) :
    nonAssociatingTriples n + 14 * 2 ^ n = 2 ^ (3 * n - 1) + 24 := by
  have h1 := associating_add_nonassociating n
  have h2 := associatingTriples_formula n hn
  have h3 := associatingTriples_formula_dim n hn
  omega

/-- Sanity check against the previously kernel-evaluated dimensions. -/
theorem associatingTriples_values :
    associatingTriples 1 = 8 ∧ associatingTriples 2 = 64 ∧ associatingTriples 3 = 344 ∧
      associatingTriples 4 = 2248 ∧ associatingTriples 5 = 16808 ∧
      associatingTriples 6 = 131944 := by
  refine ⟨?_, ?_, ?_, ?_, ?_, ?_⟩
  · have h := associatingTriples_formula 1 (by norm_num); norm_num at h; omega
  · have h := associatingTriples_formula 2 (by norm_num); norm_num at h; omega
  · have h := associatingTriples_formula 3 (by norm_num); norm_num at h; omega
  · have h := associatingTriples_formula 4 (by norm_num); norm_num at h; omega
  · have h := associatingTriples_formula 5 (by norm_num); norm_num at h; omega
  · have h := associatingTriples_formula 6 (by norm_num); norm_num at h; omega

/-! ## 10. The sector with a single high index -/

/-- The number of associating triples of `Tower (m+1)` whose first index lies in the newly
adjoined half and whose other two indices lie in the subalgebra `Tower m`. -/
def highFirstSectorTriples (m : Nat) : Nat :=
  (((Finset.range (2 ^ m)) ×ˢ (Finset.range (2 ^ m)) ×ˢ (Finset.range (2 ^ m))).filter
    (fun t => assocNeg (m + 1) (2 ^ m + t.1) t.2.1 t.2.2 = false)).card

/-- A triple whose last two indices commute always associates. -/
theorem assocNeg_false_of_commNeg_false (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m)
    (h : commNeg b c = false) : assocNeg m a b c = false := by
  have hdeg : b = 0 ∨ c = 0 ∨ b = c := by
    by_contra hcon
    push_neg at hcon
    rw [commNeg, decide_eq_false_iff_not] at h
    exact h ⟨hcon.1, hcon.2.1, hcon.2.2⟩
  rcases hdeg with h0 | h0 | h0
  · subst h0; exact assocNeg_zero_mid m a c
  · subst h0; exact assocNeg_zero_right m a b
  · subst h0; exact assocNeg_right_alt m a b ha hb

theorem commNeg_sum_last (d b : Nat) (hb : b < d) :
    ∑ c ∈ range d, indA (commNeg b c) = if b = 0 then d else 2 := by
  have hd : 0 < d := Nat.lt_of_le_of_lt (Nat.zero_le b) hb
  by_cases hb0 : b = 0
  · subst hb0
    have h : ∀ c, indA (commNeg 0 c) = 1 := by intro c; simp [indA, commNeg]
    rw [Finset.sum_congr rfl (fun c _ => h c)]
    simp
  · have h : ∀ c, indA (commNeg b c) = if c = 0 ∨ c = b then 1 else 0 := by
      intro c
      by_cases h1 : c = 0
      · simp [indA, commNeg, h1]
      · by_cases h2 : c = b
        · simp [indA, commNeg, h2]
        · simp [indA, commNeg, h1, h2, hb0, Ne.symm h2]
    rw [Finset.sum_congr rfl (fun c _ => h c),
      sum_range_ite_pair d 0 b hd hb (Ne.symm hb0)]
    simp [hb0]

theorem commNeg_sum_mid_last (d : Nat) (hd : 0 < d) :
    (∑ b ∈ range d, ∑ c ∈ range d, indA (commNeg b c)) + 2 = 3 * d := by
  rw [Finset.sum_congr rfl (fun b hb => commNeg_sum_last d b (Finset.mem_range.mp hb)),
    ← Finset.add_sum_erase _ _ (Finset.mem_range.mpr hd)]
  have herase : ∀ b ∈ (range d).erase 0, (if b = 0 then d else 2) = 2 := by
    intro b hb
    simp [Finset.ne_of_mem_erase hb]
  rw [Finset.sum_congr rfl herase, Finset.sum_const, smul_eq_mul,
    Finset.card_erase_of_mem (Finset.mem_range.mpr hd), Finset.card_range]
  simp only [if_true]
  omega

/-- **The internal sector and the "first index high" sector.**  Their associating triples
together number `d³ + 3d² - 2d`, where `d = 2ᵐ`: the pointwise contribution of a triple of
low indices is `1` when its last two indices anticommute and `2` otherwise. -/
theorem assoc_add_highFirst (m : Nat) :
    associatingTriples m + highFirstSectorTriples m + 2 * 2 ^ m
      = (2 ^ m) ^ 3 + 3 * (2 ^ m) ^ 2 := by
  have hd : 0 < 2 ^ m := Nat.two_pow_pos m
  rw [associatingTriples_eq_sum, highFirstSectorTriples,
    card_filter_triple_eq_sum (2 ^ m) (fun a b c => assocNeg (m + 1) (2 ^ m + a) b c),
    ← Finset.sum_add_distrib]
  have hinner : ∀ a ∈ range (2 ^ m),
      ((∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), indA (assocNeg m a b c))
        + ∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
            indA (assocNeg (m + 1) (2 ^ m + a) b c))
      = ∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), (1 + indA (commNeg b c)) := by
    intro a ha
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun b hb => ?_)
    rw [← Finset.sum_add_distrib]
    refine Finset.sum_congr rfl (fun c hc => ?_)
    have ha' := Finset.mem_range.mp ha
    have hb' := Finset.mem_range.mp hb
    have hc' := Finset.mem_range.mp hc
    rw [assocNeg_succ_hll m a b c ha' hb' hc']
    cases hcm : commNeg b c
    · rw [assocNeg_false_of_commNeg_false m a b c ha' hb' hcm]
      rfl
    · cases assocNeg m a b c <;> rfl
  rw [Finset.sum_congr rfl hinner]
  have hq := commNeg_sum_mid_last (2 ^ m) hd
  have hbc : (∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), (1 + indA (commNeg b c)))
      = 2 ^ m * 2 ^ m + ∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), indA (commNeg b c) := by
    rw [Finset.sum_congr rfl (fun b _ => Finset.sum_add_distrib), Finset.sum_add_distrib]
    simp [Finset.sum_const, Finset.card_range]
  rw [Finset.sum_congr rfl (fun a _ => hbc), Finset.sum_const, Finset.card_range, smul_eq_mul]
  have hsplit : 2 ^ m * (2 ^ m * 2 ^ m
        + ∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), indA (commNeg b c)) + 2 * 2 ^ m
      = 2 ^ m * (2 ^ m * 2 ^ m)
        + 2 ^ m * ((∑ b ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), indA (commNeg b c)) + 2) := by
    ring
  rw [hsplit, hq]
  ring

/-- **Exact count of the doubling sector `(1,0,0)`.**  In dimension `2ᵐ⁺¹` the number of
associating triples whose first index is high and whose last two are low is exactly
`d³/2 + 3d² - 16d + 24` for `d = 2ᵐ ≥ 2`; this confirms one of the three conjectured sector
counts of the doubling decomposition. -/
theorem highFirstSectorTriples_formula (m : Nat) (hm : 1 ≤ m) :
    2 * highFirstSectorTriples m + 32 * 2 ^ m = (2 ^ m) ^ 3 + 6 * (2 ^ m) ^ 2 + 48 := by
  have h1 := assoc_add_highFirst m
  have h2 := associatingTriples_formula_dim m hm
  omega

/-! ## 11. The sector with a high last index -/

/-- The number of associating triples of `Tower (m+1)` whose **last** index lies in the
newly adjoined half and whose other two indices lie in `Tower m`. -/
def highLastSectorTriples (m : Nat) : Nat :=
  (((Finset.range (2 ^ m)) ×ˢ (Finset.range (2 ^ m)) ×ˢ (Finset.range (2 ^ m))).filter
    (fun t => assocNeg (m + 1) t.1 t.2.1 (2 ^ m + t.2.2) = false)).card

theorem highLastSectorTriples_eq (m : Nat) :
    highLastSectorTriples m = highFirstSectorTriples m := by
  have hlt : ∀ x, x < 2 ^ m → x < 2 ^ (m + 1) := by
    intro x hx
    have : (2 : Nat) ^ m ≤ 2 ^ (m + 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
    omega
  have hhigh : ∀ x, x < 2 ^ m → 2 ^ m + x < 2 ^ (m + 1) := by
    intro x hx
    have : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by rw [pow_succ]; ring
    omega
  rw [highLastSectorTriples, highFirstSectorTriples,
    card_filter_triple_eq_sum (2 ^ m) (fun a b c => assocNeg (m + 1) a b (2 ^ m + c)),
    card_filter_triple_eq_sum (2 ^ m) (fun a b c => assocNeg (m + 1) (2 ^ m + a) b c)]
  have hrev : ∀ a ∈ range (2 ^ m), ∀ b ∈ range (2 ^ m), ∀ c ∈ range (2 ^ m),
      indA (assocNeg (m + 1) a b (2 ^ m + c))
        = indA (assocNeg (m + 1) (2 ^ m + c) b a) := by
    intro a ha b hb c hc
    rw [assocNeg_reverse (m + 1) a b (2 ^ m + c) (hlt a (Finset.mem_range.mp ha))
      (hlt b (Finset.mem_range.mp hb)) (hhigh c (Finset.mem_range.mp hc))]
  rw [Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (fun b hb =>
    Finset.sum_congr rfl (fun c hc => hrev a ha b hb c hc)))]
  rw [Finset.sum_congr rfl (fun a _ => Finset.sum_comm)]
  rw [Finset.sum_comm]
  exact Finset.sum_congr rfl (fun c _ => Finset.sum_comm)

/-- **Exact count of the doubling sector `(0,0,1)`.**  By reversal symmetry it agrees with
the sector `(1,0,0)`: in dimension `2ᵐ⁺¹` the number of associating triples whose last index
is high and whose first two are low is `d³/2 + 3d² - 16d + 24` for `d = 2ᵐ ≥ 2`. -/
theorem highLastSectorTriples_formula (m : Nat) (hm : 1 ≤ m) :
    2 * highLastSectorTriples m + 32 * 2 ^ m = (2 ^ m) ^ 3 + 6 * (2 ^ m) ^ 2 + 48 := by
  rw [highLastSectorTriples_eq]
  exact highFirstSectorTriples_formula m hm

end Sovereign
