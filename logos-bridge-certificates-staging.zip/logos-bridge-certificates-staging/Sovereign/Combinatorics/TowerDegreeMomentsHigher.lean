import Sovereign.Combinatorics.TowerDegreeMoments

namespace Sovereign

open Finset

/-! ## 1. The higher moments and the splitting lemma -/

/-- The third moment of the degree census. -/
def censusMoment3 (q : Nat) : ℤ :=
  ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) ^ 3 * (censusT q t : ℤ)

/-- The fourth moment of the degree census. -/
def censusMoment4 (q : Nat) : ℤ :=
  ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) ^ 4 * (censusT q t : ℤ)

/-- The fifth moment of the degree census. -/
def censusMoment5 (q : Nat) : ℤ :=
  ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) ^ 5 * (censusT q t : ℤ)

/-- A polynomial weight of degree at most four, summed against the census, is the
corresponding combination of the first five moments. -/
theorem censusWeightedSplit (q : Nat) (a b c d e : ℤ) :
    ∑ s ∈ range (2 ^ q),
        (a + b * (8 * (s : ℤ) + 4) + c * (8 * (s : ℤ) + 4) ^ 2 + d * (8 * (s : ℤ) + 4) ^ 3
          + e * (8 * (s : ℤ) + 4) ^ 4) * (censusT q s : ℤ)
      = a * censusMoment0 q + b * censusMoment1 q + c * censusMoment2 q + d * censusMoment3 q
        + e * censusMoment4 q := by
  rw [censusMoment0, censusMoment1, censusMoment2, censusMoment3, censusMoment4,
    Finset.mul_sum, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum, Finset.mul_sum,
    ← Finset.sum_add_distrib, ← Finset.sum_add_distrib, ← Finset.sum_add_distrib,
    ← Finset.sum_add_distrib]
  exact Finset.sum_congr rfl (fun s _ => by ring)

/-- The top weight of a doubling step, cast to `ℤ`. -/
theorem cast_top_weight (q k : Nat) :
    ((8 * ((2 ^ (q + 1) - 1 : Nat) : ℤ) + 4)) ^ k = (2 * (2 : ℤ) ^ (q + 3) - 4) ^ k := by
  have h1 : (1 : Nat) ≤ 2 ^ (q + 1) := Nat.one_le_two_pow
  have hbase : (8 * ((2 ^ (q + 1) - 1 : Nat) : ℤ) + 4) = 2 * (2 : ℤ) ^ (q + 3) - 4 := by
    push_cast [Nat.cast_sub h1]
    have hp : (2 : ℤ) ^ (q + 3) = 4 * 2 ^ (q + 1) := by ring
    rw [hp]
    ring
  rw [hbase]

/-! ## 2. The third moment -/

theorem censusMoment3_succ (q : Nat) :
    censusMoment3 (q + 1)
      = 2 * (((2 * (2 : ℤ) ^ (q + 3)) ^ 3 - 12 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2
                + 48 * (2 * (2 : ℤ) ^ (q + 3))) * censusMoment0 q
              + (-6 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 + 48 * (2 * (2 : ℤ) ^ (q + 3)))
                  * censusMoment1 q
              + 12 * (2 * (2 : ℤ) ^ (q + 3)) * censusMoment2 q)
        + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 3 * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hw := censusT_succ_weighted q (fun e => (8 * (e : ℤ) + 4) ^ 3)
  have hsum : ∀ s ∈ range (2 ^ q),
      (((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) ^ 3) + ((8 * ((2 * s + 1 : Nat) : ℤ) + 4) ^ 3))
        * (censusT q s : ℤ)
        = (((2 * (2 : ℤ) ^ (q + 3)) ^ 3 - 12 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2
              + 48 * (2 * (2 : ℤ) ^ (q + 3)))
            + (-6 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 + 48 * (2 * (2 : ℤ) ^ (q + 3)))
                * (8 * (s : ℤ) + 4)
            + 12 * (2 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4) ^ 2
            + 0 * (8 * (s : ℤ) + 4) ^ 3 + 0 * (8 * (s : ℤ) + 4) ^ 4) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    push_cast [hc]
    have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
    rw [hp]
    ring
  have hM3 : censusMoment3 (q + 1)
      = ∑ e ∈ range (2 ^ (q + 1)), ((8 * (e : ℤ) + 4) ^ 3) * (censusT (q + 1) e : ℤ) := rfl
  rw [hM3, hw, Finset.sum_congr rfl hsum, cast_top_weight q 3, censusWeightedSplit]
  ring

/-- **The third moment of the degree census.**  In every dimension `D = 2^(q+3)` of the
tower the degrees of the annihilation graph satisfy
`10 ∑ v³ · (multiplicity of v) = 3 D⁵ - 340 D³ + 2160 D² - 4928 D + 3840`. -/
theorem censusMoment3_formula (q : Nat) :
    10 * censusMoment3 q
      = 3 * ((2 : ℤ) ^ (q + 3)) ^ 5 - 340 * ((2 : ℤ) ^ (q + 3)) ^ 3
        + 2160 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 4928 * (2 : ℤ) ^ (q + 3) + 3840 := by
  cases q with
  | zero => decide
  | succ q =>
    have h0 := censusMoment0_formula q
    have h1 := censusMoment1_formula q
    have h2 := censusMoment2_formula q
    have hstep := censusMoment3_succ q
    have hp : (2 : ℤ) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    rw [hp, hstep, h0]
    linear_combination (-60 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 + 480 * (2 * (2 : ℤ) ^ (q + 3))) * h1
      + 8 * (2 * (2 : ℤ) ^ (q + 3)) * h2

/-- The third moment in terms of the degree census of dimension `2ⁿ`. -/
theorem degreeCount_third_moment (n : Nat) (hn : 3 ≤ n) :
    10 * ∑ t ∈ range (2 ^ (n - 3)), (8 * (t : ℤ) + 4) ^ 3 * (degreeCount n (8 * t + 4) : ℤ)
      = 3 * ((2 : ℤ) ^ n) ^ 5 - 340 * ((2 : ℤ) ^ n) ^ 3 + 2160 * ((2 : ℤ) ^ n) ^ 2
        - 4928 * (2 : ℤ) ^ n + 3840 := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  rw [show q + 3 - 3 = q from by omega,
    Finset.sum_congr rfl (fun t _ => by rw [degreeCount_eq_censusT q t])]
  exact censusMoment3_formula q

/-! ## 3. The fourth moment -/

theorem censusMoment4_succ (q : Nat) :
    censusMoment4 (q + 1)
      = 2 * (((2 * (2 : ℤ) ^ (q + 3)) ^ 4 - 16 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3
                + 96 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 256 * (2 * (2 : ℤ) ^ (q + 3)) + 512)
                * censusMoment0 q
              + (-8 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3 + 96 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2
                  - 384 * (2 * (2 : ℤ) ^ (q + 3)) + 1024) * censusMoment1 q
              + (24 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 192 * (2 * (2 : ℤ) ^ (q + 3)) + 768)
                  * censusMoment2 q
              + (-32 * (2 * (2 : ℤ) ^ (q + 3)) + 256) * censusMoment3 q
              + 32 * censusMoment4 q)
        + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 4 * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hw := censusT_succ_weighted q (fun e => (8 * (e : ℤ) + 4) ^ 4)
  have hsum : ∀ s ∈ range (2 ^ q),
      (((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) ^ 4) + ((8 * ((2 * s + 1 : Nat) : ℤ) + 4) ^ 4))
        * (censusT q s : ℤ)
        = (((2 * (2 : ℤ) ^ (q + 3)) ^ 4 - 16 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3
              + 96 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 256 * (2 * (2 : ℤ) ^ (q + 3)) + 512)
            + (-8 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3 + 96 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2
                - 384 * (2 * (2 : ℤ) ^ (q + 3)) + 1024) * (8 * (s : ℤ) + 4)
            + (24 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 192 * (2 * (2 : ℤ) ^ (q + 3)) + 768)
                * (8 * (s : ℤ) + 4) ^ 2
            + (-32 * (2 * (2 : ℤ) ^ (q + 3)) + 256) * (8 * (s : ℤ) + 4) ^ 3
            + 32 * (8 * (s : ℤ) + 4) ^ 4) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    push_cast [hc]
    have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
    rw [hp]
    ring
  have hM4 : censusMoment4 (q + 1)
      = ∑ e ∈ range (2 ^ (q + 1)), ((8 * (e : ℤ) + 4) ^ 4) * (censusT (q + 1) e : ℤ) := rfl
  rw [hM4, hw, Finset.sum_congr rfl hsum, cast_top_weight q 4, censusWeightedSplit]

/-- **The fourth moment of the degree census.**  In every dimension `D = 2^(q+3)` of the
tower the degrees of the annihilation graph satisfy
`6510 ∑ v⁴ · (multiplicity of v)
   = 1679 D⁶ - 297724 D⁴ + 2589120 D³ - 9138304 D² + 14676480 D - 8856576`. -/
theorem censusMoment4_formula (q : Nat) :
    6510 * censusMoment4 q
      = 1679 * ((2 : ℤ) ^ (q + 3)) ^ 6 - 297724 * ((2 : ℤ) ^ (q + 3)) ^ 4
        + 2589120 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 9138304 * ((2 : ℤ) ^ (q + 3)) ^ 2
        + 14676480 * (2 : ℤ) ^ (q + 3) - 8856576 := by
  induction q with
  | zero => decide
  | succ q ih =>
    have h0 := censusMoment0_formula q
    have h1 := censusMoment1_formula q
    have h2 := censusMoment2_formula q
    have h3 := censusMoment3_formula q
    have hstep := censusMoment4_succ q
    have hp : (2 : ℤ) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    rw [hp, hstep, h0]
    linear_combination 64 * ih
      + (-52080 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3 + 624960 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2
          - 2499840 * (2 * (2 : ℤ) ^ (q + 3)) + 6666240) * h1
      + (10416 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 83328 * (2 * (2 : ℤ) ^ (q + 3)) + 333312) * h2
      + (-41664 * (2 * (2 : ℤ) ^ (q + 3)) + 333312) * h3

/-- The fourth moment in terms of the degree census of dimension `2ⁿ`. -/
theorem degreeCount_fourth_moment (n : Nat) (hn : 3 ≤ n) :
    6510 * ∑ t ∈ range (2 ^ (n - 3)), (8 * (t : ℤ) + 4) ^ 4 * (degreeCount n (8 * t + 4) : ℤ)
      = 1679 * ((2 : ℤ) ^ n) ^ 6 - 297724 * ((2 : ℤ) ^ n) ^ 4 + 2589120 * ((2 : ℤ) ^ n) ^ 3
        - 9138304 * ((2 : ℤ) ^ n) ^ 2 + 14676480 * (2 : ℤ) ^ n - 8856576 := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  rw [show q + 3 - 3 = q from by omega,
    Finset.sum_congr rfl (fun t _ => by rw [degreeCount_eq_censusT q t])]
  exact censusMoment4_formula q

/-! ## 4. The fifth moment -/

theorem censusMoment5_succ (q : Nat) :
    censusMoment5 (q + 1)
      = 2 * (((32 * ((2 : ℤ) ^ (q + 3)) ^ 5 - 320 * ((2 : ℤ) ^ (q + 3)) ^ 4
                + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 2560 * ((2 : ℤ) ^ (q + 3)) ^ 2
                + 2560 * (2 : ℤ) ^ (q + 3)) * censusMoment0 q
              + (-160 * ((2 : ℤ) ^ (q + 3)) ^ 4 + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3
                  - 3840 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 5120 * (2 : ℤ) ^ (q + 3)) * censusMoment1 q
              + (320 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 1920 * ((2 : ℤ) ^ (q + 3)) ^ 2
                  + 3840 * (2 : ℤ) ^ (q + 3)) * censusMoment2 q
              + (-320 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 1280 * (2 : ℤ) ^ (q + 3)) * censusMoment3 q
              + (160 * (2 : ℤ) ^ (q + 3)) * censusMoment4 q))
        + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 5 * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  have hw := censusT_succ_weighted q (fun e => (8 * (e : ℤ) + 4) ^ 5)
  have hsum : ∀ s ∈ range (2 ^ q),
      (((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) ^ 5) + ((8 * ((2 * s + 1 : Nat) : ℤ) + 4) ^ 5))
        * (censusT q s : ℤ)
        = ((32 * ((2 : ℤ) ^ (q + 3)) ^ 5 - 320 * ((2 : ℤ) ^ (q + 3)) ^ 4
              + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 2560 * ((2 : ℤ) ^ (q + 3)) ^ 2
              + 2560 * (2 : ℤ) ^ (q + 3))
            + (-160 * ((2 : ℤ) ^ (q + 3)) ^ 4 + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3
                - 3840 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 5120 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4)
            + (320 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 1920 * ((2 : ℤ) ^ (q + 3)) ^ 2
                + 3840 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4) ^ 2
            + (-320 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 1280 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4) ^ 3
            + (160 * (2 : ℤ) ^ (q + 3)) * (8 * (s : ℤ) + 4) ^ 4) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    push_cast [hc]
    have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
    rw [hp]
    ring
  have hM5 : censusMoment5 (q + 1)
      = ∑ e ∈ range (2 ^ (q + 1)), ((8 * (e : ℤ) + 4) ^ 5) * (censusT (q + 1) e : ℤ) := rfl
  rw [hM5, hw, Finset.sum_congr rfl hsum, cast_top_weight q 5, censusWeightedSplit]

set_option maxHeartbeats 800000

/-- **The fifth moment of the degree census.**  In every dimension `D = 2^(q+3)` of the
tower the degrees of the annihilation graph satisfy
`434 ∑ v⁵ · (multiplicity of v)
   = 99 D⁷ - 25172 D⁵ + 275280 D⁴ - 1305472 D³ + 3279360 D² - 4475904 D + 2666496`. -/
theorem censusMoment5_formula (q : Nat) :
    434 * censusMoment5 q
      = 99 * ((2 : ℤ) ^ (q + 3)) ^ 7 - 25172 * ((2 : ℤ) ^ (q + 3)) ^ 5
        + 275280 * ((2 : ℤ) ^ (q + 3)) ^ 4 - 1305472 * ((2 : ℤ) ^ (q + 3)) ^ 3
        + 3279360 * ((2 : ℤ) ^ (q + 3)) ^ 2 - 4475904 * (2 : ℤ) ^ (q + 3) + 2666496 := by
  cases q with
  | zero => decide
  | succ q =>
    have h0 := censusMoment0_formula q
    have h1 := censusMoment1_formula q
    have h2 := censusMoment2_formula q
    have h3 := censusMoment3_formula q
    have h4 := censusMoment4_formula q
    have hstep := censusMoment5_succ q
    have hp : (2 : ℤ) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    have hstep15 : 15 * (434 * censusMoment5 (q + 1)) = 6510 * censusMoment5 (q + 1) := by ring
    rw [hp, hstep, h0]
    have hlin : 6510 * (2 * (((32 * ((2 : ℤ) ^ (q + 3)) ^ 5 - 320 * ((2 : ℤ) ^ (q + 3)) ^ 4
              + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 2560 * ((2 : ℤ) ^ (q + 3)) ^ 2
              + 2560 * (2 : ℤ) ^ (q + 3)) * (((2 : ℤ) ^ (q + 3) - 1) * ((2 : ℤ) ^ (q + 3) - 2))
            + (-160 * ((2 : ℤ) ^ (q + 3)) ^ 4 + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3
                - 3840 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 5120 * (2 : ℤ) ^ (q + 3)) * censusMoment1 q
            + (320 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 1920 * ((2 : ℤ) ^ (q + 3)) ^ 2
                + 3840 * (2 : ℤ) ^ (q + 3)) * censusMoment2 q
            + (-320 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 1280 * (2 : ℤ) ^ (q + 3)) * censusMoment3 q
            + (160 * (2 : ℤ) ^ (q + 3)) * censusMoment4 q))
      + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ 5 * (6 * ((2 : ℤ) ^ (q + 3) - 1)))
      = 15 * (99 * (2 * (2 : ℤ) ^ (q + 3)) ^ 7 - 25172 * (2 * (2 : ℤ) ^ (q + 3)) ^ 5
        + 275280 * (2 * (2 : ℤ) ^ (q + 3)) ^ 4 - 1305472 * (2 * (2 : ℤ) ^ (q + 3)) ^ 3
        + 3279360 * (2 * (2 : ℤ) ^ (q + 3)) ^ 2 - 4475904 * (2 * (2 : ℤ) ^ (q + 3)) + 2666496) := by
      linear_combination
        (6510 * (-160 * ((2 : ℤ) ^ (q + 3)) ^ 4 + 1280 * ((2 : ℤ) ^ (q + 3)) ^ 3
          - 3840 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 5120 * (2 : ℤ) ^ (q + 3))) * h1
        + (434 * (320 * ((2 : ℤ) ^ (q + 3)) ^ 3 - 1920 * ((2 : ℤ) ^ (q + 3)) ^ 2
          + 3840 * (2 : ℤ) ^ (q + 3))) * h2
        + (1302 * (-320 * ((2 : ℤ) ^ (q + 3)) ^ 2 + 1280 * (2 : ℤ) ^ (q + 3))) * h3
        + (2 * (160 * (2 : ℤ) ^ (q + 3))) * h4
    omega

/-- The fifth moment in terms of the degree census of dimension `2ⁿ`. -/
theorem degreeCount_fifth_moment (n : Nat) (hn : 3 ≤ n) :
    434 * ∑ t ∈ range (2 ^ (n - 3)), (8 * (t : ℤ) + 4) ^ 5 * (degreeCount n (8 * t + 4) : ℤ)
      = 99 * ((2 : ℤ) ^ n) ^ 7 - 25172 * ((2 : ℤ) ^ n) ^ 5 + 275280 * ((2 : ℤ) ^ n) ^ 4
        - 1305472 * ((2 : ℤ) ^ n) ^ 3 + 3279360 * ((2 : ℤ) ^ n) ^ 2 - 4475904 * (2 : ℤ) ^ n + 2666496 := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  rw [show q + 3 - 3 = q from by omega,
    Finset.sum_congr rfl (fun t _ => by rw [degreeCount_eq_censusT q t])]
  exact censusMoment5_formula q

end Sovereign
