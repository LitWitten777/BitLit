import Sovereign.Combinatorics.AssociatingTriplesCount

namespace Sovereign

open Finset

/-! ## 1. Two index-level Boolean identities -/

/-- The four indices `0, i, j, i ⊕ j` spanned by an admissible outer pair. -/
def spanSet (i j : Nat) : Finset Nat := {0, i, j, i ^^^ j}

/-- The two exceptional middles `0, a` of the last-slot doubling law. -/
def pairSet (a : Nat) : Finset Nat := {0, a}

theorem commNeg_comm (b c : Nat) : commNeg b c = commNeg c b := by
  simp only [commNeg, decide_eq_decide]
  constructor
  · rintro ⟨h1, h2, h3⟩; exact ⟨h2, h1, fun h => h3 h.symm⟩
  · rintro ⟨h1, h2, h3⟩; exact ⟨h2, h1, fun h => h3 h.symm⟩

theorem mem_spanSet_iff (i j k : Nat) :
    k ∈ spanSet i j ↔ (k = 0 ∨ k = i ∨ k = j ∨ k = i ^^^ j) := by
  simp [spanSet]

theorem mem_pairSet_iff (a k : Nat) : k ∈ pairSet a ↔ (k = 0 ∨ k = a) := by
  simp [pairSet]

/-- **Span indicator.** For an admissible pair the two commutation defects `commNeg k i`
and `commNeg i (k ⊕ j)` differ exactly on the span of `(i, j)`. -/
theorem commNeg_xor_span (i j k : Nat) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    xor (commNeg k i) (commNeg i (k ^^^ j)) = decide (k ∈ spanSet i j) := by
  have hmem : (k ∈ spanSet i j) = (k = 0 ∨ k = i ∨ k = j ∨ k = i ^^^ j) :=
    propext (mem_spanSet_iff i j k)
  have he : ∀ x : Nat, (i = x ^^^ j) ↔ (x = i ^^^ j) := by
    intro x
    constructor
    · rintro rfl; rw [Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
    · rintro rfl; rw [Nat.xor_assoc, Nat.xor_self, Nat.xor_zero]
  have hxi : i ^^^ j ≠ i := by
    intro h
    exact hj0 (by simpa [← Nat.xor_assoc] using congrArg (fun z => i ^^^ z) h)
  have hxj : i ^^^ j ≠ j := by
    intro h
    exact hi0 (by simpa [Nat.xor_assoc] using congrArg (fun z => z ^^^ j) h)
  simp only [commNeg, hmem]
  by_cases h0 : k = 0 <;> by_cases h1 : k = i <;> by_cases h2 : k = j <;>
    by_cases h3 : k = i ^^^ j <;> simp_all [Nat.xor_eq_zero_iff]

/-- **Pair indicator.** The three commutation defects appearing in the last-slot doubling
law cancel except on `{0, a}`. -/
theorem commNeg_xor_pair (a b c : Nat) (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    xor (xor (commNeg c (a ^^^ b)) (commNeg c b)) (commNeg a (b ^^^ c))
      = !decide (b ∈ pairSet a) := by
  have hmem : (b ∈ pairSet a) = (b = 0 ∨ b = a) := propext (mem_pairSet_iff a b)
  have e1 : (a ^^^ b = 0) ↔ b = a := by
    rw [Nat.xor_eq_zero_iff]; exact eq_comm
  have e2 : (b ^^^ c = 0) ↔ b = c := Nat.xor_eq_zero_iff
  have e3 : (c = a ^^^ b) ↔ b = a ^^^ c := by
    constructor <;> (rintro rfl; simp)
  have e4 : (a = b ^^^ c) ↔ b = a ^^^ c := by
    constructor <;> (rintro rfl; simp)
  have hxa : a ^^^ c ≠ a := by
    intro h
    exact hc0 (by simpa [← Nat.xor_assoc] using congrArg (fun z => a ^^^ z) h)
  have hxc : a ^^^ c ≠ c := by
    intro h
    exact ha0 (by simpa [Nat.xor_assoc] using congrArg (fun z => z ^^^ c) h)
  have hxz : a ^^^ c ≠ 0 := fun h => hac (Nat.xor_eq_zero_iff.mp h)
  simp only [commNeg, hmem]
  by_cases h0 : b = 0 <;> by_cases h1 : b = a <;> by_cases h2 : b = c <;>
    by_cases h3 : b = a ^^^ c <;> simp_all [ne_comm]

/-! ## 2. Pointwise sign laws for one doubling step -/

/-- **The high-middle defect is the associator sign twisted by the span indicator.** -/
theorem shiftDefect_eq_assocNeg_xor_span (q i j k : Nat) (hi : i < 2 ^ q) (hj : j < 2 ^ q)
    (hk : k < 2 ^ q) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    shiftDefect q i j k = xor (assocNeg q i k j) (decide (k ∈ spanSet i j)) := by
  have hkj : k ^^^ j < 2 ^ q := Nat.xor_lt_two_pow hk hj
  have h1 := epsNeg_swap_eq_commNeg q k i hk hi
  have h2 := epsNeg_swap_eq_commNeg q (k ^^^ j) i hkj hi
  have h3 := commNeg_xor_span i j k hi0 hj0 hij
  rw [commNeg_comm (k ^^^ j) i] at h2
  simp only [shiftDefect, assocNeg]
  revert h1 h2 h3
  cases epsNeg q k i <;> cases epsNeg q i k <;> cases epsNeg q k j <;>
    cases epsNeg q (i ^^^ k) j <;> cases epsNeg q (k ^^^ j) i <;>
    cases epsNeg q i (k ^^^ j) <;> cases commNeg k i <;> cases commNeg i (k ^^^ j) <;>
    cases decide (k ∈ spanSet i j) <;> simp

/-- The middle-shift sector `(0,1,0)` in terms of the associator sign and the span
indicator. -/
theorem sec010_eq_assocNeg_xor_span (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m)
    (hc : c < 2 ^ m) (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    sec010 m a b c = xor (assocNeg m a b c) (decide (b ∈ spanSet a c)) := by
  rw [← assocNeg_succ_lhl m a b c ha hb hc, assocNeg_high_middle m a c b ha hc hb,
    shiftDefect_eq_assocNeg_xor_span m a c b ha hc hb ha0 hc0 hac]

/-- **Last-slot doubling, low middle.** -/
theorem sec001_eq_assocNeg_flip (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m)
    (hc : c < 2 ^ m) (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    sec001 m a b c = !(xor (assocNeg m a b c) (decide (b ∈ pairSet a))) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have h1 := epsNeg_swap_eq_commNeg m c (a ^^^ b) hc hab
  have h2 := epsNeg_swap_eq_commNeg m c b hc hb
  have h3 := epsNeg_swap_eq_commNeg m (b ^^^ c) a hbc ha
  have h4 := commNeg_xor_pair a b c ha0 hc0 hac
  rw [commNeg_comm (b ^^^ c) a] at h3
  simp only [sec001, assocNeg]
  revert h1 h2 h3 h4
  cases epsNeg m a b <;> cases epsNeg m c (a ^^^ b) <;> cases epsNeg m (a ^^^ b) c <;>
    cases epsNeg m c b <;> cases epsNeg m b c <;> cases epsNeg m (b ^^^ c) a <;>
    cases epsNeg m a (b ^^^ c) <;> cases commNeg c (a ^^^ b) <;> cases commNeg c b <;>
    cases commNeg a (b ^^^ c) <;> cases decide (b ∈ pairSet a) <;> simp

/-- **Last-slot doubling, high middle.** -/
theorem sec011_eq_sec010_flip (m a b c : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m)
    (hc : c < 2 ^ m) (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    sec011 m a b c = !(xor (sec010 m a b c) (decide (b ∈ pairSet a))) := by
  have hab : a ^^^ b < 2 ^ m := Nat.xor_lt_two_pow ha hb
  have hbc : b ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hb hc
  have h1 := epsNeg_swap_eq_commNeg m c (a ^^^ b) hc hab
  have h2 := epsNeg_swap_eq_commNeg m c b hc hb
  have h3 := epsNeg_swap_eq_commNeg m (b ^^^ c) a hbc ha
  have h4 := commNeg_xor_pair a b c ha0 hc0 hac
  rw [commNeg_comm (b ^^^ c) a] at h3
  simp only [sec011, sec010]
  revert h1 h2 h3 h4
  cases epsNeg m b a <;> cases epsNeg m c (a ^^^ b) <;> cases epsNeg m (a ^^^ b) c <;>
    cases epsNeg m c b <;> cases epsNeg m b c <;> cases epsNeg m (b ^^^ c) a <;>
    cases epsNeg m a (b ^^^ c) <;> cases commNeg c (a ^^^ b) <;> cases commNeg c b <;>
    cases commNeg a (b ^^^ c) <;> cases decide (b ∈ pairSet a) <;> simp

/-- Sector `(0,0,1)` with a real first index vanishes. -/
theorem sec001_first_zero (m b c : Nat) : sec001 m 0 b c = false := by
  simp only [sec001, Nat.zero_xor, epsNeg_zero_left, epsNeg_zero_right]
  cases epsNeg m c b <;> rfl

/-- Sector `(0,1,1)` with a real first index vanishes. -/
theorem sec011_first_zero (m b c : Nat) : sec011 m 0 b c = false := by
  simp only [sec011, Nat.zero_xor, epsNeg_zero_left, epsNeg_zero_right]
  cases epsNeg m c b <;> rfl

/-- Sector `(0,0,1)` with equal outer indices. -/
theorem sec001_last_first (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec001 m a b a = commNeg a b := by
  have hba : b ^^^ a < 2 ^ m := Nat.xor_lt_two_pow hb ha
  have h := epsNeg_swap_eq_commNeg m (b ^^^ a) a hba ha
  have hcomm : commNeg (b ^^^ a) a = commNeg a b := by
    have h1 : (b ^^^ a = 0) ↔ b = a := Nat.xor_eq_zero_iff
    have h2 : (b ^^^ a = a) ↔ b = 0 := by
      constructor
      · intro hh; simpa using congrArg (fun z => z ^^^ a) hh
      · rintro rfl; simp
    simp only [commNeg, decide_eq_decide, ne_eq, h1, h2]
    constructor
    · rintro ⟨u1, u2, u3⟩
      exact ⟨u2, u3, fun hh => u1 hh.symm⟩
    · rintro ⟨u1, u2, u3⟩
      exact ⟨fun hh => u3 hh.symm, u1, u2⟩
  rw [← hcomm, ← h]
  simp only [sec001, Nat.xor_comm a b]
  cases epsNeg m a b <;> cases epsNeg m a (b ^^^ a) <;> cases epsNeg m (b ^^^ a) a <;> rfl

/-- Sector `(0,1,1)` with equal outer indices. -/
theorem sec011_last_first (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    sec011 m a b a = commNeg a b := by
  have h := epsNeg_swap_eq_commNeg m a b ha hb
  have hx : a ^^^ b = b ^^^ a := Nat.xor_comm a b
  simp only [sec011, hx]
  rw [commNeg_comm a b, ← epsNeg_swap_eq_commNeg m b a hb ha]
  cases epsNeg m b a <;> cases epsNeg m a b <;> cases epsNeg m a (b ^^^ a) <;> rfl

/-- The new imaginary unit `e_h` against a low index, low middle. -/
theorem assocNeg_newUnit_low (m i b : Nat) (hi : i < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) i b (2 ^ m) = commNeg i b := by
  have hpos : (0 : Nat) < 2 ^ m := by positivity
  have h := assocNeg_succ_llh m i b 0 hi hb hpos
  simp only [Nat.add_zero] at h
  rw [h, sec001_last_zero m i b hi hb]

/-- The new imaginary unit `e_h` against a low index, high middle. -/
theorem assocNeg_newUnit_high (m i b : Nat) (hi : i < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) i (2 ^ m + b) (2 ^ m) = commNeg i b := by
  have hpos : (0 : Nat) < 2 ^ m := by positivity
  have h := assocNeg_succ_lhh m i b 0 hi hb hpos
  simp only [Nat.add_zero] at h
  rw [h, sec011_last_zero m i b hi hb]

/-- The pair `(e_h, e_{h+a})`, low middle. -/
theorem assocNeg_unitPair_low (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m) b (2 ^ m + a) = commNeg a b := by
  have hpos : (0 : Nat) < 2 ^ m := by positivity
  have h := assocNeg_succ_hlh m 0 b a hpos hb ha
  simp only [Nat.add_zero] at h
  rw [h, sec001_first_zero, commNeg_comm a b]
  cases commNeg b a <;> rfl

/-- The pair `(e_h, e_{h+a})`, high middle. -/
theorem assocNeg_unitPair_high (m a b : Nat) (ha : a < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) (2 ^ m) (2 ^ m + b) (2 ^ m + a) = commNeg a b := by
  have hpos : (0 : Nat) < 2 ^ m := by positivity
  have h := assocNeg_succ_hhh m 0 b a hpos hb ha
  simp only [Nat.add_zero] at h
  rw [h, sec011_first_zero, commNeg_comm a b]
  cases commNeg b a <;> rfl

/-- The diagonal pair `(e_i, e_{h+i})`, low middle. -/
theorem assocNeg_diagPair_low (m i b : Nat) (hi : i < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) i b (2 ^ m + i) = commNeg i b := by
  rw [assocNeg_succ_llh m i b i hi hb hi, sec001_last_first m i b hi hb]

/-- The diagonal pair `(e_i, e_{h+i})`, high middle. -/
theorem assocNeg_diagPair_high (m i b : Nat) (hi : i < 2 ^ m) (hb : b < 2 ^ m) :
    assocNeg (m + 1) i (2 ^ m + b) (2 ^ m + i) = commNeg i b := by
  rw [assocNeg_succ_lhh m i b i hi hb hi, sec011_last_first m i b hi hb]

/-! ## 3. Counting infrastructure -/

/-- Splitting a count over `range (2^(q+1))` into the two halves. -/
theorem card_filter_range_split (q : Nat) (P : Nat → Bool) :
    ((range (2 ^ (q + 1))).filter (fun k => P k = true)).card
      = ((range (2 ^ q)).filter (fun k => P k = true)).card
        + ((range (2 ^ q)).filter (fun k => P (2 ^ q + k) = true)).card := by
  have hsplit : (2 : Nat) ^ (q + 1) = 2 ^ q + 2 ^ q := by ring
  rw [hsplit, Finset.range_add, Finset.filter_union, Finset.card_union_of_disjoint,
    Finset.filter_map, Finset.card_map]
  · rfl
  · apply Finset.disjoint_filter_filter
    simp only [Finset.disjoint_left, Finset.mem_range, Finset.mem_map, addLeftEmbedding]
    rintro a ha ⟨x, hx, rfl⟩
    simp only [Function.Embedding.coeFn_mk] at ha
    omega

/-- Counting the complement. -/
theorem card_filter_not (m : Nat) (P : Nat → Bool) :
    ((range (2 ^ m)).filter (fun k => (!P k) = true)).card
      + ((range (2 ^ m)).filter (fun k => P k = true)).card = 2 ^ m := by
  classical
  have h := Finset.card_filter_add_card_filter_not (s := range (2 ^ m)) (p := fun b => P b = true)
  rw [Finset.card_range] at h
  have hcongr : (range (2 ^ m)).filter (fun k => (!P k) = true)
      = (range (2 ^ m)).filter (fun k => ¬ (P k = true)) := by
    apply Finset.filter_congr
    intro x _
    simp [Bool.not_eq_true]
  rw [hcongr]
  omega

/-- **Flipping a predicate on a finite exceptional set.** -/
theorem card_filter_xor_mem (m : Nat) (E : Finset Nat) (hE : E ⊆ range (2 ^ m))
    (Y : Nat → Bool) :
    ((range (2 ^ m)).filter (fun b => xor (Y b) (decide (b ∈ E)) = true)).card
        + (E.filter (fun b => Y b = true)).card
      = ((range (2 ^ m)).filter (fun b => Y b = true)).card
        + (E.filter (fun b => Y b = false)).card := by
  classical
  have hZ : (range (2 ^ m)).filter (fun b => xor (Y b) (decide (b ∈ E)) = true)
      = ((range (2 ^ m)).filter (fun b => Y b = true) \ E) ∪ E.filter (fun b => Y b = false) := by
    ext b
    have hmem : b ∈ E → b < 2 ^ m := fun h => Finset.mem_range.mp (hE h)
    by_cases hbE : b ∈ E <;> cases hYb : Y b <;>
      simp_all [Finset.mem_filter, Finset.mem_sdiff, Finset.mem_union, Finset.mem_range]
  have hdisj : Disjoint ((range (2 ^ m)).filter (fun b => Y b = true) \ E)
      (E.filter (fun b => Y b = false)) := by
    simp only [Finset.disjoint_left, Finset.mem_sdiff, Finset.mem_filter]
    rintro a ⟨-, ha⟩ ⟨ha2, -⟩
    exact ha ha2
  have hinter : (range (2 ^ m)).filter (fun b => Y b = true) ∩ E
      = E.filter (fun b => Y b = true) := by
    ext b
    simp only [Finset.mem_inter, Finset.mem_filter, Finset.mem_range]
    constructor
    · rintro ⟨⟨-, h1⟩, h2⟩; exact ⟨h2, h1⟩
    · rintro ⟨h1, h2⟩; exact ⟨⟨Finset.mem_range.mp (hE h1), h2⟩, h1⟩
  have hsd := Finset.card_sdiff_add_card_inter ((range (2 ^ m)).filter (fun b => Y b = true)) E
  rw [hinter] at hsd
  rw [hZ, Finset.card_union_of_disjoint hdisj]
  omega

/-- The number of middles that anticommute with a fixed non-real index. -/
theorem card_filter_commNeg (m i : Nat) (hi : i < 2 ^ m) (hi0 : i ≠ 0) :
    ((range (2 ^ m)).filter (fun b => commNeg i b = true)).card + 2 = 2 ^ m := by
  classical
  have hset : (range (2 ^ m)).filter (fun b => commNeg i b = true)
      = range (2 ^ m) \ ({0, i} : Finset Nat) := by
    ext b
    simp only [commNeg, Finset.mem_filter, Finset.mem_sdiff, Finset.mem_insert,
      Finset.mem_singleton, decide_eq_true_eq, Finset.mem_range]
    constructor
    · rintro ⟨hb, -, h1, h2⟩
      exact ⟨hb, by push_neg; exact ⟨h1, fun h => h2 h.symm⟩⟩
    · rintro ⟨hb, h⟩
      push_neg at h
      exact ⟨hb, hi0, h.1, fun hh => h.2 hh.symm⟩
  have hsub : ({0, i} : Finset Nat) ⊆ range (2 ^ m) := by
    intro x hx
    simp only [Finset.mem_insert, Finset.mem_singleton] at hx
    rcases hx with rfl | rfl
    · simp only [Finset.mem_range]; positivity
    · simpa [Finset.mem_range] using hi
  have hcard : ({0, i} : Finset Nat).card = 2 := Finset.card_pair (Ne.symm hi0)
  have h2le : 2 ≤ 2 ^ m := by
    rcases Nat.eq_zero_or_pos m with rfl | hm
    · simp at hi; omega
    · calc (2 : Nat) = 2 ^ 1 := by norm_num
        _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
  rw [hset, Finset.card_sdiff_of_subset hsub, hcard, Finset.card_range]
  omega

/-- **Flipping and complementing on an exceptional set.** -/
theorem card_flip (m : Nat) (E : Finset Nat) (hE : E ⊆ range (2 ^ m)) (X Y : Nat → Bool)
    (hXY : ∀ b, b < 2 ^ m → X b = !(xor (Y b) (decide (b ∈ E)))) :
    ((range (2 ^ m)).filter (fun b => X b = true)).card
        + ((range (2 ^ m)).filter (fun b => Y b = true)).card
        + (E.filter (fun b => Y b = false)).card
      = 2 ^ m + (E.filter (fun b => Y b = true)).card := by
  classical
  have hcongr : (range (2 ^ m)).filter (fun b => X b = true)
      = (range (2 ^ m)).filter (fun b => (!(xor (Y b) (decide (b ∈ E)))) = true) := by
    apply Finset.filter_congr
    intro b hb
    rw [hXY b (Finset.mem_range.mp hb)]
  have h1 := card_filter_not m (fun b => xor (Y b) (decide (b ∈ E)))
  have h2 := card_filter_xor_mem m E hE Y
  rw [hcongr]
  omega

/-- The span of an admissible pair sits inside the index range. -/
theorem spanSet_subset_range (m i j : Nat) (hi : i < 2 ^ m) (hj : j < 2 ^ m) :
    spanSet i j ⊆ range (2 ^ m) := by
  intro x hx
  rcases (mem_spanSet_iff i j x).mp hx with rfl | rfl | rfl | rfl
  · simp only [Finset.mem_range]; positivity
  · simpa [Finset.mem_range] using hi
  · simpa [Finset.mem_range] using hj
  · simpa [Finset.mem_range] using Nat.xor_lt_two_pow hi hj

/-- The exceptional pair sits inside the index range. -/
theorem pairSet_subset_range (m a : Nat) (ha : a < 2 ^ m) : pairSet a ⊆ range (2 ^ m) := by
  intro x hx
  rcases (mem_pairSet_iff a x).mp hx with rfl | rfl
  · simp only [Finset.mem_range]; positivity
  · simpa [Finset.mem_range] using ha

/-! ## 4. The four sector laws of one doubling step -/

/-- **Reversal symmetry of the degree.** -/
theorem nonassocMiddles_card_reverse (n i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    (nonassocMiddles n i j).card = (nonassocMiddles n j i).card := by
  have hset : nonassocMiddles n i j = nonassocMiddles n j i := by
    simp only [nonassocMiddles]
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_reverse n i k j hi (Finset.mem_range.mp hk) hj]
  rw [hset]

/-- **The doubling law.** For an outer pair inherited from the previous level the number of
non-associating middles doubles and gains `4`. -/
theorem nonassocMiddles_succ_card (m i j : Nat) (hi : i < 2 ^ m) (hj : j < 2 ^ m)
    (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (nonassocMiddles (m + 1) i j).card = 2 * (nonassocMiddles m i j).card + 4 := by
  classical
  have hsplit := card_filter_range_split m (fun k => assocNeg (m + 1) i k j)
  have hlow : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i k j = true)
      = nonassocMiddles m i j := by
    simp only [nonassocMiddles]
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_succ_low m i k j hi (Finset.mem_range.mp hk) hj]
  have hhigh : ((range (2 ^ m)).filter (fun k => assocNeg (m + 1) i (2 ^ m + k) j = true)).card
      = (nonassocMiddles m i j).card + 4 := by
    have hcongr : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i (2 ^ m + k) j = true)
        = (range (2 ^ m)).filter
            (fun k => xor (assocNeg m i k j) (decide (k ∈ spanSet i j)) = true) := by
      apply Finset.filter_congr
      intro k hk
      rw [assocNeg_high_middle m i j k hi hj (Finset.mem_range.mp hk),
        shiftDefect_eq_assocNeg_xor_span m i j k hi hj (Finset.mem_range.mp hk) hi0 hj0 hij]
    have hkey := card_filter_xor_mem m (spanSet i j) (spanSet_subset_range m i j hi hj)
      (fun k => assocNeg m i k j)
    have htrue : (spanSet i j).filter (fun k => assocNeg m i k j = true) = ∅ := by
      rw [Finset.filter_eq_empty_iff]
      intro k hk
      rw [assoc_middles_four m i j k hi hj ((mem_spanSet_iff i j k).mp hk)]
      simp
    have hfalse : (spanSet i j).filter (fun k => assocNeg m i k j = false) = spanSet i j := by
      rw [Finset.filter_eq_self]
      intro k hk
      exact assoc_middles_four m i j k hi hj ((mem_spanSet_iff i j k).mp hk)
    have hcard4 : (spanSet i j).card = 4 := middles_four_card i j hi0 hj0 hij
    rw [htrue, hfalse, hcard4] at hkey
    simp only [Finset.card_empty] at hkey
    have hdefm : nonassocMiddles m i j
        = (range (2 ^ m)).filter (fun k => assocNeg m i k j = true) := rfl
    rw [hcongr, hdefm]
    omega
  have hdef : nonassocMiddles (m + 1) i j
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) i k j = true) := rfl
  rw [hdef, hsplit, hlow, hhigh]
  omega

/-- **The new imaginary unit is always an extremal partner**: `(e_i, e_h)` is maximal. -/
theorem nonassocMiddles_newUnit_card (m i : Nat) (hi : i < 2 ^ m) (hi0 : i ≠ 0) :
    (nonassocMiddles (m + 1) i (2 ^ m)).card + 4 = 2 ^ (m + 1) := by
  classical
  have hsplit := card_filter_range_split m (fun k => assocNeg (m + 1) i k (2 ^ m))
  have hlow : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i k (2 ^ m) = true)
      = (range (2 ^ m)).filter (fun k => commNeg i k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_newUnit_low m i k hi (Finset.mem_range.mp hk)]
  have hhigh : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i (2 ^ m + k) (2 ^ m) = true)
      = (range (2 ^ m)).filter (fun k => commNeg i k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_newUnit_high m i k hi (Finset.mem_range.mp hk)]
  have hc := card_filter_commNeg m i hi hi0
  have hdef : nonassocMiddles (m + 1) i (2 ^ m)
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) i k (2 ^ m) = true) := rfl
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  rw [hdef, hsplit, hlow, hhigh]
  omega

/-- The pair `(e_h, e_{h+a})` is maximal as well. -/
theorem nonassocMiddles_unitPair_card (m a : Nat) (ha : a < 2 ^ m) (ha0 : a ≠ 0) :
    (nonassocMiddles (m + 1) (2 ^ m) (2 ^ m + a)).card + 4 = 2 ^ (m + 1) := by
  classical
  have hsplit := card_filter_range_split m (fun k => assocNeg (m + 1) (2 ^ m) k (2 ^ m + a))
  have hlow : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) (2 ^ m) k (2 ^ m + a) = true)
      = (range (2 ^ m)).filter (fun k => commNeg a k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_unitPair_low m a k ha (Finset.mem_range.mp hk)]
  have hhigh : (range (2 ^ m)).filter
        (fun k => assocNeg (m + 1) (2 ^ m) (2 ^ m + k) (2 ^ m + a) = true)
      = (range (2 ^ m)).filter (fun k => commNeg a k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_unitPair_high m a k ha (Finset.mem_range.mp hk)]
  have hc := card_filter_commNeg m a ha ha0
  have hdef : nonassocMiddles (m + 1) (2 ^ m) (2 ^ m + a)
      = (range (2 ^ (m + 1))).filter
          (fun k => assocNeg (m + 1) (2 ^ m) k (2 ^ m + a) = true) := rfl
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  rw [hdef, hsplit, hlow, hhigh]
  omega

/-- The diagonal pair `(e_i, e_{h+i})` is maximal. -/
theorem nonassocMiddles_diagPair_card (m i : Nat) (hi : i < 2 ^ m) (hi0 : i ≠ 0) :
    (nonassocMiddles (m + 1) i (2 ^ m + i)).card + 4 = 2 ^ (m + 1) := by
  classical
  have hsplit := card_filter_range_split m (fun k => assocNeg (m + 1) i k (2 ^ m + i))
  have hlow : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i k (2 ^ m + i) = true)
      = (range (2 ^ m)).filter (fun k => commNeg i k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_diagPair_low m i k hi (Finset.mem_range.mp hk)]
  have hhigh : (range (2 ^ m)).filter (fun k => assocNeg (m + 1) i (2 ^ m + k) (2 ^ m + i) = true)
      = (range (2 ^ m)).filter (fun k => commNeg i k = true) := by
    apply Finset.filter_congr
    intro k hk
    rw [assocNeg_diagPair_high m i k hi (Finset.mem_range.mp hk)]
  have hc := card_filter_commNeg m i hi hi0
  have hdef : nonassocMiddles (m + 1) i (2 ^ m + i)
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) i k (2 ^ m + i) = true) := rfl
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  rw [hdef, hsplit, hlow, hhigh]
  omega

/-- **The complementation law, low first index.** -/
theorem nonassocMiddles_complement_card (m i c : Nat) (hi : i < 2 ^ m) (hc : c < 2 ^ m)
    (hi0 : i ≠ 0) (hc0 : c ≠ 0) (hic : i ≠ c) :
    (nonassocMiddles (m + 1) i (2 ^ m + c)).card + (nonassocMiddles (m + 1) i c).card
      = 2 ^ (m + 1) := by
  classical
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hile : i < 2 ^ (m + 1) := by omega
  have hcle : c < 2 ^ (m + 1) := by omega
  have hpc : (pairSet i).card = 2 := Finset.card_pair (Ne.symm hi0)
  -- low halves
  have hlowflip : ∀ b, b < 2 ^ m → assocNeg (m + 1) i b (2 ^ m + c)
      = !(xor (assocNeg (m + 1) i b c) (decide (b ∈ pairSet i))) := by
    intro b hb
    rw [assocNeg_succ_llh m i b c hi hb hc, assocNeg_succ_low m i b c hi hb hc,
      sec001_eq_assocNeg_flip m i b c hi hb hc hi0 hc0 hic]
  have hlow := card_flip m (pairSet i) (pairSet_subset_range m i hi)
    (fun b => assocNeg (m + 1) i b (2 ^ m + c)) (fun b => assocNeg (m + 1) i b c) hlowflip
  have hY0 : assocNeg (m + 1) i 0 c = false := assocNeg_zero_mid (m + 1) i c
  have hYi : assocNeg (m + 1) i i c = false := assocNeg_left_alt (m + 1) i c hile hcle
  have hfT : (pairSet i).filter (fun b => assocNeg (m + 1) i b c = true) = ∅ := by
    rw [Finset.filter_eq_empty_iff]
    intro b hb
    rcases (mem_pairSet_iff i b).mp hb with rfl | rfl
    · simp [hY0]
    · simp [hYi]
  have hfF : (pairSet i).filter (fun b => assocNeg (m + 1) i b c = false) = pairSet i := by
    rw [Finset.filter_eq_self]
    intro b hb
    rcases (mem_pairSet_iff i b).mp hb with rfl | rfl
    · exact hY0
    · exact hYi
  rw [hfT, hfF, hpc, Finset.card_empty] at hlow
  -- high halves
  have hhighflip : ∀ b, b < 2 ^ m → assocNeg (m + 1) i (2 ^ m + b) (2 ^ m + c)
      = !(xor (assocNeg (m + 1) i (2 ^ m + b) c) (decide (b ∈ pairSet i))) := by
    intro b hb
    rw [assocNeg_succ_lhh m i b c hi hb hc, assocNeg_succ_lhl m i b c hi hb hc,
      sec011_eq_sec010_flip m i b c hi hb hc hi0 hc0 hic]
  have hhigh := card_flip m (pairSet i) (pairSet_subset_range m i hi)
    (fun b => assocNeg (m + 1) i (2 ^ m + b) (2 ^ m + c))
    (fun b => assocNeg (m + 1) i (2 ^ m + b) c) hhighflip
  have hZ0 : assocNeg (m + 1) i (2 ^ m + 0) c = true := by
    rw [assocNeg_succ_lhl m i 0 c hi (by positivity) hc,
      sec010_eq_assocNeg_xor_span m i 0 c hi (by positivity) hc hi0 hc0 hic,
      assocNeg_zero_mid m i c]
    simp [spanSet]
  have hZi : assocNeg (m + 1) i (2 ^ m + i) c = true := by
    rw [assocNeg_succ_lhl m i i c hi hi hc,
      sec010_eq_assocNeg_xor_span m i i c hi hi hc hi0 hc0 hic,
      assocNeg_left_alt m i c hi hc]
    simp [spanSet]
  have hgT : (pairSet i).filter (fun b => assocNeg (m + 1) i (2 ^ m + b) c = true)
      = pairSet i := by
    rw [Finset.filter_eq_self]
    intro b hb
    rcases (mem_pairSet_iff i b).mp hb with rfl | rfl
    · exact hZ0
    · exact hZi
  have hZ0' : assocNeg (m + 1) i (2 ^ m) c = true := by simpa using hZ0
  have hgF : (pairSet i).filter (fun b => assocNeg (m + 1) i (2 ^ m + b) c = false) = ∅ := by
    rw [Finset.filter_eq_empty_iff]
    intro b hb
    rcases (mem_pairSet_iff i b).mp hb with rfl | rfl
    · simp [hZ0']
    · simp [hZi]
  rw [hgT, hgF, hpc, Finset.card_empty] at hhigh
  have hsplitA := card_filter_range_split m (fun k => assocNeg (m + 1) i k (2 ^ m + c))
  have hsplitB := card_filter_range_split m (fun k => assocNeg (m + 1) i k c)
  have hdefA : nonassocMiddles (m + 1) i (2 ^ m + c)
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) i k (2 ^ m + c) = true) := rfl
  have hdefB : nonassocMiddles (m + 1) i c
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) i k c = true) := rfl
  rw [hdefA, hdefB, hsplitA, hsplitB]
  simp only [] at hlow hhigh ⊢
  omega

/-- **The complementation law, high first index.** -/
theorem nonassocMiddles_complement_card_high (m a c : Nat) (ha : a < 2 ^ m) (hc : c < 2 ^ m)
    (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    (nonassocMiddles (m + 1) (2 ^ m + a) (2 ^ m + c)).card
        + (nonassocMiddles (m + 1) (2 ^ m + a) c).card = 2 ^ (m + 1) := by
  classical
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hpc : (pairSet a).card = 2 := Finset.card_pair (Ne.symm ha0)
  have hcNac : commNeg a c = true := by simp [commNeg, ha0, hc0, hac]
  have hbool : ∀ u t d : Bool, xor (!(xor u d)) t = !(xor (xor u t) d) := by decide
  -- low halves
  have hlowflip : ∀ b, b < 2 ^ m → assocNeg (m + 1) (2 ^ m + a) b (2 ^ m + c)
      = !(xor (assocNeg (m + 1) (2 ^ m + a) b c) (decide (b ∈ pairSet a))) := by
    intro b hb
    rw [assocNeg_succ_hlh m a b c ha hb hc, assocNeg_succ_hll m a b c ha hb hc,
      sec001_eq_assocNeg_flip m a b c ha hb hc ha0 hc0 hac, hbool]
  have hlow := card_flip m (pairSet a) (pairSet_subset_range m a ha)
    (fun b => assocNeg (m + 1) (2 ^ m + a) b (2 ^ m + c))
    (fun b => assocNeg (m + 1) (2 ^ m + a) b c) hlowflip
  have hW0 : assocNeg (m + 1) (2 ^ m + a) 0 c = false := assocNeg_zero_mid (m + 1) _ c
  have hWa : assocNeg (m + 1) (2 ^ m + a) a c = true := by
    rw [assocNeg_succ_hll m a a c ha ha hc, assocNeg_left_alt m a c ha hc, hcNac]
    rfl
  have hfT : (pairSet a).filter (fun b => assocNeg (m + 1) (2 ^ m + a) b c = true)
      = {a} := by
    ext b
    simp only [pairSet, Finset.mem_filter, Finset.mem_insert, Finset.mem_singleton]
    constructor
    · rintro ⟨hb, hval⟩
      rcases hb with rfl | rfl
      · rw [hW0] at hval; exact absurd hval (by simp)
      · rfl
    · rintro rfl
      exact ⟨Or.inr rfl, hWa⟩
  have hfF : (pairSet a).filter (fun b => assocNeg (m + 1) (2 ^ m + a) b c = false)
      = {0} := by
    ext b
    simp only [pairSet, Finset.mem_filter, Finset.mem_insert, Finset.mem_singleton]
    constructor
    · rintro ⟨hb, hval⟩
      rcases hb with rfl | rfl
      · rfl
      · rw [hWa] at hval; exact absurd hval (by simp)
    · rintro rfl
      exact ⟨Or.inl rfl, hW0⟩
  rw [hfT, hfF, Finset.card_singleton, Finset.card_singleton] at hlow
  -- high halves
  have hhighflip : ∀ b, b < 2 ^ m → assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) (2 ^ m + c)
      = !(xor (assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c) (decide (b ∈ pairSet a))) := by
    intro b hb
    rw [assocNeg_succ_hhh m a b c ha hb hc, assocNeg_succ_hhl m a b c ha hb hc,
      sec011_eq_sec010_flip m a b c ha hb hc ha0 hc0 hac, hbool]
  have hhigh := card_flip m (pairSet a) (pairSet_subset_range m a ha)
    (fun b => assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) (2 ^ m + c))
    (fun b => assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c) hhighflip
  have hV0 : assocNeg (m + 1) (2 ^ m + a) (2 ^ m + 0) c = true := by
    rw [assocNeg_succ_hhl m a 0 c ha (by positivity) hc,
      sec010_eq_assocNeg_xor_span m a 0 c ha (by positivity) hc ha0 hc0 hac,
      assocNeg_zero_mid m a c]
    simp [spanSet, commNeg]
  have hVa : assocNeg (m + 1) (2 ^ m + a) (2 ^ m + a) c = false := by
    rw [assocNeg_succ_hhl m a a c ha ha hc,
      sec010_eq_assocNeg_xor_span m a a c ha ha hc ha0 hc0 hac,
      assocNeg_left_alt m a c ha hc, hcNac]
    simp [spanSet]
  have hgT : (pairSet a).filter (fun b => assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c = true)
      = {0} := by
    ext b
    simp only [pairSet, Finset.mem_filter, Finset.mem_insert, Finset.mem_singleton]
    constructor
    · rintro ⟨hb, hval⟩
      rcases hb with rfl | rfl
      · rfl
      · rw [hVa] at hval; exact absurd hval (by simp)
    · rintro rfl
      exact ⟨Or.inl rfl, hV0⟩
  have hgF : (pairSet a).filter (fun b => assocNeg (m + 1) (2 ^ m + a) (2 ^ m + b) c = false)
      = {a} := by
    ext b
    simp only [pairSet, Finset.mem_filter, Finset.mem_insert, Finset.mem_singleton]
    constructor
    · rintro ⟨hb, hval⟩
      rcases hb with rfl | rfl
      · rw [hV0] at hval; exact absurd hval (by simp)
      · rfl
    · rintro rfl
      exact ⟨Or.inr rfl, hVa⟩
  rw [hgT, hgF, Finset.card_singleton, Finset.card_singleton] at hhigh
  have hsplitA := card_filter_range_split m
    (fun k => assocNeg (m + 1) (2 ^ m + a) k (2 ^ m + c))
  have hsplitB := card_filter_range_split m (fun k => assocNeg (m + 1) (2 ^ m + a) k c)
  have hdefA : nonassocMiddles (m + 1) (2 ^ m + a) (2 ^ m + c)
      = (range (2 ^ (m + 1))).filter
          (fun k => assocNeg (m + 1) (2 ^ m + a) k (2 ^ m + c) = true) := rfl
  have hdefB : nonassocMiddles (m + 1) (2 ^ m + a) c
      = (range (2 ^ (m + 1))).filter (fun k => assocNeg (m + 1) (2 ^ m + a) k c = true) := rfl
  rw [hdefA, hdefB, hsplitA, hsplitB]
  simp only [] at hlow hhigh ⊢
  omega

/-- **The high-high law**: a pair of indices from the new half has the same degree as the
corresponding pair from the old half. -/
theorem nonassocMiddles_highhigh_card (m a c : Nat) (ha : a < 2 ^ m) (hc : c < 2 ^ m)
    (ha0 : a ≠ 0) (hc0 : c ≠ 0) (hac : a ≠ c) :
    (nonassocMiddles (m + 1) (2 ^ m + a) (2 ^ m + c)).card
      = (nonassocMiddles (m + 1) a c).card := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hale : a < 2 ^ (m + 1) := by omega
  have hcle : c < 2 ^ (m + 1) := by omega
  have hahle : 2 ^ m + a < 2 ^ (m + 1) := by omega
  have h1 := nonassocMiddles_complement_card_high m a c ha hc ha0 hc0 hac
  have h2 := nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) c hahle hcle
  have h3 := nonassocMiddles_complement_card m c a hc ha hc0 ha0 (Ne.symm hac)
  have h4 := nonassocMiddles_card_reverse (m + 1) c a hcle hale
  omega

/-! ## 5. Degree quantization -/

/-- **Degree quantization.** In every dimension `2ⁿ⁺¹ ≥ 16` the number of non-associating
middles of an admissible outer pair is congruent to `4` modulo `8`; equivalently every
degree of the annihilation graph inside a charge sector is of the form `8 + 16t`. -/
theorem nonassocMiddles_card_mod_eight (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (nonassocMiddles n i j).card % 8 = 4 := by
  induction n, hn using Nat.le_induction generalizing i j with
  | base =>
      rw [Sovereign.annihilation_graph_regular_dim16 i j (by omega) (by omega) hi0 hj0 hij]
  | succ m hm ih =>
      have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
      have hge : (8 : Nat) ≤ 2 ^ m := by
        calc (8 : Nat) = 2 ^ 3 := by norm_num
          _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
      obtain ⟨t, ht⟩ : (8 : Nat) ∣ 2 ^ (m + 1) := by
        have h83 : (8 : Nat) = 2 ^ 3 := by norm_num
        rw [h83]
        exact pow_dvd_pow 2 (by omega)
      have hcase : ∀ x : Nat, x < 2 ^ (m + 1) →
          x < 2 ^ m ∨ x = 2 ^ m ∨ ∃ a, a ≠ 0 ∧ a < 2 ^ m ∧ x = 2 ^ m + a := by
        intro x hx
        rcases lt_trichotomy x (2 ^ m) with h | h | h
        · exact Or.inl h
        · exact Or.inr (Or.inl h)
        · exact Or.inr (Or.inr ⟨x - 2 ^ m, by omega, by omega, by omega⟩)
      have hll : ∀ x y : Nat, x < 2 ^ m → y < 2 ^ m → x ≠ 0 → y ≠ 0 → x ≠ y →
          (nonassocMiddles (m + 1) x y).card % 8 = 4 := by
        intro x y hx hy hx0 hy0 hxy
        rw [nonassocMiddles_succ_card m x y hx hy hx0 hy0 hxy]
        have := ih x y hx hy hx0 hy0 hxy
        omega
      have hmix : ∀ x y : Nat, x < 2 ^ m → y < 2 ^ m → x ≠ 0 → y ≠ 0 →
          (nonassocMiddles (m + 1) x (2 ^ m + y)).card % 8 = 4 := by
        intro x y hx hy hx0 hy0
        by_cases hxy : x = y
        · subst hxy
          have h := nonassocMiddles_diagPair_card m x hx hx0
          omega
        · have h1 := nonassocMiddles_complement_card m x y hx hy hx0 hy0 hxy
          have h2 := hll x y hx hy hx0 hy0 hxy
          omega
      rcases hcase i hi with hI | hI | ⟨a, ha0, ha, rfl⟩
      · rcases hcase j hj with hJ | hJ | ⟨c, hc0, hc, rfl⟩
        · exact hll i j hI hJ hi0 hj0 hij
        · subst hJ
          have h := nonassocMiddles_newUnit_card m i hI hi0
          omega
        · exact hmix i c hI hc hi0 hc0
      · subst hI
        rcases hcase j hj with hJ | hJ | ⟨c, hc0, hc, rfl⟩
        · have hrev := nonassocMiddles_card_reverse (m + 1) (2 ^ m) j (by omega) (by omega)
          have h := nonassocMiddles_newUnit_card m j hJ hj0
          omega
        · exact absurd hJ.symm hij
        · have h := nonassocMiddles_unitPair_card m c hc hc0
          omega
      · rcases hcase j hj with hJ | hJ | ⟨c, hc0, hc, rfl⟩
        · have hrev := nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) j (by omega) (by omega)
          have h := hmix j a hJ ha hj0 ha0
          omega
        · subst hJ
          have hrev := nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) (2 ^ m)
            (by omega) (by omega)
          have h := nonassocMiddles_unitPair_card m a ha ha0
          omega
        · have hac : a ≠ c := fun h => hij (by rw [h])
          have h := nonassocMiddles_highhigh_card m a c ha hc ha0 hc0 hac
          have h2 := hll a c ha hc ha0 hc0 hac
          omega

/-! ## 6. The full degree spectrum -/

/-- **Realizability.** Every value allowed by quantization and by the two universal bounds
is actually attained by some admissible outer pair. -/
theorem exists_nonassocMiddles_card (n : Nat) (hn : 3 ≤ n) (v : Nat) (hv : v % 8 = 4)
    (hv4 : 4 ≤ v) (hvmax : v ≤ 2 ^ n - 4) :
    ∃ i j : Nat, i < 2 ^ n ∧ j < 2 ^ n ∧ i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧
      (nonassocMiddles n i j).card = v := by
  induction n, hn using Nat.le_induction generalizing v with
  | base =>
      have h8 : (2 : Nat) ^ 3 = 8 := by norm_num
      have hv4' : v = 4 := by omega
      refine ⟨1, 2, by omega, by omega, by norm_num, by norm_num, by norm_num, ?_⟩
      rw [hv4']
      exact Sovereign.annihilation_graph_regular_dim16 1 2 (by norm_num) (by norm_num) (by norm_num)
        (by norm_num) (by norm_num)
  | succ m hm ih =>
      have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
      have hge : (8 : Nat) ≤ 2 ^ m := by
        calc (8 : Nat) = 2 ^ 3 := by norm_num
          _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
      obtain ⟨t, ht⟩ : (16 : Nat) ∣ 2 ^ (m + 1) := by
        have h164 : (16 : Nat) = 2 ^ 4 := by norm_num
        rw [h164]
        exact pow_dvd_pow 2 (by omega)
      have key : ∀ w : Nat, w % 16 = 12 → w ≤ 2 ^ (m + 1) - 4 →
          ∃ i j : Nat, i < 2 ^ m ∧ j < 2 ^ m ∧ i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧
            (nonassocMiddles (m + 1) i j).card = w := by
        intro w hw hwmax
        obtain ⟨i, j, hi, hj, hi0, hj0, hij, hcard⟩ :=
          ih ((w - 4) / 2) (by omega) (by omega) (by omega)
        refine ⟨i, j, hi, hj, hi0, hj0, hij, ?_⟩
        rw [nonassocMiddles_succ_card m i j hi hj hi0 hj0 hij, hcard]
        omega
      by_cases h16 : v % 16 = 12
      · obtain ⟨i, j, hi, hj, hi0, hj0, hij, hcard⟩ := key v h16 hvmax
        exact ⟨i, j, by omega, by omega, hi0, hj0, hij, hcard⟩
      · obtain ⟨i, j, hi, hj, hi0, hj0, hij, hcard⟩ :=
          key (2 ^ (m + 1) - v) (by omega) (by omega)
        refine ⟨i, 2 ^ m + j, by omega, by omega, hi0, by omega, by omega, ?_⟩
        have hcomp := nonassocMiddles_complement_card m i j hi hj hi0 hj0 hij
        omega

/-- **The full degree spectrum.** In dimension `D = 2ⁿ⁺¹ ≥ 16` a number `v` is the count of
non-associating middles of some admissible outer pair exactly when `v ≡ 4 [MOD 8]` and
`4 ≤ v ≤ 2ⁿ - 4`.  In graph terms: the degrees occurring in a charge sector are exactly
`8, 24, 40, …, D - 8`. -/
theorem nonassocMiddles_card_spectrum (n : Nat) (hn : 3 ≤ n) (v : Nat) :
    (∃ i j : Nat, i < 2 ^ n ∧ j < 2 ^ n ∧ i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧
        (nonassocMiddles n i j).card = v)
      ↔ (v % 8 = 4 ∧ 4 ≤ v ∧ v ≤ 2 ^ n - 4) := by
  constructor
  · rintro ⟨i, j, hi, hj, hi0, hj0, hij, rfl⟩
    exact ⟨nonassocMiddles_card_mod_eight n hn i j hi hj hi0 hj0 hij,
      nonassocMiddles_card_bounds n i j hn hi hj hi0 hj0 hij⟩
  · rintro ⟨h1, h2, h3⟩
    exact exists_nonassocMiddles_card n hn v h1 h2 h3

/-- The spectrum as an explicit finite set: the attained values are `4 + 8t`, `t < 2ⁿ⁻³`,
so there are exactly `2ⁿ⁻³ = D/16` distinct degrees in dimension `D = 2ⁿ⁺¹`. -/
theorem nonassocMiddles_card_levels (n : Nat) (hn : 3 ≤ n) (v : Nat) :
    (∃ i j : Nat, i < 2 ^ n ∧ j < 2 ^ n ∧ i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧
        (nonassocMiddles n i j).card = v)
      ↔ ∃ t : Nat, t < 2 ^ (n - 3) ∧ v = 4 + 8 * t := by
  have hsplit : (2 : Nat) ^ n = 8 * 2 ^ (n - 3) := by
    rw [show (8 : Nat) = 2 ^ 3 by norm_num, ← pow_add]
    congr 1
    omega
  have hpos : (1 : Nat) ≤ 2 ^ (n - 3) := Nat.one_le_two_pow
  rw [nonassocMiddles_card_spectrum n hn v]
  constructor
  · rintro ⟨h1, h2, h3⟩
    exact ⟨(v - 4) / 8, by omega, by omega⟩
  · rintro ⟨t, ht, rfl⟩
    exact ⟨by omega, by omega, by omega⟩

/-- The annihilation-graph reading: the number of annihilation partners of a cross-half
zero divisor inside its charge sector is `8 + 16 t` in every dimension `2ⁿ⁺¹ ≥ 16`. -/
theorem crossSign_partners_card_quantized (n : Nat) (hn : 3 ≤ n) (i j : Nat)
    (hi : i < 2 ^ n) (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    ∃ t : Nat, t < 2 ^ (n - 3) ∧
      2 * ((range (2 ^ n)).filter
        (fun k => crossSign n i j k (k ^^^ (i ^^^ j)) = true)).card = 8 + 16 * t := by
  have hcongr : (range (2 ^ n)).filter
      (fun k => crossSign n i j k (k ^^^ (i ^^^ j)) = true) = nonassocMiddles n i j := by
    simp only [nonassocMiddles]
    apply Finset.filter_congr
    intro k hk
    rw [crossSign_eq_assocNeg n i j k hi hj (Finset.mem_range.mp hk)]
  rw [hcongr]
  obtain ⟨t, ht, hv⟩ := (nonassocMiddles_card_levels n hn (nonassocMiddles n i j).card).mp
    ⟨i, j, hi, hj, hi0, hj0, hij, rfl⟩
  exact ⟨t, ht, by omega⟩

/-! ## 7. The spectrum as a finite set, and the associating middles -/

/-- The degree spectrum of the annihilation graph in dimension `D = 2ⁿ⁺¹`, recorded as the
finite set of non-associating-middle counts of the admissible outer pairs. -/
def degreeSpectrum (n : Nat) : Finset Nat :=
  (admissiblePairs n).image (fun p => (nonassocMiddles n p.1 p.2).card)

theorem mem_degreeSpectrum_iff (n v : Nat) :
    v ∈ degreeSpectrum n ↔ ∃ i j : Nat, i < 2 ^ n ∧ j < 2 ^ n ∧ i ≠ 0 ∧ j ≠ 0 ∧
      i ≠ j ∧ (nonassocMiddles n i j).card = v := by
  simp only [degreeSpectrum, admissiblePairs, Finset.mem_image, Finset.mem_filter,
    Finset.mem_product, Finset.mem_range]
  constructor
  · rintro ⟨⟨i, j⟩, ⟨⟨hi, hj⟩, hi0, hj0, hij⟩, rfl⟩
    exact ⟨i, j, hi, hj, hi0, hj0, hij, rfl⟩
  · rintro ⟨i, j, hi, hj, hi0, hj0, hij, rfl⟩
    exact ⟨(i, j), ⟨⟨hi, hj⟩, hi0, hj0, hij⟩, rfl⟩

/-- **The degree spectrum is exactly the arithmetic progression `4, 12, 20, …, 2ⁿ - 4`.** -/
theorem degreeSpectrum_eq (n : Nat) (hn : 3 ≤ n) :
    degreeSpectrum n = (range (2 ^ (n - 3))).image (fun t => 4 + 8 * t) := by
  ext v
  rw [mem_degreeSpectrum_iff, nonassocMiddles_card_levels n hn v]
  simp only [Finset.mem_image, Finset.mem_range]
  constructor
  · rintro ⟨t, ht, rfl⟩
    exact ⟨t, ht, rfl⟩
  · rintro ⟨t, ht, rfl⟩
    exact ⟨t, ht, rfl⟩

/-- **The number of distinct degrees.** In dimension `D = 2ⁿ⁺¹ ≥ 16` the annihilation graph
has exactly `2ⁿ⁻³ = D / 16` distinct degrees inside a charge sector. -/
theorem degreeSpectrum_card (n : Nat) (hn : 3 ≤ n) :
    (degreeSpectrum n).card = 2 ^ (n - 3) := by
  rw [degreeSpectrum_eq n hn, Finset.card_image_of_injective _ (fun x y hxy => by omega),
    Finset.card_range]

/-- The middles that do associate with the outer pair `(i, j)`. -/
def assocMiddles (n i j : Nat) : Finset Nat :=
  (range (2 ^ n)).filter (fun k => assocNeg n i k j = false)

theorem assocMiddles_card_add (n i j : Nat) :
    (assocMiddles n i j).card + (nonassocMiddles n i j).card = 2 ^ n := by
  have h := card_filter_not n (fun k => assocNeg n i k j)
  have hcongr : (range (2 ^ n)).filter (fun k => (!assocNeg n i k j) = true)
      = assocMiddles n i j := by
    simp only [assocMiddles]
    apply Finset.filter_congr
    intro k _
    simp
  rw [hcongr] at h
  exact h

/-- **Quantization of the associating middles** (the coset-partition sizes): for every
admissible outer pair and every `n ≥ 3` the number of associating middles is also
congruent to `4` modulo `8`. -/
theorem assocMiddles_card_mod_eight (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (assocMiddles n i j).card % 8 = 4 := by
  have h1 := assocMiddles_card_add n i j
  have h2 := nonassocMiddles_card_mod_eight n hn i j hi hj hi0 hj0 hij
  obtain ⟨t, ht⟩ : (8 : Nat) ∣ 2 ^ n := by
    have h83 : (8 : Nat) = 2 ^ 3 := by norm_num
    rw [h83]
    exact pow_dvd_pow 2 hn
  omega

/-- **The spectrum of associating-middle counts** is the same progression `4, 12, …, 2ⁿ - 4`. -/
theorem assocMiddles_card_spectrum (n : Nat) (hn : 3 ≤ n) (v : Nat) :
    (∃ i j : Nat, i < 2 ^ n ∧ j < 2 ^ n ∧ i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧
        (assocMiddles n i j).card = v)
      ↔ (v % 8 = 4 ∧ 4 ≤ v ∧ v ≤ 2 ^ n - 4) := by
  obtain ⟨t, ht⟩ : (8 : Nat) ∣ 2 ^ n := by
    have h83 : (8 : Nat) = 2 ^ 3 := by norm_num
    rw [h83]
    exact pow_dvd_pow 2 hn
  have hge : (8 : Nat) ≤ 2 ^ n := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
      _ ≤ 2 ^ n := Nat.pow_le_pow_right (by norm_num) hn
  constructor
  · rintro ⟨i, j, hi, hj, hi0, hj0, hij, rfl⟩
    have h1 := assocMiddles_card_add n i j
    have h2 := assocMiddles_card_mod_eight n hn i j hi hj hi0 hj0 hij
    have h3 := nonassocMiddles_card_bounds n i j hn hi hj hi0 hj0 hij
    omega
  · rintro ⟨h1, h2, h3⟩
    obtain ⟨i, j, hi, hj, hi0, hj0, hij, hcard⟩ :=
      exists_nonassocMiddles_card n hn (2 ^ n - v) (by omega) (by omega) (by omega)
    refine ⟨i, j, hi, hj, hi0, hj0, hij, ?_⟩
    have h4 := assocMiddles_card_add n i j
    omega

end Sovereign
