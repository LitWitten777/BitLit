import Sovereign.Combinatorics.TowerDegreeCensusClosedForm

namespace Sovereign

open Finset

/-! ## 1. Counting the words of a given prefix depth -/

/-- A `q`-bit word has at least `k` leading zeros exactly when it is below `2^(q-k)`. -/
theorem leadZeros_ge_iff (q k t : Nat) (hkq : k ≤ q) (ht : t < 2 ^ q) :
    k ≤ leadZeros q t ↔ t < 2 ^ (q - k) := by
  have hsz : Nat.size t ≤ q := Nat.size_le.mpr ht
  constructor
  · intro h
    exact Nat.size_le.mp (by simp only [leadZeros] at h; omega)
  · intro h
    have := Nat.size_le.mpr h
    simp only [leadZeros]; omega

/-- A `q`-bit word has prefix depth at least `k` exactly when it lies in the bottom or in the
top block of size `2^(q-k)`. -/
theorem prefixDepth_ge_iff (q k t : Nat) (hkq : k ≤ q) (ht : t < 2 ^ q) :
    k ≤ prefixDepth q t ↔ (t < 2 ^ (q - k) ∨ 2 ^ q - 2 ^ (q - k) ≤ t) := by
  have h1 := leadZeros_ge_iff q k t hkq ht
  have h2 := leadZeros_ge_iff q k (2 ^ q - 1 - t) hkq (by omega)
  have hp : (2:Nat) ^ (q - k) ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) (by omega)
  simp only [prefixDepth, le_max_iff]
  rw [h1, h2]
  omega

/-- Every word has prefix depth at least one: the leading bit is either a zero or a one. -/
theorem one_le_prefixDepth (q t : Nat) (hq : 1 ≤ q) (ht : t < 2 ^ q) : 1 ≤ prefixDepth q t := by
  rw [prefixDepth_ge_iff q 1 t hq ht]
  have hp : (2:Nat) ^ q = 2 * 2 ^ (q - 1) := by rw [← pow_succ']; congr 1; omega
  omega

theorem card_prefixDepth_ge (q k : Nat) (hk : 1 ≤ k) (hkq : k ≤ q) :
    ((range (2 ^ q)).filter (fun t => k ≤ prefixDepth q t)).card = 2 * 2 ^ (q - k) := by
  have hp : (2:Nat) ^ (q - k) ≤ 2 ^ (q - 1) := Nat.pow_le_pow_right (by norm_num) (by omega)
  have hp2 : (2:Nat) ^ q = 2 * 2 ^ (q - 1) := by rw [← pow_succ']; congr 1; omega
  have hset : (range (2 ^ q)).filter (fun t => k ≤ prefixDepth q t)
      = range (2 ^ (q - k)) ∪ Finset.Ico (2 ^ q - 2 ^ (q - k)) (2 ^ q) := by
    ext t
    simp only [mem_filter, mem_range, mem_union, Finset.mem_Ico]
    constructor
    · rintro ⟨htr, hpd⟩
      rcases (prefixDepth_ge_iff q k t hkq htr).mp hpd with h | h
      · exact Or.inl h
      · exact Or.inr ⟨h, htr⟩
    · rintro (h | ⟨h1, h2⟩)
      · have htr : t < 2 ^ q := by omega
        exact ⟨htr, (prefixDepth_ge_iff q k t hkq htr).mpr (Or.inl h)⟩
      · exact ⟨h2, (prefixDepth_ge_iff q k t hkq h2).mpr (Or.inr h1)⟩
  rw [hset, Finset.card_union_of_disjoint, card_range, Nat.card_Ico]
  · omega
  · rw [Finset.disjoint_left]
    intro a ha hb
    simp only [mem_range] at ha
    simp only [Finset.mem_Ico] at hb
    omega

/-- **The prefix-depth census.**  Exactly `2^(q-k)` of the `2^q` words of length `q` have
prefix depth `k`, for every `1 ≤ k ≤ q - 1`. -/
theorem card_prefixDepth_eq (q k : Nat) (hk : 1 ≤ k) (hkq : k ≤ q - 1) :
    ((range (2 ^ q)).filter (fun t => prefixDepth q t = k)).card = 2 ^ (q - k) := by
  have h1 := card_prefixDepth_ge q k hk (by omega)
  have h2 := card_prefixDepth_ge q (k + 1) (by omega) (by omega)
  have hsplit : ((range (2 ^ q)).filter (fun t => k ≤ prefixDepth q t)).card
      = ((range (2 ^ q)).filter (fun t => prefixDepth q t = k)).card
        + ((range (2 ^ q)).filter (fun t => k + 1 ≤ prefixDepth q t)).card := by
    rw [← Finset.card_union_of_disjoint]
    · congr 1
      ext t
      simp only [mem_filter, mem_union, mem_range]
      constructor
      · rintro ⟨h, hh⟩
        rcases Nat.eq_or_lt_of_le hh with h' | h'
        · exact Or.inl ⟨h, h'.symm⟩
        · exact Or.inr ⟨h, by omega⟩
      · rintro (⟨h, rfl⟩ | ⟨h, hh⟩) <;> exact ⟨h, by omega⟩
    · rw [Finset.disjoint_left]
      intro a ha hb
      simp only [mem_filter] at ha hb
      omega
  have hpow : (2:Nat) ^ (q - k) = 2 * 2 ^ (q - (k + 1)) := by rw [← pow_succ']; congr 1; omega
  omega

/-! ## 2. The interior multiplicities are strictly increasing -/

theorem censusInteriorVal_lt_succ (q k : Nat) (hq : 2 ≤ q) (hk : 1 ≤ k) (hk' : k + 1 ≤ q - 1) :
    censusInteriorVal q k < censusInteriorVal q (k + 1) := by
  obtain ⟨j, rfl⟩ : ∃ j, k = j + 1 := ⟨k - 1, by omega⟩
  have h1 := censusWingExcess_norm q (j + 1) hq (by omega) (by omega)
  have h2 := censusWingExcess_norm q (j + 2) hq (by omega) (by omega)
  have hstep : (j + 1) * 2 ^ q = j * 2 ^ q + 2 ^ q := by ring
  have hhalf : (2:Nat) ^ (q - 1 - (j + 1)) = 2 * 2 ^ (q - 1 - (j + 2)) := by
    rw [← pow_succ']; congr 1; omega
  have hle : (2:Nat) ^ (q - 1 - (j + 2)) < 2 ^ q :=
    Nat.pow_lt_pow_right (by norm_num) (by omega)
  simp only [show j + 1 + 1 = j + 2 from rfl, show j + 1 - 1 = j from rfl,
    show j + 2 - 1 = j + 1 from rfl, censusInteriorVal] at *
  omega

theorem censusInteriorVal_strictMonoOn (q k k' : Nat) (hq : 2 ≤ q) (hk : 1 ≤ k) (hkk' : k < k')
    (hk' : k' ≤ q - 1) : censusInteriorVal q k < censusInteriorVal q k' := by
  induction k' with
  | zero => omega
  | succ m ih =>
    rcases Nat.lt_or_ge k m with h | h
    · exact lt_trans (ih h (by omega)) (censusInteriorVal_lt_succ q m hq (by omega) (by omega))
    · have : k = m := by omega
      subst this
      exact censusInteriorVal_lt_succ q k hq hk (by omega)

theorem censusInteriorVal_lt_censusZeroVal (q k : Nat) (hq : 2 ≤ q) (hk : 1 ≤ k)
    (hkq : k ≤ q - 1) : censusInteriorVal q k < censusZeroVal q := by
  have hle : censusInteriorVal q k ≤ censusInteriorVal q (q - 1) := by
    rcases Nat.eq_or_lt_of_le hkq with h | h
    · rw [h]
    · exact le_of_lt (censusInteriorVal_strictMonoOn q k (q - 1) hq hk h (by omega))
  have hpow : (4:Nat) ≤ 2 ^ q := by
    calc (4:Nat) = 2 ^ 2 := by norm_num
    _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
  simp only [censusZeroVal]
  omega

theorem censusZeroVal_lt_censusMaxVal (q : Nat) (hq : 2 ≤ q) :
    censusZeroVal q < censusMaxVal q := by
  have hpow : (2:Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
  have h4 : (4:Nat) ≤ 2 ^ q := by
    calc (4:Nat) = 2 ^ 2 := by norm_num
    _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
  simp only [censusZeroVal, censusMaxVal]
  omega

/-! ## 3. A dyadic sum -/

theorem Icc_one_succ (m : Nat) : Finset.Icc 1 (m + 1) = insert (m + 1) (Finset.Icc 1 m) := by
  ext k
  simp only [Finset.mem_Icc, Finset.mem_insert]
  omega

theorem sum_two_pow_Icc (m : Nat) : (∑ k ∈ Finset.Icc 1 m, 2 ^ (m - k)) = 2 ^ m - 1 := by
  induction m with
  | zero => simp
  | succ m ih =>
    have hins : (m + 1) ∉ Finset.Icc 1 m := by simp only [Finset.mem_Icc]; omega
    rw [Icc_one_succ m, Finset.sum_insert hins, Nat.sub_self, pow_zero]
    have hshift : ∑ k ∈ Finset.Icc 1 m, 2 ^ (m + 1 - k) = 2 * ∑ k ∈ Finset.Icc 1 m, 2 ^ (m - k) := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl (fun k hk => ?_)
      simp only [Finset.mem_Icc] at hk
      rw [show m + 1 - k = (m - k) + 1 from by omega, pow_succ]
      ring
    have hpos : (1:Nat) ≤ 2 ^ m := Nat.one_le_two_pow
    have hpow : (2:Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
    rw [hshift, ih]
    omega

/-! ## 4. The multiplicity census of the annihilation graph -/

/-- Away from the two extreme degrees the multiplicity is the interior value at the prefix
depth of the degree index. -/
theorem degreeCount_interior (q t : Nat) (hq : 2 ≤ q) (ht : t < 2 ^ q) (ht0 : t ≠ 0)
    (htm : t ≠ 2 ^ q - 1) :
    degreeCount (q + 3) (8 * t + 4) = censusInteriorVal q (prefixDepth q t) := by
  rw [degreeCount_eq_censusClosedForm q hq t ht, censusClosedForm, if_neg ht0, if_neg htm]

/-- **The multiplicity census.**  In dimension `2^(q+3)` exactly `2^(q-k)` of the `2^q`
degrees are realised by `censusInteriorVal q k` ordered admissible pairs, for every
`1 ≤ k ≤ q - 1`. -/
theorem degreeCount_level_card (q k : Nat) (hq : 2 ≤ q) (hk : 1 ≤ k) (hkq : k ≤ q - 1) :
    ((range (2 ^ q)).filter
      (fun t => degreeCount (q + 3) (8 * t + 4) = censusInteriorVal q k)).card = 2 ^ (q - k) := by
  rw [← card_prefixDepth_eq q k hk hkq]
  congr 1
  ext t
  simp only [mem_filter, mem_range]
  constructor
  · rintro ⟨ht, hval⟩
    refine ⟨ht, ?_⟩
    have ht0 : t ≠ 0 := by
      rintro rfl
      rw [degreeCount_eq_censusClosedForm q hq 0 ht, censusClosedForm, if_pos rfl] at hval
      have := censusInteriorVal_lt_censusZeroVal q k hq hk hkq
      omega
    have htm : t ≠ 2 ^ q - 1 := by
      rintro rfl
      rw [degreeCount_eq_censusClosedForm q hq _ ht, censusClosedForm,
        if_neg (by omega : ¬ (2 ^ q - 1 = 0)), if_pos rfl] at hval
      have h1 := censusInteriorVal_lt_censusZeroVal q k hq hk hkq
      have h2 := censusZeroVal_lt_censusMaxVal q hq
      omega
    rw [degreeCount_interior q t hq ht ht0 htm] at hval
    have hd1 : 1 ≤ prefixDepth q t := one_le_prefixDepth q t (by omega) ht
    have hd2 : prefixDepth q t ≤ q - 1 := prefixDepth_le q t ht0 (by omega)
    rcases Nat.lt_trichotomy (prefixDepth q t) k with h | h | h
    · have := censusInteriorVal_strictMonoOn q (prefixDepth q t) k hq hd1 h hkq
      omega
    · exact h
    · have := censusInteriorVal_strictMonoOn q k (prefixDepth q t) hq hk h hd2
      omega
  · rintro ⟨ht, hpd⟩
    have ht0 : t ≠ 0 := by
      rintro rfl
      rw [prefixDepth_zero] at hpd
      omega
    have htm : t ≠ 2 ^ q - 1 := by
      rintro rfl
      rw [show (2:Nat) ^ q - 1 = 2 ^ q - 1 - 0 from by omega, prefixDepth_symm q 0 (by omega),
        prefixDepth_zero] at hpd
      omega
    exact ⟨ht, by rw [degreeCount_interior q t hq ht ht0 htm, hpd]⟩

/-- **The degree multiset of the annihilation graph in every dimension.**  In dimension
`2^(q+3)` (`q ≥ 2`) the minimal degree `4` is realised by `censusZeroVal q` ordered
admissible pairs, the maximal degree `2^(q+3) - 4` by `censusMaxVal q`, and for each
`1 ≤ k ≤ q - 1` exactly `2^(q-k)` further degrees are realised by `censusInteriorVal q k`
pairs each; the `q + 1` multiplicities so listed are pairwise distinct and the classes
account for all `2^q` degrees. -/
theorem tower_degree_census_multiset (q : Nat) (hq : 2 ≤ q) :
    degreeCount (q + 3) 4 = censusZeroVal q ∧
    degreeCount (q + 3) (8 * (2 ^ q - 1) + 4) = censusMaxVal q ∧
    (∀ k, 1 ≤ k → k ≤ q - 1 →
      ((range (2 ^ q)).filter
        (fun t => degreeCount (q + 3) (8 * t + 4) = censusInteriorVal q k)).card
          = 2 ^ (q - k)) ∧
    (∑ k ∈ Finset.Icc 1 (q - 1), 2 ^ (q - k)) + 2 = 2 ^ q := by
  have h4 : (4:Nat) ≤ 2 ^ q := by
    calc (4:Nat) = 2 ^ 2 := by norm_num
    _ ≤ 2 ^ q := Nat.pow_le_pow_right (by norm_num) hq
  refine ⟨?_, ?_, fun k hk hkq => degreeCount_level_card q k hq hk hkq, ?_⟩
  · have := degreeCount_eq_censusClosedForm q hq 0 (by omega)
    rwa [Nat.mul_zero, Nat.zero_add, censusClosedForm, if_pos rfl] at this
  · have := degreeCount_eq_censusClosedForm q hq (2 ^ q - 1) (by omega)
    rwa [censusClosedForm, if_neg (by omega : ¬ (2 ^ q - 1 = 0)), if_pos rfl] at this
  · have hshift : ∑ k ∈ Finset.Icc 1 (q - 1), 2 ^ (q - k)
        = 2 * ∑ k ∈ Finset.Icc 1 (q - 1), 2 ^ (q - 1 - k) := by
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl (fun k hk => ?_)
      simp only [Finset.mem_Icc] at hk
      rw [show q - k = (q - 1 - k) + 1 from by omega, pow_succ]
      ring
    have hpow : (2:Nat) ^ q = 2 * 2 ^ (q - 1) := by rw [← pow_succ']; congr 1; omega
    have hpos : (1:Nat) ≤ 2 ^ (q - 1) := Nat.one_le_two_pow
    rw [hshift, sum_two_pow_Icc (q - 1)]
    omega

end Sovereign
