import Sovereign.Combinatorics.TowerDegreeQuantization

namespace Sovereign

open Finset

/-! ## 1. The degree function -/

/-- The exact degree function of the annihilation graph: for an admissible pair `(i, j)` of
indices below `2ⁿ`, `towerDegree n i j` is the number of middles `k` for which
`(e_i e_k) e_j ≠ e_i (e_k e_j)`.  Each recursive step strips the leading bit. -/
def towerDegree : Nat → Nat → Nat → Nat
  | 0, _, _ => 0
  | m + 1, i, j =>
      if i < 2 ^ m then
        if j < 2 ^ m then 2 * towerDegree m i j + 4
        else if j - 2 ^ m = 0 ∨ j - 2 ^ m = i then 2 ^ (m + 1) - 4
        else 2 ^ (m + 1) - (2 * towerDegree m i (j - 2 ^ m) + 4)
      else
        if j < 2 ^ m then
          if i - 2 ^ m = 0 ∨ i - 2 ^ m = j then 2 ^ (m + 1) - 4
          else 2 ^ (m + 1) - (2 * towerDegree m j (i - 2 ^ m) + 4)
        else if i - 2 ^ m = 0 ∨ j - 2 ^ m = 0 then 2 ^ (m + 1) - 4
        else 2 * towerDegree m (i - 2 ^ m) (j - 2 ^ m) + 4

/-- **The exact degree formula.**  For every level `n` and every admissible outer pair
`(i, j)` the number of non-associating middles is `towerDegree n i j`. -/
theorem nonassocMiddles_card_eq_towerDegree (n i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n)
    (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (nonassocMiddles n i j).card = towerDegree n i j := by
  induction n generalizing i j with
  | zero => simp only [pow_zero] at hi; omega
  | succ m ih =>
    have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
    rw [towerDegree]
    by_cases hil : i < 2 ^ m
    · rw [if_pos hil]
      by_cases hjl : j < 2 ^ m
      · -- both indices in the old half
        rw [if_pos hjl, nonassocMiddles_succ_card m i j hil hjl hi0 hj0 hij,
          ih i j hil hjl hi0 hj0 hij]
      · rw [if_neg hjl]
        have hcl : j - 2 ^ m < 2 ^ m := by omega
        by_cases hdeg : j - 2 ^ m = 0 ∨ j - 2 ^ m = i
        · -- `i` low, `j = 2^m + c` with `c = 0` or `c = i`
          rw [if_pos hdeg]
          rcases hdeg with hc0 | hci
          · have hj2 : j = 2 ^ m := by omega
            have h := nonassocMiddles_newUnit_card m i hil hi0
            rw [← hj2] at h
            omega
          · have hj2 : j = 2 ^ m + i := by omega
            have h := nonassocMiddles_diagPair_card m i hil hi0
            rw [← hj2] at h
            omega
        · -- `i` low, `j = 2^m + c` with `c ∉ {0, i}`: the complementation law
          rw [if_neg hdeg]
          have hc0 : j - 2 ^ m ≠ 0 := fun h => hdeg (Or.inl h)
          have hic : i ≠ j - 2 ^ m := fun h => hdeg (Or.inr h.symm)
          have h := nonassocMiddles_complement_card m i (j - 2 ^ m) hil hcl hi0 hc0 hic
          rw [show 2 ^ m + (j - 2 ^ m) = j from by omega] at h
          have h2 := nonassocMiddles_succ_card m i (j - 2 ^ m) hil hcl hi0 hc0 hic
          rw [ih i (j - 2 ^ m) hil hcl hi0 hc0 hic] at h2
          omega
    · rw [if_neg hil]
      have hal : i - 2 ^ m < 2 ^ m := by omega
      by_cases hjl : j < 2 ^ m
      · rw [if_pos hjl, nonassocMiddles_card_reverse (m + 1) i j hi hj]
        by_cases hdeg : i - 2 ^ m = 0 ∨ i - 2 ^ m = j
        · -- `i = 2^m + a` with `a = 0` or `a = j`, `j` low
          rw [if_pos hdeg]
          rcases hdeg with ha0 | haj
          · have hi2 : i = 2 ^ m := by omega
            have h := nonassocMiddles_newUnit_card m j hjl hj0
            rw [← hi2] at h
            omega
          · have hi2 : i = 2 ^ m + j := by omega
            have h := nonassocMiddles_diagPair_card m j hjl hj0
            rw [← hi2] at h
            omega
        · -- `i = 2^m + a` with `a ∉ {0, j}`, `j` low
          rw [if_neg hdeg]
          have ha0 : i - 2 ^ m ≠ 0 := fun h => hdeg (Or.inl h)
          have hja : j ≠ i - 2 ^ m := fun h => hdeg (Or.inr h.symm)
          have h := nonassocMiddles_complement_card m j (i - 2 ^ m) hjl hal hj0 ha0 hja
          rw [show 2 ^ m + (i - 2 ^ m) = i from by omega] at h
          have h2 := nonassocMiddles_succ_card m j (i - 2 ^ m) hjl hal hj0 ha0 hja
          rw [ih j (i - 2 ^ m) hjl hal hj0 ha0 hja] at h2
          omega
      · rw [if_neg hjl]
        have hcl : j - 2 ^ m < 2 ^ m := by omega
        by_cases hdeg : i - 2 ^ m = 0 ∨ j - 2 ^ m = 0
        · -- both indices in the new half, one of them the new imaginary unit
          rw [if_pos hdeg]
          rcases hdeg with ha0 | hc0
          · have hi2 : i = 2 ^ m := by omega
            have hc0 : j - 2 ^ m ≠ 0 := by omega
            have h := nonassocMiddles_unitPair_card m (j - 2 ^ m) hcl hc0
            rw [show 2 ^ m + (j - 2 ^ m) = j from by omega, ← hi2] at h
            omega
          · have hj2 : j = 2 ^ m := by omega
            have ha0 : i - 2 ^ m ≠ 0 := by omega
            rw [nonassocMiddles_card_reverse (m + 1) i j hi hj]
            have h := nonassocMiddles_unitPair_card m (i - 2 ^ m) hal ha0
            rw [show 2 ^ m + (i - 2 ^ m) = i from by omega, ← hj2] at h
            omega
        · -- both indices in the new half, admissible shadow
          rw [if_neg hdeg]
          have ha0 : i - 2 ^ m ≠ 0 := fun h => hdeg (Or.inl h)
          have hc0 : j - 2 ^ m ≠ 0 := fun h => hdeg (Or.inr h)
          have hac : i - 2 ^ m ≠ j - 2 ^ m := by omega
          have h := nonassocMiddles_highhigh_card m (i - 2 ^ m) (j - 2 ^ m) hal hcl ha0 hc0 hac
          rw [show 2 ^ m + (i - 2 ^ m) = i from by omega,
            show 2 ^ m + (j - 2 ^ m) = j from by omega] at h
          have h2 := nonassocMiddles_succ_card m (i - 2 ^ m) (j - 2 ^ m) hal hcl ha0 hc0 hac
          rw [ih (i - 2 ^ m) (j - 2 ^ m) hal hcl ha0 hc0 hac] at h2
          omega

/-! ## 2. The maximality criterion -/

/-- In the quaternions every basis triple associates. -/
theorem nonassocMiddles_card_dim4 (i j : Nat) (hi : i < 4) (hj : j < 4) :
    (nonassocMiddles 2 i j).card = 0 := by
  interval_cases i <;> interval_cases j <;> decide

/-- Two distinct non-zero indices below `2^m` force `4 ≤ 2^m`. -/
theorem four_le_two_pow_of_admissible (m i j : Nat) (hi : i < 2 ^ m) (hj : j < 2 ^ m)
    (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) : 4 ≤ 2 ^ m := by
  rcases Nat.lt_or_ge m 2 with h | h
  · exfalso
    interval_cases m <;> simp only [pow_zero, pow_one] at hi hj <;> omega
  · calc (4 : Nat) = 2 ^ 2 := by norm_num
      _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) h

/-- Adding a multiple of `2^m` does not change a residue modulo `2^k` for `k ≤ m`. -/
theorem two_pow_add_mod (m k a : Nat) (hkm : k ≤ m) : (2 ^ m + a) % 2 ^ k = a % 2 ^ k := by
  have hsplit : (2 : Nat) ^ m = 2 ^ k * 2 ^ (m - k) := by
    rw [← pow_add]
    congr 1
    omega
  rw [hsplit, Nat.add_comm, Nat.add_mul_mod_self_left]

/-- A higher power of two vanishes modulo a lower one. -/
theorem two_pow_mod_two_pow (m k : Nat) (hkm : k ≤ m) : (2 : Nat) ^ m % 2 ^ k = 0 := by
  rw [show (2 : Nat) ^ m = 2 ^ k * 2 ^ (m - k) by rw [← pow_add]; congr 1; omega]
  exact Nat.mul_mod_right _ _

/-- **Maximality for cross-half pairs.**  A pair `(e_i, e_{2^m + c})` with `i` in the old half
has maximal degree exactly when it is degenerate (`c = 0`, the new imaginary unit, or `c = i`,
a diagonal pair) or the level is so small that the old half is associative. -/
theorem cross_max_iff (m i c : Nat) (hi : i < 2 ^ m) (hc : c < 2 ^ m) (hi0 : i ≠ 0) :
    (nonassocMiddles (m + 1) i (2 ^ m + c)).card = 2 ^ (m + 1) - 4
      ↔ (m ≤ 2 ∨ c = 0 ∨ c = i) := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  by_cases hc0 : c = 0
  · subst hc0
    have h := nonassocMiddles_newUnit_card m i hi hi0
    simp only [Nat.add_zero]
    exact ⟨fun _ => by simp, fun _ => by omega⟩
  · by_cases hci : c = i
    · subst hci
      have h := nonassocMiddles_diagPair_card m c hc (by simpa using hi0)
      exact ⟨fun _ => Or.inr (Or.inr rfl), fun _ => by omega⟩
    · have hic : i ≠ c := fun h => hci h.symm
      have hm2 : 4 ≤ 2 ^ m := four_le_two_pow_of_admissible m i c hi hc hi0 hc0 hic
      have h := nonassocMiddles_complement_card m i c hi hc hi0 hc0 hic
      have h2 := nonassocMiddles_succ_card m i c hi hc hi0 hc0 hic
      rcases Nat.lt_or_ge m 3 with hm | hm
      · have hm2' : m = 2 := by
          rcases Nat.lt_or_ge m 2 with h' | h'
          · exfalso; interval_cases m <;> simp only [pow_zero, pow_one] at hi hc <;> omega
          · omega
        subst hm2'
        have h0 := nonassocMiddles_card_dim4 i c (by simpa using hi) (by simpa using hc)
        have e1 : (2 : Nat) ^ (2 + 1) = 8 := by norm_num
        exact ⟨fun _ => Or.inl (by norm_num), fun _ => by omega⟩
      · have hge := nonassocMiddles_card_ge_four m i c hm hi hc hi0 hc0 hic
        exact ⟨fun _ => by omega, fun h' => by omega⟩

/-- The degree of a low pair doubles, so maximality is inherited from the shadow. -/
theorem max_low_iff (m i j : Nat) (hi : i < 2 ^ m) (hj : j < 2 ^ m) (hi0 : i ≠ 0)
    (hj0 : j ≠ 0) (hij : i ≠ j) :
    (nonassocMiddles (m + 1) i j).card = 2 ^ (m + 1) - 4
      ↔ (nonassocMiddles m i j).card = 2 ^ m - 4 := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hm2 := four_le_two_pow_of_admissible m i j hi hj hi0 hj0 hij
  have h := nonassocMiddles_succ_card m i j hi hj hi0 hj0 hij
  omega

/-- A pair inside the new half is maximal exactly when its shadow is. -/
theorem max_high_iff (m a c : Nat) (ha : a < 2 ^ m) (hc : c < 2 ^ m) (ha0 : a ≠ 0)
    (hc0 : c ≠ 0) (hac : a ≠ c) :
    (nonassocMiddles (m + 1) (2 ^ m + a) (2 ^ m + c)).card = 2 ^ (m + 1) - 4
      ↔ (nonassocMiddles m a c).card = 2 ^ m - 4 := by
  rw [nonassocMiddles_highhigh_card m a c ha hc ha0 hc0 hac]
  exact max_low_iff m a c ha hc ha0 hc0 hac

/-- Flexibility on basis vectors: a repeated outer index has no non-associating middle. -/
theorem nonassocMiddles_self_card (n i : Nat) (hi : i < 2 ^ n) :
    (nonassocMiddles n i i).card = 0 := by
  rw [Finset.card_eq_zero, nonassocMiddles, Finset.filter_eq_empty_iff]
  intro k hk
  simp [assocNeg_self n i k hi (Finset.mem_range.mp hk)]

/-- **Maximal degree criterion.**  Let `k` be the position of the leading bit of `i ⊕ j`.
The pair `(i, j)` attains the maximal degree `2ⁿ - 4` exactly when `k ≤ 2`, or one of the
two indices has no bits below position `k`, or `i ⊕ j` is the single bit `2^k`. -/
theorem nonassocMiddles_card_max_iff (n i j k : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n)
    (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j)
    (hk : 2 ^ k ≤ i ^^^ j) (hk' : i ^^^ j < 2 ^ (k + 1)) :
    (nonassocMiddles n i j).card = 2 ^ n - 4
      ↔ (k ≤ 2 ∨ i % 2 ^ k = 0 ∨ j % 2 ^ k = 0 ∨ i ^^^ j = 2 ^ k) := by
  induction n generalizing i j with
  | zero => simp only [pow_zero] at hi; omega
  | succ m ih =>
    have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
    by_cases hil : i < 2 ^ m
    · by_cases hjl : j < 2 ^ m
      · -- both indices in the old half: the degree doubles, so maximality is inherited
        have hm2 : 4 ≤ 2 ^ m := four_le_two_pow_of_admissible m i j hil hjl hi0 hj0 hij
        have hcard := nonassocMiddles_succ_card m i j hil hjl hi0 hj0 hij
        rw [hcard, ← ih i j hil hjl hi0 hj0 hij hk hk']
        omega
      · -- `i` in the old half, `j` in the new one: the leading bit of `i ⊕ j` is `m`
        obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
        have hcl : c < 2 ^ m := by omega
        have hxor : i ^^^ (2 ^ m + c) = 2 ^ m + (i ^^^ c) := by
          rw [Nat.xor_comm i, xor_high_low hcl hil, Nat.xor_comm c i]
        have hlt : i ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hil hcl
        have hkm : k = m := by
          by_contra hne
          rcases Nat.lt_or_ge k m with h | h
          · have : (2 : Nat) ^ (k + 1) ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) (by omega)
            omega
          · have : (2 : Nat) ^ (m + 1) ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) (by omega)
            omega
        rw [hkm]
        have hmodi : i % 2 ^ m = i := Nat.mod_eq_of_lt hil
        have hmodj : (2 ^ m + c) % 2 ^ m = c := by
          rw [Nat.add_mod_left]; exact Nat.mod_eq_of_lt hcl
        have hxc : (2 ^ m + (i ^^^ c) = 2 ^ m) ↔ i = c := by
          constructor
          · intro h
            exact Nat.xor_eq_zero_iff.mp (by omega)
          · rintro rfl; simp
        rw [cross_max_iff m i c hil hcl hi0, hmodi, hmodj, hxor, hxc]
        omega
    · obtain ⟨a, rfl⟩ : ∃ a, i = 2 ^ m + a := ⟨i - 2 ^ m, by omega⟩
      have hal : a < 2 ^ m := by omega
      by_cases hjl : j < 2 ^ m
      · -- `j` in the old half, `i` in the new one: symmetric to the previous case
        have hxor : (2 ^ m + a) ^^^ j = 2 ^ m + (a ^^^ j) := xor_high_low hal hjl
        have hlt : a ^^^ j < 2 ^ m := Nat.xor_lt_two_pow hal hjl
        have hkm : k = m := by
          by_contra hne
          rcases Nat.lt_or_ge k m with h | h
          · have : (2 : Nat) ^ (k + 1) ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) (by omega)
            omega
          · have : (2 : Nat) ^ (m + 1) ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) (by omega)
            omega
        rw [hkm]
        have hmodj : j % 2 ^ m = j := Nat.mod_eq_of_lt hjl
        have hmodi : (2 ^ m + a) % 2 ^ m = a := by
          rw [Nat.add_mod_left]; exact Nat.mod_eq_of_lt hal
        have hxa : (2 ^ m + (a ^^^ j) = 2 ^ m) ↔ a = j := by
          constructor
          · intro h
            exact Nat.xor_eq_zero_iff.mp (by omega)
          · rintro rfl; simp
        rw [nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) j hi hj,
          cross_max_iff m j a hjl hal hj0, hmodi, hmodj, hxor, hxa]
        omega
      · -- both indices in the new half: the degree equals that of the shadow pair
        obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
        have hcl : c < 2 ^ m := by omega
        have hxor : (2 ^ m + a) ^^^ (2 ^ m + c) = a ^^^ c := xor_high_high hal hcl
        have hac : a ≠ c := by omega
        have hne0 : a ^^^ c ≠ 0 := fun h => hac (Nat.xor_eq_zero_iff.mp h)
        have hltm : a ^^^ c < 2 ^ m := Nat.xor_lt_two_pow hal hcl
        have hkm : k < m := by
          by_contra hne
          have : (2 : Nat) ^ m ≤ 2 ^ k := Nat.pow_le_pow_right (by norm_num) (by omega)
          omega
        have hmodi : (2 ^ m + a) % 2 ^ k = a % 2 ^ k := two_pow_add_mod m k a (by omega)
        have hmodj : (2 ^ m + c) % 2 ^ k = c % 2 ^ k := two_pow_add_mod m k c (by omega)
        by_cases ha0 : a = 0
        · -- the first index is the new imaginary unit: maximal
          subst ha0
          have hc0 : c ≠ 0 := by omega
          have h := nonassocMiddles_unitPair_card m c hcl hc0
          have hmod0 : (2 ^ m + 0) % 2 ^ k = 0 := by
            simp only [Nat.add_zero]
            exact two_pow_mod_two_pow m k (by omega)
          simp only [Nat.add_zero] at h ⊢
          exact ⟨fun _ => Or.inr (Or.inl (by simpa using hmod0)), fun _ => by omega⟩
        · by_cases hc0 : c = 0
          · subst hc0
            have h := nonassocMiddles_unitPair_card m a hal ha0
            have hmod0 : (2 : Nat) ^ m % 2 ^ k = 0 := two_pow_mod_two_pow m k (by omega)
            rw [nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) (2 ^ m + 0) hi hj]
            simp only [Nat.add_zero] at h ⊢
            exact ⟨fun _ => Or.inr (Or.inr (Or.inl hmod0)), fun _ => by omega⟩
          · have hm2 : 4 ≤ 2 ^ m := four_le_two_pow_of_admissible m a c hal hcl ha0 hc0 hac
            have hhh := nonassocMiddles_highhigh_card m a c hal hcl ha0 hc0 hac
            have hsucc := nonassocMiddles_succ_card m a c hal hcl ha0 hc0 hac
            have hIH := ih a c hal hcl ha0 hc0 hac (by omega) (by omega)
            rw [hhh, hsucc, hmodi, hmodj, hxor, ← hIH]
            omega

/-! ## 3. The minimal degree -/

/-- **Minimality for cross-half pairs.**  From level `3` on, a cross-half pair has the
minimal degree `4` exactly when it is non-degenerate and its shadow pair is maximal. -/
theorem cross_min_iff (m i c : Nat) (hm : 3 ≤ m) (hi : i < 2 ^ m) (hc : c < 2 ^ m)
    (hi0 : i ≠ 0) :
    (nonassocMiddles (m + 1) i (2 ^ m + c)).card = 4
      ↔ (c ≠ 0 ∧ c ≠ i ∧ (nonassocMiddles m i c).card = 2 ^ m - 4) := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hm8 : 8 ≤ 2 ^ m := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
      _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
  by_cases hc0 : c = 0
  · subst hc0
    have h := nonassocMiddles_newUnit_card m i hi hi0
    simp only [Nat.add_zero]
    exact ⟨fun _ => by omega, fun h' => absurd rfl h'.1⟩
  · by_cases hci : c = i
    · subst hci
      have h := nonassocMiddles_diagPair_card m c hc hc0
      exact ⟨fun _ => by omega, fun h' => absurd rfl h'.2.1⟩
    · have hic : i ≠ c := fun h => hci h.symm
      have h := nonassocMiddles_complement_card m i c hi hc hi0 hc0 hic
      have h2 := nonassocMiddles_succ_card m i c hi hc hi0 hc0 hic
      have hle := nonassoc_middles_card_le m i c hi hc hi0 hc0 hic
      exact ⟨fun _ => ⟨hc0, hci, by omega⟩, fun h' => by have := h'.2.2; omega⟩

/-- **Minimal degree criterion.**  From dimension `32` on, the minimal degree `4` is attained
exactly by the cross-half pairs whose two half-indices form a maximal pair one level down. -/
theorem nonassocMiddles_card_min_iff (m i j : Nat) (hm : 3 ≤ m) (hi : i < 2 ^ (m + 1))
    (hj : j < 2 ^ (m + 1)) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    (nonassocMiddles (m + 1) i j).card = 4
      ↔ ∃ a c, a < 2 ^ m ∧ c < 2 ^ m ∧ a ≠ 0 ∧ c ≠ 0 ∧ c ≠ a ∧
          ((i = a ∧ j = 2 ^ m + c) ∨ (i = 2 ^ m + c ∧ j = a)) ∧
          (nonassocMiddles m a c).card = 2 ^ m - 4 := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hm8 : 8 ≤ 2 ^ m := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
      _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
  by_cases hil : i < 2 ^ m
  · by_cases hjl : j < 2 ^ m
    · -- both indices in the old half: the degree is at least `12`
      have hge := nonassocMiddles_card_ge_four m i j hm hil hjl hi0 hj0 hij
      have h := nonassocMiddles_succ_card m i j hil hjl hi0 hj0 hij
      constructor
      · intro hcard; exfalso; omega
      · rintro ⟨a, c, ha, hc, ha0, hc0, hca, (⟨rfl, rfl⟩ | ⟨rfl, rfl⟩), hmax⟩ <;> omega
    · obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
      have hcl : c < 2 ^ m := by omega
      rw [cross_min_iff m i c hm hil hcl hi0]
      constructor
      · rintro ⟨hc0, hci, hmax⟩
        exact ⟨i, c, hil, hcl, hi0, hc0, hci, Or.inl ⟨rfl, rfl⟩, hmax⟩
      · rintro ⟨a, c', ha, hc', ha0, hc0, hca, (⟨rfl, hj'⟩ | ⟨hi', rfl⟩), hmax⟩
        · have : c = c' := by omega
          subst this
          exact ⟨hc0, hca, hmax⟩
        · omega
  · obtain ⟨a, rfl⟩ : ∃ a, i = 2 ^ m + a := ⟨i - 2 ^ m, by omega⟩
    have hal : a < 2 ^ m := by omega
    by_cases hjl : j < 2 ^ m
    · rw [nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) j hi hj,
        cross_min_iff m j a hm hjl hal hj0]
      constructor
      · rintro ⟨ha0, haj, hmax⟩
        exact ⟨j, a, hjl, hal, hj0, ha0, haj, Or.inr ⟨rfl, rfl⟩, hmax⟩
      · rintro ⟨b, c', hb, hc', hb0, hc0, hcb, (⟨hi', rfl⟩ | ⟨hi', rfl⟩), hmax⟩
        · omega
        · have : a = c' := by omega
          subst this
          exact ⟨hc0, hcb, hmax⟩
    · -- both indices in the new half
      obtain ⟨c, rfl⟩ : ∃ c, j = 2 ^ m + c := ⟨j - 2 ^ m, by omega⟩
      have hcl : c < 2 ^ m := by omega
      have hac : a ≠ c := by omega
      constructor
      · intro hcard
        exfalso
        by_cases ha0 : a = 0
        · subst ha0
          have hc0 : c ≠ 0 := by omega
          have h := nonassocMiddles_unitPair_card m c hcl hc0
          simp only [Nat.add_zero] at hcard h
          omega
        · by_cases hc0 : c = 0
          · subst hc0
            have h := nonassocMiddles_unitPair_card m a hal ha0
            rw [nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) (2 ^ m + 0) hi hj] at hcard
            simp only [Nat.add_zero] at hcard h
            omega
          · have hge := nonassocMiddles_card_ge_four m a c hm hal hcl ha0 hc0 hac
            have hhh := nonassocMiddles_highhigh_card m a c hal hcl ha0 hc0 hac
            have h := nonassocMiddles_succ_card m a c hal hcl ha0 hc0 hac
            omega
      · rintro ⟨b, c', hb, hc', hb0, hc0, hcb, (⟨hi', hj'⟩ | ⟨hi', hj'⟩), hmax⟩ <;> omega

/-! ## 4. Counting the extremal pairs -/

/-- The indicator of an ordered admissible pair of maximal degree. -/
def maxIndicator (n i j : Nat) : Nat :=
  if i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧ (nonassocMiddles n i j).card = 2 ^ n - 4 then 1 else 0

/-- The ordered admissible pairs of maximal degree in dimension `2ⁿ`. -/
def maxDegreePairs (n : Nat) : Finset (Nat × Nat) :=
  ((range (2 ^ n)) ×ˢ (range (2 ^ n))).filter
    (fun p => p.1 ≠ 0 ∧ p.2 ≠ 0 ∧ p.1 ≠ p.2 ∧ (nonassocMiddles n p.1 p.2).card = 2 ^ n - 4)

theorem indicator_congr {P Q : Prop} [Decidable P] [Decidable Q] (h : P ↔ Q) :
    (if P then 1 else 0) = (if Q then (1 : Nat) else 0) := by
  by_cases hq : Q
  · rw [if_pos (h.mpr hq), if_pos hq]
  · rw [if_neg (fun hp => hq (h.mp hp)), if_neg hq]

theorem maxDegreePairs_card_eq_sum (n : Nat) :
    (maxDegreePairs n).card
      = ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), maxIndicator n i j := by
  classical
  rw [maxDegreePairs, Finset.card_filter, Finset.sum_product]
  rfl

/-- The maximality indicator is symmetric. -/
theorem maxIndicator_comm (n i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    maxIndicator n i j = maxIndicator n j i := by
  unfold maxIndicator
  rw [nonassocMiddles_card_reverse n i j hi hj]
  refine indicator_congr ?_
  constructor
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h2, h1, Ne.symm h3, h4⟩
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h2, h1, Ne.symm h3, h4⟩

theorem sum_range_ite_zero (h k : Nat) :
    ∑ i ∈ range h, (if i = 0 then 0 else k) = k * (h - 1) := by
  induction h with
  | zero => simp
  | succ p ih =>
    rw [Finset.sum_range_succ, ih]
    rcases Nat.eq_zero_or_pos p with rfl | hp
    · simp
    · obtain ⟨q, rfl⟩ : ∃ q, p = q + 1 := ⟨p - 1, by omega⟩
      simp only [Nat.add_sub_cancel, if_neg (by omega : ¬ q + 1 = 0)]
      ring

theorem sum_range_ite_eq_zero (h k : Nat) (hh : 0 < h) :
    ∑ i ∈ range h, (if i = 0 then k else 0) = k := by
  induction h with
  | zero => omega
  | succ p ih =>
    rw [Finset.sum_range_succ]
    rcases Nat.eq_zero_or_pos p with rfl | hp
    · simp
    · rw [ih hp, if_neg (by omega), Nat.add_zero]

/-! ### The four blocks of a doubling step -/

theorem block_low_low (m : Nat) :
    ∑ i ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), maxIndicator (m + 1) i j
      = (maxDegreePairs m).card := by
  rw [maxDegreePairs_card_eq_sum]
  refine Finset.sum_congr rfl (fun i hi => Finset.sum_congr rfl (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold maxIndicator
  refine indicator_congr ?_
  constructor
  · rintro ⟨h1, h2, h3, h⟩
    exact ⟨h1, h2, h3, (max_low_iff m i j hi' hj' h1 h2 h3).mp h⟩
  · rintro ⟨h1, h2, h3, h⟩
    exact ⟨h1, h2, h3, (max_low_iff m i j hi' hj' h1 h2 h3).mpr h⟩

theorem block_low_high (m : Nat) (hm : 3 ≤ m) :
    ∑ i ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), maxIndicator (m + 1) i (2 ^ m + c)
      = 2 * (2 ^ m - 1) := by
  have hpos : 0 < (2 : Nat) ^ m := Nat.two_pow_pos m
  have key : ∀ i ∈ range (2 ^ m),
      ∑ c ∈ range (2 ^ m), maxIndicator (m + 1) i (2 ^ m + c)
        = if i = 0 then 0 else 2 := by
    intro i hi
    have hi' := Finset.mem_range.mp hi
    by_cases h1 : i = 0
    · rw [if_pos h1]
      refine Finset.sum_eq_zero (fun c _ => ?_)
      unfold maxIndicator
      rw [if_neg (by rintro ⟨h, -⟩; exact h h1)]
    · rw [if_neg h1]
      have hpt : ∀ c ∈ range (2 ^ m), maxIndicator (m + 1) i (2 ^ m + c)
          = if c = 0 ∨ c = i then 1 else 0 := by
        intro c hc
        have hc' := Finset.mem_range.mp hc
        unfold maxIndicator
        refine indicator_congr ?_
        constructor
        · rintro ⟨-, -, -, h⟩
          rcases (cross_max_iff m i c hi' hc' h1).mp h with h' | h' | h'
          · omega
          · exact Or.inl h'
          · exact Or.inr h'
        · intro h
          exact ⟨h1, by omega, by omega, (cross_max_iff m i c hi' hc' h1).mpr (Or.inr h)⟩
      rw [Finset.sum_congr rfl hpt, ← Finset.card_filter]
      have hset : (range (2 ^ m)).filter (fun c => c = 0 ∨ c = i) = {0, i} := by
        ext c
        simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_insert,
          Finset.mem_singleton]
        constructor
        · rintro ⟨-, h⟩; exact h
        · rintro (rfl | rfl) <;> exact ⟨by omega, by simp⟩
      rw [hset, Finset.card_pair (Ne.symm h1)]
  rw [Finset.sum_congr rfl key, sum_range_ite_zero]

theorem block_high_low (m : Nat) (hm : 3 ≤ m) :
    ∑ a ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), maxIndicator (m + 1) (2 ^ m + a) j
      = 2 * (2 ^ m - 1) := by
  rw [Finset.sum_comm, ← block_low_high m hm]
  refine Finset.sum_congr rfl (fun j hj => Finset.sum_congr rfl (fun a ha => ?_))
  have ha' := Finset.mem_range.mp ha
  have hj' := Finset.mem_range.mp hj
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  exact maxIndicator_comm (m + 1) (2 ^ m + a) j (by omega) (by omega)

theorem block_high_high (m : Nat) :
    ∑ a ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), maxIndicator (m + 1) (2 ^ m + a) (2 ^ m + c)
      = (maxDegreePairs m).card + 2 * (2 ^ m - 1) := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hpos : 0 < (2 : Nat) ^ m := Nat.two_pow_pos m
  have hpt : ∀ a ∈ range (2 ^ m), ∀ c ∈ range (2 ^ m),
      maxIndicator (m + 1) (2 ^ m + a) (2 ^ m + c)
        = maxIndicator m a c + (if a = 0 then (if c = 0 then 0 else 1) else 0)
          + (if c = 0 then (if a = 0 then 0 else 1) else 0) := by
    intro a ha c hc
    have ha' := Finset.mem_range.mp ha
    have hc' := Finset.mem_range.mp hc
    unfold maxIndicator
    by_cases hac : a = c
    · subst hac
      rw [if_neg (by rintro ⟨-, -, h, -⟩; exact h rfl),
        if_neg (by rintro ⟨-, -, h, -⟩; exact h rfl)]
      by_cases h : a = 0 <;> simp [h]
    · by_cases ha0 : a = 0
      · subst ha0
        have hc0 : c ≠ 0 := fun h => hac h.symm
        have h := nonassocMiddles_unitPair_card m c hc' hc0
        rw [Nat.add_zero] at h ⊢
        rw [if_pos ⟨by omega, by omega, by omega, by omega⟩,
          if_neg (by rintro ⟨h', -⟩; exact h' rfl),
          if_pos rfl, if_neg hc0, if_neg hc0]
      · by_cases hc0 : c = 0
        · subst hc0
          have h := nonassocMiddles_unitPair_card m a ha' ha0
          have hrev := nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) (2 ^ m)
            (by omega) (by omega)
          rw [Nat.add_zero]
          rw [if_pos ⟨by omega, by omega, by omega, by omega⟩,
            if_neg (by rintro ⟨-, h', -⟩; exact h' rfl),
            if_neg ha0, if_pos rfl, if_neg ha0]
        · have hiff := max_high_iff m a c ha' hc' ha0 hc0 hac
          rw [if_neg ha0, if_neg hc0, Nat.add_zero, Nat.add_zero]
          refine indicator_congr ?_
          constructor
          · rintro ⟨-, -, -, h⟩
            exact ⟨ha0, hc0, hac, hiff.mp h⟩
          · rintro ⟨-, -, -, h⟩
            exact ⟨by omega, by omega, by omega, hiff.mpr h⟩
  rw [Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (hpt a ha))]
  have hsplit : ∀ a ∈ range (2 ^ m),
      ∑ c ∈ range (2 ^ m), (maxIndicator m a c + (if a = 0 then (if c = 0 then 0 else 1) else 0)
          + (if c = 0 then (if a = 0 then 0 else 1) else 0))
        = (∑ c ∈ range (2 ^ m), maxIndicator m a c)
          + (if a = 0 then 2 ^ m - 1 else 0) + (if a = 0 then 0 else 1) := by
    intro a _
    rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
    have hA : ∑ c ∈ range (2 ^ m), (if a = 0 then (if c = 0 then 0 else 1) else 0)
        = (if a = 0 then 2 ^ m - 1 else 0) := by
      by_cases h : a = 0
      · subst h
        simpa using sum_range_ite_zero (2 ^ m) 1
      · simp only [if_neg h, Finset.sum_const_zero]
    have hB : ∑ c ∈ range (2 ^ m), (if c = 0 then (if a = 0 then 0 else 1) else 0)
        = (if a = 0 then 0 else 1) := by
      by_cases h : a = 0
      · subst h
        simp
      · simp only [if_neg h]
        exact sum_range_ite_eq_zero (2 ^ m) 1 hpos
    rw [hA, hB]
  rw [Finset.sum_congr rfl hsplit, Finset.sum_add_distrib, Finset.sum_add_distrib,
    ← maxDegreePairs_card_eq_sum m,
    sum_range_ite_eq_zero (2 ^ m) (2 ^ m - 1) hpos]
  have h2 : ∑ a ∈ range (2 ^ m), (if a = 0 then 0 else 1) = 2 ^ m - 1 := by
    simpa using sum_range_ite_zero (2 ^ m) 1
  rw [h2]
  omega

/-- **The doubling law for the number of maximal-degree pairs.** -/
theorem maxDegreePairs_card_succ (m : Nat) (hm : 3 ≤ m) :
    (maxDegreePairs (m + 1)).card = 2 * (maxDegreePairs m).card + 6 * (2 ^ m - 1) := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  rw [maxDegreePairs_card_eq_sum (m + 1), hpow, Finset.sum_range_add]
  have hinner : ∀ x : Nat, ∑ j ∈ range (2 ^ m + 2 ^ m), maxIndicator (m + 1) x j
      = (∑ j ∈ range (2 ^ m), maxIndicator (m + 1) x j)
        + ∑ c ∈ range (2 ^ m), maxIndicator (m + 1) x (2 ^ m + c) :=
    fun x => Finset.sum_range_add (fun j => maxIndicator (m + 1) x j) (2 ^ m) (2 ^ m)
  rw [Finset.sum_congr rfl (fun i _ => hinner i),
    Finset.sum_congr rfl (fun a _ => hinner (2 ^ m + a)),
    Finset.sum_add_distrib, Finset.sum_add_distrib,
    block_low_low m, block_low_high m hm, block_high_low m hm, block_high_high m]
  omega

/-- **The number of maximal-degree pairs.** -/
theorem maxDegreePairs_card (n : Nat) (hn : 3 ≤ n) :
    (maxDegreePairs n).card = 3 * 2 ^ (n - 1) * (2 * n - 3) + 6 := by
  induction n, hn using Nat.le_induction with
  | base => decide
  | succ m hm ih =>
    have h1 : (2 : Nat) ^ m = 2 * 2 ^ (m - 1) := by
      obtain ⟨q, rfl⟩ : ∃ q, m = q + 1 := ⟨m - 1, by omega⟩
      rw [Nat.add_sub_cancel, pow_succ]
      ring
    have h2 : (1 : Nat) ≤ 2 ^ (m - 1) := Nat.one_le_two_pow
    have h3 : 2 * (m + 1) - 3 = (2 * m - 3) + 2 := by omega
    rw [maxDegreePairs_card_succ m hm, ih, Nat.add_sub_cancel, h1, h3]
    ring_nf
    omega

/-- The ordered admissible pairs of minimal degree in dimension `2ⁿ`. -/
def minDegreePairs (n : Nat) : Finset (Nat × Nat) :=
  ((range (2 ^ n)) ×ˢ (range (2 ^ n))).filter
    (fun p => p.1 ≠ 0 ∧ p.2 ≠ 0 ∧ p.1 ≠ p.2 ∧ (nonassocMiddles n p.1 p.2).card = 4)

/-- The indicator of an ordered admissible pair of minimal degree. -/
def minIndicator (n i j : Nat) : Nat :=
  if i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧ (nonassocMiddles n i j).card = 4 then 1 else 0

theorem minDegreePairs_card_eq_sum (n : Nat) :
    (minDegreePairs n).card
      = ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), minIndicator n i j := by
  classical
  rw [minDegreePairs, Finset.card_filter, Finset.sum_product]
  rfl

theorem minIndicator_comm (n i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    minIndicator n i j = minIndicator n j i := by
  unfold minIndicator
  rw [nonassocMiddles_card_reverse n i j hi hj]
  refine indicator_congr ?_
  constructor
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h2, h1, Ne.symm h3, h4⟩
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h2, h1, Ne.symm h3, h4⟩

theorem min_block_low_low (m : Nat) (hm : 3 ≤ m) :
    ∑ i ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), minIndicator (m + 1) i j = 0 := by
  refine Finset.sum_eq_zero (fun i hi => Finset.sum_eq_zero (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold minIndicator
  rw [if_neg]
  rintro ⟨h1, h2, h3, h4⟩
  have hge := nonassocMiddles_card_ge_four m i j hm hi' hj' h1 h2 h3
  have h := nonassocMiddles_succ_card m i j hi' hj' h1 h2 h3
  omega

theorem min_block_high_high (m : Nat) (hm : 3 ≤ m) :
    ∑ a ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
        minIndicator (m + 1) (2 ^ m + a) (2 ^ m + c) = 0 := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hm8 : 8 ≤ 2 ^ m := by
    calc (8 : Nat) = 2 ^ 3 := by norm_num
      _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm
  refine Finset.sum_eq_zero (fun a ha => Finset.sum_eq_zero (fun c hc => ?_))
  have ha' := Finset.mem_range.mp ha
  have hc' := Finset.mem_range.mp hc
  unfold minIndicator
  rw [if_neg]
  rintro ⟨-, -, h3, h4⟩
  have hac : a ≠ c := by omega
  by_cases ha0 : a = 0
  · subst ha0
    have hc0 : c ≠ 0 := fun h => hac h.symm
    have h := nonassocMiddles_unitPair_card m c hc' hc0
    simp only [Nat.add_zero] at h4
    omega
  · by_cases hc0 : c = 0
    · subst hc0
      have h := nonassocMiddles_unitPair_card m a ha' ha0
      have hrev := nonassocMiddles_card_reverse (m + 1) (2 ^ m + a) (2 ^ m)
        (by omega) (by omega)
      simp only [Nat.add_zero] at h4
      omega
    · have hge := nonassocMiddles_card_ge_four m a c hm ha' hc' ha0 hc0 hac
      have hhh := nonassocMiddles_highhigh_card m a c ha' hc' ha0 hc0 hac
      have h := nonassocMiddles_succ_card m a c ha' hc' ha0 hc0 hac
      omega

theorem min_block_low_high (m : Nat) (hm : 3 ≤ m) :
    ∑ i ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), minIndicator (m + 1) i (2 ^ m + c)
      = (maxDegreePairs m).card := by
  have hpos : 0 < (2 : Nat) ^ m := Nat.two_pow_pos m
  rw [maxDegreePairs_card_eq_sum]
  refine Finset.sum_congr rfl (fun i hi => Finset.sum_congr rfl (fun c hc => ?_))
  have hi' := Finset.mem_range.mp hi
  have hc' := Finset.mem_range.mp hc
  unfold minIndicator maxIndicator
  refine indicator_congr ?_
  by_cases h1 : i = 0
  · subst h1
    constructor
    · rintro ⟨h, -⟩; exact absurd rfl h
    · rintro ⟨h, -⟩; exact absurd rfl h
  · rw [cross_min_iff m i c hm hi' hc' h1]
    constructor
    · rintro ⟨-, -, -, hc0, hci, hmax⟩
      exact ⟨h1, hc0, fun h => hci h.symm, hmax⟩
    · rintro ⟨-, hc0, hic, hmax⟩
      exact ⟨h1, by omega, by omega, hc0, fun h => hic h.symm, hmax⟩

theorem min_block_high_low (m : Nat) (hm : 3 ≤ m) :
    ∑ a ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), minIndicator (m + 1) (2 ^ m + a) j
      = (maxDegreePairs m).card := by
  rw [Finset.sum_comm, ← min_block_low_high m hm]
  refine Finset.sum_congr rfl (fun j hj => Finset.sum_congr rfl (fun a ha => ?_))
  have ha' := Finset.mem_range.mp ha
  have hj' := Finset.mem_range.mp hj
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  exact minIndicator_comm (m + 1) (2 ^ m + a) j (by omega) (by omega)

/-- **The doubling law for the number of minimal-degree pairs**: the pairs of minimal degree
in dimension `2^(m+1)` are exactly the cross-half liftings of the maximal-degree pairs one
level down, in either order. -/
theorem minDegreePairs_card_succ (m : Nat) (hm : 3 ≤ m) :
    (minDegreePairs (m + 1)).card = 2 * (maxDegreePairs m).card := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  rw [minDegreePairs_card_eq_sum (m + 1), hpow, Finset.sum_range_add]
  have hinner : ∀ x : Nat, ∑ j ∈ range (2 ^ m + 2 ^ m), minIndicator (m + 1) x j
      = (∑ j ∈ range (2 ^ m), minIndicator (m + 1) x j)
        + ∑ c ∈ range (2 ^ m), minIndicator (m + 1) x (2 ^ m + c) :=
    fun x => Finset.sum_range_add (fun j => minIndicator (m + 1) x j) (2 ^ m) (2 ^ m)
  rw [Finset.sum_congr rfl (fun i _ => hinner i),
    Finset.sum_congr rfl (fun a _ => hinner (2 ^ m + a)),
    Finset.sum_add_distrib, Finset.sum_add_distrib,
    min_block_low_low m hm, min_block_low_high m hm, min_block_high_low m hm,
    min_block_high_high m hm]
  omega

/-- **The number of minimal-degree pairs.** -/
theorem minDegreePairs_card (n : Nat) (hn : 4 ≤ n) :
    (minDegreePairs n).card = 2 * (3 * 2 ^ (n - 2) * (2 * n - 5) + 6) := by
  obtain ⟨m, rfl⟩ : ∃ m, n = m + 1 := ⟨n - 1, by omega⟩
  have hm : 3 ≤ m := by omega
  rw [minDegreePairs_card_succ m hm, maxDegreePairs_card m hm]
  have h1 : m + 1 - 2 = m - 1 := by omega
  have h2 : 2 * (m + 1) - 5 = 2 * m - 3 := by omega
  rw [h1, h2]

/-! ## 5. Sample values -/

/-- In dimension `16` the degrees are `12` (inside a half or across the diagonal) and `4`. -/
example : towerDegree 4 1 2 = 12 := by decide

example : towerDegree 4 1 10 = 4 := by decide

/-- In dimension `32` all four possible degrees `4, 12, 20, 28` occur. -/
example : towerDegree 5 1 18 = 4 ∧ towerDegree 5 1 10 = 12 ∧ towerDegree 5 1 26 = 20
    ∧ towerDegree 5 1 2 = 28 := by decide

/-- The count of maximal-degree pairs in dimension `16`. -/
theorem maxDegreePairs_card_dim16 : (maxDegreePairs 4).card = 126 := by
  rw [maxDegreePairs_card 4 (by norm_num)]
  norm_num

/-- The count of maximal-degree pairs in dimension `32`. -/
theorem maxDegreePairs_card_dim32 : (maxDegreePairs 5).card = 342 := by
  rw [maxDegreePairs_card 5 (by norm_num)]
  norm_num

/-- The count of minimal-degree pairs in dimension `16`. -/
theorem minDegreePairs_card_dim16 : (minDegreePairs 4).card = 84 := by
  rw [minDegreePairs_card 4 (by norm_num)]
  norm_num

/-- The count of minimal-degree pairs in dimension `32`. -/
theorem minDegreePairs_card_dim32 : (minDegreePairs 5).card = 252 := by
  rw [minDegreePairs_card 5 (by norm_num)]
  norm_num

end Sovereign
