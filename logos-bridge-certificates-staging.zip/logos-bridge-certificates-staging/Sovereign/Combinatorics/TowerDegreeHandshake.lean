import Sovereign.Combinatorics.TowerDegreeCensusLevels

namespace Sovereign

open Finset

/-! ## 1. The total number of non-associating middles -/

/-- The total number of non-associating middles of the tower `Tower n`, summed over all
ordered admissible index pairs.  Twice this number is the number of edge endpoints of the
annihilation graph of dimension `2ⁿ⁺¹` inside its charge sectors. -/
def totalNonassocMiddles (n : Nat) : Nat :=
  ∑ p ∈ admissiblePairs n, (nonassocMiddles n p.1 p.2).card

theorem nonassocMiddles_card_eq_zero_of_degenerate (n i j : Nat) (hi : i < 2 ^ n)
    (h : i = 0 ∨ j = 0 ∨ i = j) : (nonassocMiddles n i j).card = 0 := by
  rw [Finset.card_eq_zero, nonassocMiddles, Finset.filter_eq_empty_iff]
  intro k hk
  rcases h with rfl | rfl | rfl
  · simp [assocNeg_zero_left]
  · simp [assocNeg_zero_right]
  · simp [assocNeg_self n i k hi (Finset.mem_range.mp hk)]

/-- Degenerate pairs contribute nothing, so the sum over admissible pairs is the sum over
all pairs of indices. -/
theorem totalNonassocMiddles_eq_sum (n : Nat) :
    totalNonassocMiddles n
      = ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), (nonassocMiddles n i j).card := by
  rw [totalNonassocMiddles, admissiblePairs, Finset.sum_filter, Finset.sum_product]
  refine Finset.sum_congr rfl (fun i hi => ?_)
  refine Finset.sum_congr rfl (fun j _ => ?_)
  by_cases h : i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j
  · rw [if_pos h]
  · rw [if_neg h,
      nonassocMiddles_card_eq_zero_of_degenerate n i j (Finset.mem_range.mp hi) (by tauto)]

/-! ## 2. Counting the non-associating triples -/

/-- The ordered basis triples whose associator does not vanish. -/
def nonassociatingTriples (n : Nat) : Nat :=
  (((range (2 ^ n)) ×ˢ (range (2 ^ n)) ×ˢ (range (2 ^ n))).filter
    (fun t => assocNeg n t.1 t.2.1 t.2.2 = true)).card

theorem nonassociatingTriples_eq_sum (n : Nat) :
    nonassociatingTriples n
      = ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), (nonassocMiddles n i j).card := by
  rw [nonassociatingTriples, Finset.card_filter, Finset.sum_product]
  refine Finset.sum_congr rfl (fun i _ => ?_)
  rw [Finset.sum_product, Finset.sum_comm]
  refine Finset.sum_congr rfl (fun j _ => ?_)
  rw [nonassocMiddles, Finset.card_filter]

theorem nonassociatingTriples_add_associatingTriples (n : Nat) :
    nonassociatingTriples n + associatingTriples n = (2 ^ n) ^ 3 := by
  have hsplit := Finset.card_filter_add_card_filter_not
    (s := (range (2 ^ n)) ×ˢ (range (2 ^ n)) ×ˢ (range (2 ^ n)))
    (p := fun t => assocNeg n t.1 t.2.1 t.2.2 = true)
  have hneg : ((range (2 ^ n)) ×ˢ (range (2 ^ n)) ×ˢ (range (2 ^ n))).filter
      (fun t => ¬ (assocNeg n t.1 t.2.1 t.2.2 = true))
      = ((range (2 ^ n)) ×ˢ (range (2 ^ n)) ×ˢ (range (2 ^ n))).filter
        (fun t => assocNeg n t.1 t.2.1 t.2.2 = false) := by
    apply Finset.filter_congr
    intro t _
    simp
  have hcard : ((range (2 ^ n)) ×ˢ (range (2 ^ n)) ×ˢ (range (2 ^ n))).card = (2 ^ n) ^ 3 := by
    rw [Finset.card_product, Finset.card_product, card_range]
    ring
  rw [hneg, hcard] at hsplit
  exact hsplit

/-! ## 3. The handshake identity -/

/-- **The handshake identity.**  Summing the non-associating middles over all admissible
pairs and adding the associating triples gives all `D³` ordered basis triples. -/
theorem totalNonassocMiddles_add_associatingTriples (n : Nat) :
    totalNonassocMiddles n + associatingTriples n = (2 ^ n) ^ 3 := by
  rw [totalNonassocMiddles_eq_sum, ← nonassociatingTriples_eq_sum]
  exact nonassociatingTriples_add_associatingTriples n

/-- **The total degree of the annihilation graph.**  In every dimension `D = 2ⁿ ≥ 2` of the
tower the admissible pairs carry exactly `D³/2 - 14 D + 24` non-associating middles in
total. -/
theorem totalNonassocMiddles_formula (n : Nat) (hn : 1 ≤ n) :
    2 * totalNonassocMiddles n + 28 * 2 ^ n = (2 ^ n) ^ 3 + 48 := by
  have h1 := totalNonassocMiddles_add_associatingTriples n
  have h2 := associatingTriples_formula_dim n hn
  omega

/-! ## 4. The first moment of the degree census -/

/-- The total number of non-associating middles is the first moment of the degree census. -/
theorem degreeCount_weighted_sum (n : Nat) :
    ∑ v ∈ range (2 ^ n + 1), v * degreeCount n v = totalNonassocMiddles n := by
  rw [totalNonassocMiddles]
  have hmaps : ∀ p ∈ admissiblePairs n, (nonassocMiddles n p.1 p.2).card ∈ range (2 ^ n + 1) := by
    intro p _
    have : (nonassocMiddles n p.1 p.2).card ≤ 2 ^ n := by
      calc (nonassocMiddles n p.1 p.2).card ≤ (range (2 ^ n)).card :=
            Finset.card_le_card (Finset.filter_subset _ _)
      _ = 2 ^ n := card_range _
    simp only [mem_range]
    omega
  have key := Finset.sum_fiberwise_of_maps_to hmaps (fun p => (nonassocMiddles n p.1 p.2).card)
  rw [← key]
  refine Finset.sum_congr rfl (fun v _ => ?_)
  have hfib : ∑ p ∈ (admissiblePairs n).filter (fun p => (nonassocMiddles n p.1 p.2).card = v),
      (nonassocMiddles n p.1 p.2).card
      = ∑ _p ∈ (admissiblePairs n).filter (fun p => (nonassocMiddles n p.1 p.2).card = v), v :=
    Finset.sum_congr rfl (fun p hp => (Finset.mem_filter.mp hp).2)
  rw [hfib, Finset.sum_const, smul_eq_mul, degreeCount, Nat.mul_comm]

end Sovereign
