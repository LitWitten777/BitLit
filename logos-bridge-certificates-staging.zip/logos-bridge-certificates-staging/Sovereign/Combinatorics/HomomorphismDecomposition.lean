module

public import Mathlib

@[expose] public section

/-!
# Why chunking works: homomorphisms decompose over concatenation

Three "scaling" results of the corpus are the same theorem in different costumes:

* **Text chunking** (`QBX.Formal.TextManifold.mapReduce`): a braid / permutation / writhe / hash
  homomorphism evaluated on a text cut into chunks is the product of its values on the chunks.
* **Gauge holonomy** (`QBX.Formal.Gauge.Connection.holonomy_append`): the holonomy of a
  concatenated walk is the product of the holonomies.
* **Cayley–Dickson tower doubling** (`Sovereign.sum_range_two_mul_int`, used by
  `Sovereign.censusT_succ_weighted`): a weighted census sum over level `q + 1` is a sum over
  blocks of two consecutive indices, one block per element of level `q`.

The common statement: a monoid homomorphism out of a **free** monoid is determined by its values
on generators, and therefore turns any cut of a word into pieces (any concatenation) into a
product.  This file states the abstract version once and then the three specialisations.

## Main results

* `prod_map_flatten` / `sum_map_flatten` — the product of `g` over a list cut into chunks is the
  product of the chunk products (the core identity; any monoid).
* `hom_ofList_eq_prod` — a homomorphism out of `FreeMonoid α` is the product of its values on
  the letters (it is determined by the generators).
* `hom_flatten` / `addHom_flatten` — **chunking theorem**: such a homomorphism, evaluated on a
  text cut into chunks, is the product of its values on the chunks.
* `prod_map_of_eq_append` — the **factorisation principle**: any quantity defined as a product
  over an "edge list" `e x` is multiplicative along every operation that `e` sends to `++`
  (this is how walks, paths and braid words inherit the chunking law).
* `prod_range_blocks` / `sum_range_blocks` — the index range `[0, k n)` cut into `n` blocks of
  length `k` (the tower costume); `sum_range_pairs` is the case `k = 2`.
* `coprod_hom_decompose` — a homomorphism out of a free product `M ∗ N` of monoids is determined
  by its two restrictions.
-/

namespace Sovereign.HomDecomp

section Chunks

variable {α M : Type*} [Monoid M]

/-- **Core identity.**  The product of `g` over a list cut into chunks is the product, over the
chunks, of the chunk products. -/
@[to_additive /-- **Core identity (additive).**  The sum of `g` over a list cut into chunks is
the sum, over the chunks, of the chunk sums. -/]
theorem prod_map_flatten (g : α → M) (chunks : List (List α)) :
    (chunks.flatten.map g).prod = (chunks.map fun c => (c.map g).prod).prod := by
  induction chunks with
  | nil => simp
  | cons c cs ih =>
    simp only [List.flatten_cons, List.map_append, List.prod_append, ih, List.map_cons,
      List.prod_cons]

/-- **Determined by generators.**  A homomorphism out of the free monoid is the product of its
values on the letters. -/
@[to_additive /-- An additive homomorphism out of the free additive monoid is the sum of its
values on the letters. -/]
theorem hom_ofList_eq_prod (f : FreeMonoid α →* M) (l : List α) :
    f (FreeMonoid.ofList l) = (l.map fun a => f (FreeMonoid.of a)).prod := by
  induction l with
  | nil => simp
  | cons a l ih =>
    rw [FreeMonoid.ofList_cons, map_mul, ih, List.map_cons, List.prod_cons]

/-- **Chunking theorem.**  A homomorphism out of the free monoid, evaluated on a text cut into
chunks, is the product of its values on the chunks. -/
@[to_additive addHom_flatten /-- **Chunking theorem (additive).** -/]
theorem hom_flatten (f : FreeMonoid α →* M) (chunks : List (List α)) :
    f (FreeMonoid.ofList chunks.flatten) =
      (chunks.map fun c => f (FreeMonoid.ofList c)).prod := by
  rw [hom_ofList_eq_prod, prod_map_flatten]
  congr 1
  exact List.map_congr_left fun c _ => (hom_ofList_eq_prod f c).symm

/-- **Factorisation principle.**  If a list `l` is the concatenation `l₁ ++ l₂` (e.g. the edge
list of a concatenated walk), the product of `g` over `l` is the product over `l₁` times the
product over `l₂`.  Every quantity defined as an ordered product over an edge list is thereby
multiplicative along every operation that the edge list turns into `++`. -/
@[to_additive /-- **Factorisation principle (additive).** -/]
theorem prod_map_of_eq_append (g : α → M) {l l₁ l₂ : List α} (h : l = l₁ ++ l₂) :
    (l.map g).prod = (l₁.map g).prod * (l₂.map g).prod := by
  rw [h, List.map_append, List.prod_append]

/-- **Factorisation principle, many pieces.**  If `l` is the concatenation of the pieces, the
product over `l` is the product of the piece products. -/
@[to_additive /-- **Factorisation principle, many pieces (additive).** -/]
theorem prod_map_of_eq_flatten (g : α → M) {l : List α} {pieces : List (List α)}
    (h : l = pieces.flatten) :
    (l.map g).prod = (pieces.map fun c => (c.map g).prod).prod := by
  rw [h, prod_map_flatten]

end Chunks

section Blocks

open Finset

variable {M : Type*} [CommMonoid M]

/-- **Blocks of an index range** (the tower costume).  The range `[0, k n)` is the
concatenation of the `n` blocks `[k s, k s + k)`, so a product over it is a product over blocks. -/
@[to_additive /-- **Blocks of an index range** (additive). -/]
theorem prod_range_blocks (k n : ℕ) (g : ℕ → M) :
    ∏ i ∈ range (k * n), g i = ∏ s ∈ range n, ∏ j ∈ range k, g (k * s + j) := by
  induction n with
  | zero => simp
  | succ n ih => rw [Nat.mul_succ, prod_range_add, ih, prod_range_succ]

/-- **Pairs** (`k = 2`): the doubling step of the Cayley–Dickson tower, where the element `s`
of level `q` has the two children `2 s` and `2 s + 1` at level `q + 1`. -/
@[to_additive /-- **Pairs** (additive, `k = 2`): the doubling step of the
Cayley–Dickson tower, where the element `s` of level `q` has the two children `2 s` and
`2 s + 1` at level `q + 1`. -/]
theorem prod_range_pairs (n : ℕ) (g : ℕ → M) :
    ∏ i ∈ range (2 * n), g i = ∏ s ∈ range n, (g (2 * s) * g (2 * s + 1)) := by
  rw [prod_range_blocks]
  refine prod_congr rfl fun s _ => ?_
  simp [prod_range_succ]

end Blocks

section FreeProduct

variable {M N P : Type*} [Monoid M] [Monoid N] [Monoid P]

/-- **Free products.**  A homomorphism out of the free product `M ∗ N` is determined by its two
restrictions: it is the homomorphism lifted from `f ∘ inl` and `f ∘ inr`. -/
theorem coprod_hom_decompose (f : Monoid.Coprod M N →* P) :
    f = Monoid.Coprod.lift (f.comp Monoid.Coprod.inl) (f.comp Monoid.Coprod.inr) :=
  Monoid.Coprod.hom_ext (by ext; simp) (by ext; simp)

end FreeProduct

end Sovereign.HomDecomp
