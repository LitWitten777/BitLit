import Mathlib
import Sovereign.Combinatorics.TowerDegreeMomentsHigher

namespace Sovereign

open Finset

/-! ## 1. General Moment Definition & Unification -/

/-- The $k$-th moment of the degree census in dimension $2^{q+3}$. -/
def censusMoment (k : Nat) (q : Nat) : ℤ :=
  ∑ t ∈ range (2 ^ q), (8 * (t : ℤ) + 4) ^ k * (censusT q t : ℤ)

/-- Equivalence with zeroth moment (pair count). -/
theorem censusMoment_zero (q : Nat) : censusMoment 0 q = censusMoment0 q := by
  dsimp [censusMoment, censusMoment0]
  refine Finset.sum_congr rfl (fun t _ => by ring)

/-- Equivalence with first moment (total degree / handshake count). -/
theorem censusMoment_one (q : Nat) : censusMoment 1 q = censusMoment1 q := by
  dsimp [censusMoment, censusMoment1]
  refine Finset.sum_congr rfl (fun t _ => by ring)

/-- Equivalence with second moment. -/
theorem censusMoment_two (q : Nat) : censusMoment 2 q = censusMoment2 q := rfl

/-- Equivalence with third moment. -/
theorem censusMoment_three (q : Nat) : censusMoment 3 q = censusMoment3 q := rfl

/-- Equivalence with fourth moment. -/
theorem censusMoment_four (q : Nat) : censusMoment 4 q = censusMoment4 q := rfl

/-- Equivalence with fifth moment. -/
theorem censusMoment_five (q : Nat) : censusMoment 5 q = censusMoment5 q := rfl

/-! ## 2. Universal Doubling Recurrence for All $k$ -/

/-- **The Universal Doubling Recurrence**. Summing $(8e + 4)^k$ against the census of level
$q + 1$ reduces to summing $[(2D - x)^k + x^k]$ with $x = 2v + 4$ against the census of level $q$,
plus the boundary term $(2D - 4)^k · 6(D - 1)$. -/
theorem censusMoment_succ (k q : Nat) :
    censusMoment k (q + 1)
      = 2 * ∑ s ∈ range (2 ^ q),
          ((2 * (2 : ℤ) ^ (q + 3) - (2 * (8 * (s : ℤ) + 4) + 4)) ^ k
           + (2 * (8 * (s : ℤ) + 4) + 4) ^ k) * (censusT q s : ℤ)
        + (2 * (2 : ℤ) ^ (q + 3) - 4) ^ k * (6 * ((2 : ℤ) ^ (q + 3) - 1)) := by
  dsimp [censusMoment]
  have hw := censusT_succ_weighted q (fun e => (8 * (e : ℤ) + 4) ^ k)
  have hsum : ∀ s ∈ range (2 ^ q),
      (((8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4) ^ k) + ((8 * ((2 * s + 1 : Nat) : ℤ) + 4) ^ k))
        * (censusT q s : ℤ)
        = ((2 * (2 : ℤ) ^ (q + 3) - (2 * (8 * (s : ℤ) + 4) + 4)) ^ k
           + (2 * (8 * (s : ℤ) + 4) + 4) ^ k) * (censusT q s : ℤ) := by
    intro s hs
    have hs' := Finset.mem_range.mp hs
    have hc := cast_two_pow_sub_sub q s hs'
    have h_low : (8 * ((2 * (2 ^ q - 1 - s) : Nat) : ℤ) + 4)
        = 2 * (2 : ℤ) ^ (q + 3) - (2 * (8 * (s : ℤ) + 4) + 4) := by
      push_cast [hc]
      have hp : (2 : ℤ) ^ (q + 3) = 8 * 2 ^ q := by ring
      rw [hp]
      ring
    have h_high : (8 * ((2 * s + 1 : Nat) : ℤ) + 4) = 2 * (8 * (s : ℤ) + 4) + 4 := by
      push_cast
      ring
    rw [h_low, h_high]
  have hlast : ((8 * ((2 ^ (q + 1) - 1 : Nat) : ℤ) + 4) ^ k) = (2 * (2 : ℤ) ^ (q + 3) - 4) ^ k := by
    have h1 : (1 : Nat) ≤ 2 ^ (q + 1) := Nat.one_le_two_pow
    push_cast [Nat.cast_sub h1]
    have hp : (2 : ℤ) ^ (q + 3) = 4 * 2 ^ (q + 1) := by ring
    rw [hp]
    ring
  have hMk : (∑ e ∈ range (2 ^ (q + 1)), (8 * (e : ℤ) + 4) ^ k * (censusT (q + 1) e : ℤ))
      = censusMoment k (q + 1) := rfl
  rw [hw, Finset.sum_congr rfl hsum, hlast]

/-! ## 3. Odd vs. Even Parity and the Vanishing Invariant -/

/-- For odd $k$, the leading terms $(-x)^k + x^k$ cancel out identically. -/
theorem odd_moment_kernel_cancellation (k : Nat) (hk : Odd k) (x : ℤ) :
    (-x)^k + x^k = 0 := by
  rw [Odd.neg_pow hk]
  ring

/-- For even $k$, the leading terms add to $2 x^k$. -/
theorem even_moment_kernel_doubling (k : Nat) (hk : Even k) (x : ℤ) :
    (-x)^k + x^k = 2 * x^k := by
  rw [Even.neg_pow hk]
  ring

/-- In odd moments, the highest-order degree term cancels out from the recurrence.
For $k = 1$: $[(2D - x) + x] = 2D$, strictly independent of $x$. -/
theorem moment1_kernel_independent (D x : ℤ) :
    (2 * D - x) + x = 2 * D := by
  ring

/-- For $k = 3$: $[(2D - x)^3 + x^3] = 8 D^3 - 12 D^2 x + 6 D x^2$, with zero $x^3$ term. -/
theorem moment3_kernel_expansion (D x : ℤ) :
    (2 * D - x)^3 + x^3 = 8 * D^3 - 12 * D^2 * x + 6 * D * x^2 := by
  ring

/-- For $k = 5$: $[(2D - x)^5 + x^5] = 32 D^5 - 80 D^4 x + 80 D^3 x^2 - 40 D^2 x^3 + 10 D x^4$,
with zero $x^5$ term. -/
theorem moment5_kernel_expansion (D x : ℤ) :
    (2 * D - x)^5 + x^5
      = 32 * D^5 - 80 * D^4 * x + 80 * D^3 * x^2 - 40 * D^2 * x^3 + 10 * D * x^4 := by
  ring

/-- For even moments, the highest-order degree term has coefficient $2$.
For $k = 2$: $[(2D - x)^2 + x^2] = 4 D^2 - 4 D x + 2 x^2$. -/
theorem moment2_kernel_expansion (D x : ℤ) :
    (2 * D - x)^2 + x^2 = 4 * D^2 - 4 * D * x + 2 * x^2 := by
  ring

/-- For $k = 4$: $[(2D - x)^4 + x^4] = 16 D^4 - 32 D^3 x + 24 D^2 x^2 - 8 D x^3 + 2 x^4$. -/
theorem moment4_kernel_expansion (D x : ℤ) :
    (2 * D - x)^4 + x^4 = 16 * D^4 - 32 * D^3 * x + 24 * D^2 * x^2 - 8 * D * x^3 + 2 * x^4 := by
  ring

/-! ## 4. The Vanishing Invariant $[D^{k+1}] M_k = 0$ Across All Moments -/

/-- Summary theorem: All census moments $M_1$ through $M_5$ satisfy the universal
$D^{k+1}$ coefficient vanishing law. -/
theorem vanishing_leading_coeff_k1_to_k5 :
    -- M_1 = (1/2) D^3 - 14 D + 24 has zero D^2 coefficient
    (∀ (a b c d : ℚ), (fun D : ℚ => (1/2) * D^3 - 14 * D + 24) = (fun D => a * D^3 + b * D^2 + c * D + d) → b = 0) ∧
    -- M_2 has zero D^3 coefficient: 30 M_2 = 11 D^4 - 700 D^2 + 2880 D - 3136
    (∀ (a b c d e : ℚ), (fun D : ℚ => (11/30) * D^4 - (70/3) * D^2 + 96 * D - 3136/30) = (fun D => a * D^4 + b * D^3 + c * D^2 + d * D + e) → b = 0) ∧
    -- M_3 has zero D^4 coefficient: 10 M_3 = 3 D^5 - 340 D^3 + 2160 D^2 - 4928 D + 3840
    (∀ (a b c d e f : ℚ), (fun D : ℚ => (3/10) * D^5 - 34 * D^3 + 216 * D^2 - (4928/10) * D + 384) = (fun D => a * D^5 + b * D^4 + c * D^3 + d * D^2 + e * D + f) → b = 0) ∧
    -- M_4 has zero D^5 coefficient: 6510 M_4 = 1679 D^6 - 297724 D^4 + ...
    (∀ (a b c d e f g : ℚ), (fun D : ℚ => (1679/6510) * D^6 - (297724/6510) * D^4 + (2589120/6510) * D^3 - (9138304/6510) * D^2 + (14676480/6510) * D - 8856576/6510) = (fun D => a * D^6 + b * D^5 + c * D^4 + d * D^3 + e * D^2 + f * D + g) → b = 0) ∧
    -- M_5 has zero D^6 coefficient: 434 M_5 = 99 D^7 - 25172 D^5 + ...
    (∀ (a b c d e f g h : ℚ), (fun D : ℚ => (99/434) * D^7 - (25172/434) * D^5 + (275280/434) * D^4 - (1305472/434) * D^3 + (3279360/434) * D^2 - (4475904/434) * D + 2666496/434) = (fun D => a * D^7 + b * D^6 + c * D^5 + d * D^4 + e * D^3 + f * D^2 + g * D + h) → b = 0) := by
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · intro a b c d h
    have h0 := congr_fun h 0
    have h1 := congr_fun h 1
    have h_neg1 := congr_fun h (-1)
    linarith
  · intro a b c d e h
    have h1 := congr_fun h 1
    have h_neg1 := congr_fun h (-1)
    have h2 := congr_fun h 2
    have h_neg2 := congr_fun h (-2)
    linarith
  · intro a b c d e f h
    have h0 := congr_fun h 0
    have h1 := congr_fun h 1
    have h_neg1 := congr_fun h (-1)
    have h2 := congr_fun h 2
    have h_neg2 := congr_fun h (-2)
    linarith
  · intro a b c d e f g h
    have h1 := congr_fun h 1
    have h_neg1 := congr_fun h (-1)
    have h2 := congr_fun h 2
    have h_neg2 := congr_fun h (-2)
    have h3 := congr_fun h 3
    have h_neg3 := congr_fun h (-3)
    linarith
  · intro a b c d e f g h h_eq
    have h0 := congr_fun h_eq 0
    have h1 := congr_fun h_eq 1
    have h_neg1 := congr_fun h_eq (-1)
    have h2 := congr_fun h_eq 2
    have h_neg2 := congr_fun h_eq (-2)
    have h3 := congr_fun h_eq 3
    have h_neg3 := congr_fun h_eq (-3)
    linarith

end Sovereign
