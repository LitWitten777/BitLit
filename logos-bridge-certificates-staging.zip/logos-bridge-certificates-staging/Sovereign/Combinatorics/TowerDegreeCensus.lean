import Sovereign.Combinatorics.TowerDegreeClosedForm

namespace Sovereign

open Finset

/-! ## 1. The multiplicity function -/

/-- `degreeCount n v` is the number of ordered admissible pairs `(i, j)` with `i, j < 2ⁿ`
whose outer pair `(e_i, ·, e_j)` has exactly `v` non-associating middles. -/
def degreeCount (n v : Nat) : Nat :=
  ((admissiblePairs n).filter (fun p => (nonassocMiddles n p.1 p.2).card = v)).card

/-- The indicator of an ordered admissible pair of degree `v`, written through the
recursion `towerDegree`. -/
def degIndicator (n v i j : Nat) : Nat :=
  if i ≠ 0 ∧ j ≠ 0 ∧ i ≠ j ∧ towerDegree n i j = v then 1 else 0

theorem degreeCount_eq_sum (n v : Nat) :
    degreeCount n v = ∑ i ∈ range (2 ^ n), ∑ j ∈ range (2 ^ n), degIndicator n v i j := by
  classical
  rw [degreeCount, admissiblePairs_degree_filter, admissiblePairs, Finset.filter_filter,
    Finset.card_filter, Finset.sum_product]
  refine Finset.sum_congr rfl (fun i _ => Finset.sum_congr rfl (fun j _ => ?_))
  unfold degIndicator
  exact indicator_congr (by tauto)

/-! ## 2. Quantization and bounds, read through the recursion -/

theorem towerDegree_mod_eight (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    towerDegree n i j % 8 = 4 := by
  rw [← nonassocMiddles_card_eq_towerDegree n i j hi hj hi0 hj0 hij]
  exact nonassocMiddles_card_mod_eight n hn i j hi hj hi0 hj0 hij

theorem towerDegree_bounds (n : Nat) (hn : 3 ≤ n) (i j : Nat) (hi : i < 2 ^ n)
    (hj : j < 2 ^ n) (hi0 : i ≠ 0) (hj0 : j ≠ 0) (hij : i ≠ j) :
    4 ≤ towerDegree n i j ∧ towerDegree n i j ≤ 2 ^ n - 4 := by
  rw [← nonassocMiddles_card_eq_towerDegree n i j hi hj hi0 hj0 hij]
  exact nonassocMiddles_card_bounds n i j hn hi hj hi0 hj0 hij

/-! ## 3. Splitting a doubling step into its four blocks -/

theorem sum_split_succ (m : Nat) (F : Nat → Nat → Nat) :
    ∑ i ∈ range (2 ^ (m + 1)), ∑ j ∈ range (2 ^ (m + 1)), F i j
      = ((∑ i ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), F i j)
          + ∑ i ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), F i (2 ^ m + c))
        + ((∑ a ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), F (2 ^ m + a) j)
          + ∑ a ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m), F (2 ^ m + a) (2 ^ m + c)) := by
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  have hinner : ∀ x : Nat, ∑ j ∈ range (2 ^ m + 2 ^ m), F x j
      = (∑ j ∈ range (2 ^ m), F x j) + ∑ c ∈ range (2 ^ m), F x (2 ^ m + c) :=
    fun x => Finset.sum_range_add (fun j => F x j) (2 ^ m) (2 ^ m)
  rw [hpow, Finset.sum_range_add]
  rw [Finset.sum_congr rfl (fun i _ => hinner i),
    Finset.sum_congr rfl (fun a _ => hinner (2 ^ m + a)),
    Finset.sum_add_distrib, Finset.sum_add_distrib]

/-! ## 4. Arithmetic separation of the two degree families

At a doubling step a degree is either of the form `2v + 4` (congruent to `12` modulo `16`)
or of the form `2ⁿ⁺¹ - (2v + 4)` (congruent to `4` modulo `16`).  The two families never
meet, which is what makes the census split cleanly. -/

theorem eight_dvd_two_pow (m : Nat) (hm : 3 ≤ m) : ∃ s, (2 : Nat) ^ m = 8 * s := by
  obtain ⟨s, hs⟩ : (8 : Nat) ∣ 2 ^ m := by
    rw [show (8 : Nat) = 2 ^ 3 by norm_num]
    exact pow_dvd_pow 2 hm
  exact ⟨s, hs⟩

theorem eight_le_two_pow (m : Nat) (hm : 3 ≤ m) : (8 : Nat) ≤ 2 ^ m := by
  calc (8 : Nat) = 2 ^ 3 := by norm_num
    _ ≤ 2 ^ m := Nat.pow_le_pow_right (by norm_num) hm

/-- A complemented degree is never a doubled degree. -/
theorem complement_ne_double (m d v : Nat) (hm : 3 ≤ m) (hd : d % 8 = 4) (hv : v % 8 = 4) :
    2 ^ (m + 1) - (2 * d + 4) ≠ 2 * v + 4 := by
  obtain ⟨s, hs⟩ := eight_dvd_two_pow m hm
  have hpow : (2 : Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
  have h8 := eight_le_two_pow m hm
  omega

/-- A doubled degree is never a complemented degree. -/
theorem double_ne_complement (m d v : Nat) (hm : 3 ≤ m) (hd : d % 8 = 4) (hv : v % 8 = 4) :
    2 * d + 4 ≠ 2 ^ (m + 1) - (2 * v + 4) :=
  fun h => complement_ne_double m v d hm hv hd h.symm

/-- The degree indicator is symmetric in the outer pair. -/
theorem degIndicator_comm (n v i j : Nat) (hi : i < 2 ^ n) (hj : j < 2 ^ n) :
    degIndicator n v i j = degIndicator n v j i := by
  unfold degIndicator
  refine indicator_congr ?_
  constructor
  · rintro ⟨h1, h2, h3, h4⟩
    refine ⟨h2, h1, Ne.symm h3, ?_⟩
    rwa [towerDegree_comm n j i hj hi h2 h1 (Ne.symm h3)]
  · rintro ⟨h1, h2, h3, h4⟩
    refine ⟨h2, h1, Ne.symm h3, ?_⟩
    rwa [towerDegree_comm n i j hi hj h2 h1 (Ne.symm h3)]

/-! ## 5. The four blocks for a doubled degree `2v + 4` -/

theorem census_low_block_ll (m v : Nat) :
    (∑ i ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m), degIndicator (m + 1) (2 * v + 4) i j)
      = degreeCount m v := by
  rw [degreeCount_eq_sum]
  refine Finset.sum_congr rfl (fun i hi => Finset.sum_congr rfl (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold degIndicator
  refine indicator_congr ?_
  rw [towerDegree_low_low m i j hi' hj']
  constructor
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h1, h2, h3, by omega⟩
  · rintro ⟨h1, h2, h3, h4⟩; exact ⟨h1, h2, h3, by omega⟩

theorem census_low_block_lh (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    (∑ i ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
        degIndicator (m + 1) (2 * v + 4) i (2 ^ m + c))
      = (if v = 2 ^ m - 4 then 2 else 0) * (2 ^ m - 1) := by
  have h8 := eight_le_two_pow m hm
  have hpow : (2 : Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
  have key : ∀ i ∈ range (2 ^ m),
      (∑ c ∈ range (2 ^ m), degIndicator (m + 1) (2 * v + 4) i (2 ^ m + c))
        = if i = 0 then 0 else (if v = 2 ^ m - 4 then 2 else 0) := by
    intro i hi
    have hi' := Finset.mem_range.mp hi
    by_cases h1 : i = 0
    · rw [if_pos h1]
      refine Finset.sum_eq_zero (fun c _ => ?_)
      unfold degIndicator
      exact if_neg (by rintro ⟨h, -⟩; exact h h1)
    · rw [if_neg h1]
      have hnd : ∀ c ∈ range (2 ^ m), c ≠ 0 → c ≠ i →
          degIndicator (m + 1) (2 * v + 4) i (2 ^ m + c) = 0 := by
        intro c hc hc0 hci
        have hc' := Finset.mem_range.mp hc
        unfold degIndicator
        refine if_neg ?_
        rintro ⟨-, -, -, h4⟩
        rw [towerDegree_low_high m i c hi' hc0 hci] at h4
        exact complement_ne_double m (towerDegree m i c) v hm
          (towerDegree_mod_eight m hm i c hi' hc' h1 hc0 (Ne.symm hci)) hv h4
      by_cases hmax : v = 2 ^ m - 4
      · rw [if_pos hmax]
        have hpt : ∀ c ∈ range (2 ^ m), degIndicator (m + 1) (2 * v + 4) i (2 ^ m + c)
            = if c = 0 ∨ c = i then 1 else 0 := by
          intro c hc
          have hc' := Finset.mem_range.mp hc
          by_cases hdeg : c = 0 ∨ c = i
          · rw [if_pos hdeg]
            unfold degIndicator
            refine if_pos ⟨h1, by omega, by omega, ?_⟩
            rw [towerDegree_low_high_deg m i c hi' hdeg]
            omega
          · rw [if_neg hdeg]
            exact hnd c hc (fun h => hdeg (Or.inl h)) (fun h => hdeg (Or.inr h))
        rw [Finset.sum_congr rfl hpt, ← Finset.card_filter]
        have hset : (range (2 ^ m)).filter (fun c => c = 0 ∨ c = i) = {0, i} := by
          ext c
          simp only [Finset.mem_filter, Finset.mem_range, Finset.mem_insert,
            Finset.mem_singleton]
          constructor
          · rintro ⟨-, h⟩; exact h
          · rintro (rfl | rfl) <;> exact ⟨by omega, by simp⟩
        rw [hset, Finset.card_pair (Ne.symm h1)]
      · rw [if_neg hmax]
        refine Finset.sum_eq_zero (fun c hc => ?_)
        have hc' := Finset.mem_range.mp hc
        by_cases hdeg : c = 0 ∨ c = i
        · unfold degIndicator
          refine if_neg ?_
          rintro ⟨-, -, -, h4⟩
          rw [towerDegree_low_high_deg m i c hi' hdeg] at h4
          omega
        · exact hnd c hc (fun h => hdeg (Or.inl h)) (fun h => hdeg (Or.inr h))
  rw [Finset.sum_congr rfl key, sum_range_ite_zero]

theorem census_low_block_hl (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    (∑ a ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m),
        degIndicator (m + 1) (2 * v + 4) (2 ^ m + a) j)
      = (if v = 2 ^ m - 4 then 2 else 0) * (2 ^ m - 1) := by
  rw [Finset.sum_comm, ← census_low_block_lh m v hm hv hvle]
  refine Finset.sum_congr rfl (fun j hj => Finset.sum_congr rfl (fun a ha => ?_))
  have ha' := Finset.mem_range.mp ha
  have hj' := Finset.mem_range.mp hj
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  exact degIndicator_comm (m + 1) (2 * v + 4) (2 ^ m + a) j (by omega) (by omega)

theorem census_low_block_hh (m v : Nat) (hm : 3 ≤ m) :
    (∑ a ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
        degIndicator (m + 1) (2 * v + 4) (2 ^ m + a) (2 ^ m + c))
      = degreeCount m v
        + 2 * ((if v = 2 ^ m - 4 then 1 else 0) * (2 ^ m - 1)) := by
  have hpos : 0 < (2 : Nat) ^ m := Nat.two_pow_pos m
  have h8 := eight_le_two_pow m hm
  have hpow : (2 : Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
  set K : Nat := if v = 2 ^ m - 4 then 1 else 0 with hK
  have hpt : ∀ a ∈ range (2 ^ m), ∀ c ∈ range (2 ^ m),
      degIndicator (m + 1) (2 * v + 4) (2 ^ m + a) (2 ^ m + c)
        = degIndicator m v a c + (if a = 0 then (if c = 0 then 0 else K) else 0)
          + (if c = 0 then (if a = 0 then 0 else K) else 0) := by
    intro a ha c hc
    have ha' := Finset.mem_range.mp ha
    have hc' := Finset.mem_range.mp hc
    by_cases hac : a = c
    · subst hac
      unfold degIndicator
      rw [if_neg (by rintro ⟨-, -, h, -⟩; exact h rfl),
        if_neg (by rintro ⟨-, -, h, -⟩; exact h rfl)]
      by_cases h : a = 0 <;> simp [h]
    · by_cases ha0 : a = 0
      · subst ha0
        have hc0 : c ≠ 0 := fun h => hac h.symm
        have hval : towerDegree (m + 1) (2 ^ m + 0) (2 ^ m + c) = 2 ^ (m + 1) - 4 :=
          towerDegree_high_high_deg m 0 c (Or.inl rfl)
        have hz : degIndicator m v 0 c = 0 := by
          unfold degIndicator; exact if_neg (by rintro ⟨h, -⟩; exact h rfl)
        have hLHS : degIndicator (m + 1) (2 * v + 4) (2 ^ m + 0) (2 ^ m + c) = K := by
          unfold degIndicator
          by_cases hmax : v = 2 ^ m - 4
          · rw [hK, if_pos hmax, if_pos]
            exact ⟨by omega, by omega, by omega, by rw [hval, hmax]; omega⟩
          · rw [hK, if_neg hmax, if_neg]
            rintro ⟨-, -, -, h4⟩
            rw [hval] at h4
            omega
        rw [hLHS, hz, if_neg hc0, if_neg hc0]
        simp
      · by_cases hc0 : c = 0
        · subst hc0
          have hval : towerDegree (m + 1) (2 ^ m + a) (2 ^ m + 0) = 2 ^ (m + 1) - 4 :=
            towerDegree_high_high_deg m a 0 (Or.inr rfl)
          have hz : degIndicator m v a 0 = 0 := by
            unfold degIndicator; exact if_neg (by rintro ⟨-, h, -⟩; exact h rfl)
          have hLHS : degIndicator (m + 1) (2 * v + 4) (2 ^ m + a) (2 ^ m + 0) = K := by
            unfold degIndicator
            by_cases hmax : v = 2 ^ m - 4
            · rw [hK, if_pos hmax, if_pos]
              exact ⟨by omega, by omega, by omega, by rw [hval, hmax]; omega⟩
            · rw [hK, if_neg hmax, if_neg]
              rintro ⟨-, -, -, h4⟩
              rw [hval] at h4
              omega
          rw [hLHS, hz, if_neg ha0, if_pos rfl, if_neg ha0]
          simp
        · rw [if_neg ha0, if_neg hc0, Nat.add_zero, Nat.add_zero]
          unfold degIndicator
          refine indicator_congr ?_
          rw [towerDegree_high_high m a c ha0 hc0]
          constructor
          · rintro ⟨-, -, -, h4⟩; exact ⟨ha0, hc0, hac, by omega⟩
          · rintro ⟨-, -, -, h4⟩; exact ⟨by omega, by omega, by omega, by omega⟩
  rw [Finset.sum_congr rfl (fun a ha => Finset.sum_congr rfl (hpt a ha))]
  have hsplit : ∀ a ∈ range (2 ^ m),
      (∑ c ∈ range (2 ^ m), (degIndicator m v a c
          + (if a = 0 then (if c = 0 then 0 else K) else 0)
          + (if c = 0 then (if a = 0 then 0 else K) else 0)))
        = (∑ c ∈ range (2 ^ m), degIndicator m v a c)
          + (if a = 0 then K * (2 ^ m - 1) else 0) + (if a = 0 then 0 else K) := by
    intro a _
    rw [Finset.sum_add_distrib, Finset.sum_add_distrib]
    have hA : (∑ c ∈ range (2 ^ m), (if a = 0 then (if c = 0 then 0 else K) else 0))
        = (if a = 0 then K * (2 ^ m - 1) else 0) := by
      by_cases h : a = 0
      · subst h
        exact sum_range_ite_zero (2 ^ m) K
      · simp only [if_neg h, Finset.sum_const_zero]
    have hB : (∑ c ∈ range (2 ^ m), (if c = 0 then (if a = 0 then 0 else K) else 0))
        = (if a = 0 then 0 else K) := by
      by_cases h : a = 0
      · subst h
        simp
      · simp only [if_neg h]
        exact sum_range_ite_eq_zero (2 ^ m) K hpos
    rw [hA, hB]
  rw [Finset.sum_congr rfl hsplit, Finset.sum_add_distrib, Finset.sum_add_distrib,
    ← degreeCount_eq_sum m v, sum_range_ite_eq_zero (2 ^ m) (K * (2 ^ m - 1)) hpos,
    sum_range_ite_zero (2 ^ m) K]
  ring

/-! ## 6. The four blocks for a complemented degree `2ⁿ⁺¹ - (2v + 4)` -/

theorem census_high_block_ll (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4) :
    (∑ i ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m),
        degIndicator (m + 1) (2 ^ (m + 1) - (2 * v + 4)) i j) = 0 := by
  refine Finset.sum_eq_zero (fun i hi => Finset.sum_eq_zero (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold degIndicator
  refine if_neg ?_
  rintro ⟨h1, h2, h3, h4⟩
  rw [towerDegree_low_low m i j hi' hj'] at h4
  exact double_ne_complement m (towerDegree m i j) v hm
    (towerDegree_mod_eight m hm i j hi' hj' h1 h2 h3) hv h4

theorem census_high_block_lh (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    (∑ i ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
        degIndicator (m + 1) (2 ^ (m + 1) - (2 * v + 4)) i (2 ^ m + c))
      = degreeCount m v := by
  have h8 := eight_le_two_pow m hm
  have hpow : (2 : Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
  rw [degreeCount_eq_sum]
  refine Finset.sum_congr rfl (fun i hi => Finset.sum_congr rfl (fun c hc => ?_))
  have hi' := Finset.mem_range.mp hi
  have hc' := Finset.mem_range.mp hc
  by_cases h1 : i = 0
  · subst h1
    unfold degIndicator
    rw [if_neg (by rintro ⟨h, -⟩; exact h rfl), if_neg (by rintro ⟨h, -⟩; exact h rfl)]
  · by_cases hdeg : c = 0 ∨ c = i
    · have hz : degIndicator m v i c = 0 := by
        unfold degIndicator
        refine if_neg ?_
        rintro ⟨-, h2, h3, -⟩
        rcases hdeg with rfl | rfl
        · exact h2 rfl
        · exact h3 rfl
      rw [hz]
      unfold degIndicator
      refine if_neg ?_
      rintro ⟨-, -, -, h4⟩
      rw [towerDegree_low_high_deg m i c hi' hdeg] at h4
      omega
    · have hc0 : c ≠ 0 := fun h => hdeg (Or.inl h)
      have hci : c ≠ i := fun h => hdeg (Or.inr h)
      have hb := (towerDegree_bounds m hm i c hi' hc' h1 hc0 (Ne.symm hci)).2
      unfold degIndicator
      refine indicator_congr ?_
      rw [towerDegree_low_high m i c hi' hc0 hci]
      constructor
      · rintro ⟨-, -, -, h4⟩; exact ⟨h1, hc0, Ne.symm hci, by omega⟩
      · rintro ⟨-, -, -, h4⟩; exact ⟨h1, by omega, by omega, by omega⟩

theorem census_high_block_hl (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    (∑ a ∈ range (2 ^ m), ∑ j ∈ range (2 ^ m),
        degIndicator (m + 1) (2 ^ (m + 1) - (2 * v + 4)) (2 ^ m + a) j)
      = degreeCount m v := by
  rw [Finset.sum_comm, ← census_high_block_lh m v hm hv hvle]
  refine Finset.sum_congr rfl (fun j hj => Finset.sum_congr rfl (fun a ha => ?_))
  have ha' := Finset.mem_range.mp ha
  have hj' := Finset.mem_range.mp hj
  have hpow : (2 : Nat) ^ (m + 1) = 2 ^ m + 2 ^ m := by ring
  exact degIndicator_comm (m + 1) (2 ^ (m + 1) - (2 * v + 4)) (2 ^ m + a) j
    (by omega) (by omega)

theorem census_high_block_hh (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4) :
    (∑ a ∈ range (2 ^ m), ∑ c ∈ range (2 ^ m),
        degIndicator (m + 1) (2 ^ (m + 1) - (2 * v + 4)) (2 ^ m + a) (2 ^ m + c)) = 0 := by
  have h8 := eight_le_two_pow m hm
  have hpow : (2 : Nat) ^ (m + 1) = 2 * 2 ^ m := by ring
  refine Finset.sum_eq_zero (fun a ha => Finset.sum_eq_zero (fun c hc => ?_))
  have ha' := Finset.mem_range.mp ha
  have hc' := Finset.mem_range.mp hc
  unfold degIndicator
  refine if_neg ?_
  rintro ⟨-, -, h3, h4⟩
  have hac : a ≠ c := fun h => h3 (by omega)
  by_cases hdeg : a = 0 ∨ c = 0
  · rw [towerDegree_high_high_deg m a c hdeg] at h4
    omega
  · have ha0 : a ≠ 0 := fun h => hdeg (Or.inl h)
    have hc0 : c ≠ 0 := fun h => hdeg (Or.inr h)
    rw [towerDegree_high_high m a c ha0 hc0] at h4
    exact double_ne_complement m (towerDegree m a c) v hm
      (towerDegree_mod_eight m hm a c ha' hc' ha0 hc0 hac) hv h4

/-! ## 7. The two doubling laws of the census -/

/-- **Doubling law, low family.**  In dimension `2ᵐ⁺¹` the degree `2v + 4` is realised by
twice as many pairs as the degree `v` in dimension `2ᵐ`, plus the `6 (2ᵐ - 1)` degenerate
cross-half pairs when `2v + 4` is the maximal degree. -/
theorem degreeCount_succ_low (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    degreeCount (m + 1) (2 * v + 4)
      = 2 * degreeCount m v + (if v = 2 ^ m - 4 then 6 * (2 ^ m - 1) else 0) := by
  rw [degreeCount_eq_sum, sum_split_succ m (fun i j => degIndicator (m + 1) (2 * v + 4) i j),
    census_low_block_ll m v, census_low_block_lh m v hm hv hvle,
    census_low_block_hl m v hm hv hvle, census_low_block_hh m v hm]
  by_cases hmax : v = 2 ^ m - 4 <;> simp [hmax] <;> ring

/-- **Doubling law, complemented family.**  The degree `2ᵐ⁺¹ - (2v + 4)` in dimension
`2ᵐ⁺¹` is realised by exactly twice as many pairs as the degree `v` in dimension `2ᵐ`. -/
theorem degreeCount_succ_high (m v : Nat) (hm : 3 ≤ m) (hv : v % 8 = 4)
    (hvle : v ≤ 2 ^ m - 4) :
    degreeCount (m + 1) (2 ^ (m + 1) - (2 * v + 4)) = 2 * degreeCount m v := by
  rw [degreeCount_eq_sum,
    sum_split_succ m (fun i j => degIndicator (m + 1) (2 ^ (m + 1) - (2 * v + 4)) i j),
    census_high_block_ll m v hm hv, census_high_block_lh m v hm hv hvle,
    census_high_block_hl m v hm hv hvle, census_high_block_hh m v hm hv]
  ring

/-! ## 8. Degenerate values of the census -/

theorem degreeCount_eq_zero_of_gt (n v : Nat) (hn : 3 ≤ n) (h : 2 ^ n - 4 < v) :
    degreeCount n v = 0 := by
  rw [degreeCount_eq_sum]
  refine Finset.sum_eq_zero (fun i hi => Finset.sum_eq_zero (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold degIndicator
  refine if_neg ?_
  rintro ⟨h1, h2, h3, h4⟩
  have hb := (towerDegree_bounds n hn i j hi' hj' h1 h2 h3).2
  omega

theorem degreeCount_eq_zero_of_mod (n v : Nat) (hn : 3 ≤ n) (h : v % 8 ≠ 4) :
    degreeCount n v = 0 := by
  rw [degreeCount_eq_sum]
  refine Finset.sum_eq_zero (fun i hi => Finset.sum_eq_zero (fun j hj => ?_))
  have hi' := Finset.mem_range.mp hi
  have hj' := Finset.mem_range.mp hj
  unfold degIndicator
  refine if_neg ?_
  rintro ⟨h1, h2, h3, h4⟩
  have hq := towerDegree_mod_eight n hn i j hi' hj' h1 h2 h3
  rw [h4] at hq
  exact h hq

/-- The octonionic base of the census: in dimension `8` all `42` admissible pairs have
four non-associating middles. -/
theorem degreeCount_dim8_eq (v : Nat) : degreeCount 3 v = if v = 4 then 42 else 0 := by
  by_cases hv : v = 4
  · subst hv
    rw [if_pos rfl, degreeCount, admissiblePairs_degree_filter]
    decide
  · rw [if_neg hv, degreeCount_eq_sum]
    refine Finset.sum_eq_zero (fun i hi => Finset.sum_eq_zero (fun j hj => ?_))
    have hi' := Finset.mem_range.mp hi
    have hj' := Finset.mem_range.mp hj
    rw [show (2 : Nat) ^ 3 = 8 by norm_num] at hi' hj'
    unfold degIndicator
    refine if_neg ?_
    rintro ⟨h1, h2, h3, h4⟩
    rw [towerDegree_dim8 i j hi' hj' h1 h2 h3] at h4
    exact hv h4.symm

/-! ## 9. The census function and its closed evaluation -/

/-- `censusT q t` evaluates the multiplicity of the degree `8t + 4` in dimension `2^(q+3)`.
The descent halves `t` when its low bit is set and reflects it at `2^q - 1` when the low
bit vanishes; the extra term `6 (2^(q+3) - 1)` appears exactly at the maximal degree. -/
def censusT : Nat → Nat → Nat
  | 0, t => if t = 0 then 42 else 0
  | q + 1, e =>
      if e % 2 = 1 then
        2 * censusT q (e / 2) + (if e = 2 ^ (q + 1) - 1 then 6 * (2 ^ (q + 3) - 1) else 0)
      else
        if e / 2 < 2 ^ q then 2 * censusT q (2 ^ q - 1 - e / 2) else 0

theorem censusT_eq_zero_of_ge (q t : Nat) (h : 2 ^ q ≤ t) : censusT q t = 0 := by
  induction q generalizing t with
  | zero =>
    have h1 : 1 ≤ t := by simpa using h
    rw [censusT, if_neg (by omega : ¬ t = 0)]
  | succ q ih =>
    have hpow : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    rw [censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd, ih (t / 2) (by omega), if_neg (by omega : ¬ t = 2 ^ (q + 1) - 1)]
    · rw [if_neg hodd, if_neg (by omega : ¬ t / 2 < 2 ^ q)]

/-- **The census formula.**  In dimension `2^(q+3)` the degree `8t + 4` is realised by
exactly `censusT q t` ordered admissible pairs. -/
theorem degreeCount_eq_censusT (q t : Nat) : degreeCount (q + 3) (8 * t + 4) = censusT q t := by
  induction q generalizing t with
  | zero =>
    rw [degreeCount_dim8_eq, censusT]
    by_cases ht : t = 0
    · subst ht; norm_num
    · rw [if_neg ht, if_neg (by omega : ¬ 8 * t + 4 = 4)]
  | succ q ih =>
    have hm : 3 ≤ q + 3 := by omega
    have hpow : (2 : Nat) ^ (q + 3 + 1) = 2 * 2 ^ (q + 3) := by ring
    have hsplit : (2 : Nat) ^ (q + 3) = 8 * 2 ^ q := by
      rw [show q + 3 = 3 + q by omega, pow_add]
      norm_num
    have hgoal : q + 1 + 3 = (q + 3) + 1 := by omega
    rw [hgoal, censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd]
      obtain ⟨s, hs⟩ : ∃ s, t = 2 * s + 1 := ⟨t / 2, by omega⟩
      have hts : t / 2 = s := by omega
      rw [hts]
      by_cases hbig : 2 ^ q ≤ s
      · rw [censusT_eq_zero_of_ge q s hbig,
          if_neg (by omega : ¬ t = 2 ^ (q + 1) - 1),
          degreeCount_eq_zero_of_gt (q + 3 + 1) (8 * t + 4) (by omega) (by omega)]
      · have hvle : 8 * s + 4 ≤ 2 ^ (q + 3) - 4 := by omega
        have harg : 8 * t + 4 = 2 * (8 * s + 4) + 4 := by omega
        rw [harg, degreeCount_succ_low (q + 3) (8 * s + 4) hm (by omega) hvle, ih s]
        have hiff : (8 * s + 4 = 2 ^ (q + 3) - 4) ↔ (t = 2 ^ (q + 1) - 1) := by
          have h2 : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
          omega
        by_cases hmax : t = 2 ^ (q + 1) - 1
        · rw [if_pos hmax, if_pos (hiff.mpr hmax)]
        · rw [if_neg hmax, if_neg (fun h => hmax (hiff.mp h))]
    · rw [if_neg hodd]
      obtain ⟨s, hs⟩ : ∃ s, t = 2 * s := ⟨t / 2, by omega⟩
      have hts : t / 2 = s := by omega
      rw [hts]
      by_cases hbig : 2 ^ q ≤ s
      · rw [if_neg (by omega : ¬ s < 2 ^ q),
          degreeCount_eq_zero_of_gt (q + 3 + 1) (8 * t + 4) (by omega) (by omega)]
      · rw [if_pos (by omega : s < 2 ^ q)]
        have hu : 2 ^ q - 1 - s < 2 ^ q := by omega
        have hvle : 8 * (2 ^ q - 1 - s) + 4 ≤ 2 ^ (q + 3) - 4 := by omega
        have harg : 8 * t + 4
            = 2 ^ (q + 3 + 1) - (2 * (8 * (2 ^ q - 1 - s) + 4) + 4) := by omega
        rw [harg, degreeCount_succ_high (q + 3) (8 * (2 ^ q - 1 - s) + 4) hm (by omega) hvle,
          ih (2 ^ q - 1 - s)]

/-! ## 10. Structure of the distribution -/

/-- Every degree that occurs in dimension `2^(q+3)` is realised by at least `21 · 2^(q+1)`
ordered pairs. -/
theorem censusT_ge (q t : Nat) (h : t < 2 ^ q) : 21 * 2 ^ (q + 1) ≤ censusT q t := by
  induction q generalizing t with
  | zero =>
    have ht : t = 0 := by simpa using h
    subst ht
    rw [censusT]
    norm_num
  | succ q ih =>
    have hpow : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    have hpow2 : (2 : Nat) ^ (q + 1 + 1) = 2 * 2 ^ (q + 1) := by ring
    rw [censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd]
      have := ih (t / 2) (by omega)
      omega
    · rw [if_neg hodd, if_pos (by omega : t / 2 < 2 ^ q)]
      have := ih (2 ^ q - 1 - t / 2) (by omega)
      omega

/-- The maximal degree is the most frequent one. -/
theorem censusT_le_top (q t : Nat) : censusT q t ≤ censusT q (2 ^ q - 1) := by
  induction q generalizing t with
  | zero =>
    rw [censusT, censusT]
    norm_num
    by_cases ht : t = 0 <;> simp [ht]
  | succ q ih =>
    have hpow : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    have hpos : 0 < (2 : Nat) ^ q := Nat.two_pow_pos q
    have htop : censusT (q + 1) (2 ^ (q + 1) - 1)
        = 2 * censusT q (2 ^ q - 1) + 6 * (2 ^ (q + 3) - 1) := by
      rw [censusT, if_pos (by omega), if_pos rfl,
        show (2 ^ (q + 1) - 1) / 2 = 2 ^ q - 1 by omega]
    rw [htop, censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd]
      have h1 := ih (t / 2)
      by_cases hmax : t = 2 ^ (q + 1) - 1
      · rw [if_pos hmax]; omega
      · rw [if_neg hmax]; omega
    · rw [if_neg hodd]
      by_cases hlt : t / 2 < 2 ^ q
      · rw [if_pos hlt]
        have h1 := ih (2 ^ q - 1 - t / 2)
        omega
      · rw [if_neg hlt]
        omega

/-- **The plateau.**  All degrees in the middle band attain the minimal multiplicity
`21 · 2^(r+3)`. -/
theorem censusT_plateau (r t : Nat) (h1 : 2 ^ r ≤ t) (h2 : t ≤ 2 ^ (r + 2) - 1 - 2 ^ r) :
    censusT (r + 2) t = 21 * 2 ^ (r + 3) := by
  induction r generalizing t with
  | zero =>
    have ht : t = 1 ∨ t = 2 := by
      norm_num at h1 h2
      omega
    rcases ht with rfl | rfl <;> decide
  | succ r ih =>
    have e1 : (2 : Nat) ^ (r + 1) = 2 * 2 ^ r := by ring
    have e2 : (2 : Nat) ^ (r + 2) = 4 * 2 ^ r := by ring
    have e3 : (2 : Nat) ^ (r + 3) = 8 * 2 ^ r := by ring
    have e4 : (2 : Nat) ^ (r + 4) = 16 * 2 ^ r := by ring
    have e5 : (2 : Nat) ^ (r + 1 + 2) = 8 * 2 ^ r := by ring
    have e6 : (2 : Nat) ^ (r + 2 + 1) = 8 * 2 ^ r := by ring
    have e7 : (2 : Nat) ^ (r + 1 + 3) = 16 * 2 ^ r := by ring
    have hpos : 0 < (2 : Nat) ^ r := Nat.two_pow_pos r
    have hstep : r + 1 + 2 = (r + 2) + 1 := by omega
    rw [hstep, censusT]
    by_cases hodd : t % 2 = 1
    · rw [if_pos hodd, if_neg (by omega : ¬ t = 2 ^ (r + 2 + 1) - 1),
        ih (t / 2) (by omega) (by omega)]
      have : r + 1 + 3 = (r + 3) + 1 := by omega
      rw [this]
      ring
    · rw [if_neg hodd, if_pos (by omega : t / 2 < 2 ^ (r + 2)),
        ih (2 ^ (r + 2) - 1 - t / 2) (by omega) (by omega)]
      have : r + 1 + 3 = (r + 3) + 1 := by omega
      rw [this]
      ring

/-! ## 11. The census read back in terms of dimensions -/

/-- **Minimal multiplicity.**  In dimension `2ⁿ` (`n ≥ 3`) every degree that occurs is
realised by at least `21 · 2ⁿ⁻²` ordered admissible pairs. -/
theorem degreeCount_ge (n v : Nat) (hn : 3 ≤ n) (hv : v % 8 = 4) (hvle : v ≤ 2 ^ n - 4) :
    21 * 2 ^ (n - 2) ≤ degreeCount n v := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  have hsplit : (2 : Nat) ^ (q + 3) = 8 * 2 ^ q := by
    rw [show q + 3 = 3 + q by omega, pow_add]
    norm_num
  obtain ⟨t, rfl⟩ : ∃ t, v = 8 * t + 4 := ⟨v / 8, by omega⟩
  have ht : t < 2 ^ q := by omega
  rw [degreeCount_eq_censusT q t, show q + 3 - 2 = q + 1 by omega]
  exact censusT_ge q t ht

/-- **The maximal degree is the most frequent.**  No degree is realised by more ordered
pairs than the maximal degree `2ⁿ - 4`. -/
theorem degreeCount_le_max (n v : Nat) (hn : 3 ≤ n) :
    degreeCount n v ≤ degreeCount n (2 ^ n - 4) := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  have hsplit : (2 : Nat) ^ (q + 3) = 8 * 2 ^ q := by
    rw [show q + 3 = 3 + q by omega, pow_add]
    norm_num
  have hpos : 0 < (2 : Nat) ^ q := Nat.two_pow_pos q
  have htop : (2 : Nat) ^ (q + 3) - 4 = 8 * (2 ^ q - 1) + 4 := by omega
  rw [htop, degreeCount_eq_censusT q (2 ^ q - 1)]
  by_cases hv : v % 8 = 4
  · by_cases hvle : v ≤ 2 ^ (q + 3) - 4
    · obtain ⟨t, rfl⟩ : ∃ t, v = 8 * t + 4 := ⟨v / 8, by omega⟩
      rw [degreeCount_eq_censusT q t]
      exact censusT_le_top q t
    · rw [degreeCount_eq_zero_of_gt (q + 3) v hn (by omega)]
      exact Nat.zero_le _
  · rw [degreeCount_eq_zero_of_mod (q + 3) v hn hv]
    exact Nat.zero_le _

/-- **The plateau, in terms of dimensions.**  In dimension `2ⁿ` with `n ≥ 5`, every degree
`8t + 4` whose index lies in the middle band `2ⁿ⁻⁵ ≤ t ≤ 2ⁿ⁻³ - 1 - 2ⁿ⁻⁵` is realised by
exactly `21 · 2ⁿ⁻²` ordered pairs — the minimum.  So the degree distribution is flat over a
band of `2ⁿ⁻³ - 2ⁿ⁻⁴` consecutive degrees. -/
theorem degreeCount_plateau (n t : Nat) (hn : 5 ≤ n) (h1 : 2 ^ (n - 5) ≤ t)
    (h2 : t ≤ 2 ^ (n - 3) - 1 - 2 ^ (n - 5)) :
    degreeCount n (8 * t + 4) = 21 * 2 ^ (n - 2) := by
  obtain ⟨r, rfl⟩ : ∃ r, n = r + 5 := ⟨n - 5, by omega⟩
  rw [show r + 5 = (r + 2) + 3 by omega, degreeCount_eq_censusT (r + 2) t,
    show r + 5 - 2 = r + 3 by omega]
  refine censusT_plateau r t ?_ ?_
  · simpa using h1
  · have : r + 5 - 3 = r + 2 := by omega
    rw [this] at h2
    simpa using h2

/-! ## 12. Completeness of the census -/

theorem sum_range_two_mul (n : Nat) (f : Nat → Nat) :
    ∑ e ∈ range (2 * n), f e = ∑ s ∈ range n, (f (2 * s) + f (2 * s + 1)) := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show 2 * (n + 1) = (2 * n + 1) + 1 by ring, Finset.sum_range_succ,
      Finset.sum_range_succ, ih, Finset.sum_range_succ]
    omega

/-- **The census is complete.**  The multiplicities of the `2^q` possible degrees add up to
the number `(2^(q+3) - 1)(2^(q+3) - 2)` of ordered admissible pairs. -/
theorem censusT_sum (q : Nat) :
    ∑ t ∈ range (2 ^ q), censusT q t = (2 ^ (q + 3) - 1) * (2 ^ (q + 3) - 2) := by
  induction q with
  | zero => decide
  | succ q ih =>
    have hpow : (2 : Nat) ^ (q + 1) = 2 * 2 ^ q := by ring
    have hpow3 : (2 : Nat) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := by ring
    have hge : (8 : Nat) ≤ 2 ^ (q + 3) := eight_le_two_pow (q + 3) (by omega)
    have hpos : 0 < (2 : Nat) ^ q := Nat.two_pow_pos q
    rw [hpow, sum_range_two_mul]
    have hterm : ∀ s ∈ range (2 ^ q),
        censusT (q + 1) (2 * s) + censusT (q + 1) (2 * s + 1)
          = 2 * censusT q (2 ^ q - 1 - s) + 2 * censusT q s
            + (if s = 2 ^ q - 1 then 6 * (2 ^ (q + 3) - 1) else 0) := by
      intro s hs
      have hs' := Finset.mem_range.mp hs
      have hmod : (2 * s) % 2 = 0 := by omega
      have hdiv : (2 * s) / 2 = s := by omega
      have hmod2 : (2 * s + 1) % 2 = 1 := by omega
      have hdiv2 : (2 * s + 1) / 2 = s := by omega
      have h1 : censusT (q + 1) (2 * s) = 2 * censusT q (2 ^ q - 1 - s) := by
        rw [censusT, hmod, hdiv, if_neg (by omega : ¬ (0 : Nat) = 1), if_pos hs']
      have h2 : censusT (q + 1) (2 * s + 1)
          = 2 * censusT q s + (if s = 2 ^ q - 1 then 6 * (2 ^ (q + 3) - 1) else 0) := by
        rw [censusT, hmod2, hdiv2, if_pos rfl]
        by_cases hmax : s = 2 ^ q - 1
        · rw [if_pos hmax, if_pos (by omega : 2 * s + 1 = 2 ^ (q + 1) - 1)]
        · rw [if_neg hmax, if_neg (by omega : ¬ 2 * s + 1 = 2 ^ (q + 1) - 1)]
      rw [h1, h2]
      omega
    rw [Finset.sum_congr rfl hterm, Finset.sum_add_distrib, Finset.sum_add_distrib,
      ← Finset.mul_sum, ← Finset.mul_sum,
      Finset.sum_range_reflect (fun s => censusT q s) (2 ^ q),
      Finset.sum_ite_eq' (range (2 ^ q)) (2 ^ q - 1) (fun _ => 6 * (2 ^ (q + 3) - 1)),
      if_pos (Finset.mem_range.mpr (by omega)), ih]
    have hP : (2 : Nat) ^ (q + 3) - 1 ≥ 7 := by omega
    have hexp : (2 : Nat) ^ (q + 1 + 3) = 2 * 2 ^ (q + 3) := hpow3
    rw [hexp]
    have hfac : ∀ P : Nat, 8 ≤ P →
        2 * ((P - 1) * (P - 2)) + 2 * ((P - 1) * (P - 2)) + 6 * (P - 1)
          = (2 * P - 1) * (2 * P - 2) := by
      intro P hPle
      obtain ⟨R, rfl⟩ : ∃ R, P = R + 8 := ⟨P - 8, by omega⟩
      rw [show R + 8 - 1 = R + 7 by omega, show R + 8 - 2 = R + 6 by omega,
        show 2 * (R + 8) - 1 = 2 * R + 15 by omega,
        show 2 * (R + 8) - 2 = 2 * R + 14 by omega]
      ring
    exact hfac (2 ^ (q + 3)) hge

/-- The census is complete, in terms of dimensions: in dimension `2ⁿ` the multiplicities of
the degrees `8t + 4`, `t < 2ⁿ⁻³`, add up to the number of ordered admissible pairs. -/
theorem degreeCount_sum (n : Nat) (hn : 3 ≤ n) :
    ∑ t ∈ range (2 ^ (n - 3)), degreeCount n (8 * t + 4) = (2 ^ n - 1) * (2 ^ n - 2) := by
  obtain ⟨q, rfl⟩ : ∃ q, n = q + 3 := ⟨n - 3, by omega⟩
  rw [show q + 3 - 3 = q by omega,
    Finset.sum_congr rfl (fun t _ => degreeCount_eq_censusT q t)]
  exact censusT_sum q

/-! ## 13. Explicit censuses -/

/-- The degree census in dimension `64`, recovered from the recursion; it agrees with the
enumeration `dim64_degree_counts`. -/
theorem census_dim64 :
    (List.range 4).map (fun t => degreeCount (2 + 3) (8 * t + 4)) = [252, 168, 168, 342] := by
  simp only [degreeCount_eq_censusT]
  rfl

/-- The degree census in dimension `128`: the multiplicities of the degrees
`4, 12, …, 124`. -/
theorem census_dim128 :
    (List.range 16).map (fun t => degreeCount (4 + 3) (8 * t + 4))
      = [1740, 1368, 1008, 1008, 672, 672, 672, 672, 672, 672, 672, 672, 1008, 1008, 1368,
          2118] := by
  simp only [degreeCount_eq_censusT]
  rfl

/-- The degree census in dimension `256`. -/
theorem census_dim256 :
    (List.range 32).map (fun t => degreeCount (5 + 3) (8 * t + 4))
      = [4236, 3480, 2736, 2736, 2016, 2016, 2016, 2016, 1344, 1344, 1344, 1344, 1344, 1344,
          1344, 1344, 1344, 1344, 1344, 1344, 1344, 1344, 1344, 1344, 2016, 2016, 2016, 2016,
          2736, 2736, 3480, 4998] := by
  simp only [degreeCount_eq_censusT]
  rfl

end Sovereign
