# Logos bridge certificates — UNCOMPILED

## What is new

- ComponentTransport: explicit blow-up component equivalence with no-isolates
  hypothesis; an isomorphism to the existing signed ZD graph; c=8R-1 with the
  component count and Hankel matrix now belonging to the same repGraph.
- Dimension32Data: decoded 28-vertex charge17 component, actual source Laplacian,
  full integer eigenbasis, rational inverse, Gram/projector finite leaves and walks.
- Dimension32: multiplicities, polynomial zero projector, positive Gram gap bound,
  a Rayleigh vector attaining6, variational gap6 and Cheeger bounds3<=h<=4.
- GapApiSmoke: imports the renamed variational API, unchanged sorted-eigenvalue
  API, earlier conditional Cheeger candidate and new dimension32 certificate.

The exact Python result h=4 is NOT a new Lean theorem. General hard Cheeger and
variational/sorted-gap equivalence remain open formalization tasks in this project.

## Exact reproduction

```bash
python verify_certificates.py
```

Standard library only. The verifier checks all1100 labeled simple graphs of orders
0 through5 for two-/three-fold component transport, then the explicit rational
spectral/Gram identities. All4,782,969 twin-occupancy states cover2^28 labeled cuts
and yield the full exact dimension32 isoperimetric profile (h=4, conductance1/3).
It regenerates dimension32-certificate.json and BridgeCert/Dimension32Data.lean.
The helper compute_bridges.py is included. Floating elapsed time is metadata only;
all mathematical comparisons and matrix identities use integers or Fractions.

## External Lean verification (NOT RUN)

Requires Lean4 v4.28.0, Lake, Git/network and the pinned Mathlib revision.

```bash
lake update
lake build BridgeCert
lake env lean BridgeCert/TrustInventory.lean
```

To isolate the cost of the new finite kernel-decision leaves after dependencies
are available, run `lake env lean BridgeCert/Dimension32Data.lean`. Their cost is
unmeasured. No compiler output or axiom inventory is claimed. Repair elaboration
errors before declaring formal completion. The new files contain no admissions,
new axioms or native_decide, but imported original files retain existing native
sites; trust must be measured per theorem with the provided queries.

## Documented review-copy patches

Uploaded originals and both earlier staging projects are unchanged. In copied
RequestProject modules and affected earlier candidates, the identifier prefix
spectralGap is renamed variationalGap. Sovereign's sorted spectralGap is unchanged.
This removes the identified naming collision at source level, not by claiming a
min-max theorem. Both declarations are referenced by the uncompiled smoke target.
A previous candidate header/comment is normalized and the box-kite charpoly proof
gets an explicit matrix reassociation. source-provenance.json records both hashes
and every adjustment; review-copy-patches.diff shows the complete patch.

All other selected dependencies are byte-preserved. Numerical certificates and
source/import/placeholder scans are not Lean elaboration or theorem certification.
