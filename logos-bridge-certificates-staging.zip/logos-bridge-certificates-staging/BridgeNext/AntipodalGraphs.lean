/-
UNCOMPILED CANDIDATE. Actual SimpleGraph packaging of crossDegree, then an explicit
antipodal two-fold independent blow-up and representative moment normalization.
The four-fold twin quotient in SectorTwinQuotient is DIFFERENT from this two-fold map.
-/
import BridgeLab.SignedGraphMoments
import Sovereign.Graph.SectorTwinQuotient

namespace BridgeNext.AntipodalGraphs
open Sovereign Sovereign.Graph Matrix Finset

section General
variable {V : Type*} [Fintype V] [DecidableEq V]
    (G : SimpleGraph V) [DecidableRel G.Adj]

def blowUp : SimpleGraph (V × Bool) where
  Adj x y := G.Adj x.1 y.1
  symm _ _ h := h.symm
  loopless := ⟨fun x => G.loopless x.1⟩

instance : DecidableRel (blowUp G).Adj := fun _ _ => inferInstance

lemma blowUp_degree (v : V) (b : Bool) : (blowUp G).degree (v,b) = 2 * G.degree v := by
  classical
  have hs : (blowUp G).neighborFinset (v,b) = G.neighborFinset v ×ˢ Finset.univ := by
    ext w
    simp [SimpleGraph.mem_neighborFinset, blowUp]
  rw [← SimpleGraph.card_neighborFinset_eq_degree, hs, Finset.card_product]
  simp [SimpleGraph.card_neighborFinset_eq_degree, mul_comm]

def vertexMoment (k : ℕ) : ℤ := ∑ v, (G.degree v : ℤ)^k

lemma blowUp_moment (k : ℕ) :
    vertexMoment (blowUp G) k = 2 * (2 : ℤ)^k * vertexMoment G k := by
  unfold vertexMoment
  rw [Fintype.sum_prod_type]
  simp_rw [blowUp_degree, Nat.cast_mul, Nat.cast_ofNat, mul_pow]
  simp only [Fintype.sum_bool]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro v hv
  ring

end General

lemma moment_eq_of_iso {V W : Type*} [Fintype V] [Fintype W]
    [DecidableEq V] [DecidableEq W] {G : SimpleGraph V} {H : SimpleGraph W}
    [DecidableRel G.Adj] [DecidableRel H.Adj] (e : G ≃g H) (k : ℕ) :
    vertexMoment G k = vertexMoment H k := by
  unfold vertexMoment
  exact Fintype.sum_equiv e.toEquiv _ _ (fun v => by rw [e.degree_eq v])

/-- All admissible signed cross-half vertices, with no fitted degree declaration. -/
def fullGraph (n : ℕ) : SimpleGraph (admVertex n) where
  Adj p q := crossAnnihilates n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2
    q.1.1 q.1.2.1 q.1.2.2.1 q.1.2.2.2 = true
  symm p q h := by
    rw [← crossAnnihilates_comm n p.1.1 p.1.2.1 q.1.1 q.1.2.1 _ _ _ _
      p.1.2.2.1.isLt p.1.2.2.2.isLt q.1.2.2.1.isLt q.1.2.2.2.isLt p.2.1 q.2.1]
    exact h
  loopless := ⟨fun p h => by
    have ha := assocNeg_of_crossAnnihilates n p.1.1 p.1.2.1 p.1.1 p.1.2.1
      _ _ _ _ p.1.2.2.1.isLt p.1.2.2.2.isLt p.1.2.2.1.isLt h
    rw [assoc_middles_four n _ _ _ p.1.2.2.1.isLt p.1.2.2.2.isLt
      (Or.inr (Or.inl rfl))] at ha
    exact Bool.false_ne_true ha⟩

instance (n : ℕ) : DecidableRel (fullGraph n).Adj := fun _ _ => by
  unfold fullGraph
  infer_instance

lemma fullGraph_degree (n : ℕ) (p : admVertex n) :
    (fullGraph n).degree p = crossDegree n p.1.1 p.1.2.1 p.1.2.2.1 p.1.2.2.2 := by
  have hr : ((fullGraph n).degree p : ℝ) = ∑ q, crossAdj n p q := by
    rw [← SimpleGraph.card_neighborFinset_eq_degree, SimpleGraph.neighborFinset_eq_filter,
      Finset.card_filter]
    push_cast
    apply Finset.sum_congr rfl
    intro q hq
    simp [crossAdj, fullGraph]
  rw [crossAdj_rowSum_eq_crossDegree] at hr
  exact_mod_cast hr

/-- Reindexing only: Nat finite-set pairs/signs to the existing Fin-indexed vertices. -/
def pairSignsEquiv (n : ℕ) : (↥(admissiblePairs n) × (Bool × Bool)) ≃ admVertex n where
  toFun p := by
    have hp := Finset.mem_filter.mp p.1.2
    have hi := Finset.mem_range.mp (Finset.mem_product.mp hp.1).1
    have hj := Finset.mem_range.mp (Finset.mem_product.mp hp.1).2
    exact ⟨(p.2.1,p.2.2,⟨p.1.1.1,hi⟩,⟨p.1.1.2,hj⟩),hp.2⟩
  invFun v := (⟨((v.1.2.2.1 : ℕ),(v.1.2.2.2 : ℕ)), by
    simp only [admissiblePairs, Finset.mem_filter, Finset.mem_product, Finset.mem_range]
    exact ⟨⟨v.1.2.2.1.isLt,v.1.2.2.2.isLt⟩,v.2⟩⟩,(v.1.1,v.1.2.1))
  left_inv _ := rfl
  right_inv _ := rfl

lemma fullGraph_moment_eq_signed (n k : ℕ) :
    vertexMoment (fullGraph n) k = BridgeLab.GraphMoments.signedGraphMoment n k := by
  unfold vertexMoment
  simp_rw [fullGraph_degree]
  rw [← Equiv.sum_comp (pairSignsEquiv n)]
  rw [Fintype.sum_prod_type]
  change (∑ p : ↥(admissiblePairs n), ∑ s : Bool × Bool,
    (crossDegree n s.1 s.2 p.1.1 p.1.2 : ℤ)^k) = _
  rw [Finset.sum_coe_sort]
  rfl

abbrev RepVertex (n : ℕ) := ↥(admissiblePairs n) × Bool

def canonicalVertex (n : ℕ) (v : RepVertex n) : admVertex n :=
  pairSignsEquiv n (v.1,(false,v.2))

def repGraph (n : ℕ) : SimpleGraph (RepVertex n) := (fullGraph n).comap (canonicalVertex n)

instance (n : ℕ) : DecidableRel (repGraph n).Adj := fun _ _ => by
  unfold repGraph SimpleGraph.comap
  infer_instance

lemma canonical_annihilation (n : ℕ) (s t u r : Bool) (i j k m : ℕ) :
    crossAnnihilates n s t i j u r k m =
      crossAnnihilates n false (xor s t) i j false (xor u r) k m := by
  rw [crossAnnihilates_sign_xor n s t false (xor s t) u r i j k m
    (by cases s <;> cases t <;> rfl)]
  cases u <;> cases r
  · rfl
  · rfl
  · exact crossAnnihilates_involution n false (xor s t) false true i j k m
  · exact crossAnnihilates_involution n false (xor s t) false false i j k m

/-- Global sign is the twin coordinate; relative sign determines the representative. -/
def signSplit (n : ℕ) : admVertex n ≃ RepVertex n × Bool :=
  (pairSignsEquiv n).symm.trans
    { toFun := fun p => ((p.1,xor p.2.1 p.2.2),p.2.1)
      invFun := fun v => (v.1.1,(v.2,xor v.2 v.1.2))
      left_inv := by rintro ⟨p,s,t⟩; cases s <;> cases t <;> rfl
      right_inv := by rintro ⟨⟨p,r⟩,s⟩; cases s <;> cases r <;> rfl }

def antipodalIso (n : ℕ) : fullGraph n ≃g blowUp (repGraph n) where
  toEquiv := signSplit n
  map_rel_iff' := by
    intro p q
    change crossAnnihilates n false (xor p.1.1 p.1.2.1) _ _
      false (xor q.1.1 q.1.2.1) _ _ = true ↔
      crossAnnihilates n p.1.1 p.1.2.1 _ _ q.1.1 q.1.2.1 _ _ = true
    exact (Bool.eq_iff_iff.mp (canonical_annihilation n p.1.1 p.1.2.1 q.1.1 q.1.2.1
      p.1.2.2.1 p.1.2.2.2 q.1.2.2.1 q.1.2.2.2)).symm

/-- Actual signed SimpleGraph moments, not only the original raw count model. -/
theorem fullGraph_moment_census (q k : ℕ) :
    vertexMoment (fullGraph (q+3)) k = 4 * (2 : ℤ)^k * censusMoment k q := by
  rw [fullGraph_moment_eq_signed, BridgeLab.GraphMoments.signedGraphMoment_eq_census]

/-- Actual antipodal representative graph moments; the degree halves as well. -/
theorem repGraph_moment_census (q k : ℕ) :
    vertexMoment (repGraph (q+3)) k = 2 * censusMoment k q := by
  have hb : vertexMoment (fullGraph (q+3)) k =
      2 * (2 : ℤ)^k * vertexMoment (repGraph (q+3)) k := by
    rw [moment_eq_of_iso (antipodalIso (q+3)) k, blowUp_moment]
  have hp : (2 * (2 : ℤ)^k) * vertexMoment (repGraph (q+3)) k =
      (2 * (2 : ℤ)^k) * (2 * censusMoment k q) := by
    calc
      _ = vertexMoment (fullGraph (q+3)) k := hb.symm
      _ = 4 * (2 : ℤ)^k * censusMoment k q := fullGraph_moment_census q k
      _ = _ := by ring
  exact mul_left_cancel₀ (by positivity : (2 * (2 : ℤ)^k) ≠ 0) hp

end BridgeNext.AntipodalGraphs
