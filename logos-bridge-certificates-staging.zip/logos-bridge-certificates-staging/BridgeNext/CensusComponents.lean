/-
UNCOMPILED CANDIDATE. Positive-measure rank specialized to the actual census;
component count is REUSED from the supplied uniform charge-connectivity proof.
Census dimension 2^(q+3); cross-half ambient graph dimension 2^(q+4).
-/
import BridgeNext.PositiveHankel
import BridgeNext.AntipodalGraphs
import Sovereign.Combinatorics.TowerDegreeMomentsUniform
import Sovereign.Algebra.CrossHalfZeroDivisorTheorem

namespace BridgeNext.CensusComponents
open Sovereign Matrix

noncomputable def censusHankel (q r : ℕ) : Matrix (Fin r) (Fin r) ℝ :=
  fun i j => (censusMoment (i.val + j.val) q : ℝ)

lemma censusHankel_eq_atomic (q r : ℕ) : censusHankel q r =
    PositiveHankel.hankel (fun a : Fin (2^q) => 8 * (a.val : ℝ) + 4)
      (fun a => (censusT q a.val : ℝ)) r := by
  ext i j
  unfold censusHankel PositiveHankel.hankel censusMoment
  push_cast
  simpa only [mul_comm] using
    (Fin.sum_univ_eq_sum_range (fun t : ℕ =>
      (8 * (t : ℝ) + 4) ^ (i.val + j.val) * (censusT q t : ℝ)) (2^q)).symm

lemma censusT_positive (q : ℕ) (a : Fin (2^q)) : 0 < (censusT q a.val : ℝ) := by
  have h := censusT_ge q a.val a.isLt
  have hp : 0 < 21 * (2 : ℕ)^(q+1) := by positivity
  exact_mod_cast lt_of_lt_of_le hp h

/-- Full finite-truncation formula, not just an informal infinite Hankel rank. -/
theorem censusHankel_rank (q r : ℕ) : (censusHankel q r).rank = min r (2^q) := by
  rw [censusHankel_eq_atomic]
  apply PositiveHankel.rank_hankel
  · intro i j hij
    apply Fin.ext
    have hc : (i.val : ℝ) = j.val := by linarith
    exact_mod_cast hc
  · exact censusT_positive q

noncomputable def representativeHankel (q r : ℕ) : Matrix (Fin r) (Fin r) ℝ :=
  fun i j => (AntipodalGraphs.vertexMoment (AntipodalGraphs.repGraph (q+3))
    (i.val+j.val) : ℝ)

lemma representativeHankel_eq_scaled (q r : ℕ) :
    representativeHankel q r = (2 : ℝ) • censusHankel q r := by
  ext i j
  simp only [representativeHankel, censusHankel, Matrix.smul_apply, smul_eq_mul]
  rw [AntipodalGraphs.repGraph_moment_census]
  push_cast
  rfl

/-- The rank statement now applies to actual representative-graph degree moments. -/
theorem representativeHankel_rank (q r : ℕ) :
    (representativeHankel q r).rank = min r (2^q) := by
  rw [representativeHankel_eq_scaled, censusHankel_eq_atomic,
    ← PositiveHankel.hankel_weight_scale]
  apply PositiveHankel.rank_hankel
  · intro i j hij
    apply Fin.ext
    have hc : (i.val : ℝ) = j.val := by linarith
    exact_mod_cast hc
  · intro a
    exact mul_pos (by norm_num) (censusT_positive q a)

/-- The finite set counts components meeting the cross-half ZD set, not all
components of the ambient infinite Label graph (which has additional isolates).
This recycles CrossHalfComponents.component_count; no new connectivity conjecture.
-/
theorem crossHalf_components_eq_eight_rank_sub_one (q : ℕ) :
    (CrossHalfComponents.components (q+3)).card =
      8 * (censusHankel q (2^q)).rank - 1 := by
  rw [CrossHalfComponents.component_count (by omega), censusHankel_rank, min_self]
  have hpow : (2 : ℕ)^(q+3) = 8 * 2^q := by ring
  rw [hpow]

theorem crossHalf_components_eq_eight_representative_rank_sub_one (q : ℕ) :
    (CrossHalfComponents.components (q+3)).card =
      8 * (representativeHankel q (2^q)).rank - 1 := by
  rw [CrossHalfComponents.component_count (by omega), representativeHankel_rank, min_self]
  have hpow : (2 : ℕ)^(q+3) = 8 * 2^q := by ring
  rw [hpow]

end BridgeNext.CensusComponents
