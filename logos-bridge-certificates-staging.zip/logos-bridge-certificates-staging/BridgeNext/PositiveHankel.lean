/-
UNCOMPILED CANDIDATE. Finite positive atomic measures: Hankel rank = min(size,support).
Only Mathlib is imported. No graph or algebra-specific polynomial is substituted.
-/
import Mathlib

namespace BridgeNext.PositiveHankel
open Matrix

noncomputable def hankel {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) :
    Matrix (Fin r) (Fin r) ℝ := fun i j => ∑ a, w a * x a ^ (i.val + j.val)

lemma hankel_weight_scale {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) (c : ℝ) :
    hankel x (fun a => c * w a) r = c • hankel x w r := by
  ext i j
  simp only [hankel, Matrix.smul_apply, smul_eq_mul]
  rw [Finset.mul_sum]
  apply Finset.sum_congr rfl
  intro a ha
  ring

def evaluation {s : ℕ} (x : Fin s → ℝ) (r : ℕ) : Matrix (Fin s) (Fin r) ℝ :=
  fun a j => x a ^ j.val

noncomputable def sqrtEvaluation {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) :
    Matrix (Fin s) (Fin r) ℝ := Matrix.diagonal (fun a => Real.sqrt (w a)) * evaluation x r

lemma sqrtEvaluation_apply {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) (a : Fin s) (j : Fin r) :
    sqrtEvaluation x w r a j = Real.sqrt (w a) * x a ^ j.val := by
  simp [sqrtEvaluation, evaluation, Matrix.diagonal_mul]

lemma gram_identity {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) (hw : ∀ a, 0 ≤ w a) :
    hankel x w r = (sqrtEvaluation x w r)ᵀ * sqrtEvaluation x w r := by
  ext i j
  simp only [hankel, Matrix.mul_apply, Matrix.transpose_apply, sqrtEvaluation_apply]
  apply Finset.sum_congr rfl
  intro a ha
  calc
    w a * x a ^ (i.val + j.val) =
        (Real.sqrt (w a))^2 * (x a ^ i.val * x a ^ j.val) := by
      rw [Real.sq_sqrt (hw a), pow_add]
    _ = (Real.sqrt (w a) * x a ^ i.val) *
        (Real.sqrt (w a) * x a ^ j.val) := by ring

lemma rank_eq_evaluation {s : ℕ} (x w : Fin s → ℝ) (r : ℕ) (hw : ∀ a, 0 < w a) :
    (hankel x w r).rank = (evaluation x r).rank := by
  have hD : IsUnit ((Matrix.diagonal (fun a => Real.sqrt (w a))).det) := by
    apply isUnit_iff_ne_zero.mpr
    rw [Matrix.det_diagonal]
    exact Finset.prod_ne_zero_iff.mpr (fun a _ => ne_of_gt (Real.sqrt_pos.2 (hw a)))
  rw [gram_identity x w r (fun a => le_of_lt (hw a)), Matrix.rank_transpose_mul_self]
  exact Matrix.rank_mul_eq_right_of_isUnit_det _ _ hD

lemma rank_vandermonde {s : ℕ} (x : Fin s → ℝ) (hx : Function.Injective x) :
    (Matrix.vandermonde x).rank = s := by
  have hd : IsUnit (Matrix.vandermonde x).det :=
    isUnit_iff_ne_zero.mpr (Matrix.det_vandermonde_ne_zero_iff.mpr hx)
  have h := Matrix.rank_mul_eq_left_of_isUnit_det (Matrix.vandermonde x)
    (1 : Matrix (Fin s) (Fin s) ℝ) hd
  simpa using h

lemma rank_evaluation {s : ℕ} (x : Fin s → ℝ) (r : ℕ) (hx : Function.Injective x) :
    (evaluation x r).rank = min r s := by
  by_cases hrs : r ≤ s
  · rw [Nat.min_eq_left hrs]
    apply le_antisymm (by simpa using (evaluation x r).rank_le_card_width)
    let f : Fin r → Fin s := Fin.castLE hrs
    let y : Fin r → ℝ := x ∘ f
    have hy : Function.Injective y := by
      intro i j hij
      apply Fin.ext
      exact congrArg Fin.val (hx hij)
    have he : (evaluation x r).submatrix f (Equiv.refl (Fin r)) = Matrix.vandermonde y := rfl
    have hm := Matrix.rank_submatrix_le f (Equiv.refl (Fin r)) (evaluation x r)
    rw [he, rank_vandermonde y hy] at hm
    exact hm
  · have hsr : s ≤ r := by omega
    rw [Nat.min_eq_right hsr]
    apply le_antisymm (by simpa using (evaluation x r).rank_le_card_height)
    let f : Fin s → Fin r := Fin.castLE hsr
    have he : ((evaluation x r)ᵀ).submatrix f (Equiv.refl (Fin s)) =
        (Matrix.vandermonde x)ᵀ := rfl
    have hm := Matrix.rank_submatrix_le f (Equiv.refl (Fin s)) (evaluation x r)ᵀ
    rw [he, Matrix.rank_transpose, Matrix.rank_transpose, rank_vandermonde x hx] at hm
    exact hm

/-- Distinct atoms and strictly positive weights are both explicit hypotheses. -/
theorem rank_hankel {s : ℕ} (x w : Fin s → ℝ) (r : ℕ)
    (hx : Function.Injective x) (hw : ∀ a, 0 < w a) :
    (hankel x w r).rank = min r s := by
  rw [rank_eq_evaluation x w r hw, rank_evaluation x r hx]

end BridgeNext.PositiveHankel
